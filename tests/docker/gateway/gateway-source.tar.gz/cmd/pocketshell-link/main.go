// pocketshell-link is the host-side CLI of the PocketShell reverse tunnel.
//
//	pocketshell-link enroll --token-stdin [--server wss://gateway.pocketshell.io]
//	                        [--device-id ID] [--ssh-host 127.0.0.1:22]
//	                        [--expect-host-key 'ssh-ed25519 AAAA...']
//	pocketshell-link run    [--server ...] [--config-dir DIR] [--insecure-dev]
//	pocketshell-link show   [--config-dir DIR]
//	pocketshell-link version [--json]
//
// enroll generates (or reuses) the local Ed25519 device identity, probes
// the real local sshd host key over loopback, pins it, and enrolls the
// device with the gateway using a signed challenge. The gateway credential
// is the SHORT-LIVED BROKER TOKEN from the PocketShell web UI (sign in
// there; the UI mints a gateway-scoped token). It is read from stdin
// (--token-stdin), validated locally, and only ever sent as an
// Authorization header — never in a URL, argv or log line. A Google ID
// token or any other credential is refused locally before any request.
//
// run maintains the outbound WSS control connection; the gateway can open
// multiplexed streams, each bridged to the configured loopback-only SSH
// endpoint. No inbound ports are opened anywhere.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"os"
	"os/signal"
	"regexp"
	"runtime/debug"
	"strings"
	"syscall"

	"github.com/PocketShell-io/pocketshell-gateway/internal/hostagent"
)

// version and commit are injected into release builds; an unset version is
// never silently presented as a release:
//
//	go build -ldflags "-X main.version=v1.0.0 -X main.commit=<git-sha>" ./cmd/pocketshell-link
//
// Release artifacts prove which tag built them; a source build resolves to
// the visible non-release spelling "devel" with the commit taken from Go's
// VCS stamping when available (or "unknown"). There is no "dev" spelling.
var (
	version = ""
	commit  = ""
)

// protocolVersionTag is the compatibility contract between the PocketShell
// CLI wrapper and this helper: the wrapper keys compatibility on THIS tag,
// not on the release version. Bump it (pocketshell-tunnel-v2, ...) on any
// wire-INCOMPATIBLE change — handshake shapes, control frames, or the
// enroll API contract. Additive changes (new optional wire fields, new
// subcommands, appended --json fields) keep the tag unchanged. The tag
// tracks major version 1 of the tunnel wire protocol (internal/tunnel:
// ProtocolTunnel / ProtocolVersion).
const protocolVersionTag = "pocketshell-tunnel-v1"

// versionJSON is the machine-readable `version --json` payload. FROZEN
// ADDITIVE CONTRACT, like the argv surface: existing fields keep their
// names, types and meaning forever; compatibility-affecting changes bump
// protocolVersionTag instead.
type versionJSON struct {
	Version  string `json:"version"`
	Protocol string `json:"protocol"`
	Commit   string `json:"commit"`
}

// pseudoVersionMark matches the timestamp-commit core Go embeds in
// VCS-derived pseudo-versions (all three forms share it). A version
// containing it was derived from version-control state, not from a release
// tag: it must surface as the honest "devel" spelling, never as a version
// a consumer could mistake for a release.
var pseudoVersionMark = regexp.MustCompile(`-\d{14}-[0-9a-f]{12}`)

// resolvedMetadata returns the effective build metadata. Injected release
// values win; otherwise Go build info supplies a real module version (e.g.
// `go install …@v1.2.3`) and the VCS revision; whatever remains unknown is
// spelled out honestly so no build can pass a hardcoded dev string off as
// a release.
func resolvedMetadata() (ver, cmt string) {
	ver, cmt = strings.TrimSpace(version), strings.TrimSpace(commit)
	if info, ok := debug.ReadBuildInfo(); ok {
		if ver == "" {
			mv := info.Main.Version
			if mv != "" && mv != "(devel)" && !pseudoVersionMark.MatchString(mv) {
				ver = mv
			}
		}
		if cmt == "" {
			for _, s := range info.Settings {
				if s.Key == "vcs.revision" && s.Value != "" {
					cmt = s.Value
					break
				}
			}
		}
	}
	if ver == "" {
		ver = "devel"
	}
	if cmt == "" {
		cmt = "unknown"
	}
	return ver, cmt
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}

func run(args []string, stdout, stderr io.Writer) int {
	if len(args) == 0 {
		usage(stdout)
		return 2
	}
	switch args[0] {
	case "enroll":
		return cmdEnroll(args[1:], stdout, stderr)
	case "run":
		return cmdRun(args[1:], stdout, stderr)
	case "show":
		return cmdShow(args[1:], stdout, stderr)
	case "version":
		return cmdVersion(args[1:], stdout, stderr)
	case "-h", "--help", "help":
		usage(stdout)
		return 0
	default:
		fmt.Fprintf(stderr, "unknown command %q\n\n", args[0])
		usage(stderr)
		return 2
	}
}

func usage(w io.Writer) {
	fmt.Fprint(w, `pocketshell-link — PocketShell host tunnel CLI

Usage:
  pocketshell-link enroll --token-stdin [flags]
  pocketshell-link run [flags]
  pocketshell-link show [flags]
  pocketshell-link version [--json]

Commands:
  enroll  generate device key, pin the local sshd host key, enroll with the gateway
  run     maintain the reverse tunnel to the gateway
  show    print the enrolled configuration (no secrets)
  version print the build version and tunnel protocol tag (--json: one JSON line)
`)
}

// cmdVersion reports the build metadata. The human line keeps its shape for
// compatibility; `--json` emits the frozen one-line machine contract.
// Neither path logs: version output is parsed by scripts and CI.
func cmdVersion(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("version", flag.ContinueOnError)
	fs.SetOutput(stderr)
	asJSON := fs.Bool("json", false, `print one JSON line: {"version":…,"protocol":…,"commit":…} (frozen additive contract)`)
	if err := fs.Parse(args); err != nil {
		return 2
	}
	if fs.NArg() > 0 {
		fmt.Fprintf(stderr, "unknown argument %q for version\n\n", fs.Arg(0))
		fs.Usage()
		return 2
	}
	ver, cmt := resolvedMetadata()
	if *asJSON {
		if err := json.NewEncoder(stdout).Encode(versionJSON{
			Version: ver, Protocol: protocolVersionTag, Commit: cmt,
		}); err != nil {
			fmt.Fprintf(stderr, "version: %v\n", err)
			return 1
		}
		return 0
	}
	fmt.Fprintf(stdout, "pocketshell-link %s (protocol %s)\n", ver, protocolVersionTag)
	return 0
}

func commonFlags(fs *flag.FlagSet) (server *string, dir *string, insecure *bool, verbose *bool) {
	server = fs.String("server", "", "gateway base URL (default "+hostagent.DefaultServerURL+"); wss/https")
	dir = fs.String("config-dir", hostagent.DefaultDir(), "agent configuration directory")
	insecure = fs.Bool("insecure-dev", false, "DEV ONLY: allow plain ws:// or http:// gateway URLs (e.g. docker). Local SSH stays loopback-only. TLS verification is never skipped.")
	verbose = fs.Bool("verbose", false, "log debug output")
	return
}

func loggerFor(stdout, stderr io.Writer, verbose bool) *slog.Logger {
	level := slog.LevelInfo
	if verbose {
		level = slog.LevelDebug
	}
	return slog.New(slog.NewTextHandler(stderr, &slog.HandlerOptions{Level: level}))
}

func cmdEnroll(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("enroll", flag.ContinueOnError)
	fs.SetOutput(stderr)
	server, dir, insecure, _ := commonFlags(fs)
	tokenStdin := fs.Bool("token-stdin", false, "read the gateway broker token from stdin (required; the token never touches argv/URLs). Get it from the PocketShell web UI — it is a short-lived token scoped to this gateway, NOT a Google ID token")
	deviceID := fs.String("device-id", "", "device ID (default: auto-generated from hostname)")
	sshHost := fs.String("ssh-host", "127.0.0.1:22", "local SSH endpoint; loopback only (host:port)")
	expectKey := fs.String("expect-host-key", "", "authorized_keys line or SHA256 fingerprint the local sshd's SELECTED host key must match, else abort (digest comparison is case-sensitive; the probe negotiates the browser-supported policy: ssh-ed25519 > rsa-sha2-512 > rsa-sha2-256 > ssh-rsa — an expected fingerprint of a non-selected offered key is an honest refusal, never a pin swap)")
	reenroll := fs.Bool("re-enroll", false, "request explicit replacement of an existing registration (requires the gateway to allow re-enrollment)")
	devIssuer := fs.String("dev-broker-issuer", "", "DEV ONLY (requires --insecure-dev): lab issuer whose broker tokens the local guard accepts; production always uses the sync broker")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	if !*tokenStdin {
		fmt.Fprintln(stderr, "enroll requires --token-stdin: pipe the SHORT-LIVED GATEWAY BROKER TOKEN from the PocketShell web UI, e.g.")
		fmt.Fprintln(stderr, "  pbpaste | pocketshell-link enroll --token-stdin")
		fmt.Fprintln(stderr, "Do NOT pipe a Google ID token: it is refused locally, before anything is sent.")
		return 2
	}
	token, err := readAllStdin()
	if err != nil {
		fmt.Fprintf(stderr, "read token from stdin: %v\n", err)
		return 1
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	_, err = hostagent.RunEnroll(ctx, hostagent.EnrollOptions{
		Dir:           *dir,
		Server:        hostagent.ResolveServer(*server),
		Token:         token,
		DeviceID:      *deviceID,
		SSHHost:       *sshHost,
		ExpectHostKey: *expectKey,
		Reenroll:      *reenroll,
		InsecureDev:   *insecure,
		BrokerIssuer:  *devIssuer,
		Stdout:        stdout,
		Stderr:        stderr,
	})
	if err != nil {
		fmt.Fprintf(stderr, "enroll failed: %v\n", err)
		return 1
	}
	return 0
}

func cmdRun(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("run", flag.ContinueOnError)
	fs.SetOutput(stderr)
	server, dir, insecure, verbose := commonFlags(fs)
	if err := fs.Parse(args); err != nil {
		return 2
	}
	log := loggerFor(stdout, stderr, *verbose)
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	err := hostagent.RunAgent(ctx, hostagent.RunOptions{
		Dir:         *dir,
		Server:      *server,
		InsecureDev: *insecure,
		Logger:      log,
	})
	if err == nil || ctx.Err() != nil {
		fmt.Fprintln(stderr, "pocketshell-link stopped")
		return 0
	}
	fmt.Fprintf(stderr, "pocketshell-link exited: %v\n", err)
	return 1
}

func cmdShow(args []string, stdout, stderr io.Writer) int {
	fs := flag.NewFlagSet("show", flag.ContinueOnError)
	fs.SetOutput(stderr)
	_, dir, _, _ := commonFlags(fs)
	if err := fs.Parse(args); err != nil {
		return 2
	}
	st, err := hostagent.ShowStatus(*dir)
	if err != nil {
		fmt.Fprintf(stderr, "show failed: %v\n", err)
		return 1
	}
	fmt.Fprintf(stdout, "server:          %s\n", st.Server)
	fmt.Fprintf(stdout, "device id:       %s\n", st.DeviceID)
	fmt.Fprintf(stdout, "local ssh:       %s (loopback only)\n", st.SSHHost)
	fmt.Fprintf(stdout, "device key:      %s\n", st.DeviceKeyFP)
	fmt.Fprintf(stdout, "pinned ssh host key: %s\n", st.PinnedHostKey)
	return 0
}

func readAllStdin() (string, error) {
	data, err := io.ReadAll(os.Stdin)
	if err != nil {
		return "", err
	}
	// A pasted/piped token often carries a trailing newline.
	return strings.TrimSpace(string(data)), nil
}
