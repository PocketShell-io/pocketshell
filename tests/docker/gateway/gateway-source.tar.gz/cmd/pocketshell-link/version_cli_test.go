package main

// Real-binary tests for the frozen version metadata contract (CLI gateway
// contract request): the helper is built with INJECTED release metadata the
// way release artifacts are built, and every observable surface — the
// `version --json` line, the human line, and the error exits — is validated
// against the actual executable. The Python wrapper parses `version --json`
// and keys compatibility on the protocol tag, so the contract is one line,
// free of log chatter, and honest about non-release builds.

import (
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

// buildCLIVersion builds the actual binary with release metadata injected
// exactly as documented next to the ldflags vars in main.go.
func buildCLIVersion(t *testing.T, injectedVersion, injectedCommit string) string {
	t.Helper()
	bin := filepath.Join(t.TempDir(), "pocketshell-link")
	goTool := filepath.Join(runtime.GOROOT(), "bin", "go")
	cmd := exec.Command(goTool, "build",
		"-ldflags", "-X main.version="+injectedVersion+" -X main.commit="+injectedCommit,
		"-o", bin, ".")
	cmd.Env = append(os.Environ(), "GOCACHE="+filepath.Join(t.TempDir(), "gocache"))
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build with injected metadata: %v\n%s", err, out)
	}
	return bin
}

// requireOneLine asserts the stdout of a successful version run: exactly
// one newline-terminated line, nothing on stderr (no log chatter — the
// output is parsed by scripts and CI).
func requireOneLine(t *testing.T, out, errOut string) string {
	t.Helper()
	if errOut != "" {
		t.Fatalf("log chatter on the version contract path:\n%s", errOut)
	}
	if !strings.HasSuffix(out, "\n") || strings.Count(out, "\n") != 1 {
		t.Fatalf("version contract is exactly ONE line, got %q", out)
	}
	return strings.TrimSuffix(out, "\n")
}

// TestCLIVersionJSONInjectedMetadata: `version --json` on a release-style
// build echoes the INJECTED version and commit, carries the protocol tag,
// and stays one JSON object with the three required typed fields present —
// compatible additional metadata is additive and needs no bump (the
// protocol tag bumps only on incompatible change).
func TestCLIVersionJSONInjectedMetadata(t *testing.T) {
	bin := buildCLIVersion(t, "v1.2.3-rc1", "0123456789abcdef")
	out, errOut, code := runCLI(t, bin, "", "version", "--json")
	if code != 0 {
		t.Fatalf("version --json exited %d\nstdout: %s\nstderr: %s", code, out, errOut)
	}
	line := requireOneLine(t, out, errOut)

	var parsed struct {
		Version  string `json:"version"`
		Protocol string `json:"protocol"`
		Commit   string `json:"commit"`
	}
	if err := json.Unmarshal([]byte(line), &parsed); err != nil {
		t.Fatalf("contract line is not valid JSON: %v (%q)", err, line)
	}
	if parsed.Version != "v1.2.3-rc1" {
		t.Fatalf("version %q, want the injected release version", parsed.Version)
	}
	if parsed.Protocol != "pocketshell-tunnel-v1" {
		t.Fatalf("protocol tag %q, want the documented compatibility tag", parsed.Protocol)
	}
	if parsed.Commit != "0123456789abcdef" {
		t.Fatalf("commit %q, want the injected commit", parsed.Commit)
	}
	// The whole line must be exactly ONE JSON object, and the three
	// required fields above must keep their documented names, types and
	// meaning (main.go: the frozen additive contract). Compatible
	// ADDITIONAL metadata is allowed WITHOUT a protocol bump — the bump
	// is reserved for compatibility-affecting changes, which is exactly
	// what the protocol tag exists to signal to consumers. (Decoding into
	// the struct above already pins the required fields' types; a missing
	// or retyped field fails the injected-value checks.)
	var generic map[string]any
	if err := json.Unmarshal([]byte(line), &generic); err != nil {
		t.Fatalf("contract line is not exactly one JSON object: %v (%q)", err, line)
	}
	for _, key := range []string{"version", "protocol", "commit"} {
		if _, ok := generic[key]; !ok {
			t.Fatalf("required contract field %q missing: %v", key, generic)
		}
	}
}

// TestCLIVersionHumanLineInjected: the human line keeps its historical
// shape (compatibility) and shows the real injected version — never a
// hardcoded dev placeholder posing as a release.
func TestCLIVersionHumanLineInjected(t *testing.T) {
	bin := buildCLIVersion(t, "v9.8.7", "cafebabe")
	out, errOut, code := runCLI(t, bin, "", "version")
	if code != 0 {
		t.Fatalf("version exited %d\nstdout: %s\nstderr: %s", code, out, errOut)
	}
	line := requireOneLine(t, out, errOut)
	if line != "pocketshell-link v9.8.7 (protocol pocketshell-tunnel-v1)" {
		t.Fatalf("human line changed shape: %q", line)
	}
	if strings.Contains(line, "dev (") {
		t.Fatalf("human line still presents the hardcoded dev placeholder: %q", line)
	}
}

// TestCLIVersionErrorExits: malformed invocations fail with a non-zero
// exit, empty stdout, and a diagnostic on stderr.
func TestCLIVersionErrorExits(t *testing.T) {
	bin := buildCLIVersion(t, "v1.0.0", "feedface")
	t.Run("unknown flag", func(t *testing.T) {
		out, errOut, code := runCLI(t, bin, "", "version", "--yaml")
		if code == 0 {
			t.Fatal("unknown flag accepted")
		}
		if out != "" {
			t.Fatalf("stdout must stay empty on an error exit: %q", out)
		}
		if !strings.Contains(errOut, "yaml") {
			t.Fatalf("no diagnostic naming the bad flag:\n%s", errOut)
		}
	})
	t.Run("stray argument", func(t *testing.T) {
		out, _, code := runCLI(t, bin, "", "version", "extra")
		if code == 0 {
			t.Fatal("stray argument accepted")
		}
		if out != "" {
			t.Fatalf("stdout must stay empty on an error exit: %q", out)
		}
	})
}

// TestCLIVersionUninjectedIsVisiblyDevel: a build WITHOUT injected metadata
// must never present itself as a release. The version is visibly "devel"
// (the old binary printed the hardcoded "dev", which pins nothing), and the
// commit is the Go VCS revision when stamped, or the honest "unknown".
func TestCLIVersionUninjectedIsVisiblyDevel(t *testing.T) {
	bin := buildCLI(t) // the plain build from the e2e suite: no ldflags
	out, errOut, code := runCLI(t, bin, "", "version", "--json")
	if code != 0 {
		t.Fatalf("version --json exited %d\nstdout: %s\nstderr: %s", code, out, errOut)
	}
	line := requireOneLine(t, out, errOut)
	var parsed struct {
		Version  string `json:"version"`
		Protocol string `json:"protocol"`
		Commit   string `json:"commit"`
	}
	if err := json.Unmarshal([]byte(line), &parsed); err != nil {
		t.Fatalf("contract line is not valid JSON: %v (%q)", err, line)
	}
	if parsed.Version != "devel" {
		t.Fatalf("uninjected build version %q, want the visible non-release spelling %q", parsed.Version, "devel")
	}
	if parsed.Commit == "" {
		t.Fatal("commit must be spelled out (VCS revision or unknown)")
	}
	if parsed.Protocol != "pocketshell-tunnel-v1" {
		t.Fatalf("protocol tag %q, want the documented compatibility tag", parsed.Protocol)
	}

	human, humanErr, hcode := runCLI(t, bin, "", "version")
	if hcode != 0 {
		t.Fatalf("version exited %d: %s", hcode, humanErr)
	}
	if !strings.Contains(human, "devel") {
		t.Fatalf("human line hides the non-release state: %q", human)
	}
}
