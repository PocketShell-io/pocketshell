package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel/wsnet"
)

// These tests run the REAL pocketshell-link binary end to end: enrollment
// against a real identity.Service over HTTP, the real agent control loop
// against a real tunnel.Service, and real SSH through the tunnel. They are
// the in-process form of the Opus Docker findings F-08/F-09/F-11/F-13.

// buildCLI compiles the actual binary once for the test binary's lifetime.
func buildCLI(t *testing.T) string {
	t.Helper()
	bin := filepath.Join(t.TempDir(), "pocketshell-link")
	goTool := filepath.Join(runtime.GOROOT(), "bin", "go")
	cmd := exec.Command(goTool, "build", "-o", bin, ".")
	cmd.Env = append(os.Environ(), "GOCACHE="+filepath.Join(t.TempDir(), "gocache"))
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build pocketshell-link: %v\n%s", err, out)
	}
	return bin
}

// runCLI invokes the binary with stdin and returns stdout/stderr.
func runCLI(t *testing.T, bin string, stdin string, args ...string) (string, string, int) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, bin, args...)
	cmd.Stdin = strings.NewReader(stdin)
	var outBuf, errBuf strings.Builder
	cmd.Stdout = &outBuf
	cmd.Stderr = &errBuf
	err := cmd.Run()
	code := 0
	var ee *exec.ExitError
	if errors.As(err, &ee) {
		code = ee.ExitCode()
	} else if err != nil {
		t.Fatalf("run %v: %v\nstdout: %s\nstderr: %s", args, err, outBuf.String(), errBuf.String())
	}
	return outBuf.String(), errBuf.String(), code
}

// testWorld wires identity + tunnel exactly like production (documented
// adapters, OnRevoke) over httptest, plus a real in-process sshd.
type cliWorld struct {
	bin      string
	sshdAddr string
	sshdKey  ssh.Signer // the user key the sshd accepts
	sshdHost ssh.PublicKey
	idSvc    *identity.Service
	gwSvc    *tunnel.Service
	idURL    string // http base for enrollment
	wsURL    string // ws base for the agent
	token    string // broker-shaped credential the fake verifier accepts
	deviceID string
	dir      string // config dir for the CLI
	requests atomic.Int64
	recorder *httptest.Server
	pinLine  string
}

func newCLIWorld(t *testing.T) *cliWorld {
	t.Helper()
	w := &cliWorld{
		bin:      buildCLI(t),
		deviceID: "dev-cli-e2e",
		dir:      t.TempDir(),
		token:    cliBrokerToken(t, time.Now()),
	}

	// In-process sshd (real SSH protocol).
	_, userPriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	w.sshdKey, err = ssh.NewSignerFromKey(userPriv)
	if err != nil {
		t.Fatal(err)
	}
	hostSigner, err := ssh.NewSignerFromKey(cliKey(t))
	if err != nil {
		t.Fatal(err)
	}
	w.sshdHost = hostSigner.PublicKey()
	w.pinLine = strings.TrimSpace(string(ssh.MarshalAuthorizedKey(w.sshdHost)))
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	w.sshdAddr = ln.Addr().String()
	cfg := &ssh.ServerConfig{
		PublicKeyCallback: func(_ ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			if string(key.Marshal()) == string(w.sshdKey.PublicKey().Marshal()) {
				return &ssh.Permissions{}, nil
			}
			return nil, fmt.Errorf("unknown key")
		},
	}
	cfg.AddHostKey(hostSigner)
	sshdDone := make(chan struct{})
	go func() {
		defer close(sshdDone)
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			go func(c net.Conn) {
				defer c.Close()
				sconn, chans, reqs, err := ssh.NewServerConn(c, cfg)
				if err != nil {
					return
				}
				defer sconn.Close()
				go ssh.DiscardRequests(reqs)
				for nc := range chans {
					if nc.ChannelType() != "session" {
						nc.Reject(ssh.UnknownChannelType, "no")
						continue
					}
					ch, reqs2, err := nc.Accept()
					if err != nil {
						continue
					}
					go serveExec(ch, reqs2)
				}
			}(c)
		}
	}()
	t.Cleanup(func() { ln.Close(); <-sshdDone })

	// Identity service (real HTTP API, fake verifier).
	mem := identity.NewMemoryStore()
	idSvc, err := identity.NewService(identity.Config{
		Verifier: cliVerifier{token: w.token, account: "google:cli-e2e-account"},
		Store:    mem,
		Domain:   "127.0.0.1",
		Clock:    time.Now,
	})
	if err != nil {
		t.Fatal(err)
	}
	w.idSvc = idSvc
	idTS := httptest.NewServer(idSvc)
	t.Cleanup(idTS.Close)
	w.idURL = idTS.URL

	// Tunnel gateway over the documented adapters.
	gwSvc, err := tunnel.NewService(tunnel.ServiceOptions{
		Store: tunnel.DeviceStoreFunc(func(id string) (tunnel.Device, error) {
			d, err := idSvc.Store().GetDevice(id)
			if err != nil {
				return tunnel.Device{}, err
			}
			return tunnel.Device{
				ID: d.ID, AccountID: d.AccountID, PublicKey: d.PublicKey,
				SSHHostKey: d.SSHHostKey, Revoked: d.Revoked,
			}, nil
		}),
		Authenticate: func(ctx context.Context, token string) (tunnel.Principal, error) {
			p, err := idSvc.TokenAuthenticator()(ctx, token)
			if err != nil {
				return tunnel.Principal{}, err
			}
			return tunnel.Principal{AccountID: p.AccountID, Email: p.Email, ExpiresAt: p.ExpiresAt}, nil
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	w.gwSvc = gwSvc
	gwTS := httptest.NewServer(gwSvc)
	t.Cleanup(func() { gwTS.Close(); gwSvc.Close() })
	w.wsURL = "ws" + strings.TrimPrefix(gwTS.URL, "http")
	// The production revocation contract: the identity service persists the
	// revocation first, then tears the tunnel session down (OnRevoke).
	idSvc.OnRevoke(func(d identity.Device) { gwSvc.RevokeDevice(d.ID) })

	// A recorder for the F-09 zero-request property.
	w.recorder = httptest.NewServer(http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		w.requests.Add(1)
		http.Error(rw, "nothing may be sent here", http.StatusInternalServerError)
	}))
	t.Cleanup(w.recorder.Close)
	return w
}

type cliKeyT struct{}

func cliKey(t *testing.T) ed25519.PrivateKey {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	return priv
}

type cliVerifier struct {
	token   string
	account string
}

func (v cliVerifier) VerifyToken(_ context.Context, token string) (identity.Principal, error) {
	if token == v.token {
		return identity.Principal{
			AccountID: v.account, Email: "cli@example.com",
			ExpiresAt: time.Now().Add(5 * time.Minute),
		}, nil
	}
	return identity.Principal{}, errors.New("unknown token")
}

func serveExec(ch ssh.Channel, reqs <-chan *ssh.Request) {
	defer ch.Close()
	for req := range reqs {
		if req.Type != "exec" {
			if req.WantReply {
				req.Reply(false, nil)
			}
			continue
		}
		if len(req.Payload) < 4 {
			req.Reply(false, nil)
			continue
		}
		n := int(req.Payload[0])<<24 | int(req.Payload[1])<<16 | int(req.Payload[2])<<8 | int(req.Payload[3])
		if n > len(req.Payload)-4 {
			req.Reply(false, nil)
			continue
		}
		cmd := string(req.Payload[4 : 4+n])
		req.Reply(true, nil)
		out, err := exec.Command("/bin/sh", "-c", cmd).CombinedOutput()
		_, _ = ch.Write(out)
		status := uint32(0)
		if err != nil {
			status = 1
		}
		_, _ = ch.SendRequest("exit-status", false, ssh.Marshal(struct{ Status uint32 }{status}))
		ch.CloseWrite()
		return
	}
}

func cliBrokerToken(t *testing.T, now time.Time) string {
	t.Helper()
	mk := func(m map[string]any) string {
		h, _ := json.Marshal(map[string]any{"alg": "RS256", "kid": "k"})
		c, _ := json.Marshal(m)
		enc := base64.RawURLEncoding.EncodeToString
		return enc(h) + "." + enc(c) + "." + enc([]byte("sig"))
	}
	return mk(map[string]any{
		"iss":   "https://a7sota2qic.execute-api.eu-west-1.amazonaws.com",
		"aud":   "pocketshell-gateway",
		"scope": "pocketshell.gateway",
		"exp":   now.Add(4 * time.Minute).Unix(),
		"iat":   now.Unix(),
	})
}

func googleToken(t *testing.T, now time.Time) string {
	t.Helper()
	mk := func(m map[string]any) string {
		h, _ := json.Marshal(map[string]any{"alg": "RS256", "kid": "g"})
		c, _ := json.Marshal(m)
		enc := base64.RawURLEncoding.EncodeToString
		return enc(h) + "." + enc(c) + "." + enc([]byte("sig"))
	}
	return mk(map[string]any{
		"iss": "https://accounts.google.com",
		"aud": "pocketshell-sync.apps.googleusercontent.com",
		"exp": now.Add(time.Hour).Unix(),
		"iat": now.Unix(),
	})
}

// TestCLIEnrollRunSSH is the full production path with the real binary:
//   - F-08/F-09: `enroll` accepts a broker token, enrolls against the real
//     identity API, probes and pins the real sshd host key;
//   - F-11: `run` starts with default options (no injected clock);
//   - F-13: the agent session carries SSH traffic across the 10s default
//     handshake deadline that used to kill every connection;
//   - end-to-end SSH: the pinned host key and authorized key decide access.
func TestCLIEnrollRunSSH(t *testing.T) {
	if testing.Short() {
		t.Skip("runs ~15s with real process lifecycle")
	}
	w := newCLIWorld(t)

	// 1. Enroll with the real CLI.
	out, errOut, code := runCLI(t, w.bin, w.token,
		"enroll", "--token-stdin",
		"--server", w.idURL,
		"--insecure-dev",
		"--config-dir", w.dir,
		"--ssh-host", w.sshdAddr,
		"--device-id", w.deviceID,
	)
	if code != 0 {
		t.Fatalf("enroll failed (code %d)\nstdout: %s\nstderr: %s", code, out, errOut)
	}
	if !strings.Contains(out, "local sshd host key: "+w.sshdHost.Type()) {
		t.Fatalf("enroll did not print the pinned sshd key:\n%s", out)
	}
	if !strings.Contains(out, "SHA256:") {
		t.Fatalf("enroll output does not show the useful key fingerprint:\n%s", out)
	}
	dev, err := w.idSvc.Store().GetDevice(w.deviceID)
	if err != nil {
		t.Fatalf("device not registered: %v", err)
	}
	if dev.SSHHostKey != w.pinLine {
		t.Fatalf("pinned key mismatch:\n got %s\nwant %s", dev.SSHHostKey, w.pinLine)
	}

	// 2. Run the real agent (default options besides server/dir/dev).
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	cmd := exec.CommandContext(ctx, w.bin, "run",
		"--server", w.wsURL,
		"--insecure-dev",
		"--config-dir", w.dir,
	)
	var logBuf strings.Builder
	cmd.Stdout = &logBuf
	cmd.Stderr = &logBuf
	runDone := make(chan error, 1)
	go func() { runDone <- cmd.Run() }()
	var stopOnce sync.Once
	stopRun := func() {
		stopOnce.Do(func() {
			cancel()
			select {
			case <-runDone:
			case <-time.After(5 * time.Second):
				t.Logf("run did not exit after cancel")
			}
		})
	}
	t.Cleanup(stopRun)

	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) && !w.gwSvc.IsDeviceConnected(w.deviceID) {
		time.Sleep(20 * time.Millisecond)
	}
	if !w.gwSvc.IsDeviceConnected(w.deviceID) {
		t.Fatalf("agent never connected:\n%s", logBuf.String())
	}

	// 3. Real SSH over the tunnel, now and across the 10s default
	// handshake deadline (the old F-13 bug killed the session at exactly
	// 10.000s after connect).
	pinned, _, _, _, err := ssh.ParseAuthorizedKey([]byte(w.pinLine))
	if err != nil {
		t.Fatal(err)
	}
	sshOverTunnel := func(round int) error {
		dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
		ws, _, err := dialer.Dial(w.wsURL+"/api/v1/hosts/"+w.deviceID+"/ssh", nil)
		if err != nil {
			return fmt.Errorf("round %d: dial: %w", round, err)
		}
		defer ws.Close()
		auth, _ := json.Marshal(tunnel.ClientAuth{
			Type: "auth", V: tunnel.ProtocolVersion,
			Token: w.token, DeviceID: w.deviceID,
		})
		_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
		if err := ws.WriteMessage(websocket.TextMessage, auth); err != nil {
			return err
		}
		_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
		_, raw, err := ws.ReadMessage()
		if err != nil {
			return err
		}
		var ready tunnel.ReadyMsg
		if err := json.Unmarshal(raw, &ready); err != nil || ready.Type != "ready" {
			return fmt.Errorf("round %d: not ready: %s", round, raw)
		}
		_ = ws.SetReadDeadline(time.Time{})
		cfg := &ssh.ClientConfig{
			User: "cli",
			Auth: []ssh.AuthMethod{ssh.PublicKeys(w.sshdKey)},
			HostKeyCallback: func(_ string, _ net.Addr, key ssh.PublicKey) error {
				if string(key.Marshal()) != string(pinned.Marshal()) {
					return errors.New("host key mismatch")
				}
				return nil
			},
			Timeout: 5 * time.Second,
		}
		conn, chans, reqs, err := ssh.NewClientConn(wsnet.Wrap(ws), "pocketshell-tunnel", cfg)
		if err != nil {
			return err
		}
		cl := ssh.NewClient(conn, chans, reqs)
		defer cl.Close()
		sess, err := cl.NewSession()
		if err != nil {
			return err
		}
		defer sess.Close()
		out, err := sess.CombinedOutput("echo cli-round-" + fmt.Sprint(round))
		if err != nil {
			return err
		}
		if got := strings.TrimSpace(string(out)); got != "cli-round-"+fmt.Sprint(round) {
			return fmt.Errorf("round %d output %q", round, got)
		}
		return nil
	}
	if err := sshOverTunnel(1); err != nil {
		t.Fatalf("first SSH round trip: %v\nagent log:\n%s", err, logBuf.String())
	}
	// Cross the 10s default handshake deadline: with the old code the
	// control connection died here and this round trip hit host_offline.
	time.Sleep(11 * time.Second)
	if !w.gwSvc.IsDeviceConnected(w.deviceID) {
		t.Fatalf("agent session died at the handshake deadline (F-13):\n%s", logBuf.String())
	}
	if err := sshOverTunnel(2); err != nil {
		t.Fatalf("SSH round trip after one handshake deadline: %v\nagent log:\n%s", err, logBuf.String())
	}
	stopRun()
}

// postJSON sends a JSON body with a bearer token and returns the status.
func postJSON(t *testing.T, url, token string, body []byte) int {
	t.Helper()
	var rd io.Reader
	if body != nil {
		rd = bytes.NewReader(body)
	}
	req, err := http.NewRequest(http.MethodPost, url, rd)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	return resp.StatusCode
}

// TestCLIRunExitsFatallyOnRevocation (FH-1 at the binary level): after a
// real API revocation, the running `pocketshell-link run` process must EXIT
// with a non-zero code and a clear local message — the old binary retried
// forever and never reported anything.
func TestCLIRunExitsFatallyOnRevocation(t *testing.T) {
	if testing.Short() {
		t.Skip("runs ~10s with real process lifecycle")
	}
	w := newCLIWorld(t)

	out, errOut, code := runCLI(t, w.bin, w.token,
		"enroll", "--token-stdin",
		"--server", w.idURL,
		"--insecure-dev",
		"--config-dir", w.dir,
		"--ssh-host", w.sshdAddr,
		"--device-id", w.deviceID,
	)
	if code != 0 {
		t.Fatalf("enroll failed (code %d)\nstdout: %s\nstderr: %s", code, out, errOut)
	}

	// Run the real binary; the process context has NO cancellation — only
	// the agent's own exit or the bounded test wait can end it.
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, w.bin, "run",
		"--server", w.wsURL,
		"--insecure-dev",
		"--config-dir", w.dir,
	)
	var logBuf strings.Builder
	cmd.Stdout = &logBuf
	cmd.Stderr = &logBuf
	runDone := make(chan error, 1)
	start := time.Now()
	go func() { runDone <- cmd.Run() }()

	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) && !w.gwSvc.IsDeviceConnected(w.deviceID) {
		time.Sleep(20 * time.Millisecond)
	}
	if !w.gwSvc.IsDeviceConnected(w.deviceID) {
		t.Fatalf("agent never connected:\n%s", logBuf.String())
	}

	// Revoke through the REAL identity HTTP API (owner token, durable,
	// persist-before-notify via OnRevoke).
	if status := postJSON(t, w.idURL+"/identity/v1/devices/"+w.deviceID+"/revoke", w.token, nil); status != 200 {
		t.Fatalf("revoke HTTP status %d", status)
	}

	// The binary must exit on its own, promptly, with the fatal message.
	select {
	case err := <-runDone:
		elapsed := time.Since(start)
		var ee *exec.ExitError
		if !errors.As(err, &ee) || ee.ExitCode() == 0 {
			t.Fatalf("run exited with %v (want non-zero exit)", err)
		}
		if elapsed > 30*time.Second {
			t.Fatalf("binary took %v to exit", elapsed)
		}
		if !strings.Contains(logBuf.String(), "gateway rejected this device") {
			t.Fatalf("exit output lacks the fatal rejection message:\n%s", logBuf.String())
		}
		t.Logf("binary exited after %v with the revocation surfaced", elapsed)
	case <-time.After(45 * time.Second):
		cancel()
		t.Fatalf("binary never exited after revocation (FH-1 unbounded retry):\n%s", logBuf.String())
	}
}

// TestCLIGoogleTokenNeverTransmitted (F-09 at the binary level): piping a
// Google ID token into the real CLI must fail with a local refusal and
// leave the recorder at zero requests.
func TestCLIGoogleTokenNeverTransmitted(t *testing.T) {
	w := newCLIWorld(t)
	out, errOut, code := runCLI(t, w.bin, googleToken(t, time.Now()),
		"enroll", "--token-stdin",
		"--server", w.recorder.URL,
		"--insecure-dev",
		"--config-dir", t.TempDir(),
		"--ssh-host", "127.0.0.1:22",
		"--device-id", "dev-should-never-enroll",
	)
	if code == 0 {
		t.Fatalf("CLI accepted a Google token\nstdout: %s\nstderr: %s", out, errOut)
	}
	if !strings.Contains(strings.ToUpper(errOut+out), "GOOGLE") {
		t.Fatalf("refusal does not name the Google token:\nstdout: %s\nstderr: %s", out, errOut)
	}
	if n := w.requests.Load(); n != 0 {
		t.Fatalf("%d HTTP requests left the machine with a Google token on stdin", n)
	}
}

// TestCLIEnrollRejectsNonJWT: garbage on stdin is refused locally too.
func TestCLIEnrollRejectsNonJWT(t *testing.T) {
	w := newCLIWorld(t)
	_, errOut, code := runCLI(t, w.bin, "pasted-password-or-random-string",
		"enroll", "--token-stdin",
		"--server", w.recorder.URL,
		"--insecure-dev",
		"--config-dir", t.TempDir(),
		"--ssh-host", "127.0.0.1:22",
	)
	if code == 0 {
		t.Fatal("CLI accepted a non-JWT credential")
	}
	if n := w.requests.Load(); n != 0 {
		t.Fatalf("%d HTTP requests left the machine", n)
	}
	if !strings.Contains(errOut, "refusing to send") {
		t.Fatalf("refusal text missing:\n%s", errOut)
	}
}

// cliHostileReason is the message a hostile configured gateway encodes into
// a fatal ErrMsg frame: ANSI color, a forged output line, an OSC title
// escape, cursor movement, a tab, DEL, the C1 NEL, and bidi marks.
const cliHostileReason = "\x1b[31mFORGED exit\x1b[0m\npocketshell-link exited: pwned\r\n" +
	"\x1b]0;evil\x07\x1b[3;H\ta\x7f\u0085\u202erev\u2066erse\u202c"

// cliHostileCloseText is the close-frame variant (raw payload; gorilla only
// requires valid UTF-8, so the reachable route carries UTF-8 controls).
const cliHostileCloseText = "\x1b[2J\x1b[H CLEAR\n\x1b]0;evil\x07tab\there\x7f\u0085\u202ebidi\u202c"

// hostilePeerGateway is a WS endpoint that rejects every agent connection
// with the configured peer-controlled payload, standing in for a
// compromised configured gateway.
type hostilePeerGateway struct {
	srv *httptest.Server
	url string
}

func startHostilePeerGateway(t *testing.T, errJSON []byte, closeCode int, closeText string) *hostilePeerGateway {
	t.Helper()
	hg := &hostilePeerGateway{}
	up := websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}
	hg.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ws, err := up.Upgrade(w, r, nil)
		if err != nil {
			return
		}
		defer ws.Close()
		_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
		if errJSON != nil {
			_ = ws.WriteMessage(websocket.TextMessage, errJSON)
		}
		if closeCode != 0 {
			_ = ws.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(closeCode, closeText))
		}
		time.Sleep(2 * time.Second) // hold the socket while the agent reads
	}))
	t.Cleanup(hg.srv.Close)
	hg.url = "ws" + strings.TrimPrefix(hg.srv.URL, "http")
	return hg
}

// assertCLIStderrTerminalSafe fails if any peer-controlled terminal control
// character reached the captured CLI stderr. Newlines are allowed only as
// the local formatter's own line endings.
func assertCLIStderrTerminalSafe(t *testing.T, s string) {
	t.Helper()
	for i, r := range s {
		switch {
		case r == '\n':
			// the formatter's own line endings
		case r < 0x20, r == 0x7f, r >= 0x80 && r <= 0x9f,
			r == 0x061c, r == 0x200e, r == 0x200f,
			r >= 0x202a && r <= 0x202e, r >= 0x2066 && r <= 0x2069:
			t.Fatalf("byte %d: raw terminal control U+%04X reached CLI stderr: %q", i, r, s)
		}
	}
}

// TestCLIRunHostileGatewayRejectionWithholdsPeerText (run-path
// credential-withholding contract at the binary level, replacing the older
// escaped-rendering contract): a hostile configured gateway rejects the
// agent handshake with peer-controlled payloads — once a fatal JSON ErrMsg
// message carrying terminal controls, once a fatal raw close reason. The
// real binary must still exit non-zero with the same fixed verdict, and the
// captured stderr must contain NO peer bytes at all — not raw, not in the
// old sanitizer's escaped form — with the only newlines being the local
// formatter's own.
func TestCLIRunHostileGatewayRejectionWithholdsPeerText(t *testing.T) {
	if testing.Short() {
		t.Skip("runs the real binary against a hostile gateway")
	}
	w := newCLIWorld(t)
	out, errOut, code := runCLI(t, w.bin, w.token,
		"enroll", "--token-stdin",
		"--server", w.idURL,
		"--insecure-dev",
		"--config-dir", w.dir,
		"--ssh-host", w.sshdAddr,
		"--device-id", w.deviceID,
	)
	if code != 0 {
		t.Fatalf("enroll failed (code %d)\nstdout: %s\nstderr: %s", code, out, errOut)
	}

	cases := []struct {
		name      string
		errJSON   []byte
		closeCode int
		closeText string
		wantClose string
		forbidden []string // peer payload fragments that must not survive in any form
	}{
		{
			name: "json error frame",
			errJSON: mustJSONErrMsgForCLI(t, tunnel.ErrMsg{
				Type: "error", V: tunnel.ProtocolVersion,
				Code: "revoked", Message: cliHostileReason,
			}),
			closeCode: tunnel.CloseForbidden,
			wantClose: "(close 4403)",
			forbidden: []string{"FORGED", "pwned", "evil", `\x1b`, `\u202e`},
		},
		{
			name:      "raw close reason",
			closeCode: tunnel.CloseUnauth,
			closeText: cliHostileCloseText,
			wantClose: "(close 4401)",
			forbidden: []string{"CLEAR", "evil", "bidi", `\x1b`, `\u202e`},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			hg := startHostilePeerGateway(t, tc.errJSON, tc.closeCode, tc.closeText)
			ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
			defer cancel()
			var stdout, stderr bytes.Buffer
			cmd := exec.CommandContext(ctx, w.bin, "run",
				"--server", hg.url,
				"--insecure-dev",
				"--config-dir", w.dir,
			)
			cmd.Stdout = &stdout
			cmd.Stderr = &stderr
			err := cmd.Run()
			var ee *exec.ExitError
			if !errors.As(err, &ee) || ee.ExitCode() == 0 {
				t.Fatalf("run exit: %v (want non-zero)\nstdout: %s\nstderr: %s", err, stdout.String(), stderr.String())
			}
			errText := stderr.String()
			assertCLIStderrTerminalSafe(t, errText)
			if !strings.Contains(errText, "gateway rejected this device "+tc.wantClose) {
				t.Fatalf("stderr lacks the fixed verdict %s:\n%s", tc.wantClose, errText)
			}
			if !strings.Contains(errText, "withheld") {
				t.Fatalf("stderr lacks the fixed withholding phrase:\n%s", errText)
			}
			for _, frag := range tc.forbidden {
				if strings.Contains(errText, frag) {
					t.Fatalf("peer payload fragment %q survived in stderr:\n%s", frag, errText)
				}
			}
			if n := strings.Count(errText, "\n"); n != 3 { // startup + agent-error slog lines + the CLI's own exit line
				t.Fatalf("stderr carries %d newlines (forged lines?):\n%s", n, errText)
			}
		})
	}
}

// mustJSONErrMsgForCLI encodes an ErrMsg frame for the hostile gateway.
func mustJSONErrMsgForCLI(t *testing.T, msg tunnel.ErrMsg) []byte {
	t.Helper()
	b, err := json.Marshal(msg)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// mustJSONFrameForCLI encodes any handshake frame (e.g. a crafted OKMsg
// with a hostile reply type) for the hostile gateway.
func mustJSONFrameForCLI(t *testing.T, v any) []byte {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// startProbeOnlySSHDCLI starts a minimal loopback sshd whose Ed25519 host
// key the enrollment probe pins (the probe stops at its verified-host-key
// callback, before userauth). Needed so the REAL `enroll` subprocess gets
// past the local probe and reaches its HTTP step.
func startProbeOnlySSHDCLI(t *testing.T) (addr string) {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	signer, err := ssh.NewSignerFromKey(priv)
	if err != nil {
		t.Fatal(err)
	}
	cfg := &ssh.ServerConfig{
		PublicKeyCallback: func(ssh.ConnMetadata, ssh.PublicKey) (*ssh.Permissions, error) {
			return &ssh.Permissions{}, nil // never reached by the probe
		},
	}
	cfg.AddHostKey(signer)
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { ln.Close() })
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			go func() {
				defer c.Close()
				_, _, _, _ = ssh.NewServerConn(c, cfg) // probe disconnects at its stop
			}()
		}
	}()
	return ln.Addr().String()
}

// TestCLIEnrollFailureStderrWithholdsCredential is the ACTUAL stderr
// verification for the enrollment failure output policy: the real
// pocketshell-link binary, run as a subprocess, sends a real development
// broker bearer over HTTP; the local gateway fixture reflects that exact
// transmitted credential back in a 401 body (whole, cut past the old
// 256-byte bound, and re-encoded), and the assertion is on the process's
// real stderr bytes — the fixed safe status message and nothing else.
func TestCLIEnrollFailureStderrWithholdsCredential(t *testing.T) {
	bin := buildCLI(t)
	addr := startProbeOnlySSHDCLI(t)

	token := func() string {
		h, _ := json.Marshal(map[string]any{"alg": "RS256", "kid": "k"})
		c, _ := json.Marshal(map[string]any{
			"iss":   "https://a7sota2qic.execute-api.eu-west-1.amazonaws.com",
			"aud":   "pocketshell-gateway",
			"scope": "pocketshell.gateway",
			"exp":   time.Now().Add(4 * time.Minute).Unix(),
			"iat":   time.Now().Unix(),
			"jti":   strings.Repeat("cli-prefix-canary-", 40),
		})
		enc := base64.RawURLEncoding.EncodeToString
		return enc(h) + "." + enc(c) + "." + enc([]byte("sig"))
	}()
	var mu sync.Mutex
	var gotAuth string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		gotAuth = r.Header.Get("Authorization")
		auth := strings.TrimPrefix(gotAuth, "Bearer ")
		mu.Unlock()
		body := fmt.Sprintf("bad credential %q\n\x1b[2Jforged\nline\nwhole=%s prefix=%s tail=%s urlq=%q b64=%s b64url=%s",
			auth, auth, auth[:256], auth[len(auth)-64:],
			url.QueryEscape(auth),
			base64.StdEncoding.EncodeToString([]byte(auth)),
			base64.URLEncoding.EncodeToString([]byte(auth)))
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.WriteHeader(http.StatusUnauthorized)
		_, _ = w.Write([]byte(body))
	}))
	t.Cleanup(srv.Close)
	if len(token) <= 256 {
		t.Fatalf("fixture setup: credential is only %d bytes; want the reflected-prefix shape past 256", len(token))
	}

	stdout, stderr, code := runCLI(t, bin, token,
		"enroll", "--token-stdin",
		"--server", srv.URL,
		"--ssh-host", addr,
		"--insecure-dev",
		"--device-id", "dev-cli-withhold",
	)
	if code != 1 {
		t.Fatalf("enroll exit code %d, want 1\nstdout: %s\nstderr: %s", code, stdout, stderr)
	}

	// The fixture is meaningful: the binary really transmitted the bearer
	// and the server really reflected that same credential.
	mu.Lock()
	auth := gotAuth
	mu.Unlock()
	if auth != "Bearer "+token {
		t.Fatalf("server saw Authorization %q, want the transmitted bearer", auth)
	}

	// Actual stderr bytes: exactly the fixed safe line and nothing else.
	wantLine := "enroll failed: challenge: HTTP 401 Unauthorized: gateway rejected the request (peer failure body withheld)\n"
	if stderr != wantLine {
		t.Fatalf("actual stderr %q, want exactly %q", stderr, wantLine)
	}
	assertCLIStderrTerminalSafe(t, stderr)

	// No declared credential — whole, any usable prefix/suffix, or any
	// reversible re-encoding — in either stream.
	for name, out := range map[string]string{"stdout": stdout, "stderr": stderr} {
		if strings.Contains(out, token) {
			t.Fatalf("%s: full fixture credential leaked", name)
		}
		for n := 12; n <= len(token); n++ {
			if strings.Contains(out, token[:n]) {
				t.Fatalf("%s: credential prefix of length %d leaked: %q", name, n, token[:n])
			}
			if strings.Contains(out, token[len(token)-n:]) {
				t.Fatalf("%s: credential suffix of length %d leaked: %q", name, n, token[len(token)-n:])
			}
		}
		for _, enc := range []string{
			url.QueryEscape(token),
			base64.StdEncoding.EncodeToString([]byte(token)),
			base64.URLEncoding.EncodeToString([]byte(token)),
		} {
			if strings.Contains(out, enc) {
				t.Fatalf("%s: re-encoded credential variant leaked: %q", name, enc)
			}
		}
	}
}

// brokerShapedCanary mints the synthetic enrollment bearer this test's
// fixture transmits: the exact production broker-token shape the local
// guard accepts. A non-empty jti sets the reflected-prefix shape (long,
// past the historical 256-byte rendering bound); an empty jti omits the
// claim, keeping the token under 256 bytes for the prints-whole shape.
func brokerShapedCanary(t *testing.T, jti string) string {
	t.Helper()
	mk := func(m map[string]any) string {
		h, _ := json.Marshal(map[string]any{"alg": "RS256", "kid": "k"})
		c, _ := json.Marshal(m)
		enc := base64.RawURLEncoding.EncodeToString
		return enc(h) + "." + enc(c) + "." + enc([]byte("sig"))
	}
	claims := map[string]any{
		"iss":   "https://a7sota2qic.execute-api.eu-west-1.amazonaws.com",
		"aud":   "pocketshell-gateway",
		"scope": "pocketshell.gateway",
		"exp":   time.Now().Add(4 * time.Minute).Unix(),
		"iat":   time.Now().Unix(),
	}
	if jti != "" {
		claims["jti"] = jti
	}
	return mk(claims)
}

// multiTokenVerifier accepts the synthetic bearers minted above, so real
// enrollments succeed and the fixture can prove that the bytes the hostile
// run gateway reflects back are the exact Authorization credential the
// binary transmitted.
type multiTokenVerifier map[string]string // token -> account

func (v multiTokenVerifier) VerifyToken(_ context.Context, token string) (identity.Principal, error) {
	account, ok := v[token]
	if !ok {
		return identity.Principal{}, errors.New("unknown token")
	}
	return identity.Principal{
		AccountID: account, Email: "run-withhold@example.com",
		ExpiresAt: time.Now().Add(5 * time.Minute),
	}, nil
}

// assertCredentialWithheldFromSubprocess fails if any usable piece of token
// — the whole value, any contiguous prefix or suffix of 12+ bytes, or a
// reversible re-encoding — appears in the captured subprocess output.
// Twelve bytes is far below diagnostic utility: even that much is
// correlatable credential material, and the old bound-then-escape renderer
// leaked 256-byte prefixes (whole tokens below the bound).
func assertCredentialWithheldFromSubprocess(t *testing.T, name, out, token string) {
	t.Helper()
	if strings.Contains(out, token) {
		t.Fatalf("%s: full credential leaked", name)
	}
	for n := 12; n <= len(token); n++ {
		if strings.Contains(out, token[:n]) {
			t.Fatalf("%s: credential prefix of length %d leaked: %q", name, n, token[:n])
		}
		if strings.Contains(out, token[len(token)-n:]) {
			t.Fatalf("%s: credential suffix of length %d leaked: %q", name, n, token[len(token)-n:])
		}
	}
	for _, enc := range []string{
		url.QueryEscape(token),
		base64.StdEncoding.EncodeToString([]byte(token)),
		base64.URLEncoding.EncodeToString([]byte(token)),
	} {
		if strings.Contains(out, enc) {
			t.Fatalf("%s: re-encoded credential variant leaked: %q", name, enc)
		}
	}
}

// syncBuffer is a concurrency-safe buffer for subprocess output a test
// polls while the process is still running: exec's internal copying
// goroutine writes concurrently with the polling reads.
type syncBuffer struct {
	mu  sync.Mutex
	buf bytes.Buffer
}

func (b *syncBuffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.buf.Write(p)
}

func (b *syncBuffer) String() string {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.buf.String()
}

// TestCLIRunRejectionsWithholdEnrolledBearer is the ACTUAL run-path
// verification of the peer-diagnostic withholding policy, end to end with
// the real binary: two REAL enrollments succeed against a real identity API
// behind a recorder (so the hostile gateway below reflects the exact
// Authorization bearers the binary itself transmitted), and `run` is then
// pointed at a hostile local gateway that echoes those captured
// credentials back through every peer-controlled diagnostic channel — a
// fatal ErrMsg message at the pre-challenge stage (long and short bearer),
// a fatal raw close reason (at most 123 bytes survive the wire), and an
// unrecognized control-bearing ErrMsg code (which must stay transient).
// Fatal variants must exit 1 with the fixed safe verdict; the transient
// variant must keep the bounded reconnect; and no captured subprocess
// output may contain the credential whole, cut, or re-encoded.
func TestCLIRunRejectionsWithholdEnrolledBearer(t *testing.T) {
	if testing.Short() {
		t.Skip("runs the real binary through enroll + a hostile run gateway")
	}
	bin := buildCLI(t)
	probeAddr := startProbeOnlySSHDCLI(t)

	longTok := brokerShapedCanary(t, strings.Repeat("cli-run-canary-", 40))
	shortTok := brokerShapedCanary(t, "") // no jti claim: stays under 256 bytes
	if len(longTok) <= 256 {
		t.Fatalf("fixture: long credential is only %d bytes; want the reflected-prefix shape past 256", len(longTok))
	}
	if len(shortTok) >= 256 || len(shortTok) <= 12 {
		t.Fatalf("fixture: short credential is %d bytes; want the prints-whole shape (13..255)", len(shortTok))
	}

	// Real identity API behind a recorder.
	mem := identity.NewMemoryStore()
	idSvc, err := identity.NewService(identity.Config{
		Verifier: multiTokenVerifier{
			longTok:  "google:run-withhold-account",
			shortTok: "google:run-withhold-account",
		},
		Store:  mem,
		Domain: "127.0.0.1",
		Clock:  time.Now,
	})
	if err != nil {
		t.Fatal(err)
	}
	var mu sync.Mutex
	var authz []string
	idTS := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if a := r.Header.Get("Authorization"); a != "" {
			mu.Lock()
			authz = append(authz, a)
			mu.Unlock()
		}
		idSvc.ServeHTTP(w, r)
	}))
	t.Cleanup(idTS.Close)

	// Two real enrollments: the hostile gateways below reflect exactly
	// these transmitted Authorization bearers back.
	dirOf := map[string]string{
		longTok:  t.TempDir(),
		shortTok: t.TempDir(),
	}
	deviceOf := map[string]string{
		longTok:  "dev-run-withhold-long",
		shortTok: "dev-run-withhold-short",
	}
	for _, tok := range []string{longTok, shortTok} {
		out, errOut, code := runCLI(t, bin, tok,
			"enroll", "--token-stdin",
			"--server", idTS.URL,
			"--insecure-dev",
			"--config-dir", dirOf[tok],
			"--ssh-host", probeAddr,
			"--device-id", deviceOf[tok],
		)
		if code != 0 {
			t.Fatalf("enroll failed (code %d)\nstdout: %s\nstderr: %s", code, out, errOut)
		}
	}
	mu.Lock()
	seen := strings.Join(authz, "\n")
	mu.Unlock()
	for _, tok := range []string{longTok, shortTok} {
		if !strings.Contains(seen, "Bearer "+tok) {
			t.Fatalf("fixture: enrollment never transmitted the synthetic bearer (saw %d authz headers)", len(authz))
		}
	}

	// runHostileFatal points the real binary at a hostile local gateway and
	// requires the prompt fatal exit with the fixed safe verdict.
	runHostileFatal := func(t *testing.T, dir string, errJSON []byte, closeCode int, closeText string) string {
		t.Helper()
		hg := startHostilePeerGateway(t, errJSON, closeCode, closeText)
		ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
		defer cancel()
		var stdout, stderr bytes.Buffer
		cmd := exec.CommandContext(ctx, bin, "run",
			"--server", hg.url,
			"--insecure-dev",
			"--config-dir", dir,
		)
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr
		err := cmd.Run()
		var ee *exec.ExitError
		if !errors.As(err, &ee) || ee.ExitCode() != 1 {
			t.Fatalf("run exit: %v (want exit 1)\nstdout: %s\nstderr: %s", err, stdout.String(), stderr.String())
		}
		return stderr.String()
	}

	t.Run("fatal frame reflects the long enrolled bearer", func(t *testing.T) {
		stderr := runHostileFatal(t, dirOf[longTok],
			mustJSONErrMsgForCLI(t, tunnel.ErrMsg{
				Type: "error", V: tunnel.ProtocolVersion,
				Code: "unauthorized", Message: longTok,
			}),
			tunnel.CloseUnauth, "")
		assertCLIStderrTerminalSafe(t, stderr)
		if !strings.Contains(stderr, "gateway rejected this device (close 4401)") {
			t.Fatalf("stderr lacks the fixed fatal verdict:\n%s", stderr)
		}
		if !strings.Contains(stderr, "unauthorized") || !strings.Contains(stderr, "peer message withheld") {
			t.Fatalf("stderr lacks the canonical verdict + withholding phrase:\n%s", stderr)
		}
		if n := strings.Count(stderr, "\n"); n != 3 { // startup + agent-error slog lines + the CLI's own exit line
			t.Fatalf("stderr carries %d newlines (forged lines?):\n%s", n, stderr)
		}
		assertCredentialWithheldFromSubprocess(t, "stderr", stderr, longTok)
	})

	t.Run("fatal frame reflects the short enrolled bearer", func(t *testing.T) {
		stderr := runHostileFatal(t, dirOf[shortTok],
			mustJSONErrMsgForCLI(t, tunnel.ErrMsg{
				Type: "error", V: tunnel.ProtocolVersion,
				Code: "unauthorized", Message: shortTok,
			}),
			tunnel.CloseUnauth, "")
		assertCLIStderrTerminalSafe(t, stderr)
		if !strings.Contains(stderr, "gateway rejected this device (close 4401)") {
			t.Fatalf("stderr lacks the fixed fatal verdict:\n%s", stderr)
		}
		assertCredentialWithheldFromSubprocess(t, "stderr", stderr, shortTok)
	})

	t.Run("fatal close reason reflects the enrolled bearer", func(t *testing.T) {
		// No ErrMsg frame: the close frame's raw reason carries the bearer
		// prefix. The wire truncates it to 123 bytes (control frames cap at
		// 125 bytes of payload including the two-byte code; longer frames
		// are invalid and never deliver), so the reachable reflection is
		// exactly this prefix-leak shape.
		stderr := runHostileFatal(t, dirOf[shortTok], nil, tunnel.CloseUnauth, shortTok[:123])
		assertCLIStderrTerminalSafe(t, stderr)
		if !strings.Contains(stderr, "gateway rejected this device (close 4401)") {
			t.Fatalf("stderr lacks the fixed fatal verdict:\n%s", stderr)
		}
		if !strings.Contains(stderr, "peer close reason withheld") {
			t.Fatalf("stderr lacks the close-reason withholding phrase:\n%s", stderr)
		}
		assertCredentialWithheldFromSubprocess(t, "stderr", stderr, shortTok)
	})

	t.Run("unrecognized control code stays transient and withheld", func(t *testing.T) {
		laundered := "revoked\u202e" // bidi-laundered: NOT the revoked verdict
		hg := startHostilePeerGateway(t,
			mustJSONErrMsgForCLI(t, tunnel.ErrMsg{
				Type: "error", V: tunnel.ProtocolVersion,
				Code: laundered, Message: longTok,
			}),
			tunnel.CloseForbidden, "")
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		var stdout, stderr syncBuffer // polled while the process runs
		cmd := exec.CommandContext(ctx, bin, "run",
			"--server", hg.url,
			"--insecure-dev",
			"--config-dir", dirOf[longTok],
		)
		cmd.Stdout = &stdout
		cmd.Stderr = &stderr
		done := make(chan error, 1)
		go func() { done <- cmd.Run() }()

		// The agent must ride the transient rejection out: several bounded
		// reconnects, never a fatal exit.
		deadline := time.After(10 * time.Second)
		for {
			reconnects := strings.Count(stderr.String(), "reconnecting")
			if reconnects >= 2 {
				break
			}
			select {
			case err := <-done:
				t.Fatalf("run exited on an unrecognized peer code: %v\nstderr: %s", err, stderr.String())
			case <-deadline:
				t.Fatalf("no bounded reconnects within the window\nstderr: %s", stderr.String())
			case <-time.After(50 * time.Millisecond):
			}
		}
		// Still alive after the reconnects, then stop it cleanly.
		select {
		case err := <-done:
			t.Fatalf("run exited while the rejection stayed transient: %v\nstderr: %s", err, stderr.String())
		case <-time.After(1200 * time.Millisecond):
		}
		cancel()
		select {
		case <-done:
		case <-time.After(5 * time.Second):
			t.Fatal("run did not stop after cancel")
		}

		out := stdout.String() + stderr.String()
		assertCLIStderrTerminalSafe(t, stderr.String())
		assertCredentialWithheldFromSubprocess(t, "output", out, longTok)
		if strings.Contains(out, laundered) {
			t.Fatalf("raw hostile peer code reached subprocess output:\n%s", out)
		}
	})
}

// peerFieldGateway speaks the agent handshake like tunnel.Service and then
// delivers ONE crafted peer-controlled frame: either as the very first
// frame ("pre" — the challenge slot) or after reading the agent's signed
// auth ("post" — the ok-ack slot; the signature is verified against the
// enrolled device key from the real identity store, so the fixture proves
// the agent really transmitted its proof before the hostile reply lands).
type peerFieldGateway struct {
	srv      *httptest.Server
	url      string
	stage    string
	frame    []byte
	deviceID string
	pub      ed25519.PublicKey
}

func startPeerFieldGateway(t *testing.T, stage string, frame []byte, deviceID string, pub ed25519.PublicKey) *peerFieldGateway {
	t.Helper()
	gw := &peerFieldGateway{stage: stage, frame: frame, deviceID: deviceID, pub: pub}
	up := websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}
	gw.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ws, err := up.Upgrade(w, r, nil)
		if err != nil {
			return
		}
		defer ws.Close()
		_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
		if stage == "post" {
			// Valid challenge scaffolding: the agent must accept it, sign,
			// and send HostAuth before the crafted reply is served.
			nonce := make([]byte, 32)
			connNonce := make([]byte, 32)
			if _, err := rand.Read(nonce); err != nil {
				return
			}
			if _, err := rand.Read(connNonce); err != nil {
				return
			}
			enc := base64.StdEncoding.EncodeToString
			ch := tunnel.HostChallenge{
				Type: "challenge", V: tunnel.ProtocolVersion,
				ChallengeID: "gw-field-" + deviceID,
				Nonce:       enc(nonce), ConnectionNonce: enc(connNonce),
				Server: "127.0.0.1", Role: identity.RoleHost,
				Protocol:  tunnel.ProtocolTunnel,
				ExpiresAt: time.Now().Add(time.Minute).Unix(),
			}
			chJSON, err := json.Marshal(ch)
			if err != nil {
				return
			}
			if err := ws.WriteMessage(websocket.TextMessage, chJSON); err != nil {
				return
			}
			_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
			_, raw, err := ws.ReadMessage()
			if err != nil {
				return
			}
			var auth tunnel.HostAuth
			if err := json.Unmarshal(raw, &auth); err != nil {
				return
			}
			sig, err := base64.StdEncoding.DecodeString(auth.Signature)
			if err != nil || auth.DeviceID != deviceID {
				return
			}
			idCh, err := ch.ToIdentityChallenge(deviceID)
			if err != nil || identity.Verify(gw.pub, idCh, sig) != nil {
				return
			}
			_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
		}
		_ = ws.WriteMessage(websocket.TextMessage, gw.frame)
		time.Sleep(2 * time.Second) // hold the socket while the agent reacts
	}))
	t.Cleanup(gw.srv.Close)
	gw.url = "ws" + strings.TrimPrefix(gw.srv.URL, "http")
	return gw
}

// TestCLIRunPeerFieldReflectionWithheldBearer extends the run-path
// credential-withholding verification to the remaining handshake-validation
// fields (run-peer-fields-final): REAL enrollments transmit synthetic
// broker bearers, and `run` is pointed at a hostile local gateway that
// reflects those exact credentials back through the challenge
// type/server/role/protocol fields and the post-proof handshake reply type.
// Under the previous renderings every one of these fields printed its peer
// value (%q or the shared %s role/protocol text) into the reconnect
// warnings. Each variant must stay transient (bounded reconnects, never a
// fatal exit), render only the fixed local diagnostics, and carry no
// credential whole, cut, or re-encoded, and no hostile control payload in
// any form.
func TestCLIRunPeerFieldReflectionWithheldBearer(t *testing.T) {
	if testing.Short() {
		t.Skip("runs the real binary through enroll + hostile validation-field gateways")
	}
	bin := buildCLI(t)
	probeAddr := startProbeOnlySSHDCLI(t)

	longTok := brokerShapedCanary(t, strings.Repeat("cli-field-canary-", 40))
	shortTok := brokerShapedCanary(t, "") // no jti claim: the prints-whole shape
	if len(longTok) <= 256 {
		t.Fatalf("fixture: long credential is only %d bytes; want the reflected-prefix shape past 256", len(longTok))
	}
	if len(shortTok) >= 256 || len(shortTok) <= 12 {
		t.Fatalf("fixture: short credential is %d bytes; want the prints-whole shape (13..255)", len(shortTok))
	}

	// Real identity API behind a recorder, exactly like the ErrMsg/close
	// fixture: the hostile gateways below reflect the bearers the binary
	// itself transmitted.
	mem := identity.NewMemoryStore()
	idSvc, err := identity.NewService(identity.Config{
		Verifier: multiTokenVerifier{
			longTok:  "google:run-field-account",
			shortTok: "google:run-field-account",
		},
		Store:  mem,
		Domain: "127.0.0.1",
		Clock:  time.Now,
	})
	if err != nil {
		t.Fatal(err)
	}
	var mu sync.Mutex
	var authz []string
	idTS := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if a := r.Header.Get("Authorization"); a != "" {
			mu.Lock()
			authz = append(authz, a)
			mu.Unlock()
		}
		idSvc.ServeHTTP(w, r)
	}))
	t.Cleanup(idTS.Close)

	dirOf := map[string]string{
		longTok:  t.TempDir(),
		shortTok: t.TempDir(),
	}
	deviceOf := map[string]string{
		longTok:  "dev-run-field-long",
		shortTok: "dev-run-field-short",
	}
	for _, tok := range []string{longTok, shortTok} {
		out, errOut, code := runCLI(t, bin, tok,
			"enroll", "--token-stdin",
			"--server", idTS.URL,
			"--insecure-dev",
			"--config-dir", dirOf[tok],
			"--ssh-host", probeAddr,
			"--device-id", deviceOf[tok],
		)
		if code != 0 {
			t.Fatalf("enroll failed (code %d)\nstdout: %s\nstderr: %s", code, out, errOut)
		}
	}
	mu.Lock()
	seen := strings.Join(authz, "\n")
	mu.Unlock()
	for _, tok := range []string{longTok, shortTok} {
		if !strings.Contains(seen, "Bearer "+tok) {
			t.Fatalf("fixture: enrollment never transmitted the synthetic bearer (saw %d authz headers)", len(authz))
		}
	}

	// enrolledPub fetches the real device public key so the post-proof
	// fixture verifies the agent's signed auth before serving its crafted
	// reply.
	enrolledPub := func(t *testing.T, deviceID string) ed25519.PublicKey {
		t.Helper()
		dev, err := idSvc.Store().GetDevice(deviceID)
		if err != nil {
			t.Fatalf("device %s not enrolled: %v", deviceID, err)
		}
		if len(dev.PublicKey) != ed25519.PublicKeySize {
			t.Fatalf("device %s public key is %d bytes", deviceID, len(dev.PublicKey))
		}
		return ed25519.PublicKey(dev.PublicKey)
	}

	// craftedChallenge builds a challenge that passes every validation
	// except the one corrupted field.
	craftedChallenge := func(t *testing.T, cor func(*tunnel.HostChallenge)) []byte {
		t.Helper()
		nonce := make([]byte, 32)
		connNonce := make([]byte, 32)
		if _, err := rand.Read(nonce); err != nil {
			t.Fatal(err)
		}
		if _, err := rand.Read(connNonce); err != nil {
			t.Fatal(err)
		}
		enc := base64.StdEncoding.EncodeToString
		ch := tunnel.HostChallenge{
			Type: "challenge", V: tunnel.ProtocolVersion,
			ChallengeID: "gw-field-crafted",
			Nonce:       enc(nonce), ConnectionNonce: enc(connNonce),
			Server: "127.0.0.1", Role: identity.RoleHost,
			Protocol:  tunnel.ProtocolTunnel,
			ExpiresAt: time.Now().Add(time.Minute).Unix(),
		}
		cor(&ch)
		b, err := json.Marshal(ch)
		if err != nil {
			t.Fatal(err)
		}
		return b
	}

	cases := []struct {
		name       string
		dir        string
		stage      string // "pre": crafted first frame; "post": crafted ok slot
		frame      func(t *testing.T) []byte
		wantPhrase string
		token      string // reflected credential that must not appear ("" = control payload only)
		forbidden  []string
	}{
		{
			name: "handshake reply type reflects the short enrolled bearer",
			dir:  dirOf[shortTok], stage: "post",
			frame: func(t *testing.T) []byte {
				return mustJSONFrameForCLI(t, tunnel.OKMsg{Type: shortTok, V: tunnel.ProtocolVersion})
			},
			wantPhrase: "unexpected handshake reply: peer reply type withheld",
			token:      shortTok,
		},
		{
			name: "challenge type reflects the short enrolled bearer",
			dir:  dirOf[shortTok], stage: "pre",
			frame: func(t *testing.T) []byte {
				return craftedChallenge(t, func(ch *tunnel.HostChallenge) { ch.Type = shortTok })
			},
			wantPhrase: "unexpected challenge: peer type withheld",
			token:      shortTok,
		},
		{
			name: "challenge server mismatch reflects the long enrolled bearer",
			dir:  dirOf[longTok], stage: "pre",
			frame: func(t *testing.T) []byte {
				return craftedChallenge(t, func(ch *tunnel.HostChallenge) { ch.Server = longTok })
			},
			wantPhrase: "challenge: peer server name does not match the configured server",
			token:      longTok,
		},
		{
			name: "challenge role mismatch reflects the short enrolled bearer",
			dir:  dirOf[shortTok], stage: "pre",
			frame: func(t *testing.T) []byte {
				return craftedChallenge(t, func(ch *tunnel.HostChallenge) { ch.Role = shortTok })
			},
			wantPhrase: "challenge: peer role/protocol/nonce fields failed local validation (peer values withheld)",
			token:      shortTok,
		},
		{
			name: "challenge protocol mismatch reflects the long enrolled bearer",
			dir:  dirOf[longTok], stage: "pre",
			frame: func(t *testing.T) []byte {
				return craftedChallenge(t, func(ch *tunnel.HostChallenge) { ch.Protocol = longTok })
			},
			wantPhrase: "challenge: peer role/protocol/nonce fields failed local validation (peer values withheld)",
			token:      longTok,
		},
		{
			name: "challenge role carries terminal controls and forged lines",
			dir:  dirOf[shortTok], stage: "pre",
			frame: func(t *testing.T) []byte {
				return craftedChallenge(t, func(ch *tunnel.HostChallenge) { ch.Role = cliHostileReason })
			},
			wantPhrase: "challenge: peer role/protocol/nonce fields failed local validation (peer values withheld)",
			forbidden:  []string{"FORGED", "pwned", "evil", `\x1b`, `\u202e`},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			var pub ed25519.PublicKey
			if tc.stage == "post" {
				pub = enrolledPub(t, deviceOf[shortTok])
			}
			gw := startPeerFieldGateway(t, tc.stage, tc.frame(t), deviceOf[shortTok], pub)

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			var stdout, stderr syncBuffer // polled while the process runs
			cmd := exec.CommandContext(ctx, bin, "run",
				"--server", gw.url,
				"--insecure-dev",
				"--config-dir", tc.dir,
			)
			cmd.Stdout = &stdout
			cmd.Stderr = &stderr
			done := make(chan error, 1)
			go func() { done <- cmd.Run() }()

			// The validation refusal stays transient: several bounded
			// reconnects, never a fatal exit.
			deadline := time.After(15 * time.Second)
			for {
				reconnects := strings.Count(stderr.String(), "reconnecting")
				if reconnects >= 2 {
					break
				}
				select {
				case err := <-done:
					t.Fatalf("run exited on a validation-field rejection: %v\nstderr: %s", err, stderr.String())
				case <-deadline:
					t.Fatalf("no bounded reconnects within the window\nstderr: %s", stderr.String())
				case <-time.After(50 * time.Millisecond):
				}
			}
			// Still alive after the reconnects, then stop it cleanly.
			select {
			case err := <-done:
				t.Fatalf("run exited while the rejection stayed transient: %v\nstderr: %s", err, stderr.String())
			case <-time.After(1200 * time.Millisecond):
			}
			cancel()
			select {
			case <-done:
			case <-time.After(5 * time.Second):
				t.Fatal("run did not stop after cancel")
			}

			out := stdout.String() + stderr.String()
			assertCLIStderrTerminalSafe(t, stderr.String())
			if !strings.Contains(out, tc.wantPhrase) {
				t.Fatalf("output lacks the fixed local phrase %q:\n%s", tc.wantPhrase, out)
			}
			if tc.token != "" {
				assertCredentialWithheldFromSubprocess(t, "output", out, tc.token)
			}
			for _, frag := range tc.forbidden {
				if strings.Contains(out, frag) {
					t.Fatalf("hostile payload fragment %q survived in subprocess output:\n%s", frag, out)
				}
			}
		})
	}
}
