package main

// Lifecycle regressions for the ACTUAL lifecycle entrypoint (run — and the
// real binary for signal/exit-code semantics). Astra P1: the previous
// wiring called log.Fatal on every http.Server.Serve return, so the
// EXPECTED ErrServerClosed of a coordinated SIGTERM shutdown exited the
// process (code 1) mid-drain — before the tunnel close, the HTTP drain and
// the hijacked legacy/tunnel SSH sessions completed — and the ACME serving
// goroutine could kill the whole process the moment its server stopped.
//
// Proven here, through run() itself (never a reconstructed server pair):
//
//   - a cancelled lifecycle context (what SIGTERM delivers through
//     signal.NotifyContext) drains EVERYTHING — tunnel teardown, service
//     and ACME servers, hijacked active SSH sessions — and run returns
//     nil, with both ports closed afterwards;
//   - the root-owned handler tracker joins the handlers both servers
//     cannot see: an UPGRADED host agent parked before its signed proof
//     and a client WebSocket parked before its first auth frame are
//     force-closed by the drain, their completion is joined BEFORE run
//     returns (deterministic doneGate seam), and no new upgrade is
//     admitted mid-drain (admission shutter);
//   - a REAL in-Serve failure (injected listener death) is surfaced as
//     run's error AFTER the same coordinated drain — the process-equivalent
//     behavior is an error exit, not an abrupt kill from a goroutine;
//   - a drain that hits its Shutdown bound is recorded as an error: run
//     never claims a complete drain that did not happen — and on a spent
//     bound the drain force-closes the blocked ordinary connection and
//     cancels the server's owned request contexts, so run returns the
//     explicit error instead of waiting forever on a non-hijacked handler
//     parked on a dead client;
//   - the final join is bounded: a tracked completion that cannot finish
//     turns into a recorded join error within the bound — never an
//     unbounded wait, never a success;
//   - startup error paths (refused binds, verifier refusal) surface as
//     returned errors;
//   - the real binary, driven as an actual process: SIGTERM with an
//     ACTIVE, REAL-AUTHENTICATED, independently-pinned SSH session (and,
//     separately, a legacy hijacked session) tears the session down with a
//     NON-TIMEOUT termination, the lab sshd's own counters prove the
//     backend leg closed — all asserted BEFORE the parent's deferred
//     cleanup — and the process exits 0. A refused bind exits non-zero.
//
// False-positive discipline (the corrections): wherever a test waits for a
// socket or an SSH client to die, a TIMEOUT-class error is a FAILURE, not
// evidence — a local read deadline must never stand in for the behavior
// under test; outer test timeouts stay outside the transport.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"testing"
	"time"

	"github.com/gorilla/websocket"

	"github.com/PocketShell-io/pocketshell-gateway/internal/hostagent"
	"github.com/PocketShell-io/pocketshell-gateway/internal/routingauth"
	"github.com/PocketShell-io/pocketshell-gateway/internal/testtoolchain"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
	"github.com/PocketShell-io/pocketshell-gateway/security/sshlab"
)

// --- shared lifecycle fixtures -------------------------------------------------

// useTempRegistryBase repoints the registry state root at a per-test
// temp directory (production binaries run with the /var/lib default).
func useTempRegistryBase(t *testing.T) {
	t.Helper()
	oldBase, oldRegistry, oldTunnel := registryBaseDir, registryPosture, tunnelPosture
	registryBaseDir = t.TempDir()
	t.Cleanup(func() {
		registryBaseDir, registryPosture, tunnelPosture = oldBase, oldRegistry, oldTunnel
	})
}

// freeAddr returns a 127.0.0.1 address that was free at call time. The
// bind-then-release race window is accepted: a collision fails the run()
// call loudly instead of passing silently.
func freeAddr(t *testing.T) string {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer l.Close()
	return l.Addr().String()
}

// waitHealthz polls until /healthz answers 200.
func waitHealthz(t *testing.T, base string) {
	t.Helper()
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		res, err := http.Get(base + "/healthz")
		if err == nil {
			res.Body.Close()
			if res.StatusCode == http.StatusOK {
				return
			}
		}
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatal("healthz never answered 200")
}

// tlsHealthzClient speaks TLS to a production-mode service port with the
// fixture SNI, trusting exactly the fixture CA — the self-signed cached
// cert is signed by that CA, so certificate verification is complete and
// never bypassed.
func tlsHealthzClient(ca *fixtureCA, domain string) *http.Client {
	return &http.Client{
		Transport: &http.Transport{TLSClientConfig: ca.clientConfig(domain)},
		Timeout:   5 * time.Second,
	}
}

// waitHealthzClient polls until /healthz answers 200 through client.
func waitHealthzClient(t *testing.T, client *http.Client, base string) {
	t.Helper()
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		res, err := client.Get(base + "/healthz")
		if err == nil {
			res.Body.Close()
			if res.StatusCode == http.StatusOK {
				return
			}
		}
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatal("healthz never answered 200 through the TLS client")
}

// addrRefused asserts nothing accepts on addr any more (drain completed).
func addrRefused(t *testing.T, addr string) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		conn, err := net.DialTimeout("tcp", addr, time.Second)
		if err != nil {
			return // refused: the listener is gone
		}
		conn.Close()
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatalf("%s still accepting after the drain", addr)
}

// lifecycleConfig is the dev-mode runtimeConfig shared by the in-process
// lifecycle tests: full new-API wiring (real routingauth verifier against
// the fixture broker's TLS JWKS, real registry file, real tunnel) on a
// plain-HTTP service port.
func lifecycleConfig(t *testing.T, b *testBroker, listen string) runtimeConfig {
	t.Helper()
	allow := []string{"ops@example.com"}
	return runtimeConfig{
		listen:   listen,
		origins:  parseOrigins("https://app.pocketshell.io"),
		clientID: "unused-in-dev",
		allow:    allow,
		registry: filepath.Join(registryBaseDir, "registry.json"),
		broker: brokerConfig{
			issuer:   b.issuer,
			jwksURL:  b.jwksURL,
			audience: routingauth.Audience,
			allow:    allow,
			client:   b.tlsClient,
		},
	}
}

// startLifecycleAgent runs the real hostagent session loop against a run()-
// owned server. Unlike startRealAgent it cannot poll the tunnel service
// handle (run builds it internally), so readiness is proven end to end by
// the client session dial in the test.
func startLifecycleAgent(t *testing.T, serverURL, deviceID string, key ed25519.PrivateKey, sshAddr string) (stop func()) {
	t.Helper()
	wsURL := "ws" + strings.TrimPrefix(serverURL, "http")
	ctx, cancel := context.WithCancel(context.Background())
	agent := hostagent.NewAgent(hostagent.AgentConfig{
		ServerURL:        wsURL,
		DeviceID:         deviceID,
		Key:              key,
		SSHHost:          sshAddr,
		HandshakeTimeout: 3 * time.Second,
		LocalDialTimeout: 2 * time.Second,
		Logger:           quietLogger(),
	})
	done := make(chan error, 1)
	go func() { done <- agent.Run(ctx) }()
	stop = func() {
		cancel()
		select {
		case err := <-done:
			if err != nil {
				t.Logf("agent stop: %v", err)
			}
		case <-time.After(5 * time.Second):
			t.Log("agent did not stop within 5s")
		}
	}
	return stop
}

// waitClientSSH retries the client handshake until the agent-connected
// tunnel admits it (bounded), returning the live session.
func waitClientSSH(t *testing.T, serverURL, deviceID, token string) (*websocket.Conn, tunnel.ReadyMsg) {
	t.Helper()
	deadline := time.Now().Add(10 * time.Second)
	var lastErr error
	for time.Now().Before(deadline) {
		ws, ready, err := tryDialClientSSH(t, serverURL, deviceID, token)
		if err == nil {
			return ws, ready
		}
		lastErr = err
		time.Sleep(50 * time.Millisecond)
	}
	t.Fatalf("client session never admitted: %v", lastErr)
	return nil, tunnel.ReadyMsg{}
}

// labSSHWorld is the REAL home SSH endpoint of the lifecycle tests: an
// in-process lab sshd with an independent host-key pin and a real client
// key (P12 recipe shape; an echo stand-in does not qualify for the SSH
// claim).
type labSSHWorld struct {
	sshd       *sshlab.Server
	pinLine    string
	clientKey  *sshlab.SSHKey
	deviceKey  ed25519.PrivateKey
	deviceID   string
	deviceStop func()
}

func newLabSSHWorld(t *testing.T, serverURL, token string) *labSSHWorld {
	t.Helper()
	hostKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	clientKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	sshd, err := sshlab.StartSSHD(hostKey.Signer, clientKey.Public)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(sshd.Close)
	w := &labSSHWorld{
		sshd:      sshd,
		pinLine:   strings.TrimSpace(hostKey.AuthorizedLine()),
		clientKey: clientKey,
		deviceKey: ed25519.NewKeyFromSeed([]byte("lifecycle device seed 32 bytes!!")),
		deviceID:  "lifecycle-1",
	}
	enrollOverHTTPWithHostKey(t, serverURL, token, w.deviceID, w.deviceKey, w.pinLine, false)
	w.deviceStop = startLifecycleAgent(t, serverURL, w.deviceID, w.deviceKey, sshd.Addr())
	t.Cleanup(w.deviceStop)
	return w
}

// --- P1: coordinated shutdown through the entrypoint ---------------------------

func TestRunLifecycleShutdownDrainsActiveSSHAndReturnsNil(t *testing.T) {
	useTempRegistryBase(t)
	b := newTestBroker(t)
	addr := freeAddr(t)
	cfg := lifecycleConfig(t, b, addr)

	ctx, cancel := context.WithCancel(context.Background())
	runErr := make(chan error, 1)
	go func() { runErr <- run(ctx, cfg) }()
	base := "http://" + addr
	waitHealthz(t, base)

	// Active REAL SSH session through the tunnel (hijacked, untracked by
	// http.Server.Shutdown) alive when shutdown lands. The run()-owned
	// server verifies REAL broker credentials, so the bearer is a signed
	// fixture JWT. (The legacy proxy's hijack is covered by the subprocess
	// SIGTERM test: validateConfig refuses dev-auth bypasses next to the
	// registry this test runs.)
	token := b.sign(t, b.validClaims())
	w := newLabSSHWorld(t, base, token)
	ws, ready := waitClientSSH(t, base, w.deviceID, token)
	if !samePin(ready.SSHHostKey, w.pinLine) {
		t.Fatalf("ready advisory %q does not match the pinned endpoint", ready.SSHHostKey)
	}
	cl := realSSHSession(t, ws, w.pinLine, w.clientKey.Signer)
	closedBefore := w.sshd.Stats().ClosedConns

	// SIGTERM equivalent: cancel the lifecycle context.
	cancel()

	// The ACTIVE SSH session is torn down as part of the drain — never by
	// one of our own local deadlines (a timeout-class Wait is a FAILURE),
	// and the lab sshd's OWN counters prove the backend leg closed BEFORE
	// any deferred cleanup runs. With revocation/drain teardown disabled,
	// both assertions fail: the client survives and the counter stays.
	expectSSHClientTeardown(t, cl, "coordinated shutdown")
	requireBackendClosed(t, w.sshd, closedBefore, "coordinated shutdown")

	// run itself returns NIL on the coordinated shutdown (the old code
	// surfaced ErrServerClosed as a fatal error), only after the drain.
	select {
	case err := <-runErr:
		if err != nil {
			t.Fatalf("coordinated shutdown returned an error: %v", err)
		}
	case <-time.After(15 * time.Second):
		t.Fatal("run did not return after the coordinated shutdown")
	}
	// Both facts hold at return: the port no longer accepts.
	addrRefused(t, addr)
}

// legacySSHSession opens a legacy proxy session (dev wiring) toward the
// lab sshd: a real hijacked WebSocket carrying real SSH bytes.
func legacySSHSession(t *testing.T, addr, sshAddr string) *websocket.Conn {
	t.Helper()
	host, port, err := net.SplitHostPort(sshAddr)
	if err != nil {
		t.Fatal(err)
	}
	ws, _, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial(fmt.Sprintf("ws://%s/?host=%s&port=%s&token=dev", addr, host, port), nil)
	if err != nil {
		t.Fatalf("legacy dial: %v", err)
	}
	t.Cleanup(func() { ws.Close() })
	return ws
}

// legacyExchange writes a client banner and reads the server's SSH banner
// back through the pipe.
func legacyExchange(t *testing.T, ws *websocket.Conn, banner string) string {
	t.Helper()
	ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if err := ws.WriteMessage(websocket.BinaryMessage, []byte(banner)); err != nil {
		t.Fatalf("legacy write: %v", err)
	}
	ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	for {
		_, data, err := ws.ReadMessage()
		if err != nil {
			t.Fatalf("legacy read: %v", err)
		}
		if len(data) > 0 {
			return string(data)
		}
	}
}

// expectGenuineWSClose requires the WebSocket to terminate with a REAL
// close (EOF, reset, abnormal closure — anything but a timeout) within the
// window. A read TIMEOUT is a FAILURE, never evidence: it would mean the
// socket survived the drain and only our own deadline fired — exactly the
// false pass the corrections forbid.
func expectGenuineWSClose(t *testing.T, ws *websocket.Conn, what string) {
	t.Helper()
	// Clear any deadline a handshake helper may have left behind first:
	// the close under test must be the drain's, observable within the
	// OUTER bound below.
	if err := ws.SetReadDeadline(time.Time{}); err != nil {
		t.Fatalf("%s: %v", what, err)
	}
	ws.SetReadDeadline(time.Now().Add(10 * time.Second))
	for {
		if _, _, err := ws.ReadMessage(); err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				t.Fatalf("%s: still open after 10s — the reported close was our own read deadline, not the drain", what)
			}
			return
		}
	}
}

// dialPreProofAgent opens a tunnel agent WebSocket and consumes the
// server's challenge frame, leaving the handler upgraded and parked BEFORE
// the signed proof — the exact pre-authentication window neither
// http.Server.Shutdown nor tunnel.Service.Close tracks.
func dialPreProofAgent(t *testing.T, base, token string) *websocket.Conn {
	t.Helper()
	ws, _, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial("ws"+strings.TrimPrefix(base, "http")+"/api/v1/agent/connect", nil)
	if err != nil {
		t.Fatalf("pre-proof agent dial: %v", err)
	}
	t.Cleanup(func() { ws.Close() })
	var ch tunnel.HostChallenge
	readJSONWS(t, ws, &ch)
	if ch.Type != "challenge" || ch.ChallengeID == "" {
		t.Fatalf("agent got %+v, want a challenge frame", ch)
	}
	// Parked pre-proof: no deadline of ours may mask the drain's close.
	if err := ws.SetReadDeadline(time.Time{}); err != nil {
		t.Fatal(err)
	}
	return ws
}

// dialPreAuthClient opens a tunnel client WebSocket and sends NOTHING: the
// handler parks before the first auth frame (the upgrade itself needs no
// credential — admission is checked at frame time).
func dialPreAuthClient(t *testing.T, base, deviceID string) *websocket.Conn {
	t.Helper()
	ws, res, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial("ws"+strings.TrimPrefix(base, "http")+"/api/v1/hosts/"+deviceID+"/ssh", nil)
	if err != nil {
		t.Fatalf("pre-auth client dial: %v (res %v)", err, res)
	}
	t.Cleanup(func() { ws.Close() })
	if err := ws.SetReadDeadline(time.Time{}); err != nil {
		t.Fatal(err)
	}
	return ws
}

// TestRunDrainJoinsPreAuthUpgradesBeforeReturn is the root-owned lifecycle
// regression the corrections demand: a host agent upgraded but BEFORE its
// signed proof, and a client WebSocket BEFORE its first auth frame — the
// two pre-authentication windows http.Server.Shutdown ignores (hijacked)
// and tunnel.Service.Close does not cover — are held across a drain.
// Proven, in order:
//
//  1. cancelling run's lifecycle force-closes BOTH pre-auth sockets
//     promptly (they do not survive their HandshakeTimeout);
//  2. the join is real: with every handler completion parked at the
//     deterministic doneGate seam, run has NOT returned while the tracked
//     handlers are still completing — and the HTTP servers have drained;
//  3. no new upgrade is admitted mid-drain (admission shutter / closed
//     listener);
//  4. releasing the seam lets the handlers finish and run return nil.
//
// The old shape (drain without the root tracker) cannot pass: it returns
// while the gate is still held and leaves the pre-auth sockets open to
// survive their handshake deadlines.
func TestRunDrainJoinsPreAuthUpgradesBeforeReturn(t *testing.T) {
	useTempRegistryBase(t)
	b := newTestBroker(t)
	addr := freeAddr(t)
	cfg := lifecycleConfig(t, b, addr)
	tr := newHandlerTracker()
	cfg.newTracker = func() *handlerTracker { return tr }

	ctx, cancel := context.WithCancel(context.Background())
	runErr := make(chan error, 1)
	go func() { runErr <- run(ctx, cfg) }()
	base := "http://" + addr
	waitHealthz(t, base)

	agentWS := dialPreProofAgent(t, base, b.sign(t, b.validClaims()))
	clientWS := dialPreAuthClient(t, base, "laptop-1")

	// The tracker holds both pre-auth handlers from their first line.
	tr.mu.Lock()
	parked := tr.inFlight
	tr.mu.Unlock()
	if parked < 2 {
		t.Fatalf("tracked in-flight handlers = %d, want at least the two pre-auth upgrades", parked)
	}

	// Arm the deterministic seam BEFORE the signal: every handler
	// completion from now on parks until the test releases it, making
	// run's join observable.
	gate := make(chan struct{})
	tr.armDoneGate(gate)

	cancel() // SIGTERM equivalent

	// 1. BOTH pre-auth sockets are force-closed by the drain — genuinely,
	// not by our own read deadlines.
	expectGenuineWSClose(t, agentWS, "pre-proof agent ws")
	expectGenuineWSClose(t, clientWS, "pre-auth client ws")

	// 2. Join ordering at the deterministic seam: the HTTP servers have
	// drained (the port refuses), yet run is STILL waiting on the parked
	// completions.
	refuseUpgradeDuringDrain(t, base)
	addrRefused(t, addr)
	select {
	case err := <-runErr:
		t.Fatalf("run returned while tracked handlers were still completing: %v", err)
	case <-time.After(500 * time.Millisecond):
	}

	// 4. Release: handlers finish, the join completes, run returns nil.
	close(gate)
	select {
	case err := <-runErr:
		if err != nil {
			t.Fatalf("coordinated shutdown returned an error: %v", err)
		}
	case <-time.After(15 * time.Second):
		t.Fatal("run did not return after the seam release")
	}
}

// refuseUpgradeDuringDrain requires upgrade attempts to start failing and
// STAY failing: the admission shutter answers 503 while the server still
// drains, and the closed listener refuses the dial afterwards. A 101
// during the drain is the bug. The retry loop exists so the probe cannot
// race the drain goroutine through the pre-shutter window.
func refuseUpgradeDuringDrain(t *testing.T, base string) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for {
		ws, res, err := (&websocket.Dialer{HandshakeTimeout: 2 * time.Second}).
			Dial("ws"+strings.TrimPrefix(base, "http")+"/api/v1/agent/connect", nil)
		if err != nil {
			if res != nil {
				res.Body.Close()
				if res.StatusCode == http.StatusServiceUnavailable {
					return // admission shutter refused it
				}
			}
			return // listener closed: the dial is refused
		}
		ws.Close()
		if time.Now().After(deadline) {
			t.Fatal("upgrades still admitted during the drain")
		}
		time.Sleep(20 * time.Millisecond)
	}
}

// --- handler tracker units: shutter, force-close, join, deadline pass-through ----

// TestHandlerTrackerShutterForceCloseAndJoin pins the tracker's semantics
// directly (deterministic, no lifecycle needed): a hijacking handler's
// socket is owned by the tracker, beginDrain force-closes it while a NEW
// handler is refused by the admission shutter, and waitIdle joins the
// parked completion only after the test seam releases it.
func TestHandlerTrackerShutterForceCloseAndJoin(t *testing.T) {
	tr := newHandlerTracker()
	gate := make(chan struct{})
	tr.armDoneGate(gate)
	entered := make(chan struct{})
	closedRead := make(chan error, 1)
	srv := httptest.NewServer(tr.track(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		hj, ok := w.(http.Hijacker)
		if !ok {
			t.Error("handler writer lost the Hijacker contract")
			return
		}
		conn, brw, err := hj.Hijack()
		if err != nil {
			t.Errorf("hijack: %v", err)
			return
		}
		_, _ = brw.WriteString("HTTP/1.1 101 Switching Protocols\r\n\r\n")
		_ = brw.Flush()
		close(entered)
		buf := make([]byte, 16)
		_, readErr := conn.Read(buf) // parks until the tracker force-closes
		closedRead <- readErr
		<-tr.doneGate // park the completion at the deterministic seam
	})))
	defer srv.Close()

	// A raw client completes the (pseudo-)upgrade; the socket is now the
	// tracker's.
	conn, err := net.DialTimeout("tcp", strings.TrimPrefix(srv.URL, "http://"), 2*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	if _, err := conn.Write([]byte("GET / HTTP/1.1\r\nHost: t\r\n\r\n")); err != nil {
		t.Fatal(err)
	}
	select {
	case <-entered:
	case <-time.After(5 * time.Second):
		t.Fatal("handler never hijacked")
	}

	// Drain: the hijacked socket is force-closed (the CLIENT sees a real
	// close — a timeout would be our own deadline, i.e. the bug), a NEW
	// request is refused by the shutter with 503, and the join waits at
	// the parked completion.
	tr.beginDrain()
	conn.SetReadDeadline(time.Now().Add(5 * time.Second))
	buf := make([]byte, 64)
	sawUpgradeBytes := false
	for {
		n, err := conn.Read(buf)
		if n > 0 {
			sawUpgradeBytes = true // the 101 response bytes
		}
		if err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				t.Fatal("hijacked socket close was not observed — our own read deadline fired instead")
			}
			break // EOF or reset: the force-close landed client-side
		}
	}
	if !sawUpgradeBytes {
		t.Fatal("the 101 response never reached the client — upgrade path broken through the wrapper")
	}
	res, err := http.Post(srv.URL+"/", "text/plain", strings.NewReader("x"))
	if err != nil {
		t.Fatalf("request during drain: %v", err)
	}
	res.Body.Close()
	if res.StatusCode != http.StatusServiceUnavailable {
		t.Fatalf("request during drain = %d, want 503 (admission shutter)", res.StatusCode)
	}

	// The handler saw the force-close too; its completion is parked.
	select {
	case <-closedRead:
	case <-time.After(5 * time.Second):
		t.Fatal("handler never observed the force-close")
	}
	idle := make(chan struct{})
	go func() {
		tr.waitIdle()
		close(idle)
	}()
	select {
	case <-idle:
		t.Fatal("waitIdle returned while a completion was parked at the seam")
	case <-time.After(300 * time.Millisecond):
	}
	close(gate)
	select {
	case <-idle:
	case <-time.After(5 * time.Second):
		t.Fatal("waitIdle did not return after the seam release")
	}
}

// TestTrackingResponseWriterDeadlinePassThrough proves the wrapper does
// not break http.ResponseController: identity's strict body decoder sets
// its network deadline through ResponseController.SetReadDeadline, which
// must traverse Unwrap and land on the real writer.
type deadlineRecorder struct {
	http.ResponseWriter
	readDeadline time.Time
}

func (d *deadlineRecorder) SetReadDeadline(t time.Time) error {
	d.readDeadline = t
	return nil
}

func TestTrackingResponseWriterDeadlinePassThrough(t *testing.T) {
	inner := &deadlineRecorder{}
	w := &trackingResponseWriter{ResponseWriter: inner, tracker: newHandlerTracker()}
	if err := http.NewResponseController(w).SetReadDeadline(time.Unix(123, 0)); err != nil {
		t.Fatalf("ResponseController through the wrapper: %v", err)
	}
	if inner.readDeadline.IsZero() {
		t.Fatal("the deadline never reached the real writer — Unwrap is broken (identity body deadline would silently vanish behind the tracker)")
	}
}

// --- bounded drain: spent Shutdown bound, force-close, bounded final join --------

// stalledChallengeConn opens a plain-TCP challenge request whose declared
// body never arrives: the handler parks in the identity strict decode (the
// production 15s network deadline wired through run's buildRegistry). The
// request is CANONICAL — valid JSON, valid device id — so only the
// definitive-end discipline can be what holds it, never field validation.
func stalledChallengeConn(t *testing.T, base, bearer, deviceID string) net.Conn {
	t.Helper()
	hostPort := strings.TrimPrefix(base, "http://")
	conn, err := net.DialTimeout("tcp", hostPort, 2*time.Second)
	if err != nil {
		t.Fatalf("stalled challenge dial: %v", err)
	}
	head := fmt.Sprintf("POST /identity/v1/challenge HTTP/1.1\r\n"+
		"Host: %s\r\nAuthorization: Bearer %s\r\n"+
		"Content-Type: application/json\r\nContent-Length: 512\r\n\r\n", hostPort, bearer)
	if _, err := conn.Write([]byte(head + fmt.Sprintf(`{"device_id":%q}`, deviceID))); err != nil {
		t.Fatalf("stalled challenge write: %v", err)
	}
	return conn
}

// TestRunDrainDeadlineForceClosesBlockedHandlerAndReturnsError is the
// spent-Shutdown-bound regression the corrections demand: a NON-hijacked
// handler parked on a client that never finishes its body (the class
// beginDrain does not close and http.Server.Shutdown waits for) must not
// let run outlive the drain budget. With the service Shutdown bound
// shortened by the timing seam (500ms — far inside the 15s identity body
// deadline and the 60s server ReadTimeout, so ONLY the drain's force-close
// can unblock the handler on this side of them), proven in order:
//
//  1. the spent bound is force-closed — the client observes a GENUINE
//     connection close (a timeout-class read is a FAILURE: it would mean
//     the conn survived and only our own deadline fired);
//  2. run returns the EXPLICIT deadline error within a bounded window —
//     the old shape (record the error, then wait forever on the blocked
//     handler) never returns and fails this bound;
//  3. the tracked handler was actually joined (not orphaned) and the port
//     is closed.
//
// Normal SIGTERM behavior is untouched: on a healthy drain Shutdown never
// spends its bound, so no force-close ever fires (covered by the
// SIGTERM-return-nil regressions).
func TestRunDrainDeadlineForceClosesBlockedHandlerAndReturnsError(t *testing.T) {
	useTempRegistryBase(t)
	b := newTestBroker(t)
	addr := freeAddr(t)
	cfg := lifecycleConfig(t, b, addr)
	tr := newHandlerTracker()
	cfg.newTracker = func() *handlerTracker { return tr }
	cfg.serviceDrain = 500 * time.Millisecond

	token := b.sign(t, b.validClaims())
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- run(ctx, cfg) }()
	base := "http://" + addr
	waitHealthz(t, base)

	conn := stalledChallengeConn(t, base, token, "stall-drain")
	defer conn.Close()

	// The handler is in flight and tracked before the signal: the drain
	// deadline below is spent waiting on IT.
	deadline := time.Now().Add(5 * time.Second)
	for {
		tr.mu.Lock()
		n := tr.inFlight
		tr.mu.Unlock()
		if n >= 1 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("stalled handler never became tracked in-flight")
		}
		time.Sleep(20 * time.Millisecond)
	}

	cancel() // SIGTERM equivalent
	deadline0 := time.Now()

	// 1. The spent bound force-closes the ordinary connection.
	if err := conn.SetReadDeadline(time.Now().Add(5 * time.Second)); err != nil {
		t.Fatal(err)
	}
	buf := make([]byte, 512)
	var collected []byte
	for {
		n, err := conn.Read(buf)
		collected = append(collected, buf[:n]...)
		if err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				t.Fatalf("stalled handler's connection still open 5s after the signal — the drain deadline force-close never landed (read deadline fired, error %v)", err)
			}
			t.Logf("conn force-closed %v after signal, observed client-side as: %v, received: %q", time.Since(deadline0), err, collected)
			break // EOF/reset: the force-close reached the client
		}
	}

	// 2. run returns the explicit deadline error, bounded.
	select {
	case err := <-runErr:
		if err == nil {
			t.Fatal("a drain that spent its Shutdown bound was reported as success")
		}
		t.Logf("run returned: %v", err)
		if !strings.Contains(err.Error(), "service drain") {
			t.Fatalf("error does not identify the spent drain bound: %v", err)
		}
	case <-time.After(10 * time.Second):
		t.Fatal("run did not return after the drain deadline + bounded join — the old shape waits forever on a blocked non-hijacked handler")
	}

	// 3. The tracked handler was joined, and the port is closed.
	if n := tr.inFlightCount(); n != 0 {
		t.Fatalf("%d tracked handler(s) still live after run returned", n)
	}
	addrRefused(t, addr)
}

// TestRunDrainJoinBoundReportsIncompleteNotSuccess pins the bounded final
// join: with a tracked completion parked at the deterministic doneGate seam
// (a handler that CANNOT finish), run must give up at the explicit join
// bound and record the incomplete join as its error — never wait forever
// for it, and never report the drain as success. The old unbounded join
// never returns while the gate is held and fails the bound below. Releasing
// the gate afterwards leaves nothing parked behind.
func TestRunDrainJoinBoundReportsIncompleteNotSuccess(t *testing.T) {
	useTempRegistryBase(t)
	b := newTestBroker(t)
	addr := freeAddr(t)
	cfg := lifecycleConfig(t, b, addr)
	tr := newHandlerTracker()
	cfg.newTracker = func() *handlerTracker { return tr }
	cfg.handlerJoin = 800 * time.Millisecond

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- run(ctx, cfg) }()
	base := "http://" + addr
	waitHealthz(t, base)

	// A pre-auth client WebSocket: upgraded, tracked, parked before its
	// first auth frame — the drain force-closes it at the shutter, its
	// handler exits, and its completion parks at the seam below.
	ws := dialPreAuthClient(t, base, "laptop-1")

	gate := make(chan struct{})
	tr.armDoneGate(gate)

	cancel() // SIGTERM equivalent

	// The drain genuinely closed the pre-auth socket (non-timeout close).
	expectGenuineWSClose(t, ws, "pre-auth client ws")

	// The completion is parked and cannot finish: run must STILL return,
	// at the explicit join bound, with a non-nil error identifying the
	// incomplete join.
	select {
	case err := <-runErr:
		if err == nil {
			t.Fatal("run reported a complete drain while a tracked completion was parked and unable to finish")
		}
		if !strings.Contains(err.Error(), "handler join") {
			t.Fatalf("error does not identify the bounded join: %v", err)
		}
	case <-time.After(10 * time.Second):
		t.Fatal("run did not return at the join bound — the final join waited forever on a completion that cannot finish")
	}

	// Release the parked completion so the test leaves nothing behind.
	close(gate)
}

// --- P1: service + ACME coordinated shutdown (production topology) --------------

func TestRunLifecycleProductionShutsDownServiceAndACME(t *testing.T) {
	useTempRegistryBase(t)
	b := newTestBroker(t)
	ca := newFixtureCA(t)
	const domain = "lifecycle.test"
	serviceAddr, acmeAddr := freeAddr(t), freeAddr(t)

	// Offline autocert cache: a fixture-CA-signed cert in DirCache format
	// so GetCertificate serves the TLS listener without any ACME network —
	// and the test client verifies the chain for real.
	certDir := t.TempDir()
	if err := os.MkdirAll(filepath.Join(certDir, "certs"), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(certDir, "certs", domain), ca.leafCertPEM(t, domain), 0o600); err != nil {
		t.Fatal(err)
	}

	cfg := runtimeConfig{
		domain:   domain,
		listen:   serviceAddr,
		acmeAddr: acmeAddr,
		certDir:  certDir,
		origins:  parseOrigins("https://app.pocketshell.io"),
		clientID: "unused",
		allow:    []string{"ops@example.com"},
		registry: filepath.Join(registryBaseDir, "registry.json"),
		broker: brokerConfig{
			issuer:   b.issuer,
			jwksURL:  b.jwksURL,
			audience: routingauth.Audience,
			allow:    []string{"ops@example.com"},
			client:   b.tlsClient,
		},
	}

	ctx, cancel := context.WithCancel(context.Background())
	runErr := make(chan error, 1)
	go func() { runErr <- run(ctx, cfg) }()

	// The service port speaks TLS with the cached certificate, verified
	// against the fixture CA (never bypassed); the ACME port serves
	// healthz; the full new API answers through the TLS mux.
	tlsClient := tlsHealthzClient(ca, domain)
	deadline := time.Now().Add(10 * time.Second)
	for {
		conn, err := tls.DialWithDialer(&net.Dialer{Timeout: 2 * time.Second}, "tcp", serviceAddr, ca.clientConfig(domain))
		if err == nil {
			conn.Close()
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("TLS service never came up: %v", err)
		}
		time.Sleep(25 * time.Millisecond)
	}
	waitFor := func(url string, client *http.Client) {
		t.Helper()
		d := time.Now().Add(10 * time.Second)
		for time.Now().Before(d) {
			res, err := client.Get(url)
			if err == nil {
				res.Body.Close()
				if res.StatusCode == http.StatusOK {
					return
				}
			}
			time.Sleep(25 * time.Millisecond)
		}
		t.Fatalf("%s never answered 200", url)
	}
	waitFor("http://"+acmeAddr+"/healthz", &http.Client{Timeout: 5 * time.Second})
	waitFor("https://"+serviceAddr+"/healthz", tlsClient)
	res, err := tlsClient.Get("https://" + serviceAddr + "/healthz")
	if err != nil {
		t.Fatal(err)
	}
	var h map[string]string
	if err := json.NewDecoder(res.Body).Decode(&h); err != nil {
		t.Fatal(err)
	}
	res.Body.Close()
	if h["registry"] != "enabled" || h["tunnel"] != "enabled" {
		t.Fatalf("healthz posture = %+v, want registry=enabled tunnel=enabled", h)
	}

	// SIGTERM equivalent: BOTH servers must drain and run must return nil
	// (the old code: the ACME goroutine log.Fatal'ed its own ErrServerClosed
	// and exited the whole process; the service Serve fatal'ed mid-drain).
	cancel()
	select {
	case err := <-runErr:
		if err != nil {
			t.Fatalf("coordinated shutdown returned an error: %v", err)
		}
	case <-time.After(15 * time.Second):
		t.Fatal("run did not return after the coordinated shutdown")
	}
	addrRefused(t, serviceAddr)
	addrRefused(t, acmeAddr)
}

// --- P1: in-Serve failures surface as errors, after a coordinated drain ---------

// recordingBinder is the listener factory seam: real net.Listen, with every
// produced listener remembered by address so the tests can die mid-Serve.
type recordingBinder struct {
	mu        sync.Mutex
	listeners map[string]net.Listener
}

func newRecordingBinder() *recordingBinder {
	return &recordingBinder{listeners: map[string]net.Listener{}}
}

func (r *recordingBinder) bind(network, addr string) (net.Listener, error) {
	l, err := net.Listen(network, addr)
	if err != nil {
		return nil, err
	}
	r.mu.Lock()
	r.listeners[addr] = l
	r.mu.Unlock()
	return l, nil
}

func (r *recordingBinder) get(addr string) net.Listener {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.listeners[addr]
}

func TestRunLifecycleInServeFailureIsSurfacedAfterDrain(t *testing.T) {
	// The ACME goroutine is the sharpest P1 case: its server failing used
	// to os.Exit the whole process from inside the goroutine. Now the
	// failure must (a) surface as run's error, (b) drain the service
	// server first — no abrupt exit.
	ca := newFixtureCA(t)
	t.Run("acme-server-failure", func(t *testing.T) {
		useTempRegistryBase(t)
		b := newTestBroker(t)
		const domain = "lifecycle.test"
		serviceAddr, acmeAddr := freeAddr(t), freeAddr(t)
		certDir := t.TempDir()
		if err := os.MkdirAll(filepath.Join(certDir, "certs"), 0o700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(certDir, "certs", domain), ca.leafCertPEM(t, domain), 0o600); err != nil {
			t.Fatal(err)
		}
		cfg := lifecycleConfig(t, b, serviceAddr)
		cfg.domain = domain
		cfg.acmeAddr = acmeAddr
		cfg.certDir = certDir
		binder := newRecordingBinder()
		cfg.newListener = binder.bind

		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		runErr := make(chan error, 1)
		go func() { runErr <- run(ctx, cfg) }()
		waitHealthz(t, "http://"+acmeAddr)
		waitHealthzClient(t, tlsHealthzClient(ca, domain), "https://"+serviceAddr)

		// REAL in-Serve failure: the ACME listener dies while Serve is
		// running on it.
		if err := binder.get(acmeAddr).Close(); err != nil {
			t.Fatal(err)
		}

		select {
		case err := <-runErr:
			if err == nil {
				t.Fatal("in-Serve ACME failure surfaced as a clean shutdown")
			}
			if !strings.Contains(err.Error(), "acme challenge server") {
				t.Fatalf("error does not identify the failing server: %v", err)
			}
		case <-time.After(15 * time.Second):
			t.Fatal("run did not surface the in-Serve ACME failure")
		}
		// The coordinated drain shut the service server down too — the
		// failure never aborted the lifecycle abruptly.
		addrRefused(t, serviceAddr)
		addrRefused(t, acmeAddr)
	})

	// Symmetric case: the SERVICE server dies mid-Serve; the ACME server
	// must be drained and the error surfaced.
	t.Run("service-server-failure", func(t *testing.T) {
		useTempRegistryBase(t)
		b := newTestBroker(t)
		const domain = "lifecycle.test"
		serviceAddr, acmeAddr := freeAddr(t), freeAddr(t)
		certDir := t.TempDir()
		if err := os.MkdirAll(filepath.Join(certDir, "certs"), 0o700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(certDir, "certs", domain), ca.leafCertPEM(t, domain), 0o600); err != nil {
			t.Fatal(err)
		}
		cfg := lifecycleConfig(t, b, serviceAddr)
		cfg.domain = domain
		cfg.acmeAddr = acmeAddr
		cfg.certDir = certDir
		binder := newRecordingBinder()
		cfg.newListener = binder.bind

		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		runErr := make(chan error, 1)
		go func() { runErr <- run(ctx, cfg) }()
		waitHealthz(t, "http://"+acmeAddr)
		waitHealthzClient(t, tlsHealthzClient(ca, domain), "https://"+serviceAddr)

		if err := binder.get(serviceAddr).Close(); err != nil {
			t.Fatal(err)
		}

		select {
		case err := <-runErr:
			if err == nil {
				t.Fatal("in-Serve service failure surfaced as a clean shutdown")
			}
			if !strings.Contains(err.Error(), "service server") {
				t.Fatalf("error does not identify the failing server: %v", err)
			}
		case <-time.After(15 * time.Second):
			t.Fatal("run did not surface the in-Serve service failure")
		}
		addrRefused(t, serviceAddr)
		addrRefused(t, acmeAddr)
	})
}

func TestRunLifecycleStartupErrorsSurfaced(t *testing.T) {
	useTempRegistryBase(t)
	b := newTestBroker(t)

	// A held service port: run must return the bind error.
	held, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer held.Close()
	cfg := lifecycleConfig(t, b, held.Addr().String())
	if err := run(context.Background(), cfg); err == nil {
		t.Fatal("bind conflict accepted — startup errors must surface")
	}

	// An ACME bind conflict after the service port bound: the error is
	// returned AND the service port is not leaked (re-bindable).
	acmeHeld, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer acmeHeld.Close()
	cfg = lifecycleConfig(t, b, freeAddr(t))
	cfg.domain = "lifecycle.test"
	cfg.acmeAddr = acmeHeld.Addr().String()
	cfg.certDir = t.TempDir()
	if err := run(context.Background(), cfg); err == nil {
		t.Fatal("ACME bind conflict accepted")
	}
	probe, err := net.Listen("tcp", cfg.listen)
	if err != nil {
		t.Fatalf("failed lifecycle leaked the service port: %v", err)
	}
	probe.Close()

	// A verifier-refused broker config fails closed at the entrypoint.
	cfg = lifecycleConfig(t, b, freeAddr(t))
	cfg.broker.jwksURL = "http://127.0.0.1:1/gateway/jwks"
	cfg.broker.client = nil
	cfg.broker.insecureDev = false
	if err := run(context.Background(), cfg); err == nil {
		t.Fatal("refused broker verifier accepted at the lifecycle entrypoint")
	}
}

// --- P1: the real binary, as an actual process ----------------------------------

// buildLifecycleBinary builds the real gateway binary for the subprocess
// regressions (signal/exit-code semantics cannot be proven in-process).
func buildLifecycleBinary(t *testing.T) string {
	t.Helper()
	if testing.Short() {
		t.Skip("binary build skipped in -short mode")
	}
	bin := filepath.Join(t.TempDir(), "pocketshell-gateway-lifecycle")
	cmd := exec.Command(testtoolchain.Go(t), "build", "-o", bin, ".")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build: %v\n%s", err, out)
	}
	return bin
}

// buildLifecycleBinaryWithRegistryBase builds the real binary with the
// registry state root pointed at a per-test directory — the same package
// var useTempRegistryBase repoints in-process, injected here via -ldflags
// so the SUBPROCESS accepts -registry under it too. Production binaries
// keep the /var/lib default; the injection exists only in this test-built
// artifact.
func buildLifecycleBinaryWithRegistryBase(t *testing.T) (bin, registryBase string) {
	t.Helper()
	if testing.Short() {
		t.Skip("binary build skipped in -short mode")
	}
	registryBase = filepath.Join(t.TempDir(), "registry-root")
	if err := os.MkdirAll(registryBase, 0o700); err != nil {
		t.Fatal(err)
	}
	bin = filepath.Join(t.TempDir(), "pocketshell-gateway-lifecycle")
	cmd := exec.Command(testtoolchain.Go(t), "build", "-o", bin,
		"-ldflags", "-X main.registryBaseDir="+registryBase, ".")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build: %v\n%s", err, out)
	}
	return bin, registryBase
}

// TestMainProcessSigtermDrainsRealAuthenticatedSSH is the upgraded process
// gate: the REAL binary runs the full production wiring (registry +
// tunnel, scoped broker credentials over routingauth's explicit dev
// transport opt-in — plain-HTTP fixture JWKS; token verification stays
// fully on), and the session held across SIGTERM is a REAL, AUTHENTICATED
// SSH session over an INDEPENDENTLY pinned host key — not a banner
// exchange. (The lab sshd's 5s LoginGraceTime cannot fake this: the
// session is fully authenticated, past the pre-auth grace window, and its
// death is proven on the SERVER side.) Asserted, all BEFORE the parent's
// deferred cleanup (process kill, sshd close):
//
//  1. the SSH client's termination is genuine — a timeout-class error
//     (our own deadline, not the drain) is a FAILURE;
//  2. the lab sshd's own counters prove the backend connection closed;
//  3. the process exits 0 — the P1 gate (the old code exited 1 mid-drain).
func TestMainProcessSigtermDrainsRealAuthenticatedSSH(t *testing.T) {
	bin, registryBase := buildLifecycleBinaryWithRegistryBase(t)
	b := newPlainTestBroker(t)

	addr := freeAddr(t)
	cmd := exec.Command(bin, "-listen", addr,
		"-registry", filepath.Join(registryBase, "registry.json"),
		"-broker-issuer", b.issuer,
		"-broker-jwks", b.jwksURL,
		"-broker-allow-insecure-dev",
		"-allow", "ops@example.com",
		"-origins=")
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if cmd.Process != nil {
			_ = cmd.Process.Kill()
			_, _ = cmd.Process.Wait()
		}
	})
	base := "http://" + addr
	waitHealthz(t, base)
	posture := func() map[string]string {
		t.Helper()
		res, err := (&http.Client{Timeout: 5 * time.Second}).Get(base + "/healthz")
		if err != nil {
			t.Fatal(err)
		}
		defer res.Body.Close()
		var h map[string]string
		if err := json.NewDecoder(res.Body).Decode(&h); err != nil {
			t.Fatal(err)
		}
		return h
	}
	if h := posture(); h["registry"] != "enabled" || h["tunnel"] != "enabled" {
		t.Fatalf("subprocess posture = %+v, want registry=enabled tunnel=enabled\n%s", h, out.String())
	}

	// REAL authenticated SSH topology through the subprocess: enrollment
	// with a signed broker JWT, real host agent, real client session, real
	// SSH handshake against the independent pin.
	token := b.sign(t, b.validClaims())
	w := newLabSSHWorld(t, base, token)
	ws, ready := waitClientSSH(t, base, w.deviceID, token)
	if !samePin(ready.SSHHostKey, w.pinLine) {
		t.Fatalf("ready advisory %q does not match the pinned endpoint", ready.SSHHostKey)
	}
	cl := realSSHSession(t, ws, w.pinLine, w.clientKey.Signer)
	closedBefore := w.sshd.Stats().ClosedConns

	// SIGTERM: the authenticated session must die of the drain — never of
	// a local timeout — and the backend must observe the close, both
	// before the parent cleans anything up.
	start := time.Now()
	if err := cmd.Process.Signal(syscall.SIGTERM); err != nil {
		t.Fatal(err)
	}
	expectSSHClientTeardown(t, cl, "subprocess SIGTERM")
	requireBackendClosed(t, w.sshd, closedBefore, "subprocess SIGTERM")

	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	select {
	case err := <-done:
		if err != nil {
			t.Fatalf("SIGTERM shutdown exited non-zero (mid-drain abort): %v\n%s", err, out.String())
		}
	case <-time.After(20 * time.Second):
		t.Fatalf("process did not exit after SIGTERM\n%s", out.String())
	}
	if elapsed := time.Since(start); elapsed > 15*time.Second {
		t.Fatalf("shutdown took %s", elapsed)
	}
}

// TestMainProcessSigtermDrainsLegacyHijackedSession keeps the LEGACY
// proxy's hijack covered at the process level (the upgraded test above
// covers the tunnel path): a real hijacked WebSocket carrying real SSH
// bytes from the lab sshd's version exchange. Tightened per the
// corrections: liveness is re-proven immediately before the signal (the
// lab's 5s LoginGraceTime must not be what closes the session), the
// client-side termination must be a genuine close (timeout-class errors
// fail), and the sshd's own counters prove the backend leg closed — all
// before the parent's deferred cleanup — and the process still exits 0.
func TestMainProcessSigtermDrainsLegacyHijackedSession(t *testing.T) {
	bin := buildLifecycleBinary(t)
	useTempRegistryBase(t)

	hostKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	sshd, err := sshlab.StartSSHD(hostKey.Signer)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(sshd.Close)

	addr := freeAddr(t)
	cmd := exec.Command(bin, "-listen", addr,
		"-dev-allow-any-token", "-dev-allow-private-hosts", "-origins=")
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	if err := cmd.Start(); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if cmd.Process != nil {
			_ = cmd.Process.Kill()
			_, _ = cmd.Process.Wait()
		}
	})
	waitHealthz(t, "http://"+addr)

	// Active hijacked SSH session (legacy proxy → lab sshd) alive at the
	// moment of the signal.
	host, port, err := net.SplitHostPort(sshd.Addr())
	if err != nil {
		t.Fatal(err)
	}
	ws, _, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial(fmt.Sprintf("ws://%s/?host=%s&port=%s&token=dev", addr, host, port), nil)
	if err != nil {
		t.Fatalf("legacy dial: %v", err)
	}
	defer ws.Close()
	banner := legacyExchange(t, ws, "SSH-2.0-lifecycle-process\r\n")
	if !strings.HasPrefix(banner, "SSH-2.0-") {
		t.Fatalf("banner %q", banner)
	}
	closedBefore := sshd.Stats().ClosedConns

	// Liveness immediately before the signal: the session is open NOW, so
	// whatever closes it below is the drain, not LoginGraceTime.
	ws.SetWriteDeadline(time.Now().Add(2 * time.Second))
	if err := ws.WriteMessage(websocket.BinaryMessage, []byte("still-here")); err != nil {
		t.Fatalf("session not alive immediately before SIGTERM: %v", err)
	}

	// SIGTERM: the drain must complete and the process must exit 0. This
	// is the P1 gate — the old code log.Fatal'ed Serve's ErrServerClosed
	// and exited 1 mid-drain on this exact path.
	start := time.Now()
	if err := cmd.Process.Signal(syscall.SIGTERM); err != nil {
		t.Fatal(err)
	}
	expectGenuineWSClose(t, ws, "legacy hijacked session")
	requireBackendClosed(t, sshd, closedBefore, "legacy SIGTERM")
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	select {
	case err := <-done:
		if err != nil {
			t.Fatalf("SIGTERM shutdown exited non-zero (mid-drain abort): %v\n%s", err, out.String())
		}
	case <-time.After(20 * time.Second):
		t.Fatalf("process did not exit after SIGTERM\n%s", out.String())
	}
	if elapsed := time.Since(start); elapsed > 15*time.Second {
		t.Fatalf("shutdown took %s", elapsed)
	}
	if !strings.Contains(out.String(), "pocketshell relay (DEV") {
		t.Fatalf("unexpected process output: %s", out.String())
	}
}

func TestMainProcessBindFailureExitsNonZero(t *testing.T) {
	if testing.Short() {
		t.Skip("binary build skipped in -short mode")
	}
	bin := filepath.Join(t.TempDir(), "pocketshell-gateway-lifecycle-bind")
	cmd := exec.Command(testtoolchain.Go(t), "build", "-o", bin, ".")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build: %v\n%s", err, out)
	}

	held, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer held.Close()
	run := exec.Command(bin, "-listen", held.Addr().String(),
		"-dev-allow-any-token", "-dev-allow-private-hosts")
	var out bytes.Buffer
	run.Stdout = &out
	run.Stderr = &out
	if err := run.Start(); err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	go func() { done <- run.Wait() }()
	select {
	case err := <-done:
		var exitErr *exec.ExitError
		if err == nil || !(func() bool { exitErr, _ = err.(*exec.ExitError); return exitErr != nil }()) {
			t.Fatalf("bind conflict did not exit non-zero: err=%v", err)
		}
		if !strings.Contains(out.String(), "bind") {
			t.Fatalf("bind error not surfaced: %s", out.String())
		}
	case <-time.After(15 * time.Second):
		t.Fatalf("process hung on a refused bind\n%s", out.String())
	}
}
