package main

// Passive presence through the PRODUCTION wiring: the real identity HTTP
// handler, the real tunnel service, the root presence adapter and the real
// hostagent session loop. Presence must follow the actual ready host-agent
// state — not the durable enrollment record — and stay account-scoped.

import (
	"context"
	"crypto/ed25519"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// twoAccountVerifier maps two bearer tokens to two distinct accounts.
type twoAccountVerifier struct{}

func (twoAccountVerifier) VerifyToken(_ context.Context, token string) (identity.Principal, error) {
	switch token {
	case "alice-bearer":
		return identity.Principal{AccountID: "google:alice-sub", Email: "a@example.com", ExpiresAt: time.Now().Add(5 * time.Minute)}, nil
	case "bob-bearer":
		return identity.Principal{AccountID: "google:bob-sub", Email: "b@example.com", ExpiresAt: time.Now().Add(5 * time.Minute)}, nil
	}
	return identity.Principal{}, errors.New("bad token")
}

type wiredPresence struct {
	Online            bool   `json:"online"`
	ObservedAt        string `json:"observed_at"`
	ConnectedSince    string `json:"connected_since"`
	SessionGeneration uint64 `json:"session_generation"`
}

type wiredDevice struct {
	ID       string         `json:"id"`
	Revoked  bool           `json:"revoked"`
	Presence *wiredPresence `json:"presence"`
}

func listWired(t *testing.T, base, token string) map[string]wiredDevice {
	t.Helper()
	req, err := http.NewRequest(http.MethodGet, base+"/identity/v1/devices", nil)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Authorization", "Bearer "+token)
	res, err := (&http.Client{Timeout: 5 * time.Second}).Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	raw, _ := io.ReadAll(res.Body)
	if res.StatusCode != http.StatusOK {
		t.Fatalf("list: HTTP %d: %s", res.StatusCode, raw)
	}
	if res.Header.Get("Cache-Control") != "no-store" {
		t.Fatal("presence list must not be cacheable")
	}
	var out struct {
		Devices []wiredDevice `json:"devices"`
	}
	if err := json.Unmarshal(raw, &out); err != nil {
		t.Fatal(err)
	}
	m := map[string]wiredDevice{}
	for _, d := range out.Devices {
		if d.Presence == nil {
			t.Fatalf("wired gateway listed %s without presence: %s", d.ID, raw)
		}
		if _, err := time.Parse(time.RFC3339, d.Presence.ObservedAt); err != nil {
			t.Fatalf("observed_at %q not RFC 3339: %v", d.Presence.ObservedAt, err)
		}
		m[d.ID] = d
	}
	return m
}

func waitWired(t *testing.T, base, token, id string, ok func(wiredDevice) bool, what string) wiredDevice {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for {
		d := listWired(t, base, token)[id]
		if ok(d) {
			return d
		}
		if time.Now().After(deadline) {
			t.Fatalf("%s: last %+v presence=%+v", what, d, d.Presence)
		}
		time.Sleep(20 * time.Millisecond)
	}
}

func TestDevicePresenceThroughProductionWiring(t *testing.T) {
	oldRegistry, oldTunnel := registryPosture, tunnelPosture
	t.Cleanup(func() { registryPosture, tunnelPosture = oldRegistry, oldTunnel })
	idSvc := buildRegistryWith(identity.Config{
		Verifier:            twoAccountVerifier{},
		StorePath:           filepath.Join(t.TempDir(), "registry.json"),
		RequestReadDeadline: testIdentityReadDeadline,
		Logger:              func(string, ...any) {},
	})
	if idSvc == nil {
		t.Fatal("registry not constructed")
	}
	tunSvc := buildTunnel(idSvc, nil, tunnel.Limits{MaxHosts: 4, MaxClientsGlobal: 4, MaxClientsPerAccount: 2, MaxStreamsPerHost: 2})
	if tunSvc == nil {
		t.Fatal("tunnel not constructed")
	}
	t.Cleanup(tunSvc.Close)
	api := &newAPI{identitySvc: idSvc, tunnelSvc: tunSvc}
	s := httptest.NewServer(newHandler(testRelay(), api))
	defer s.Close()

	aliceKey := ed25519.NewKeyFromSeed([]byte("presence alice seed 32 bytes!!!!"))
	bobKey := ed25519.NewKeyFromSeed([]byte("presence bob seed 32 bytes!!!!!!"))
	enrollOverHTTP(t, s.URL, "alice-bearer", "alice-laptop", aliceKey, false)
	enrollOverHTTP(t, s.URL, "bob-bearer", "bob-laptop", bobKey, false)
	_, sshPort := echoListener(t)
	sshAddr := fmt.Sprintf("127.0.0.1:%d", sshPort)

	// Enrolled but never connected: registered and unrevoked, yet offline.
	d := listWired(t, s.URL, "alice-bearer")["alice-laptop"]
	if d.Revoked || d.Presence.Online || d.Presence.ConnectedSince != "" {
		t.Fatalf("never-connected device: %+v %+v", d, d.Presence)
	}

	// Bob's host connects; alice never sees it, and her device stays offline.
	stopBob, _ := startRealAgent(t, api, s.URL, "bob-laptop", bobKey, sshAddr)
	defer stopBob()
	alice := listWired(t, s.URL, "alice-bearer")
	if _, leaked := alice["bob-laptop"]; leaked || len(alice) != 1 || alice["alice-laptop"].Presence.Online {
		t.Fatalf("cross-account leak or wrong presence: %+v", alice)
	}
	if b := listWired(t, s.URL, "bob-bearer")["bob-laptop"]; !b.Presence.Online || b.Presence.SessionGeneration != 1 {
		t.Fatalf("bob's own connected host: %+v", b.Presence)
	}

	// Alice's real host agent connects; no client stream is ever opened.
	stopAlice, aliceDone := startRealAgent(t, api, s.URL, "alice-laptop", aliceKey, sshAddr)
	first := waitWired(t, s.URL, "alice-bearer", "alice-laptop", func(d wiredDevice) bool { return d.Presence.Online }, "alice online")
	if first.Presence.ConnectedSince == "" || first.Presence.SessionGeneration != 1 {
		t.Fatalf("first session presence: %+v", first.Presence)
	}
	since1, err := time.Parse(time.RFC3339, first.Presence.ConnectedSince)
	if err != nil {
		t.Fatal(err)
	}
	obs1, _ := time.Parse(time.RFC3339, first.Presence.ObservedAt)
	if obs1.Before(since1) {
		t.Fatalf("observed_at %v before connected_since %v", obs1, since1)
	}

	// Disconnect: the agent stops, presence goes offline.
	stopAlice()
	<-aliceDone
	waitWired(t, s.URL, "alice-bearer", "alice-laptop", func(d wiredDevice) bool { return !d.Presence.Online }, "alice offline after disconnect")

	// Reconnect: a NEW session (generation 2) with a later connected_since.
	time.Sleep(5 * time.Millisecond) // millisecond-precision timestamps must differ
	stopAlice2, _ := startRealAgent(t, api, s.URL, "alice-laptop", aliceKey, sshAddr)
	defer stopAlice2()
	second := waitWired(t, s.URL, "alice-bearer", "alice-laptop", func(d wiredDevice) bool {
		return d.Presence.Online && d.Presence.SessionGeneration == 2
	}, "alice new session")
	since2, err := time.Parse(time.RFC3339, second.Presence.ConnectedSince)
	if err != nil || !since2.After(since1) {
		t.Fatalf("new session connected_since %v must follow %v (%v)", since2, since1, err)
	}

	// Revocation over the REAL endpoint: offline immediately (no polling),
	// still listed as revoked.
	if code := revokeOverHTTP(t, s.URL, "alice-bearer", "alice-laptop"); code != http.StatusOK {
		t.Fatalf("revoke: HTTP %d", code)
	}
	r := listWired(t, s.URL, "alice-bearer")["alice-laptop"]
	if !r.Revoked || r.Presence.Online || r.Presence.ConnectedSince != "" {
		t.Fatalf("revoked device presence: %+v %+v", r, r.Presence)
	}
	// Bob is unaffected by alice's churn: still his first session.
	if b := listWired(t, s.URL, "bob-bearer")["bob-laptop"]; !b.Presence.Online || b.Presence.SessionGeneration != 1 {
		t.Fatalf("bob after alice churn: %+v", b.Presence)
	}
}

// Registry without a running tunnel: presence is absent (unknown), never
// a fabricated "offline".
func TestDevicePresenceAbsentWithoutTunnel(t *testing.T) {
	oldRegistry, oldTunnel := registryPosture, tunnelPosture
	t.Cleanup(func() { registryPosture, tunnelPosture = oldRegistry, oldTunnel })
	idSvc := buildRegistryWith(identity.Config{
		Verifier:            twoAccountVerifier{},
		StorePath:           filepath.Join(t.TempDir(), "registry.json"),
		RequestReadDeadline: testIdentityReadDeadline,
		Logger:              func(string, ...any) {},
	})
	s := httptest.NewServer(newHandler(testRelay(), &newAPI{identitySvc: idSvc}))
	defer s.Close()
	key := ed25519.NewKeyFromSeed([]byte("presence solo seed 32 bytes!!!!!"))
	enrollOverHTTP(t, s.URL, "alice-bearer", "solo", key, false)
	req, _ := http.NewRequest(http.MethodGet, s.URL+"/identity/v1/devices", nil)
	req.Header.Set("Authorization", "Bearer alice-bearer")
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	var out struct {
		Devices []map[string]json.RawMessage `json:"devices"`
	}
	if err := json.NewDecoder(res.Body).Decode(&out); err != nil {
		t.Fatal(err)
	}
	if len(out.Devices) != 1 {
		t.Fatalf("devices: %d", len(out.Devices))
	}
	if _, ok := out.Devices[0]["presence"]; ok {
		t.Fatal("presence reported without a tunnel")
	}
}
