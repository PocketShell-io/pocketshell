# Gateway coordination status, 2026-10-07

Implementation continues through isolated ZAI workers using the configured
`glm-5.3-flash` provider and the documented noninteractive zcy YOLO warm bridge.
The coordinator assigns ownership, preserves interrupted changes, integrates
reviewed commits and verifies receipts. Independent reviewers do not approve
changes merely because a worker reports passing tests.

Latest live operation: the user reopened AWS Gate, and the independently
reviewed broker source from merged PR80 was deployed successfully. Public
JWKS and authorizer-negative checks passed; preserved Google configuration,
exact key grants and the deny audit passed independent live review. Legitimate
Google sign-in/token issuance remains untested. Gateway rollout remains held
for installer, browser and Android acceptance; details and historical source
checkpoints follow below.

Broker operations documentation is now merged in
[aws-infra PR81](https://github.com/DataTalksClub/aws-infra/pull/81), merge
`c9a22c3d2c73ec9d1162ba183cb1917f58d4a620`, documenting the verified live
backend and the still-open legitimate Google and Go runtime acceptance gates.
One public JWKS key does not prove that the previous signing parameter is absent.

## Review checkpoint at 21:28 UTC

AWS STS confirms account817685572750 and the reopened sandbox role. No new
gateway rollout has occurred. Independently reviewed routing/fingerprint,
enrollment-body withholding and run rejection-channel fixes are integrated
as3f17dc4,bdf8767,bc66577. Coordinator combined verification
`go test -race -count=1 ./internal/hostagent ./internal/tunnel ./cmd/pocketshell-link`
passed with exit0 (61.092s,13.429s,324.920s respectively). The accepted
final-runtime marker remains absent until all CLI warning fields
are reviewed and integrated.

Fresh isolated ZAI repair turns own the remaining handshake type/server/role/
protocol diagnostics, Android original-value authority, and installer D21/D23
findings. Native restoration readback passed independent20/7/122 checks, but
the reviewer reproduced failed initial capture fabricating null and missing
records causing deletion; these must be corrected before leased packaged runs.
Installer stderr and stale-parent metadata repairs are accepted in source;
writable legacy ancestors, registry ownership normalization, systemd comment/
continuation parsing and descriptor identity evidence remain open.

Browser composition9b6832f passed427 unit checks and the real-sshd protocol
fixture, but its actual Go composition run remains pending the accepted runtime
marker. Production-flow fixture1ba8a83 has calibration evidence only; its
scratch final driver requires failure-status and targeted-cleanup corrections.
Capacity2e64326 and the browser/production-flow fixtures are under independent
review. A worker report's claimed root acceptance is not coordinator approval.

Desktop publish37686679698 failed before packaging in local-shell, filesystem,
agent-dialog mock and port-dialog tests. The preceding run shared several
failures. A separate ZAI checkout at exact desktop5e5b037 with corebf408907
owns diagnosis and repair; no gateway regression is established by these logs.

Subsequent independent fixture review requires browser header capture and
late-context custody corrections, exact origin enforcement and immutable Go
build binding. Production-flow review requires exact image/network ownership,
failure-safe driver cleanup and a composed work/cleanup budget. Capacity review
verified the existing69 assertions and324 numeric rows but withheld acceptance
for premature verdict, leader-loss containment and unregister-before-deletion.
Separate ZAI turns own those three fixture corrections; no new measurement or
production rollout is inferred. The earlier worker's root-acceptance claim is
unsupported and must be corrected. Seven explicitly scoped external repairs
are running; actual process identities and bridge activity were revalidated.

Read-only rollout prerequisite recheck confirms the repository remains private
with immutable owner327658728/repository1408222370 OIDC subject configuration.
IAM `GetRole` for `pocketshell-github-deploy` returns `NoSuchEntity`; one-time
bootstrap remains required. Instancei-0dee79146aceb4014 is running att4g.nano
and52.213.219.13, with IMDS tokens required, hop limit1, IPv6 metadata disabled.
These instance settings do not prove runtime-UID metadata isolation. Trusted
TLS `curl` to canonical `/healthz` fails with a TLS internal alert; canonical
TLS/runtime acceptance remains open. No role, document or instance mutation
was performed by this recheck.

Read-only SSM inventory92179c5f-1b47-4e03-98db-dea23f7d7719 and execution-
property check0724bf0a-8e9e-4094-96b8-d13850b463ea both returned success/0.
The host runs Amazon Linux2023,aarch64,kernel6.18.48,systemd252.23;
`ExecStartEx` exists with an empty flags field. ACL tools and runuser are
available; nft and iptables are absent. BPF filesystem presence does not
prove systemd address-deny efficacy, so actual post-install metadata probes
remain mandatory. Existing service is active under root and has no metadata
address deny. No service, package, file, firewall or device setting was changed.

Inventory reports MemTotal422376kB, MemAvailable286628kB and SwapTotal421884kB.
The512MiB Docker cap and earlier arithmetic headroom are local measurement
conditions, not this guest's measured usable-memory budget. Final ARM64 live
resource observation must account for the actual host; no capacity guarantee
is inferred from the current idle inventory. Full generated nonsecret SSM
receipts are retained in the coordination evidence directory.

Astra target review identified an additional classifier defect: the helper
accepts curl status28 before checking whether HTTP200/403 arrived. A000
HTTP status with timeout also cannot distinguish connection failure from a
connected server that never responded. A separate isolated ZAI turn owns
the helper and harmless injected-curl regressions; no live metadata request
was made. The initial brief was corrected before source edits, its owned
processes were stopped with verified identities, and original receipts were
preserved. Ambiguous timeouts must remain unproven. Integration must regenerate
the combined document and reverify helper identity after delivery review.

## Review checkpoint at 09:56 UTC

This checkpoint supersedes the older worker assignments below; earlier test
results remain evidence for their stated commits only.

- CLI `f79b57f` and `334680f` are integrated locally. Independent review
  accepted guarded development issuer/re-enrollment forwarding, refusal of
  blank or malformed server URLs and canonical/legacy production host aliases.
  Coordinator verification passed 74 focused tests, the full 1,051-test suite
  and Ruff on owned files. Helper distribution remains incomplete.
- Tunnel `71bc797` adds fatal rejection handling and negotiated stream windows.
  Astra found two residuals: challenge-capacity exhaustion still uses a terminal
  code, and an agent accepts an in-cap window above its own offer. A fresh ZAI
  correction turn owns both regressions and real helper version/JSON protocol
  metadata. FH-1/FH-2 remain open until reviewed and integrated; the root
  production security suite has not yet been rerun against this commit.
- Delivery `cd72b57` reports 139 installer checks, 28 deploy-API checks,
  174 source contracts, 11 workflow checks and a real reverse-Docker pass.
  Independent source review still finds five uncovered blockers: parsing real
  structured systemd properties; auditing helper paths before privileged writes;
  rejecting a blank/classic OIDC subject; explicit runtime broker-key/path
  denies; and removing successful missing-runtime skips. A fresh explicit ZAI
  turn owns all five. Current harness results do not close these findings.
- Web `d629cf6`, `f30b5bf` and `110b64d` repair gateway intent and broker
  exchange, but review found malformed/mismatched link payloads ignored before
  secret access, stale SSH keys selected for a link warning bridge, and expired
  enrollment tokens copied before the timer fires. ZAI owns explicit repair
  regressions. The reported 329-test/build pass still needs raw receipts and
  integration with the separately owned crypto files.
- Root lifecycle `8215432` remains unintegrated. Review found hijacked pending
  upgrades untracked during shutdown, local read deadlines that can create false
  teardown positives, duplicate rather than distinct stalled-body tests and a
  test-only TLS constructor. A fresh ZAI turn owns these exact corrections.
- Independent Android N4 verification passed 414 canonical tests and preserved
  production bytes through an isolated five-failure red / eighteen-pass green
  mutation check. A ZAI worker now adds exact visible packaged intent cases and
  a real direct-SSH positive. No Android commit or packaged acceptance is implied.
- Core `5fee24f` bounds polling, but late container startup and pending Docker
  exec cleanup remain under a fresh ZAI correction. Broker B5 evidence validation
  likewise remains open for finite input bounds, pre-update invocation duration,
  successful Lambda state, invocation authority inventory and clock-error proof.

Required followups use fresh explicit worker turns. Earlier successful queue
receipts did not establish that the inner warm worker read those instructions.

### Additional evidence at 10:18 UTC

CLI CI run 37603797555 passed on pushed `334680f`. Independent crypto checks
on `4c8360a` passed 34 shim tests, production build and Chromium lab: sixteen
result records included four real verified SSH positives, two ECDSA refusals
and one pin rejection. The lab uses production-bundled crypto through a test
entry, not the full application. PEM framing, structural checks and misleading
per-case assertions remain assigned to a fresh ZAI correction.

Broker vector changes are integrated as `b9f8017`; current runbook checkpoints
are `a6c07f7` and `c5da231`. Root routingauth race tests passed in 1.814s.
The committed `56d08cd` Node snapshot passed nine Lambda, sixteen template and
eight deploy-pair checks. Its token suite passed 24/25: the actual lifecycle
Go verifier/removal/mutation cross-check passed, but a missing-tool regression
discarded the explicitly configured checkout and assumed a developer sibling.
A fresh repair must prove all tests in an unrelated snapshot directory.
An earlier missing-vector-field failure was fixed by integrating the vector.
No token-suite pass is claimed for the root checkpoint yet.

Astra closed the four prior B5 source corrections but found that only the
observation clock was corrected. Opposite signed observation/decision offsets
can permit early retirement. A fresh ZAI turn must bound both clocks; live
retirement remains refused while inventory evidence is incomplete.

Native packaged intent fixtures are prepared and under independent source
review. Core cleanup has two final bookkeeping corrections: repeated stop
requests must preserve pending/failed outcomes, and the regression's outer
timeout must cover its complete cleanup budget. Neither is final approval.

The direct web SSH path keeps private keys in the browser; the Go gateway
receives a Google token on its legacy route and forwards opaque SSH bytes.
The separate legacy Lambda bridge receives SSH credentials. Keys used there
can be exposed by compromise of that bridge, including keys reused for a home
machine. New broker-only flows isolate Google sync authority from the Go
gateway; legacy Google-authenticated flows do not. Architecture wording that
claims application gates survive a fully compromised application must be
corrected: endpoint SSH authentication and independent host pins are the
remote-machine boundary, while gateway admission/SSRF gates protect an honest
implementation. The root wiring documentation owner retains that correction.

## Verified results and remaining work

- Identity correction `b6b12a3`, integrated as `12d09ae`, rejects unsupported
  opaque stores and enforces the typed admission contract. Astra's source review
  closed those two correction findings. Coordinator identity race tests passed
  in 16.572s on the integrated source. Custom AuthorizedStore implementations
  remain responsible for honoring their documented lock/admission contract.
- Production security tests were integrated as `6b4383e`. A coordinator run of
  P7/P10/P12/P13 failed in 42.458s because P7 reproduced **FH-1**: a revoked
  agent receives a text error before a close frame, loses the denial code and
  retries. Active SSH teardown itself succeeded. A dedicated ZAI tunnel worker
  owns fatal classification and its regression; the failure is not waived.
- **FH-2:** different agent/server stream windows can drop the host leg.
  The same tunnel worker owns bounded negotiation and real SSH transfer tests
  with unequal configurations. Defaults passing is insufficient evidence.
- Root wiring `bdd3756` uses shared routingauth, preserves Principal.ExpiresAt
  and adds listener/HTTP bounds. Review still requires coordinated shutdown
  instead of log.Fatal on ErrServerClosed, actual active-SSH uncertain-fsync
  coverage, distinct stalled-body tests and a shared production TLS constructor.
  A fresh ZAI lifecycle worker owns these corrections and current dependencies.
- Android default-shell correction passed 407 canonical tests in 59 files,
  typecheck and packaged fixture compilation. Review then found **N4**:
  changing the selected SSH key or refreshing away an account row clears the
  only gateway intent while retaining the host draft. A fresh ZAI worker owns
  persistent intent and regressions. Android changes remain uncommitted for
  independent review, visible packaged evidence and required PR CI. Packaged
  missing-key positive controls do not prove successful direct SSH connections.
- Core test `f2843bf` replaces the rejected probe with actual sshd CLOSE,
  channel-free and unknown-channel log ordering. Worker reports five focused
  Docker passes and the full 23-test tier; source review accepts the ordering.
  A fresh ZAI worker still must bound the poller's own Docker operations and
  cancellation, preserve cleanup budget and refresh stale receipts.
- Browser crypto `f918ed5` guards private signing and resolves pbkdf2 3.1.7.
  Its 21 shim tests and 16 hooked Node lab cases are supplemental evidence.
  They do not prove shipping Vite/browser alias behavior. A fresh ZAI worker
  owns actual build/browser acceptance and malformed-container review. Existing
  production connection KEX restrictions must be considered before describing
  a standalone Curve25519 shim failure as a shipping connection bug.
- Delivery timed out with its source preserved. Last completed installer
  receipt was 134 passes and four failures. A fresh ZAI continuation owns real
  systemd property parsing, helper provisioning/generated SSM bundle, rollback,
  metadata isolation, runtime IAM denies and same-commit deployment gating.
  The reverse-Docker wrapper must fail when prerequisites are absent; adapter
  fallbacks and successful skips cannot satisfy production acceptance.
- Broker rollout/drain and effective old/new signing-reference validation
  remain assigned to their ZAI lifecycle worker. Browser client corrections
  continue in their separate worktree. Neither is accepted by this status note.

## Verified GitHub OIDC identity

Read-only GitHub API verification at 08:25 UTC returned `use_default: true`,
`use_immutable_subject: true` and prefix
`repo:PocketShell-io@327658728/pocketshell-gateway@1408222370`.
The repository was verified private, with repository ID 1408222370 and owner
ID 327658728. The required AWS trust is exact audience `sts.amazonaws.com`
and subject:

```text
repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main
```

No environment suffix, wildcard or name-only fallback is authorized by this
verification. Bootstrap must not override this with a blank parameter.
[GitHub's immutable subject documentation](https://docs.github.com/en/actions/reference/security/oidc#immutable-subject-claims)
describes the immutable format; the live API response establishes this repo's
configuration. No GitHub OIDC settings were changed for this verification.

## Coordinator checks on wiring checkpoint `5a38c96`

The root wiring checkpoint was integrated for combined validation, with its
review corrections still assigned. `go test -race -count=1 -timeout=180s ./...`
returned failure: root 19.329s, CLI 48.837s, hostagent 2.746s, identity 20.963s,
routingauth 2.324s and tunnel 9.814s passed; security failed in 93.795s solely
on the known P7 revoked-agent retry regression. This is not a whole-suite pass.
`go vet ./...` passed. Linux ARM64 server and host-helper builds passed.

Govulncheck v1.8.0 scanned the checkpoint and Go 1.27.1: zero affected symbols
and zero imported-package findings. Its one required-module finding was
[GO-2026-5932](https://pkg.go.dev/vuln/GO-2026-5932), concerning unmaintained
`golang.org/x/crypto/openpgp`; this application does not import that package.
This scan does not establish absence of application-level security defects.

Independent Node checks on broker `a6efb1c` / infra `25bee8a` passed 57/57,
with zero skips and real Go verifier/mutation checks. Astra closed B6 and the
removed-key regression in source. B5 remains open: sampled tokens cannot prove
dormant old issuers stopped. A fresh ZAI worker owns a retirement bound based
on verified expected Lambda revision/configuration, routing inventory,
completion time and the maximum remaining pre-update invocation duration.

CLI review found that the Python wrapper forwards `--server` but omits the
Go helper's explicit development broker issuer and re-enrollment flags. Its
documented local Docker enrollment example therefore fails. A fresh ZAI CLI
worker owns guarded forwarding and corrected examples. Ordinary-user helper
installation, stable version/protocol metadata, supported platform artifacts
and helper checksums remain distribution work; private-source build instructions
are not a completed installable distribution.

## Production deployment

Production main remains gated. The existing service is still running; a new
gateway binary, broker routes, canonical trusted TLS and automatic deployment
have not been accepted or deployed. AWS authorization remains available to the
coordinator after source and CI gates pass. Actual root-positive/runtime-denied
metadata probes, IAM simulations, trusted TLS on both names, version/hash
verification and rollback evidence remain required.

External warm logs can remain quiet while work proceeds. A queue receipt is
only evidence that the outer thread queued a message, not that the inner agent
read it. Required supplemental corrections are preserved in named prompt files
and must be checked in resulting source or delivered in a fresh explicit turn.

### Additional coordination evidence at 10:55 UTC

ZAI completed tunnel corrections and real helper metadata in `1d2248e`:
capacity rejections recover, post-proof challenge failures remain terminal,
and replies above the agent's offered window refuse before mux allocation.
Its owned race tests pass. Independent source review and integration into the
root security suite remain pending. A separate ZAI task now owns the real
multi-key sshd negotiation mismatch and case-sensitive fingerprint comparison.

Read-only mux diagnosis identified an ACK/Open setup race in A5 and partial
frame loss from repeated one-millisecond reads in the RESET-flood harness.
It also found a separate product bound gap: every overflowing RESET enqueue
can start a teardown goroutine. ZAI owns the bounded cleanup fix and explicit
test barriers; queue, credit, teardown and liveness assertions must remain.

Broker `6117c95` counts separately attested observation and decision clock
errors. `ace5619` fixes the standalone prerequisite fixture. The worker reports
59 actual Node tests, including the Go verifier bridge, with zero skips;
independent archived-source verification and Astra review are pending.
Neither patch retires a signing key or verifies live clock/inventory evidence.

IAM `b35da54` installed one named signing-key read deny on
`phone-aws-sandbox-role`; its stateful offline harness and read-only live
simulations report preserved deployment grants and explicit family-read denies.
Independent verification is pending. Discovery reports other broad readers,
including scheduler deployment and two SSM-managed instance roles; these were
reported without mutating their policies. IAM administrators can remove denies.

Deployment activation is another required blocker. The registry argument is a
JSON file. The proposed trusted layout uses a root-owned
`/var/lib/pocketshell-relay` parent with service-owned `certs` and `registry`
children, and `registry/devices.json` initialized by Go. Installer audits must
permit only those exact writable leaves and preserve existing certificates and
registry state. The new release must require actual health fields `registry`
and `tunnel` to equal `enabled`, with the prior posture retained for rollback.
ZAI's explicit activation task follows the active five-finding installer repair.
No canonical TLS or new gateway service deployment has been accepted.

Trust-boundary documentation correction `48268ec` is complete in the wiring
worktree, pending independent review. Ordinary Go WebSocket SSH remains opaque;
the separate legacy Lambda bridge receives SSH credentials. Gateway compromise
permits management-token misuse and denial of service, while independent host
pins and endpoint authorized keys protect SSH access within their stated trust
assumptions. Root bounded shutdown, packaged native proofs, crypto classifier,
web enrollment/intent and core fixture cleanup repairs remain active ZAI tasks.

### Verified coordination update at 11:50 UTC

The integrated Go tree at `acd3b86` passed the full race suite:
`go test -race -count=1 -timeout240s ./...`, exit 0. This includes the
previous production revocation failure, lifecycle integration and bounded mux
cleanup. It does not establish that optional Docker cases executed; their
mandatory fixture receipts remain separate. Further probe, peer-error rendering
and mux regression corrections are still assigned to ZAI and require review.
Drain documentation `07780b6` was independently source-accepted and integrated:
clean exit requires successful joins; an error exit does not promise every
handler goroutine has terminated.

Core PR [35](https://github.com/PocketShell-io/pocketshell-core/pull/35) merged
as `4096fc569e207cb2b245e84b3a1a8acf2c30894b`, preserving the concurrent pager
and terminal changes. Independent combined verification passed 692 core tests,
141 UI tests, both typechecks and both builds; the main CI run passed. Consumer
pinning waits for the native fixture editor to finish, then requires fresh
packaged native evidence rather than acceptance of the earlier APK.

CLI `29a9fa7` independently passed 1139 full-suite tests, 162 serial gateway
tests and owned-file Ruff. An earlier concurrent focused run failed its global
`sleep 30` process scan; that failure is retained, and exact owned-child tracking
is required. Source review also found a bare relative pin could probe a PATH
binary while executing the cwd binary, non-JSON constants/deep nesting escaped
strict metadata handling, an extra post-EOF acceptance allowance, uncontained
corrupt WHEEL reads and misplaced installed-wheel test isolation. A fresh ZAI
worker owns all these repairs and the packaging/provenance documentation
qualifications. CLI publication is not yet accepted.

Archived broker `ace5619` independently passed all 59 Node tests with zero
skips, including the real root Go verifier bridge. Source review accepted the
dual-clock bound; live clock observations, inventory and signing-key retirement
remain unverified. IAM boundary script `f7f4b94` independently passed 87 tests,
including preflight drift rejection and preservation checks. The live phone
role's named read deny remains applied; five other broad readers and removable
administrator permissions prevent a claim of complete signing-key isolation.

ZAI remains responsible for deployment activation, native packaged fixture,
web secret selection/custody and clipboard expiry, shared crypto format guards,
SSH probe boundaries, peer-controlled error diagnostics and mux harness bounds.
Independent reviewers accept exact committed source and executed receipts.
The existing production service remains in place. New broker routes, canonical
trusted TLS, activated registry/tunnel, production CI/CD and rollback proofs are
still required before a readiness claim.

### Review and publication update at 12:25 UTC

Peer diagnostic repair `cdd92a4` passed independent source review and focused
race verification, then integrated as `1b64a70`. Root integrated focused race
checks passed for hostagent (5.269s) and real CLI (19.355s). An initial root
command used an invalid timeout flag and ran no selected tests; its failed
invocation log is retained separately. Gateway-controlled rejection messages
and fatal close reasons now escape terminal controls without changing raw
verdict classification. This is diagnostic output protection, not an SSH
key or shell-access claim.

Mux harness `6400f22` passed six independent focused race tests, but review
still found unbounded new timeout-origin writes and phase-one receives, a
cleanup join for an unstarted writer, and an unsupported parked-worker comment.
Fresh ZAI repairs are assigned; the root has not integrated that test-only
commit. Probe `604c615` fixes stopping before userauth, but a fresh turn must
include resolution within the same runtime budget and join/flush the actual
observed connections before zero-auth assertions. Worker Docker passes do not
close these source/oracle gaps.

Broker source and accepted IAM scripts are published in
[PR80](https://github.com/DataTalksClub/aws-infra/pull/80), head `ca13b96`.
Worker integration reran all59 broker checks and87 IAM checks successfully.
No workflow covers this backend path; absent checks are not failed checks.
Accepted Lambda/template/deployment source is unchanged. Independent review
found command defects in the new first-v1 rollout document, now assigned to
ZAI. The PR is unmerged and the broker remains undeployed.

Both native and desktop now reference published core `4096fc5`. Desktop's
91 focused guards, typecheck and build pass. Native's414 registered JS tests
and J1 wiring pass, but three marker-type boundary errors block typecheck and
fresh APK preparation; ZAI owns those corrections without dropping malformed
gateway intent. Native fixture corrections are a separate owner. A reviewed
six-path parity mapping repair makes conservative full-test selection explicit;
the current required JS/debug workflow does not run this legacy parity check.

The signing-key review distinguishes three ordinary workload readers from two
administrative readers. Existing RSA/SSM and gateway deny boundaries can serve
the scoped compromised-gateway v1 threat; broader workload isolation and legacy
key history remain limitations. Administrator policies are mutable. A dedicated
KMS encryption key with fresh RSA rotation is a separate possible improvement,
not an implemented guarantee or a required cryptographic redesign.

Independent installer execution at `7927880` timed out after600s with139
passing assertions and no reported failures; it did not complete160 assertions.
Known default-root audit, sticky-directory and systemd-prefix fidelity blockers
remain assigned. A new bounded Docker capacity measurement is also assigned:
the512MiB live-host budget has not yet been established by observation.

### Source and access update at 13:00 UTC

Broker first-v1 rollout instructions were corrected at `691c2d9` and
independently accepted. [PR80](https://github.com/DataTalksClub/aws-infra/pull/80)
merged as `44249d1bca6cc4bce0c01ae99d74150125105f74`. This publishes source;
the broker is still undeployed. A read-only STS check failed with credential
process HTTP403, "AWS Gate is closed or denied". The user has been asked to
reopen access for the already-authorized rollout. No failed AWS call executed
an infrastructure mutation, and local work continues without bypassing the gate.

CLI repair `1a066a4` closes the remaining deadline acceptance seam and moves
the installed-wheel skip to the intended missing-helper test. Worker receipts
show180 focused and1157 full serial passes; the isolated installed-wheel
scenario has179 passes and one correctly scoped skip. Independent final review
is pending; these receipts do not publish the helper download channel.

Probe production `1817232` passed independent full functional verification:
57 top-level tests, zero skips, including all six required Docker cases.
Test-only repair `47bcf40` captures connection completion channels under the
accept lock, releases held handlers before cleanup joins on early failure,
and adds actual final-log OpenSSH excess-attempt calibration. Its worker ran
60 top-level race tests with all seven Docker cases and zero skips. Independent
source review remains pending. The final-log evidence is aggregate quiescent
accounting; DEBUG1 output does not identify each attempt's origin.

Mux test repair `c0dcd33` is under independent review for bounded writes,
signal waits, cleanup of launched workers and a real parked-worker barrier.
The worker preserved an initial failure of the untouched A10 RESET deadline
and subsequent passing runs. Source ordering alone cannot establish that a
failure is unrelated; no timing issue is declared resolved from reruns alone.

Native marker carriage/type-boundary corrections passed independent typecheck
and32 focused guards, preserving malformed gateway intent and core `4096fc5`.
The414-test canonical pass is a worker receipt. Fresh packaged fixture proof
and reviewer approval remain required before committing the native changes.
Parity behavior is accepted, but a comment correction is assigned: removing a
manifest row still selects conservative full tests via the unmapped fallback;
P2 detects removed pins and unpinned tightening, not that row removal.

### Integrated evidence update at 13:13 UTC

CLI `1a066a4` passed final independent source review,180 focused tests,
179 installed-wheel-fixture passes with one justified absence-test skip,
and owned Ruff. It is now pushed to public main; CI37625593024 succeeded.
The worker's1157 full serial passes remain separately attributed. No helper
release has been published: the private Go repository has no live workflows,
artifacts or releases at the audit time, and the helper PyPI endpoint returned
404. Installation without private repository access is a release gate.

Accepted probe production and final harness revisions and accepted mux bounds
are integrated at `eb04a64`. The integrated hostagent race run passed60
top-level tests and150 including subtests, with zero failures/skips and all
seven top-level Docker cases executed (57.335s). Committed hostagent and mux
files match `47bcf40` exactly. A fresh ZAI task addresses the separate unchanged
reader's partial-frame retry and early-failure cleanup risks; those have not
been proven to be the cause of the previously observed A10 timeout.

Frozen web `3c372e7`/`360feaf` retains accepted conservative selected-record
resolution. Independent review found four further repairs: record and scan the
first gateway authentication text frame; clear stale manual-copy errors at
expiry and make the pending manual-rejection regression actually reject;
replace substring URL exceptions with exact parsed rules and qualify HTTP
capture claims; and await ordered PTY output after the OSC52 clear attempt.
ZAI owns those repairs. The combined shipping-browser/production-Go-gateway
fixture is running separately and must incorporate the eventual corrected web
commit before acceptance. Shared-core selected-host identity handoff remains a
conservative usability limitation, rather than a fallback to a sibling's key.

The web worker disclosed one Python string replacement contrary to the editing
instruction. Reapplying the line with Edit does not erase that deviation.
New tasks explicitly require Edit/apply_patch for all source, including test
files written in Python. Final source review and test results remain required
independently of the editing method.

### Scoped evidence and repair update at 13:45 UTC

Capacity fixture `01f9345` passed independent source/raw-data review for its
recorded local observations. The measured product is `1b64a70`, with unchanged
gateway quota/routing/mux production source relative to `d09815c`. Three
recorded cgroup peaks were62.05,62.90 and52.27MiB, with zero OOM events;
64 pinned SSH clients echoed192MiB each direction, and16 paced consumers
received32MiB. The179MiB residual budget is arithmetic based on unmeasured
OS/SSM/TLS/legacy reservations, not live ARM64 headroom.

The capacity harness itself remains unaccepted: assertion/cleanup failures can
exit0, fixture host-key copies and root-owned agent directories remain, client
setup/work cancellation and joins are incomplete, and result durations are0.
Fresh ZAI corrections are assigned. No global65th-client or eight-streams-on-one
host test, full64-client slow-window occupancy, or active-client drain was
observed. The report must qualify those gaps before integration; no production
capacity settings have been changed.

Mux reader fixture `7a22643` passed15 independent focused race tests, but
cleanup lacks explicit reader/relay joins and early-failure A6 responder joins.
It remains unintegrated. A fresh ZAI turn owns those lifecycle corrections and
meaningful full-output/early-abort controls. The prior A10 timeout's cause is
still unproven. The worker disclosed a sed edit despite the edit-only rule;
source-result checks do not establish method compliance.

Frozen native fixture review ran75 checker self-tests successfully, but found
an actual watcher closure N-1/checker N mismatch, unsuccessful package/session
lookups being mistaken for absence, and cleanup reporting after lease release.
Historical HUP isolation also needs actual producer calibration. Corrective
ZAI work is queued after the current owner's exit; no emulator acceptance or
Android commit is authorized by these synthetic checks. Its Python-edit
deviation remains recorded. Native source/APK hashes must be rechecked after
the repair, preserving published core4096 and legitimate peer changes.

### Implementation and review update at 14:15 UTC

ZAI remains the implementation owner. Mux test-only commit3975d46 adds shared
responder lifetimes and explicit reader/relay joins, with actual encoded-frame
full-output controls. Its worker reports19 focused race tests and the full
tunnel race package passing; fresh independent source review is pending.
Neither7a22643 nor3975d46 is integrated yet. Old reader-join RED controls were
timing-dependent; the smallest abandoned-reader control did not fail in four
samples. No stronger RED or prior-timeout cause claim is made.

Deployment activation timed out with exit124 and partial changes retained.
Static review additionally found D23: privileged pathname operations on
service-writable registry/certificate entries can race runtime replacements.
A corrective ZAI task is queued after the default-root, staging and systemd
serialization repairs. All remain rollout blockers. AWS credentials remain
unavailable after the closed-gate HTTP403; no later infrastructure deployment
has occurred.

Independent web review accepted the556ed27 first-auth capture, per-write
expiry refusal and ordered OSC52 output repairs. HTTP/URL credential policy
still accepts unintended surfaces and is assigned a fresh correction. The
combined shipping browser/actual Go gateway fixture remains in progress and
must establish its final source composition independently.

The native parent worker corrected the watcher/checker closure count after
independent review and prepared APKs, but failed lookup/absence handling,
cleanup reporting order and historical HUP calibration remain assigned to
the successor. No emulator acceptance is claimed. Endpoint onboarding docs
are undergoing corrections for actual daemon configuration/connection
context, required versus recommended policy and honest-gateway revocation.

### Accepted endpoint documentation and composition gates

Independent Astra source review accepted CLI4acd122 and Go1f6d244 for
documentation integration. CLI main now publishes4acd122; its new CI run is
37636388884, pending at publication. Go source-review branch now includes
f068857/b3aee18, equivalent to596c190/1f6d244. No endpoint configuration was
changed or production key-only authentication certified. A nonblocking
wording clarification remains; the worker's summary sentence describing
which revocation remains under user control is inaccurate and must not be
reused as the security conclusion.

Combined browser composition1b883f8 preserved the accepted crypto classifier
and production guards but independently reimplemented the web harness and
regressed the CLEAR acknowledgement into a contiguous echoed-input match.
Accepted original-auth recording and expiry controls also need restoration.
Its actual bundled core is8e8679d rather than published4096. A fresh ZAI
composition repair is queued behind the predecessor's exit and independent
acceptance of the URL/header-policy commit. No final browser acceptance is
implied by the predecessor's fixture run.

Independent mux3975d46 focused race passed19 top-level tests with zero skips,
but acceptance remains withheld: RESET consumers need explicit closure
handling, and its concurrent write probe can itself time out the ACK. ZAI
owns a fresh repair using an actual partial ACK read barrier that leaves the
write parked until owner cleanup. Full-output tests are a separate direction
and remain useful. Neither unaccepted mux commit has been integrated.

### Final mux integration and remaining fixture corrections

Independent405cde1 review accepted the final RESET closure handling and
partial-ACK read barrier, with20 focused race tests, zero failures/skips.
Root integrated7a22643/3975d46/405cde1 as976c54f/76d405a/daed54e. Both
production mux and final test files are byte-identical to the reviewed
source. Root full tunnel race atdaed54e passed47 top-level tests (70 including
subtests), zero failures/skips, exit0; raw JSON/stderr/exit receipts are
`root-integrated-mux-final-race.*`. The earlier A10 timeout remains unassigned.
Historical method deviations and scheduling-dependent RED limits remain.

CLI7a3e014 clarifies which endpoint actions remain under user control when
the gateway is compromised; it is published with CI37637678360 successful.
The previous endpoint worker's inaccurate receipt bullet is corrected with
its original wording retained in the correction note. No endpoint daemon
was changed or audited on behalf of a user.

Webfaf4ac9 passed its existing six offline controls but independent review
withheld acceptance: raw URL scanning misses percent-encoded query secrets;
the Playwright header view omits some headers; and two diagnostic paths echo
untrusted credential-bearing values. Fresh ZAI repair owns decoded surface
scanning, complete awaited header capture and actual diagnostic controls.
The combined-browser approval file remains absent.

Capacitycf39348 closes substantial exit/provenance/telemetry/cancellation
defects, but disables its watchdog before unbounded teardown and leaves a
traffic reader unjoined on errors. Final documentation, numeric sampling,
inventory failure and owned worktree removal refinements are also assigned
to a successor. This worker disclosed nine sed-edited timeout call sites;
the deviation is retained despite the explicit edit-tool instruction.

Provisional native source review accepted real producer/checker closure and
history controls, but still found error-bearing/malformed session lists being
treated as complete, arbitrary failed lookup 'not found' text treated as
package absence, and delegated launcher restoration failures not reliably
surfaced. A successor owns narrow repairs and actual helper controls before
fresh APK preparation and any emulator acceptance. AWS remains gated closed;
no production gateway deployment is claimed.

### Broker live rollout after AWS reopening

The user explicitly reported AWS Gate opened. Fresh STS verified account
817685572750, phone-aws-sandbox-role; the accepted691c2d9 source matched
merged44249d1 byte-for-byte under sandbox/pocketshell-sync. Before snapshots
confirmed the existing desktop and web Google audiences and subscription
URL. Root invoked the reviewed deploy.sh with all five inherited overrides
unset and three intended gateway values supplied. Deployment exited0 with
the new JWKS/token outputs. Lambda package key is
`pocketshell-sync/lambda-9c69a79e52cfff47bf23b96a3034a6658e26d1bfeae6648f6eb680a8469561c7.zip`.

Root public JWKS check returned200, one key, accepted SPKI SHA256
`1fecbb99b4425f2b19432c7b9199f6c79eed1e16c238687309318747fe4c76a7`.
All six actual authorized method/route pairs returned401 anonymously and
with a forged Google-shaped JWT. Independent review repeated these checks,
confirmed all existing parameters except LambdaCodeKey preserved, the three
new values correct, authorizerq8n0v9 with unchanged Google issuer and both
audiences, and public JWKS/JWT token/sync route wiring. The live Lambda has
only the two exact ssm:GetParameter signing-key grants; read-only deny audit
passed10 DENY/6 KEEP. An ephemeral self-signed broker-shaped JWT on GET/me
also returned401, without saved or printed private key/token.

These are live negative/wiring/public-key receipts, not the legitimate
Google P1–P4 flow. Correctly signed broker issuance and its rejection by
sync remain untested. Five broader readers are unchanged and old-key
retirement remains refused. No signing private key or OAuth secret was
read or rotated. This deploy activates the broker only; canonical gateway
TLS, runtime migration and CD remain held for their own review gates.
The three persistent broker operation documents were subsequently updated
by ZAI, reviewed and merged as PR81; the merge receipt is recorded above.

## Independent Opus review at 15:47 UTC

External Opus5.5 reviewed exact root `89cbbd2`. Required real OpenSSH
host-key scenarios passed under the race detector: 8 top-level tests,
2 subtests, zero skips/failures/races, completed final sshd log accounting.
Owned fixture containers/images/temp keys were cleaned up; peer containers
were left untouched. The existing fixture uses the default Docker bridge
with a loopback-only ephemeral port, rather than a private test network.

The result is conditional. Real OpenSSH exercises production enrollment
probing, but its mirrored Go pin callbacks do not establish shipping browser
or native pin verification. Two separately run ordinary auth tests use the
real verifier/service/agent with a Go SSH fixture, rather than real OpenSSH
through the root executable. Combining those links remains a coverage gate.

Opus identified two low-severity source findings: tunnel routing ignores
the URL device ID in favor of the auth-frame ID (ownership is still checked),
and enrollment prints raw HTTP error text without the runtime reason
sanitizer. The logged pinned-key value is also a type-header prefix rather
than a distinguishing fingerprint. ZAI owns the source/tests in
`pocketshell-gateway-opus-followup`. A separate ZAI worker owns
`security/productionflow/**` in `pocketshell-gateway-production-flow`, using
real CLI enrollment/run, the root gateway executable, real OpenSSH and an
independent pin for ordinary positive/refusal checks. No production code is
owned by that fixture worker.

Final browser composition, delivery helper builds and the composed OpenSSH
fixture require the exact reviewed root commit containing these repairs.
No approval marker exists yet. Installer D21/D23, real Google positive
issuance, native packaged evidence, TLS/runtime migration and CD remain
separate gates; the Opus result accepts none of them.

## Review follow-ups at 16:32 UTC

Default-root installer and initial combined-browser workers timed out with
exit124. Their partial source/logs remain preserved and unaccepted. The
expired installer subprocess was identified by its own group, start time,
worktree and script, stopped, and verified no longer writing its log. No
matching old browser fixture runner/container remained at the cleanup check.
Fresh ZAI follow-ups own final installer and browser composition gates.

Go follow-up `1463314` independently passed 5 focused top-level race tests
and 2 subtests without skips. URL/auth-frame consistency and true pinned-key
fingerprints are accepted at that commit, but not integrated yet. Enrollment
errors now escape controls and bound text; they still print a reflected
submitted bearer token, including a prefix when truncation precedes redaction.
A fresh ZAI follow-up must suppress credential-bearing response text before
the final root dependency marker and composed builds can be accepted.

Browser diagnostic `6000025` passed its eight offline controls and preserved
the accepted custody definitions. Review still rejected its raw top-level
exception traceback and unvalidated field-name/version assertion payloads.
Fresh ZAI corrections own those exact output paths. Screenshots are explicitly
unredacted local artifacts outside the text/log guarantee, with no automatic
upload found in the reviewed runner scope.

Native authority checks independently passed104/80/18/5 and verified prepared
APK hashes/identities and unchanged APK-input reuse. CI now has the required
HUP artifact argument and explicit PyYAML setup, independently source-accepted.
Package-absence logic still accepts ambiguous diagnostics/garbage enumeration,
and unset-setting deletion lacks readback before dropping the recovery record.
The next ZAI repair is limited to those two findings; actual leased packaged
execution remains required after final source acceptance.

Capacity `8283dc9` (fixture `47b7b38`) has verified normal-run evidence:
69 passing assertions,341 numeric rows, matching four binary revisions/hashes,
and currently absent owned objects, ports, process group and worktree. Source
acceptance is withheld: watchdog stop precedes late cleanup; its TERM trap
does not preserve escalation; per-step timeouts lack hard escalation; a
traffic join-timeout path/helper returns unjoined; PID signals lack complete
identity checks; failed Git inventory looks absent; a failure path captures
the wrong status; and selftest artifact rebinding breaks watchdog paths.
The fresh ZAI fixture repair must calibrate these actual paths. Valid memory
measurements do not establish those all-path cleanup claims.

## 17:15 UTC — browser diagnostic acceptance and native status witness

Web fixture commit `6b7b8e844921cc2eb011eadc7cea69798b9a3b84` independently
passed all nine offline controls and six additional boundary calibrations.
All seventeen accepted custody/policy/recorder/OSC definitions are unchanged.
Exception cycles and reporter failures now yield bounded, safe diagnostic
output and failure status. Root verified the worker's actual exit0 and
recorded the exact source dependency marker. The final composed browser
worker may use this revision; shipping browser/Go-runtime acceptance remains
open. Peer crypto edits and unredacted local screenshots are excluded from
this diagnostic acceptance.

Native cleanup's next repair independently passed122/19/6 tests and closed
the ambiguous package diagnostic, malformed package enumeration and ignored
settings-delete findings. Review calibrated a further readback defect:
`settings get` can print the expected value but exit1, and the helper still
drops the durable recovery record. A fresh ZAI repair owns explicit success
status checks in both null and numeric readback branches, with actual-helper
controls. Prepared APK reuse and CI wiring retain their scoped acceptance;
the canonical leased packaged run remains pending this source correction.

The composed real-OpenSSH fixture's source review confirmed the intended
root executable/CLI/independent-pin path, but required stronger binary VCS
binding, real transport deadlines and checked partial-start cleanup. A
separate ZAI checkout owns those repairs with a distinct resource namespace.
Final fixture execution waits for the independently accepted root Go
enrollment correction, rather than substituting an older runtime revision.

## 2026-10-08 — reopened AWS access and final source gates

STS confirmed account817685572750 through phone-aws-sandbox-role after the
user reopened AWS Gate. Read-only IAM inventory confirmed the existing
`arn:aws:iam::817685572750:oidc-provider/token.actions.githubusercontent.com`.
The broker remains deployed; the new Go gateway runtime, trusted canonical
TLS and routine GitHub OIDC deployment have not been deployed or accepted.

Root Go source `a31e733027424fe77b217f0d5c551956be12d60f` includes the
independently accepted run-peer-fields correction. The independent focused
race checks passed26 events; the integrated `go test -race -count=1
-timeout15m ./...` and `go vet ./...` both passed. Plain-text full-suite
output does not establish a skip count. A local source marker now permits
functional fixtures to build that exact clean, detached revision. It does
not accept browser/delivery/native fixtures or a future combined release.

Independent offline review accepted IMDS classifier commit
`0916b92f9cd6195f1d4d180577a63d2a7904000d` with41 passing checks. All timeout
results remain unproven; only a validated `000` status with curl exit7
proves a blocked connection. Integration, generated SSM source identity,
CI wiring and actual target enforcement remain pending. The target has
no iptables/nft command; an unproven systemd probe therefore cannot be
silently accepted in place of a working fallback.

Native original-setting authority repair independently passed25 preflight,
8 restoration and122 cleanup checks. The existing guard APK inputs are
unchanged and may be reused for their canonical leased refusal fixture.
Those results do not establish Android or Desktop gateway connectivity.
Separate ZAI workers own the portable transport contract and both native
backends; UI/pairing integration and actual packaged connections remain
required. Capacity, browser custody, production OpenSSH fixture, wheel
provenance, installer and Desktop publish repairs remain under review.

Bootstrap review found a missing existing-provider ARN parameter, an
incorrect IAM simulator CLI option, incomplete multi-result checking and
missing simulation context. A separate ZAI repair owns the bootstrap
script and offline controls. Full bootstrap also publishes the executable
SSM installer, whose final delivery review is still pending. No bootstrap
or runtime rollout was attempted from this unaccepted source.

The credential boundary documentation now explicitly covers mixed traffic:
new routes use scoped broker tokens, but legacy direct SSH/forwarding
clients still send Google tokens to the same process. Accounts using those
paths remain within its sync-credential trust boundary. Retiring those
callers or genuinely isolating the legacy execution boundary is a separate
checklist gate; this does not demonstrate plaintext-key recovery or home
SSH control. Documentation correction `728500fd161423596d2622a989c3946bbf056b63`
and the Go source were pushed to the existing draft review branch.

### IAM-only quarantine stage executed

Independent review accepted the frozen `infra/bootstrap-iam-quarantine.yaml`
(SHA256 `eb6f3e818313356343ea280218c60611cfa4849f17f465af083a2ceed62860fe`).
AWS template validation passed. Change set `gateway-iam-quarantine-20261008`
contained exactly one Add: logical `GithubDeployRole`, type `AWS::IAM::Role`.
Root executed that exact change set after source and change-set review;
stack `pocketshell-gateway-bootstrap` reached CREATE_COMPLETE.

Live role readback confirmed `pocketshell-github-deploy`, the existing account
OIDC provider, audience `sts.amazonaws.com`, exact immutable main subject
`repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main`,
and MaxSessionDuration3600. Its only permissions policy is inline
`quarantine-deny-all` (`Deny`, `Action:*`, `Resource:*`), with no attached
managed policies. Live IAM simulation returned explicitDeny for all four
requested actions: SendCommand, PutObject, GetParameter and InvokeFunction;
all four results were checked, with no missing context or truncation.

This stage creates the deployment identity without deployment authority.
It adds no SSM document, runtime policy, instance change, artifact upload or
host command. A later independently accepted full bootstrap update must
use this same stack/logical role ID and preserve exact trust; its change
set must show no role replacement. Removing quarantine and enabling the
installer remain separate acceptance gates. Generated change-set, stack,
role, policy and simulation receipts are retained in the local task evidence
directory; they contain no credentials.

The canonical packaged Android guard lane subsequently exposed a fixture
restoration failure: DELETE FROM `ssh_keys` addresses a nonexistent table.
The failed run is preserved. Diagnosis, a reviewed repair, new test APK
and a successful canonical run are required; offline helper acceptance
does not close this actual packaged gate.

### Final fixture and wheel review residuals

Browser worker completed clean7a02a5a with seven offline control suites.
Independent review accepted the new async complete-header capture, real
RS256 verification and final three-context custody pass, but required a
full-line source-marker parser, bounded work/cleanup, origin-specific
account paths, authoritative public-key-auth log filtering and a final
broken-context zero-socket/auth check. Actual-helper calibrations showed
that a journal banner was counted as authentication and a broker-origin
GET of a sync path was allowed. A new isolated ZAI repair owns those
fixture boundaries; the actual composed browser/Go run remains pending.

Wheel worker completed cleanc2f43e5 with34 passing harness assertions.
Independent review found seven invalid semantic inputs still accepted:
duplicate/conflicting producer fields or effective flags and downstream
copied-provenance/helper-map contradictions. Metadata label agreement
also needs to be distinguished from inspected binary/build identity.
A separate ZAI correction owns the packager/verifier/harness; four-platform
product artifacts, installed-helper runtime and actual CI verifier invocation
remain open. Unsigned checksums are consistency data, not producer authentication.

Production-flow driver1cda215 passed27 offline checks, but an independent
fake-Docker control showed failed inventory output could authorize removal.
Required repairs include mandatory receipt status checks, owned-child
retirement, bounded work and separate cleanup, worktree retention on unknown
registration, output isolation and shared-deadline enforcement. The existing
worker was sent the exact report; queued delivery alone does not prove it
read or implemented the correction. No unaccepted final driver was run
against real Docker resources.

### Capacity deadline diagnosis and Desktop publish review

Astra identified a genuine capclient deadline-result race in the unchanged
production source: socket hard expiry at endAt+grace can finish workers
before the separately scheduled watchdog callback closes its channel.
The final channel-only check can then return success and stop that callback.
This is not safely waived as a pre-existing test flake. A separate ZAI
worktree owns authoritative monotonic-cutoff/finalization repair and
deterministic actual-socket/callback controls, plus bounded fixture cleanup
and per-attempt test timing. Independent targeted repetitions passed24
executions without reproducing the intermittent failure; that result does
not disprove the identified source interleaving. The earlier measurement
remains historical and a new complete accepted measurement is required.

Desktop publish repair completed clean493ba7e bound to the failed run's
exact corebf408907. Local typecheck/lint/build passed; unit3186+1 skip,
integration55+1 skip and E2E55+3 skips passed. Skips are explicitly reported
and do not certify the unavailable platform cases. Independent review
accepted canonical SFTP expectation, completed agent-binaries mocks and
maintenance-tool locators, but actual filesystem controls showed the new
LocalHost availability check accepts directories and non-executable files.
A fresh ZAI worker owns only that guard and its tests. Actual three-platform
CI and the publish rerun remain open. The worker disclosed shared helper
image retagging; running peer containers were not touched. Owned compose
teardown and absent override file were independently checked.

The next read-only AWS package prerequisite preview could not start:
STS credential processing returned AWS Gate HTTP403 at22:56:03 UTC.
No SSM command, package install or target change occurred. The earlier
quarantine stack remains created and verified; local source/review work
continues. Reopening access is needed for the next concrete AWS action,
not for continued implementation or a change in task authorization.

### Later production fixture receipt and AWS reopening

The production-flow worker's later terminal receipt corrects the earlier
statement that no unaccepted driver ran against real Docker. It ran four
owned functional cases at product a31e733 despite pending driver review.
Run 88434487c426446b9b68a246d2d1f5dd reported four passes and no skips;
those observations are provisional and do not accept the driver or the
release gate. The independently identified inventory-error cleanup and
deadline/ownership defects still require repair. A fresh worker owns that
repair with offline controls only; root will schedule the next actual run
after independent source acceptance. Queued instructions did not establish
that the running warm worker read them.

The user reports AWS Gate reopened. A separate agent is verifying identity
and the already planned read-only firewall-package prerequisites. This
does not activate the quarantined deployment role or approve an unfinished
runtime installer.

Independent review accepted the native fixture's required privateKeyPath
plumbing, but found four remaining ownership/error gaps: present non-file
paths treated as absent, missing cleanup schema validation, key-file
mutation before DB ownership checks, and close errors interrupting later
cleanup. A new fixture-only ZAI turn owns the correction; no new APK or
device run is authorized by the prior compile receipt.

Desktop source30c719c closes the four existence-only guard defects.
Independent focused checks passed23 tests with1 Windows-positive skip.
Review still requires spawning the exact validated candidate, because
relative/empty PATH lookup can otherwise differ at spawn, and containing
the new test artifacts and connection/timer cleanup. A fresh two-file ZAI
turn owns those corrections; the three accepted publish test repairs stay.

Astra's installer authority-profile review confirms final merged-group
and bind-only capability checks, but those checks follow directory
migration. The ordinary account write probe does not establish authority
of every existing same-UID process. The current/prospective unsupported
profile refusal, actor assumption and phase-order evidence remain review
requirements; no such stronger actor was observed on the live target.

The correct default AWS credential process was rechecked after the user's
reopening message and still returned HTTP403. No account verification or
instance command succeeded. A clarification request is pending; source
implementation, independent review and documentation continue locally.
