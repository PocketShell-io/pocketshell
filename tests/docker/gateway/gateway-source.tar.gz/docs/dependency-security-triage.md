# Dependency security triage — 2026-10-07

Verification only: no source or lockfile edits, no test/build reruns, no cloud operations. Three `npm audit --json` receipts are retained beside this report: `core-dependency-audit.json`, `web-dependency-audit.json`, `desktop-dependency-audit.json`. Each audit exits nonzero because vulnerabilities are present; that is expected audit behavior. Counts represent affected packages and propagated findings, not independent exploit chains.

| Snapshot | Audit package counts | SSH library |
| --- | --- | --- |
| Integrated core `b42d06e`, `/home/alexey/git/gateway-integrated-workspace/pocketshell-core` | 12: 3 moderate, 7 high, 2 critical | ssh2 1.16.0, test-only |
| Browser client `b44743c`, `/home/alexey/git/gateway-client-workspace/pocketshell-web` | 17: 6 low, 4 moderate, 5 high, 2 critical | ssh2 1.17.0, shipped browser implementation |
| Desktop `262af05`, `/home/alexey/git/gateway-native-workspace/pocketshell-desktop` | 48: 2 low, 9 moderate, 33 high, 4 critical | ssh2 1.16.0, shipped external runtime dependency |

## Conclusions and priority

The core's twelve findings belong to its development/test dependency graph. The published core has no production npm dependencies and ships its own `dist`, so these twelve do not demonstrate a vulnerability in the opaque Go gateway or the user's SSH server. They still matter on machines and CI workers that build the trusted browser/client artifacts.

Browser cryptography needs a specific release decision: the polyfill imports vulnerable `elliptic` through the **production SSH signing path**, even though its lockfile records the polyfill as development tooling. The low severity npm label does not establish safe key custody. No SSH key recovery or exploitation was attempted or demonstrated in this verification. The upstream report discusses restricted prerequisites and doubts ordinary hash-before-sign key recovery; do not claim that a compromised gateway can automatically recover any user's key.

Desktop Electron 33.3.1 is shipped as the application runtime despite its `devDependency` classification. Its current advisory set therefore cannot be dismissed as test tooling. This is a desktop release maintenance concern independent of the new unsupported-gateway guards. Individual reachability depends on application features and protections; the three latest Electron cases examined have mitigating or absent prerequisites in this source, described below.

Neither the three audits nor the audited versions report a direct advisory against ssh2 or tweetnacl. This means no matching advisory was reported, not that their integration or protocol choices have been proven secure.

Lockfile SHA-256 receipts: core `9a14e513b8963599939e4366535d1530f270c7668e2aef63ad3d0bf70b781b10`; web `a4b17abb0a989c736389068ddfb087f73c58047156fe555952b82694daf1d03e`; desktop `399c8f156d263fd3e0fbe2e75f28c0ea5a5f67986607c5b62606df0c95c0422c`. Audits and npm-ls can traverse adjacent file-linked core development dependencies; the browser/desktop lock inventory therefore may differ from npm-ls's linked-tree development inventory. Neither was interpreted as an emitted bundle manifest.

## Core: exact twelve affected packages and paths

All twelve have `dev:true` in the integrated core lockfile. Core integration fixtures import testcontainers; the ordinary unit/integration commands use `vitest run`. Searches found no explicit public Vitest API/UI server configuration in the examined core test configuration and scripts.

| Package and installed version | Dependency path / impact / scoped remedy |
| --- | --- |
| `vitest` 2.1.8 (critical) | direct dev tool. API-server RCE [GHSA-9crc-q9x8-hgqq](https://github.com/vitest-dev/vitest/security/advisories/GHSA-9crc-q9x8-hgqq), UI/API file read/execution [GHSA-5xrq-8626-4rwp](https://github.com/vitest-dev/vitest/security/advisories/GHSA-5xrq-8626-4rwp), mock redirect issue below, plus propagated Vite/tinypool findings. `vitest run` is not evidence of a remotely exposed UI server. Updating only to 2.1.9 fixes the oldest API issue but leaves current findings. |
| `@vitest/mocker` 2.1.8 (moderate) | vitest child. Redirect-target file read through a reachable dev-server mock registration boundary; own browser RPC is authenticated. Latest maintained fix is 4.1.11, with older 2.x/3.x not planned for this fix. [Maintainer advisory](https://github.com/vitest-dev/vitest/security/advisories/GHSA-82fw-gwwq-j7x9). |
| `tinypool` 1.1.1 (critical) | vitest child. Prototype-pollution gadgets in worker construction and `run()` options; requires a separate pollution primitive and applicable options path. It is not an automatic remote-code-execution endpoint. Fix both cases with at least 2.1.2 or a Vitest release that no longer uses this package. [Worker advisory](https://github.com/tinylibs/tinypool/security/advisories/GHSA-5gmw-xhrv-c9v3), [run-options advisory](https://github.com/tinylibs/tinypool/security/advisories/GHSA-85c8-ppgw-ccpr). Do not force an incompatible major override into Vitest 2 without compatibility review. |
| `vite` 5.4.21 (high) | vitest and vite-node child. Optimized source-map path traversal, Windows deny-list bypass, Windows UNC editor disclosure; dev-server issues, not static deployed assets. Use a patched supported Vite resolution, e.g. 6.4.3 satisfies the audit's current <=6.4.2 boundary. [Windows maintainer advisory](https://github.com/vitejs/vite/security/advisories/GHSA-fx2h-pf6j-xcff). |
| `vite-node` 2.1.8 (moderate) | vitest child; affected by Vite. Update with Vitest. |
| nested `esbuild` 0.21.5 (moderate) | Vite child. The core's independent direct esbuild ^0.28.2 does not replace this nested copy. Vulnerable development-server cross-origin reads, patched >=0.25.0. [Maintainer advisory](https://github.com/evanw/esbuild/security/advisories/GHSA-67mh-4wv8-2f99). |
| `source-map-js` 1.2.1 (high) | vitest → vite → postcss. Indexed source-map offsets can block event loop when maps are consumed. No core runtime imports found; fixture/build maps come from the checked-out source tree. Patch-level 1.2.2 resolves the current issue. [Upstream release](https://github.com/7rulnik/source-map-js/releases/tag/v1.2.2). |
| `testcontainers` 10.17.2 (high) | direct Docker integration test tool, propagated dockerode/undici findings. It is not the WebSocket transport client shipped to users. Upgrade its owned dev dependency and exercise real Docker compatibility. npm proposes 12.2.0, which requires Node >=22.22. |
| `dockerode` 3.3.5 (high) | testcontainers child; propagated archive extraction finding. Build/test worker filesystem authority matters if archives or Docker daemon data are untrusted. |
| nested `tar-fs` 2.0.1 (high) | testcontainers → dockerode. Three path traversal / link-following extraction advisories: [GHSA-pq67-2wwv-3xjx](https://github.com/mafintosh/tar-fs/security/advisories/GHSA-pq67-2wwv-3xjx), [GHSA-8cj5-5rvv-wf4v](https://github.com/mafintosh/tar-fs/security/advisories/GHSA-8cj5-5rvv-wf4v), [GHSA-vj76-c3g6-qr5v](https://github.com/mafintosh/tar-fs/security/advisories/GHSA-vj76-c3g6-qr5v). 2.x requires >=2.1.4 for these current entries. |
| `undici` 5.29.0 (high) | testcontainers child. Thirteen direct current entries cover decompression, request/response splitting, invalid WebSocket negotiation, fragmentation resource exhaustion, cookie/header injection and retry/keepalive behavior. They apply to Node test HTTP clients, not browser native WebSocket. Exact entries retained in JSON and appendix; cumulative 6.x patch boundary is >=6.28.1, which requires a compatible parent update. [Maintainer fragmentation advisory](https://github.com/nodejs/undici/security/advisories/GHSA-vxpw-j846-p89q). |
| `@fastify/busboy` 2.1.1 (high) | testcontainers → undici → multipart parser. Prototype-named header DoS and filename/name CRLF injection; cumulative patch >=3.2.2. [DoS advisory](https://github.com/fastify/busboy/security/advisories/GHSA-x8mw-p69m-v3mx), [CRLF advisory](https://github.com/fastify/busboy/security/advisories/GHSA-gxm5-99cw-xjw9). Requires actual multipart parsing of attacker-influenced data to trigger. |

## Browser: production cryptography and other findings

Actual path: `vite-plugin-node-polyfills` 0.28.0 → `node-stdlib-browser` 1.3.1 → `crypto-browserify` 3.12.1 → `browserify-sign` 4.2.6 / `create-ecdh` 4.0.4 → **elliptic 6.6.1**. `src/shims/ssh2-crypto.ts` imports crypto-browserify and exposes `createSign`/`createECDH`; `src/terminal/connection.ts` imports ssh2 and passes private keys from `authOf()` to the SSH client. ssh2's key parser uses the shim's sign function, which calls `createSign().sign(key)` for non-Ed25519 keys; browserify-sign parses an EC key and calls `elliptic.ec.keyFromPrivate(...).sign(hash)`. Thus ECDSA user authentication can reach the affected implementation. Configuring `serverHostKey` to Ed25519/RSA restricts **server host keys**, not user private keys, and does not remove this path.

The current advisory has no patched elliptic release and describes ECDSA signature arithmetic/key exposure under specific conditions. The original upstream issue describes hash/curve mismatch and explicitly questions key recovery under ordinary hash-before-sign conditions. This check establishes code reachability, not practical key recovery. ECDH use of the same package is present (`ecdh-sha2-nistp256`) but this advisory concerns ECDSA signatures, so it does not by itself establish broken ECDH. [Original upstream issue](https://github.com/indutny/elliptic/issues/321), [current advisory record](https://github.com/advisories/GHSA-848j-6mx2-7j84).

Minimum owner-assigned browser fix: fail closed on ECDSA **user authentication** before any signing/private-key use, permit the already-tested Ed25519/RSA paths, and add a genuine browser/shim key-parser regression proving zero ECDSA signatures across gateway/direct/forward paths. Report the unsupported key type visibly. Removing/replacing elliptic with a reviewed primitive is preferable long term but is a larger crypto migration, not a blind package update. Re-run real browser SSH positive/pin-negative tests after either solution. Do not claim the library has been removed merely because ECDSA signing is rejected; ECDH still uses it.

The same polyfill tree has **pbkdf2 3.1.6**, via both crypto-browserify and browserify-sign → parse-asn1. Long passphrases cause excessive repeated hashing in the JS fallback. Patch 3.1.7 is available. This is browser key-parsing/passphrase availability exposure; no evidence this function is used by the trusted sync broker or Go gateway. Account vault cryptography must be evaluated from its actual WebCrypto implementation separately. [Maintainer advisory](https://github.com/browserify/pbkdf2/security/advisories/GHSA-477h-4r7f-fvrx).

Other browser entries: Vite 6.0.7 plus nested 5.4.21, Vitest 2.1.9, tinypool 1.1.1, esbuild 0.24.2 / 0.21.5, brace-expansion 2.1.4, source-map-js 1.2.1, and Vue/server-renderer 3.5.13. Vue SSR XSS requires SSR rendering attacker-controlled attribute keys; searches in app/shared UI found no server-renderer/renderToString path, and this is a static client deployment. The presence of Vue's compiler/server packages or `dev:false` alone does not establish vulnerable SSR in the deployed page. source-map-js is reached by Vue compiler and PostCSS, not shown here as a consumer of server-provided SSH maps. Confirm emitted bundle membership before a categorical excluded-from-runtime assertion. [Vue maintainer advisory, fixed 3.5.42](https://github.com/vuejs/core/security/advisories/GHSA-g2v6-rqmx-r4w6).

## Desktop: shipped runtime versus build authority

Electron 33.3.1 ships Chromium/Node and is the actual application runtime, independent of electron-builder's production node_modules selection. npm lists 38 direct Electron advisory entries in this receipt. Updating to an actively supported patched release requires an Electron-major migration and complete application acceptance; the latest registry version observed is 44.6.0, while several current entries require at least 41.10.6 on their corresponding branch. Picking an older one-case patched version is insufficient for the full receipt.

Specific primary advisories examined:

- [Sandboxed iframe popup restrictions](https://github.com/electron/electron/security/advisories/GHSA-hq2x-r82h-9wj4): requires untrusted iframe with `allow-scripts allow-popups`. Shared file previews add `allow-popups` for Markdown but not scripts; desktop preview CSP forbids scripts; `windowLinks.ts` denies all in-app popups using setWindowOpenHandler. The examined prerequisites are mitigated; no bypass was tested.
- [Top-level sandbox popup restrictions](https://github.com/electron/electron/security/advisories/GHSA-gr2m-v5gq-v685): source denies popups rather than allowing child windows. This is a mitigation assessment, not a tested complete proof.
- [File/HTTP protocol handler CORS bypass](https://github.com/electron/electron/security/advisories/GHSA-j84w-jfhq-vhvj): this source uses `protocol.handle` and registers its preview scheme with `corsEnabled:true`, rather than the missing-CORS configuration described. Confirm full scheme behavior during the runtime update.
- [Webview worker Node integration](https://github.com/electron/electron/security/advisories/GHSA-9qh4-3jw8-366w): no webview usage was found in the examined desktop source; windows have `nodeIntegration:false`, `contextIsolation:true`, `sandbox:true`. Absence of this feature does not neutralize other Electron/Chromium vulnerabilities.

Build authority findings also matter: electron-builder 25.1.8 → app-builder-lib → @electron/rebuild/node-gyp/cacache → **tar 6.2.1** (critical extraction findings); Electron installer retrieval uses **extract-zip 2.0.1** (high); Playwright 1.49.1 has an unverified-download advisory. Those are artifact acquisition/packaging/test execution rather than normal SSH socket parsing. Root should assign a separate builder/runtime maintenance slice, keep signing/publishing authority separated from untrusted PR tests, and never dismiss archive writes because the packages are development dependencies. The complete 48-package inventory is in the receipt, including affected XML, CSS, URI, YAML, glob, logging, test and HTTP-client transitive packages.

## Recommended disjoint implementation scopes

1. **Browser crypto worker (release security scope):** only browser auth validation/shim and focused tests plus minimal pbkdf2 patch resolution in browser package/lock. Coordinate with the active browser worker; do not alter authentication feature contracts silently. ECDSA reachability must be removed or explicitly resolved before claiming protected browser key custody.
2. **Core test-tool maintenance worker:** core package/lock + affected test config only. Move Vitest to >=4.1.11 with compatible Vite (>=6.4.3), resolve source-map-js >=1.2.2, update testcontainers through its compatible maintained release. Registry metadata confirms Vitest 4.1.11 supports Node20/22/24; testcontainers12.2.0 requires Node >=22.22 and dockerode5/undici8. Check CI runtime before selecting that update. Avoid `npm audit fix --force`, which currently misleadingly suggests Vitest2.1.9 even though several known advisories survive.
3. **Web dev-tool worker:** browser Vite/Vitest/lock (including nested copies) synchronized with the core maintenance slice; source-map/brace-expansion patch refreshes; Vue SSR package update can be separately justified by reachable features rather than npm severity alone.
4. **Desktop runtime/build worker:** Electron, builder and locks plus application acceptance gates as its own tracked scope. Do not hold the pure core marker-preservation fix hostage to unrelated broad dependency changes, but do not ship an Electron release claiming those runtime findings were cleared by the marker guards.

This report is a static reachability/advisory assessment. No exploit was run and no security issue was closed by dependency-count interpretation.

## Exact advisory appendix from captured npm audit

These are exact audit-record IDs/ranges and lockfile versions; the primary maintainer links above were separately inspected for the impact assessment. This appendix records additional audit entries without claiming each was individually source-reviewed.

### core

Worktree git metadata: gitdir: /home/alexey/git/pocketshell-core/.git/worktrees/pocketshell-core2; lockfile package versions below.

- **@fastify/busboy** (high): `node_modules/@fastify/busboy@2.1.1`. .
- **@vitest/mocker** (moderate): `node_modules/@vitest/mocker@2.1.8`. propagated from vite.
- **dockerode** (high): `node_modules/dockerode@3.3.5`. propagated from tar-fs.
- **esbuild** (moderate): `node_modules/vite/node_modules/esbuild@0.21.5`. .
- **source-map-js** (high): `node_modules/source-map-js@1.2.1`. .
- **tar-fs** (high): `node_modules/dockerode/node_modules/tar-fs@2.0.1`. .
- **testcontainers** (high): `node_modules/testcontainers@10.17.2`. propagated from dockerode; propagated from undici.
- **tinypool** (critical): `node_modules/tinypool@1.1.1`. .
- **undici** (high): `node_modules/undici@5.29.0`. propagated from @fastify/busboy.
- **vite** (high): `node_modules/vite@5.4.21`. propagated from esbuild.
- **vite-node** (moderate): `node_modules/vite-node@2.1.8`. propagated from vite.
- **vitest** (critical): `node_modules/vitest@2.1.8`. propagated from @vitest/mocker; propagated from tinypool; propagated from vite; propagated from vite-node.

Direct advisory records (deduplicated):

- [GHSA-x8mw-p69m-v3mx](https://github.com/advisories/GHSA-x8mw-p69m-v3mx): @fastify/busboy vulnerable to Denial of Service via prototype-named multipart part header; affected `>=1.0.0 <3.2.1`.
- [GHSA-gxm5-99cw-xjw9](https://github.com/advisories/GHSA-gxm5-99cw-xjw9): @fastify/busboy vulnerable to CRLF injection via multipart Content-Disposition filename and name; affected `<3.2.2`.
- [GHSA-82fw-gwwq-j7x9](https://github.com/advisories/GHSA-82fw-gwwq-j7x9): Vitest: Path Traversal / Arbitrary File Read via @vitest/mocker Redirect Mock; affected `>=2.1.0 <4.1.11`.
- [GHSA-67mh-4wv8-2f99](https://github.com/advisories/GHSA-67mh-4wv8-2f99): esbuild enables any website to send any requests to the development server and read the response; affected `<=0.24.2`.
- [GHSA-68fv-2mgg-jv7q](https://github.com/advisories/GHSA-68fv-2mgg-jv7q): source-map-js allows event-loop denial of service through indexed source-map section offsets; affected `>=1.0.0 <1.2.2`.
- [GHSA-vj76-c3g6-qr5v](https://github.com/advisories/GHSA-vj76-c3g6-qr5v): tar-fs has a symlink validation bypass if destination directory is predictable with a specific tarball; affected `>=2.0.0 <2.1.4`.
- [GHSA-8cj5-5rvv-wf4v](https://github.com/advisories/GHSA-8cj5-5rvv-wf4v): tar-fs can extract outside the specified dir with a specific tarball; affected `>=2.0.0 <2.1.3`.
- [GHSA-pq67-2wwv-3xjx](https://github.com/advisories/GHSA-pq67-2wwv-3xjx): tar-fs Vulnerable to Link Following and Path Traversal via Extracting a Crafted tar File; affected `>=2.0.0 <2.1.2`.
- [GHSA-5gmw-xhrv-c9v3](https://github.com/advisories/GHSA-5gmw-xhrv-c9v3): Tinypool: Prototype Pollution gadget in worker options leads to Remote Code Execution; affected `<=2.1.0`.
- [GHSA-85c8-ppgw-ccpr](https://github.com/advisories/GHSA-85c8-ppgw-ccpr): Tinypool: Prototype Pollution Gadget to RCE in run() options; affected `<2.1.2`.
- [GHSA-g9mf-h72j-4rw9](https://github.com/advisories/GHSA-g9mf-h72j-4rw9): Undici has an unbounded decompression chain in HTTP responses on Node.js Fetch API via Content-Encoding leads to resource exhaustion; affected `<6.23.0`.
- [GHSA-2mjp-6q6p-2qxm](https://github.com/advisories/GHSA-2mjp-6q6p-2qxm): Undici has an HTTP Request/Response Smuggling issue; affected `<6.24.0`.
- [GHSA-vrm6-8vpv-qv8q](https://github.com/advisories/GHSA-vrm6-8vpv-qv8q): Undici has Unbounded Memory Consumption in WebSocket permessage-deflate Decompression; affected `<6.24.0`.
- [GHSA-v9p9-hfj2-hcw8](https://github.com/advisories/GHSA-v9p9-hfj2-hcw8): Undici has Unhandled Exception in WebSocket Client Due to Invalid server_max_window_bits Validation; affected `<6.24.0`.
- [GHSA-4992-7rv2-5pvq](https://github.com/advisories/GHSA-4992-7rv2-5pvq): Undici has CRLF Injection in undici via `upgrade` option; affected `<6.24.0`.
- [GHSA-p88m-4jfj-68fv](https://github.com/advisories/GHSA-p88m-4jfj-68fv): undici vulnerable to HTTP header injection via Set-Cookie percent-decoding; affected `<6.27.0`.
- [GHSA-vxpw-j846-p89q](https://github.com/advisories/GHSA-vxpw-j846-p89q): undici WebSocket client vulnerable to denial of service via fragment count bypass; affected `<6.27.0`.
- [GHSA-g8m3-5g58-fq7m](https://github.com/advisories/GHSA-g8m3-5g58-fq7m): undici vulnerable to Set-Cookie SameSite attribute downgrade via permissive substring matching; affected `<6.27.0`.
- [GHSA-8xcm-r25x-g524](https://github.com/advisories/GHSA-8xcm-r25x-g524): undici vulnerable to downstream response desynchronization via retry interceptor; affected `<6.28.0`.
- [GHSA-m8rv-5g2x-5cg5](https://github.com/advisories/GHSA-m8rv-5g2x-5cg5): undici vulnerable to CRLF Injection via blob-like body 'type' property; affected `<6.28.0`.
- [GHSA-v3r7-h72x-cjcm](https://github.com/advisories/GHSA-v3r7-h72x-cjcm): undici vulnerable to cookie attribute injection via unsanitized domain and unparsed setCookie fields; affected `<6.28.0`.
- [GHSA-35p6-xmwp-9g52](https://github.com/advisories/GHSA-35p6-xmwp-9g52): undici vulnerable to HTTP response queue poisoning via keep-alive socket reuse; affected `<6.27.0`.
- [GHSA-r53p-7pc4-xj5r](https://github.com/advisories/GHSA-r53p-7pc4-xj5r): undici vulnerable to downstream response splitting via retry interceptor; affected `<6.28.1`.
- [GHSA-4w7w-66w2-5vf9](https://github.com/advisories/GHSA-4w7w-66w2-5vf9): Vite Vulnerable to Path Traversal in Optimized Deps `.map` Handling; affected `<=6.4.1`.
- [GHSA-v6wh-96g9-6wx3](https://github.com/advisories/GHSA-v6wh-96g9-6wx3): launch-editor: NTLMv2 hash disclosure via UNC path handling on Windows; affected `<=6.4.2`.
- [GHSA-fx2h-pf6j-xcff](https://github.com/advisories/GHSA-fx2h-pf6j-xcff): vite: `server.fs.deny` bypass on Windows alternate paths; affected `<=6.4.2`.
- [GHSA-9crc-q9x8-hgqq](https://github.com/advisories/GHSA-9crc-q9x8-hgqq): Vitest allows Remote Code Execution when accessing a malicious website while Vitest API server is listening; affected `>=2.0.0 <2.1.9`.
- [GHSA-5xrq-8626-4rwp](https://github.com/advisories/GHSA-5xrq-8626-4rwp): When Vitest UI server is listening, arbitrary file can be read and executed; affected `<3.2.6`.

### web

Worktree git metadata: gitdir: /home/alexey/git/pocketshell-web/.git/worktrees/pocketshell-web4; lockfile package versions below.

- **@vitest/mocker** (moderate): `node_modules/vitest/node_modules/@vitest/mocker@2.1.9`. propagated from vite.
- **@vue/server-renderer** (high): `node_modules/@vue/server-renderer@3.5.13`. propagated from vue.
- **brace-expansion** (high): `node_modules/brace-expansion@2.1.4`. .
- **browserify-sign** (low): `node_modules/browserify-sign@4.2.6`. propagated from elliptic.
- **create-ecdh** (low): `node_modules/create-ecdh@4.0.4`. propagated from elliptic.
- **crypto-browserify** (low): `node_modules/crypto-browserify@3.12.1`. propagated from browserify-sign; propagated from create-ecdh.
- **elliptic** (low): `node_modules/elliptic@6.6.1`. .
- **esbuild** (moderate): `node_modules/esbuild@0.24.2`, `node_modules/vite-node/node_modules/esbuild@0.21.5`, `node_modules/vitest/node_modules/esbuild@0.21.5`. .
- **node-stdlib-browser** (low): `node_modules/node-stdlib-browser@1.3.1`. propagated from crypto-browserify.
- **pbkdf2** (moderate): `node_modules/pbkdf2@3.1.6`. .
- **source-map-js** (high): `node_modules/source-map-js@1.2.1`. .
- **tinypool** (critical): `node_modules/tinypool@1.1.1`. .
- **vite** (high): `node_modules/vite@6.0.7`, `node_modules/vite-node/node_modules/vite@5.4.21`, `node_modules/vitest/node_modules/vite@5.4.21`. propagated from esbuild.
- **vite-node** (moderate): `node_modules/vite-node@2.1.9`. propagated from vite.
- **vite-plugin-node-polyfills** (low): `node_modules/vite-plugin-node-polyfills@0.28.0`. propagated from node-stdlib-browser.
- **vitest** (critical): `node_modules/vitest@2.1.9`. propagated from @vitest/mocker; propagated from tinypool; propagated from vite; propagated from vite-node.
- **vue** (high): `node_modules/vue@3.5.13`. propagated from @vue/server-renderer.

Direct advisory records (deduplicated):

- [GHSA-82fw-gwwq-j7x9](https://github.com/advisories/GHSA-82fw-gwwq-j7x9): Vitest: Path Traversal / Arbitrary File Read via @vitest/mocker Redirect Mock; affected `>=2.1.0 <4.1.11`.
- [GHSA-g2v6-rqmx-r4w6](https://github.com/advisories/GHSA-g2v6-rqmx-r4w6): @vue/server-renderer: XSS via missing CR in attribute-name blacklist; affected `<3.5.42`.
- [GHSA-q2hr-2g5m-vwhr](https://github.com/advisories/GHSA-q2hr-2g5m-vwhr): brace-expansion: Quadratic-time expansion of the `{a},b}` rewrite causes CPU denial of service; affected `>=2.0.0 <2.1.7`.
- [GHSA-qhr7-859c-m2p7](https://github.com/advisories/GHSA-qhr7-859c-m2p7): brace-expansion: DoS via uncontrolled recursion on nested brace groups causing stack exhaustion; affected `>=2.0.0 <2.1.6`.
- [GHSA-6j4f-fj2g-mc7p](https://github.com/advisories/GHSA-6j4f-fj2g-mc7p): brace-expansion: DoS via uncontrolled recursion in parseCommaParts causing stack exhaustion; affected `>=2.0.0 <2.1.5`.
- [GHSA-848j-6mx2-7j84](https://github.com/advisories/GHSA-848j-6mx2-7j84): Elliptic Uses a Cryptographic Primitive with a Risky Implementation; affected `<=6.6.1`.
- [GHSA-67mh-4wv8-2f99](https://github.com/advisories/GHSA-67mh-4wv8-2f99): esbuild enables any website to send any requests to the development server and read the response; affected `<=0.24.2`.
- [GHSA-477h-4r7f-fvrx](https://github.com/advisories/GHSA-477h-4r7f-fvrx): pbkdf2 rehashes long passwords on every iteration, enabling denial of service; affected `<=3.1.6`.
- [GHSA-68fv-2mgg-jv7q](https://github.com/advisories/GHSA-68fv-2mgg-jv7q): source-map-js allows event-loop denial of service through indexed source-map section offsets; affected `>=1.0.0 <1.2.2`.
- [GHSA-5gmw-xhrv-c9v3](https://github.com/advisories/GHSA-5gmw-xhrv-c9v3): Tinypool: Prototype Pollution gadget in worker options leads to Remote Code Execution; affected `<=2.1.0`.
- [GHSA-85c8-ppgw-ccpr](https://github.com/advisories/GHSA-85c8-ppgw-ccpr): Tinypool: Prototype Pollution Gadget to RCE in run() options; affected `<2.1.2`.
- [GHSA-vg6x-rcgg-rjx6](https://github.com/advisories/GHSA-vg6x-rcgg-rjx6): Websites were able to send any requests to the development server and read the response in vite; affected `>=6.0.0 <=6.0.8`.
- [GHSA-x574-m823-4x7w](https://github.com/advisories/GHSA-x574-m823-4x7w): Vite bypasses server.fs.deny when using ?raw??; affected `>=6.0.0 <6.0.12`.
- [GHSA-356w-63v5-8wf4](https://github.com/advisories/GHSA-356w-63v5-8wf4): Vite has an `server.fs.deny` bypass with an invalid `request-target`; affected `>=6.0.0 <6.0.15`.
- [GHSA-859w-5945-r5v3](https://github.com/advisories/GHSA-859w-5945-r5v3): Vite's server.fs.deny bypassed with /. for files under project root; affected `>=6.0.0 <=6.1.5`.
- [GHSA-xcj6-pq6g-qj4x](https://github.com/advisories/GHSA-xcj6-pq6g-qj4x): Vite allows server.fs.deny to be bypassed with .svg or relative paths; affected `>=6.0.0 <6.0.14`.
- [GHSA-g4jq-h2w9-997c](https://github.com/advisories/GHSA-g4jq-h2w9-997c): Vite middleware may serve files starting with the same name with the public directory; affected `>=6.0.0 <=6.3.5`.
- [GHSA-jqfw-vq24-v9c3](https://github.com/advisories/GHSA-jqfw-vq24-v9c3): Vite's `server.fs` settings were not applied to HTML files; affected `>=6.0.0 <=6.3.5`.
- [GHSA-93m4-6634-74q7](https://github.com/advisories/GHSA-93m4-6634-74q7): vite allows server.fs.deny bypass via backslash on Windows; affected `>=6.0.0 <=6.4.0`.
- [GHSA-4r4m-qw57-chr8](https://github.com/advisories/GHSA-4r4m-qw57-chr8): Vite has a `server.fs.deny` bypassed for `inline` and `raw` with `?import` query; affected `>=6.0.0 <6.0.13`.
- [GHSA-4w7w-66w2-5vf9](https://github.com/advisories/GHSA-4w7w-66w2-5vf9): Vite Vulnerable to Path Traversal in Optimized Deps `.map` Handling; affected `<=6.4.1`.
- [GHSA-p9ff-h696-f583](https://github.com/advisories/GHSA-p9ff-h696-f583): Vite Vulnerable to Arbitrary File Read via Vite Dev Server WebSocket; affected `>=6.0.0 <=6.4.1`.
- [GHSA-v6wh-96g9-6wx3](https://github.com/advisories/GHSA-v6wh-96g9-6wx3): launch-editor: NTLMv2 hash disclosure via UNC path handling on Windows; affected `<=6.4.2`.
- [GHSA-fx2h-pf6j-xcff](https://github.com/advisories/GHSA-fx2h-pf6j-xcff): vite: `server.fs.deny` bypass on Windows alternate paths; affected `<=6.4.2`.
- [GHSA-5xrq-8626-4rwp](https://github.com/advisories/GHSA-5xrq-8626-4rwp): When Vitest UI server is listening, arbitrary file can be read and executed; affected `<3.2.6`.

### desktop

Worktree git metadata: gitdir: /home/alexey/git/pocketshell-desktop/.git/worktrees/pocketshell-desktop4; lockfile package versions below.

- **@electron/get** (moderate): `node_modules/@electron/get@2.0.3`. propagated from global-agent.
- **@electron/rebuild** (high): `node_modules/@electron/rebuild@3.6.1`. propagated from node-gyp; propagated from tar.
- **@eslint/plugin-kit** (low): `node_modules/@eslint/plugin-kit@0.2.8`. .
- **@fastify/busboy** (high): `node_modules/@fastify/busboy@2.1.1`. .
- **@playwright/test** (high): `node_modules/@playwright/test@1.49.1`. propagated from playwright.
- **@vitest/coverage-v8** (critical): `node_modules/@vitest/coverage-v8@2.1.8`. propagated from vitest.
- **@vitest/mocker** (moderate): `node_modules/vitest/node_modules/@vitest/mocker@2.1.8`. propagated from vite.
- **@vue/server-renderer** (high): `node_modules/@vue/server-renderer@3.5.13`. propagated from vue.
- **@xmldom/xmldom** (high): `node_modules/@xmldom/xmldom@0.9.10`. .
- **app-builder-lib** (high): `node_modules/app-builder-lib@25.1.8`. propagated from @electron/rebuild; propagated from builder-util; propagated from builder-util-runtime; propagated from dmg-builder; propagated from electron-builder-squirrel-windows; propagated from electron-publish; propagated from tar.
- **baseline-browser-mapping** (moderate): `node_modules/baseline-browser-mapping@2.10.38`. .
- **brace-expansion** (high): `node_modules/@electron/asar/node_modules/brace-expansion@1.1.15`, `node_modules/@electron/universal/node_modules/brace-expansion@2.1.1`, `node_modules/@eslint/config-array/node_modules/brace-expansion@1.1.15`, `node_modules/@eslint/eslintrc/node_modules/brace-expansion@1.1.15`, `node_modules/@vue/language-core/node_modules/brace-expansion@2.1.1`, `node_modules/brace-expansion@5.0.6`, `node_modules/cacache/node_modules/brace-expansion@2.1.1`, `node_modules/config-file-ts/node_modules/brace-expansion@2.1.1`, `node_modules/dir-compare/node_modules/brace-expansion@1.1.15`, `node_modules/editorconfig/node_modules/brace-expansion@2.1.4`, `node_modules/eslint/node_modules/brace-expansion@1.1.15`, `node_modules/filelist/node_modules/brace-expansion@2.1.1`, `node_modules/glob/node_modules/brace-expansion@1.1.15`, `node_modules/js-beautify/node_modules/brace-expansion@2.1.4`, `node_modules/readdir-glob/node_modules/brace-expansion@2.1.1`, `node_modules/test-exclude/node_modules/brace-expansion@2.1.4`, `node_modules/testcontainers/node_modules/brace-expansion@2.1.1`. .
- **browserslist** (high): `node_modules/browserslist@4.28.2`. .
- **builder-util** (high): `node_modules/builder-util@25.1.7`. propagated from builder-util-runtime.
- **builder-util-runtime** (high): `node_modules/builder-util-runtime@9.2.10`. .
- **cacache** (high): `node_modules/cacache@16.1.3`. propagated from tar.
- **dmg-builder** (high): `node_modules/dmg-builder@25.1.8`. propagated from app-builder-lib; propagated from builder-util; propagated from builder-util-runtime.
- **dockerode** (high): `node_modules/dockerode@3.3.5`. propagated from tar-fs.
- **electron** (high): `node_modules/electron@33.3.1`. propagated from @electron/get; propagated from extract-zip.
- **electron-builder** (high): `node_modules/electron-builder@25.1.8`. propagated from app-builder-lib; propagated from builder-util; propagated from builder-util-runtime; propagated from dmg-builder.
- **electron-builder-squirrel-windows** (high): `node_modules/electron-builder-squirrel-windows@25.1.8`. propagated from app-builder-lib; propagated from builder-util.
- **electron-publish** (high): `node_modules/electron-publish@25.1.7`. propagated from builder-util; propagated from builder-util-runtime.
- **esbuild** (moderate): `node_modules/vite-node/node_modules/esbuild@0.21.5`, `node_modules/vite/node_modules/esbuild@0.24.2`, `node_modules/vitest/node_modules/esbuild@0.21.5`. .
- **eslint** (low): `node_modules/eslint@9.17.0`. propagated from @eslint/plugin-kit.
- **extract-zip** (high): `node_modules/extract-zip@2.0.1`. .
- **fast-uri** (high): `node_modules/fast-uri@3.1.2`. .
- **global-agent** (moderate): `node_modules/global-agent@3.0.0`. propagated from roarr.
- **http-cache-semantics** (high): `node_modules/http-cache-semantics@4.2.0`. .
- **ip-address** (high): `node_modules/ip-address@10.2.0`. .
- **js-yaml** (high): `node_modules/js-yaml@4.2.0`. .
- **make-fetch-happen** (high): `node_modules/make-fetch-happen@10.2.1`. propagated from cacache.
- **nanoid** (high): `node_modules/nanoid@3.3.12`. .
- **node-gyp** (high): `node_modules/node-gyp@9.4.1`. propagated from make-fetch-happen; propagated from tar.
- **playwright** (high): `node_modules/playwright@1.49.1`. .
- **postcss** (high): `node_modules/postcss@8.5.15`. .
- **postcss-selector-parser** (moderate): `node_modules/postcss-selector-parser@7.1.5`. .
- **roarr** (moderate): `node_modules/roarr@2.15.4`. propagated from sprintf-js.
- **source-map-js** (high): `node_modules/source-map-js@1.2.1`. .
- **sprintf-js** (moderate): `node_modules/sprintf-js@1.1.3`. .
- **tar** (critical): `node_modules/tar@6.2.1`. .
- **tar-fs** (high): `node_modules/dockerode/node_modules/tar-fs@2.0.1`. .
- **testcontainers** (high): `node_modules/testcontainers@10.17.2`. propagated from dockerode; propagated from undici.
- **tinypool** (critical): `node_modules/tinypool@1.1.1`. .
- **undici** (high): `node_modules/jsdom/node_modules/undici@7.29.0`, `node_modules/undici@5.29.0`. propagated from @fastify/busboy.
- **vite** (high): `node_modules/vite@6.0.7`, `node_modules/vite-node/node_modules/vite@5.4.21`, `node_modules/vitest/node_modules/vite@5.4.21`. propagated from esbuild.
- **vite-node** (moderate): `node_modules/vite-node@2.1.8`. propagated from vite.
- **vitest** (critical): `node_modules/vitest@2.1.8`. propagated from @vitest/mocker; propagated from tinypool; propagated from vite; propagated from vite-node.
- **vue** (high): `node_modules/vue@3.5.13`. propagated from @vue/server-renderer.

Direct advisory records (deduplicated):

- [GHSA-xffm-g5w8-qvg7](https://github.com/advisories/GHSA-xffm-g5w8-qvg7): @eslint/plugin-kit is vulnerable to Regular Expression Denial of Service attacks through ConfigCommentParser; affected `<0.3.4`.
- [GHSA-x8mw-p69m-v3mx](https://github.com/advisories/GHSA-x8mw-p69m-v3mx): @fastify/busboy vulnerable to Denial of Service via prototype-named multipart part header; affected `>=1.0.0 <3.2.1`.
- [GHSA-gxm5-99cw-xjw9](https://github.com/advisories/GHSA-gxm5-99cw-xjw9): @fastify/busboy vulnerable to CRLF injection via multipart Content-Disposition filename and name; affected `<3.2.2`.
- [GHSA-82fw-gwwq-j7x9](https://github.com/advisories/GHSA-82fw-gwwq-j7x9): Vitest: Path Traversal / Arbitrary File Read via @vitest/mocker Redirect Mock; affected `>=2.1.0 <4.1.11`.
- [GHSA-g2v6-rqmx-r4w6](https://github.com/advisories/GHSA-g2v6-rqmx-r4w6): @vue/server-renderer: XSS via missing CR in attribute-name blacklist; affected `<3.5.42`.
- [GHSA-6gmq-8vp8-gcm6](https://github.com/advisories/GHSA-6gmq-8vp8-gcm6): xmldom: XML fragment injection via invalid EntityReference.nodeName during requireWellFormed serialization; affected `>=0.9.0 <=0.9.11`.
- [GHSA-6mj3-qw4j-hgrw](https://github.com/advisories/GHSA-6mj3-qw4j-hgrw): xmldom: HTML raw-text closing-tag case mismatch causes output amplification; affected `>=0.9.0-beta.1 <=0.9.11`.
- [GHSA-g53g-w8rj-fmg7](https://github.com/advisories/GHSA-g53g-w8rj-fmg7): xmldom PI grammar regex ReDoS: quadratic backtracking on unterminated processing instructions; affected `>=0.9.0-beta.9 <=0.9.10`.
- [GHSA-w2rr-34g9-rvrj](https://github.com/advisories/GHSA-w2rr-34g9-rvrj): xmldom: Element name injection via createElement() bypasses requireWellFormed; affected `>=0.9.0 <=0.9.10`.
- [GHSA-4w3w-2rp5-g8jm](https://github.com/advisories/GHSA-4w3w-2rp5-g8jm): xmldom: Attribute name injection via setAttribute() bypasses requireWellFormed; affected `>=0.9.0 <=0.9.10`.
- [GHSA-c7q8-3ch8-vqpv](https://github.com/advisories/GHSA-c7q8-3ch8-vqpv): xmldom: Processing Instruction Target Injection Bypasses requireWellFormed; affected `>=0.9.0 <=0.9.11`.
- [GHSA-27p8-2357-5qqv](https://github.com/advisories/GHSA-27p8-2357-5qqv): xmldom: DocType `name` Injection Bypasses requireWellFormed; affected `>=0.9.0 <=0.9.11`.
- [GHSA-3px3-54cx-rmw9](https://github.com/advisories/GHSA-3px3-54cx-rmw9): xmldom: Creation-time XML Name/QName validation is bypassable via an embedded line terminator, allowing injection on the default serialization path; affected `>=0.9.0 <=0.9.11`.
- [GHSA-vr34-hp96-76pp](https://github.com/advisories/GHSA-vr34-hp96-76pp): xmldom: requireWellFormed DocType publicId/systemId validation is bypassable via an embedded line terminator; affected `>=0.9.10 <=0.9.11`.
- [GHSA-6h8r-xr42-gp59](https://github.com/advisories/GHSA-6h8r-xr42-gp59): xmldom: Parser silently accepts a not-well-formed end tag whose name is followed by a line break and trailing content; affected `>=0.9.0 <=0.9.11`.
- [GHSA-8344-3jmq-59r6](https://github.com/advisories/GHSA-8344-3jmq-59r6): xmldom: Quadratic-time attribute deduplication; affected `>=0.9.0 <=0.9.11`.
- [GHSA-965w-775f-mr7g](https://github.com/advisories/GHSA-965w-775f-mr7g): xmldom: Quadratic-memory consumption; affected `>=0.9.0 <=0.9.11`.
- [GHSA-93r5-fhx6-vmg9](https://github.com/advisories/GHSA-93r5-fhx6-vmg9): xmldom: Quadratic-time parsing via the malformed-input recovery path — `parseElementStartPart` re-scan and `normalize()` adjacent-text merge; affected `>=0.9.0 <=0.9.11`.
- [GHSA-7g7r-gx96-252g](https://github.com/advisories/GHSA-7g7r-gx96-252g): electron-updater: Uncontrolled search path elements within `AppImage` built by `app-builder-lib`; affected `<26.15.0`.
- [GHSA-w5vr-8v7q-w6rv](https://github.com/advisories/GHSA-w5vr-8v7q-w6rv): baseline-browser-mapping process termination on invalid input causes denial of service; affected `>=2.0.0 <2.11.0`.
- [GHSA-3jxr-9vmj-r5cp](https://github.com/advisories/GHSA-3jxr-9vmj-r5cp): brace-expansion: DoS via exponential-time expansion of consecutive non-expanding {} groups; affected `>=3.0.0 <5.0.7`.
- [GHSA-mh99-v99m-4gvg](https://github.com/advisories/GHSA-mh99-v99m-4gvg): brace-expansion: DoS via unbounded expansion length causing an out-of-memory process crash; affected `>=4.0.0 <5.0.8`.
- [GHSA-rgw5-rvv9-x895](https://github.com/advisories/GHSA-rgw5-rvv9-x895): brace-expansion: DoS via unbounded intermediate arrays, bypassing the CVE-2026-14257 mitigation; affected `<1.1.18`.
- [GHSA-q2hr-2g5m-vwhr](https://github.com/advisories/GHSA-q2hr-2g5m-vwhr): brace-expansion: Quadratic-time expansion of the `{a},b}` rewrite causes CPU denial of service; affected `>=4.0.0 <5.0.12`.
- [GHSA-qhr7-859c-m2p7](https://github.com/advisories/GHSA-qhr7-859c-m2p7): brace-expansion: DoS via uncontrolled recursion on nested brace groups causing stack exhaustion; affected `>=4.0.0 <5.0.11`.
- [GHSA-6j4f-fj2g-mc7p](https://github.com/advisories/GHSA-6j4f-fj2g-mc7p): brace-expansion: DoS via uncontrolled recursion in parseCommaParts causing stack exhaustion; affected `>=4.0.0 <5.0.10`.
- [GHSA-c83g-rgw3-j3cx](https://github.com/advisories/GHSA-c83g-rgw3-j3cx): Browserslist: Unbounded memory growth (no cache eviction) via distinct query results, leading to eventual OOM; affected `<=4.28.6`.
- [GHSA-73wf-gq98-2v4g](https://github.com/advisories/GHSA-73wf-gq98-2v4g): Browserslist: Uncaught crash / prototype write via untrusted browserslist-stats.json custom stats (normalizeStats); affected `<=4.28.6`.
- [GHSA-p2f4-r6v6-j797](https://github.com/advisories/GHSA-p2f4-r6v6-j797): electron-updater: Cross-origin redirect leaks `PRIVATE-TOKEN` and mixed-case `Authorization` credentials in `builder-util-runtime`; affected `<9.7.0`.
- [GHSA-vmqv-hx8q-j7mg](https://github.com/advisories/GHSA-vmqv-hx8q-j7mg): Electron has ASAR Integrity Bypass via resource modification; affected `<35.7.5`.
- [GHSA-5rqw-r77c-jp79](https://github.com/advisories/GHSA-5rqw-r77c-jp79): Electron: AppleScript injection in app.moveToApplicationsFolder on macOS; affected `<38.8.6`.
- [GHSA-xj5x-m3f3-5x3h](https://github.com/advisories/GHSA-xj5x-m3f3-5x3h): Electron: Service worker can spoof executeJavaScript IPC replies; affected `<38.8.6`.
- [GHSA-r5p7-gp4j-qhrx](https://github.com/advisories/GHSA-r5p7-gp4j-qhrx): Electron: Incorrect origin passed to permission request handler for iframe requests; affected `<38.8.6`.
- [GHSA-3c8v-cfp5-9885](https://github.com/advisories/GHSA-3c8v-cfp5-9885): Electron: Out-of-bounds read in second-instance IPC on macOS and Linux; affected `<38.8.6`.
- [GHSA-xwr5-m59h-vwqr](https://github.com/advisories/GHSA-xwr5-m59h-vwqr): Electron: nodeIntegrationInWorker not correctly scoped in shared renderer processes; affected `<38.8.6`.
- [GHSA-532v-xpq5-8h95](https://github.com/advisories/GHSA-532v-xpq5-8h95): Electron: Use-after-free in offscreen child window paint callback; affected `<39.8.1`.
- [GHSA-mwmh-mq4g-g6gr](https://github.com/advisories/GHSA-mwmh-mq4g-g6gr): Electron: Registry key path injection in app.setAsDefaultProtocolClient on Windows; affected `<38.8.6`.
- [GHSA-9w97-2464-8783](https://github.com/advisories/GHSA-9w97-2464-8783): Electron: Use-after-free in download save dialog callback; affected `<38.8.6`.
- [GHSA-8337-3p73-46f4](https://github.com/advisories/GHSA-8337-3p73-46f4): Electron: Use-after-free in WebContents fullscreen, pointer-lock, and keyboard-lock permission callbacks; affected `<38.8.6`.
- [GHSA-jjp3-mq3x-295m](https://github.com/advisories/GHSA-jjp3-mq3x-295m): Electron: Use-after-free in PowerMonitor on Windows and macOS; affected `<38.8.6`.
- [GHSA-jfqx-fxh3-c62j](https://github.com/advisories/GHSA-jfqx-fxh3-c62j): Electron: Unquoted executable path in app.setLoginItemSettings on Windows; affected `<38.8.6`.
- [GHSA-4p4r-m79c-wq3v](https://github.com/advisories/GHSA-4p4r-m79c-wq3v): Electron: HTTP Response Header Injection in custom protocol handlers and webRequest; affected `<38.8.6`.
- [GHSA-9899-m83m-qhpj](https://github.com/advisories/GHSA-9899-m83m-qhpj): Electron: USB device selection not validated against filtered device list; affected `<38.8.6`.
- [GHSA-8x5q-pvf5-64mp](https://github.com/advisories/GHSA-8x5q-pvf5-64mp): Electron: Use-after-free in offscreen shared texture release() callback; affected `>=33.0.0-alpha.1 <39.8.5`.
- [GHSA-f37v-82c4-4x64](https://github.com/advisories/GHSA-f37v-82c4-4x64): Electron: Crash in clipboard.readImage() on malformed clipboard image data; affected `<39.8.5`.
- [GHSA-f3pv-wv63-48x8](https://github.com/advisories/GHSA-f3pv-wv63-48x8): Electron: Named window.open targets not scoped to the opener's browsing context; affected `<39.8.5`.
- [GHSA-9wfr-w7mm-pc7f](https://github.com/advisories/GHSA-9wfr-w7mm-pc7f): Electron: Renderer command-line switch injection via undocumented commandLineSwitches webPreference; affected `<38.8.6`.
- [GHSA-jm7p-cc5g-qwxx](https://github.com/advisories/GHSA-jm7p-cc5g-qwxx): Electron: Parent process code-sign check is spoofable; affected `<39.8.8`.
- [GHSA-v3j7-r9gq-3gjw](https://github.com/advisories/GHSA-v3j7-r9gq-3gjw): Electron: Custom protocol with supportFetchAPI but not corsEnabled allows cross-origin reads; affected `<39.8.10`.
- [GHSA-m55f-7gqj-fr98](https://github.com/advisories/GHSA-m55f-7gqj-fr98): Electron: Extension tab APIs operate across session boundaries; affected `<39.8.8`.
- [GHSA-5c9j-mhmv-5xgx](https://github.com/advisories/GHSA-5c9j-mhmv-5xgx): Electron: shell.openPath path validation bypass via embedded null byte; affected `<39.8.6`.
- [GHSA-h7rp-cf8h-j98x](https://github.com/advisories/GHSA-h7rp-cf8h-j98x): Electron: Context isolation bypass via Function.prototype.bind hijack; affected `<39.8.9`.
- [GHSA-x8rc-wpg4-grpf](https://github.com/advisories/GHSA-x8rc-wpg4-grpf): Electron: Cross-origin iframe can position native autofill popup; affected `<39.8.8`.
- [GHSA-9pf5-hg6p-4pwp](https://github.com/advisories/GHSA-9pf5-hg6p-4pwp): Electron: Permission Check Handler Receives Main Frame Origin Instead of Requesting Iframe Origin; affected `<39.8.7`.
- [GHSA-pfmc-3mgc-p6fp](https://github.com/advisories/GHSA-pfmc-3mgc-p6fp): Electron: Off-screen rendering trusts GPU-supplied geometry over shared-memory size; affected `<39.8.10`.
- [GHSA-v64r-4m7r-3mvq](https://github.com/advisories/GHSA-v64r-4m7r-3mvq): Electron: HTTP redirect followed into local file loader; affected `<39.8.8`.
- [GHSA-v93f-fgjr-hjrj](https://github.com/advisories/GHSA-v93f-fgjr-hjrj): Electron: window.open features string controls some window options considered privileged; affected `<39.8.8`.
- [GHSA-9f4c-93c8-jc8g](https://github.com/advisories/GHSA-9f4c-93c8-jc8g): Electron: Sandboxed iframe can bypass the allow-popups restriction via the OpenURL navigation path; affected `<39.8.10`.
- [GHSA-p2rr-rvmm-c5fp](https://github.com/advisories/GHSA-p2rr-rvmm-c5fp): Electron: Sandboxed iframes can launch external protocol handlers; affected `<39.8.8`.
- [GHSA-f2r8-jv7c-xqmp](https://github.com/advisories/GHSA-f2r8-jv7c-xqmp): Electron: DevTools embedder handler executes arbitrary files via shell open; affected `<39.8.9`.
- [GHSA-ff2p-hmqr-hxm4](https://github.com/advisories/GHSA-ff2p-hmqr-hxm4): Electron: contextBridge object copy honors prototype setters; affected `<39.8.9`.
- [GHSA-4f78-qhmw-8j8m](https://github.com/advisories/GHSA-4f78-qhmw-8j8m): Electron: DevTools JavaScript Injection via Unsanitized Dock State Parameter; affected `<39.8.7`.
- [GHSA-hq2x-r82h-9wj4](https://github.com/advisories/GHSA-hq2x-r82h-9wj4): Electron drops inherited HTML sandbox restrictions for popups opened through OpenURLFromTab; affected `<41.10.4`.
- [GHSA-gr2m-v5gq-v685](https://github.com/advisories/GHSA-gr2m-v5gq-v685): Electron: Windows opened from a sandboxed top-level document do not inherit its sandbox restrictions; affected `<41.10.6`.
- [GHSA-j84w-jfhq-vhvj](https://github.com/advisories/GHSA-j84w-jfhq-vhvj): Electron: File and HTTP protocol handlers allow cross-origin reads without corsEnabled; affected `<41.10.6`.
- [GHSA-9qh4-3jw8-366w](https://github.com/advisories/GHSA-9qh4-3jw8-366w): Electron: <webview> can enable Node.js integration in Web Workers despite embedder restrictions; affected `<41.10.6`.
- [GHSA-vv43-5jgx-7qv8](https://github.com/advisories/GHSA-vv43-5jgx-7qv8): Electron: Local race condition in Squirrel.Mac update installation on macOS; affected `<39.8.10`.
- [GHSA-67mh-4wv8-2f99](https://github.com/advisories/GHSA-67mh-4wv8-2f99): esbuild enables any website to send any requests to the development server and read the response; affected `<=0.24.2`.
- [GHSA-jmr9-qjv8-65gv](https://github.com/advisories/GHSA-jmr9-qjv8-65gv): extract-zip unvalidated symlink path traversal; affected `<=2.0.1`.
- [GHSA-7pqw-9j4j-h8q3](https://github.com/advisories/GHSA-7pqw-9j4j-h8q3): extract-zip allows arbitrary file writes through symlink archive entries; affected `<=2.0.1`.
- [GHSA-v2hh-gcrm-f6hx](https://github.com/advisories/GHSA-v2hh-gcrm-f6hx): fast-uri vulnerable to host confusion via literal backslash authority delimiter; affected `>=3.0.0 <=3.1.3`.
- [GHSA-7p8r-x3mc-p8w7](https://github.com/advisories/GHSA-7p8r-x3mc-p8w7): fast-uri vulnerable to host confusion via backslash authority introducer; affected `>=3.0.0 <3.1.5`.
- [GHSA-f65p-4m7j-42xc](https://github.com/advisories/GHSA-f65p-4m7j-42xc): fast-uri vulnerable to server-side request forgery via malformed IPv6 normalization; affected `>=3.0.0 <3.1.6`.
- [GHSA-fph4-wmhf-6fwf](https://github.com/advisories/GHSA-fph4-wmhf-6fwf): fast-uri vulnerable to server-side request forgery via repeated hostname percent-decoding; affected `>=3.1.2 <3.1.6`.
- [GHSA-jqff-g426-hqxp](https://github.com/advisories/GHSA-jqff-g426-hqxp): fast-uri vulnerable to host confusion via percent-encoded scheme normalization; affected `>=3.0.0 <3.1.6`.
- [GHSA-4c8g-83qw-93j6](https://github.com/advisories/GHSA-4c8g-83qw-93j6): fast-uri vulnerable to host confusion via failed IDN canonicalization; affected `>=3.0.0 <3.1.3`.
- [GHSA-qw65-cvwx-89v3](https://github.com/advisories/GHSA-qw65-cvwx-89v3): fast-uri vulnerable to authority injection via an unvalidated port in serialize; affected `>=3.0.0 <3.1.7`.
- [GHSA-hrr3-gc8f-f4qj](https://github.com/advisories/GHSA-hrr3-gc8f-f4qj): fast-uri vulnerable to inconsistent host case normalization via percent-encoded octets; affected `>=3.0.0 <3.1.8`.
- [GHSA-ch52-4w7c-c8xp](https://github.com/advisories/GHSA-ch52-4w7c-c8xp): http-cache-semantics max-stale handling can disclose cross-user cached responses; affected `<=4.2.0`.
- [GHSA-mwp4-54f8-5fhr](https://github.com/advisories/GHSA-mwp4-54f8-5fhr): ip-address: Address4 decodes leading-zero octets as decimal while resolvers decode them as octal, allowing SSRF and trust-boundary bypass; affected `<=10.3.0`.
- [GHSA-4xrf-jv44-h6hh](https://github.com/advisories/GHSA-4xrf-jv44-h6hh): ip-address: a CIDR suffix on the parsed address suppresses special-use classification and can bypass SSRF and trust-boundary checks; affected `>=10.1.1 <=10.2.1`.
- [GHSA-22jq-vg5j-6vgg](https://github.com/advisories/GHSA-22jq-vg5j-6vgg): ip-address: misclassification of IPv4-mapped/NAT64 IPv6 addresses can bypass SSRF and trust-boundary checks; affected `>=10.1.1 <=10.2.0`.
- [GHSA-rpw4-54j3-4h4q](https://github.com/advisories/GHSA-rpw4-54j3-4h4q): ip-address: Address6.isLinkLocal() recognizes fe80::/64 rather than fe80::/10, allowing SSRF and trust-boundary bypass to on-link hosts; affected `<=10.5.0`.
- [GHSA-2vr4-cq9g-pvrc](https://github.com/advisories/GHSA-2vr4-cq9g-pvrc): ip-address: no classifier recognizes the NAT64 local-use range 64:ff9b:1::/48, allowing SSRF and trust-boundary bypass; affected `>=10.2.0 <=10.5.0`.
- [GHSA-j6r3-76f7-8jcv](https://github.com/advisories/GHSA-j6r3-76f7-8jcv): ip-address: isInSubnet() and isHostInSubnet() compare addresses of different families as if they shared an address space, allowing an allowlist check to admit an address outside its range; affected `<=10.7.0`.
- [GHSA-h3mg-xc3c-68pw](https://github.com/advisories/GHSA-h3mg-xc3c-68pw): ip-address: Address6 builds a parse diagnostic proportional to the input with no length bound, allowing a single long string to stall or crash the process; affected `<=10.7.0`.
- [GHSA-52cp-r559-cp3m](https://github.com/advisories/GHSA-52cp-r559-cp3m): js-yaml: YAML merge-key chains can force quadratic CPU consumption; affected `>=4.0.0 <4.3.0`.
- [GHSA-5p4m-2wfm-xmqj](https://github.com/advisories/GHSA-5p4m-2wfm-xmqj): JS-YAML: Quadratic CPU consumption in !!omap resolution (3.x and 4.x) — CVE-2026-59870 fix not backported; affected `>=4.0.0 <4.3.1`.
- [GHSA-2883-xcg3-v3hh](https://github.com/advisories/GHSA-2883-xcg3-v3hh): js-yaml: maxTotalMergeKeys does not limit CPU use for empty merge sources; affected `>=4.0.0 <4.3.2`.
- [GHSA-28wg-ghj8-5hjv](https://github.com/advisories/GHSA-28wg-ghj8-5hjv): nanoid: non-secure generators can loop indefinitely with negative size; affected `<3.3.16`.
- [GHSA-2v37-7h3g-55p8](https://github.com/advisories/GHSA-2v37-7h3g-55p8): nanoid: custom generators can loop indefinitely when size is zero; affected `<3.3.18`.
- [GHSA-7mvr-c777-76hp](https://github.com/advisories/GHSA-7mvr-c777-76hp): Playwright downloads and installs browsers without verifying the authenticity of the SSL certificate; affected `<1.55.1`.
- [GHSA-fxqj-rqcc-2cmp](https://github.com/advisories/GHSA-fxqj-rqcc-2cmp): PostCSS: incomplete fix of GHSA-6g55-p6wh-862q — attacker-controlled sourceMappingURL reads arbitrary .map files when `from` is unset; affected `<=8.5.22`.
- [GHSA-r28c-9q8g-f849](https://github.com/advisories/GHSA-r28c-9q8g-f849): PostCSS: Path Traversal in Previous Source Map Auto-Loading (sourceMappingURL) leads to Arbitrary .map File Disclosure; affected `<=8.5.17`.
- [GHSA-rj75-hqrm-r3gf](https://github.com/advisories/GHSA-rj75-hqrm-r3gf): PostCSS: Quadratic complexity in flat selector parsing allows CPU exhaustion; affected `<7.1.6`.
- [GHSA-68fv-2mgg-jv7q](https://github.com/advisories/GHSA-68fv-2mgg-jv7q): source-map-js allows event-loop denial of service through indexed source-map section offsets; affected `>=1.0.0 <1.2.2`.
- [GHSA-hp3w-g68c-fv3c](https://github.com/advisories/GHSA-hp3w-g68c-fv3c): sprintf-js vulnerable to denial of service through unbounded precision specifiers; affected `<=1.1.3`.
- [GHSA-34x7-hfp2-rc4v](https://github.com/advisories/GHSA-34x7-hfp2-rc4v): node-tar Vulnerable to Arbitrary File Creation/Overwrite via Hardlink Path Traversal; affected `<7.5.7`.
- [GHSA-8qq5-rm4j-mr97](https://github.com/advisories/GHSA-8qq5-rm4j-mr97): node-tar is Vulnerable to Arbitrary File Overwrite and Symlink Poisoning via Insufficient Path Sanitization; affected `<=7.5.2`.
- [GHSA-83g3-92jg-28cx](https://github.com/advisories/GHSA-83g3-92jg-28cx): Arbitrary File Read/Write via Hardlink Target Escape Through Symlink Chain in node-tar Extraction; affected `<7.5.8`.
- [GHSA-qffp-2rhf-9h96](https://github.com/advisories/GHSA-qffp-2rhf-9h96): tar has Hardlink Path Traversal via Drive-Relative Linkpath; affected `<=7.5.9`.
- [GHSA-9ppj-qmqm-q256](https://github.com/advisories/GHSA-9ppj-qmqm-q256): node-tar Symlink Path Traversal via Drive-Relative Linkpath; affected `<=7.5.10`.
- [GHSA-r6q2-hw4h-h46w](https://github.com/advisories/GHSA-r6q2-hw4h-h46w): Race Condition in node-tar Path Reservations via Unicode Ligature Collisions on macOS APFS; affected `<=7.5.3`.
- [GHSA-vmf3-w455-68vh](https://github.com/advisories/GHSA-vmf3-w455-68vh): node-tar applies PAX size override to intermediary GNU long-name/long-link headers, causing tar parser interpretation differential (file smuggling); affected `<=7.5.15`.
- [GHSA-w8wr-v893-vjvp](https://github.com/advisories/GHSA-w8wr-v893-vjvp): node-tar: Process crash via PAX numeric path type confusion; affected `<=7.5.17`.
- [GHSA-23hp-3jrh-7fpw](https://github.com/advisories/GHSA-23hp-3jrh-7fpw): node-tar: Decompression/parse DoS via unlimited input; affected `<=7.5.18`.
- [GHSA-8x88-c5mf-7j5w](https://github.com/advisories/GHSA-8x88-c5mf-7j5w): node-tar: Negative tar entry size causes infinite loop in archive replace; affected `<=7.5.17`.
- [GHSA-gvwx-54wh-qm9j](https://github.com/advisories/GHSA-gvwx-54wh-qm9j): node-tar: Uncaught Exception DoS via NUL byte in PAX path/linkpath records; affected `<=7.5.16`.
- [GHSA-r292-9mhp-454m](https://github.com/advisories/GHSA-r292-9mhp-454m): node-tar: Uncontrolled recursion in mapHas/filesFilter allows uncatchable stack-overflow DoS via crafted long-path tar with member selection; affected `<=7.5.20`.
- [GHSA-vj76-c3g6-qr5v](https://github.com/advisories/GHSA-vj76-c3g6-qr5v): tar-fs has a symlink validation bypass if destination directory is predictable with a specific tarball; affected `>=2.0.0 <2.1.4`.
- [GHSA-8cj5-5rvv-wf4v](https://github.com/advisories/GHSA-8cj5-5rvv-wf4v): tar-fs can extract outside the specified dir with a specific tarball; affected `>=2.0.0 <2.1.3`.
- [GHSA-pq67-2wwv-3xjx](https://github.com/advisories/GHSA-pq67-2wwv-3xjx): tar-fs Vulnerable to Link Following and Path Traversal via Extracting a Crafted tar File; affected `>=2.0.0 <2.1.2`.
- [GHSA-5gmw-xhrv-c9v3](https://github.com/advisories/GHSA-5gmw-xhrv-c9v3): Tinypool: Prototype Pollution gadget in worker options leads to Remote Code Execution; affected `<=2.1.0`.
- [GHSA-85c8-ppgw-ccpr](https://github.com/advisories/GHSA-85c8-ppgw-ccpr): Tinypool: Prototype Pollution Gadget to RCE in run() options; affected `<2.1.2`.
- [GHSA-g9mf-h72j-4rw9](https://github.com/advisories/GHSA-g9mf-h72j-4rw9): Undici has an unbounded decompression chain in HTTP responses on Node.js Fetch API via Content-Encoding leads to resource exhaustion; affected `<6.23.0`.
- [GHSA-2mjp-6q6p-2qxm](https://github.com/advisories/GHSA-2mjp-6q6p-2qxm): Undici has an HTTP Request/Response Smuggling issue; affected `<6.24.0`.
- [GHSA-vrm6-8vpv-qv8q](https://github.com/advisories/GHSA-vrm6-8vpv-qv8q): Undici has Unbounded Memory Consumption in WebSocket permessage-deflate Decompression; affected `<6.24.0`.
- [GHSA-v9p9-hfj2-hcw8](https://github.com/advisories/GHSA-v9p9-hfj2-hcw8): Undici has Unhandled Exception in WebSocket Client Due to Invalid server_max_window_bits Validation; affected `<6.24.0`.
- [GHSA-4992-7rv2-5pvq](https://github.com/advisories/GHSA-4992-7rv2-5pvq): Undici has CRLF Injection in undici via `upgrade` option; affected `<6.24.0`.
- [GHSA-p88m-4jfj-68fv](https://github.com/advisories/GHSA-p88m-4jfj-68fv): undici vulnerable to HTTP header injection via Set-Cookie percent-decoding; affected `<6.27.0`.
- [GHSA-vxpw-j846-p89q](https://github.com/advisories/GHSA-vxpw-j846-p89q): undici WebSocket client vulnerable to denial of service via fragment count bypass; affected `<6.27.0`.
- [GHSA-g8m3-5g58-fq7m](https://github.com/advisories/GHSA-g8m3-5g58-fq7m): undici vulnerable to Set-Cookie SameSite attribute downgrade via permissive substring matching; affected `<6.27.0`.
- [GHSA-8xcm-r25x-g524](https://github.com/advisories/GHSA-8xcm-r25x-g524): undici vulnerable to downstream response desynchronization via retry interceptor; affected `<6.28.0`.
- [GHSA-m8rv-5g2x-5cg5](https://github.com/advisories/GHSA-m8rv-5g2x-5cg5): undici vulnerable to CRLF Injection via blob-like body 'type' property; affected `<6.28.0`.
- [GHSA-v3r7-h72x-cjcm](https://github.com/advisories/GHSA-v3r7-h72x-cjcm): undici vulnerable to cookie attribute injection via unsanitized domain and unparsed setCookie fields; affected `<6.28.0`.
- [GHSA-35p6-xmwp-9g52](https://github.com/advisories/GHSA-35p6-xmwp-9g52): undici vulnerable to HTTP response queue poisoning via keep-alive socket reuse; affected `<6.27.0`.
- [GHSA-3wwx-pv8p-q78v](https://github.com/advisories/GHSA-3wwx-pv8p-q78v): undici vulnerable to Denial of Service via unhandled error in WebSocket permessage-deflate decompression; affected `>=7.28.0 <7.29.1`.
- [GHSA-pmjh-fq2x-6v4x](https://github.com/advisories/GHSA-pmjh-fq2x-6v4x): undici vulnerable to Denial of Service via orphaned RetryHandler response body; affected `>=7.11.0 <7.29.1`.
- [GHSA-r53p-7pc4-xj5r](https://github.com/advisories/GHSA-r53p-7pc4-xj5r): undici vulnerable to downstream response splitting via retry interceptor; affected `<6.28.1`.
- [GHSA-rfgv-xxqx-mfg5](https://github.com/advisories/GHSA-rfgv-xxqx-mfg5): undici vulnerable to Denial of Service via unrequested WebSocket subprotocol; affected `>=7.0.0 <7.29.1`.
- [GHSA-3xpg-4rpp-hhhm](https://github.com/advisories/GHSA-3xpg-4rpp-hhhm): undici vulnerable to Denial of Service via unbounded decompression of compressed responses; affected `>=7.15.0 <7.29.1`.
- [GHSA-2jfj-6hjv-fm6j](https://github.com/advisories/GHSA-2jfj-6hjv-fm6j): undici vulnerable to cross-user cookie disclosure via Set-Cookie caching in shared caches; affected `>=7.0.0 <7.29.1`.
- [GHSA-2gqq-gqf2-x968](https://github.com/advisories/GHSA-2gqq-gqf2-x968): undici vulnerable to response truncation via oversized chunked responses in the dump interceptor; affected `>=7.1.0 <7.29.1`.
- [GHSA-w293-vg96-wgc3](https://github.com/advisories/GHSA-w293-vg96-wgc3): undici vulnerable to TLS certificate validation bypass via dropped connect options in BalancedPool; affected `>=7.24.1 <7.29.1`.
- [GHSA-8436-99hf-9mmv](https://github.com/advisories/GHSA-8436-99hf-9mmv): undici vulnerable to caching and replay of unsafe HTTP method responses; affected `>=7.0.0 <7.29.1`.
- [GHSA-rx4f-c7p8-82vq](https://github.com/advisories/GHSA-rx4f-c7p8-82vq): undici vulnerable to Denial of Service via WebSocketStream unclean close; affected `>=7.0.0 <7.29.1`.
- [GHSA-vg6x-rcgg-rjx6](https://github.com/advisories/GHSA-vg6x-rcgg-rjx6): Websites were able to send any requests to the development server and read the response in vite; affected `>=6.0.0 <=6.0.8`.
- [GHSA-x574-m823-4x7w](https://github.com/advisories/GHSA-x574-m823-4x7w): Vite bypasses server.fs.deny when using ?raw??; affected `>=6.0.0 <6.0.12`.
- [GHSA-356w-63v5-8wf4](https://github.com/advisories/GHSA-356w-63v5-8wf4): Vite has an `server.fs.deny` bypass with an invalid `request-target`; affected `>=6.0.0 <6.0.15`.
- [GHSA-859w-5945-r5v3](https://github.com/advisories/GHSA-859w-5945-r5v3): Vite's server.fs.deny bypassed with /. for files under project root; affected `>=6.0.0 <=6.1.5`.
- [GHSA-xcj6-pq6g-qj4x](https://github.com/advisories/GHSA-xcj6-pq6g-qj4x): Vite allows server.fs.deny to be bypassed with .svg or relative paths; affected `>=6.0.0 <6.0.14`.
- [GHSA-g4jq-h2w9-997c](https://github.com/advisories/GHSA-g4jq-h2w9-997c): Vite middleware may serve files starting with the same name with the public directory; affected `>=6.0.0 <=6.3.5`.
- [GHSA-jqfw-vq24-v9c3](https://github.com/advisories/GHSA-jqfw-vq24-v9c3): Vite's `server.fs` settings were not applied to HTML files; affected `>=6.0.0 <=6.3.5`.
- [GHSA-93m4-6634-74q7](https://github.com/advisories/GHSA-93m4-6634-74q7): vite allows server.fs.deny bypass via backslash on Windows; affected `>=6.0.0 <=6.4.0`.
- [GHSA-4r4m-qw57-chr8](https://github.com/advisories/GHSA-4r4m-qw57-chr8): Vite has a `server.fs.deny` bypassed for `inline` and `raw` with `?import` query; affected `>=6.0.0 <6.0.13`.
- [GHSA-4w7w-66w2-5vf9](https://github.com/advisories/GHSA-4w7w-66w2-5vf9): Vite Vulnerable to Path Traversal in Optimized Deps `.map` Handling; affected `<=6.4.1`.
- [GHSA-p9ff-h696-f583](https://github.com/advisories/GHSA-p9ff-h696-f583): Vite Vulnerable to Arbitrary File Read via Vite Dev Server WebSocket; affected `>=6.0.0 <=6.4.1`.
- [GHSA-v6wh-96g9-6wx3](https://github.com/advisories/GHSA-v6wh-96g9-6wx3): launch-editor: NTLMv2 hash disclosure via UNC path handling on Windows; affected `<=6.4.2`.
- [GHSA-fx2h-pf6j-xcff](https://github.com/advisories/GHSA-fx2h-pf6j-xcff): vite: `server.fs.deny` bypass on Windows alternate paths; affected `<=6.4.2`.
- [GHSA-9crc-q9x8-hgqq](https://github.com/advisories/GHSA-9crc-q9x8-hgqq): Vitest allows Remote Code Execution when accessing a malicious website while Vitest API server is listening; affected `>=2.0.0 <2.1.9`.
- [GHSA-5xrq-8626-4rwp](https://github.com/advisories/GHSA-5xrq-8626-4rwp): When Vitest UI server is listening, arbitrary file can be read and executed; affected `<3.2.6`.
