# internal/identity — account identity and device registry

Package `internal/identity` owns two questions for the gateway:

1. **Who is this user?** — verified from a Google ID token (issuer, audience,
   expiry, RS256 signature against Google's JWKS, verified email, and the
   rollout email allowlist). The stable account identifier is
   `google:<sub>` — issuer + subject, **never** the email, which is mutable
   display data.
2. **Which devices may reach whose hosts?** — a durable, atomically
   persisted registry of enrolled devices, each holding an Ed25519 public
   key and the pinned SSH public host key of a real host, owned by exactly
   one verified account.

The package is stdlib-only and does **not** import `internal/tunnel`.
The tunnel worker consumes `identity.Store` and `identity.Authenticate`;
this package never reaches into tunnel concerns.

> **v2 enrollment signing (breaking, 2026-10-07).** Enrollment signatures
> now cover the full registration payload, not just the challenge. The
> earlier bare-challenge format is **rejected with no fallback** — an
> altered SSH host key under an unaltered challenge signature was accepted
> by the previous format. Every enroller (tunnel CLI `--enroll`) must use
> `identity.SignEnrollment` as described under *Enrollment flow* below.

## Contract surface

```go
type Principal struct {
    AccountID string    // "google:<sub>" — stable issuer+subject
    Email     string    // verified email; display/allowlist only
    ExpiresAt time.Time // token expiry; zero if unknown
}
type Authenticate func(context.Context, string) (Principal, error)
type Device struct {
    ID         string
    AccountID  string
    PublicKey  []byte // raw 32-byte Ed25519 public key
    SSHHostKey string // pinned OpenSSH public host key line
    Revoked    bool
}
type Store interface{ GetDevice(id string) (Device, error) }
```

Authorization admission (checked at the current clock and request context,
not at authentication time):

```go
type AdmissionCheck func() error
// ValidAdmission(ctx, now, principal) — the standard production check:
// alive context, strictly future ExpiresAt, zero expiry denies.
var ErrAdmissionDenied // expired/canceled at admission; nothing applied
type AuthorizedStore interface {
    DeviceStore
    PutAdmitted(check AdmissionCheck, dev Device) error
    ReplaceAdmitted(check, dev) (previous Device, acknowledged bool, err error)
    ListAdmitted(check, accountID string) ([]Device, error)
    RevokeAdmitted(check, id, accountID string) (revoked Device, affectedOthers []Device, acknowledged bool, err error)
}
```

`*Service` provides `ServeHTTP` / `Handler()`, `NewService(Config)`,
`TokenAuthenticator() Authenticate`, `Store() Store`, `DeviceStore()
DeviceStore` (always satisfies `AuthorizedStore`), and `OnRevoke(func(Device))`.

`Authenticate` verifies a bearer credential (a Google ID token) and fails
closed. It is meant for the tunnel endpoint's **first WebSocket auth
frame** — never query parameters.

## HTTP API (mounted under the gateway)

All endpoints take `Authorization: Bearer <Google ID token>`; requests
without a valid token are `401`. Bodies are strict JSON
(unknown fields rejected, bounded by default to 32 KiB). `Config.Domain`
(e.g. `gateway.pocketshell.io`) is enforced **on every endpoint** —
challenge, enroll, list and revoke: requests arriving under any other Host
are rejected.

| Endpoint | Method | Purpose |
|---|---|---|
| `/identity/v1/challenge` | POST | Issue an enrollment challenge for a device ID |
| `/identity/v1/enroll` | POST | Enroll (or explicitly re-enroll) a device |
| `/identity/v1/devices` | GET | List the caller's own devices (with live presence when the tunnel runs) |
| `/identity/v1/devices/{id}/revoke` | POST | Revoke one of the caller's own devices |

### Enrollment flow — exact client signing contract (canonical, v2)

1. `POST /identity/v1/challenge` with `Authorization: Bearer <ID token>`
   and body `{"device_id":"laptop-1"}`. The response carries the complete
   reconstruction contract — including the **verified `account_id`** — with
   URL-safe nonces and an integer `expires_at` (Unix seconds):

   ```json
   {
     "challenge_id": "pUBl1cChallengeIDExample0000000000",
     "device_id": "laptop-1",
     "account_id": "google:113958430858354529072",
     "nonce": "URLsafeServerNonce43chars_xxxxxxxxxxxxxxxxx",
     "connection_nonce": "URLsafeConnNonce43chars_xxxxxxxxxxxxxxx",
     "expires_at": 1799999999,
     "domain": "gateway.pocketshell.io",
     "role": "enroll",
     "protocol": "pocketshell-identity/1",
     "transcript": "<base64 std of the INNER challenge transcript>"
   }
   ```

   `transcript` is the inner challenge transcript for binding reference and
   cross-checks only — **it is not the enrollment signing input.**
2. Rebuild the challenge with the shared helper and sign the enrollment
   payload with the **device's Ed25519 private key**:

   ```go
   ch, err := identity.ChallengeFromWire(resp.ChallengeID, resp.DeviceID,
       resp.AccountID, resp.Role, resp.Protocol, resp.Domain,
       resp.Nonce, resp.ConnectionNonce, resp.ExpiresAt)
   sig, err := identity.SignEnrollment(priv, pub, ch, sshHostKey, reenroll)
   ```

   The enrollment transcript is
   `"pocketshell-enroll-request-v2"` followed by length-prefixed
   (4-byte big-endian) fields: the challenge transcript (itself
   `"pocketshell-challenge-v1"` + length-prefixed role, protocol, domain,
   device ID, account, nonce, connection nonce, expiry), the raw 32-byte
   public key, the exact `ssh_host_key` string, and `"0"` or `"1"` for the
   re-enrollment mode. The signature covers the challenge binding **plus**
   the submitted public key, SSH host key and re-enroll mode, so nothing in
   the request can be altered under a valid signature. The bare challenge
   signature of the previous format is rejected (`401 proof of possession
   failed`) — there is no fallback.
3. Enroll:

   ```json
   {
     "device_id": "laptop-1",
     "public_key": "<base64 std of the raw 32-byte Ed25519 public key>",
     "ssh_host_key": "ssh-ed25519 AAAA... user@host",
     "challenge_id": "<from step 1>",
     "signature": "<base64 std Ed25519 enrollment signature>",
     "re_enroll": false
   }
   ```

   Every enrollment attempt consumes its challenge (single-use): failed,
   altered or replayed attempts always need a fresh challenge.

#### Fixed interoperability signing vector

All clients must reproduce this byte-for-byte (pinned in
`TestEnrollmentSigningVector`):

- Ed25519 seed (hex): `201d9d97027b268f30ed2b9a75cf8e107984618b067c8a7721cdb7ef4adf7d0a`
- Public key (base64 std): `fK7L9oR+0QFZhblBJ0lVKn/CclYl4DRfpxoFFABV/5A=`
- Challenge: id `vec-challenge-0001`, device `laptop-1`, account
  `google:113958430858354529072`, role `enroll`, protocol
  `pocketshell-identity/1`, domain `gateway.pocketshell.io`, nonce
  `vec-nonce-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA`, connection
  nonce `vec-conn-BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB`, expires_at
  `2000000000`.
- Host key: `ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFiXedVecTorHostKeyPublicKeyAAAA=`
- `SignEnrollment(priv, pub, ch, hostKey, false)` =
  `bAOA9th0OZ3OQCY0dq6XCIVwUVwzRryqsnnVxxp8fJNNRB1OfAELhaOAtfEX0y11nojdktfr19hQwLQrXINZDw==`
  (base64 std). A signature over the bare challenge transcript with the
  same key is rejected.

### Key replacement policy

Enrolling an existing device ID succeeds only if it is owned by the same
account **and** the public key *and* host key are unchanged (idempotent
re-enrollment). Anything else fails:

- different owner → `403` (a device ID can never be taken over);
- key or host key differs without `re_enroll: true` → `409` (explicit
  re-enrollment required);
- `re_enroll: true` while `Config.AllowReenrollment` is false (the
  default) → `403`;
- re-enrolling a **revoked** device → `409`, even with the original key —
  revocation is terminal; generate a new device with a new key;
- the key already enrolled on another **active** device → `409 public key
  already enrolled` (duplicate registration keys are refused).

With the operator opt-in (`AllowReenrollment: true`) and `re_enroll: true`,
the replacement is a single atomic store swap for the same owner, after a
fresh proof of possession of the *new* key. If a revocation races the
re-enrollment, **the revocation wins** (the store refuses to replace a
revoked device). Active sessions for the old key are torn down via the
revocation callbacks.

### Revocation, key tombstones and duplicate keys

`POST /identity/v1/devices/{id}/revoke` is owner-only; unknown and
foreign-owned devices are indistinguishable (`404`). The revocation is
**persisted first** (fsync + atomic rename, together with a tombstone for
the device's public key in the same atomic write), then `OnRevoke`
callbacks fire — the tunnel worker registers there to disconnect live
sessions. Re-revoking is idempotent and fires no callback.

If durability cannot be proven (directory fsync fails after the rename),
the revocation stays **applied** and `OnRevoke` still fires for every
affected device — containment is not a durability ACK — while the HTTP
answer is `500 "revocation not acknowledged; retry"`. Retries re-attempt
the flush and cannot return `200` until it succeeds (see *Store
guarantees* below).

- **A revoked public key can never be enrolled again under any device ID**
  (`403 public key has been revoked`). Tombstones are durable (registry
  file v2, `revoked_keys`) and survive restarts; **loading a v1 registry
  derives the same rejections from its already-revoked records**, and
  rejection is always derived from tombstones *plus* revoked records — a
  full tombstone table can never silently weaken a revocation. There is
  deliberately **no API to clear a tombstone**; the only escape is a
  privileged operator process editing the registry file offline.
- **Revoking a key invalidates every copy of it.** If historical data
  contains two devices sharing one key, revoking either device revokes the
  other in the same atomic write (the revocation response callbacks fire
  for both), so no duplicate survives as an active registration.
- New duplicate active keys are refused at enrollment (`409 public key
  already enrolled`), so the cascade only ever applies to pre-existing
  data.

### Device list and passive presence

`GET /identity/v1/devices` answers `{"devices":[...]}` with the caller's
own devices (revoked ones included, flagged `revoked: true`), sorted by
ID and bounded by the per-account device quota. Each entry carries the
durable record (`id`, `account_id`, `public_key`, `ssh_host_key`,
`revoked`) and — **additively, only when the gateway runs the reverse
tunnel** — a `presence` object derived from the tunnel's actual
ready-host state at request time:

```json
{
  "devices": [
    {
      "id": "laptop-1", "account_id": "google:113958430858354529072",
      "public_key": "...", "ssh_host_key": "ssh-ed25519 AAAA...", "revoked": false,
      "presence": {
        "online": true,
        "observed_at": "2026-10-10T12:01:00.250Z",
        "connected_since": "2026-10-10T11:58:12.004Z",
        "session_generation": 3
      }
    }
  ]
}
```

- `online` is true only when the device's **current** host-agent session
  completed its signed handshake (the OK frame was written) and is not
  revoked — exactly the readiness the client SSH route needs before it
  would open a stream. No client stream is required. Enrolled-but-never-
  connected, disconnected, superseded, mid-handshake and revoked devices
  are `online: false`; a revoked device is never online (the store's
  revocation is authoritative, and the tunnel unpublishes readiness in the
  same critical section as the revocation epoch bump).
- `observed_at` is the gateway time the snapshot was taken (one snapshot
  for the whole list). RFC 3339, UTC, millisecond precision.
- `connected_since` (online only) is when the current host session became
  ready; a reconnect or replacement session reports its own, later time.
- `session_generation` (online only) counts host registrations **for this
  device** in the running gateway process; it increases on every
  reconnect/replacement and restarts after a gateway restart. It is
  per-device on purpose (a gateway-wide counter would expose other
  accounts' connection churn).
- No `presence` key at all means presence is **unknown** (tunnel disabled
  or an older gateway), never "offline". Enroll responses never carry it.

Presence is a point-in-time observation: a host can drop right after the
snapshot. Authentication, Host enforcement, the under-lock admission gate
and account scoping are exactly those of the list itself; the presence
snapshot is taken only after the admitted disclosure, only for the listed
devices, keyed by the verified principal's account.

## Request admission and body discipline

Verification happens at header time, but admission is decided later, at the
actual operation points, against the **current** clock and the current
request context:

- After the request body completes (a slow body must not extend a lapsed
  authorization; a denied enroll never consumes its single-use challenge).
- After slow store lookups (an injected registry may answer arbitrarily
  late).
- As the **final pre-mutation gate under the store's mutation lock**: every
  admitted mutation (enroll, replacement, revoke) and every list disclosure
  runs an `AdmissionCheck` inside the store lock, immediately before the
  state change or the copy. A request whose principal expires while queued
  behind a slow fsync is denied (`ErrAdmissionDenied`, HTTP 401) and
  applies nothing. Injected stores cannot bypass this: `NewService` only
  accepts injected stores that themselves implement `AuthorizedStore` and
  forwards every check into their actual mutation/list lock, where it runs
  again as the final gate. Stores without those semantics are **refused at
  construction** — a store whose internals may block arbitrarily cannot be
  made atomic from the outside (a check evaluated before an opaque call
  says nothing about the state when the call returns).
- Request-context cancellation rejects at admission the same way.

Denial is `401` with no state change, no challenge issue or consumption,
and no disclosure. A mutation **legitimately admitted** keeps the full
durability contract: post-rename failures still apply the state, fire
containment callbacks, and refuse to acknowledge (no false 200). The
challenge issuer is gated by the same check before Issue/Consume (its lock
guards bounded in-memory work only, never I/O).

`Principal.ExpiresAt` is not re-verified against the token itself after
authentication (no active JWT re-authentication for long bodies); the gate
checks the verified principal's declared expiry against the current clock.

Bodies are strict JSON with a definitive-ending discipline: after the JSON
value decodes, a **second decode must return exactly io.EOF**. Trailing
JSON values, stray closing delimiters, oversize (byte cap unchanged), and
stalled/errored trailing reads are all rejected — valid prefix never
licenses an error body. Trailing whitespace followed by a clean EOF is
valid. Timeouts and cancellation map to `408`, oversize to `413`, other
malformations to `400`.

> **Transport deadline requirement.** The strict body decoder waits for the
> definitive end of the body, so a request body stalled forever must be
> unblocked by a real network deadline: the HTTP server's `ReadTimeout`, or
> `Config.RequestReadDeadline` (applied via
> `http.ResponseController.SetReadDeadline` when the writer supports it;
> zero by default). A context timeout alone does not interrupt
> `Body.Read`. Root integration must provide this bound at one of the two
> layers.

## Store guarantees (single instance, durable local registry)

All mutations (`Put`/`Replace`/`Revoke`) and the list disclosure serialize
on the store lock and persist durably before returning, so admission
decisions are atomic with the mutation itself — there is no count-then-put
window, and the authorization check runs under the same lock immediately
before the state change (see *Request admission and body discipline*):

- **Quota:** `Config.MaxDevicesPerAccount` is enforced inside the store
  (`WithLimits`) for `StorePath` registries, and by an atomic decorator for
  **injected** `Config.Store` registries (which must implement
  `AuthorizedStore` — see *Request admission and body discipline*);
  concurrent enrollments at limit 1 admit exactly one in both cases.
  Registry-wide device cap: 10000.
- **Terminality:** a revoked device cannot be replaced or revived even
  when a replace races a revoke; its key is tombstoned in the same write.
- **Crash safety:** every write is temp-file + fsync + rename; corrupt or
  invalid files refuse to load (fail closed).
- **Durability acknowledgment (two distinct failure stages).** A failure
  *before* the rename leaves the file unchanged: the in-memory state rolls
  back and the error is `ErrStoreFailure`. A failure *after* the rename
  (directory open/fsync) means the file already holds the new state: the
  applied in-memory state is kept — never rolled back, and a revocation is
  never reverted to active — and the mutation is NOT acknowledged:
  `ErrDurabilityUncertain` (HTTP 500 "not acknowledged; retry").
- **Containment is not a durability ACK.** A revocation with unproven
  durability still fires `OnRevoke` for the revoked device AND every
  cascaded device immediately: active sessions are torn down at once even
  though the HTTP answer is an error. Callbacks are containment and
  idempotent — an uncertain attempt and the later acknowledged retry may
  both fire them.
- **Retries re-attempt durability.** While durability is pending, the
  store is fail-closed for acknowledgments: every mutating call (including
  an idempotent revoke retry) re-runs the flush, and nothing returns 200
  until a flush succeeds. Once it does, the pending revocation(s) are
  acknowledged (HTTP 200, containment re-runs) and later retries are clean
  no-ops. General writes (enroll/replace) during the pending window are
  equally gated: each attempt re-flushes the full registry; nothing is
  acknowledged while the base state's durability is unproven.
- **Crash window.** If the process dies between rename and dir fsync, the
  restart loads the applied state from the file (atomic rename) with no
  memory of the pending ACK; the reconnect-time `Revoked` check is the
  backstop for sessions missed during that window.

## Authentication semantics and active sessions

- `Principal.ExpiresAt` is populated by the production Google verifier from
  the token `exp` (UTC). **Zero-expiry contract:** a zero `ExpiresAt` means
  "verifier does not populate it" — acceptable ONLY from explicit test
  stubs; production consumers (root server, tunnel adapter) MUST reject
  zero-expiry principals when the principal comes from a verifier that is
  expected to populate it, and MUST NOT treat zero as "never expires".
  Verification happens at request/authentication time: an existing tunnel
  session is not killed at the expiry instant, but the tunnel worker MUST
  NOT (re-)authenticate with an expired principal and SHOULD drop or
  re-authenticate active sessions before `ExpiresAt` passes.
- **Allowlist changes are also authentication-time.** Removing an email
  from the configured allowlist blocks all *new* authentications
  immediately but does not itself kill an established session; to end an
  account's access now, revoke its devices (persisted + callback) and
  remove its SSH authorized keys at the host (endpoint-side revocation is
  the compromised-gateway backstop).
- **JWKS refresh is bounded on every axis:** at most one refresh in flight
  (single-flight); waiters honor their own context cancellation instead of
  blocking behind in-flight I/O; the fetch runs detached from the
  initiating request with its own 10s timeout; every refresh attempt
  (success or failure, any trigger — cold cache, unknown kid, expired
  cache) is rate-limited by the cooldown (default 30s), so outage bursts
  cannot storm the endpoint and a failed cold fetch returns unauthorized
  promptly instead of spinning until the caller deadline; and cached keys
  are served stale only within `MaxStaleAge` (default 24h) — beyond it
  verification fails closed rather than trusting possibly-rotated keys
  forever. An empty `JWKSURL` uses the Google default endpoint.

## Budgets (exact limits)

| Resource | Bound | Default |
|---|---|---|
| Request body | `Config.MaxBodyBytes` | 32 KiB |
| ID token size | `GoogleConfig.MaxTokenBytes` | 8 KiB |
| Live challenges per account | `Config.MaxOutstandingChallenges` | 16 |
| Live challenges, all accounts | `Config.MaxOutstandingChallengesGlobal` | 4096 |
| Challenge lifetime | `Config.ChallengeTTL` | 2 min |
| Devices per account | `Config.MaxDevicesPerAccount` | 32 |
| Devices, registry total | store `Limits.MaxTotal` | 10000 |
| Revoked-key tombstones | store `Limits.MaxRevokedKeys` | 100000 |
| JWKS response | fixed | 1 MiB |
| Auth verification per request | `Config.AuthTimeout` | 10 s |
| Body read (network) | server `ReadTimeout` or `Config.RequestReadDeadline` | server-owned |
| JWKS refresh cooldown (all triggers) | `GoogleConfig.RefreshCooldown` | 30 s |
| Stale signing-key acceptance | `GoogleConfig.MaxStaleAge` | 24 h |

## Credential scope and isolation (read before making claims)

- The gateway management/routing credential is **not routing-only**: the
  same verified identity authorizes device management (enroll, list,
  revoke) and tunnel/routing authorization. Document and enforce it as one
  management+routing credential; do not claim narrower token-use scopes
  unless they are actually enforced.
- **No whole-gateway credential isolation holds while legacy Google paths
  remain.** Google-compatible legacy proxy users still expose their Google
  bearer tokens to the gateway runtime; scoped-credential isolation applies
  to new clients only when no legacy or background path receives their
  Google bearer. Never state gateway-wide credential isolation while the
  legacy path is live.
- Expiry ownership: this package verifies tokens and exposes
  `Principal.ExpiresAt`; the broker/routing layers carry expiry separately
  and enforce their own lifetimes. Active connection lifetime is enforced
  independently of token issuance (tunnel/root scope).

## Tunnel host authentication

The tunnel worker authenticates a connecting host agent with the same
primitives: issue a challenge with `RoleHost` (binding its own protocol
string and per-connection nonce), then verify the agent's signature
against the enrolled device:

```go
ch, _ := identity.NewChallengeIssuer(ttl, limit, nil).Issue(identity.ChallengeParams{
    AccountID: principal.AccountID, DeviceID: deviceID,
    Role: identity.RoleHost, Protocol: "pocketshell-tunnel/1",
    Domain: "gateway.pocketshell.io", ConnectionNonce: connEpoch,
})
dev, err := store.GetDevice(deviceID)
err = identity.VerifyDeviceProof(dev, ch, sig) // fails if revoked, wrong device, or bad signature
```

Challenges are single-use and expiring; replays on the same or another
connection fail because every binding field is inside the signed
transcript. Host-auth signatures (`identity.Sign`/`Verify` over the
challenge transcript) are unchanged by the v2 enrollment format — only
enrollment moved to `SignEnrollment`/`VerifyEnrollment`.

## User flow (device owner)

1. Open the PocketShell UI, sign in with Google. The gateway verifies the
   ID token; your account is `google:<sub>` and stays stable even if your
   email changes.
2. On a host you control, run the pocketshell-link agent. It generates an
   Ed25519 identity key (file mode 0600) and reads its real SSH host key.
3. The agent enrolls through the flow above, signing the full payload with
   its private key and registering the pinned SSH host key. Nothing is
   trusted from the wire alone — every enrollment carries a fresh proof of
   possession over the exact asserted values.
4. The device appears in your device list; you can revoke it at any time.
   Revocation is durable, kills sessions via callbacks, and permanently
   retires the device's key.
5. If the host is reimaged (new host key) or the identity key is lost, the
   agent enrolls as a **new** device with a **new** key. Replacing the key
   of an existing device ID requires explicit re-enrollment and is disabled
   unless the operator turns it on.

## Trust bootstrap caveat — read this

**The SSH host key pinned at enrollment is only as trustworthy as the
channel it was read from.** The identity service records what the agent
reports; it cannot tell a real host key from one a man-in-the-middle fed
you during first setup, and device-key possession does not prove ownership
of the asserted SSH host key. Therefore:

- The SSH host key **must be verified locally and independently** at the
  host itself (e.g. read it from the host's console or an already-trusted
  shell: `cat /etc/ssh/ssh_host_ed25519_key.pub`, verify the fingerprint
  via CLI/QR pairing before pinning on the client). The registry's host-key
  metadata is advisory; it is never auto-trusted for first contact.
- Later connections must reject host key mismatches (standard SSH
  behavior); a changed host key after enrollment is an incident, not an
  update. Rotation requires explicit independent verification plus
  explicit re-enrollment.
- These in-package guarantees do not protect against a fully compromised
  gateway: SSH endpoint authentication (client keys, host key verification)
  must remain enforced independently by SSH itself.

## Security invariants

- Identity = verified issuer+subject; emails only gate the allowlist and
  aid display. No user-supplied account IDs anywhere; a verifier returning
  a malformed AccountID is rejected.
- Enrollment signature covers challenge + public key + host key + mode;
  there is no legacy-format fallback.
- Revocation is terminal: persisted before acknowledgment, wins races
  against replacement, and tombstones the key registry-wide.
- No secrets in URLs (bearer header only), no token/signature/private-key
  material in logs; loggers receive outcomes and identifiers only.
- All inputs bounded (see *Budgets*); every failure path fails closed.
