# Gateway implementation and security checklist

Current coordination evidence and open acceptance gates are recorded in
[coordination-status-2026-10-07.md](coordination-status-2026-10-07.md).
That dated record supersedes older interim repair status below; unchecked
implementation/deployment gates remain unchecked until their evidence passes.

Last updated: 2026-10-08. Coordinator: daemon session in pocketshell-cli. This document tracks actual completion, not intended behavior. Public deployment of reverse tunnels requires passing the security checks below.

## Final composition gates identified by Opus at root 89cbbd2

- [x] Independently accept browser fixture credential-policy and failure-reporting corrections at6b7b8e8 (nine offline controls, six boundary calibrations); combined shipping browser/runtime proof remains open.
- [x] Native setting-restoration source: preserve successful original-value capture and valid durable records before mutation, and check put/get status. Independent final checks passed25 preflight,8 restoration and122 cleanup cases, including both original-authority counterexamples.
- [ ] Canonical packaged native guard fixture: repaired migration JSON carries the required privateKeyPath, but independent review requires strict DB absence/schema checks, ownership checks before key-file mutation, and aggregate close-error handling. Finish those corrections, rebuild the test APK, then pass the leased lane. The actual run produced2 tests/2 failures/0 skips; owned resource and setting restoration completed. This does not establish usable native gateway transport.
- [ ] Final browser fixture: strict full-line source marker; separate bounded work/cleanup; paths tied to configured account origins; real Accepted-publickey log calibration; final all-context auth/custody checks. Seven offline suites passed at7a02a5a, but independent actual-helper controls demonstrated remaining oracle defects.
- [ ] Real production-flow fixture: verify embedded VCS metadata, enforce transport/HTTP deadlines and check partial-start cleanup before the final composed OpenSSH run.

- [x] Reject a tunnel auth-frame device ID that differs from the URL before lookup or stream opening; retain matching-route behavior and ownership checks. Independently reviewed1463314 integrated as3f17dc4.
- [x] Withhold enrollment HTTP failure bodies and wire reason strings, and log a real distinguishing pinned-key fingerprint. Independently reviewed6d12ee0 integrated asbdf8767; fingerprint correction integrated as3f17dc4.
- [x] Withhold reviewed run-handshake peer strings from CLI diagnostics. ErrMsg/close corrections at aa547ad and type/server/role/protocol corrections at 85a7abc are integrated in root **a31e733027424fe77b217f0d5c551956be12d60f**. Independent frozen-source race controls passed 26 test events, including actual binary checks of both output streams; coordinator full Go race suite passed (root 39.576s, CLI 213.178s, hostagent 71.088s). No skip count is inferred from those package summaries. This closes the scoped diagnostic source gate, not production/browser/native/rollout gates.
- [ ] Integrate metadata classifier0916b92, wire its41-check suite into CI and regenerate the SSM document, then prove actual target isolation. Independent classifier review passed: received responses and all timeouts are unproven; only validated000 with curl exit7 proves blockage. Target systemd252 supports Ex properties; missing firewall tooling prevents fallback strategyB unless separately provisioned.
- [ ] Final helper wheels: close producer-field/effective-flag ambiguity and downstream provenance/map contradictions; verify actual binary identity or accurately scope label agreement; run the independent verifier on the real four-platform release and installed offline helper. Existing34-check harness passed, but seven additional invalid-input controls passed unexpectedly atc2f43e5.
- [ ] Capacity client deadline verdict: fix the real socket-expiry/watchdog-callback race, retire test fixture goroutines and use per-attempt timing; independently verify deterministic controls, then repeat the complete measurement with the accepted client and harness. Historical69 assertions do not close this new deadline gate.
- [ ] Independently review and integrate the ZAI repairs, then bind final browser/delivery/fixture builds to that exact root revision.
- [ ] Run real OpenSSH through the root gateway executable and real CLI enrollment/run with an independent pin: authorized-key positive, unknown-key/password refusal and wrong-pin refusal before userauth, zero skips and complete owned cleanup.

The required Docker probe checks passed under the race detector at this revision;
that result does not check off composed SSH, browser/native or rollout gates.

## User requirements

- [x] Name approved: pocketshell-gateway, private PocketShell-io repository.
- [x] Repository created and initial extraction pushed: https://github.com/PocketShell-io/pocketshell-gateway.
- [x] Canonical gateway.pocketshell.io DNS points to existing server 52.213.219.13; Route53 change C09160111ONV395RXKK7J INSYNC. Legacy relay.pocketshell.io retained.
- [ ] Canonical hostname has valid TLS and works in production; legacy hostname continues working.
- [ ] New repo owns the Go server; old aws-infra source/deployer replaced by migration pointers.
- [ ] GitHub main CI/CD deploys without local phone AWS Gate. One-time IAM/SSM bootstrap is allowed while gate is open.
- [x] Stage the exact GitHub main-branch deployment identity under CloudFormation with deny-all quarantine. Live trust/policy readback and all four requested explicit-deny simulations passed; removing quarantine, publishing the accepted SSM installer and routine deployment remain open.
- [ ] Repair Desktop publish gates and pass actual Windows/macOS/Linux CI. Source493ba7e passed local type/lint/build,3186 unit tests plus1 platform skip,55 integration tests plus1 existing skip, and55 E2E tests plus3 existing skips. Source30c719c closes the directory/non-executable guard defects; independent focused checks passed23 with1 Windows-positive skip. Resolve and spawn the exact validated PATH candidate and contain fixture cleanup before source acceptance; Windows/macOS CI remains unexecuted.
- [ ] Multi-user ownership and device registration are independently authenticated; no global shared shell-access token.
- [ ] Actual SSH authenticates the user key and the pinned host key end to end. Gateway never receives client SSH private keys or decrypted terminal content.
- [x] Host CLI --server URL defaults to wss://gateway.pocketshell.io; explicit development opt-in allows ws://gateway:PORT in Docker. Go common flags/config and published Python wrapper7a3e014 implement this; CLI CI37637678360 succeeded. Helper distribution and live endpoint acceptance remain separate gates.
- [ ] Docker demonstration uses no published home-host SSH port.
- [x] zcy YOLO launch convention documented and validated in external-model-agents skill (commit d3e0544 in .agents). Installed warm bridge write/read probe passed; cold diagnostic workers stopped before replacements.
- [ ] Approach, protocol, deployment, migration and security results documented.

## Ownership / implementation work

- [ ] identity worker: internal/identity, docs/identity.md — verified issuer+subject identity, durable registration, proof of device private key, owner-only list/revoke.
- [ ] tunnel worker: internal/tunnel, internal/hostagent, cmd/pocketshell-link, tests/docker, docs/tunnel.md — bounded opaque SSH streams and usable host CLI.
- [ ] integration worker: root server, tests, docs/architecture.md and migration — TLS aliases, health/version, identity/tunnel integration, legacy proxy hardening.
- [ ] delivery worker: .github, scripts, infra/github-actions.yaml, README, docs/deployment.md — least-privilege OIDC, immutable artifacts, constrained SSM install and rollback.
- [ ] migration worker: aws-infra and web isolated branches — ownership pointers and canonical hostname config.
- [x] Python CLI worker: explicit `pocketshell gateway enroll/run/show` wraps the SSH host helper, forwards --server safely and preserves stdin/signals/exit status. Integrated locally; helper build/install and server rollout still pending. Old Link is a different protocol.
- [ ] Core/web client worker: distinct gateway target, scoped-token WebSocket handshake, real ssh2 connection and independently paired SSH host-key pin; preserve direct SSH.
- [ ] Scoped-credential broker worker: independently trusted sync service exchanges Google credentials for short-lived gateway-only JWT; broker key and sync authority inaccessible to gateway runtime/deployment.
- [ ] New enrollment/client flows send only scoped credentials to gateway; verify broker tokens cannot authorize sync CRUD and warning sweeps cannot upload their SSH keys.
- [ ] Retire raw-Google legacy credential use/acceptance across shipping direct SSH, forwarding, desktop/CLI and background callers without silent Google fallback, or prove genuine legacy/new execution-boundary isolation. Same process, hostname/path separation or same-authority processes are insufficient. Until then, accounts sending valid Google bearers through any co-resident legacy path remain inside its sync-credential trust boundary; new-route tests do not close this gate.
- [ ] Document helper build/install and distinguish implemented web support from pending native-client integration.
- [ ] Native clients preserve synced gateway intent and refuse unsupported gateway hosts before credentials, sockets or SSH-config mutation; ZAI implementation tracked in PocketShell-io/pocketshell#3059.
- [ ] Implement and verify actual Android and Desktop gateway connections: explicit target/pairing, trusted broker exchange, opaque end-to-end SSH, independent host pin before user authentication, and real behind-NAT positive/refusal/lifecycle evidence. Marker-preservation and unsupported-target guards alone provide no usable gateway connection and do not complete native transport support.
- [ ] Integrate commits, review interfaces, run Go tests/race/vet/format, Docker suite and CI.

## Compromised-gateway validation and repair loop

Threat model: untrusted gateway has its own credentials/state and controls routing/bytes. Client, home-host agent/local SSH server, authorized private SSH keys and independent frontend delivery remain trusted. Lab uses only disposable local containers and ephemeral test keys. No external targets or real user data.

- [ ] Positive control: authorized SSH key executes a benign sentinel command on the lab host.
- [ ] Unknown SSH key fails; password, keyboard-interactive and `none`/empty-password login fail; and routing/account/device credentials alone do not authenticate SSH — each under the endpoint's verified key-only policy, which is required for every admitted username (a deliberately admitted root account included: it would still need a key). Root and excluded-account refusals evidence the **selected** recommended baseline profile, not a client/protocol-enforced universal requirement: `PermitRootLogin no` (`prohibit-password` still permits some root authentication) and `AllowUsers` exclusions are recommended hardening choices, and the fixture must mirror whichever profile the operator selected.
- [ ] Endpoint policy evidence is the daemon's **effective** configuration, not the edited file: `sshd -t` plus `sshd -T -C`, both carrying the running daemon's actual `-f` configuration file and every `-o` override (a bare command can validate a different configuration), for each admitted username and for excluded accounts (root included). The `-C` context is the full connection — user, resolved source host name, accepted client source address, and the local address/port of the dialed listener so `Match LocalAddress`/`LocalPort` are evaluated — with the accepted source observed rather than assumed from the dialed destination, IPv4 and IPv6 as actually reachable, and `Match`/`Include` overrides covered.
- [ ] A key-only lab pass certifies that fixture's policy only, not every enrolled home machine; enrollment's host-key probe stops before userauth and is not an sshd-policy audit. Home machines need the operator-reviewed baseline documented in the CLI onboarding (`docs/gateway.md` §2.1 in the pocketshell-cli repository).
- [ ] Client rejects a substituted SSH host key before sending SSH authentication.
- [ ] Modified/replayed bytes and registration proofs cannot produce authenticated shell access.
- [ ] Through the home agent, gateway cannot choose arbitrary LAN/local destinations; agent forwards only its configured loopback SSH endpoint. A compromised gateway process can still use its own network access.
- [ ] Multiple clients remain isolated; cross-account route/enroll/list/revoke attempts fail.
- [ ] Revocation closes existing streams and rejects re-registration; reconnect generations cannot erase a replacement.
- [ ] Malformed frames, slow consumers and disconnects are bounded and cleaned up under race detector.
- [ ] Document observed metadata/availability limits and trusted-frontend caveat.
- [ ] For every failed security assertion: record reproduction, assign owner, add regression test, fix, independently rerun original reproduction and full relevant suite.
- [ ] Final report identifies integrated commit, commands, results, fixed findings and unresolved limitations. No unsupported claim of absolute security.

Astra execution status: BLOCKED by runtime security screening for both requested executable tasks (“possible cybersecurity risk”). No Astra test ran and no implementation approval exists. A distinct read-only Astra architecture review DID complete; requirements and decisions are in design-review.md. Independent zcy and user-requested Opus 5.5 validation workers are assigned local-only defensive integration tests. Track actual model availability and executed results separately.

- [x] Read-only Astra architecture review completed; findings documented in design-review.md.
- [ ] Implement and validate Astra review requirements, including independent host-key trust, enrollment binding, active-session lifecycle and endpoint-side revocation limits.
- [ ] Close every finding in source-review-findings.md with a named regression and integrated rerun.
- [ ] Close every finding in deployment-review-findings.md, including unprivileged runtime and verified instance-metadata isolation.
- [x] Delegate official ngrok, Cloudflare, Tailscale and SSH research and preserve notes plus reports/Secure outbound tunnel standards.md (ten acceptance gates).
- [ ] Apply primary-source industry research from research_notes/Secure outbound tunnel standards/ and reports/ to the implementation and acceptance tests.

## Production rollout

- [ ] Preserve existing instance, VPC, EIP and stack; do not recreate the server.
- [ ] Bootstrap deployment role exact repository/main OIDC trust, artifact-prefix upload and document/instance-scoped SSM permissions; existing instance gets read-only artifact-prefix permission.
- [ ] Deployment uses immutable commit artifacts, SHA verification, atomic replacement and rollback when health/version fails.
- [ ] Main CI passes and automatic deployment succeeds through OIDC.
- [ ] Both canonical and legacy hostnames pass TLS, health/version and existing authenticated SSH proxy checks.
- [ ] Enable reverse tunnel API only after security validation and persistent registry configuration.
- [ ] Migrate deployed web config to canonical hostname after server is ready.
- [ ] Confirm git status, commit receipts, live build identity and document remaining work.

## Evidence log

- 12:02 UTC checkpoint: integrated Go `acd3b86` full race suite passed;
  accepted drain documentation is integrated. Core PR35 merged as `4096fc5`
  with green main CI after independent692 core/141 UI checks. Final consumer
  pins and real packaged Android proof remain pending.
- Crypto `eb9a6c8` independently passed shim65, Node16, production build and
  the Chromium lab's18 records/9 dials/8 server connections. Astra accepted
  the shared classifier and observed guard telemetry. This lab clones the
  connection configuration; actual shipping browser/webApi/pin-store through
  the real Go gateway is a separately queued functional gate.
- CLI `29a9fa7` independently passed1139 full/162 serial gateway tests. Its
  concurrent global process scan failure is retained. Five source corrections
  and exact owned-child tracking are assigned to a fresh ZAI worker; passing
  tests did not close the probe/exec path identity or malformed-metadata gaps.
- Native fixture synthetic checker57 and dispatch29/wiring checks pass, but
  independent review still requires distinct marker arguments, correct folder
  creation order, external-only socket sampling, exact connection-bound auth,
  stream continuity/identity and complete owned import cleanup. Fresh ZAI
  repair follows pin preparation; no emulator or Android approval is claimed.
- Broker `ace5619` independently passed59 checks with the actual Go verifier
  and zero skips. IAM script `f7f4b94` independently passed87 offline checks.
  Source integration/publication is assigned; live broker deployment, signing
  key reader isolation, clock/inventory observations and rotation remain gates.
- Deployment D20–D22 were found despite green committed harnesses; a fresh ZAI
  turn is scheduled after the active activation editor. No production gateway
  activation, canonical trusted TLS or automatic CD acceptance has occurred.

- Initial server extraction commits: 04ec538 and 36ccd32. Original source: aws-infra/sandbox/pocketshell-relay.
- Existing AWS account 817685572750, region eu-west-1; instance i-0dee79146aceb4014; service pocketshell-relay; bucket pocketshell-relay-relaybucket-azljzs6pn8i8. Resource names retain legacy spelling for continuity.
- Read-only baseline inspection: SSM command 9053b9ee-4a47-44f9-a2f6-cc10504f53ff. Existing relay hostname answered HTTP 426 before migration.
- Temporary coordination logs and receipts: /home/alexey/tmp/pocketshell-gateway (not committed; durable results belong in docs).
- Initial identity repair integrated as 3b707fa and 185d964; coordinator reran `go test -race -count=1 ./internal/identity` successfully (8.231s). Round-two findings remain open in identity-review-round-two.md; this is not production acceptance.
- Live legacy instance artifact policy reduced to GetObject only; readback confirmed, existing relay HTTPS still returned expected 426. Dedicated runtime user and metadata isolation remain pending.
- Legacy hardening/identity wiring integrated as 168e3f2; coordinator reran `go test -race -count=1 ./...`: root 2.576s, identity 8.224s, both pass. Reverse handlers and scoped verifier still pending integration.
- Broker signing key bootstrapped as RSA-3072 SSM SecureString version 1; gateway instance explicitly denied its key family/history/path retrieval. Lambda invoke/update denied by policy simulation. Broker source and live token boundaries not yet accepted.
- Python CLI ZAI commits 1634ee9/47d9e27 integrated as 86687db/1aa46c0; worker full CI-equivalent suite 1005 passed, package build/guards/ruff passed. Coordinator focused gateway rerun recorded separately after minor header-description correction.
- CLI main 0516b94 pushed; coordinator gateway suite 28 passed; GitHub CI run 37577614106 succeeded.
- Identity round-two and routing verifier integrated as 62fde37/c2171a1/ef536b7/0dc61e6. Coordinator complete Go race suite passed for gateway, identity and routingauth. Independent follow-up findings remain open in security-review-round-three.md; these passing baseline suites do not close them.
- Identity e4bc01e: coordinator `go test -race ./internal/identity` passed (9.775s). Astra confirmed the previous cold-fetch cooldown, derived authentication deadline and deterministic fetch-barrier fixes in source, then found A16: an unlocked cache read during recovery. A separate ZAI repair and concurrency regression remain required.
- Native guards: core 98941b5 and desktop 262af05 remain isolated; Android changes remain uncommitted pending independent review. Independent Android debug APK build, typecheck and 13 focused tests passed. The canonical JS gate failed after 395 passing tests because the new file was unregistered (N2). The packaged shared-core pin still strips gateway metadata (N1). Actual shared-store regressions, manifest registration, dependency integration and packaged refusal evidence are pending; this is not acceptance.
- At 06:35 UTC, active ZAI workers stopped with the provider's five-hour usage-limit error. Their changes, prompts and failure logs were preserved. A staggered restart is scheduled for 06:50 UTC using fresh bounded ZAI turns, with explicit ownership and repair briefs. Quota recovery is not a completed implementation or test receipt.
- ZAI resumed at 06:50 UTC; tool activity and source edits were verified. Broker verifier 6069099 integrated as 387081d; coordinator package race rerun passed (1.734s). Broker infrastructure, production wiring and rotation acceptance remain pending.
- Independent source review identified A17/A18: identity authorization can expire during body/lookup waits, and whole-body HTTP deadlines are absent. Separate ZAI identity follow-up is queued after the current cache-race worker; root wiring has a real-network deadline regression assigned. Existing green authentication tests do not close these cases.
- Coordination checkpoints are backed up on private branch `coordination/gateway-review-progress`; production main and rollout remain gated on accepted integration.
- A16 repair efee6d6 integrated as c63b49f; coordinator identity race suite passed (14.390s). Separate post-body/store-lock admission repair remains pending.
- Combined core b42d06e contains gateway contract plus native marker guards in an isolated integration worktree. Coordinator build, core/UI typechecks, 680 unit tests, six UI guard tests and 168 browser assertions passed. Docker tier initially lacked its core-owned fixture image; after building that isolated tag, 22/23 tests passed and one pre-existing channel-reclamation hazard test timed out. Its test and implementation are unchanged from origin e87040d; a ZAI harness repair is assigned, not waived.
- Independent dependency triage is preserved in dependency-security-triage.md. Browser crypto containment and a minimal PBKDF2 patch have disjoint ZAI ownership; no practical SSH key recovery was demonstrated. Broad desktop runtime/build maintenance remains a separate scope; marker guards do not clear those existing dependency advisories.
- A temporary nonsecret AWS parameter probe confirmed that hierarchical GetParameter calls require the leading slash; the slashless broker default returns ValidationException (B4). The probe was deleted and no production private key was read. ZAI owns canonical-name validation and an atomic current/previous reference-swap rotation repair within the protected signing-key namespace.
- Root's custom TLS config and ListenAndServeTLS permit net/http's automatic HTTP/2 setup, so the accepted-socket cap alone cannot bound multiplexed requests (A19). Root integration must disable HTTP/2 while retaining HTTP/1.1 and certificate validation, or demonstrate a global request budget plus real body deadlines before acceptance. Test actual production ALPN negotiation, not an assumed autocert configuration.
- Astra independently confirmed the A16 mutex snapshot fix at 46961dd; the coordinator package race pass supports that specific closure. The review notes nondeterministic waiter coverage in the recovery tests. Post-body/store-lock admission and transport deadlines remain open and separately assigned.
- Native second-round independent canonical JS gate (396/58), typecheck, APK and focused desktop/core checks passed, but review found N3 in Android's actual default legacy shell. Its sync projection loses gateway intent before a separate direct key/controller path; previous tests exercised the opt-in shared shell only. A fresh ZAI Android repair is running, with changes left uncommitted for review. Emulator and packaged PR CI acceptance remain pending.
- Core fixture 849c731 reports repeated focused and full 23-test Docker success, but its probe-allocation inference does not prove server reclamation. Independent review rejected that inference; a sequential ZAI correction is running before coordinator acceptance.
- Interim identity redesign review identified differing service/store quotas and an unsupported opaque-store admission fallback. These remain I2/A17 repair requirements; passing store-lock tests alone do not close all admission paths.
- Tunnel/host helper 8890f13 integrated as 3395098. Coordinator race rerun passed: tunnel 9.296s, hostagent 2.670s, real CLI 39.806s, including canonical enrollment and SSH across the prior handshake deadline. Actual accepted-source OpenSSH Docker rerun and root wiring remain required.
- Identity 8fcbff8 integrated as 5ee8735 for built-in atomic admission and second-decode EOF discipline. Astra confirms the built-in store placement, but the opaque-store fallback and HTTP barrier ordering remain open; a fresh ZAI contract repair is running. Coordinator combined package race pass: identity 18.459s, routingauth 2.071s, tunnel 9.430s, hostagent 2.655s, CLI 45.806s. Whole suite FAILED because two root tests still expect three Revoke results; the root wiring owner is correcting that stale API usage. This is not a whole-suite pass.
- Broker 418e425 integrated as c361513; coordinator Node token suite 26/26 with zero skips and actual Go vector passed. Astra found B5/B6 and narrower-than-claimed removed-key evidence, so a fresh ZAI lifecycle/deploy validation repair is running. New broker routes and human/core deny attachment remain undeployed or unverified; live gateway deny evidence is separate.
