# Deployment, CI/CD and the one-time bootstrap

This document is the operator-facing contract for how code reaches
`gateway.pocketshell.io` (legacy alias `relay.pocketshell.io`), what the
automation is allowed to do, and what it refuses to do. The review ledger
(`docs/deployment-review-findings.md`) items D1–D13 are marked inline; every
claim here is enforced by a test listed in §8.

Owned by the delivery worker: `.github/**`, `infra/github-actions.yaml`,
`scripts/**`, `Makefile`, this document. The existing stack
(`pocketshell-relay`, instance `i-0f9c18ce63cf6c26e` (RelayInstance replaced
2026-10-09; the terminated predecessor was `i-0dee79146aceb4014`), bucket
`pocketshell-relay-relaybucket-azljzs6pn8i8`, eu-west-1 / 817685572750) is
inventory — nothing in it is replaced, and the legacy
`/relay-arm64.gz` deployment path keeps working untouched.

## 1. Pieces

| Path | Role |
| --- | --- |
| `.github/workflows/ci.yml` | push/PR CI: `make test` (race), `vet`, `fmt-check`, `vuln` (govulncheck), `artifacts` (ARM64 release set), Docker e2e (legacy wire contract AND the mandatory production-shaped new-API fixture — it fails the job on any missing dependency, it never succeeds by skipping), the delivery contract suite, EVERY regression harness (workflow, installer, API, bootstrap, provisioning, packaging) and shellcheck — all as REAL steps in the SAME run; plus non-gating `build-matrix`/`wheels` release-infra jobs. Read-only permissions, every action pinned to a commit SHA. |
| `.github/workflows/deploy.yml` | REUSABLE (`workflow_call` only — no `push`, no `pull_request`, no `workflow_dispatch`): OIDC → download the artifact THIS CI run built → `scripts/deploy.sh`. The ONLY way in is ci.yml's `deploy` job, which needs every gate green at the same commit and refuses when any need failed, was cancelled or was skipped (D14). Deploys serialize and are never cancelled. |
| `.github/workflows/oidc-probe.yml` | manual probe that prints the exact OIDC `sub` this repo emits (D12 verification aid). |
| `infra/github-actions.yaml` | one-time bootstrap stack: OIDC deploy role pinned to the VERIFIED IMMUTABLE subject (owner/repo IDs included — no name-only fallback, wildcards structurally impossible), the `pocketshell-gateway-deploy` SSM document (trusted helper provisioning preamble, then the installer), the runtime instance-role policy (read-only `artifacts/*` PLUS the broker-signing fences the runtime carries itself: explicit denies on the `pocketshell-sync/gateway-signing-key*` family for GetParameter/GetParameters/GetParameterHistory and GLOBAL GetParametersByPath deny — review R4), and explicit denies for Lambda/API Gateway/CloudFront and for the signing-key SSM parameters on the deploy role. |
| `scripts/bootstrap-aws.sh` | coordinator-run one-time bootstrap + read-only `iam simulate-principal-policy` verification. Accepts ONLY the verified immutable OIDC subject — blank, wildcard, classic name-only or any other value is refused BEFORE any AWS call, and the template itself is asserted to pin the exact subject + `sts.amazonaws.com` audience first (R3). The simulation distinguishes `allowed`/`explicitDeny`/`implicitDeny` and requires EXPLICIT denies for the runtime signing-key/path fences (R4). |
| `scripts/deploy.sh` | deployer side: digest checks, immutable uploads, SendCommand with string-array parameters (including `Revision` and `ServiceUser` AND the carried activation configuration `CertDir`/`RegistryFile`), bounded polling, result verification (digests, version, commit, `healthz=ok`, `registry=enabled`, `tunnel=enabled`, `imds=` strategy). |
| `scripts/host/install-deploy.sh` | the ONLY code the deploy role can run on the instance (reconstructed byte-for-byte from the verified SSM envelope by `make infra`). Its runtime audit parses the flags-aware `systemctl show` ExecStartEx/ExecStartPreEx properties (`{ path=… ; argv[]=… ; flags=… ; … }` groups) — REAL systemd consumes the `+`/`-`/`!`/`!!`/`@`/`:` modifiers at load time, so plain properties report prefix-free path/argv and only the Ex form carries the consumed flags (`privileged` etc.); a prefix INSIDE a property value is treated as invented output and refused. Because no property can carry the `+` itself, the raw unit SOURCES systemd reports as loaded (FragmentPath/DropInPaths) are audited too: the guard line must be EXACTLY `ExecStartPre=+$HELPERS_DIR/imds-guard.sh $SERVICE_USER` (exactly once), drop-ins may not set Exec* directives at all, and ExecStart must be byte-equal to the property argv with EMPTY flags — exact executable/argv/root-guard matching and privilege semantics preserved (R1). Non-Exec properties are likewise compared in systemd's RENDERED form, not the unit text: capability sets print as lowercase mask names (`CapabilityBoundingSet=cap_net_bind_service` on systemd 252.23/255.4) and must be exactly the one-element set {CAP_NET_BIND_SERVICE} (case-insensitive, any extra capability refuses); `IPAddressDeny` prints CIDR host prefixes in set order (`169.254.169.254/32 fd00:ec2::254/128`) and must contain both exact IMDS host entries (deploy incident 37947576965). The ExecStart rewrite substitutes the binary, preserves the nonempty `-allow` allowlist verbatim, and installs EXACTLY ONE `-certdir` and ONE `-registry` pair (the carried activation configuration); the health gate requires the enabled registry+tunnel postures AND mounted, auth-rejecting routes on top of version/commit. |
| `scripts/host/provision-helpers.sh` | the trusted provisioning preamble embedded BEFORE the installer in the SSM document (R2): validates the helpers directory chain (original AND resolved, no symlink component anywhere, DAC/ACL checked) BEFORE any mutation, creates the helpers directory only as the final component of an already-trusted parent (plain `mkdir`, never `install -d`/`mkdir -p`), refuses symlinked/foreign/writable helper leaves, and installs each helper by same-directory staging + atomic `rename(2)` — no privileged write ever follows a symlink or mutates an ancestor. |
| `scripts/e2e/` | Docker end-to-end: legacy wire contract (real SSH through the gateway in explicit dev mode) and `newapi/` — the production-shaped fixture: REAL `pocketshell-link` enroll/run against the REAL gateway with registry + tunnel + true broker verification, toward REAL OpenSSH, with independent client pins and negative controls. `run-newapi.sh` is a MANDATORY gate (R5): missing runtime sources, Docker, compose or tooling fail NONZERO with the dependency named — there is no successful skip, no legacy-adapter fallback, no waiver. |
| `scripts/tests/` | regression harnesses + contract suites (no AWS needed): installer (incl. the R1 structured-systemd block with REAL `systemctl show` fixtures), deploy-API, workflow checker + 17 mutation negatives (incl. missing-gate/skip-bypass detection, R5), bootstrap trust validation (R3), generated-document provisioning sequence (R2), packaging (real wheel artifacts + matrix fail-closed), python/Go contracts. |
| `scripts/packaging/build_wheel.py` | deterministic, stdlib-only platform-wheel packager for the `pocketshell-link` helper (see §10). Builds only; never uploads; refuses credential-shaped payloads and hostile version strings. |

## 2. Deployment flow (routine, fully automatic)

The gateway build injects `main.version` and `main.commit` from the same
Make variables used by its manifest. Without these ldflags a plain build
reports dev defaults at `/healthz` and fails the installer's version check.

1. Merge to `main` → ci.yml runs every gate at that exact commit:
   `make test` (race), `vet`, `fmt-check`, `vuln`, `artifacts` (the ARM64
   release set — uploaded as the run's artifact), the Docker e2e (legacy wire
   contract AND the production-shaped new-API fixture), the delivery
   contract suite, the workflow harness, the installer/API harnesses and
   shellcheck. Only then does its `deploy` job call the REUSABLE
   `deploy.yml` (`workflow_call`), and only when the event is a push to
   `refs/heads/main` on the canonical repo and NO need failed, was cancelled
   or was skipped (D14). There is no second, independent way to deploy;
   main-branch CI runs are never cancelled mid-flight (the deploy job lives
   inside that workflow), deploys serialize, and a running deploy is never
   cancelled.
2. `make artifacts` cross-builds the gateway for linux/arm64 and writes
   `build/dist/`: the gzipped archive, `VERSION`, `sha256sums.txt` and the
   digest-bound `manifest.json` (archive digest, binary digest, version,
   source revision, domain/aliases/service).
3. OIDC: GitHub mints a token for the push; `aws-actions/configure-aws-credentials`
   assumes `pocketshell-github-deploy`. The bootstrap trust policy accepts
   EXACTLY one subject (see §3) with audience `sts.amazonaws.com` — PRs,
   forks, feature branches and other repos are rejected by AWS, not by us.
4. `scripts/deploy.sh`:
   - recomputes both digests and cross-checks `manifest.json` (build drift
     fails before any upload);
   - reads the exact custom document ARN at its explicitly reviewed numeric
     version before any upload, requiring Active/Command, expected owner/name,
     Sha256 and the independently approved hash; missing pins or mismatched
     metadata abort before PutObject/SendCommand;
   - uploads the four objects under `s3://<bucket>/artifacts/<archive-sha>/`
     with `IfNoneMatch:*` (D10): an existing object must byte-match (identical
     retry) or the deploy aborts — overwrites and substitutions are
     impossible through this role;
   - invokes `pocketshell-gateway-deploy` on the pinned instance with
     string-array parameters (D7) binding the artifact key to the archive
     digest and carrying the expected binary digest, with explicit
     DocumentVersion/DocumentHash/DocumentHashType=Sha256 (no default/latest);
     the workflow pins owner817685572750/version4/hash
     `b342b7626d9ae961008feb59cac83f03829b4fac4ff8dfb00fb15dac70bc4258`.
     Legitimate bootstrap document updates require independently qualified
     metadata/content and a reviewed workflow pin update; the driver never
     learns its expected hash from DescribeDocument. These integrity checks
     do not prove a fix for an unknown IAM authorization-context denial;
   - polls to a terminal status: `InvocationDoesNotExist` immediately after
     send is eventual consistency (bounded retry); `AccessDenied` and friends
     fail fast and loudly (D7);
   - verifies the instance's `StandardOutputContent` echoes both digests, the
     version and `health=ok` + `rollback=none` + `healthz=ok` +
     `registry=enabled` + `tunnel=enabled` (D7/D8 + activation). `rollback=ok`
     is a RED deploy (old binary serving); `rollback=failed` exits 2 = page a
     human.

## 3. One-time bootstrap (coordinator)

Prerequisites, in order:

1. **DNS first**: `gateway.pocketshell.io` (and the legacy name) must point at
   the instance EIP `52.213.219.13` BEFORE the first gateway deploy — the
   health check verifies trusted TLS on both names, and autocert issues the
   canonical certificate on the first successful start. Deploying before DNS
   fails closed (health fails → rollback → red CI); fix DNS and re-run.
2. **Exact OIDC subject (D12, R3)**: the trust policy accepts EXACTLY ONE
   subject — the coordinator-verified IMMUTABLE form carrying GitHub's
   owner and repository IDs,
   `repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main`
   (verified against GitHub's API, which reports `use_default: true` and
   `use_immutable_subject: true` for this repository), with audience
   `sts.amazonaws.com`. There is NO name-only fallback and NO blank
   override: `scripts/bootstrap-aws.sh` pins the subject as a constant,
   refuses empty/wildcard/classic/any-other values BEFORE any AWS call,
   statically asserts the template pins the same subject + audience, and
   `--oidc-subject` is accepted only when it equals the constant. The
   template's `ExactOIDCSubject` parameter is additionally pinned by an
   `AllowedPattern` that matches only that exact value, so wildcards and
   the classic `repo:<owner>/<repo>:...` form are structurally impossible.
   If GitHub ever changes the subject shape, re-verify with
   `.github/workflows/oidc-probe.yml` FIRST and change the constant + the
   template + its pattern together.
3. Run:
   ```
   scripts/bootstrap-aws.sh
   ```
   Idempotent (CloudFormation create-or-update). Defaults match the verified
   inventory. The script:
   - auto-detects that the GitHub OIDC provider is already registered in the
     account (it is) and sets `CreateOidcProvider=false`;
   - refuses to run against any account other than 817685572750;
   - after the stack settles, runs `iam simulate-principal-policy` (read-only)
     asserting the deploy role CAN upload under `artifacts/*`, CAN SendCommand
     only with the pinned document on the pinned instance, and CANNOT touch
     the legacy `/relay-arm64.gz`, cannot delete, cannot start sessions, and
     cannot run `AWS-RunShellScript`; and that the instance role CAN read
     `artifacts/*` while still reading `/relay-arm64.gz`, is EXPLICITLY
     denied (explicitDeny, not merely implicit) GetParameter/GetParameters/
     GetParameterHistory on the broker signing-key family (current key,
     previous/rotated keys, any path spelling) and on the whole
     `pocketshell-sync/*` family, and denied GetParametersByPath GLOBALLY
     (R4 — the instance profile's AmazonSSMManagedInstanceCore otherwise
     allows parameter reads on `*`, and an implicit deny would not survive a
     future broad grant).

### Prepare an existing-stack update for review

For an existing bootstrap stack, use the preparation mode when execution
requires a separate infrastructure review:

```sh
make infra
sha256sum infra/github-actions.yaml
scripts/bootstrap-aws.sh --create-oidc false \
  --prepare-update-change-set gateway-reviewed-update
```

This command uploads the exact generated template and calls
`create-change-set --change-set-type UPDATE --template-url ...`. It exits
without executing the change set or running post-execution IAM simulation.
`--no-exec` additionally stops before any S3 upload or change-set creation;
it still performs the account/provider read-only checks. Preparation does
not remove an existing deploy-role quarantine. Review the returned change-set
ARN, every resource change and the actual target preflight receipts before
separately authorizing execution. For an existing quarantine, verify that
`GithubDeployRole` retains its logical ID, role name/path, exact OIDC subject
and provider ARN, and that CloudFormation reports no role replacement.

CloudFormation accepts at most 51,200 bytes in `TemplateBody`; its
[TemplateURL limit is 1 MB](https://docs.aws.amazon.com/AWSCloudFormation/latest/APIReference/API_CreateChangeSet.html).
The generated SSM document exceeds the inline limit. The script therefore
uses the existing relay artifact bucket, requiring the verified account as
its owner and the configured region as its bucket location. It never creates
a bucket or rewrites, shrinks or packages the template. The dedicated key is
`bootstrap/templates/<template-sha256>/github-actions.yaml`, addressed by a
regional HTTPS S3 URL.

Staging takes a private snapshot, checks its digest against the source,
uploads with `If-None-Match: *` plus SHA256 checksum and `sha256` metadata,
and downloads the object to verify the actual bytes, checksum, metadata and
length before submitting the URL. An existing key is reused only after this
same verification; missing buckets, wrong regions, denied upload/readback or
mismatched bytes fail before change-set creation. The bootstrap operator
needs read/write access to this dedicated prefix and bucket-location access;
these operations do not grant that access to the OIDC deploy role. CLI
prerequisites include `aws`, `jq`, `sha256sum`, `xxd` and `base64`, with an AWS
CLI supporting conditional `s3api put-object` and SHA256 checksums.

The default command still creates/updates and executes the stack, then runs
the permission verification described above. It supplies the unchanged
snapshot to `cloudformation deploy` together with `--s3-bucket` and the same
digest-based prefix, so the AWS CLI can upload large templates under that
prefix using its own object naming. The
[CLI requires this bucket option for templates over 51,200 bytes](https://docs.aws.amazon.com/cli/latest/reference/cloudformation/deploy.html).
Use preparation mode when only creating the reviewable change set is
authorized.

Re-run the bootstrap only to change the role/document (the SSM document is
regenerated from `scripts/host/install-deploy.sh` by `make infra`).

## 4. What the deploy role may do (and nothing else)

- `s3:PutObject` into `<bucket>/artifacts/*` — nothing else in the bucket, no
  deletes, no reads (it never downloads).
- `ssm:SendCommand`, split into two grants (D2): the document grant is
  restricted to the exact custom document ARN, and the instance grant names the
  one pinned instance. Other documents (including `AWS-RunShellScript`,
  explicitly denied) and other instances are unauthorized.
  The normal driver additionally requires reviewed Active Command metadata and
  explicit version/SHA256 pins. These are driver controls, not IAM conditions;
  a role bearer can bypass the driver and select another allowed version of
  the same document if the trusted bootstrap owner later creates it.
- `ssm:GetCommandInvocation` / `ListCommandInvocations` with `Resource:*`
  constrained by `aws:ResourceAccount` + `aws:RequestedRegion` — these SSM
  result APIs do not support document-ARN scoping (D1). `DescribeDocument` is
  document-scoped.
- Explicit denies on sessions, automation, IAM, Organizations, Route 53,
  CloudFormation, EC2 writes and S3 deletes.

## 5. The SSM document = the on-instance contract

The document's `runCommand` is generated from
`scripts/host/install-deploy.sh` (`make infra`); a contract test fails if the
decoded copy drifts. The generated command first enters Bash explicitly,
requires UID0, checks `/` and `/run` are root-owned directories without symlinks
or group/world write access, then creates a private mode0700 random directory
under `/run`. It decodes the deterministic gzip/base64 payload with an output
size cap and verifies its exact byte length and SHA256 before executing it.
The original UTF-8 sources and comments are preserved; there is no download,
source minification, or alternate executor. Required host tools are Bash,
GNU-compatible base64/gzip/head/stat/mktemp/wc/sha256sum/cut, id, sleep and rm.
SSM parameter expressions remain visible outside the compressed payload.

The verified decoded script runs in order (R2 — the provisioning harness
executes the exact decoded region to prove it):

1. the installer body (function definitions only — nothing executes yet);
2. the trusted provisioning preamble (`scripts/host/provision-helpers.sh`,
   embedded verbatim): it validates the helpers directory chain AS GIVEN and
   RESOLVED — no symlink component anywhere (dangling leaf included),
   trusted owner/group, NO group- or world-writable component (the sticky
   bit is explicitly NOT a mitigation: it blocks unlinking other users'
   files but not creating or racing new entries at a predictable staging
   name), no ACL granting write — BEFORE any mutation. The walk runs from
   the target down to AND INCLUDING the trust base — by default `/`, so
   every ancestor plus the root directory itself is audited; the default is
   special-cased, never pattern-matched (a literal `$TRUST_BASE/*` glob
   expands to `//*` and matches nothing ordinary, which once made the whole
   production-default audit vacuous). TRUST_BASE is normalized (trailing
   and duplicate slashes) and a relative base is refused. The preamble then
   creates the helpers directory only as the final component of an
   already-trusted parent (plain `mkdir(2)`, never `install -d` or
   `mkdir -p`, so no ancestor is ever created, chmod'ed or chowned), refuses
   symlinked or foreign-owned helper leaves (tamper evidence: attacker
   content is never blessed with chown), and installs each helper by
   staging it under an exclusive, unpredictable mktemp name INSIDE the
   audited directory and `rename(2)` — an untrusted concurrent writer can
   neither pre-create nor race the staging name, no write follows a
   symlink, and no partially-written helper is ever observed;
3. the IMDS helper payloads (`imds-probe.sh`, `imds-guard.sh`) embedded
   verbatim as `helper_install` heredocs — the installer refuses to run
   without them.

The envelope writes only to its private temporary `/run` directory. Within
the decoded helper provisioning region, no persistent privileged write bypasses
`helper_install` (contract-tested). Every parameter is constrained by an
anchored, backslash-free `allowedPattern` (D3) and re-validated by the
script; the bucket and service are pinned to the bootstrap values (D9); the
artifact key's embedded digest must equal the `ExpectedSHA256` parameter
(D9).

The serialized SSM document plus maximum runtime parameter sizes must remain
under65536 bytes. Every parameter carries a `maxChars` bound. The contract adds
1024 bytes for Unicode/JSON escaping in the two wildcard dots each of the
current Domain/Aliases patterns and rejects drift from the reviewed bootstrap
default/pattern census. This proof qualifies these source defaults, not arbitrary
CloudFormation overrides: before activation, compare actual stack parameters
and the resolved document to the reviewed values and recalculate their budget.
`python3 scripts/tests/ssm-envelope-test.py` reconstructs the committed payload,
checks exact source bytes/order, shell syntax and generation idempotence, and
runs inert corruption/cleanup controls. `make contract` includes this gate.

Normal execution returns the decoded child's exact exit status and the wrapper
removes its private stage. Wrapper INT/TERM cancellation sends TERM to its
**direct child**, waits at most approximately5 seconds, then sends KILL and
reaps it before removing the stage; cancellation returns130/143. This is an
aborted deployment, never success. Forced KILL can interrupt the installer's
EXIT rollback (whose health checks can take longer); cancellation does not
prove successful rollback or cleanup of descendants. SIGKILL of the wrapper
cannot run its cleanup trap and can leave a bounded root-only stage. Actual
SSM process-group termination and production rollback require separate target
evidence; inert local fixture receipts do not establish them.

On the instance, under an exclusive `flock` (D6):

1. Download the archive, `VERSION` and `manifest.json`.
2. Verify: gzip integrity, archive sha256, manifest agreement, `VERSION`
   sidecar, gunzipped binary sha256 (a SEPARATE digest, D4), and full ARM64
   ELF validation — magic, class, endianness, version, `e_type`, and
   `e_machine == 0xB7 0x00` little-endian at the exact offsets (D4).
3. Preserve the legacy executable (hash-verified copy under
   `/var/lib/pocketshell-gateway/legacy/`) before any swap — a failed FIRST
   migration therefore restores legacy (D5).
4. Install into `.../releases/<archive-sha>/` (immutable per-SHA), atomically
   repoint `/usr/local/bin/pocketshell-relay` via `rename(2)`. `releases/`,
   `releases/<sha>/` and any directory created on the way to the `-certdir`
   base are set to an EXPLICIT `root:root 0755` (an existing 0700 one is
   repaired): the SSM envelope runs under `umask 077`, and a umask-derived
   0700 release path is untraversable for the non-root service user
   (systemd `203/EXEC` — incident deploy 0ca7ec8 / SSM 4bcf35ae). 0755 is
   never group/world-writable, so the D13 path-trust audit is unchanged.
5. Rewrite the unit's ExecStart token-aware (D11 + activation contract):
   substitute the binary path, keep every unrelated argument (client id,
   allowlist, staging flag) verbatim in order — a nonempty `-allow` is
   MANDATORY (the new API refuses an empty allowlist next to a public
   domain, and a rewrite-time refusal beats a startup crash) — drop any
   pre-existing `-domain/-aliases/-certdir/-registry` pairs, and leave
   exactly one `-domain gateway.pocketshell.io -aliases relay.pocketshell.io`
   pair PLUS the carried activation configuration `-certdir <base>` and
   `-registry <base>/registry/devices.json`. Unit and state writes are
   temp-file+rename.
6. Restart, then health-check (D8 + activation): unit active; MainPID's
   `/proc/<pid>/exe` resolves to the release file AND hashes to the binary
   digest; the D13 runtime-credential audit (whose ExecStart argv check now
   also demands exactly the carried `-certdir`/`-registry` and the preserved
   allowlist); and TRUSTED TLS (system CA — never `-k`) answers with the
   frozen wire contract's 4xx on the canonical name AND every alias.
   `/healthz` must return JSON whose version equals VERSION, whose commit
   matches the source revision, AND whose `registry` and `tunnel` postures
   are BOTH `enabled`; beyond the self-reported postures, the mounted routes
   are probed: an anonymous `GET /identity/v1/devices` must be auth-rejected
   with 401 and the client-ssh route must answer 426 (websocket-only) — a
   404 means the API was never wired and fails the deploy.
7. On any failure: restore the state's CURRENT release (or the preserved
   legacy copy on first migration), restore the unit from backup, restart,
   re-verify the RESTORED identity and names (an ACTIVATED rollback target
   must show the enabled postures again — a silently deactivated previous
   release is never accepted as a healthy rollback), and swap the state
   ledger back. Exit 0 only if the new release or the rollback is healthy;
   exit 2 when the rollback itself fails.

## 5a. The canonical on-instance layout (activation state)

Both the legacy and the new binary keep their autocert cache under
`<certdir>/certs` (`DirCache` joins `/certs` — verified in both sources), so
the carried `-certdir` value is the BASE:

- `/var/lib/pocketshell-relay` — the `-certdir` base; `root:root 0755`, a
  ROOT-ONLY ancestor. The installer explicitly repairs a pre-canonical state
  where the whole base had been chowned to the service account (nesting a
  registry under a service-writable parent violates the ancestor rules).
- `/var/lib/pocketshell-relay/certs/` — the autocert cache leaf;
  `service:service 0700`; the existing legacy cache is migrated IN PLACE
  (chown only — files are never moved, rewritten or invalidated, so TLS
  state and ownership continuity survive the migration AND a rollback).
- `/var/lib/pocketshell-relay/registry/` — the registry workspace leaf;
  `service:service 0700` (Go's store writes its temp file, renames and
  fsyncs the directory here).
- `/var/lib/pocketshell-relay/registry/devices.json` — the identity-registry
  STATE FILE, `service:service 0600`, created and initialized by GO ALONE:
  the installer never pre-creates or truncates it (an empty pre-created file
  is corrupt — `NewFileStore` refuses it — and a reset would destroy
  enrolled devices). If it exists it must be a regular, non-empty,
  HARDLINK-FREE, service-owned file; drifted group/mode is realigned AS THE
  SERVICE USER, anything else (foreign owner, aliasing, wrong type) is
  refused fail-closed (see 5b).
- The unit's `ReadWritePaths` whitelist is EXACTLY the two leaves
  (`certs/` and `registry/`) — never the base. The runtime audit refuses a
  whitelist naming the base (a pre-canonical leftover) as well as any
  foreign entry.
- The D13 leaf-owner exception accepts a service-owned leaf ONLY with its
  OWN designated group (the service account's primary group) and ONLY at
  the leaf — ancestors stay strictly root-owned; the audit refuses a
  service-owned ancestor even when the leaf below it is missing.

## 5b. The runtime-leaf authority boundary (D23)

The effective-write probe requires a successful service-user shell execution,
verifies its numeric uid, and accepts only the exact `protected` witness.
Launch failure, wrong uid, empty output or malformed output refuses before
descent. Ancestor probes run before the state base's first pathname open;
post-migration checks cannot authorize earlier privileged operations.

The two leaves (and the registry file) are service-owned and service-WRITABLE
by design. A root pathname operation on anything INSIDE a service-writable
directory races the service: between any check and any use, a service-side
writer can replace the pathname (symlink, hardlink, rename), and a root
`chown`/`chmod`/open would land on the object the service chose. The
migration therefore never path-mutates or path-reads runtime leaf content:

- **Read-only preflight.** Symlink and trust-chain refusals are pure `lstat`
  decisions; nothing is mutated based on them alone.
- **Base reclaimed FIRST.** The `-certdir` base entry lives in an audited
  root-owned parent, so the service cannot replace the base pathname itself.
  A pre-canonical service-owned base is reclaimed to `root:root 0755` BEFORE
  any child is examined or created — while it is still service-owned, the
  service could swap the `certs/`/`registry/` entries themselves. (A running
  service keeps its already-open fds; nothing in the migration relies on
  quiescence, `KillMode`, or a `MainPID` exit — surviving same-UID writers
  are accounted for by construction, not by stopping them.)
- **Root ownership is not write authority.** Before root walks, opens for
  use, or adopts anything inside a root-owned legacy directory (the certs
  leaf, a nested legacy directory, the registry directory), that directory
  is proven NOT service-writable: first by mode-bit math, then by an
  EFFECTIVE write probe executed as the service user (`runuser -u … test
  -w`, kernel `access(3)` semantics — a POSIX access ACL that the mode bits
  cannot express still refuses). A writable root-owned legacy directory
  refuses the deploy BEFORE any child is touched; it is never normalized
  after its children have been mutated. These probes are also what freeze
  entry names for the privileged opens below: rename/unlink inside a
  directory requires write on it, so once the immediate parent of an open
  target is root-owned and not service-writable (the stable-parent
  invariant), the service can neither swap the name nor plant a FIFO for
  the open to block on between check and use. The parent of the base itself
  is probed the same way before the base's descriptor-bound reclaim.
- **The registry is NOT certificate-adoptable content.** The legacy
  certificate policy normalizes owners — exactly what must never happen to
  registry state before its own policy has judged it. The registry
  directory therefore has its own handler: the registry FILE's ORIGINAL
  type/link/owner/size evidence is validated read-only BEFORE anything in
  the registry subtree is mutated (a root-owned or foreign-owned nonempty
  state file refuses with bytes, owner, mode — directory included —
  unchanged); then only the directory ITSELF moves to the service account,
  never its contents, and never through the generic adoption walk. An
  absent registry file is still left to Go; an already-service-owned file
  stays untouched or is aligned as that UID.
- **Service authority for leaf alignment.** A service-owned leaf whose
  group/mode drifted is realigned via `runuser -u <service> chown/chmod`:
  the kernel refuses (EPERM) any object the service does not already own, so
  even a raced replacement can only ever be acted on within the service's
  own power. Root authority never touches such content.
- **Descriptor-bound privileged changes.** The unavoidable privileged
  operations (base reclaim; adopting the legacy root-owned autocert cache)
  open the path, `fstat` the OPENED inode through `/proc/self/fd`, compare
  the full record (type/DEVICE/inode/nlink/mode/owner/group — identity is
  dev+inode complete) against the preflight `lstat`, and then
  `chown`/`chmod` the `/proc/self/fd` path — the change lands on that exact
  inode no matter what the pathname does afterwards.
- **Explicit legacy-content policy.** Adoption walks a ROOT-owned directory
  only (frozen against service writes), per-inode: regular files and
  directories only, owner admin-or-service, group admin-or-service,
  `nlink == 1` for files (hardlinks are REFUSED, never normalized —
  metadata changes would hit every alias), depth-bounded, byte-preserving.
  Service-owned subdirectories are the service's own domain and are not
  walked by root. Anything unexpected refuses the deploy before any swap;
  an interrupted migration is recoverable (the next deploy completes the
  adoption; the legacy root service is unaffected by a partial one).
- **No privileged reads.** The preserved-registry log size comes from inode
  metadata (`stat %s`), never from opening the file; already-correct state
  is left completely untouched (an ordinary redeploy performs NO root
  chown/chmod under the certdir at all).
- **Availability.** A refusal in this phase happens BEFORE the unit is
  rewritten, so the previous service keeps running with its previous
  configuration; post-swap failures still roll back unit+symlink+state as
  before.

Related audit-fidelity corrections (D21 residuals): the structured-systemd
parser requires EXACTLY ONE authoritative `flags=` field per `ExecStartEx`/
`ExecStartPreEx` command group — missing (a plain property wearing an Ex
label), duplicated, or unknown-named flags refuse instead of being accepted
or overwritten; and the raw unit-source Exec* ban parses systemd assignment
syntax the way conf-parser.c v252 actually does: a PHYSICAL line whose
first non-whitespace character is `#`/`;` is a comment and is skipped
BEFORE any continuation processing (a comment ending in a backslash
absorbs nothing and does not affect a pending continuation), continuation
is decided by trailing-backslash PARITY of the accumulated line (odd
continues; the last backslash becomes one space; the next non-comment line
is appended verbatim), and an unterminated trailing continuation refuses
(deliberately stronger than v252, which would parse the fragment). A
drop-in `ExecStopPost = ...` — spelled with spaces, hidden behind a
comment-backslash, or behind an even-backslash run — cannot escape the ban,
while systemd-equivalent spellings in the unit we loaded remain acceptable.

## 6. Trust model — the honest version

Anyone who can push to the trusted OIDC subject can run arbitrary code on the
gateway instance: the deploy document is a shell script and SendCommand is its
executor. **GitHub main-branch write access IS the deploy authority.** The
role's walls limit blast radius, not authority: no IAM/DNS/EC2 mutations, no
interactive sessions, no unrestricted documents, one pinned instance, one
write-once artifact prefix, every parameter pattern-pinned, and health-checked
rollback that fails closed. This is deliberate — an approval gate would add
latency, not security, against an attacker who already controls `main`.

**Frontend isolation (D13):** the guarantees here are for the gateway
server. If the browser application's own delivery is compromised, this
pipeline cannot help; do not claim end-to-end protection across that
boundary.

**Runtime credentials on the instance (D13, implemented):** the runtime is
migrated to a dedicated no-login system user (`pocketshell-gateway`,
UID ≠ 0, no supplementary groups, allocation refused for UID 0 or any
privileged group). Its ONLY writable surfaces are the certificate cache and
the registry directory; releases, bin link, unit, drop-ins, state, backups
and helpers stay root-owned and are DAC-audited — including an EFFECTIVE
write probe executed as the service user (ACL-aware). The unit gets
`NoNewPrivileges`, `ProtectSystem=strict`, `PrivateTmp`,
`CAP_NET_BIND_SERVICE` as the only capability (bounding + ambient), and a
WHITELISTED `ReadWritePaths` (legacy/foreign entries are dropped, never
carried forward). Before a deploy reports success, the RUNNING process is
audited via `/proc/<pid>/status` (Uid/Gid/CapInh/Prm/Eff/Bnd/Amb) and the
effective systemd properties INCLUDING every drop-in.

**IMDSv2 credentials (D13, implemented, verified not assumed):** the IMDS
strategy is decided in a PREFLIGHT, before the unit, the binary link or the
runtime layout is touched. Strategy A — the unit sets `IPAddressDeny` for
both IMDS endpoints (169.254.169.254 and fd00:ec2::254) — must be proven by
a differential probe in two transient units: an UNFILTERED root control must
obtain an IMDSv2 token, and the same bounded token PUT AS the service user
inside a unit carrying the same `IPAddressDeny` properties must be refused
(curl 7) or dropped in the connect phase (curl 28 with `num_connects` 0 —
what the cgroup BPF egress filter actually produces on a real kernel: the
SYN is dropped and the connect times out; a timeout AFTER a connection, any
HTTP answer, tooling failure or proxy interference is fail-closed and never
counts as protected). The probe's EXIT CODE is the verdict (no output
marker; the control's positive verdict is the distinct exit 20 because
systemd-run itself exits 1 when it cannot start a unit). `make
imds-native-proof` demonstrates all of this against REAL enforcement:
Amazon Linux 2023 with systemd 252.23 booted in a privileged container, a
stand-in IMDS on both production addresses, the installer's own probe
functions — filtered service user (also under the live unit's full property
set) is protected, an equivalent filter on the wrong hosts and the unfiltered
service user are not, the uid-firewall preflight refuses (no iptables), and
the pre-fix probe reproduces the 2026-10-09 "inconclusive". Otherwise strategy B — a uid-scoped OUTPUT REJECT rule installed by
a root `ExecStartPre` helper (reboot-safe; root/SSM access untouched) — is
used ONLY if `imds-guard.sh --check` finds its tooling (iptables, plus
ip6tables on IPv6 hosts) present and functional, the rule applies, and a
probe as the service user then proves protection; it is re-probed after the
restart. If neither strategy is proven the deploy is REFUSED before any
unit/binary change and the service keeps its previous configuration.
Incident 2026-10-09 (Amazon Linux 2023, systemd 252, deploy 37970949069):
the pre-fix probe read the BPF drop as "inconclusive", strategy B was
activated on a host without iptables (nft is absent too), the guard
`ExecStartPre` exited 127 and the unit crash-looped, and the rollback trap
died on `unit_installed: unbound variable` (errexit in a top-level script
unwinds main's locals before the EXIT trap). Rollback is now driven from an
ERR trap and the installer harness runs `main` at top level exactly like the
SSM envelope. SSM itself is unaffected (the guard rejects only the service
uid's traffic to the two IMDS addresses). What remains root/security-owned: auditing the
instance role's OTHER existing credential grants.

## 7. Runbook

- **Deploy went red with `rollback=ok`**: the previous binary is serving and
  healthy; investigate the instance output in the workflow log
  (`get-command-invocation`), fix, merge again. No operator action needed.
- **Deploy exited 2 (`rollback=failed`)**: manual intervention. SSH/SSM session
  in, inspect `/var/lib/pocketshell-gateway/deploy-state`,
  `.../backups/`, and `.../legacy/pocketshell-relay`; the legacy binary is a
  preserved, hash-verified copy and the unit backups are timestamped.
- **Health fails on TLS for the canonical name right after the first deploy**:
  DNS/ACME sequencing (see §3.1). The rollback will have restored service.
- **Change the deploy script**: edit `scripts/host/install-deploy.sh`, run
  `make infra`, commit both; after merge the coordinator re-runs
  `scripts/bootstrap-aws.sh` to update the SSM document.

## 8. Verification matrix (all green, no AWS required)

| Surface | Test | What it proves |
| --- | --- | --- |
| installer | `make installer-harness` (244 assertions) | real cross-builds pass; amd64 impostor, corrupt gzip, wrong digests, VERSION/manifest mismatch, corrupt release, parameter injection all fail closed; A→B→failed-C rollback (ledger shifts so a failed retry cannot poison the last-good entry); failed first migration restores legacy; interrupted + concurrent deploys stay consistent; repeated deploys idempotent (incl. user allocation); trusted TLS + both names probed with healthz version/commit verification; D13 migration: uid-0/dangerous-group refusals, whitelisted ReadWritePaths, drop-in escalation refused, /proc credential audit, IMDS strategy A/B/refuse with fail-closed probe classification; planted-symlink paths refused BEFORE any mutation. R1 block: EVERY systemd property fixture uses the REAL `systemctl show` output shapes captured on the installed systemd 255.4 (prefix-free `path=`/`argv[]=` for plain properties, flags-carrying ExecStartEx/ExecStartPreEx); raw strings, unknown trailer fields, trailing junk, multi-command properties, invented prefix-preserving serializations, non-`privileged` or extra-flag guards, fully-privileged ExecStart, `'+'`-less guard unit text, lying property-vs-source disagreement, drop-in Exec* directives and drop-in ExecStart/ExecStartPre overrides are all refused; strategy-B installs pass with the real guard serialization. Activation block: old deployed unit → activated ExecStart (one `-certdir`/`-registry`, FILE flag, preserved allowlist); canonical layout (base root:root 0755, service:service 0700 leaves, registry file never pre-created); rerun with service:service leaves (leaf-group audit rule incl. foreign-group and service-owned-ancestor refusals); existing certificates + registry preserved byte-for-byte; symlinked leaf/dirs/file and writable or world-writable (sticky included) ancestors refused before download/swap; version/commit-healthy but disabled/failed posture or 404 routes → fail + rollback; enabled posture + auth-rejecting routes pass; rollback preserves the previous posture expectation (an activated target must be enabled again, else rollback=failed) and restores the legacy posture with the cert cache intact; missing allowlist refused before any write |
| deploy driver | `make api-harness` (30 assertions) | string-array SSM parameters incl. the carried activation configuration; `StandardOutputContent` verification of both digests + version + commit + `healthz=ok` + `registry=enabled` + `tunnel=enabled` + `imds=` strategy; bounded `InvocationDoesNotExist` retry; `AccessDenied` fail-fast; `IfNoneMatch` conflict refused, identical retry accepted; build/driver drift blocked; rolled-back deploys go red |
| contracts (python) | `make contract` (256 checks) | OIDC trust pinned to the verified immutable subject ONLY (no name-only fallback, no wildcards); split SendCommand; Resource-star reads with account+region; allowPattern accept/reject matrices incl. backslash-free; pinned bucket/service; same-commit deploy gate (needs, skip/failure/cancel guards, artifact binding, job-only id-token); workflow trigger/permission/pinning rules; embedded-script sync (installer, provisioning preamble AND helper payloads, in order, before `main`); R1 structured-systemd parsing present; R1 fidelity (flags-aware Ex properties, no privilege prefix expected inside a property, raw-source `+guard` pinning, non-empty ExecStart flags refusal, base-inclusive sticky refusal in both auditors, exclusive mktemp staging in the preamble); R4 runtime signing/path denies present with legacy access untouched; R3 bootstrap semantics; activation contract carried end to end (pinned CertDir/RegistryFile parameters, canonical layout, posture+route gates, no registry pre-creation); secrets sweep |
| contracts (go) | `go test ./scripts/...` | dependency-free twin of the contract suite (runs even without Python/Docker): embedded sync + provisioning ordering/bypass scan, structured-systemd audit markers, template boundaries incl. R4 denies, activation contract markers, CI harness wiring, no-failure-swallowing, secrets sweep |
| workflows | `make workflow-harness` (18) | the workflow checker must pass the real workflows AND detect every known-bad mutation: gate dropped from needs, skip guard removed, push guard removed, artifact renamed, independent push trigger added, floating action tag, workflow-level id-token, main-run cancellation, `--revision` binding dropped, concurrency group removed, AND (R5) `make e2e-newapi` step removed, `|| true` on a gate step, `continue-on-error` on a gate step, a harness unwired from CI, an `exit 0` skip branch in the runner, the runner's runtime-dependency check removed, the docker/compose requirement removed |
| bootstrap trust | `make bootstrap-harness` (10, R3) | with `aws`/`jq` stubbed to record-and-fail: blank, wildcard, classic name-only, other-repo subjects and repository overrides are refused with an EMPTY AWS invocation log (refusal strictly precedes any AWS call); the immutable subject (default and explicit) passes validation and reaches the (stubbed) identity call; three template-drift mutations (subject default swapped, audience changed, AllowedPattern loosened) are refused |
| provisioning | `make provision-harness` (78, R2) | extracts the GENERATED runCommand block from infra/github-actions.yaml and executes its EXACT provisioning region in a sandbox: structural order (helpers via `helper_install` before `main`, no `install -d`/bare `cat >`/post-hoc chown); pristine + idempotent installs produce byte-identical 0755 root:root helpers; with the PRODUCTION-DEFAULT trust base (TRUST_BASE unset) the pristine install succeeds AND the stat query log records every component examined INCLUDING `/` itself; a world-writable sticky parent, a broken stat, relative/`.`/`..` bases and trailing-slash/`//` base variants are exercised (hostile and broken environments refused BEFORE any mkdir/chmod/chown/write; normalized bases audited); sticky world-writable (1757 and 1777) helpers dirs refused; dangling final symlink, symlink-to-victim, group-writable helpers dir, foreign-owned helper, symlinked helpers dir and missing parent chain are all REFUSED with target bytes, ownership and modes preserved |
| packaging | `make packaging-harness` (9) | real wheels built from real ELF/Mach-O payloads: filename name/version/tag, RECORD hashes verified, binary round-trip + exec bit, deterministic (byte-identical rebuilds), refuses missing binaries / hostile versions / credential-shaped payloads; `make build-matrix` builds + verifies all four platforms on a full-source tree and FAILS CLOSED naming the runtime dependency on a standalone tree |
| e2e (legacy wire) | `make e2e-docker` | real SSH through the gateway (dev mode) in Docker: pinned host key accepted, wrong host key rejected, unenrolled client key rejected, command output round-trips |
| e2e (new API, production-shaped) | `make e2e-newapi` | the REAL `pocketshell-link` enrolls (broker token on stdin, real RS256/JWKS verification server-side, real loopback sshd host key pinned against an independently generated key file) and runs the real reverse tunnel against the REAL gateway binary with registry+tunnel enabled; a real SSH client speaks SSH through the tunnel with its OWN host-key pin (the ready message's metadata is unused), survives past the 10s handshake deadline, and the negatives all fail closed: wrong host pin, unknown client key, garbage token. Gateway container mounts no SSH keys; no privileged/docker-socket/host-network anywhere (self-audited at run time). MANDATORY (R5): missing runtime/fixture/Docker/compose fails the job — never a successful skip |

## 9. Limitations

- The root/integrated binary must support `-domain` + `-aliases` and serve
  ACME certificates for both names; the deploy contract (one
  domain/aliases pair) is enforced regardless, and an old binary that rejects
  `-aliases` simply fails health and rolls back.
- S3 object immutability is enforced by `IfNoneMatch:*` per object, not by
  bucket Object Lock (the bucket already exists; enabling versioning/lock is a
  coordinator change if ever desired). Same-digest content re-uploads are
  byte-verified, so this is write-once-in-practice with conflict detection.
- The instance echoes version/digests over SSM; there is no application-level
  `/version` endpoint (root-owned surface). The running process's identity is
  bound to the artifact by hashing `/proc/<pid>/exe`.
- `govulncheck` and the OIDC probe require network; everything else runs
  offline.
- D13 instance-role audit: the deploy role's grants are bounded here, and the
  R4 signing-key/path fences now live on the runtime role itself (explicit
  denies, bootstrap-simulated), but the existing instance role's remaining
  legacy grants (`pocketshell-relay-RelayRole-LvjBzsqkrVMa`'s inline
  `relay-arm64.gz` GetObject+PutObject, AmazonSSMManagedInstanceCore) are
  root/security-owned; the deny layer keeps the dangerous reads fenced
  without touching them.
- The provisioning preamble's ACL check runs only where `getfacl` exists;
  the mode-bit rules apply regardless, and the installer's effective write
  probe (as the service user) runs later in `main`. A root-writable-by-ACL
  path without `getfacl` on the image is refused only by the mode/DAC rules.
- The new-API e2e fixture requires the versioned-API runtime
  (`cmd/pocketshell-link` + registry/tunnel in the root binary). On a
  standalone delivery tree the gate FAILS with the dependency named
  (fail-closed, R5) — it runs for real in CI on the full-source tree and in
  the combined checkout used for verification. There is no skip branch.
- `make fmt-check` currently fails on `relay.go` (unformatted at the base
  commit, coordinator-owned root integration). The gate is deliberately NOT
  weakened; the file's owner must gofmt it.

## 10. Helper distribution (raw matrix, checksums, provenance, wheels)

Owned delivery surface for the CLI gateway contract handoff (2026-10-07):

- **Build matrix** (`make build-matrix`, CI job `build-matrix`):
  `pocketshell-link` cross-built for linux/amd64, linux/arm64,
  darwin/amd64, darwin/arm64 — `CGO_ENABLED=0` (static; the linux binaries
  carry no glibc dependency, so the documented ≥ 2.28 floor is a support
  statement mirroring aplexer's `manylinux_2_28`), `-trimpath`,
  Windows excluded by contract. Requires the runtime sources; a standalone
  delivery tree fails closed with the dependency named.
- **Version/commit injection**: `-ldflags '-X main.version=$(VERSION) -X
  main.commit=$(COMMIT)'` into `cmd/pocketshell-link`'s main package — the
  canonical seam the Go metadata worker owns; `-X` on an absent symbol is a
  no-op, so the injection is safe before their change lands and correct
  after.
- **Checksums**: a `sha256` sidecar NEXT TO every raw artifact plus a
  combined `SHA256SUMS`; the packaging harness recomputes both against the
  binaries. Raw-binary verification stays fail-closed: no digest, no trust.
- **Provenance**: `PROVENANCE.txt` records version, full commit, build
  timestamp, toolchain, exact flags, platform list, glibc/darwin floors and
  the no-public-channel statement.
- **Wheels** (`make wheels`, CI job `wheels`): deterministic, stdlib-only
  platform wheels (`pocketshell_gateway_link/bin/pocketshell-link`,
  `Root-Is-Purelib: false`) tagged `manylinux_2_28_x86_64`,
  `manylinux_2_28_aarch64`, `macosx_11_0_x86_64`, `macosx_11_0_arm64`.
  The default version is a PEP 440 LOCAL version (`0.0.0+<sha>`) which
  public PyPI rejects on upload — an accidental publish is structurally
  impossible; a real release passes an explicit `WHEEL_VERSION`.
- **Producer gate + complete wheel artifact set** (everything lands in
  `build/dist/wheels/`, which the CI `wheels` job uploads whole): before
  anything is packaged, the packager
  (`scripts/packaging/build_wheel.py`) verifies the raw matrix record set
  against the actual binary bytes — every per-binary `.sha256` sidecar, the
  combined `SHA256SUMS` (exactly the four binaries), and `PROVENANCE.txt` as
  a strict record: duplicate fields are an ambiguous record and are refused
  (no first-wins/later-override), required fields
  (version/commit/built_at/toolchain/flags/platforms) must be present with
  exact types (full 40-hex commit, RFC3339 UTC `built_at`, `go version`
  toolchain line), and the flags line is parsed as a GRAMMAR, not by
  substring: exactly one effective `CGO_ENABLED=0` assignment, exactly one
  `-trimpath`, exactly one `-ldflags` argument with unambiguous `-X`
  assignments — two `-X main.commit=` assignments (the linker lets a later
  one override an earlier one) or a value that merely contains the revision
  as a prefix are refused. Missing, mismatched, stale (different revision),
  conflicting, short-form or ambiguous producer inputs are refused. Each raw
  binary is additionally identified by a read-only, never-executing parse of
  its embedded Go build information (safe for cross-compiled slots): the
  toolchain version must match the receipt, `GOOS`/`GOARCH` must match the
  platform slot, `CGO_ENABLED=0` and `-trimpath=true` must be the recorded
  build settings, and the source-binding stamps `vcs.revision` (== the full
  release revision), `vcs.modified=false` (clean worktree — a matrix built
  with uncommitted changes is refused) and an RFC3339 `vcs.time` must be
  present; a binary whose ELF `e_machine` / Mach-O `cputype` does not match
  its slot is also refused. One bounded residual, kept explicit: with
  `-trimpath` the Go toolchain redacts `-ldflags` from the buildinfo
  (go.dev/issue/52372), so the effective `-X main.version/main.commit`
  injections cannot be re-derived from the packaged bytes by a static
  reader — they are enforced as an unambiguous grammar on the receipt's
  flags line, and their independent acceptance belongs to the trusted CI
  build receipt at the final release gate. The emitted release set is: one
  `pocketshell_gateway_link-<version>-<tag>.whl` per platform plus an outer
  `<wheel>.whl.sha256` sidecar each; a `SHA256SUMS` over all four wheels +
  `wheels-manifest.json` + `helper-matrix-PROVENANCE.txt`; the
  deterministic machine-readable `wheels-manifest.json` (schema
  `pocketshell-gateway-wheels-manifest/v1`) binding the full source
  revision, wheel version, per-wheel platform tag / archive SHA256 / size,
  the embedded helper's SHA256 bound to the named raw matrix binary, the
  complete canonical `helper_matrix` digest map, and the validated producer
  provenance; and a byte-identical copy of the checked raw-matrix
  `PROVENANCE.txt`. A rebuild clears exactly this artifact namespace in the
  output directory first, so a stale wheel from an earlier run cannot ride
  along in the uploaded set.
- **Offline verification and install of a received wheel set**: obtain the
  whole `build/dist/wheels/` directory through the private delivery route
  and, ideally, the manifest digest through a separate channel. Then:
  `sha256sum -c SHA256SUMS` recompute-checks every file, and
  `python3 scripts/packaging/verify_wheel_release.py --release-dir <dir>
  --expect-commit <full 40-hex revision>` independently re-derives the outer
  digests, every manifest member, the strict manifest schema (duplicate JSON
  keys and stripped required provenance fields are failures), the canonical
  platform order/tag/member/producer_file identities, wheel structure/RECORD,
  the embedded helper digest against BOTH the manifest entry and the
  `helper_matrix` map, the carried provenance (parsed strictly in BOTH modes
  with every field equal to its manifest representation), and the embedded
  binary's ELF/Mach-O architecture plus its Go buildinfo stamp (toolchain,
  GOOS/GOARCH, CGO_ENABLED=0, -trimpath, `vcs.revision` == the manifest
  revision, `vcs.modified=false`) — without executing anything and without
  raw-matrix access. `--matrix-dir <helper-matrix>` additionally re-verifies
  the complete raw record set with the same strictness and proves the
  embedded helper IS the verified raw producer binary. Install offline into
  the SAME Python environment as `pocketshell`:
  `pip install --no-index --no-deps
  pocketshell_gateway_link-<version>-<tag>.whl`. The accepted CLI resolves
  the helper in a fixed order — the `POCKETSHELL_GATEWAY_HELPER`
  environment pin, then the installed `pocketshell-gateway-link` wheel,
  then `PATH` — and never fetches anything at runtime; there is no
  `--helper-path` flag and no optional dependency extra.
- **Same-run consistency is not authentication**: RECORD hashes travel
  inside the wheel they describe, and the manifest/checksums are emitted by
  the same run that built the binaries. The Go buildinfo stamp strengthens
  the consistency story — it ties the packaged bytes to a toolchain, a git
  revision and a clean tree — but it is producer-authored data: it is not a
  signature, a malicious producer can build arbitrary bytes with chosen
  stamps, and a self-authored unsigned manifest never authenticates the
  build producer. Together these checks detect corruption, truncation,
  cross-platform swaps, stale or other-revision helpers, stripped manifest
  fields and contradictory maps — they do NOT prove who built the bytes or
  that the effective ldflags match the receipt (the `-trimpath` redaction
  above). Binding the release to a trusted source build requires the
  trusted CI receipt at the accepted revision plus out-of-band comparison of
  the manifest digest (or a coordinator-chosen authenticated release
  channel/attestation below). The manifest binds bytes to the exact source
  revision; it is not a signature.
- **No publication**: nothing in this repo uploads to any index and no
  channel credentials exist anywhere in it (contract-tested secret sweep +
  the packager refuses credential-shaped payloads). This repository has not
  published or reserved the normalized project name and makes no claim
  about its current registry availability or ownership (no live registry
  check was performed or needed); nothing here authorizes a public upload.
  The publish-channel decision (PyPI project + Trusted Publisher / token
  custody vs an authenticated internal index) stays with the coordinator;
  the CLI wrapper never downloads at runtime regardless.

**Distribution gaps that remain (explicit):** the version/commit injection
seam is LIVE (the runtime's d50cfa5 landed `main.version`/`main.commit` in
`cmd/pocketshell-link` with exactly these ldflags — matrix binaries now
self-report their build); the wheel-manifest gap is closed (manifest +
outer sidecars + SHA256SUMS + checked provenance now ship beside the
wheels), but the final 4-platform wheel receipt against the REAL
`cmd/pocketshell-link` matrix is PENDING root integration — this
delivery tree has no runtime sources, the packaging harness covers format
and build-stamp controls with clearly-labelled locally-compiled fixtures,
and an earlier-revision helper artifact must never be passed off as the
final release. CI uploads the complete wheel release set after consuming the downloaded raw matrix without rebuilding it. The mandatory independent verifier binds the full source commit, version and actual raw matrix before upload. Local callers use `make build-matrix wheels verify-wheels`. The effective `-X` ldflags remain receipt-verified only
(statically unprovable under `-trimpath`, see the producer-gate bullet
above) and close at the trusted CI build receipt / release gate; the wheel
platform tags are asserted from our own build matrix, not audited by
`auditwheel`/`delocate` (fine for an internal channel, not for a public
manylinux claim); no detached signatures, attestations or SBoM exist beyond
sha256 sidecars + the manifest + provenance text + the binaries' embedded
build stamps (a signing identity is a coordinator decision); no public
release exists or is faked.
