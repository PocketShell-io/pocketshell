# One-time OIDC result-context qualification

2026-10-09 note: the gateway instance was replaced (deploy target is now i-0f9c18ce63cf6c26e). This workflow intentionally keeps its historical binding to command 104ba941-344f-4fd6-b9cb-707c54488f28 on the terminated instance i-0dee79146aceb4014, the only instance that command ran on (its invocation record remains readable). The result-read grant is account/region scoped, not instance scoped, so the binding stays valid. A new binding on the new instance needs a new, independently reviewed diagnostic command.

This manual MAIN-only workflow reads the already completed diagnostic command104ba941-344f-4fd6-b9cb-707c54488f28 on instancei-0dee79146aceb4014. It never sends a command or prints the command's stdout/stderr. Its Failed/response2 receipt is expected: target runtime protection is NOT_PROVEN, independently of successful result-read permissions.

Parent publication sequence is essential. Publish only this independently reviewed workflow to existing main before landing delivery CI/autodeploy, or keep automatic deployment disabled until this proof completes. Never merge the complete delivery candidate into main with an activated role before the result-context gate. This proposal changes no existing CI/deploy workflow and does not implement a permanent runtime deployment gate. Root owns only these isolated sources; parent owns publication, bounded bootstrap activation and workflow execution.

Before running: independently accept actual bootstrap changeset and its runtime policy/document readback, keep its account/region conditions, preserve exact immutable OIDC sub/aud, and complete required source/prerequisite gates. Quarantine deny-all must be replaced only through the separately reviewed parent activation. A quarantined run fails and does not prove context. Avoid simultaneous main pushes while qualifying.

The action is pinned to the same configure-aws-credentials commit as delivery. It obtains genuine OIDC credentials for the exact role/account, clears prior runner credentials, does not use existing credentials, and applies an additional read-only session policy allowing only GetCommandInvocation/ListCommandInvocations with the SAME ResourceAccount/RequestedRegion conditions. Successful calls therefore cannot be explained by a synthetic IAM context or an unrestricted alternate session grant. STS authentication/caller checks performed by the credential action precede the two SSM calls. No SendCommand permission exists in the session ceiling.

Parent runnable command after reviewed gate-only publication and separately authorized bounded activation:

```bash
gh workflow run oidc-result-preflight.yml --repo PocketShell-io/pocketshell-gateway --ref main \
  -f preflight-command-id=104ba941-344f-4fd6-b9cb-707c54488f28
```

Inspect the exact run ID/head SHA, event workflow_dispatch/ref main, non-skipped successful job and step summary. Require BOTH live actions ALLOWED on the exact existing command/instance, sourceRevision matching the published reviewed gate commit, and runtimeProtection NOT_PROVEN. Failure, skipped job, expired/pruned command or changed receipt is no approval: preserve logs, independently review a new command binding if needed, and keep the IAM conditions. Do not substitute AWS operator credentials or remove conditions to obtain a pass. Only after this evidence and the independent target/runtime gates may parent publish/activate routine main deployment.

Pinned action input meanings verified against [the exact action source](https://github.com/aws-actions/configure-aws-credentials/blob/e1253824e5c10ff9df46874f81ed3ec929e19cfd/action.yml). Local behavioral fixtures exercise the actual workflow shell blocks with fake metadata-only AWS responses; they are not live AWS/OIDC acceptance.
