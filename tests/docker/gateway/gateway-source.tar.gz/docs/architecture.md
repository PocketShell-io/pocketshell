# PocketShell Gateway architecture

Status: integration worker view of the gateway binary (`relay.go` at the
repository root), covering the deployed legacy WebSocket↔TCP SSH proxy, the
hardening added around it, and the fail-closed integration point for the new
identity registry and reverse tunnel. Worker package docs:
`sibling worktree docs/identity.md` (internal/identity, committed) and the
tunnel worker's doc (internal/tunnel, in progress) — this file references
their contracts, it does not restate them.

## 1. What runs where

One Go binary, one t4g.nano instance (stack `pocketshell-relay`, account
817685572750, eu-west-1, EIP 52.213.219.13 — see `infra/legacy-stack.yaml`):

- **:443** — the (W)SS server. `/healthz` for CI; `/identity/v1/*` only when
  the registry is configured; everything else is the legacy proxy.
  **HTTP/1.1 only**: HTTP/2 is explicitly disabled (an empty
  `TLSNextProto` map and an ALPN list of just `http/1.1`), so one
  connection is one request at a time and the per-connection admission
  cap below cannot be multiplexed past (finding A19).
- **:80** — ACME HTTP-01 challenges and a plain-HTTP `/healthz` probe.
  **No redirect, ever**: WebSocket alias hostnames must not bounce, and
  nothing else lives on this port. (TLS-ALPN-01 is not offered; HTTP-01 is
  the configured challenge type.)

Canonical hostname: `gateway.pocketshell.io`. `relay.pocketshell.io` remains
a TLS/HTTP alias during client migration (see `docs/migration.md`); both are
in the autocert whitelist via `-domain` + `-aliases`. Deployment status is
deliberately not promoted here: the canonical DNS record exists, but trusted
TLS on both names and deployment acceptance are coordinator-owned gates that
are still pending — this document describes the committed binary and
configuration, not an accepted production rollout.

## 2. The legacy proxy (deployed wire contract, frozen)

The browser speaks SSH itself; this process ferries opaque bytes between its
WebSocket and a TCP stream. Success path is frozen to the reference worker
(`pocketshell-web relay/src/worker.ts`):

```
GET /?token=<Google ID token>&host=<host>&port=<n>
400  bad host or port        (malformed, syntactically private, or DNS
                             resolving into forbidden space)
401  unauthorized            (token missing/invalid/not allowlisted)
426  pocketshell relay       (not a WebSocket upgrade)
502  dial failed             (TCP refused/timed out)
101  Switching Protocols  →  opaque binary frames both ways;
                             client text frames are forwarded as bytes
```

Hardening adds statuses only on requests that previously failed anyway:
**403** cross-origin browser request, **429** per-account session cap,
**503** relay full / handshake bound / handshake timeout. One behavior
delta, documented for clients: a request arriving when the relay is full
used to get `101` and an immediate close; it now gets a clean pre-upgrade
`503`.

Request processing order in `establish` is the security order:

1. 426 gate (must be a WebSocket upgrade)
2. handshake-slot admission (bounds the unauthenticated phase, 503 when full)
3. host/port syntax + private-name pre-filter (400)
4. browser-origin allowlist (403) — requests **without** an Origin header
   are not browsers and skip this gate; they still hit auth
5. token verification with a 15 s handshake deadline (401)
6. capacity reservation — global pool **and** per-account — strictly
   **before** any DNS or TCP work (429 per-account, 503 global)
7. resolve once, vet every answer, dial vetted numerics (400 on forbidden
   resolution, 502 on dial failure)
8. WebSocket upgrade, then the bidirectional pipe

## 3. Trust boundaries and what the gateway can and cannot see

- **The gateway ferries SSH ciphertext, not plaintext.** Browsers run an
  SSH client over the WebSocket; the relay forwards opaque bytes it cannot
  read. A *malicious* gateway can still route, modify, drop or replay those
  bytes — but under the assumption that SSH, the endpoint and the client
  code hold, it cannot derive the user's private key or authenticate as the
  user: the client refuses an un-pinned or mismatched SSH host key before
  any authentication (`pocketshell-web` `src/terminal/connection.ts`). What
  an honest gateway compromise yields is traffic metadata (account email,
  target host:port, byte counts) plus every bearer credential presented to
  it — and those are not equal: the new API's broker JWT is scoped to
  gateway management and client routing with a ≤5-minute lifetime, while
  the legacy endpoint's Google ID token also carries sync-vault authority
  (the scoped-versus-legacy distinction detailed below). The endpoint SSH
  user key is not among them on the Go opaque path — the browser's SSH
  client holds the private key and the relay forwards only ciphertext —
  but the separate Lambda bridge (below) receives keys outright.
- **Identity is issuer+subject.** The legacy proxy keys accounts by
  verified email (frozen allowlist semantics). The new identity package
  keys accounts by `google:<sub>` — stable, not user-supplied, not the
  mutable email. New endpoints authenticate with bearer credentials in
  headers or the first WebSocket auth frame — **never** query parameters.
  The token-in-query on the legacy endpoint is wire compatibility only —
  it is why no code path ever logs request URLs, and why the log carries
  only account + host:port + duration.
- **Scoped routing credentials (finding C2).** A Google web ID token also
  carries GET/PUT/DELETE authority over the encrypted sync vault, so the
  gateway must never accept one on the new API. The trusted sync service
  (`https://a7sota2qic.execute-api.eu-west-1.amazonaws.com`, the broker)
  exchanges an authorized Google session for a short-lived (≤5 min) RS256
  JWT at `POST /gateway/token`: exact issuer (the API base), audience
  `pocketshell-gateway`, the fixed `pocketshell.gateway` routing scope,
  verified Google owner/email, and numeric `exp`/`iat`/`nbf` with a
  lifetime at or under five minutes. Verification is the shared
  `internal/routingauth.Verifier` (one verifier for every consumer — no
  duplicated crypto, claim or cache logic at the wiring site): exact
  issuer, exact string audience, required scope, required `iat`/`nbf`,
  `exp − iat ≤ 5 min` (hard maximum; a larger configuration is refused at
  startup), RS256 against the pinned JWKS, an expiry/context re-check
  after the key fetch, and the allowlisted owner. Issuer and JWKS are
  constant defaults plus `-broker-*` flags — HTTPS mandatory outside
  dev-listen, never discovered through the gateway, TLS verification never
  skipped. `-broker-allow-insecure-dev` is a pass-through to
  routingauth's own `AllowInsecureDev` mode for plain-HTTP lab fixtures;
  it is refused next to a public domain. A Google ID token shape (and a
  wrong-scope, over-lifetime, or not-yet-valid broker token) is rejected
  on the new API by regression.
- **Device identity is a registered Ed25519 key with proof of
  possession.** Enrollment (challenge → `identity.SignEnrollment` → enroll)
  binds device ID, account, domain, role, protocol and connection nonce
  into a single-use transcript. Key replacement requires explicit
  re-enrollment; revocation is terminal with durable key tombstones. See
  the identity worker's `docs/identity.md` for the exact contract; this
  binary mounts the service and wires its revocation callback into the
  tunnel service: containment (rename + tombstone) is applied before the
  tunnel is notified on **every** path — including durability-uncertain
  ones — and only the revocation's 200 ACK waits on a proven flush.

### Honest limits: explicit trust assumptions, no absolute guarantees

SSH authenticates the far end; it cannot save the near end. The browser JS
that speaks SSH runs with the user's unlocked private keys in memory. A
compromised PocketShell frontend (bad deploy, XSS, supply-chain) can use
those keys directly — tunneling through the gateway changes nothing there.
Trusted by assumption throughout this design: frontend delivery, the
browser/native client, the home OS and its sshd configuration, and the SSH
protocol with its endpoint and client implementations. Against a malicious
server, or a compromised client frontend/OS, no availability is promised —
and the guarantees below are conditional on those assumptions holding.

- **The admission/SSRF/capacity gates bind an honest implementation, not a
  malicious one.** The claim that the server "cannot be turned into an open
  relay even when fully compromised at the application layer" is false: a
  fully compromised gateway application can bypass its own code — route,
  modify, drop or replay the opaque SSH bytes, dial elsewhere, or refuse
  service. What stops a malicious gateway from *becoming the user* lives on
  the remote machines: the client verifies its independently provisioned
  SSH host-key pin before any authentication, the home sshd accepts only
  the user's own keys in `authorized_keys`, and the host agent dials only
  the operator-configured loopback SSH target (`internal/hostagent/localssh.go`
  refuses anything else). Under the assumed-secure SSH
  endpoint and client code, a malicious gateway cannot derive the user's
  private key or authenticate as the user. That sshd condition is an
  operator prerequisite, not a property of this code: it must hold as an
  effective key-only policy (`AuthenticationMethods publickey`, password,
  keyboard-interactive and empty-password/`none` login disabled) for
  **every username the routed listener admits**, because the opaque route
  lets a compromised gateway pick arbitrary usernames; the host-key pin
  identifies the server, not the daemon's allowed methods, and the
  enrollment host-key probe stops before user authentication. The
  operator-reviewed baseline and its `sshd -t`/`sshd -T -C` verification
  are documented in the host CLI onboarding (`docs/gateway.md` §2.1 in
  the pocketshell-cli repository).
- **A stolen broker JWT is not harmless — but it is not the account.** The
  scoped routing credential (≤5 min, `pocketshell.gateway`) authorizes
  gateway management — enroll/list/revoke — plus client routing, and the
  gateway necessarily sees it. A thief holding one can misuse exactly those
  capabilities: deny routing, revoke or re-enroll devices, register gateway
  records under the account. Endpoint SSH still requires the user's key —
  under the endpoint's effective key-only policy (above); a daemon that
  also accepts passwords accepts those over the tunnel too.
  Sync ciphertext CRUD authority remains a Google capability. The
  co-resident legacy direct/forwarding routes are one concrete way a
  gateway compromise acquires a valid bearer for an affected account;
  scoped-token use on a separate new connection does not remove that
  exposure. Reads, replacement and deletion remain subject to the sync
  API's ordinary policies and token validity; this is not proof of vault
  plaintext or SSH private-key recovery. Separately, a stolen Google
  session or compromised frontend has its own trust boundary that the
  broker-only connection cannot repair.
- **Enrollment and revocation are durable and operator-visible**, so a
  stolen enrollment can be cut off out-of-band: containment (rename +
  tombstone) applies before the tunnel is notified on every path, including
  durability-uncertain ones, and only the 200 ACK waits on the proven
  flush (host-side `authorized_keys` revocation is the endpoint backstop).

**Which server-side SSH paths exist.** The ordinary web direct path hands
the user's key to the browser's own SSH client only: the legacy Go
WebSocket upgrade request carries host, port and the Google token, and from
there the gateway forwards opaque SSH — it never receives the SSH private
key, passphrase or password. The *separate* legacy Lambda bridge
(`aws-infra/sandbox/pocketshell-web/lambda/index.mjs`, protocol in the web
workspace's `src/terminal/bridge.ts`) is different by design: the client
sends the private key, passphrase or password in its connect frame and the
bridge holds the server-side ssh2 session. A user who reuses the same key
on that bridge has placed it inside the bridge's trust boundary — a bridge
compromise defeats the home protection for that key. Likewise, the new
broker-only Go endpoints isolate Google authority, but the legacy
Google-token compatibility in the same Go process does not. Web-side
warnings and bridge fixes are client-worker deliverables still in progress;
nothing here claims every client path is protected.

## 4. The dial guard (SSRF / DNS rebinding defense)

Four independent layers, all fail closed:

1. **Syntactic pre-filter** (`isDialableHost`): lowercase hostname charset,
   no `localhost`/`*.internal`/`*.local`, no textual private IPv4 — mirrors
   the frozen worker's guard so obvious garbage never reaches DNS.
2. **Resolve once, vet everything** (`resolveAndVet` + `isForbiddenIP`):
   DNS is resolved a single time through the system resolver and **every**
   answer address is checked. Forbidden: all IPv4 non-global space —
   0/8, 10/8, CGNAT 100.64/10, loopback 127/8, link-local 169.254/16 (IMDS
   169.254.169.254), 172.16/12, 192.168/16, benchmarking/documentation/
   TEST-NET ranges, multicast 224/4, reserved 240/4 — and, for IPv6,
   everything outside global unicast 2000::/3 (loopback ::1, ULA fc00::/7
   incl. `fd00:ec2::254` metadata, link-local fe80::/10, multicast) plus
   in-global specials: Teredo 2001::/32, ORCHID, documentation 2001:db8::/32,
   6to4 2002::/16 (tunnel-embedded IPv4). IPv4-mapped IPv6
   (`::ffff:127.0.0.1`) is unmapped and judged by the IPv4 rules. A mixed
   answer (one public, one private record) poisons the whole answer.
3. **Dial numerics only**: the dialer connects to the vetted IP literals,
   never re-resolving, so a rebinding resolver cannot swap the address
   between vet and connect.
4. **Control-callback belt** (`vettedControl`): the Dialer's Control hook
   re-checks that the address the library is actually about to connect to
   is a member of the vetted set. A future edit that reintroduces a second
   resolution fails here instead of dialing.

`-dev-allow-private-hosts` bypasses layers 2–4 for local e2e (loopback sshd
containers). It is refused in combination with a public domain or with
`-registry` and never disables layer 1 or the frame limits.

## 5. Origin policy

`-origins` is an exact `scheme://host` allowlist. Browsers always send
`Origin` on cross-site WebSocket opens; a browser origin not on the list is
rejected with 403 before any auth or dial work. Exact matching is on
normalized scheme+host — suffix spoofs (`app.pocketshell.io.evil.example`),
port pins and scheme downgrades do not match. Requests without `Origin`
(CLI, tests, monitors) pass this gate and still need the token.

Defaults are the two hostnames that serve the PocketShell web app today
(`aws-infra/sandbox/pocketshell-web`: `app.pocketshell.io` is the canonical
CloudFront alias, the apex serves the same SPA):

```
https://app.pocketshell.io, https://pocketshell.io
```

Dev localhost is deliberately not a default; `-origins=` (empty) denies all
browser origins. www.pocketshell.io is not included (it serves the
GitHub-Pages landing, not the terminal app).

## 6. Bounds (all enforced in code, none disableable)

| Resource | Limit |
| --- | --- |
| Raw service connections (accepted sockets, pre-parse) | 256 (`netutil.LimitListener` on the raw :443 listener; pending TLS handshakes, hijacked WebSockets and mid-request connections all hold a slot until their socket closes — finding A15) |
| Raw ACME :80 connections | 32 (independent pool — certificate churn never competes with the service port) |
| Concurrent sessions, global | 64 (reserved before dial) |
| Concurrent sessions per account | 8 |
| Concurrent unauthenticated handshakes | 128 |
| Handshake phase (auth+DNS+dial) | 15 s deadline |
| TCP dial | 10 s, per candidate address |
| WebSocket frame (client→relay) | 512 KiB read limit, never lifted, dev included |
| TCP→client chunk | 32 KiB read, per-write 15 s deadline |
| Server ping / dead-client reap | ping every 25 s; read deadline 90 s, reset by pong or data |
| HTTP headers | ReadHeaderTimeout 10 s (also bounds the TLS handshake on the raw listener), MaxHeaderBytes 32 KiB |
| HTTP request body | whole-request read deadline 60 s from request start (finding A18 — the transport deadline that unblocks a stalled `Body.Read`); upgraded WebSocket sessions are exempt (gorilla clears conn deadlines on hijack; the pipe's own deadlines govern) |
| Identity API (when enabled) | see identity worker budgets (32 KiB bodies, 8 KiB tokens, 16 challenges/account, …) |
| Tunnel host agents (global) | 64 (`-tunnel-max-hosts`) |
| Tunnel client sessions (global / per account) | 64 / 8 (`-tunnel-max-clients`, `-tunnel-max-clients-account`) |
| Tunnel streams per host / window | 8 / 64 KiB (`-tunnel-max-streams-host`, `-tunnel-stream-window`) |
| Tunnel outstanding challenges | 256 (`-tunnel-challenge-capacity`) |
| Tunnel session lifetime | admission-time token expiry (zero/expired refused, `Principal.ExpiresAt` carried through the typed adapter) plus the tunnel service's absolute `MaxSessionDuration` (default 12 h, hard ceiling 24 h) — the short broker JWT governs admission only; an admitted session is NOT re-checked against the token mid-session and no re-authentication mechanism exists (finding F-14, stated as implemented) |
| Graceful drain window (per HTTP server) | 25 s (service :443) / 5 s (ACME :80), concurrent with independent deadlines; a spent window cancels that server's owned request contexts and force-closes its ordinary connections (`http.Server.Close`) |
| Final handler join | 10 s per join (`handlerJoinTimeout`) — legacy session WaitGroup, then tracked handlers, sequential (worst case ~20 s, not a shared global 10 s); a spent join is a hard error, never an unbounded wait |

**Aggregate budget on the live t4g.nano (512 MiB) — declared arithmetic,
NOT measurements.** Every number below is a configured bound multiplied by
a worst-case per-unit footprint; no load measurement has been run on the
instance.

- raw admission pool: 256 sockets × ~32 KiB (TLS record + HTTP read
  buffers, before any parsing) ≈ **8 MiB**;
- legacy proxy at capacity: 64 sessions × (512 KiB worst-case in-flight
  frame + 32 KiB TCP chunk + ~16 KiB conn buffers) ≈ **36 MiB** worst case
  (≈4 MiB steady state with real SSH-sized frames);
- tunnel hosts: 64 × ~24 KiB ≈ **1.5 MiB**;
- tunnel client streams: each client SSH session is one mux stream with
  64 KiB flow-control windows in both directions plus buffers — 64 global
  client sessions × ~144 KiB ≈ **9 MiB** (the per-host
  `-tunnel-max-streams-host 8` cap bounds any single host agent's
  fan-in beneath this);
- identity bodies: bounded by MaxBytesReader (32 KiB) per request —
  inside the raw pool's 8 MiB above;
- Go runtime + binary: ~30–40 MiB live, plus GC headroom (the runtime
  targets up to 2× live heap): budget **~80 MiB** combined.

Worst-case declared total ≈ **135 MiB** on 512 MiB, leaving ~375 MiB for
the OS and page cache. The previous "under 80 MiB" figure in this document
excluded worst-case WebSocket frame buffers and GC headroom and has been
corrected. The tunnel service additionally clamps every configured value
to its own hard ceilings, so a wiring mistake cannot unbound the
transport. (Measured acceptance on the real instance remains a
coordinator-owned deployment gate; nothing here claims a measurement.)

The pipe keeps **no unbounded queues**: client→TCP writes straight through,
TCP→client reads bounded chunks with write deadlines; a stalled client dies
instead of accumulating memory. All writes on a websocket (data, pings,
close) share one serialized writer with deadlines. When the WS reader exits
for any reason (client close, pong deadline, oversized frame) it tears down
**both legs** — a client disconnect can never strand a session or its
reserved capacity. Startup refuses the obvious misconfigurations: dev flags
with a public domain, dev flags with the registry, an empty allowlist on a
public listener, an insecure-broker opt-in outside dev-listen.

Shutdown is coordinated by a single lifecycle entrypoint (`run`, everything
after flag parsing; `main` only wires the signal context and turns a
returned error into a non-zero exit). SIGINT/SIGTERM cancels the lifecycle
context, which triggers one drain, in order: every tunnel host agent and
client stream is disconnected first (identity applies the revocation —
rename + tombstone — before notifying; the durable flush gates only the
revocation's 200 ACK, never the containment), then the root-owned handler
tracker engages its admission shutter and force-closes every hijacked
socket, then both HTTP servers stop accepting and drain — the service port
with a 25 s cap, the ACME :80 port independently with a 5 s cap. Each
server's request contexts derive from a lifecycle-independent context that
the drain deliberately keeps live through the graceful window — cancelling
it at drain start would silently end the graceful window it exists to
protect. Only when a server's Shutdown bound is spent does the drain cancel
that owned request context and force-close the server's ordinary
(non-hijacked) connections with the standard `http.Server.Close`, so a
handler blocked on a dead client unblocks instead of outliving the budget;
`Close` leaves the hijacked sockets alone — `beginDrain` already closed
those at drain start.

After both graceful windows close, `run` joins the remaining handlers under
an explicit bound (10 s per join, the `handlerJoinTimeout` constant): first
the legacy relay's hijacked sessions — the drain already force-closed their
sockets at the shutter — then, through the root-owned `handlerTracker`, the
handlers `http.Server.Shutdown` ignores (they hijacked their connection) and
`tunnel.Service.Close` does not cover: an upgraded host agent parked before
its signed proof, a client WebSocket parked before its first auth frame,
live client bridges, and mid-flight plain requests. The tracker counts every
handler from its first line, records each hijacked socket at `Hijack`,
force-closes those sockets at drain time (so parked pre-auth handshakes end
immediately instead of surviving their handshake deadline), and refuses new
handler work once the shutter is engaged (no new upgrades mid-drain, and no
count-increment can race the join). The two joins run sequentially, each
with its own 10 s bound — the bounded worst case is ~20 s of joining, not a
single shared 10 s allowance (the waits on the ACME-serve and drain
goroutines just before them are serving/drain coordination, not handler
joins).

Exit status is the drain's honest verdict, not a termination guarantee.
Exit code 0 requires a full join: every legacy session and every tracked
handler finished inside its bound, with no other recorded error. A drain
that spends its Shutdown bound is recorded as run's error (after the
owned-context cancel and force-close above), and a join that outlives its
bound — a handler that cannot finish — is likewise a non-nil error and a
non-zero exit: `run` never reports an incomplete drain as success and never
waits forever for a handler. The converse is stated just as plainly: a
non-zero exit does NOT promise that every handler goroutine was terminated
at the moment `run` returned. A non-cooperative legacy session leaves the
WaitGroup waiter goroutine parked past the bound until the process's hard
exit reaps it — no absolute availability or termination guarantee is
claimed, consistent with the trust assumptions above. `http.Server.Serve`
returns `http.ErrServerClosed` on every coordinated shutdown, and that
expected return is handled as success. A REAL in-Serve failure (the ACME
challenge server dying, a service accept error) takes the same coordinated
drain and is surfaced as the process error (non-zero exit) naming the
failing server; no serving goroutine ever calls `log.Fatal` (the previous
wiring exited mid-drain on SIGTERM and let the ACME goroutine kill the
whole process). Startup failures — refused configuration, failed verifier,
refused binds — surface as errors before serving; an ACME bind failure
after the service port bound releases that port again. These properties are
regression-tested against the entrypoint itself (`lifecycle_test.go`: the
pre-auth agent/client windows are held across a drain with a deterministic
completion seam proving `run` joins handler teardown before returning on a
healthy drain; a real stalled request body whose 500 ms drain bound is
spent is force-closed, and `run` returns a non-nil "service drain" error
instead of waiting; a completion parked so it cannot finish makes `run`
return at the join bound with a non-nil "handler join" error instead of
reporting success; the admission shutter refuses upgrades mid-drain) and
against the real binary as a process (SIGTERM with an active
REAL-AUTHENTICATED, independently-pinned SSH session — and, separately, a
legacy hijacked session — exits 0 after a non-timeout teardown whose
backend close is proven by the lab sshd's own counters; a refused bind
exits non-zero).

## 7. Registry / new API integration state (honest)

The new versioned API is **disabled by default and in the committed
deployment configuration**: the systemd unit in `infra/legacy-stack.yaml` runs
`pocketshell-relay -domain … -allow …` with no `-registry`, so a deployment
of this configuration reports
`"registry":"disabled","tunnel":"disabled"` and neither
`/identity/v1/*` nor `/api/v1/*` is mounted. Enabling requires:

- `-registry <path>` where `<path>` is absolute **under
  `/var/lib/pocketshell-relay`** (enforced at startup; the autocert cache
  already lives in the same directory) — durable device-registry state has
  exactly one home;
- a non-dev configuration (`-dev-allow-any-token` /
  `-dev-allow-private-hosts` are refused together with `-registry`);
- broker credential configuration: constant defaults exist for the trusted
  sync broker (`-broker-issuer`, `-broker-jwks`, `-broker-audience`); an
  `http://` override exists only with explicit `-broker-allow-insecure-dev`
  on a dev-listen (domain-less) process. TLS verification is never
  skipped.

When enabled, the integration constructs, in order:

1. the **identity service** (`internal/identity`): `challenge`, `enroll`,
   `devices`, `devices/{id}/revoke` under `/identity/v1/`, bearer-token
   auth in headers (never URL), domain binding into challenge transcripts,
   its own budgets and admission gates (round-eight: admission rechecks at
   every operation point and a final authorization gate under the store
   lock — internal to the package, no root wiring needed), and the
   **scoped broker verifier only** — a Google ID token is never accepted
   on this path (C2). The verifier is wrapped in an expiry gate that
   rejects zero-expiry, expired, or cancelled admissions before any
   handler; the transport-level whole-request read deadline above bounds
   stalled request bodies (finding A18) — an admission whose context dies
   or whose token expires while the body drips in cannot apply state.
   Identity additionally carries its OWN network body deadline
   (`identity.Config.RequestReadDeadline`, wired nonzero by the root
   factory: 15 s, matching the legacy auth/handshake budget): the strict
   body decoder waits for the definitive end of the body, and the
   whole-server 60 s bound alone is only a weaker outer bound shared with
   every other route. The handler's `SetReadDeadline` is the effective
   deadline on identity routes — it reaches the real writer through the
   lifecycle wrapper's `Unwrap` — so stalled identity bodies close at the
   identity bound, well before the server bound could fire.
2. the **reverse tunnel** (`internal/tunnel`) on top of it:
   `/api/v1/agent/connect` for host agents (server-first Ed25519 challenge
   over the identity challenge transcript, generation-guarded against
   revocation races) and `/api/v1/hosts/{deviceID}/ssh` for clients (first
   WebSocket auth frame carries the scoped credential; ownership derives
   from the verified account vs the registered device; unknown,
   other-owner and offline devices get one uniform denial — no existence
   oracle). The typed adapters in this binary (`tunnelStoreAdapter`,
   `tunnelAuthAdapter`) are the only conversion point between the
   packages' named types, and `tunnelAuthAdapter` copies `ExpiresAt`
   through: the tunnel refuses a zero/expired principal at admission and
   bounds every admitted session with its absolute `MaxSessionDuration`
   (default 12 h, hard ceiling 24 h); there is no mid-session
   re-authentication.
   The tunnel service owns its published route parsing end to end — root
   adds no path rewriting. Revocation ordering (finding A1): the identity
   service APPLIES the revocation — atomic rename + key tombstone — and
   then fires `OnRevoke` from its HTTP handlers on **every** path; on the
   durability-uncertain path the containment has already fired even though
   the caller sees 500, and only the 200 ACK is gated on the proven flush.
   The callback tears the host connection and every stream down.

`/healthz` reports the two postures independently: `"registry"` reflects
the identity service construction, `"tunnel"` the tunnel service — a
configured registry whose tunnel failed to build reports
`"registry":"enabled","tunnel":"failed"` and serves no tunnel endpoints.
A registry that fails to construct reports `"failed"` and serves nothing;
the legacy proxy is unaffected either way.

**Open cross-worker items at integration time** (tracked in the
source-review ledger): the real host agent still treats the tunnel's
revocation rejection as retriable (its handshake reader consumes the
error text frame before the application close frame its `classify()`
maps to fatal), so a revoked agent retries until its context ends —
server-side refusal is proven in the wiring tests; the agent-side fatal
classification is the hostagent worker's. The tunnel package's own suite
had one timing-sensitive failure on the first integrated run and passed
three consecutive reruns (owner informed).

## 8. Build, release, verification

```
go build -ldflags "-X main.version=$(git describe) -X main.commit=$(git rev-parse HEAD)" -o pocketshell-relay .
```

`/healthz` answers (both listeners, any configured host):

```json
{"service":"pocketshell-gateway","version":"…","commit":"…","status":"ok","registry":"disabled","tunnel":"disabled"}
```

CI uses this for deploy verification and rollback: version/commit must
match the artifact; `registry` and `tunnel` must match the intended API
posture. The endpoint is unauthenticated by design and carries no secrets.

Tests live beside the binary: dial-guard and rebinding attacks
(`dialguard_test.go`), the frozen wire contract, origin policy,
capacity-before-dial, ping/pong liveness, oversized frames, copy cleanup
and shutdown (`relay_test.go`), configuration invariants
(`config_test.go`), registry and tunnel wiring with the identity worker's
test verifier (`registry_test.go`), the scoped broker verifier against the
real `internal/routingauth` module — real RS256/JWKS over TLS, strict
claim/scope/lifetime matrix, Google-token rejection, expiry gate,
dev-insecure pass-through (`broker_test.go`) — real host-agent enrollment
and transport e2e over the production wiring, including revocation
containment on the uncertain-durability path (`tunnel_wiring_test.go`),
raw-listener admission caps with hijacked WebSockets and shutdown release
(`listener_test.go`), and the production HTTP server factory: no HTTP/2
negotiation, functional ACME certificate policy, bounded stalled/trailing
request bodies with no side effects, and upgraded sessions surviving the
HTTP body deadline (`httpserver_test.go`). Run with `-race`; the suite
asserts capacity release and goroutine cleanup under the race detector.
