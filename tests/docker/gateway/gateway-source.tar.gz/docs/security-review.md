# PocketShell gateway — security review (astra-security-review)

Worker: independent defensive security validation (`security/**`,
`docs/security-review.md` only). Last updated: 2026-10-07.

## 1. Scope, authorization and method

Task: validate the end-to-end SSH trust boundary of a public reverse tunnel
with standard positive/negative integration tests, under the documented
threat model (docs/design.md, implementation checklist): the gateway is
UNTRUSTED — it holds valid routing credentials, controls routing frames and
can substitute endpoints; it must never grant shell access without an SSH key
authorized on the local host.

Constraints honored: disposable local labs only (loopback listeners and local
Docker containers); all keys/accounts ephemeral and generated per test run; no
public service testing, no AWS/GitHub mutations, no pushes, no real user data;
benign `echo`/`seq` commands only as positive controls (no exploit tooling, no
intrusion payloads).

Method: executable tests, not claims. Every assertion observes a real
outcome — shell output, the real SSH server's auth counters, connection
counts of a protected "sensitive local service", OpenSSH client exit
codes/stderr, and container-internal sshd logs.

## 2. Test architecture and evidence classes

One assertion suite, three execution classes (results are always labeled):

| Class | What runs | Where | Status |
|---|---|---|---|
| **In-process (reference SUT)** | `security/sshlab` fixtures: public-key-only x/crypto/ssh server with auth counters, reference destination-pinned host agent, lab identity registry (single-use domain-separated challenges), adversarial gateway fixture | Go test process, `-race` | **PASS** (S1–S10, stable ≥8 consecutive runs) |
| **Docker-executed (reference fixture, real OpenSSH both ends)** | gateway fixture container (single-file rootfs) ⇄ home container with **real OpenSSH sshd on 127.0.0.1 inside the container, no published host ports**; **real `ssh` client on the host** via a stdio⇄WS ProxyCommand bridge with pinned host key | local Docker (bridge network, unique names, full teardown) | **PASS** (D1–D6) |
| **Production-integrated** | real `internal/tunnel`, `internal/hostagent`, `internal/identity`, `internal/routingauth` and the real CLI binary exercised through their actual APIs | in-process (`-race` in combined runs) | **12/13 PASS; P7 FAIL (FH-1) → CHANGES REQUESTED** — see §6 |

The adversarial gateway fixture stays ours in every class: in production mode
it IS the compromised-gateway position (production components connect to it
voluntarily via the documented insecure-dev transport), which is the strongest
executable form of the threat model.

## 3. Threat matrix

Attacker positions and the properties that must hold. S* = in-process
reference, D* = Docker/real-OpenSSH, P* = production-integrated.

| # | Attacker position / behavior | Required property | Tests | Result |
|---|---|---|---|---|
| 1 | Honest user with authorized key | benign sentinel executes end-to-end | S1, D1 | PASS / PASS |
| 2 | SSH client with unknown key | userauth rejected, no shell | S2, D3 | PASS / PASS |
| 3 | SSH client attempting passwords | password/keyboard-interactive never offered; denied | S2, D4 | PASS / PASS |
| 4 | Gateway with valid relay/device credentials but no authorized SSH key | its own SSH client is rejected by the real home sshd; relay unharmed | S3, D6 | PASS / PASS |
| 5 | Gateway substitutes the SSH host key (MITM) | client refuses at key exchange, BEFORE userauth; real sshd sees nothing | S4, D2 | PASS / PASS |
| 6 | Replayed device proof (captured nonce+sig on a fresh connection/challenge) | rejected; live connection unaffected | S5 | PASS |
| 7 | Wrong device key signing a fresh valid challenge | rejected | S5 | PASS |
| 8 | Challenge reuse (single-use violation), cross-connection nonce binding | rejected at the registry | S5 | PASS |
| 9 | Gateway injects an arbitrary local destination into stream-open frames | agent ignores it; dials only the configured loopback sshd; sensitive service: 0 connections | S6, D5 | PASS / PASS |
| 10 | Cross-account routing (honest gateway) | refused: no route to another owner's host | S7 | PASS |
| 11 | Compromised gateway routes cross-account anyway | end-to-end SSH still isolates: foreign key denied on the host; owner-only list/revoke enforced | S7 | PASS |
| 12 | Revocation of a device | active session torn down; reconnect + attacker handshake refused; silent re-key refused | S8 | PASS |
| 13 | Malformed frames (oversized, garbage tokens, pre-auth frames, truncated framing) | connection fails closed; honest traffic unaffected | S9 | PASS |
| 14 | Slow/dead consumer | stream killed within a bounded time; service recovers; no unbounded queueing | S10 | PASS |
| 15 | Whole suite under load/races | `-race` clean; goroutine counts return to baseline (S11) | all | PASS |
| 16–23 | Production-API versions of 1,2,4,5,6,9,12,13 + broker-token lifetime | real `internal/tunnel`/`hostagent`/`identity`/routingauth via actual APIs | P-suite | **CHANGES REQUESTED** (§6) |

## 4. What SSH end-to-end cannot protect (exact reasons)

1. **Availability.** SSH authenticates and encrypts a byte stream; it cannot
   force bytes to flow. The gateway (or anyone on its path) can always refuse
   connections, drop them mid-stream, or keep them half-open. A compromised
   gateway is a self-inflicted outage, not an SSH property. The suite proves
   only that the tested opaque-SSH interference does not produce shell
   access or expose SSH stream plaintext under its endpoint/key assumptions
   (S9/S10). It does not establish whole-runtime sync-credential isolation:
   the co-resident legacy direct/forwarding proxy still receives Google
   bearers that authorize affected accounts' sync ciphertext CRUD. A
   captured valid bearer can expose, replace or delete ciphertext subject
   to normal API policies; that is separate from proving vault decryption
   or recovery of an SSH private key.
2. **Traffic metadata.** The gateway must see connection times, durations,
   byte counts/timing, IPs and device/account routing state to route at all.
   SSH encrypts stream *content* and authenticates endpoints; it does not and
   cannot hide flow metadata from the relay that carries it. Anyone claiming
   "the gateway learns nothing" is wrong. This SSH-focused evidence
   protects stream content and endpoint private keys; it does not exclude
   the legacy bearer/sync ciphertext authority described above. The broker
   token's five-minute lifetime does not shorten a captured Google token's
   validity or erase previously captured ciphertext.
3. **Compromised frontend delivery.** SSH protects a session only if the
   client code path that originates it is trusted. If the web frontend (or
   the update/delivery channel serving the SSH client) is compromised, the
   attacker can steal keys, exfiltrate plaintext before encryption, or pin
   the wrong host key with user consent — all before SSH's protections
   apply. Trust in the session is inherited from trust in the client
   delivery; no server-side measure can repair it. (The suite's MITM tests
   cover a network-position key substitution — S4/D2 — which is precisely
   why the independent, out-of-band host-key pin is load-bearing.)

## 5. Baseline results (reference suites)

Executed commands (from the repository root):

- `/usr/local/go/bin/go test -race ./security/ -count=1 -v` — in-process
  suite S1–S10 + goroutine-leak checks; ≥8 consecutive clean runs.
- `/usr/local/go/bin/go test ./security/ -run 'TestD' -count=1 -v` — Docker
  suite D1–D6; 2+ consecutive clean runs, each with real `ssh` (OpenSSH
  9.6 client) against real `sshd` (OpenSSH 9.7, in-container, loopback-only).
- `/usr/local/go/bin/go test -race ./security/ -count=1` — combined run: ok.
- `/usr/local/go/bin/go build ./...` — module builds.

Key observables asserted (not trusted claims): sshd auth counters
(`AuthAccepted`/`AuthDenied`/`ShellsGranted`/`Connections`), client-visible
rejections (`host key mismatch`, `no supported methods`, `Permission denied
(publickey)`, `Host key verification failed`), protected-service connection
counts (always 0 under substitution attacks), gateway slow-kill counters,
container sshd logs unchanged during MITM, and goroutine baselines.

Fixture notes (honest limitations of the reference suites): the reference
gateway/agent/registry are lab implementations that pin the contract — they
demonstrate the assertions are real, they do NOT demonstrate that the
production packages satisfy them; that is the P-suite's job (§6). The lab
sshd restricts exec to a benign allowlist (`echo`, numeric `seq`) — the
positive control is a real command execution over real SSH framing with no
interactive shell. Lab account tokens are HMAC-signed stand-ins for verified
issuer+subject JWTs.

## 6. Production-integrated suite — results: CHANGES REQUESTED (1 defect)

The production suite (P1–P13, `security/prod_test.go` +
`security/prodharness_test.go`) drives the REAL packages through their
actual APIs: `tunnel.NewService(ServiceOptions{Store, Authenticate,
Limits})`, `hostagent.NewAgent(AgentConfig).Run(ctx)` (default clock),
`identity.NewService(Config)` over HTTP `/identity/v1/challenge|enroll|
devices/.../revoke` with `identity.SignEnrollment`/`ChallengeFromWire`,
the real `routingauth.NewVerifier(...).VerifyToken` against locally signed
broker-shaped RS256 JWTs (≤5-minute lifetime), client path
`/api/v1/hosts/{deviceID}/ssh` with the first text frame
`{type:auth,v:1,token,device_id}` → `ready` → opaque SSH bytes, and agent
path `/api/v1/agent/connect` with the server-first challenge. The real CLI
binary (`cmd/pocketshell-link`) is built and executed for enroll/run/show
with `--server` + explicit `--insecure-dev` + `--dev-broker-issuer`.
Copied production trees are READ-ONLY, untracked, sha256-pinned in
`.tmp/prodsnap-receipt.txt` (identity/routingauth @ 212117b incl. 12daba3;
tunnel/hostagent/CLI @ 36ccd32); no dependency file is staged.

Results (all in-process, ephemeral keys, `-race` in the combined run):

| Test | Scenario | Result |
|---|---|---|
| P1 | positive control: real enrollment + broker-token admission + gateway + agent + SSH sentinel | PASS |
| P2 | unknown SSH key; password-only attempt | PASS (both denied) |
| P3 | MITM rewrites ready `ssh_host_key` | PASS (contract client aborts pre-userauth; rewrite inert for pin-verified clients — session provably lands on the real sshd) |
| P4 | wrong device key; MITM-captured proof replay; enrollment challenge replay (real API) | PASS (all rejected; honest agent stays connected) |
| P5 | cross-owner dial/revoke/list; non-allowlisted credential | PASS (uniform not_found; verifier refuses) |
| P6 | loopback-only validation; OPEN frame has zero payload; sensitive probe untouched | PASS |
| P7 | revocation: session teardown + future denial + agent fatal surfacing | **FAIL — FH-1** |
| P8 | malformed frames (binary-first, oversized, garbage SSH bytes, JSON-after-handshake) | PASS (fail closed; recovery dial+SSH 8 ms) |
| P9 | slow consumer: stalled transport torn down at configured bound | PASS (10 s; host leg survives; gateway recovers) |
| P10 | 16 credential-boundary negatives + expiry-after-wait + F-09 zero-HTTP | PASS |
| P11 | session bound vs admission lifetime (3 s kill with valid 5-min token; 12 h default / 24 h hard; 5 min broker) | PASS |
| P12 | revocation under injected dir-fsync fault: HTTP 500 (no ACK) yet active SSH torn down, state on disk, re-registration denied; retry acks 200 | PASS |
| P13 | real CLI: enroll/run/show positive + Google-token refusal with zero HTTP | PASS |

**FH-1 (requested change, owner: hostagent):** after a revocation the
gateway denies everything server-side, but the agent never surfaces the
fatal rejection: the gateway's `{"type":"error","code":"revoked"}` frame
unmarshals into `OKMsg` in `internal/hostagent/agent.go` `session()`, hits
the generic "unexpected handshake reply type" error instead of
`errFatalAuth`, and `Run()` retries forever (captured in the P7 test log).
`pocketshell-link run` on a revoked device never exits with "gateway
rejected this device". Full details and requested fix:
`.tmp/security-requests.md` (FH-1). Additionally recorded (not a failing
test — shipped defaults are safe): FH-2, the mux stream window is not
negotiated on the wire (mux.go sendWin vs receive enforcement), so
asymmetric-but-valid `StreamWindow` configurations kill the whole host leg.

**Verdict: CHANGES REQUESTED.** 12/13 production tests pass against the
current snapshots; P7 fails on FH-1. No production file was modified by
this worker. No claim of accepted main is made until the coordinator's
ready-commit and a final rerun of both suites against it.

## 7. Astra status

The Astra-requested reviewer was blocked by runtime security screening (both
the original compromised-gateway task and a narrowed defensive Docker-only
task were rejected as "possible cybersecurity risk"). **No Astra test ran and
no Astra approval exists or is claimed.** The defensive suites above were
built and executed by authorized zcy workers under the user's explicit
disposable-local-lab authorization.
