# Identity working-source review, round two

Astra reviewed uncommitted source at 2026-10-07 04:52:44–04:53:29 UTC, without running tests or project code. Source implementation of I1, I3 and I5 was visible; no finding is accepted as closed until integrated regression evidence exists.

Remaining corrections assigned to ZAI:

1. Host enrollment must use actual identity endpoints, Bearer authentication, challenge device ID, integer expiry, URL-safe nonce encoding, canonical enrollment signature and returned device `id`. Test the real host agent against the real identity handler, stubbing only account verification.
2. The response must provide a complete public reconstruction contract for signing. Current response omits verified AccountID; the returned inner challenge transcript is incorrectly described as the exact enrollment bytes to sign. Expose the verified account and reconstruct/compare, or accept returned challenge bytes in a shared domain-separated enrollment helper. Add an independent fixed signing vector and reject the old signature.
3. Enforce the configured per-account quota with injected default stores as well as StorePath. A deterministic concurrent HTTP test with Config.Store and limit one must admit exactly one device.
4. Loading a v1 registry must derive tombstones from already-revoked records. Re-enrollment under another ID/account must fail before and after restart.
5. Prevent duplicate active registration keys or invalidate all copies consistently when revoking that key, including active connections. Existing duplicates cannot escape a key tombstone through GetDevice.
6. Tombstone capacity must not silently weaken a successful revocation. Reserve capacity or derive rejection from revoked records; test a small-capacity boundary.
7. Apply the default Google JWKS URL. Bound stale-key acceptance and outage refresh frequency; concurrent waiters must honor cancellation while another refresh performs I/O. Existing warm-cache unknown-kid coverage does not cover expired-cache outage bursts.
8. Directory-open/fsync failure must not acknowledge durability. Distinguish failure before rename from uncertainty after rename: restoring old in-memory state after the file changed is inconsistent. Test both stages and restart behavior.
9. Preserve populated Principal.ExpiresAt through the tunnel adapter and enforce the documented session lifetime, including expired and zero-expiry principals.

Regression quality corrections: the mode-flip test reuses a consumed challenge and therefore proves replay rejection rather than mode binding; use a fresh challenge. The quota test creates a release channel that is never awaited; force the intended interleaving. One tombstone regression uses an obsolete signature and fails before reaching tombstone admission; use a valid signature so the denial isolates that property.

All items remain in source-review-findings.md and the implementation checklist. This review is a repair assignment, not deployment approval.
