# In-progress source review and repair ledger

Date: 2026-10-07. Independent read-only reviewer: gpt-6-astra. Findings refer to in-progress worktree code, not a deployed build. No executable review was performed by Astra. Each item remains open until a regression test and an integrated rerun demonstrate resolution.

| ID | Finding | Owner | Required regression property | Status |
| --- | --- | --- | --- | --- |
| I1 | Enrollment proof omits registration public key, SSH host key and replacement mode | Identity | Altering any signed enrollment field is rejected | Assigned |
| I2 | Per-account quota check and insertion are separate | Identity | Concurrent enrollment cannot exceed a one-device quota | Assigned |
| I3 | Replacement can resurrect a concurrently revoked device | Identity | Revocation remains terminal through replacement races | Assigned |
| I4 | Revoked public registration key can escape under a new ID | Identity | Key tombstone survives alternate IDs and restart | Assigned |
| I5 | Aggregate challenge count needs a bound | Identity | Many accounts cannot exceed global challenge budget | Assigned |
| A1 | Revocation can finish between host lookup and registration | Tunnel | Paused old-key registration cannot succeed after revoke/replacement | Open |
| A2 | Mux completion is never signaled; closing accept channel races with send | Tunnel | Disconnect/revoke/concurrent OPEN terminate waiters and release admissions without panic | Open |
| A3 | Keepalive and data paths write concurrently to one WebSocket | Tunnel | Keepalive during sustained traffic is race-free and byte-correct | Open |
| A4 | Host socket retains authentication read deadline after success | Tunnel | Healthy host survives multiple handshake deadlines; stalled host expires | Open |
| A5 | Incoming DATA ignores receive credit; WINDOW grants are unrestricted | Tunnel | Excess data/credit rejected before bounded buffers can overflow | Open |
| A6 | Unexpected OPEN blocks the sole mux reader | Tunnel | Role-invalid OPEN rejected; slow admission does not block other streams | Open |
| A7 | Host limits not enforced atomically; pending client upgrades uncounted | Tunnel | Pending and established admission limits hold under concurrent handshakes | Open |
| A8 | ACK channel can become nil before Open begins waiting | Tunnel | Immediate ACK succeeds reliably and has no data race | Open |
| A9 | Empty JWKSURL bypasses the declared Google default | Identity | Default production verifier uses Google endpoint via local transport stub | Assigned |
| A10 | Late DATA/EOF/WINDOW for closed streams kill unrelated streams; OPEN timeout has no RESET | Tunnel | Cancellation cleans both sides while unrelated transfers survive late frames | Open |
| A11 | Small windows cannot replenish credit; concurrent writes overspend credit | Tunnel | Small-window transfer progresses; parallel writes never exceed grant | Open |
| A12 | JWKS refresh holds mutex across I/O, stale acceptance/cooldown are insufficiently bounded | Identity | Wait honors cancellation; failed refresh is rate-limited; stale acceptance has maximum age | Assigned |
| A13 | Directory fsync failures after registry rename are ignored | Identity | Revocation never acknowledges unproven durability; post-rename state is handled consistently | Assigned |
| O1 | Gateway-supplied ready SSH host key is not an independent client trust pin | Tunnel / client integration | Client validates a separately provisioned host key before SSH authentication | Open |
| C1 | Host enrollment and identity API disagree on path, bearer auth, fields, expiry/nonce encoding and signed transcript; response omits challenge account | Identity / host agent | Actual hostagent enrolls against actual identity.Service using one canonical helper; modified signed fields rejected | Assigned |
| A14 | Aggregate defaults exceed comfortable memory on live t4g.nano; challenge-capacity override ignored and local-dial timeout not capped | Tunnel / integration | Conservative documented rollout budgets include legacy traffic; configured limits applied/clamped; concurrent traffic stays within aggregate accounting | Assigned |
| C2 | Google routing bearer also grants sync authority over encrypted vault data | Broker / identity integration / client / host agent | New API receives only scoped broker token; gateway credentials rejected by sync GET/PUT/DELETE | Assigned |
| C3 | Background warning bridge sends raw SSH keys for hosts using other transports | Web client | Unlock/recall/navigation/refresh/ack with both URLs configured emits no credential bridge frame for direct/gateway hosts | Assigned |
| A15 | HTTP handler admission does not bound accepted sockets before HTTP/TLS parsing | Root integration | Listener cap includes pending and hijacked WebSockets; disconnect/shutdown release capacity; ACME listener separately bounded | Assigned |
| F-08 | Real host CLI enrollment misparses challenge prefix and JSON-encodes enrollment twice | Host agent | Actual CLI enrolls against actual identity API with shared canonical challenge decoding and one JSON encoding | Assigned |
| F-09 | Host helper help requests Google credentials and accepts them for transmission | Host agent / client | CLI requests a scoped broker token; Google bearer refused locally before any request; enrollment UI generates only broker credentials | Assigned |
| F-11 | Production RunAgent invokes an unset clock and panics | Host agent | Actual CLI run with default options connects without panic | Assigned |
| F-12 | Root integration verifier shim omits scope and lifetime/time-claim policy | Root integration / broker | Production root uses shared routingauth verifier; both registry and SSH route reject exact Opus negative claim cases | Assigned |
| F-13 | Agent authentication read deadline survives handshake and drops healthy sessions after ten seconds | Host agent | Actual agent/CLI carries SSH traffic beyond several handshake deadlines with keepalive and clean shutdown | Assigned |
| F-14 | Documentation claims token reauthentication while implementation checks admission only | Tunnel / identity / broker / root | Document and test admission-token expiry separately from bounded SSH-session duration; preserve expiry at admission | Assigned |
| A16 | Identity cooldown branch reads the JWKS cache after releasing its mutex | Identity | Recovery publishes keys while concurrent rate-limited callers run; no unlocked cache read and race suite passes | Source reviewed; package race pass |
| A17 | Identity authorization precedes body/lookup waits without current expiry/context revalidation; decoder can ignore a trailing read error | Identity | Expiry/cancellation after body or lookup refuses before admission; complete JSON followed by read error cannot pass | Assigned |
| A18 | HTTP request-body reads have no transport deadline after the authentication timeout ends | Root integration | Real slow/trailing-body HTTP requests end within a bound without side effects; upgraded healthy SSH sessions survive that HTTP bound | Source accepted at a408c19; integrated full race pass at acd3b86 |
| N1 | Android's pinned shared connection store drops gateway intent before the platform guard | Native client / core | Actual shared store and Android API refuse a synced gateway row matching a saved direct host before credentials or connection | Assigned |
| N2 | New Android guard test file is absent from the exact-result unit manifest | Native client | Canonical JS unit gate includes the new named regressions and reports the exact expected result set | Assigned |
| B1 | Broker and SSM stub model a missing previous key with the wrong AWS exception | Broker | Actual ParameterNotFound permits the documented empty previous slot; other retrieval failures return 503 | Assigned |
| B2 | Configurable broker signing-key paths can escape the instance role's denied namespace | Broker / infrastructure | Template, deployment and runtime reject paths outside the protected signing-key family | Assigned |
| B3 | Rotation test checks only RSA after expiry; emergency cache bound omits warm JWKS producers | Broker | Last-old issuance is verified with full claims at valid and expired times; removal bound includes publication and verifier caches | Assigned |
| W1 | Browser transport guards are not connected before credential access; malformed shared intent can downgrade | Web client | Actual webApi entry/payload validation refuses malformed, conflicting and mismatched markers before secret reads, broker or socket | Assigned |
| W2 | Broker fetch allows redirects and clears its deadline before body consumption | Web client | Redirects rejected; stalled successful/error bodies abort within the same bounded exchange deadline | Assigned |
| W3 | Browser accepts unchecked token type and inconsistent or malformed expiry fields | Web client | Exact Bearer and bounded numeric absolute/relative expiry fields required and checked together | Assigned |
| W4 | Warning bridge treats null Link metadata as a bridge target while connection chooses direct SSH | Web client | Direct host with null Link sends no raw credential to bridge across every warning action with both URLs configured | Assigned |
| W5 | Enrollment dialog retains expired/failed tokens and accepts completion after closing | Web client | Expiry disables copying; close, failure and regeneration clear state and invalidate outstanding completions | Assigned |
| W6 | Client token-exchange test bypasses actual webApi and never supplies the original Google credential | Web client | Real webApi exchanges distinct Google/broker sentinels; only scoped bearer reaches gateway, no fallback | Assigned |
| W7 | Browser ECDSA user-key signing reaches flagged elliptic implementation; PBKDF2 fallback is outdated | Browser crypto / web client | Signing refuses ECDSA before the flagged private operation; real Ed25519/RSA positives remain; PBKDF2 patch resolved and checked | eb9a6c8 source accepted; independent shim65/Node16/browser lab/build pass; combined production gateway/browser gate pending |
| T1 | Existing core Docker hazard test assumes local channel close proves server channel reclamation | Core test harness | Observe server-side reclamation before the late request; preserve original disconnect assertion and bounded cleanup | Independent source and 30 Docker tests accepted; published in core PR35/main4096fc5 |
| B4 | Broker's slashless default SSM lookup is rejected for hierarchical AWS parameter names | Broker / infrastructure | Validate configured names, send canonical leading-slash names to SSM, preserve exact IAM ARNs and reject invalid paths before SDK calls | Assigned |
| A19 | A connection cap alone does not bound HTTP/2 multiplexed requests and body readers | Root integration | Disable HTTP/2 on gateway listeners while retaining HTTP/1.1 and ACME ALPN, or enforce a global request budget with bounded body reads; test actual network behavior | Assigned |
| N3 | Android's default legacy shell drops synced gateway markers and dials outside the guarded shared API | Native client | Actual default sync/account-row selection refuses gateway intent before keyManager, controller, native calls or sockets; matching direct record cannot erase intent; packaged default/shared positives and refusals required | Assigned |
| B5 | Normal key rotation assumes old Lambda environments stop signing when their key cache expires | Broker / infrastructure | Observe explicit rollout/drain completion; retain OLD through last possible OLD issuance plus token lifetime/skew; full Go checks cover persistent old/new producers and no retirement without drain | ace5619 source accepted; independent59 actual Go/Node checks; live drain/clock/inventory evidence pending, no retirement |
| B6 | Deploy name equality check omits preserved stack references; JavaScript seal permits terminal line breaks | Broker / infrastructure | Effective current/previous pair validated before deploy, including one-sided overrides; LF/CR/CRLF inputs rejected before SDK calls | Assigned |

AWS naming evidence: on 2026-10-07 at approximately 07:31 UTC, the
coordinator created a temporary nonsecret String parameter named
`/pocketshell-sync/gateway-signing-key-name-probe-20261007-073145-a19f`.
GetParameter with the leading slash succeeded; the same hierarchical name
without it returned ValidationException. The cleanup trap deleted the
probe and the command exited successfully. No production signing key was
retrieved. The AWS parameter-name constraints and GetParameter API are
the authoritative contracts; accepting an optional slash in configuration
must not mean sending a slashless hierarchical name to AWS.

Rotation repair uses immutable key values and an atomic swap of current
and previous parameter references inside the instance-denied signing-key
namespace. Prepublish the new key, wait for producer and verifier caches,
then swap both references in one Lambda configuration update. Both exact
IAM resource grants cover the same old/new pair during that transition.
Retain the old key through warm-producer issuance and token expiry, with
clock skew. Tests must exercise every intermediate state with full Go
claim verification; a valid RSA signature after expiry is insufficient.

A16 evidence: efee6d6, integrated as c63b49f, snapshots the diagnostic's
cache-empty value under the same mutex used for publication. The
coordinator's identity race suite passed (14.390s); Astra confirmed the
source fix independently at 46961dd. Its review also notes that the
recovery tests do not deterministically hold the fetch until waiting
callers are confirmed; that stronger waiter assertion remains useful
follow-up evidence and does not close the separate admission findings.

A19 source precision: root relay.go uses a custom TLS config with
GetCertificate and ListenAndServeTLS, so net/http can automatically enable
HTTP/2. It does not currently call autocert.Manager.TLSConfig. Test the
actual production server factory's ALPN negotiation, body deadlines and
capacity reuse rather than inferring its policy from the autocert helper.

Native second-round review: core 98941b5, desktop d6238cc and Android's
staged vendor pin plus registered 14-test suite passed independent focused
checks, canonical 396-test manifest gate, typecheck and APK build. N1/N2
source repairs therefore have useful evidence, but N3 blocks overall
acceptance: the tests exercise the opt-in shared shell; the default legacy
App.vue projects account rows to ordinary host fields, writes a direct
draft, then calls keyManager and the connection controller directly.
No emulator was started against this known-broken flow. ZAI owns the
default-path repair; visible refusal, packaged CI and final published
combined-core pin parity remain required.

T1 follow-up: ZAI core fixture commit 849c731 reports six focused passes
and all 23 Docker tests passing. Independent source review rejects its
allocation-based observation: a different probe channel ID does not prove
the target slot was freed, and reusing the target then closing the probe
recreates the race. A separate ZAI corrective turn must observe the exact
server-side free event before injection; the green test result does not
close this proof requirement.

Identity admission interim review also keeps I2/A17 open: the service
quota and an injected authorized store's quota may differ, so admission
support does not justify removing quota serialization. An opaque-store
fallback cannot guarantee a final check under the inner mutation lock.
Both need explicit regressions and a supported atomic admission contract.

Broker follow-up at infra 0876443 / gateway 418e425: the coordinator ran
all 26 token tests successfully with zero skips and the Go bridge active.
Astra confirms canonical SSM addressing and protected-family checks, but
rotation remains unaccepted. An invoked old environment can reload its
immutable OLD parameter after every cache expiry. Its signing lifetime
requires a control-plane drain condition, not a five-minute cache bound.
Intermediate rotation tests must use full Go verification of the actual
old/new producer tokens. Removing OLD currently fails a fixture presence
assertion before VerifyToken; add a named OLD unauthorized / NEW accepted
verifier assertion. Human/core deny attachment remains unverified and
must not be described as deployed. ZAI owns these corrections.

The client and host SSH keys remain the shell authentication boundary even when the gateway ignores its own ACLs. Honest-gateway revocation and endpoint SSH-key revocation are separate guarantees. No finding is closed because another test suite happens to pass; rerun the exact property listed here.

Evidence sources: Astra architecture review in design-review.md; read-only source findings at identity/jwt.go, identity/store.go, tunnel/service.go, tunnel/mux.go and tunnel/transport.go. Opus independently raised O1, A5, A6 and admission/revocation concerns; its executable review results belong in opus-security-review.md.

Opus production-source Docker run (suite commit 8cfb707, integrated as
796cccd) executed against root wiring 1a4b5c3, main 12daba3 and a hashed
snapshot of uncommitted tunnel sources. It observed cross-owner isolation,
proof replay refusal, independent host-pin rejection, loopback-only
forwarding, and active revocation teardown. Normal CLI enrollment/startup
and sustained-session acceptance remain blocked by the failures above.
The fixture reports its stand-ins explicitly; they do not close CLI
failures. Accepted integrated-tree rerun remains required.
