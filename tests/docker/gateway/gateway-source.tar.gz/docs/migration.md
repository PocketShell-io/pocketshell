# Migrating relay.pocketshell.io → gateway.pocketshell.io

Audience: the coordinator and whoever operates the deployment. This covers
what changes in the gateway binary, in what order to move clients, and what
stays compatible. Infrastructure facts: stack `pocketshell-relay`, instance
`i-0dee79146aceb4014`, EIP `52.213.219.13`, Route53 zone
`Z041067223717ASYGLOOD` (verified inventory, `bootstrap-inventory.json`).
(2026-10-09 note: RelayInstance was replaced; the live instance is now
`i-0f9c18ce63cf6c26e`, same EIP. The ID above is historical inventory.)
All DNS/infra changes are coordinator-owned; this document only specifies
them.

## 1. Why

The relay was a personal single-user toy with a name to match. The gateway
is the front door for the PocketShell product: the same dumb WebSocket↔TCP
SSH proxy (frozen wire contract, now hardened), plus — behind an explicit
flag — the device registry and reverse tunnel endpoints. The canonical
name moves to `gateway.pocketshell.io`; `relay.pocketshell.io` stays
working as a TLS alias until the client fleet has moved.

## 2. Server-side steps (no existing-client cutoff)

1. **DNS (coordinator):** the `gateway.pocketshell.io` A record →
   `52.213.219.13` already exists in the zone; nothing to add there.
   Do **not** touch the
   `relay.pocketshell.io` record; both names point at the same host
   during the whole migration. (Trusted TLS on the canonical name and
   deployment acceptance are coordinator-owned gates still pending —
   see `docs/coordination-status-2026-10-07.md`; the certificate for a
   whitelisted name is provisioned lazily on its first HTTPS hit.)
2. **Deploy the new binary with both names** (delivery worker's pipeline;
   flag-level the invocation is):

   ```
   pocketshell-relay \
     -domain gateway.pocketshell.io \
     -aliases relay.pocketshell.io \
     -client-id 1035162854462-… \
     -allow <emails> \
     -origins https://app.pocketshell.io,https://pocketshell.io
   ```

   `-aliases` names are appended to the autocert whitelist
   (`gateway.pocketshell.io`, `relay.pocketshell.io`); each hostname gets
   its certificate lazily on first HTTPS hit, so provisioning the new name
   needs nothing but the DNS record. **No HTTP redirect exists on port 80**
   — alias hostnames are never bounced to the canonical name; the ACME
   challenge listener shares the port with an unauthenticated `/healthz`.
3. **Verify** before touching any client:
   - `https://gateway.pocketshell.io/healthz` and
     `https://relay.pocketshell.io/healthz` both return
     `{"status":"ok","registry":"disabled",…}` with the new version/commit;
   - an existing browser terminal session over
     `wss://relay.pocketshell.io/` still connects (frozen contract;
     hardening is intentionally invisible to legitimate clients).
4. **Rollback** at any point: redeploy the previous binary. The old binary
   accepted only `-domain` (no aliases/origins/registry/healthz flags) —
   the new flag set is a strict superset, so the old command line runs
   unchanged on the new binary, and the new command line can be dropped
   back to `-domain relay.pocketshell.io` if ever needed.

## 3. Client-side steps (per client, after step 3 above)

The only client that matters today is `pocketshell-web`, which pins its
relay in `.github/workflows/deploy.yml` as
`DIRECT_WS_URL=wss://relay.pocketshell.io/`.

1. Change the workflow to `DIRECT_WS_URL=wss://gateway.pocketshell.io/`
   and deploy. The value is build-time config, not user data — no stored
   per-account state mentions the relay hostname.
2. Browser behavior is unchanged: same query-string contract
   (`?token=&host=&port=`), same frames; the origin allowlist already
   contains `https://app.pocketshell.io` and `https://pocketshell.io`, so
   no web-side change is needed for the origin gate.
3. Watch `relay.pocketshell.io` traffic in the instance logs
   (`[account] host:port open/closed` lines) — **never** URLs; the query
   string with its bearer token is never logged. When the alias has been
   at zero sessions for a comfortable window (weeks, not days), drop it
   from `-aliases` and retire the DNS record (coordinator).

Other clients (CLI, desktop) that speak the legacy contract need exactly
one change: the `wss://` base URL. There is no client certificate, no
account migration, no server-side state keyed by hostname.

## 4. What behavior changed for clients (complete list)

Everything not listed here is byte-identical to the old relay.

| Situation | Old relay | Gateway |
|---|---|---|
| Relay at global capacity | `101` then immediate close | clean pre-upgrade `503 relay full` |
| One account, > 8 live sessions | worked (no per-account cap) | `429 too many sessions for account` |
| Browser origin not allowlisted | worked (no origin check) | `403 cross-origin not allowed` — default list covers both production web origins |
| DNS resolving to private/metadata IP | dial attempt leaked, then `502` | refused `400 bad host or port` before any socket |
| Slow/garbage HTTP handshakes | unbounded | bounded headers/timeouts; floods beyond 128 concurrent handshakes get `503` |
| Stalled or never-ending request bodies | unbounded read | connection closed within 60 s of request start (whole-request read deadline; finding A18); upgraded WebSocket sessions are unaffected |
| HTTP/2-capable clients | n/a (old relay had no TLS) | negotiate HTTP/1.1 — HTTP/2 is explicitly disabled on the gateway (one request per connection; finding A19) |
| Idle sessions | kept alive only by client traffic | server pings every 25 s; dead clients reaped after 90 s without pong/data |
| `GET /healthz` | did not exist | `200` JSON with version/commit/registry posture (also on :80) |
| Unknown new endpoints (`/identity/v1/*`, tunnel) | did not exist | `404`/relay-owned unless `-registry` is configured — fail closed |
| SIGTERM/SIGINT to the process | process exited **1** immediately (the shutdown itself was logged as fatal); active sessions cut mid-drain | coordinated drain — tunnel agents/clients disconnected, the admission shutter force-closes every hijacked socket (including tunnel upgrades still before their auth/proof), both listeners drained gracefully (25 s / 5 s caps; a spent cap cancels that server's owned request contexts and force-closes its ordinary connections; the already-hijacked sockets were closed by the shutter at drain start), then the remaining handlers are joined under an explicit bound (10 s per join — legacy sessions first, then tracked handlers; sequential, worst case ~20 s, not one shared 10 s). A healthy drain completes every join and exits **0**; a real server failure, a spent drain cap, or a handler that outlives the join bound returns a non-nil error and exits non-zero, after the same drain — an incomplete drain is never reported as success, and a non-zero exit is not a promise that every handler goroutine was terminated: a non-cooperative session can leave a waiter goroutine that only the process's hard exit reaps |

## 5. Enabling the new API (deliberately not yet)

The registry-backed endpoints stay **off** in this deployment until the
source-review findings close and the credential broker is live: the
systemd unit passes no `-registry`, and `/healthz` proving
`"registry":"disabled","tunnel":"disabled"` is part of the deploy
verification. When it is time:

1. Provision `/var/lib/pocketshell-relay/registry.json` (the only allowed
   location — the flag refuses paths outside it) on the instance.
2. Accept the scoped-credential broker (`docs/scoped-credential-design-review.md`):
   the sync API must issue `POST /gateway/token` RS256 JWTs (exact issuer,
   audience `pocketshell-gateway`, scope `pocketshell.gateway`,
   `exp − iat ≤ 5 min`, required `iat`/`nbf`) and publish
   `GET /gateway/jwks`, with the signing key denied to the instance. The
   gateway verifies all of it through the shared `internal/routingauth`
   verifier; the defaults already pin these endpoints, the issuer and
   JWKS are never discovered through the gateway, and TLS is never
   skipped. **Credential lifetime governs ADMISSION only**: a token that
   is expired (or whose principal carries no expiry) is refused when a
   client connects, but an already-admitted SSH session is bounded by the
   tunnel's absolute session-duration policy (default 12 h, hard ceiling
   24 h), not re-checked against the
   token's `exp` mid-session — there is no re-authentication mechanism, and
   no claim of expiry-driven session
   termination is made (finding F-14, stated as implemented).
3. Add `-registry /var/lib/pocketshell-relay/registry.json` to the unit.
   `/identity/v1/*` (challenge/enroll/devices/revoke) and the reverse
   tunnel (`/api/v1/agent/connect` for host agents,
   `/api/v1/hosts/{deviceID}/ssh` for clients) go live behind it; the
   legacy proxy is unaffected. **Every new-API credential is a broker
   JWT** — clients obtain it from the trusted frontend/service via the
   broker exchange; a Google web ID token is rejected on all new routes
   because its bearer would grant sync vault authority (finding C2).
   Enrollment and client sessions therefore require the broker to be
   independently trusted — the gateway does not run a local exchange.
4. `/healthz` postures are the deployment's honest signal: `registry`
   reflects the identity service, `tunnel` the reverse tunnel
   (`disabled` / `enabled` / `failed` each). A configured registry with a
   failed tunnel never claims a running tunnel.

Rolling back the API = remove the flag; enrolled device state survives on
disk and is picked up again on re-enable. Revocations are terminal and
tombstoned — re-enabling does not resurrect revoked keys.

**Legacy credential caveat during the migration window** (accepted risk,
temporary): the frozen legacy proxy still authenticates Google ID tokens
passed in the query string, and those tokens still carry sync authority
over the vault. A replayed stolen bearer is an otherwise-valid Google
token with no trustworthy origin signal — the sync service cannot tell
which service disclosed it, so no gateway-origin rejection can isolate
it. Closing this window is structural, not detection-based: retire the
shared Google bearer acceptance/use on the legacy proxy, or separate
credentials and audiences so the gateway path never presents a token
that also unlocks the vault. The new gateway must never expose a sync
bearer: no route echoes, logs, or forwards credentials, and no
background key-upload path may receive them (separate client-worker
deliverable). Account isolation from this legacy trust requires that no
simultaneous, background or other-device path send a valid sync-authorizing
Google bearer to the same runtime. The reviewed web client's direct SSH
and forwarding paths still do so; using a new scoped-token connection
does not close that account's exposure. Retire those raw-token callers and
acceptance, or isolate the legacy service behind a genuinely separate
execution boundary with no credential, memory, log or control access from
the new gateway. A second hostname/path or same-authority process is
insufficient. A retained isolated legacy service still holds its own
users' sync-authorizing credentials and remains trusted for that authority.

## 6. Security-relevant notes for the migration window

- Both hostnames terminate on the same process; the identity API's domain
  binding (challenge transcripts pin `gateway.pocketshell.io`) means a
  later move off the canonical name is a breaking change for enrolled
  devices — pick the name before enabling the registry, not after.
- The origin allowlist is a gateway-side hardening, not the auth
  boundary; the token is. Cross-origin pages still cannot use the relay
  without a valid allowlisted Google identity.
- Query-string tokens on the legacy endpoint are a legacy compromise,
  not the only one — the Lambda bridge (next bullet) receives SSH
  private keys outright. The new API never accepts URL auth. The
  no-credential claim is scoped to this process's audited application
  log sinks, which carry only account + host:port + duration; it is not
  a blanket statement about access logs — request-URL credentials must
  be kept out of upstream/access logs entirely, and any layer that
  records full request URLs cannot be treated as safe.
- The separate legacy Lambda bridge
  (`aws-infra/sandbox/pocketshell-web/lambda/index.mjs`, protocol in the
  client workspace's `pocketshell-web` `src/terminal/bridge.ts`) is a
  third trust boundary, distinct from relay and gateway: the client sends
  the SSH private key, passphrase or password in its connect frame and the
  bridge holds the server-side ssh2 session. A key reused on that bridge
  sits inside the bridge's trust boundary regardless of any gateway
  hardening. Consolidating client paths is client-worker scope and still
  in progress — this migration claims no protection for that path.
