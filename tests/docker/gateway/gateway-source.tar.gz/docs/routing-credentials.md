# Gateway routing credentials — the sync-service auth broker

Status: **gateway verifier integrated in root source; broker deployed
separately.** Live broker checks and remaining legitimate Google-flow and
gateway rollout gates are recorded in
[coordination-status-2026-10-07.md](coordination-status-2026-10-07.md).
The broker routes live in the separately trusted pocketshell-sync service
(aws-infra repo, `sandbox/pocketshell-sync`); this package
(`internal/routingauth`) is the gateway's verifier for the credentials that
service mints. Root wiring and AWS bootstrap were separate implementation
scopes; this credential contract alone does not certify their deployment.

## Why this exists (threat model)

A Google ID token — the credential the browser/desktop client already
presents — authorizes the user's *entire sync account*: `GET/PUT/DELETE` of
the (client-encrypted) settings ciphertext and the destructive sync
operations, at the sync API. Handing that token to the gateway would make a
gateway compromise a sync compromise: the gateway could read ciphertext
(offline-guessable under a weak passphrase), overwrite or delete slots, and
reuse the bearer token elsewhere while it lives.

Instead the **sync service itself acts as the auth broker**: it verifies the
Google token (its existing API Gateway JWT authorizer does this before the
request reaches the Lambda) and mints a **distinct, short-lived gateway
credential**. The new enrollment/client routes see only that credential:

- the broker token exposes routing and gateway account management (device
  enrollment, listing, revocation) for ≤5 minutes; it grants no sync CRUD
  authority and does not authenticate to Google;
- the SSH session itself remains end-to-end: routing credentials never
  authenticate SSH (client keys + pinned host keys stay the endpoint
  boundary, per the compromised-gateway model);
- there is no shared superuser token — every credential is bound to one
  verified account (`google:<sub>` + allowlisted verified email).

This is credential separation for the new routes, not whole-runtime or
whole-account isolation. The same Go process still receives sync-authorizing
Google tokens from legacy direct SSH and forwarding clients. Any account
using those paths remains inside that runtime's sync-credential trust
boundary, even if its other connections use the new routes correctly.
Captured valid Google bearers can authorize that account's ciphertext
reads, replacement or deletion under the sync API's ordinary policies;
they do not themselves supply the independent vault passphrase or SSH
private key. Retirement or genuine execution-boundary isolation is an
explicit [migration gate](migration.md#6-security-relevant-notes-for-the-migration-window).

## The two roles, in one sentence each

| Service | Role |
|---|---|
| pocketshell-sync (existing, separately trusted) | Verifies the Google login; issues `POST /gateway/token` credentials; publishes public keys at `GET /gateway/jwks`. Holds the signing private key. |
| gateway (this repo) | `internal/routingauth.Verifier` verifies broker tokens against the broker's public JWKS and admits routing/enrollment for that account only. |

The sync service does not gain any new authority over the gateway: it can
only mint ≤5-minute routing credentials for accounts already allowed by the
existing email allowlist, exactly like the gateway's own Google verifier
does today.

## Broker token contract

Compact JWS, `alg=RS256` only, `kid` = RFC 7638 thumbprint of the signing
key's public JWK. Claims — all fixed by the broker, nothing from request
input:

| Claim | Value |
|---|---|
| `iss` | exact sync API base URL, e.g. `https://a7sota2qic.execute-api.eu-west-1.amazonaws.com` |
| `aud` | `pocketshell-gateway` (string) |
| `sub` | raw Google `sub` |
| `email` | verified Google email (signed) |
| `email_verified` | `true` (issuance refuses otherwise) |
| `iat`, `nbf` | issuance time |
| `exp` | `min(iat+300, Google exp)` — hard 5-minute cap, bounded by the upstream login |
| `scope` | `pocketshell.gateway` — the route-permission marker |

Response of `POST /gateway/token` (behind the Google authorizer; body must
be empty): `{"token","token_type":"Bearer","expires_in","expires_at"}` with
`Cache-Control: no-store` — `expires_at` is the absolute Unix time the
token dies, equal to the signed `exp`, so browser clients can schedule the
re-mint without their own skew math. The Google access/id/refresh tokens
are never in the response and never logged.

Upstream claim runtime types are enforced strictly at issuance, never
coerced: `sub`/`email` must be nonempty strings (the email verbatim, no
trimming), the upstream `exp` must be a finite positive integer number of
seconds (number or digit string — malformed or overflow-sized forms are
rejected), and `email_verified` must be the boolean `true` or Google's
serialized `"true"` string. Identity can never enter through the request
body, and a request with no authorizer context stays unauthorized no matter
what its body carries.

`GET /gateway/jwks` is public and returns only public members
(`kty, alg, use, kid, n, e`) for the current key plus the previous key
through the rotation overlap window (the window closes at the retirement
bound proven in the rotation runbook — the last POSSIBLE old issuance
(authoritative flip-completion bound) plus token TTL, verifier cache TTL
and leeway — see the rotation runbook).

## Gateway-side verification (`internal/routingauth`)

```go
v, err := routingauth.NewVerifier(routingauth.Config{
    Issuer:    "https://a7sota2qic.execute-api.eu-west-1.amazonaws.com", // exact iss
    JWKSURL:   "https://a7sota2qic.execute-api.eu-west-1.amazonaws.com/gateway/jwks",
    Allowlist: allowlist, // same rollout list as the Google verifier
})
principal, err := v.VerifyToken(ctx, token) // (identity.Principal, error)
```

- `*Verifier` has exactly the method set of `identity.TokenVerifier`
  (`VerifyToken(ctx, token) (identity.Principal, error)`), so it plugs into
  the gateway's `Config.Verifier` slot the same way the Google verifier
  does. The package imports `internal/identity` **only** for `Principal`
  and never imports `internal/tunnel`.
- Checks, cheap-local-first: token size → parse → strict `RS256` + `kid` →
  exact `iss`/`aud` → required `exp/iat/nbf` with leeway → lifetime bound →
  `sub` charset → verified email + allowlist → `scope` → key lookup → RSA
  verify. Populates `Principal{AccountID: "google:<sub>", Email, ExpiresAt}`.
- **Separation is enforced on both sides:** a Google token fails here on
  `iss` (and would fail `scope`/`aud`); a broker token fails the sync API's
  Google authorizer on `iss`/`aud` before reaching any sync handler.
- Key policy (all fail closed): fixed HTTPS JWKS URL from configuration —
  no discovery, no key material from token headers (`jku`/`x5u` ignored),
  redirects refused so the pinned URL cannot silently hop hosts; JWKS body
  ≤1 MiB; ≤16 keys; RSA-only with ≥2048-bit modulus, `use=sig`, `alg=RS256`;
  a set with no usable keys is an error. Refreshes are single-flight and
  detached from the initiating request (identity A12 semantics): at most
  one fetch in flight, waiters honor their own context cancellation, the
  mutex is never held across network I/O. The cooldown rate-limits EVERY
  refresh trigger — unknown kid, expired cache and cold cache alike — so
  outage bursts cost at most one fetch per cooldown window. Cached keys are
  served only within `CacheTTL` (default 5m); past it the cache is rejected
  even while a refresh is cooling down, so a key the JWKS stops publishing
  stops verifying here within one TTL (verifier-side; the broker's own warm
  JWKS producers add their own cache window on top — see the broker
  rotation runbook).
- `MaxLifetime` is both the default and the hard maximum: 5 minutes
  (`MaxTokenLifetime`). A configuration asking for more fails
  `NewVerifier`; tokens with `exp-iat` over the bound are rejected, so a
  misbehaving future broker cannot mint long-lived routing credentials this
  verifier would honor.
- Allowlist semantics match the existing rollout: empty list denies
  everyone; comparison is case-insensitive and constant-time.

Budgets: token ≤8 KiB, header ≤1 KiB, JWKS ≤1 MiB / ≤16 keys, JWKS fetch
timeout 10s, refresh cooldown 30s, cache TTL 5m, leeway 30s, lifetime ≤5m
(hard max — default and cap; a configuration asking for more is rejected).

For local Docker fixtures (no public domain, plain HTTP) `Config` carries
`AllowInsecureDev` — default false; without it, non-HTTPS issuer/JWKS URLs
are rejected at construction, and setting it never disables HTTPS
verification. Production wiring leaves it false; there is no wildcard,
discovery, or token-header key source in either mode.

## Exact user flow

Broker-only connection flow (native connection support remains a separate
implementation gate):

1. User signs in with Google in pocketshell.io / the desktop app and gets a
   Google ID token as today. **For this flow, the token goes only to the sync service** —
   to `POST /gateway/token` (and, for the settings feature, the sync CRUD
   endpoints).
2. The client calls `POST /gateway/token` with
   `Authorization: Bearer <Google ID token>` and an empty body. The sync
   service's Google authorizer verifies it; the broker mints the gateway
   token above.

Gateway use (CLI / hostagent / client — implementation owned by the tunnel,
hostagent and core-web workers, consuming this contract):

3. Host enrollment reads the **broker token** from CLI stdin and sends it
   in the identity HTTP Authorization header. The client WebSocket sends
   its broker token in the first auth frame. Neither sends a Google token
   on these new routes, nor puts credentials in query parameters, argv or
   URLs. The enrolled host's later control connection uses its device key
   to sign a challenge; it does not send a broker bearer.
4. The gateway verifies it with `routingauth.Verifier`; the resulting
   `Principal.AccountID` (`google:<sub>`) is the ownership identity for
   device registration, listing and revocation — same shape the identity
   package's Google verifier produces, so downstream ownership logic is
   unchanged.

The reviewed web client's ordinary direct SSH and port-forwarding paths
still send Google tokens to the co-resident legacy proxy. These concurrent,
background or other-device paths are outside the broker-only flow above;
sign-in or use of a new connection alone does not isolate the account.

The token lives at most 5 minutes; the client re-acquires from the broker
with its still-live Google session as often as needed. **The session model
is admission-time verification plus a bounded session duration — nothing
more:** the verifier checks the token (and the caller's context) at
admission, and the tunnel bounds how long an admitted session may run
(`MaxSessionDuration`), but there is no native mechanism that
re-authenticates an ESTABLISHED session at `ExpiresAt`. Do not claim
mid-session re-authentication support; the guarantee is "expired or
canceled credentials are never admitted", not "live sessions die exactly
at expiry".

## Rotation runbook (manual — no automatic rotation exists; reference-flip, warm-signer aware)

The sync Lambda caches its signing key for up to 5 minutes **per warm
instance**, and gateway verifiers cache the JWKS for up to their own TTL
on top. The rotation (full operator detail in the broker repo's
`sandbox/pocketshell-sync/docs/GATEWAY-BROKER.md`) therefore never mutates
a key VALUE while it is in use; it moves the two parameter REFERENCES
inside the sealed `pocketshell-sync/gateway-signing-key*` family (each
reference may be the exact base or a suffixed member; the two must
differ), one deploy each:

1. **Prepublish.** Store the new key in a fresh suffixed parameter and
   deploy with the current reference unchanged and the previous reference
   pointing at the NEW key. Every instance (warm or cold) publishes
   old + new and signs OLD. Wait ≥ producer TTL + verifier TTL + skew —
   conservatively ≈ 11 minutes (the verifier bound sits on top of the
   producer bound, so a bare "5 minutes" is not enough) — then positively
   check the public JWKS for both kids.
2. **Flip (one configuration transition).** Swap the two references:
   current = the new key's parameter, previous = the old key's parameter.
   SSM values are never rewritten, and the Lambda role's two exact ARNs
   are the same before and after. New containers sign NEW and publish
   new+old; containers still on the previous environment sign OLD and
   publish old+new. No intermediate publishes new+new or drops the old
   kid. (This replaces an earlier in-place ordering — overwrite the
   current parameter's value, then copy the old key into its retention
   slot — which briefly left cold instances publishing the new key
   without the retained old one.)
3. **Drain, then retire — the bound is authoritative; observation is
   supplemental.** The 5-minute producer cache is NOT the mechanism that
   stops an old signing environment: a container Lambda still invokes
   reloads its unchanged environment past the cache TTL and keeps signing
   OLD, and AWS publishes no deadline for recycling old execution
   environments ("do not assume that the execution environment will
   persist indefinitely" — Lambda execution environment lifecycle docs).
   A corollary: a kid-observation window can NEVER prove the drain,
   because it only sees producers Lambda actually invokes — a dormant one
   betrays nothing. The old key therefore stays published until the drain
   is proven by an authoritative BOUND (full evidence list in the broker
   repo's `docs/GATEWAY-BROKER.md`, step 3, with the gate as code in its
   `scripts/drain-bound.mjs`):
   the flip's function update completed — `LastUpdateStatus` read back as
   the exact string `Successful` and `State` exactly `Active` (missing /
   `InProgress` / `Failed` refuses; boolean conclusions cannot substitute),
   the recorded pre-flip `RevisionId` present and different from the
   read-back one (bare Successful is not attributable — creation or any
   unrelated update can set it), and the effective configuration matching
   the expected flip values;
   the routing inventory ATTESTS both grant mechanisms: the only intended
   invocation path is the unqualified `$LATEST` integration (no aliases —
   a pinned published version would keep its immutable pre-flip
   configuration invocable forever), but get-integration + list-aliases +
   the function resource policy CANNOT prove "no other invoke grants" —
   same-account principals invoke under IDENTITY-based policies, qualified
   versions included, with no resource-policy entry — so the account's
   identity-based `lambda:InvokeFunction` grants, qualified invokers/other
   triggers, and other readers of the OLD parameter must be attested too
   (the OLD-reader attestation is provable only once the human/core
   explicit-deny is attached and verified — PENDING, so until then the
   evidence set cannot be completed and retirement is refused); unknowns
   refuse, and an empty alias list alone proves nothing;
   and the in-flight duration is the PRE-flip `Timeout` — recorded from
   the live configuration BEFORE the flip (range 1–900 s), because an
   invocation still running at completion started under the PREVIOUS
   configuration: bounding a 900 s old config by the flipped-in 10 s would
   be invalid, and a token issued after the observed completion but within
   the pre-flip duration is legitimate — plus VERIFIED clock-error bounds
   for BOTH clocks the retirement arithmetic touches (auditable time
   evidence; a missing or malformed bound on EITHER refuses): the
   observation clock at the observed completion (`clockErrorBound`,
   added to T_bound — a behind observer clock understates it) and the
   decision clock at the retirement evaluation (`decisionClockErrorBound`,
   subtracted from the decision reading — an ahead decision clock
   overstates elapsed time). Comparing the RAW decision reading against
   the threshold counts only one side: an observer 1000 s behind plus a
   decider 1000 s ahead — each within its own attested bound — could
   retire up to 2000 s early. The gate therefore allows retirement only
   when decisionTime − decisionClockErrorBound ≥ T_bound + retention, and
   nothing assumes NTP, an unchanged clock, or a monotonic reading
   spanning observation and decision — each timestamp carries its own
   verified bound. That yields
   T_bound = observed completion + preFlipTimeout + observationClockErrorBound + 60 s
   — after which no OLD-signed token can be minted, regardless of traffic
   (dormant producers are covered because nothing observes them). Kid
   sampling on `POST /gateway/token` is supplemental and refute-only: an
   old kid at or after T_bound contradicts the evidence — abort and
   investigate; old kids before the bound are consistent and move nothing.
   Retire — remove the old parameter — only once
   decisionTime − decisionClockErrorBound reaches T_bound + 5 min (max
   token lifetime, the token-admission bound) + 5 min (verifier cache TTL,
   publication conservatism) + 30s (verifier leeway) — for a 900 → 10 flip
   with 1 s verified bounds on both clocks ≈ 26.5 minutes after the
   observed completion plus one decision-clock bound (the pre-flip Timeout
   dominates); these retention values are frozen floors in
   `scripts/drain-bound.mjs` (malformed or below-floor operator overrides
   refuse — the wait can only be lengthened). Any missing or mismatched
   piece of the evidence set — including any malformed numeric form
   (NaN/±Infinity/fraction/negative/zero-where-meaningless) and either
   clock-error bound being unknown — REFUSES
   retirement (keeping the old parameter is safe: its value is immutable
   and it is one of the two exact granted ARNs). Full procedure (including
   the exact quotes and the live checks): the broker repo's
   `docs/GATEWAY-BROKER.md`, step 3.

Emergency removal (key compromise) — separate from the rotation drain
above: pull the key from all parameters and redeploy immediately, without
any drain proof. Deletion is the containment kill switch (anything that
must reload fails closed; a producer still holding the warm private key
signs for at most one further cache TTL). Publication alone does NOT stop
acceptance, and the two caches are sequential — count them once. Measured
from the authoritative change (the moment no configuration references the
key anymore), the worst-case acceptance window is one producer JWKS-cache
TTL (≤5 min) + one verifier cache TTL (5 min) + verifier leeway ≈ 10–11
minutes. Once the LAST stale publication has stopped, only the verifier
window remains (TTL + leeway ≈ 5–5.5 minutes) — that remainder is not
added again. Restarting every sync instance flushes producer caches
quickly but cannot flush gateway verifier caches: verifiers hold the key
until their own bounded TTL expires even after every producer has
stopped. This arithmetic bounds emergency containment — it is not, by
itself, evidence that a rotation drained (that is step 3's authoritative
bound: verified completion + routing inventory + the recorded PRE-flip
in-flight Timeout;
sampling stays supplemental). The kid is the RFC 7638 thumbprint, so it is
stable across PEM/JWK encodings and changes only with real key material.

## Scope and limits of the credential

- The token authorizes gateway identity management (enrollment, listing,
  revocation) and SSH routing for the account — it is NOT routing-only;
  the `scope` claim exists so any future narrower authority cannot
  silently widen. Active connection lifetime is enforced independently of
  token issuance: a token that has expired (or a caller whose context died)
  is never admitted, and admitted sessions are bounded by the tunnel's
  `MaxSessionDuration` — admission-time checks, not mid-session
  re-authentication.
- This isolation applies to the new API path only — whole-gateway
  isolation from Google tokens is NOT achieved while legacy compatibility
  runs. The LEGACY public SSH proxy still receives Google bearer tokens
  from old clients by wire contract; those clients' tokens remain exposed
  to that runtime until migration completes (documented compromise-gateway
  caveat, review §7). The promise is strictly: the NEW gateway API never
  sees a Google token.

## Deployment and integration status (do not overclaim)

- **The signing key exists.** The coordinator generated an RSA-3072 key
  once and stored it as version 1 of Standard-tier SecureString
  `/pocketshell-sync/gateway-signing-key` in eu-west-1; the temporary local
  PEM was destroyed after upload. This document must not describe the key
  as pending creation.
- **The broker routes are NOT live.** Deploying the sync stack (and
  therefore `GET /gateway/jwks` / `POST /gateway/token`) is owned by the
  coordinator and has not happened; the template defaults already carry
  the exact API URL. Nothing in this repo may claim the routes answer in
  production.
- **The gateway instance is already locked out of the key — live.** An
  explicit-deny policy covers GetParameter, GetParameters,
  GetParameterHistory and GetParametersByPath over the signing-key
  parameter family (current, previous, ancestor paths), IAM simulation
  returned explicitDeny, and invoking or updating the sync Lambda is
  implicitly denied for the instance role. These gateway-role facts are
  verified live. This must be preserved by final
  bootstrap: the gateway only ever needs the public JWKS over HTTPS, and
  nothing should ever grant the gateway runtime SSM read or direct Lambda
  invoke on the broker (a forged direct invocation could mint tokens
  outside the authorizer boundary).
- **Human/core deny attachment: PENDING.** The human/core explicit-deny
  policy (`policies/gateway-broker-key-deny.json` in the broker repo) has
  NOT been attached and no human/core denial has been verified live — do
  not describe human key access as denied until the coordinator attaches
  the policy and confirms.
- **Gateway-side wiring is not integrated yet**: `Config.Verifier` in
  relay.go/tunnel and the client/hostagent token plumbing belong to the
  root/tunnel/core workers (`*routingauth.Verifier` is a drop-in for the
  identity.TokenVerifier method set).
- Post-deploy contract checks (coordinator, against the live API — local
  tests stub the API Gateway authorizer and cannot substitute for these):
  `GET /gateway/jwks` returns public keys with no auth; a broker token sent
  to a sync route (e.g. `GET /me`) gets 401 from the Google authorizer; a
  Google token mints a gateway token via `POST /gateway/token`; the gateway
  verifier accepts that token and rejects a Google token.
- These components are individually tested (Go `-race`, Node test suites,
  template contract tests). No claim is made that the whole feature is
  secure or live until the integration and deployment checks above pass.
