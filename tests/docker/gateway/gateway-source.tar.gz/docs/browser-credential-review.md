# Browser credential review and scoped-token correction

2026-10-07: Astra reviewed the existing web source at 5f07aea without executing tests or making live requests. These findings distinguish confirmed source paths from unverified deployment behavior.

The Google bearer alone does not decrypt the SSH-key vault. The entire keys slot is encrypted using a separate user sync passphrase with PBKDF2-SHA256 (600,000 iterations) and AES-GCM. The private-key PEM and its key passphrase reside inside that same envelope. Remembered vault unlock material lives in the browser, not in the Google token. Strong independent passphrases and trusted frontend code remain necessary.

However, the documented sync authorizer accepts the same web Google audience and permits account GET/PUT/DELETE operations. A gateway holding that token can therefore obtain encrypted vault ciphertext for offline guessing, replace/delete data or replay previous ciphertext, conditional on the deployed web-audience setting. This is not evidence that a token directly exposes plaintext private keys.

An additional background path sends raw credentials: unlock, remembered unlock and navigation trigger warning sweeps; the warnings store chooses the legacy Lambda bridge whenever its URL is configured, including hosts using other transports. The warning helper copies private-key PEM and key passphrase into BridgeSession authentication JSON. This does not prove the new gateway receives those keys, but it contradicts a client-only credential boundary for the affected background operation.

## Required implementation

- New gateway hosts must never send their Google sync bearer to the gateway. Exchange it at the independently trusted existing sync service for a short-lived gateway-only routing credential. A gateway-local exchange cannot fix the exposure.
- The trusted broker is the existing sync API, `https://a7sota2qic.execute-api.eu-west-1.amazonaws.com`. Google-authorized `POST /gateway/token` issues an RS256 token with that exact issuer, fixed `pocketshell-gateway` audience, verified Google subject/email and expiry no longer than five minutes or the upstream credential. Public `GET /gateway/jwks` supplies its verification keys.
- Keep the broker signing key in a separate SSM SecureString parameter under the sync service's authority. Gateway instance credentials must be explicitly denied access to that parameter; the runtime must also be unprivileged and unable to access metadata. Gateway deployment cannot alter the broker or frontend.
- Identity management and client routing on the new API accept only broker credentials. Existing Google verification remains a legacy-proxy compatibility path during migration, with its broader credential trust documented. No silent fallback to a Google bearer on the new gateway path.
- Browser exchange uses frontend-owned sync configuration, never broker discovery supplied by the gateway. Enrollment tokens supplied to the host agent are scoped broker tokens. No SSH key or vault passphrase appears in either broker requests or gateway frames.
- Exclude end-to-end/direct/gateway hosts from raw-credential warning bridge operations, including refresh/ack and automatic unlock paths; alternatively use the pinned browser SSH engine. Regression tests configure both URLs and assert no credential bridge frame is emitted.
- Verify after deployment that a gateway token cannot authorize sync GET/PUT/DELETE. Demonstrate that new client/enrollment requests use the scoped token and never the original Google bearer.

ZAI owns implementation in separate broker, client, agent and integration scopes. This correction is designed and assigned; it is not deployed or accepted yet. A compromised gateway can still deny service, inspect routing metadata and ignore its own account ACLs. Real SSH host-key pinning and endpoint user keys remain the shell authentication boundary.

Source evidence: web src/stores/hosts.ts; src/shared/syncCrypto.ts; src/api/sync.ts; src/shared/passphraseVault.ts; src/stores/warnings.ts; src/aplexer/warnings.ts; src/terminal/bridge.ts; src/views/HostsView.vue. Sync authority: aws-infra/sandbox/pocketshell-sync/template.yaml and lambda/index.mjs.
