# Independent Astra design review — 2026-10-07

Model: gpt-6-astra. Scope: read-only architecture review of design.md and implementation-checklist.md. Outcome: authentication layers are coherent, but requirements below need implementation evidence. No code execution, Docker tests or implementation approval occurred. Earlier executable security-review requests were rejected by runtime screening; this narrower review completed.

## Required clarifications / acceptance criteria

1. Host-key trust: a real SSH host key must be independently verified from local setup output/QR and pinned on the client before user authentication. Fetching it only from gateway-owned registry cannot authenticate first contact under this threat model. Rotation requires explicit independent verification.
2. Frontend trust: browser code/distribution is trusted separately. Compromised frontend delivery can read terminal data or misuse unlocked keys. The gateway deployment role and runtime instance role must not be able to modify the frontend distribution/bucket or its deployment pipeline.
3. Enrollment: device proof signs a canonical transcript binding verified issuer+subject account, device ID, public registration key, actual SSH host key, service/protocol and fresh challenge. Consume challenge once and serialize uniqueness checks/persistence. Device-key possession does not prove ownership of asserted SSH host key; local verification remains required.
4. Lifecycle: all ownership uses verified issuer+subject. Specify Google-token expiry and removal from configured account allowlist for active sessions. Browser Origin is checked; native CLI without Origin still authenticates.
5. Revocation: persist before acknowledgment, serialize against enroll/register/stream admission, reject revoked keys under another ID unless deliberate trusted re-enrollment is supported. Disconnect callbacks alone do not settle races. V1 is single-instance with durable registry; distributed consistency is not claimed.
6. Compromised-gateway guarantee: a malicious gateway can disregard ACL/revocation, route to configured SSH endpoints, observe metadata and deny service. SSH endpoint authentication/host-key verification remain enforced independently. Account revocation at a compromised gateway is not sufficient: remove the SSH authorized key on the host and terminate its SSH sessions where immediate endpoint-side revocation is required.
7. Budgets: state exact aggregate/per-owner limits for unauthenticated sockets, handshake/challenge lifetimes, enrollment, devices, hosts, streams, frames, buffered bytes and local SSH dials. Slow data must not indefinitely block control/revocation.
8. Forwarding: agent accepts only literal IPv4/IPv6 loopback SSH destination, no gateway-provided destinations. Existing public TCP proxy revalidates resolved addresses and cannot dial private/metadata targets. Local SSH daemon policy independently governs agent/TCP/X11 forwarding; tunnel restriction alone cannot disable SSH forwarding.
9. Release evidence: final acceptance requires integrated commit and executable results, not this design review.

## Decisions for the first release

- Independent initial trust uses host CLI fingerprint output/QR verification and explicit client pinning; registry host-key metadata is advisory, never auto-trusted. A browser UI for this may remain follow-up; without independent pairing, compromised-gateway protection is not accepted.
- Keep existing allowlist for rollout and per-account authorization. Document active-session expiry/removal behavior explicitly; no implicit forever-authenticated account stream.
- Single existing gateway instance and durable local registry. No distributed revocation claim.
- Registration key revocation and SSH login-key revocation are separate operations. Honest-gateway close tests and endpoint SSH authorized-key removal tests have distinct guarantees.
- Production rollout of new reverse endpoints waits on defensive integration validation. Existing SSH proxy/hostname migration can ship independently with new reverse endpoints disabled.
