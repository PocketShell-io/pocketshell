# PocketShell tunnel (v1): host agent, multiplexer, gateway service

Owner: tunnel worker. Packages: `internal/tunnel`, `internal/hostagent`,
`cmd/pocketshell-link`, `tests/docker`. The identity dependency
(`internal/identity`) is owned by the identity worker; this package
consumes it read-only through the API in `docs/design.md` and
`docs/identity.md`.

## What the gateway is (and is not)

The gateway authenticates **ownership** and **routes opaque bytes**. It
never parses SSH, never holds SSH keys, and never executes anything. Shell
access is decided end-to-end by the home `sshd`; the pinned host key
identifies the server, not which authentication methods the daemon allows.
Because the routed bytes are opaque, a compromised gateway can still open
SSH conversations with the configured loopback listener under arbitrary
usernames — the transport does not bind an SSH username to the enrolled
device. Gateway/routing credentials alone authenticate no SSH session
**only while the endpoint's effective key-only policy holds for every
username the listener admits** (password, keyboard-interactive and
`none`/empty-password login refused). That is an operator prerequisite,
not something enrollment establishes: the host-key probe deliberately
stops before user authentication. The operator-reviewed OpenSSH baseline
and its `sshd -t` / `sshd -T -C` verification are documented in the host
CLI onboarding (`docs/gateway.md` §2.1 in the pocketshell-cli
repository); the trust assumptions are in `docs/architecture.md`
("Honest limits") and prior lab evidence in `docs/opus-security-review.md`.
A compromised gateway can always initiate connections and deny service.
Removing an endpoint SSH login key prevents new logins only and is a
distinct operation from gateway routing/device revocation.

```
browser/CLI client ── WS binary (SSH bytes) ── gateway ── mux frame ── host agent ── loopback sshd
        │                              ▲
        └── JSON auth frame: broker JWT ┘
```

## Endpoints (served by `tunnel.Service`)

| Route | Role | Handshake |
|---|---|---|
| `GET /api/v1/agent/connect` | host agent | server challenge (JSON) → signed auth (JSON) → `ok`; then binary mux frames |
| `GET /api/v1/hosts/{deviceID}/ssh` | client | first TEXT frame `ClientAuth{token, device_id}` → `ready` (or `error`); then binary SSH bytes |

The client route is parsed by the service itself
(`parseClientSSHPath`): there is no root-side path rewriting and no other
accepted spelling. `deviceID` must be registry-wellformed
(`identity.ValidDeviceID`).

### Host authentication

The gateway speaks first: a `HostChallenge` carrying a single-use,
TTL-bounded, capacity-bounded challenge (`internal/tunnel/challenge.go`).
The agent signs the **canonical `identity.Challenge` transcript** — the
same encoding enrollment uses, rebuilt via `HostChallenge.ToIdentityChallenge`
and signed with `identity.Sign`. There is no local transcript format and no
fallback. The challenge is bound to role (`host`), protocol
(`pocketshell-tunnel/1`), server name, device ID, a per-connection nonce and
an expiry; replaying a proof on another connection or device fails
verification and burns the challenge.

**Fatal rejection surfacing (FH-1).** The gateway always sends a JSON
`ErrMsg` frame (`{type:"error", code, message}`) before closing with an
application close code, at BOTH handshake stages: before the challenge
(pre-challenge capacity/refusals) and after proof verification (revoked or
unknown device, bad signature). The agent decodes the error frame as a
verdict — never as a type mismatch — and maps terminal codes to a fatal
`errFatalAuth` (exit with "gateway rejected this device (close N)"):
`revoked`→4403, `signature`/`challenge`/`unauthorized`→4401,
`not_found`→4404, identical to the close-code classification. Transient
codes (`quota`, `timeout`, `protocol`, `internal`) keep the bounded
backoff reconnect.

The `challenge` code is STAGE-DEPENDENT (FH-1 correction), matching the
real service's pairings: before any challenge exists it means **challenge
capacity exhaustion** — a temporary condition, paired on the wire with the
transient close code 4408 (`"challenge capacity reached"`) — so the agent
rides it out with the bounded reconnect and connects once a slot frees.
After the signed proof it is the terminal redeem failure ("challenge
invalid or expired", 4401) and stays fatal. Retrying every `challenge`
frame would be as wrong as failing every one: the agent knows which reply
it is waiting for and never trusts the peer to be consistent. Rejection
text is bounded (256 bytes) and constants by design; the agent never logs
raw credentials or unbounded peer text. Regressions:
`TestAgentFatalExitOnInitialErrorFrame`,
`TestAgentFatalExitOnPostProofErrorFrame`,
`TestAgentPostProofChallengeVerdictStillFatal` (post-proof `challenge`
stays fatal), `TestAgentFatalExitOnCloseCodeOnly`,
`TestAgentTransientQuotaRecovers`,
`TestAgentPreChallengeCapacityFrameRecovers`,
`TestRealServiceChallengeCapacityRecovers` (real service: capacity full →
rejects → TTL frees the slot → agent connects, never exits),
`TestServiceRevokeEndsAgentRunFatally` (real service, revoke → `Run`
returns) and `TestCLIRunExitsFatallyOnRevocation` (the real binary exits
non-zero with the message).

### Stream-window negotiation (FH-2)

Per-stream credit windows are negotiated during the agent handshake so
asymmetric-but-valid local `Limits.StreamWindow` configurations can never
look like a protocol violation:

- The agent announces its configured (resolved) window in
  `HostAuth.StreamWindow`.
- The gateway validates it **before any allocation**: negative or above
  `MaxStreamWindow` (256 KiB) fails the handshake closed with a `protocol`
  error frame; zero/absent is the legacy "no negotiation" marker.
- The symmetric window is `min(gateway, agent-announced)` — an
  announcement can only lower it. The gateway builds its mux on it and
  announces it in `OKMsg.StreamWindow`; the agent applies exactly that
  value to both directions of its mux. Both peers therefore run identical
  send/receive credit on every stream.
- The agent validates the returned choice **before allocating its mux**
  (FH-2 correction): a positive `OKMsg.StreamWindow` above the window the
  agent itself offered is a broken or lying peer — even when the choice is
  within `MaxStreamWindow` (e.g. offer 8 KiB, reply 256 KiB) — and fails
  the handshake closed with a `protocol` error, followed by the bounded
  reconnect. Smaller-or-equal choices keep working symmetrically; the
  bounded-buffer commitments never grow above what the agent itself
  offered.
- **Backward default (documented):** an OK frame without
  `stream_window` (pre-negotiation gateway) keeps the agent's own
  configured window. Peers that do not negotiate must run EQUAL windows —
  the shipped defaults do (64 KiB both sides); operator overrides on one
  side only are unsupported for non-negotiating peers.
- A hostile gateway can never negotiate more than `MaxStreamWindow`
  (256 KiB) per stream per direction, and malformed or above-offer values
  fail the session (bounded reconnect, not a fatal auth verdict).
- `MaxFramePayload` is deliberately NOT negotiated: it is build-coupled
  fixed policy (defaults 32 KiB, hard cap 64 KiB — `hardLimits` in
  `internal/tunnel/limits.go`); receivers add slack to their own limit.

Regressions: `TestNegotiatedWindowMismatchedConfigLargeTransfer`
(gateway 16 KiB vs agent 64 KiB default, 8-window transfer stays alive and
byte-correct — before the fix this tore the whole host leg down with
"exceeded its receive window"),
`TestNegotiatedWindowAgentOfferBelowServiceLargeTransfer` (real service,
reverse mismatch: agent offers 8 KiB under the gateway's 64 KiB),
`TestWindowNegotiationServiceSide`
(min/absent/zero/never-raise/malformed rejection before allocation),
`TestAgentRejectsMalformedNegotiatedWindow`,
`TestAgentRejectsAboveOfferNegotiatedWindow` (in-cap above-offer reply is
rejected before mux allocation, then retried) and
`TestAgentLegacyGatewayNoNegotiation`.

### Client authentication and ownership

The first client frame carries the **sync-broker routing credential**: a
short-lived RS256 JWT with `iss` = the PocketShell sync API,
`aud` = `pocketshell-gateway`, `scope` = `pocketshell.gateway` and a
≤ 5-minute lifetime (see `docs/routing-credentials.md`). Production wiring
verifies it with the shared `routingauth` verifier and returns a
`tunnel.Principal{AccountID, Email, ExpiresAt}`. Ownership derives only
from the verified `issuer+subject` account: unknown, revoked and
other-owner devices get **one identical denial**
(`uniformClientDenial`; no device-existence oracle — regression
`TestUniformClientDenial`).

Admission requires a positive, unexpired `Principal.ExpiresAt`, re-checked
after the store lookup and after the host ACK
(`TestHandshakeDeadlines`, service.go `admissionExpired`).

**Session lifetime honesty (finding F-14):** the admission token is checked
at admission only. There is NO mid-session re-authentication, and no claim
of expiry-driven termination. Every session is absolutely bounded by
`Limits.MaxSessionDuration` (default 12h, hard cap 24h), independently of
the 5-minute credential: clients reconnect with a fresh token. Regression:
`TestSessionMaxDuration`. Device revocation closes the active host
connection and every stream on it (`TestRevokeDisconnectsActiveSessions`).

The `ready` frame's `ssh_host_key` is **advisory registry metadata**
(finding O1): clients must verify the SSH host key against a pin
provisioned independently (local enrollment output), and abort on
mismatch before userauth (`TestO1ClientPinIsIndependent`).

## Multiplexer (`internal/tunnel/mux.go`)

One persistent host-agent WebSocket carries per-client streams. Frame:
`version(1) type(1) streamID(8) length(4)` + payload; types
OPEN/DATA/EOF/RESET/WINDOW/ACK. Properties, each with a regression:

- **Flow control (A5, A11).** Credit-based per direction. The receiver
  enforces the window on arrival — a peer that overruns its credit is a
  protocol error that tears the connection down before buffers grow
  (`TestA5ExcessDataTearsDown`). WINDOW grants cannot inflate credit past
  the negotiated initial window (`TestA5WindowGrantOverflow`). Senders
  reserve credit atomically under the stream lock before writing
  (`TestA11ParallelWritersHonorCredit`); consumed bytes are returned as
  credit at the flush threshold **or on drain-to-empty**, so windows
  smaller than the threshold still progress (`TestA11SmallWindowTransfer`).
  The initial window is the handshake-negotiated symmetric value (FH-2,
  see the host-authentication section); both muxes of a connection always
  run the same number (`TestNegotiatedWindowMismatchedConfigLargeTransfer`).
- **Epoch-scoped random stream IDs.** IDs are random 64-bit values per
  connection, so stale frames from a previous connection cannot address a
  new one. Recently closed IDs are tombstoned (bounded FIFO, 1024); late
  DATA/EOF/WINDOW/ACK for a closed or tombstoned stream is dropped — never
  a teardown of unrelated streams (`TestA10LateFramesDoNotKillUnrelatedStreams`).
  Frames for never-seen IDs remain hard protocol errors.
- **Role enforcement (A6, A10).** Exactly one side opens (gateway) and one
  accepts (host). Role-invalid OPENs are RESET through a bounded control
  queue drained by ONE worker goroutine; the reader never blocks on
  admission or control writes (`TestA6RoleInvalidOpenGetsReset`). OPENs
  beyond the accept queue depth are refused without blocking
  (`TestA6AcceptQueueFullResets`, which also proves read-loop liveness with
  a post-flood data marker). An un-ACKed OPEN times out, RESETs, and
  tombstones (`TestA10OpenTimeoutSendsResetAndTombstones`). Sustained
  refusal storms with a slow reader keep unrelated stream progress within
  budget, and control-queue overflow fails closed instead of spawning or
  buffering without bound (`TestResetFloodSlowReaderBoundedWork`).
- **Completion (A2, A8).** `Done` closes exactly once on teardown; the
  accept channel is never closed (senders select against `doneCh`), so
  disconnect/revoke/concurrent OPEN terminate waiters without panics
  (`TestA2DoneClosedOnceAndNoSendPanic`). OPEN's ack channel is captured
  under the creating lock (`TestA8ImmediateAckStorm`).
- **Serialized transport (A3).** All writes on one WebSocket — handshake
  JSON, pings, mux frames — share one `WSWriter` mutex
  (`TestA3ConcurrentKeepaliveAndData`, `TestA3KeepaliveDuringSustainedTraffic`).

## Host agent (`internal/hostagent`, CLI `cmd/pocketshell-link`)

`pocketshell-link enroll --token-stdin` generates (or reuses) an Ed25519
device identity (PKCS#8 PEM, mode 0600, loose permissions refused), probes
the real local sshd over loopback (`ProbeSSHHostKey`: handshake only, no
auth, no commands), pins its authorized_keys line, and enrolls via the
identity API. `pocketshell-link run` maintains the outbound WSS control
connection (no inbound ports anywhere) and bridges every gateway-opened
stream to the configured loopback SSH endpoint (`ValidateLoopback`:
literal loopback IPs or `localhost` resolving exclusively to loopback;
`--insecure-dev` never lifts this).

- **Enrollment contract (F-08).** The challenge response is decoded through
  the SHARED `identity.ChallengeFromWire` helper and cross-checked against
  the server-provided transcript bytes before anything is signed; the
  enrollment body is JSON-encoded exactly once. Regressions run the actual
  `Enroll` against an actual `identity.Service` HTTP handler:
  `TestEnrollAgainstRealIdentityService`, `TestEnrollCanonicalTranscriptVector`,
  `TestEnrollRejectsTamperedChallenge` (every signed binding tampered),
  `TestEnrollSecondJSONEncodingRejected`.
- **Host-key selection policy (browser contract).** The browser SSH client
  negotiates exactly `ssh-ed25519 > rsa-sha2-512 > rsa-sha2-256 > ssh-rsa`
  (no ECDSA). SSH host-key negotiation is client-preference-dominated, so
  `ProbeSSHHostKey` offers exactly that list (`BrowserHostKeyAlgorithms`)
  instead of the x/crypto default (which prefers ECDSA and would pin a
  fingerprint no browser client ever requests on an ordinary multi-key
  sshd). The freshly paired fingerprint is therefore the key the browser
  will request. Consequences, all deliberate:
  - Ed25519 wins whenever offered, regardless of the server's HostKey
    order (real-OpenSSH proof: `TestDockerOpenSSHMultiKeyPinsBrowserRequestedKey`,
    `TestDockerOpenSSHReverseOrderStillPinsEd25519` — real OpenSSH
    containers offering Ed25519+ECDSA+RSA in both orders, with a
    browser-algorithm SSH2 client authenticating against the SAME pinned
    key); RSA-only servers still pair (`TestDockerOpenSSHRSAOnlyPairsBrowserCompatible`);
    legacy ssh-rsa-only sshds stay supported (intentional compat tail).
  - A server offering ONLY unsupported types (e.g. ECDSA) fails the probe
    honestly — "offers none of the enrollment host key algorithms …
    server offered …" — with no fallback and no pin of an unverifiable
    key (`TestProbeSSHHostKeyECDSAOnlyFailsHonestly`,
    `TestDockerOpenSSHECDSAOnlyFailsHonestly`). The probe remains keyless
    (no userauth, no commands, `TestDockerOpenSSHProbeNeverAuthenticates`)
    and loopback-only (`ValidateLoopback`).
  - `--expect-host-key` is a STRICT post-probe check of the independently
    supplied pin against the SELECTED key, evaluated BEFORE any HTTP
    request: fingerprints compare as SHA256 digest BYTES (only whitespace,
    the optional `SHA256:` prefix and base64 padding normalize; the base64
    body is case-significant, so a case-toggled fingerprint refuses), and
    authorized_keys lines compare as the parsed public key (comments
    ignored, key bytes exact). A pin naming a non-selected offered key is
    an honest refusal — the pin is never swapped for another offered key,
    and there is no alternate-key retry. Refusals leave zero HTTP requests
    and no written config (`TestRunEnrollExpectPinMismatchFailsBeforeAnyHTTP`,
    `TestRunEnrollUnsupportedHostAlgorithmFailsBeforeHTTP`,
    `TestSameHostKeyCanonicalComparison`).
- **Credential disclosure guard (F-09).** The CLI sends only the sync-broker
  gateway credential. `ValidateBrokerCredential` refuses — locally, before
  any request — anything that is not a JWT with the exact broker
  issuer/audience/scope and a bounded, unexpired lifetime; Google ID
  tokens are named and refused explicitly. These are UNVERIFIED claims: a
  disclosure gate, not authentication; the gateway's verifier is
  authoritative. Dev labs may override the issuer ONLY with
  `--insecure-dev --dev-broker-issuer`. Regressions:
  `TestValidateBrokerCredential`, `TestHostCLINeverSendsGoogleToken`
  (library) and `TestCLIGoogleTokenNeverTransmitted` (real binary, zero
  HTTP requests on the recorder).
- **Liveness (F-13, A4).** The handshake read deadline is cleared after
  `ok`. The session deadline is a liveness bound extended by every inbound
  frame and by pongs answering the agent's keepalive pings; a peer silent
  for `PongWait` is dropped. Regressions:
  `TestAgentSessionOutlivesHandshakeDeadline` (six round trips across many
  handshake deadlines), `TestStalledGatewayExpires`,
  `TestA4HealthyHostOutlivesHandshakeDeadline` (gateway side).
- **Default clock (F-11).** `NewAgent` defaults `Now` to `time.Now`; the
  production CLI runs with zero injected configuration
  (`TestNewAgentDefaultClockMustNotPanic`).
- **Peer diagnostic rendering (terminal-output defense).** Everything the
  gateway sends that can reach CLI output is peer-controlled: `ErrMsg`
  messages at either handshake stage, raw WebSocket close reasons,
  unrecognized ErrMsg codes, the handshake reply type, and the challenge
  type/server/role/protocol. A misbehaving configured gateway or on-path
  proxy legitimately saw the enrollment request's Authorization bearer and
  can echo that credential back through any of them — wholly, cut to any
  length, or re-encoded — and no practical redaction covers every encoding
  of a token the agent does not store. The agent therefore withholds peer
  bytes STRUCTURALLY at each boundary: the ErrMsg message is dropped when
  the frame is read and never retained; recognized wire codes render only
  as their canonical literals (`canonicalErrCode`); unrecognized codes,
  close reasons, reply/challenge field values, and shared
  role/protocol-validation errors render as fixed local phrases (the only
  numbers shown are locally safe, e.g. the wire version or close code);
  fatal verdicts keep the close-code + canonical-verdict shape that keeps
  triage useful; fatal/transient classification still matches the RAW wire
  codes (never laundered), and validation refusals stay on the bounded
  transient reconnect path. Regressions:
  `TestAgentFatalJSONRejectionWithholdsPeerText`,
  `TestAgentFatalCloseReasonWithholdsPeerText`,
  `TestAgentUnknownPeerCodeStaysTransientWithheld`,
  `TestPeerDiagnosticRenderingContract`,
  `TestValidateChallengeWithholdsPeerFields`,
  `TestAgentValidationRejectionsStayTransientWithheld`,
  `TestCLIRunHostileGatewayRejectionWithholdsPeerText`,
  `TestCLIRunRejectionsWithholdEnrolledBearer`,
  `TestCLIRunPeerFieldReflectionWithheldBearer` (real binary).
- **Build metadata contract.** `pocketshell-link version` keeps the
  human line `pocketshell-link <version> (protocol <tag>)`;
  `pocketshell-link version --json` prints the FROZEN ADDITIVE machine
  contract — exactly one line, no log chatter, exit 0:
  `{"version":…,"protocol":"pocketshell-tunnel-v1","commit":…}`. Release
  builds inject real metadata (`go build -ldflags "-X main.version=v1.0.0
  -X main.commit=<sha>"`); an un-injected build visibly says `devel` with
  the Go VCS revision (or `unknown`) as the commit — never a hardcoded dev
  string posing as a release. The protocol tag is the wrapper's
  compatibility key: bump it (`pocketshell-tunnel-v2`, …) only on
  wire-incompatible changes (handshake, control frames, enroll API);
  additive changes keep the tag and may only append `--json` fields.
  Regressions (real binary): `TestCLIVersionJSONInjectedMetadata`,
  `TestCLIVersionHumanLineInjected`, `TestCLIVersionErrorExits`,
  `TestCLIVersionUninjectedIsVisiblyDevel`.

End-to-end proof with the real binary: `cmd/pocketshell-link/cli_e2e_test.go`
runs `enroll` against a real identity service, `run` against a real tunnel
service and a real in-process sshd, and carries SSH traffic across the 10s
default handshake deadline (`TestCLIEnrollRunSSH`).

## Limits and rollout budget (A14)

`Limits.Resolved()` defaults target one 512 MiB t4g.nano instance that also
serves the legacy browser proxy: 64 hosts, 64 global client sessions,
8 per account, 8 streams per host, 32 KiB frames, 64 KiB per-direction
windows, 256 outstanding challenges; configured values are clamped to hard
ceilings (`LocalDialTimeout` included) with `MaxStreamWindow` (256 KiB) as
the window ceiling for both local config and peer negotiation. These are
design budgets, not a memory measurement: worst case both mux directions of
every admitted session are bounded by `MaxStreamsPerHost × StreamWindow`
buffers plus the legacy proxy's working set, leaving GC headroom on that
instance; the aggregate is asserted by the quota tests
(`TestPendingAdmissionQuotas`, `TestQuotasAndHostOffline`) rather than a
runtime RSS claim.

## Revocation contract (for root wiring)

The identity service persists revocation first (persist-before-notify) and
calls `tunnelSvc.RevokeDevice(deviceID)` via `OnRevoke`. RevokeDevice bumps
the device's revocation epoch — the same generation host registrations
re-check under the service mutex at insert time (A1) — tears down the host
connection and every stream, and future registrations are refused.
Re-revoking an unconnected device is idempotent.

## Root integration adapters

```go
tunnelSvc, _ := tunnel.NewService(tunnel.ServiceOptions{
    Store: tunnel.DeviceStoreFunc(func(id string) (tunnel.Device, error) {
        d, err := identityStore.GetDevice(id) // identity.Device → tunnel.Device
        ...
    }),
    Authenticate: func(ctx context.Context, token string) (tunnel.Principal, error) {
        p, err := routingauthVerifier.Verify(ctx, token) // must set ExpiresAt
        return tunnel.Principal{AccountID: p.AccountID, ExpiresAt: p.ExpiresAt}, nil
    },
    AllowedOrigins: []string{"https://pocketshell.io"},
})
identitySvc.OnRevoke(func(d identity.Device) { tunnelSvc.RevokeDevice(d.ID) })
// mount tunnelSvc at /api/v1/ (agent + client routes are parsed internally)
```

## Development / Docker proof

Plain `ws://`/`http://` server URLs are accepted only with
`--insecure-dev` (explicit, labelled; TLS verification is never skipped and
there is no cert-skip flag anywhere). The Opus lab uses a labelled lab-only
issuer through `--dev-broker-issuer`; production Google or lab fallbacks
are refused by the local guard in normal mode. Run the suites:

```sh
/usr/local/go/bin/go test ./internal/tunnel/ ./internal/hostagent/ ./cmd/pocketshell-link/
/usr/local/go/bin/go test -race ./internal/tunnel/ ./internal/hostagent/
```
