# Review follow-up: identity and scoped credentials

Reviewed snapshots: identity `c87e332` / `670b1a3`, routing verifier
`4f42642`, sync broker `422b3c5` / `19d00f4` / `38c2c6b`.
Independent reviewer: Astra, read-only source review. These findings remain
open until corrected source and named regression evidence are integrated.

1. **Uncertain revocation must contain active sessions.** After rename but
   failed directory fsync, applied revoked state is retained while callbacks
   are suppressed. A retry observes an already revoked record and can return
   success without flushing durability or disconnecting existing streams.
   Required: contain every affected device immediately, acknowledge only
   after proven durability, and test repeated failed and successful retries.
2. **Historical duplicate keys must inherit revocation.** Loading a revoked
   device or tombstone must also invalidate active records with the same key.
   Test v1 revoked/active mixtures and v2 tombstone/active mixtures across
   restart, including the actual gateway read path.
3. **Routing lifetime contract.** Default verifier lifetime is ten minutes
   despite a five-minute broker contract. Enforce the agreed bound and align
   response `expires_at` with browser enrollment and refresh consumers.
4. **Broker claim validation.** Reject absent, zero, nonnumeric or malformed
   upstream expiration; avoid converting invalid expiration to an unlimited
   upstream lifetime. Handle verified-email claim representations explicitly.
5. **Verifier refresh availability.** Routing JWKS refresh holds its mutex
   across network I/O; cold and expired failures bypass refresh cooldown.
   Require bounded single-flight I/O outside the mutex, cancellable waiters,
   cooldown on failure, and fail-closed cache expiry.
6. **Expiry after network wait.** Recheck token expiration and cancellation
   after JWKS retrieval. Test a blocked fetch released after the fake clock
   crosses token expiry.
7. **Rotation evidence.** Retain an actual old-key token in tests. Account
   for warm Lambda instances signing with cached old private keys after a
   parameter change, plus token lifetime and verifier skew. The original
   previous-key assertion accidentally verified a new current-key token.

POST CORS is present in the broker template. Local unit/template tests do
not establish live API authorizer behavior; deployment verification must
separately reject gateway credentials at settings CRUD and token issuance.

## Integration receipts

Identity and routing verifier snapshots above are integrated as `62fde37`,
`c2171a1`, `ef536b7`, and `0dc61e6`. Root ran
`go test -race -count=1 ./...`: gateway, identity, and routingauth passed.
This is baseline evidence, not closure of the findings above.

CLI main `0516b94` is pushed; GitHub CI run `37577614106` succeeded. The
Python wrapper's focused gateway suite passed 28 tests. Gateway reverse
runtime, browser wiring, deployment hardening, and production SSH lab
acceptance are still being integrated by their assigned workers.
