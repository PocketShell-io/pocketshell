# Deployment review and repair ledger

2026-10-07: Astra independently reviewed the in-progress deployment worktree without executing commands or changing AWS. These are rollout blockers until corrected and verified. The workflow was still incomplete during review; this is not acceptance of the final deployment.

| ID | Finding | Required verification | Status |
| --- | --- | --- | --- |
| D1 | SSM result APIs incorrectly scoped to a document ARN | Resource-star read permissions with region constraint; final role can retrieve its deployment result | Assigned to ZAI |
| D2 | DocumentType condition incorrectly applied to instance authorization | Split pinned document and instance grants; other documents/instances denied | Assigned to ZAI |
| D3 | Single-quoted YAML contains doubled regex escapes | Parsed actual document accepts examples and rejects unwanted values | Assigned to ZAI |
| D4 | Compressed and executable hashes conflated; ARM64 ELF byte order wrong | Real ARM64 build passes; corruption, wrong architecture and wrong digest fail | Assigned to ZAI |
| D5 | Rollback does not save current release or legacy executable | Failed initial migration restores legacy; failed C after A to B restores B and its unit/hash | Assigned to ZAI |
| D6 | Unit/state writes not atomic; no deployment lock; cleanup variable out of scope | Concurrent, interrupted, failed restart and successful deployment leave consistent recoverable state | Assigned to ZAI |
| D7 | SSM parameters use strings instead of string arrays; output field wrong; permanent errors masked | Realistic API request/response fixtures distinguish eventual consistency from errors | Assigned to ZAI |
| D8 | Health checks skip TLS verification, alias and application version | Trusted TLS for both names; running version and restored executable identity verified | Assigned to ZAI |
| D9 | Arbitrary bucket/service parameters exceed intended authority | Bootstrap-pinned values and digest-bound artifact path reject substitutions | Assigned to ZAI |
| D10 | Artifact keys and VERSION can be overwritten | Conditional immutable uploads and digest-bound manifest support identical retries only | Assigned to ZAI |
| D11 | Unit rewriting duplicates aliases and can change unrelated arguments | Repeated deployments preserve arguments and one canonical domain/alias pair | Assigned to ZAI |
| D12 | Newly created repository may use immutable-ID OIDC subject | Verify/configure exact repository subject before bootstrap; never wildcard trust | Assigned to coordinator and ZAI |
| D13 | Root service can access instance credentials and legacy mutable artifact | Dedicated service user, verified IMDS block, protected deployment files, retire legacy object write permission; SSM remains operational | Assigned to coordinator and ZAI |
| D14 | Generated CI and deployment independently trigger on push, allowing deployment before failed checks | Deployment depends on all required checks for the same commit; main serialization preserves completed release transactions | Assigned to ZAI |
| D15 | Metadata probe accepts all curl failures and expects a nonexistent systemd-run output marker | Actual runtime-context token PUT is blocked; unrelated tool/output/proxy failures cannot pass; fallback checks actual exit and guard state | Assigned to ZAI |
| D16 | Health/ownership checks omit effective service UID, groups, capabilities and overriding unit settings | Actual MainPID and effective unit satisfy minimal runtime privileges before deployment success | Assigned to ZAI |
| D17 | Trusted-path audit loses original symlink ancestry and misses sensitive files; certificate chown precedes path validation | Original/resolved paths and write access audited before privileged mutations; protected files cannot be replaced by runtime | Assigned to ZAI |
| D18 | Runtime unit inherits arbitrary writable paths and does not deliberately include the certificate cache | Only intended certificate and registry state are writable; legacy argument preservation does not expand runtime write authority | Assigned to ZAI |
| D19 | Success ledger does not rotate prior CURRENT to PREVIOUS; error cleanup removes rollback probe directory | Successful and failed retries preserve last-good release; rollback health verification retains usable private scratch state | Assigned to ZAI |
| D20 | Helper trust-base default `/` produces a `//*` match and skips ordinary absolute ancestors | Actual default-root generated helper audits every component before writes; unsafe owner/mode/ACL and failing stat refuse | Fresh ZAI repair assigned after activation task |
| D21 | Plain systemd properties strip privilege prefixes, while installer fixtures preserve them | Actual prefix-free output and authoritative command flags distinguish fully privileged guard from unsafe modifiers; realistic fixtures and refusal controls | Fresh ZAI repair assigned after activation task |
| D22 | Sticky writable helper directory is accepted with predictable, nonexclusive staging | Actual helper/staging paths reject untrusted writes; staging cannot follow an attacker-created symlink before final rename | Fresh ZAI repair assigned after activation task |
| D23 | Root normalizes and reads service-writable registry/certificate paths after a separate preflight while writers remain active | Ordinary redeploy avoids privileged pathname operations on runtime contents; migration binds unavoidable changes to checked no-follow descriptors and a link/ownership policy, preserves bytes and availability, and verifies full writer quiescence where relied upon | Fresh ZAI repair queued after D20–D22 |

Sources: [AWS SSM authorization](https://docs.aws.amazon.com/service-authorization/latest/reference/list_ssm.html), [SSM SendCommand](https://docs.aws.amazon.com/systems-manager/latest/APIReference/API_SendCommand.html), [SSM GetCommandInvocation](https://docs.aws.amazon.com/systems-manager/latest/APIReference/API_GetCommandInvocation.html), [SSM parameter validation](https://docs.aws.amazon.com/systems-manager/latest/userguide/documents-syntax-data-elements-parameters.html), [S3 conditional uploads](https://docs.aws.amazon.com/AmazonS3/latest/API/API_PutObject.html), [GitHub AWS OIDC](https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-in-aws).

No bootstrap or deployment was performed using the reviewed broken source. Final review must cover generated SSM content and CI gates as well as these repairs.

Independent committed review of `933a482`/`7927880` passed contract205,
provision33, bootstrap10 and workflow18 checks. These passing harnesses did
not expose D20–D22: they used a custom trust base and an inaccurate systemd
serialization fixture. D20–D22 remain required source and behavior repairs.
Missing standalone runtime source caused the new-API runner to exit1 rather
than skip successfully; this is dependency refusal evidence, not Docker
acceptance. Registry/certificate ownership, enabled health and rollback
posture are still separately assigned activation gates.

The isolated independent installer harness at `7927880` reached139 passing
assertions before its600-second timeout (exit124); no full160-case independent
pass is claimed. This partial receipt neither waives D20–D22 nor establishes
production activation. Further harness runs must retain actual timeouts and
unexecuted-case limits in their reports.

Static review of activation installer blob
`e2946de327ca6f95beab94640c5e12910f06f12c` identified D23 independently of
D20–D22. Registry symlink checks precede root pathname chown/chmod/read;
legacy service-owned parent reclamation follows child mutation. The runtime
can replace those names between operations. This is source analysis, not an
executed compromise. Installer serialization does not stop runtime writers.
Acceptance requires owned replacement/hardlink/interrupted-migration fixtures
with an outside sentinel unchanged, and completion of the actual activation
and rollback gates. The prior activation worker timed out with exit124;
its partial source and logs are preserved, not accepted or deployed.

The provisional default-root installer review found two residual D21 defects:
authoritative command records accept missing flags or duplicate flags that
overwrite earlier values, and the raw unit hook check misses whitespace before
`=`. Plain systemd command properties strip privilege prefixes, so these cases
cannot establish guard authority. The queued D23 repair also owns strict
exactly-once authoritative flag validation and faithful whitespace/drop-in
handling. Its final committed source and realistic refusal controls must pass
independent review before deployment. A provision harness passing 78 cases does
not close these findings or establish the final installer result.

## Verified bootstrap inputs and runtime boundary

The live GitHub repository OIDC settings report `use_default: true`, `use_immutable_subject: true` and prefix `repo:PocketShell-io@327658728/pocketshell-gateway@1408222370`. Astra confirmed the exact main-branch subject without a job environment is `repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main`. Match that and `sts.amazonaws.com` exactly. An environment changes the subject context; privileged deployment must not execute untrusted pull-request code. [GitHub OIDC reference](https://docs.github.com/en/actions/reference/security/oidc)

Read-only live AWS inspection found only the inline `fetch-relay-binary` policy (GetObject and PutObject on the old `relay-arm64.gz`) and managed `AmazonSSMManagedInstanceCore` on the existing instance role. No attached frontend mutation policy was found. IMDSv2 is required, hop limit is one, IPv6 metadata is disabled. These settings do not prevent a gateway process on the instance from obtaining credentials. The managed SSM policy includes Parameter Store reads and agent-channel authority; the application must be prevented from accessing metadata. Retire the unnecessary legacy object write grant during bootstrap. [AWS managed SSM policy](https://docs.aws.amazon.com/aws-managed-policy/latest/reference/AmazonSSMManagedInstanceCore.html), [AWS process-level metadata restrictions](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-metadata-limiting-access.html)

The existing unit runs as root. Migration must establish a dedicated service user with only required low-port capability, keep deployment files root-owned, and narrowly allow certificate/registry writes. Verify metadata filtering on the actual kernel rather than assuming a systemd setting is enforced. SSM and root deployment must retain access. This runtime change requires executable acceptance evidence; the read-only review supplies none.

The coordinator retired the live instance role's legacy S3 write grant on 2026-10-07: `fetch-relay-binary` now permits only GetObject on the exact old artifact. A fresh IAM read confirmed that policy, and the existing HTTPS relay still returned its expected 426 response. The old CloudFormation inventory remains historical; routine deployment must not reintroduce its write grant. D13 remains open for service-user and metadata-isolation verification.

IAM simulation of the live role subsequently returned GetObject allowed and PutObject implicitDeny on that old object. Read-only inspection of `pocketshell-web-github-actions-deploy` also confirmed exact audience and subject matching limited to the web repository's main branch (immutable-ID and historical name forms). The gateway repository's OIDC subject does not match that frontend role. Final gateway deployment-role and runtime enforcement still require verification after bootstrap.
