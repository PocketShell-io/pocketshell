# Opus independent security review: compromised-gateway SSH isolation

Reviewer: Opus 5.5 (claude-opus-5-5), independent defensive review requested by the project owner.
Scope owned: `security/opus/**` and this document. Runtime code is owned by the identity, tunnel, integration and delivery workers. The separate security suite is not part of this review. No Astra test ran, so this review makes no Astra approval claim.

**Status: CHANGES REQUESTED.** The suite now runs against the exact current sibling sources (section 5a). It found new runtime bugs. A fresh run against the root's accepted integrated commit is still required. No approval rests on baseline results alone.

## 1. Question under review

Can an untrusted or compromised byte-forwarding gateway authenticate to a user's home SSH server without that user's authorized SSH private key?

The intended answer is "no", by construction:

- SSH runs end to end between the user's client and the home sshd.
- The gateway only carries opaque bytes.
- The host agent forwards only to its configured loopback SSH endpoint.
- Shell access is decided by the home sshd: the user's authorized key, with password and keyboard-interactive login disabled.
- The client pins the real home host key.

Gateway account and device credentials prove ownership and allow routing. They do not grant shell access.

## 2. Threat model

### Assets

| Asset | Where it lives | Must never be available to the gateway |
|---|---|---|
| User's SSH private key | Client only | Yes |
| Home SSH host private key | Home host only | Yes |
| Terminal plaintext (commands and output) | Client and home sshd | Yes (only ciphertext crosses the gateway) |
| Device Ed25519 private key (agent identity) | Home agent, mode 0600 | Yes |
| Google ID token | Client and sync service in the broker-only flow; also the co-resident gateway process on legacy direct/forwarding paths | Must never be sent on the new routes. The retained legacy bearer carries sync ciphertext GET/PUT/DELETE authority for affected accounts; this SSH suite does not prove whole-process isolation. |
| Scoped broker token (sync-minted RS256 JWT: `iss` = exact sync API, `aud` = `pocketshell-gateway`, `scope` = `pocketshell.gateway`, lifetime ≤ 5 min) | Client and gateway | No. The gateway sees it by design. It must not work as an SSH credential or as a sync credential. |
| Device registry (public keys, pinned host-key lines, owner IDs) | Gateway | No. The gateway is assumed able to read and modify it. |

The table describes the new SSH flow's boundaries, with the retained legacy
exception explicit. An account that also sends a valid Google bearer
through any legacy/background/other-device path remains exposed to that
runtime's sync-credential authority. Captured ciphertext CRUD authority
does not itself establish vault passphrase recovery, SSH key extraction or
shell access. Historical SSH/routing results below do not close the raw
Google retirement or execution-isolation migration gate.

### Trusted

- The client binary or browser bundle, and how it is distributed.
- The home host agent, the home sshd, the home OS.
- The user's authorized SSH private keys.
- The out-of-band step that pins the home host key at enrollment (the `known_hosts` entry on the client).

### Untrusted (the adversary)

- The gateway process, its host, its storage and its credentials.

The adversary can do all of the following:

- Read, drop, delay, reorder, modify, replay and inject bytes on every stream.
- Route any client stream to any endpoint it controls, including its own SSH server with its own host key.
- Open new streams toward a connected agent at will, including with forged stream IDs or destination-looking metadata.
- Keep and replay any token, challenge, proof or registration message it has ever seen.
- Rewrite the device registry, including pinned host-key lines and owner IDs.

### Security properties claimed by the design (and tested here)

| ID | Property | Main test |
|---|---|---|
| P1 | Positive control: the authorized key runs a benign sentinel command through the real path | `TestPositiveControlAuthorizedKey` |
| P2 | An unknown SSH key is refused by the home sshd | `TestUnauthorizedKeyRejected`, `TestNoCredentialRejected` |
| P3 | Password and keyboard-interactive login are disabled even with the correct password; only `publickey` is advertised | `TestPasswordLoginDisabled` |
| P4 | Credentials the gateway holds or sees (account token, device key, routing IDs) do not work as SSH credentials | `TestGatewayHeldCredentialsAreNotShellCredentials` |
| P5 | The client refuses a substituted host key before sending any user-authentication request | `TestSubstitutedHostKeyRefusedBeforeAuth` (the substituted server records zero userauth requests) |
| P6 | The agent forwards only to its configured loopback SSH endpoint; gateway-chosen destinations never connect | Decoy listeners on home `127.0.0.1:2222` and on the LAN neighbour record zero agent connections (integrated phase) |
| P7 | Cross-owner route, list, enroll and revoke attempts fail; host-challenge proofs cannot be replayed across connections or devices | Integrated phase |
| P8 | Revoking a device tears down existing streams and blocks re-registration; a reconnect from an older generation cannot clean up its replacement | Integrated phase |
| P9 | The home sshd is reachable only on loopback; the lab publishes no host ports; the home host needs no inbound port | `TestHomeSSHDNotReachableFromLabNetwork`, `TestNoPublishedPorts` |

### Out of scope, and limits that remain by design

- **Availability.** A compromised gateway can always drop, stall or refuse service, and can selectively disconnect users.
- **Traffic metadata.** The gateway sees:
  - which account connects to which device, and when;
  - client and agent IP addresses;
  - session timing and duration;
  - byte counts and packet sizes and timing, which leak keystroke timing patterns (SSH's keystroke obfuscation reduces but does not remove this);
  - verified account email addresses.
- **Trust-on-first-use of the host key.** P5 holds only if the client's pinned host key came from the real home host (local enrollment). If the pin itself is fetched from the gateway registry, a compromised gateway can supply its own key, and P5 does not hold. This review checks where the client gets its pin.
- **Browser frontend.** Browser clients run SSH in JavaScript delivered by the web frontend. Whoever controls frontend delivery controls the code that holds the user's SSH key and checks the host key. That delivery is a separate trusted boundary. Nothing in this repository can protect a browser user from a compromised frontend origin, CDN or build pipeline. In particular, the gateway must not serve, proxy or influence that code.
- Compromise of the home host, the client device or the user's keys.
- Weaknesses in SSH itself, OpenSSH or Go `x/crypto/ssh`, beyond running current versions.

## 3. Lab and fixture plan

Everything runs in a disposable Docker Compose project named `gateway-opus-test`:

- One `internal: true` network with no route outside the lab and no published host ports.
- Keys, passwords and sentinels are generated per run, written under the gitignored `.tmp/opus-lab/<run>/`, and private keys are deleted after the run.
- No external systems, real accounts or real secrets are used.

| Role | Contents |
|---|---|
| `home` | Alpine OpenSSH `sshd` on `127.0.0.1:22` only. Config: `AuthenticationMethods publickey`, password and kbd-interactive off, `AllowUsers labuser`, no forwarding. `labuser` has a real random password so P3 is meaningful. Decoy `tcpsentinel` on `127.0.0.1:2222`. Integrated phase: the runtime host agent with an enrolled device key. |
| `lan` | Neighbour `tcpsentinel` on `:22`, `:2222` and `:80`, standing in for other LAN hosts the agent must never reach. |
| `gateway` | Baseline: `bytepipe` honest route plus a substituted route to `honeyssh`. Integrated: the real gateway server built from the integrated commit (dev mode, lab-only JWKS), plus fixture routing for substitution. |
| `client` | OpenSSH client with a pinned `known_hosts` under a fixed `HostKeyAlias`, `IdentitiesOnly`, no agent and no ambient config. Integrated phase: the runtime client CLI as `ProxyCommand`. |

Fixtures in `security/opus/fixtures/`:

- `honeyssh`: an SSH server with its own fresh host key. It records every userauth attempt (method and user only, never secrets) and rejects all of them.
- `tcpsentinel`: a decoy listener that records every connection.
- `bytepipe`: a fixed-route byte forwarder. It never parses or injects bytes.

None of these is an attack tool. They only receive, record and refuse, or forward to a fixed upstream inside the lab.

Phases:

1. **Baseline (runtime-independent).** `bytepipe` stands in for agent plus gateway. This validates P1–P5 and P9 and proves the fixtures can detect the property being tested. The baseline exposes `home:2200` inside the lab network to emulate the agent. The integrated lab has no such listener.
2. **In-flight code review.** Read the worker branches and record issues early, marked as not final.
3. **Integrated.** Build the gateway and the agent/client CLI from the commit in `.tmp/ready-commit`. Repeat P1–P5 and P9 over the real transport. Add P6–P8 using real enrollment, two lab accounts signed by a lab-only JWKS, and revocation during an active session.

### Sibling-source mode (pre-integration)

`OPUS_LAB_MODE=siblings` runs `security/opus/scripts/stage-siblings.sh`. The script copies these exact sibling sources, read-only, into the untracked `.tmp/opus-lab/<run>/stage/` and writes a SHA-256 `MANIFEST.txt`:

- root: integration `relay.go`, `go.mod`, `go.sum`;
- `internal/identity` and `internal/routingauth` from main;
- `internal/tunnel`, `internal/hostagent` and `cmd/pocketshell-link` from the tunnel worktree.

From that staging copy the lab builds the real gateway binary, the real `pocketshell-link` and `siblingprobe`. Nothing from other owners is committed here.

The gateway runs in dev-listen mode. It trusts the per-run lab JWKS (`idp:8080/gateway/jwks`) as its sync broker only through `-broker-allow-insecure-dev`. **That trust exists only in the lab.** The client is real OpenSSH. Its `ProxyCommand` is `wsclient`, which speaks the actual `ClientAuth`/`ReadyMsg` frames. Its host-key pin is provisioned independently at key generation, never taken from `ready.ssh_host_key`.

Lab-only adapters are used only where the real CLI is broken. Each one is labelled and has its own failing regression test:

- `siblingprobe enroll` signs with the actual `identity.SignEnrollment` and writes the actual `hostagent` config and key files. It stands in for F-08.
- `siblingprobe agent` is `hostagent.RunAgent` with the missing `Now` clock supplied. It stands in for F-11.

## 4. Commands

```sh
# Baseline lab (requires Docker; runs only on the local disposable network)
OPUS_LAB=1 /usr/local/go/bin/go test -tags opuslab -count=1 -v ./security/opus/

# Keep containers for inspection after the run
OPUS_LAB=1 OPUS_LAB_KEEP=1 /usr/local/go/bin/go test -tags opuslab -count=1 -v ./security/opus/
docker compose -p gateway-opus-test -f security/opus/lab/compose.baseline.yaml down -v

# Sibling-source lab (exact current worker sources; override paths with
# OPUS_SRC_ROOT / OPUS_SRC_IDENTITY / OPUS_SRC_TUNNEL)
OPUS_LAB=1 OPUS_LAB_MODE=siblings /usr/local/go/bin/go test -tags opuslab -count=1 -v ./security/opus/
```

Without `OPUS_LAB=1`, or without the `opuslab` build tag, the suite does nothing, so the repository's ordinary `go test ./...` is not affected.

## 5. Results log

| Date | Commit under test | Mode | Result |
|---|---|---|---|
| 2026-10-07 | d963900 (main before runtime) + review suite | baseline | 8/8 PASS (P1–P5, P9). Run dir `.tmp/opus-lab/<ts>` |
| 2026-10-07 06:01Z | siblings: integration `1a4b5c3` (clean), main `12daba3` (clean), tunnel `36ccd32` + uncommitted runtime; manifest SHA-256 `8d67186a379592cc…` | siblings | **FAIL**, details in 5a. Run dir `.tmp/opus-lab/20261007T060107Z`, log `.tmp/opus-siblings-run3.log` |

### 5a. Sibling-source run (2026-10-07 06:01Z)

Staged file hashes (SHA-256, first 16 hex characters):

| File | Hash |
|---|---|
| `relay.go` | `a4046baa457e8fbd` |
| `internal/routingauth/routingauth.go` | `56076c39399fecbb` |
| `internal/identity/challenge.go` | `d9433cd2fa5c33b0` |
| `internal/identity/service.go` | `1c33f557cfbf14e4` |
| `internal/identity/store.go` | `686951d7e8a50202` |
| `internal/tunnel/service.go` | `ae5c15b79dba90dc` |
| `internal/tunnel/mux.go` | `ece53c3c06842ff3` |
| `internal/hostagent/agent.go` | `b69e3aae5ce4eb87` |
| `internal/hostagent/enroll.go` | `e4a027df6967145f` |
| `internal/hostagent/cli.go` | `38b1de70cadcb14c` |
| `cmd/pocketshell-link/main.go` | `410b88152a68ee87` |

The full manifest is in the run directory.

| Property / test | Result |
|---|---|
| Real `pocketshell-link enroll` against real identity (`TestRealCLIEnrollment`) | **FAIL**: F-08 |
| Real `pocketshell-link run` (`TestRealCLIRun`) | **FAIL**: F-11 (nil-pointer panic) |
| Scoped credential policy (`TestScopedCredentialPolicy`, client route and identity API, all variants signed by the trusted lab key) | PASS: valid broker token accepted. Rejected: Google ID token (plain, and with gateway `aud` and `scope`), wrong audience, audience array, issuer with trailing `/`, expired, string `exp`, unverified email, string `email_verified`, non-allowlisted account, untrusted signer reusing the trusted `kid`. **FAIL** (accepted on both entry points): missing `scope`, wrong `scope`, 1 h lifetime, 9 min lifetime, missing `iat`/`nbf`, future `nbf`. This is F-12. |
| Host CLI never sends the Google token (`TestHostCLINeverSendsGoogleToken`) | **FAIL**: F-09 |
| Cross-owner (`TestCrossOwnerDenied`) | PASS. Bob cannot reach `home-a`, list it or revoke it; Alice cannot reach `home-b`; the positive control still works afterwards. |
| Host proof replay (`TestHostProofReplayRejected`, actual `identity.Sign` and `HostChallenge`) | PASS. A fresh proof is accepted (positive control). A proof from another connection's challenge is refused. `home-b`'s key claiming `home-a` is refused. |
| Revocation, active and future (`TestRevocationActiveAndFuture`) | PASS. A real OpenSSH session through the real gateway and agent printed the sentinel (P1 over the real path). Owner revoke cut it (exit 255, "closed by remote host"). After the revoke, and again after a gateway restart: new client streams are refused, the revoked key's host auth is refused, and re-enrolling the revoked key under a new device ID is refused. |
| P6, agent loopback only (decoy sentinels on home `127.0.0.1:2222` and LAN `:22/:2222/:80`) | PASS: zero connections. By source, `FrameOpen` carries no destination. |
| P5 substituted host key refused before userauth; P9 loopback-only sshd; no published ports | PASS |
| P1–P4 matrix over the real tunnel (`ssh_test.go`) | **BLOCKED** by F-13. The agent control connection dies 10 s after every handshake, so these runs hit `host_offline` during reconnects. Not counted as passes. |
| Session lifetime policy (`TestSessionOutlivesAdmissionTokenByPolicy`) | **BLOCKED** by F-13: the session was cut at 5 s by the agent reconnect, not by any token policy. |
| Uncertain fsync during revocation, and duplicate revoked keys across store formats | Not reachable black-box. Identity owns them (Astra items 1 and 2; main `12daba3` claims the containment fix). This suite only covers revoke → restart → tombstone on the normal path. |
| Expiry re-check after JWKS fetch | Source review only. Both the root shim and `routingauth` check `exp` before the key fetch and never again (Astra item 6 still open). The black-box run cannot show the window because the lab JWKS answers immediately. |

## 6. Findings, fixes and retests

Status key: *in-flight* means raised from uncommitted worker code and not yet confirmed on the integrated commit. Each in-flight finding is either confirmed or retired by rerunning against the integrated build. Cross-references point to the coordinator ledger in `docs/source-review-findings.md`.

| ID | Severity | Finding | Ledger | Owner | Fix / required property | Retest |
|---|---|---|---|---|---|---|
| F-01 | High (impersonation) | The gateway sends the client its registry copy of the home SSH host key (`ready.ssh_host_key`). A client that pins this value trusts the gateway for host authentication. A compromised gateway can then put its own SSH server in the path and receive the user's userauth requests and terminal input. It still cannot log in to the home sshd, because publickey signatures are bound to the session. | O1 | tunnel / clients | The client verifies a host key provisioned independently: local enrollment output, fingerprint or QR. The registry value is advisory only. A mismatch aborts before userauth. | Pending integrated run: `TestSubstitutedHostKeyRefusedBeforeAuth` plus a demo using `wsclient -trust-ready-known-hosts` |
| F-02 | Medium (availability) | The mux receiver does not enforce receive credit. A peer can push DATA beyond the window and grow buffers without bound. A malicious agent can exhaust gateway memory (affecting every user); a malicious gateway can exhaust agent memory. | A5 | tunnel | DATA beyond granted credit is a protocol error that tears down the connection | Pending |
| F-03 | Low (availability) | The gateway-side mux accepts OPEN frames from a host. The unbuffered accept channel is never drained, so the read loop blocks. | A6 | tunnel | Role-aware mux rejects OPEN frames sent in the wrong direction | Pending |
| F-04 | Low (privacy) | Device-existence oracle: a cross-owner probe gets close 4403 `forbidden`, but an unknown device gets 4404 `not_found`. | — | tunnel | Uniform response for unknown, revoked and other-owner devices | Pending |
| F-05 | Low/Medium (honest-gateway revocation) | Revoke time-of-check/time-of-use race: an agent that passed `GetDevice` before the revocation was persisted can register after `RevokeDevice` has run, and stays connected. Active client sessions are also not re-checked when the token expires or the account leaves the allowlist. | A1 | tunnel | Serialize admission with revocation; re-check after registration | Pending |
| F-06 | Medium (availability) | Unauthenticated client WebSocket handshakes are not counted against any limit; they are bounded only by the handshake timeout. | A7 | tunnel | Pending handshakes have a bounded budget | Pending |
| F-07 | Info (interop) | The in-flight agent signed `tunnel.EnrollTranscript`, but identity verifies `identity.Challenge.Transcript()`. A later in-flight revision switched to the identity transcript. | I1 | coordinator | One canonical transcript | Pending |

New findings from the sibling-source run. Each one is executable against the exact staged sources listed in 5a.

| ID | Severity | Finding | Ledger | Owner | Failing regression | Required property |
|---|---|---|---|---|---|---|
| F-08 | High (function) | `hostagent.parseChallengeTranscript` reads the first 4 bytes as a length. Identity's `Challenge.Transcript()` starts with the unprefixed separator `pocketshell-challenge-v1`. Real enrollment always fails with "transcript: field length overruns input". `Enroll` also JSON-encodes an already marshalled `[]byte` body for `/identity/v1/enroll`, which sends a base64 JSON string. That bug is still unexercised because the earlier failure stops enrollment first. | C1 | tunnel / hostagent | `TestRealCLIEnrollment` | Real CLI enrolls against real `identity.Service`. Parsing goes through one shared identity helper. |
| F-09 | High (credential exposure) | `pocketshell-link enroll` sends whatever is on stdin as the bearer, including a Google-issued ID token. Its help text tells users to pipe a Google token. A compromised gateway then receives a credential with sync authority. The gateway refuses it, but too late: the gateway has already seen it. | C2 | hostagent / CLI | `TestHostCLINeverSendsGoogleToken`: the recorder saw `iss=https://accounts.google.com` at `/identity/v1/challenge` | The CLI accepts only broker tokens and refuses other issuers locally, before any request. Help text and docs say "gateway token from the sync broker". |
| F-11 | High (function) | `hostagent.RunAgent` never sets `AgentConfig.Now`, and `NewAgent` has no default. `Agent.Run` calls `a.cfg.Now()` and panics (agent.go:109). The real `pocketshell-link run` cannot start. | — | hostagent | `TestRealCLIRun` (panic trace in `out/home/agent.log`) | `NewAgent` defaults `Now` to `time.Now`. A CLI-level test runs the real `run` command. |
| F-12 | Medium (contract) | Root wiring uses the `relay.go` `brokerVerifier` shim instead of `routingauth`. It never checks `scope`, `iat`, `nbf` or lifetime. Tokens with no scope, a wrong scope, a 1 h lifetime or a future `nbf` are admitted on both `/identity/v1/*` and the client SSH route. `routingauth` itself still allows a 10 min lifetime (Astra item 3), so even swapping it in would still accept the 9 min case. The JWKS cache TTL is 1 h. | Astra round three items 3 and 6 | coordinator / authbroker | `TestScopedCredentialPolicy/{missing-scope,wrong-scope,lifetime-1h,lifetime-9m,missing-iat,not-yet-valid}` | Wire `routingauth.Verifier` (or the same checks): exact `scope`, required `iat`/`nbf`, `exp − iat ≤ 300 s` plus leeway, and an `exp` re-check after the key fetch. |
| F-13 | High (availability) | The agent sets its WebSocket read deadline to now + 10 s before the handshake (agent.go:178). It never clears or extends that deadline and installs no pong handler. Every control connection drops 10.000 s after connecting (gateway log 06:01:20.161 → 06:01:30.161, 1006), killing every SSH session on it. This is finding A4 on the agent side. The gateway side was fixed. | A4 | hostagent | Agent and gateway logs in the run dir. The ssh_test matrix over the tunnel shows `host_offline`. | After `ok`, the agent switches to a liveness deadline extended by pings and data. A session lasting more than 3 handshake timeouts stays up. |
| F-14 | Medium (overclaim) | `docs/routing-credentials.md` says "sessions are re-authenticated before ExpiresAt". The tunnel checks the token only at admission. The adapter in `relay.go` drops `ExpiresAt`. Sessions are bounded only by `MaxSessionDuration`: default 12 h, hard cap 24 h, and not settable by flag. Token expiry does not end a session. | Astra scoped item 7 | docs / coordinator | Source; behavioural test pending F-13 (`TestSessionOutlivesAdmissionTokenByPolicy`) | Document admission expiry separately from the absolute session bound, or actually enforce re-authentication. Make no claim of expiry-driven termination unless it is enforced. |

Status of earlier findings against the staged sources:

- **F-01:** server side unchanged, and `ready.ssh_host_key` is now documented as advisory. The lab client pins independently, and P5 passes.
- **F-05:** the source now uses a revocation epoch. Active and future revocation pass on the honest path.
- **F-06:** pending client upgrades are now counted (`pendingClients`) in source. Not load-tested here.
- **F-02, F-03, F-04, F-07:** not re-verified in this run. F-04's response asymmetry (`not_found` vs `forbidden`) is still present in source.

Fixture sensitivity check (2026-10-07): in a kept baseline lab, sshd was weakened to `PasswordAuthentication yes` and `AuthenticationMethods any`. Password login over the same transport then succeeded (`MUT-OK`, exit 0). So `TestPasswordLoginDisabled` does detect the weakened configuration it guards against.

## 7. Verdict

**CHANGES REQUESTED** (pre-integration, sibling sources as of 2026-10-07 06:01Z).

- **What held:** with lab adapters standing in for F-08 and F-11, the SSH boundary held wherever it could be exercised: host-key substitution, loopback only, cross-owner, proof replay and revocation.
- **Blockers:**
  - The real host CLI cannot enroll (F-08) or run (F-11).
  - Agent sessions die every 10 s (F-13).
  - The CLI forwards Google tokens to the gateway (F-09).
  - The root verifier does not enforce the broker `scope` or lifetime contract (F-12).
- **Before any verdict:** the root must rerun this suite (`OPUS_LAB_MODE=siblings`, pointed at the accepted integrated tree) with the full P1–P4 matrix passing over the real tunnel.

This is not an approval, and it is not an Astra execution approval.
