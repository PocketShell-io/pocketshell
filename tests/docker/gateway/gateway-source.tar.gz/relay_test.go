package main

// Tests for the frozen legacy wire contract plus the hardening around it:
// status codes, origin policy, capacity reserved before dial, websocket
// liveness/boundedness, cleanup and context-aware shutdown.

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/netip"
	"runtime"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
)

// testRelay builds a relay with deterministic small timings and a stubbed
// authenticator (token "good-token" → "user@example.com").
func testRelay() *relay {
	r := newRelay()
	r.handshakeTimeout = 2 * time.Second
	r.pongWait = time.Second
	r.pingPeriod = 200 * time.Millisecond
	r.origins = map[string]bool{
		"https://app.pocketshell.io": true,
		"https://pocketshell.io":     true,
	}
	r.authenticate = func(ctx context.Context, token string) string {
		if token == "good-token" {
			return "user@example.com"
		}
		return ""
	}
	return r
}

// accountCount reads perAccount under the relay lock (the server mutates it
// from session goroutines).
func accountCount(r *relay) int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.perAccount)
}

func wsServer(t *testing.T, r *relay) *httptest.Server {
	t.Helper()
	s := httptest.NewServer(r)
	t.Cleanup(s.Close)
	return s
}

func wsDial(t *testing.T, s *httptest.Server, query string, header http.Header) (*websocket.Conn, *http.Response, error) {
	t.Helper()
	u := "ws" + strings.TrimPrefix(s.URL, "http") + "/?" + query
	d := websocket.Dialer{HandshakeTimeout: 2 * time.Second}
	return d.Dial(u, header)
}

// echoListener is a stand-in SSH server: echoes bytes, never speaks.
func echoListener(t *testing.T) (net.Listener, int) {
	t.Helper()
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { l.Close() })
	go func() {
		for {
			conn, err := l.Accept()
			if err != nil {
				return
			}
			go func(c net.Conn) {
				defer c.Close()
				buf := make([]byte, 4096)
				for {
					n, err := c.Read(buf)
					if n > 0 {
						if _, werr := c.Write(buf[:n]); werr != nil {
							return
						}
					}
					if err != nil {
						return
					}
				}
			}(conn)
		}
	}()
	return l, l.Addr().(*net.TCPAddr).Port
}

func devEchoRelay(t *testing.T) (*relay, int) {
	t.Helper()
	_, port := echoListener(t)
	r := testRelay()
	r.allowPrivateHosts = true
	return r, port
}

func TestNonWebSocketRequestGets426(t *testing.T) {
	r := testRelay()
	s := wsServer(t, r)
	res, err := http.Get(s.URL + "/?host=example.com&port=22&token=good-token")
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusUpgradeRequired {
		t.Fatalf("status = %d, want 426", res.StatusCode)
	}
	body, _ := io.ReadAll(res.Body)
	// The frozen body as served: http.Error appends one more newline.
	if string(body) != "pocketshell relay (websocket only)\n\n" {
		t.Fatalf("body = %q, want the frozen 426 body", body)
	}
}

func TestFrozenErrorStatuses(t *testing.T) {
	r := testRelay()
	s := wsServer(t, r)

	cases := []struct {
		name  string
		query string
		want  int
	}{
		{"missing host", "port=22&token=good-token", 400},
		{"missing port", "host=example.com&token=good-token", 400},
		{"port out of range", "host=example.com&port=70000&token=good-token", 400},
		{"port not numeric", "host=example.com&port=ssh&token=good-token", 400},
		{"private host by name", "host=10.0.0.1&port=22&token=good-token", 400},
		{"loopback name", "host=localhost&port=22&token=good-token", 400},
		{"internal name", "host=ip-10-0-1-9.internal&port=22&token=good-token", 400},
		{"bad token", "host=example.com&port=22&token=nope", 401},
		{"no token", "host=example.com&port=22", 401},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			_, res, err := wsDial(t, s, c.query, nil)
			if err == nil {
				t.Fatal("dial should have failed")
			}
			if res == nil || res.StatusCode != c.want {
				t.Fatalf("status = %v, want %d", res, c.want)
			}
			res.Body.Close()
		})
	}
}

func TestDialFailureIs502(t *testing.T) {
	r := testRelay()
	r.dialFunc = func(ctx context.Context, network, addr string) (net.Conn, error) {
		return nil, errors.New("connection refused")
	}
	s := wsServer(t, r)
	_, res, err := wsDial(t, s, "host=example.com&port=22&token=good-token", nil)
	if err == nil {
		t.Fatal("dial should have failed")
	}
	if res == nil || res.StatusCode != http.StatusBadGateway {
		t.Fatalf("status = %v, want 502", res)
	}
	if res != nil {
		res.Body.Close()
	}
}

func TestDnsForbiddenTargetIs400Not502(t *testing.T) {
	r := testRelay()
	r.resolver = &fakeResolver{addrs: map[string][]netip.Addr{
		"metadata.example": {aip("169.254.169.254")},
	}}
	s := wsServer(t, r)
	_, res, err := wsDial(t, s, "host=metadata.example&port=22&token=good-token", nil)
	if err == nil {
		t.Fatal("dial should have failed")
	}
	if res == nil || res.StatusCode != http.StatusBadRequest {
		t.Fatalf("status = %v, want 400 (forbidden resolution is a bad host, not a dial failure)", res)
	}
	if res != nil {
		res.Body.Close()
	}
}

func TestEchoWireContract(t *testing.T) {
	r, port := devEchoRelay(t)
	s := wsServer(t, r)
	conn, res, err := wsDial(t, s, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err != nil {
		t.Fatalf("upgrade: %v (resp %v)", err, res)
	}
	defer conn.Close()

	// Binary frame → echoed as binary (the SSH-over-WS path).
	if err := conn.WriteMessage(websocket.BinaryMessage, []byte("hello-ssh")); err != nil {
		t.Fatal(err)
	}
	_, got, err := conn.ReadMessage()
	if err != nil {
		t.Fatal(err)
	}
	if string(got) != "hello-ssh" {
		t.Fatalf("binary echo = %q", got)
	}

	// Text frame → forwarded as its bytes, like the frozen worker.
	if err := conn.WriteMessage(websocket.TextMessage, []byte("as-text")); err != nil {
		t.Fatal(err)
	}
	mt, got, err := conn.ReadMessage()
	if err != nil {
		t.Fatal(err)
	}
	if mt != websocket.BinaryMessage || string(got) != "as-text" {
		t.Fatalf("text echo = (type %d) %q, want binary %q", mt, got, "as-text")
	}
}

func TestOriginPolicy(t *testing.T) {
	r := testRelay()
	s := wsServer(t, r)

	cases := []struct {
		name   string
		origin string
		token  string
		want   int
	}{
		{"allowed origin passes to auth (bad token → 401)", "https://app.pocketshell.io", "nope", 401},
		{"allowed apex passes to auth", "https://pocketshell.io", "nope", 401},
		{"evil origin rejected", "https://evil.example", "good-token", 403},
		{"suffix spoof rejected", "https://app.pocketshell.io.evil.example", "good-token", 403},
		{"scheme downgrade rejected", "http://app.pocketshell.io", "good-token", 403},
		{"port-pinned variant rejected", "https://app.pocketshell.io:8443", "good-token", 403},
		{"trailing slash is the same origin (allowed)", "https://app.pocketshell.io/", "nope", 401},
		{"no origin is not a browser (auth still applies)", "", "nope", 401},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			h := http.Header{}
			if c.origin != "" {
				h.Set("Origin", c.origin)
			}
			q := "host=example.com&port=22&token=" + c.token
			_, res, err := wsDial(t, s, q, h)
			if err == nil {
				t.Fatal("dial should have failed")
			}
			if res == nil || res.StatusCode != c.want {
				t.Fatalf("status = %v, want %d", res, c.want)
			}
			if res != nil {
				res.Body.Close()
			}
		})
	}

	// And a full success with the real allowed origin.
	relayEcho, port := devEchoRelay(t)
	relayEcho.origins = r.origins
	s2 := wsServer(t, relayEcho)
	h := http.Header{"Origin": {"https://app.pocketshell.io"}}
	conn, _, err := wsDial(t, s2, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), h)
	if err != nil {
		t.Fatalf("allowed origin could not connect: %v", err)
	}
	conn.Close()
}

func TestEmptyOriginsDeniesBrowsers(t *testing.T) {
	r := testRelay()
	r.origins = parseOrigins("") // explicit -origins= → no browser origins at all
	s := wsServer(t, r)
	_, res, err := wsDial(t, s, "host=example.com&port=22&token=good-token",
		http.Header{"Origin": {"https://app.pocketshell.io"}})
	if err == nil || res == nil || res.StatusCode != http.StatusForbidden {
		t.Fatalf("status = %v, want 403", res)
	}
	if res != nil {
		res.Body.Close()
	}
}

func TestCapacityReservedBeforeDial(t *testing.T) {
	r := testRelay()
	r.global = make(chan struct{}, 1)
	dial := &recordingDialer{}
	r.dialFunc = dial.dialFunc
	s := wsServer(t, r)

	// Pool full before any request: the request must be refused without a
	// single dial attempt (reservation happens before the TCP leg).
	r.global <- struct{}{}
	_, res, err := wsDial(t, s, "host=example.com&port=22&token=good-token", nil)
	if err == nil || res == nil || res.StatusCode != http.StatusServiceUnavailable {
		t.Fatalf("status = %v, want 503", res)
	}
	if res != nil {
		res.Body.Close()
	}
	if n := len(dial.dials); n != 0 {
		t.Fatalf("dials at capacity = %d, want 0", n)
	}
	<-r.global

	// Full flow: one live session exhausts the pool; the next is refused;
	// after it ends the slot is released and a new session works.
	relayEcho, port := devEchoRelay(t)
	relayEcho.global = r.global
	s2 := wsServer(t, relayEcho)
	c1, _, err := wsDial(t, s2, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer c1.Close()

	_, res, err = wsDial(t, s2, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err == nil || res == nil || res.StatusCode != http.StatusServiceUnavailable {
		t.Fatalf("second session status = %v, want 503", res)
	}
	if res != nil {
		res.Body.Close()
	}

	c1.Close()
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if len(relayEcho.global) == 0 && accountCount(relayEcho) == 0 {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if len(relayEcho.global) != 0 || accountCount(relayEcho) != 0 {
		buf := make([]byte, 1<<20)
		n := runtime.Stack(buf, true)
		t.Fatalf("capacity not released: global=%d accounts=%d\nSTACKS:\n%s",
			len(relayEcho.global), accountCount(relayEcho), buf[:n])
	}
	c3, _, err := wsDial(t, s2, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err != nil {
		t.Fatalf("session after release: %v", err)
	}
	c3.Close()
}

func TestReservePerAccountCap(t *testing.T) {
	r := testRelay()
	for i := 0; i < maxPerAccount; i++ {
		if res := r.reserveCapacity("a@example.com"); res != reserveOK {
			t.Fatalf("reservation %d = %v, want ok", i+1, res)
		}
	}
	if res := r.reserveCapacity("a@example.com"); res != reserveAccountFull {
		t.Fatalf("reservation %d = %v, want account-full", maxPerAccount+1, res)
	}
	// Another account still fits the same global pool.
	if res := r.reserveCapacity("b@example.com"); res != reserveOK {
		t.Fatalf("other account = %v, want ok", res)
	}
	// A refused per-account reservation must not have consumed a global slot.
	before := len(r.global)
	r.releaseCapacity("a@example.com")
	if len(r.global) != before-1 {
		t.Fatalf("global slots after one release: %d, want %d", len(r.global), before-1)
	}
	// "a" had maxPerAccount reservations; one is already released above.
	for i := 0; i < maxPerAccount-1; i++ {
		r.releaseCapacity("a@example.com")
	}
	r.releaseCapacity("b@example.com")
	if len(r.global) != 0 || accountCount(r) != 0 {
		t.Fatalf("leak: global=%d accounts=%d", len(r.global), accountCount(r))
	}
}

func TestHandshakeBoundRefusesWhenFull(t *testing.T) {
	r := testRelay()
	r.handshakes = make(chan struct{}, 2)
	r.handshakes <- struct{}{}
	r.handshakes <- struct{}{}
	s := wsServer(t, r)
	_, res, err := wsDial(t, s, "host=example.com&port=22&token=good-token", nil)
	if err == nil || res == nil || res.StatusCode != http.StatusServiceUnavailable {
		t.Fatalf("status = %v, want 503", res)
	}
	if res != nil {
		res.Body.Close()
	}
}

func TestAuthTimeoutRejects(t *testing.T) {
	r := testRelay()
	r.handshakeTimeout = 150 * time.Millisecond
	r.authenticate = func(ctx context.Context, token string) string {
		<-ctx.Done() // auth hangs until the handshake deadline cuts it off
		return ""
	}
	s := wsServer(t, r)
	done := make(chan int, 1)
	go func() {
		_, res, err := wsDial(t, s, "host=example.com&port=22&token=good-token", nil)
		if err == nil || res == nil {
			done <- 0
			return
		}
		done <- res.StatusCode
	}()
	select {
	case code := <-done:
		if code != http.StatusUnauthorized {
			t.Fatalf("timed-out auth status = %d, want 401 (deny)", code)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("auth timeout did not reject in time")
	}
}

func TestOversizedFrameTearsDown(t *testing.T) {
	r, port := devEchoRelay(t)
	r.readLimit = 128 // never lifted in production; shrunk here to attack it
	s := wsServer(t, r)
	conn, _, err := wsDial(t, s, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()

	if err := conn.WriteMessage(websocket.BinaryMessage, make([]byte, 256)); err != nil {
		t.Fatal(err)
	}
	conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, _, err := conn.ReadMessage(); err == nil {
		t.Fatal("server accepted an over-limit frame without tearing down")
	}
}

func TestDeadClientReapedByPongDeadline(t *testing.T) {
	r, port := devEchoRelay(t)
	r.pongWait = 250 * time.Millisecond
	r.pingPeriod = 100 * time.Millisecond
	s := wsServer(t, r)
	conn, _, err := wsDial(t, s, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()

	// Swallow pings: never pong, never send data — a dead client.
	conn.SetPingHandler(func(string) error { return nil })

	start := time.Now()
	conn.SetReadDeadline(time.Now().Add(3 * time.Second))
	if _, _, err := conn.ReadMessage(); err == nil {
		t.Fatal("dead client was never reaped")
	}
	if elapsed := time.Since(start); elapsed > 2500*time.Millisecond {
		t.Fatalf("reap took %s, too slow for a 250ms deadline", elapsed)
	}
}

func TestAliveClientSurvivesPingLoop(t *testing.T) {
	r, port := devEchoRelay(t)
	r.pongWait = 300 * time.Millisecond
	r.pingPeriod = 100 * time.Millisecond
	s := wsServer(t, r)
	conn, _, err := wsDial(t, s, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()

	// gorilla auto-pongs while reading; traffic + pings keep the session
	// alive well past a single pongWait window.
	deadline := time.Now().Add(1 * time.Second)
	sent := 0
	for time.Now().Before(deadline) {
		if err := conn.WriteMessage(websocket.BinaryMessage, []byte(fmt.Sprintf("k%d", sent))); err != nil {
			t.Fatal(err)
		}
		conn.SetReadDeadline(time.Now().Add(2 * time.Second))
		if _, got, err := conn.ReadMessage(); err != nil || string(got) != fmt.Sprintf("k%d", sent) {
			t.Fatalf("live session died at msg %d: %v (%q)", sent, err, got)
		}
		sent++
		time.Sleep(80 * time.Millisecond)
	}
	if sent < 5 {
		t.Fatalf("only %d round-trips in 1s — test timing collapsed", sent)
	}
}

type trackedConn struct {
	net.Conn
	closed int32
}

func (c *trackedConn) Close() error {
	atomic.StoreInt32(&c.closed, 1)
	return c.Conn.Close()
}

func TestWebsocketCopyCleanup(t *testing.T) {
	r, port := devEchoRelay(t)
	var tracked []*trackedConn
	baseDial := r.dialFunc
	r.dialFunc = func(ctx context.Context, network, addr string) (net.Conn, error) {
		conn, err := baseDial(ctx, network, addr)
		if err != nil {
			return nil, err
		}
		tc := &trackedConn{Conn: conn}
		tracked = append(tracked, tc)
		return tc, nil
	}
	s := wsServer(t, r)

	before := runtime.NumGoroutine()
	conn, _, err := wsDial(t, s, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err != nil {
		t.Fatal(err)
	}
	if err := conn.WriteMessage(websocket.BinaryMessage, []byte("x")); err != nil {
		t.Fatal(err)
	}
	conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, _, err := conn.ReadMessage(); err != nil {
		t.Fatal(err)
	}
	conn.Close()

	deadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(deadline) {
		clean := true
		for _, tc := range tracked {
			if atomic.LoadInt32(&tc.closed) != 1 {
				clean = false
			}
		}
		if clean && accountCount(r) == 0 && runtime.NumGoroutine() <= before+2 {
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	for i, tc := range tracked {
		if atomic.LoadInt32(&tc.closed) != 1 {
			t.Errorf("tracked conn %d not closed after client disconnect", i)
		}
	}
	if accountCount(r) != 0 {
		t.Errorf("per-account map not cleaned: %d entries", accountCount(r))
	}
	if n := runtime.NumGoroutine(); n > before+2 {
		t.Errorf("goroutines leaked: before=%d after=%d", before, n)
	}
}

func TestShutdownCancelsLiveSessions(t *testing.T) {
	r, port := devEchoRelay(t)
	base, cancel := context.WithCancel(context.Background())
	r.baseCtx = base
	s := wsServer(t, r)
	conn, _, err := wsDial(t, s, fmt.Sprintf("host=127.0.0.1&port=%d&token=good-token", port), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()

	cancel() // SIGTERM path
	conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, _, err := conn.ReadMessage(); err == nil {
		t.Fatal("live session survived base-context cancellation")
	}
}

func TestHealthzAndRouting(t *testing.T) {
	r := testRelay()
	s := httptest.NewServer(newHandler(r, nil))
	defer s.Close()

	oldVersion, oldCommit := version, commit
	version, commit = "v9.9.9-test", "abc1234"
	defer func() { version, commit = oldVersion, oldCommit }()

	res, err := http.Get(s.URL + "/healthz")
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("healthz status = %d", res.StatusCode)
	}
	if ct := res.Header.Get("Content-Type"); !strings.HasPrefix(ct, "application/json") {
		t.Fatalf("content-type = %q", ct)
	}
	var out map[string]string
	if err := json.NewDecoder(res.Body).Decode(&out); err != nil {
		t.Fatal(err)
	}
	for k, want := range map[string]string{
		"service": "pocketshell-gateway",
		"version": "v9.9.9-test",
		"commit":  "abc1234",
		"status":  "ok",
	} {
		if out[k] != want {
			t.Errorf("healthz[%s] = %q, want %q", k, out[k], want)
		}
	}
	if _, ok := out["token"]; ok {
		t.Error("healthz must not echo secrets")
	}

	// POST is not allowed.
	resPost, err := http.Post(s.URL+"/healthz", "text/plain", strings.NewReader("x"))
	if err != nil {
		t.Fatal(err)
	}
	resPost.Body.Close()
	if resPost.StatusCode != http.StatusMethodNotAllowed {
		t.Fatalf("POST healthz = %d, want 405", resPost.StatusCode)
	}

	// Everything except /healthz is the legacy relay: still 426 for plain
	// GETs, including lookalike paths.
	for _, path := range []string{"/", "/healthzzz", "/?host=example.com"} {
		resGet, err := http.Get(s.URL + path)
		if err != nil {
			t.Fatal(err)
		}
		resGet.Body.Close()
		if resGet.StatusCode != http.StatusUpgradeRequired {
			t.Fatalf("GET %s = %d, want 426 (relay owns all non-health paths)", path, resGet.StatusCode)
		}
	}
}
