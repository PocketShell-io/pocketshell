// Package security holds the independent security validation suite for the
// PocketShell gateway (branch astra-security-review).
//
// Scope: prove, with executable positive/negative integration tests, that the
// end-to-end SSH trust boundary of the public reverse tunnel holds when the
// gateway itself is untrusted (it holds valid routing credentials, controls
// routing frames, and can substitute endpoints), while shell access still
// requires an SSH key authorized on the local host.
//
// Everything here runs against disposable local labs only: ephemeral keys,
// loopback listeners, and local Docker containers. No public service is ever
// contacted by these tests.
//
// The lab implementations in security/sshlab are FIXTURES, not production
// code: they exist to (a) make every trust-boundary assertion observable
// before the production packages land, (b) pin the contract that
// internal/tunnel, internal/hostagent, internal/identity and
// cmd/pocketshell-link must satisfy — the same suites are re-run against the
// production sides once the coordinator signals the integrated commit. The
// final report (docs/security-review.md) distinguishes in-process reference
// results from Docker-executed and production-integrated results.
package security
