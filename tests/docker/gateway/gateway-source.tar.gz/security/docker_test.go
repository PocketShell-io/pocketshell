package security

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/security/dockerlab"
)

// Docker-executed assertion suite (mode "docker").
//
// Topology per test (disposable containers, unique names, full teardown):
//
//	gateway container  = the ADVERSARIAL fixture binary (secgw)
//	home container     = REAL OpenSSH sshd on 127.0.0.1 INSIDE the container
//	                     (no published host ports), secprobe sensitive
//	                     service, destination-pinned secagent
//	host               = the real ssh(1) client via secbridge ProxyCommand
//	                     with pinned host key (StrictHostKeyChecking=yes)
//
// These tests exercise ordinary OpenSSH at BOTH ends through the wire
// contract, not the Go SSH library.

const dockerSentinel = "POCKETSHELL_DOCKER_SENTINEL_OK"

func recordDockerResult(t *testing.T, id, detail string) {
	t.Helper()
	dir := filepath.Join("..", ".tmp", "security-logs")
	_ = os.MkdirAll(dir, 0o755)
	f, err := os.OpenFile(filepath.Join(dir, "results.jsonl"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	v := "PASS"
	if t.Failed() {
		v = "FAIL"
	}
	_, _ = fmt.Fprintf(f, "{\"id\":%q,\"test\":%q,\"mode\":\"docker\",\"verdict\":%q,\"detail\":%q}\n",
		id, t.Name(), v, detail)
}

// sshdLogLines counts sshd log lines inside the home container (used to
// observe whether traffic ever reached the real home sshd).
func sshdLogLines(t *testing.T, l *dockerlab.Lab) int {
	t.Helper()
	out, err := l.ExecHome("wc -l < /sshd.log 2>/dev/null")
	if err != nil {
		return -1
	}
	n, _ := strconv.Atoi(strings.TrimSpace(out))
	return n
}

// probeCount reads the sensitive-service connection count inside the home
// container (missing file = zero connections ever).
func probeCount(t *testing.T, l *dockerlab.Lab) string {
	t.Helper()
	out, err := l.ExecHome("cat /probe-count 2>/dev/null")
	if err != nil {
		return "" // file absent: no connections
	}
	return strings.TrimSpace(out)
}

// --- D1: positive control over real OpenSSH ----------------------------------

func TestD1PositiveControlRealOpenSSH(t *testing.T) {
	l := dockerlab.Start(t, "")
	start := time.Now()
	stdout, stderr, exit := l.RunSSH(t, "echo "+dockerSentinel)
	if exit != 0 {
		sshlog, _ := l.ExecHome("tail -20 /sshd.log")
		agentlog, _ := l.ExecHome("tail -5 /agent.log")
		t.Fatalf("real ssh failed (exit %d): stderr=%s\nsshd.log:\n%s\nagent.log:\n%s", exit, stderr, sshlog, agentlog)
	}
	if !strings.Contains(stdout, dockerSentinel) {
		t.Fatalf("sentinel missing: %q", stdout)
	}
	t.Logf("real OpenSSH client → real OpenSSH sshd via gateway container: %q in %s",
		strings.TrimSpace(stdout), time.Since(start).Round(time.Millisecond))
	recordDockerResult(t, "D1", "authorized key executed benign sentinel end-to-end (real ssh client, real sshd, container topology)")
}

// --- D2: host key substitution rejected by real ssh before userauth -----------

func TestD2HostKeySubstitutionRejectedRealOpenSSH(t *testing.T) {
	l := dockerlab.Start(t, "mitm")
	baseline := sshdLogLines(t, l)

	_, stderr, exit := l.RunSSH(t, "echo never")
	if exit == 0 {
		t.Fatal("real ssh succeeded through a host-key-substituting gateway")
	}
	if !strings.Contains(stderr, "Host key verification failed") {
		t.Fatalf("expected host key verification failure, stderr=%s", stderr)
	}
	after := sshdLogLines(t, l)
	if after != baseline {
		t.Fatalf("home sshd saw traffic during MITM (log %d -> %d lines)", baseline, after)
	}
	t.Logf("real ssh refused the gateway's substituted host key; home sshd log unchanged (%d lines); ssh exit=%d", baseline, exit)
	recordDockerResult(t, "D2", "real ssh aborted at host key verification before userauth; home sshd untouched")
}

// --- D3: unknown key rejected by real OpenSSH ---------------------------------

func TestD3UnknownSSHKeyRejectedRealOpenSSH(t *testing.T) {
	l := dockerlab.Start(t, "")
	wrong := filepath.Join(t.TempDir(), "wrong_key")
	runLocal(t, "ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", wrong)

	_, stderr, exit := l.RunSSHAs(t, wrong, "echo never")
	if exit == 0 {
		t.Fatal("unknown key gained shell access on the real home sshd")
	}
	if !strings.Contains(stderr, "Permission denied") {
		t.Fatalf("expected Permission denied, stderr=%s", stderr)
	}
	log, _ := l.ExecHome("grep -c 'Accepted' /sshd.log || true")
	if strings.TrimSpace(log) != "0" {
		t.Fatalf("unexpected accepted auths on home sshd: %s", log)
	}
	t.Logf("unknown key: real sshd denied access (exit %d, stderr=%s)", exit, strings.TrimSpace(stderr))
	recordDockerResult(t, "D3", "unknown key rejected by real OpenSSH; zero accepted auths")
}

// --- D4: password auth disabled on real OpenSSH --------------------------------

func TestD4PasswordAuthDisabledRealOpenSSH(t *testing.T) {
	l := dockerlab.Start(t, "")

	_, stderr, exit := l.RunSSH(t, "echo never",
		"-o", "PubkeyAuthentication=no",
		"-o", "PreferredAuthentications=password",
		"-o", "NumberOfPasswordPrompts=0",
	)
	if exit == 0 {
		t.Fatal("password path granted shell access")
	}
	if !strings.Contains(stderr, "Permission denied") {
		t.Fatalf("expected Permission denied, stderr=%s", stderr)
	}
	accepted, _ := l.ExecHome("grep -c 'Accepted' /sshd.log || true")
	if strings.TrimSpace(accepted) != "0" {
		t.Fatalf("password attempt produced accepted auths: %s", accepted)
	}
	t.Logf("password-only attempt denied by real sshd (exit %d): %s", exit, strings.TrimSpace(stderr))
	recordDockerResult(t, "D4", "password authentication disabled on the real home sshd; pubkey-only advertised")
}

// --- D5: destination pinning in the container topology --------------------------

func TestD5ArbitraryDestinationNotHonoredDocker(t *testing.T) {
	l := dockerlab.Start(t, "subst=127.0.0.1:9999")

	stdout, stderr, exit := l.RunSSH(t, "echo "+dockerSentinel)
	if exit != 0 || !strings.Contains(stdout, dockerSentinel) {
		t.Fatalf("stream must still land on the pinned loopback sshd (exit %d) stdout=%q stderr=%s", exit, stdout, stderr)
	}
	if c := probeCount(t, l); c != "" && c != "0" {
		t.Fatalf("sensitive local service got %s connections — destination pinning violated", c)
	}
	t.Logf("substituted destination ignored: sshd stream intact, probe connections=%q", probeCount(t, l))
	recordDockerResult(t, "D5", "attacker-chosen destination in OPEN ignored; agent dialed only 127.0.0.1:22; probe count 0")
}

// --- D6: gateway-held credentials cannot shell into the real home host ----------

func TestD6GatewayCredentialsNoShellRealOpenSSH(t *testing.T) {
	l := dockerlab.Start(t, "shell")

	// Keep an honest session alive so the gateway has a live agent leg, then
	// read the attacker outcome file the gateway wrote after its attempt.
	deadline := time.Now().Add(45 * time.Second)
	var result string
	polls := 0
	for time.Now().Before(deadline) {
		out, err := l.GWAttackerResult()
		if polls < 3 {
			t.Logf("attacker-result poll %d: out=%q err=%v", polls, out, err)
		}
		polls++
		if err == nil && out != "" {
			result = out
			break
		}
		time.Sleep(500 * time.Millisecond)
	}
	if result == "" {
		t.Fatal("gateway shell-attempt produced no result")
	}
	if strings.Contains(result, "SHELL-GRANTED") {
		t.Fatalf("CRITICAL: compromised gateway gained shell with its own credentials: %s", result)
	}
	if !strings.Contains(result, "rejected") {
		t.Fatalf("unexpected attacker outcome: %q", result)
	}
	accepted, _ := l.ExecHome("grep -c 'Accepted' /sshd.log || true")
	if strings.TrimSpace(accepted) != "0" {
		t.Fatalf("gateway attempt produced accepted auths on home sshd: %s", accepted)
	}
	t.Logf("gateway with valid relay/device credentials: own SSH key rejected by real sshd (%q)", result)
	recordDockerResult(t, "D6", "gateway-as-SSH-client with unauthorized key: rejected by real OpenSSH; zero accepted auths")
}

// runLocal runs a host command, failing the test on error.
func runLocal(t *testing.T, name string, args ...string) {
	t.Helper()
	out, err := exec.Command(name, args...).CombinedOutput()
	if err != nil {
		t.Fatalf("%v: %v\n%s", args, err, out)
	}
}
