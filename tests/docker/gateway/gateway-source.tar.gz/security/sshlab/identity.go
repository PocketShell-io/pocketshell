// Reference identity registry: durable-in-memory lab stand-in for
// internal/identity. It pins the contract the production package must
// satisfy:
//
//   - account identity is a verified issuer+subject principal (lab tokens are
//     HMAC-signed and expire; a token never grants another account's rights)
//   - device enrollment requires an account token AND a proof-of-possession
//     signature from the device key over a domain-separated transcript; an
//     existing device's key can never be silently replaced
//   - host-connection challenges are random, single-use, deadline-bounded and
//     bound to the connection they were issued on
//   - list/revoke are owner-only; revoke persists before observers are told
//   - every lookup path fails closed
package sshlab

import (
	"crypto/ed25519"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"sync"
	"time"
)

// Principal mirrors internal/identity's Principal.
type Principal struct {
	AccountID string
	Email     string
}

// Device mirrors internal/identity's Device.
type Device struct {
	ID         string
	AccountID  string
	PublicKey  ed25519.PublicKey
	SSHHostKey string
	Revoked    bool
}

const (
	// Transcript domains so an enrollment proof can never be replayed as a
	// connection challenge and vice versa.
	enrollDomain  = "pocketshell-enroll-v1"
	connectDomain = "pocketshell-connect-v1"

	challengeTTL = 30 * time.Second
	// tokenTTL bounds a lab account token; long enough for a full Docker
	// test run, short enough that expiry stays observable.
	tokenTTL = 30 * time.Minute
)

// ErrAuth is the single fail-closed error: no reason strings that could leak
// which check failed.
var ErrAuth = errors.New("auth failed")

// Registry is the lab identity service.
type Registry struct {
	mu      sync.Mutex
	secret  []byte
	devices map[string]*Device
	// challenges: nonce -> {deviceID, connID, issued}
	challenges map[string]challenge
	usedNonce  map[string]bool
	onRevoked  []func(deviceID string)
	now        func() time.Time
}

type challenge struct {
	deviceID string
	connID   string
	issued   time.Time
}

// NewRegistry creates a lab registry with a fresh HMAC secret.
func NewRegistry() *Registry {
	secret := make([]byte, 32)
	_, _ = rand.Read(secret)
	return &Registry{
		secret:     secret,
		devices:    map[string]*Device{},
		challenges: map[string]challenge{},
		usedNonce:  map[string]bool{},
		now:        time.Now,
	}
}

// --- lab account tokens (stand-in for verified Google JWTs) -----------------

type tokenClaims struct {
	AccountID string `json:"a"`
	Email     string `json:"e"`
	Exp       int64  `json:"x"`
}

// MintAccountToken issues a lab account token (issuer = lab, subject =
// accountID). Base64 so it survives JSON transport. Production replaces this
// with verified issuer+subject JWTs.
func (r *Registry) MintAccountToken(p Principal) string {
	c, _ := json.Marshal(tokenClaims{AccountID: p.AccountID, Email: p.Email, Exp: r.now().Add(tokenTTL).Unix()})
	body := append([]byte{1}, c...) // version byte
	mac := r.mac(body)
	return B64(append(body, mac...))
}

func (r *Registry) mac(body []byte) []byte {
	h := hmac.New(sha256.New, r.secret)
	h.Write(body)
	return h.Sum(nil)
}

// VerifyAccountToken verifies signature and expiry; fail closed.
func (r *Registry) VerifyAccountToken(tok string) (Principal, error) {
	raw, err := UnB64(tok)
	if err != nil || len(raw) < 1+1+32 {
		return Principal{}, ErrAuth
	}
	body := raw[:len(raw)-32]
	if body[0] != 1 || !hmac.Equal(r.mac(body), raw[len(raw)-32:]) {
		return Principal{}, ErrAuth
	}
	var c tokenClaims
	if err := json.Unmarshal(body[1:], &c); err != nil {
		return Principal{}, ErrAuth
	}
	if r.now().Unix() >= c.Exp {
		return Principal{}, ErrAuth
	}
	return Principal{AccountID: c.AccountID, Email: c.Email}, nil
}

// --- enrollment --------------------------------------------------------------

// EnrollProof is the signature over enrollTranscript(deviceID, accountID, pub).
func EnrollProof(k *DeviceKey, deviceID, accountID string) []byte {
	return ed25519.Sign(k.Priv, enrollTranscript(deviceID, accountID, k.Pub))
}

func enrollTranscript(deviceID, accountID string, pub ed25519.PublicKey) []byte {
	h := sha256.Sum256(append([]byte(fmt.Sprintf("%s|%s|%s|", enrollDomain, deviceID, accountID)), pub...))
	return h[:]
}

// Enroll registers a device for an account. proof must be a valid
// proof-of-possession by pub. If the device ID already exists, its key may
// only be replaced when oldProof is a valid signature by the CURRENTLY
// enrolled key (no silent replacement).
func (r *Registry) Enroll(tok, deviceID string, pub ed25519.PublicKey, proof, oldProof []byte) (*Device, error) {
	p, err := r.VerifyAccountToken(tok)
	if err != nil {
		return nil, ErrAuth
	}
	if p.AccountID == "" || deviceID == "" || len(pub) != ed25519.PublicKeySize {
		return nil, ErrAuth
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if existing, ok := r.devices[deviceID]; ok {
		if !ed25519.Verify(existing.PublicKey, enrollTranscript(deviceID, existing.AccountID, pub), oldProof) {
			return nil, ErrAuth // key replacement without current-key proof
		}
	}
	if !ed25519.Verify(pub, enrollTranscript(deviceID, p.AccountID, pub), proof) {
		return nil, ErrAuth
	}
	d := &Device{ID: deviceID, AccountID: p.AccountID, PublicKey: append([]byte(nil), pub...)}
	r.devices[deviceID] = d
	cp := *d
	return &cp, nil
}

// --- connection challenges ---------------------------------------------------

// NewChallenge issues a random single-use nonce bound to (deviceID, connID).
func (r *Registry) NewChallenge(deviceID, connID string) ([]byte, error) {
	nonce := make([]byte, 16)
	if _, err := rand.Read(nonce); err != nil {
		return nil, err
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, ok := r.devices[deviceID]; !ok {
		return nil, ErrAuth // unknown device: no challenge at all
	}
	r.challenges[B64(nonce)] = challenge{deviceID: deviceID, connID: connID, issued: r.now()}
	return nonce, nil
}

// ConnectProof signs the connect transcript (domain separation: protocol,
// role, device, nonce). The gateway↔connection binding itself is enforced
// structurally: the registry only accepts a nonce on the connection it was
// issued to, and burns it on first use.
func ConnectProof(k *DeviceKey, deviceID string, nonce []byte) []byte {
	return ed25519.Sign(k.Priv, connectTranscript(deviceID, nonce))
}

func connectTranscript(deviceID string, nonce []byte) []byte {
	raw := make([]byte, 4, 4+len(connectDomain)+len(deviceID)+len(nonce))
	binary.BigEndian.PutUint32(raw, uint32(len(nonce)))
	raw = append(raw, []byte(connectDomain+"|")...)
	raw = append(raw, []byte(deviceID+"|")...)
	raw = append(raw, nonce...)
	return raw
}

// VerifyChallenge checks a connection proof: signature by the enrolled key
// over the transcript of THE nonce issued on THIS connID, single use, within
// TTL, device not revoked. The nonce burns on first successful verify.
func (r *Registry) VerifyChallenge(gwID, connID, deviceID string, nonce, sig []byte) (*Device, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	_ = gwID // instance ID is lab bookkeeping; binding is via connID
	ch, ok := r.challenges[B64(nonce)]
	if !ok || ch.connID != connID || ch.deviceID != deviceID {
		return nil, ErrAuth // unknown, or replayed onto a different connection
	}
	delete(r.challenges, B64(nonce)) // single use, burn regardless of outcome
	if r.now().Sub(ch.issued) > challengeTTL {
		return nil, ErrAuth
	}
	d, ok := r.devices[deviceID]
	if !ok || d.Revoked {
		return nil, ErrAuth
	}
	if !ed25519.Verify(d.PublicKey, connectTranscript(deviceID, nonce), sig) {
		return nil, ErrAuth
	}
	cp := *d
	return &cp, nil
}

// --- owner-only operations ----------------------------------------------------

// ListDevices returns only the caller's own devices.
func (r *Registry) ListDevices(tok string) ([]Device, error) {
	p, err := r.VerifyAccountToken(tok)
	if err != nil {
		return nil, ErrAuth
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	var out []Device
	for _, d := range r.devices {
		if d.AccountID == p.AccountID {
			out = append(out, *d)
		}
	}
	return out, nil
}

// Revoke marks the device revoked (persisted first) and only then notifies
// observers, so a revoked device can never re-authenticate from a race.
func (r *Registry) Revoke(tok, deviceID string) error {
	p, err := r.VerifyAccountToken(tok)
	if err != nil {
		return ErrAuth
	}
	r.mu.Lock()
	d, ok := r.devices[deviceID]
	if !ok || d.AccountID != p.AccountID { // owner only
		r.mu.Unlock()
		return ErrAuth
	}
	d.Revoked = true
	notify := append([]func(string){}, r.onRevoked...)
	r.mu.Unlock()
	for _, f := range notify {
		f(deviceID)
	}
	return nil
}

// OnRevoked registers a disconnect callback.
func (r *Registry) OnRevoked(f func(deviceID string)) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.onRevoked = append(r.onRevoked, f)
}

// DeviceCount reports registered devices (test introspection).
func (r *Registry) DeviceCount() int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return len(r.devices)
}

// IsRevoked reports the device's revocation flag.
func (r *Registry) IsRevoked(deviceID string) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	d, ok := r.devices[deviceID]
	return ok && d.Revoked
}
