// Reference host agent — lab stand-in for internal/hostagent. It pins the
// security contract the production agent must satisfy:
//
//   - it dials OUT to the gateway (no inbound ports) and authenticates with
//     the enrolled device key over the single-use challenge;
//   - the ONLY local dial target is the configured loopback SSH endpoint.
//     There is no code path to any other destination, and any destination
//     field found inside an OPEN frame is counted and ignored;
//   - revoked devices tear everything down and never reconnect.
package sshlab

import (
	"context"
	"errors"
	"fmt"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gorilla/websocket"
)

// AgentConfig configures a lab host agent.
type AgentConfig struct {
	GatewayURL string // ws://127.0.0.1:port/host (insecure-dev lab transport)
	DeviceID   string
	DeviceKey  *DeviceKey
	PinnedSSH  string // loopback address of the home sshd — the only dial target
	// ChunkSize bounds the sshd→gateway relay read chunk; 0 = ChunkSize.
	ChunkSize int
}

// Agent is the running lab agent.
type Agent struct {
	cfg  AgentConfig
	ctx  context.Context
	done chan struct{}
	wg   sync.WaitGroup

	// observable state
	Authed          atomic.Bool
	Revoked         atomic.Bool
	StreamsServed   atomic.Int64
	DestSubstReject atomic.Int64 // OPEN frames carrying a destination: counted, then ignored
	ConnectErrors   atomic.Int64
	DbgToSSH        atomic.Int64
	DbgFromSSH      atomic.Int64
}

// StartAgent runs the agent until ctx is cancelled, the device is revoked,
// or (lab simplification) MaxReconnects consecutive dial failures happen.
func StartAgent(ctx context.Context, cfg AgentConfig) (*Agent, error) {
	host, _, err := net.SplitHostPort(cfg.PinnedSSH)
	if err != nil {
		return nil, fmt.Errorf("pinned ssh endpoint must be host:port: %w", err)
	}
	if !isLoopbackHost(host) {
		return nil, errors.New("agent refuses non-loopback pinned SSH endpoint (home SSH is loopback-only)")
	}
	a := &Agent{cfg: cfg, ctx: ctx, done: make(chan struct{})}
	a.wg.Add(1)
	go a.loop()
	return a, nil
}

func isLoopbackHost(h string) bool {
	if h == "localhost" {
		return true
	}
	ip := net.ParseIP(h)
	return ip != nil && ip.IsLoopback()
}

func (a *Agent) loop() {
	defer a.wg.Done()
	defer close(a.done)
	backoff := 100 * time.Millisecond
	for {
		if a.ctx.Err() != nil || a.Revoked.Load() {
			return
		}
		ok := a.connectOnce()
		if ok {
			backoff = 100 * time.Millisecond
		} else {
			a.ConnectErrors.Add(1)
		}
		if a.Revoked.Load() || a.ctx.Err() != nil {
			return
		}
		select {
		case <-time.After(backoff):
		case <-a.ctx.Done():
			return
		}
		if backoff < 2*time.Second {
			backoff *= 2
		}
	}
}

// connectOnce dials, authenticates, serves streams; returns true if it got
// authenticated at least once.
func (a *Agent) connectOnce() bool {
	d := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := d.DialContext(a.ctx, a.cfg.GatewayURL, nil)
	if err != nil {
		return false
	}
	defer ws.Close()
	ws.SetReadLimit(MaxFrameBytes)
	_ = ws.SetReadDeadline(time.Now().Add(AuthTimeout * time.Second))

	// HELLO → CHALLENGE → AUTH → AUTH_OK
	if err := ws.WriteMessage(websocket.BinaryMessage, append([]byte{FrameHello}, mustJSON(authJSON{DeviceID: a.cfg.DeviceID})...)); err != nil {
		return false
	}
	mt, data, err := ws.ReadMessage()
	if err != nil || mt != websocket.BinaryMessage || len(data) < 1 || data[0] != FrameChallenge {
		return false
	}
	var ch challengeJSON
	if jsonUnmarshal(data[1:], &ch) != nil {
		return false
	}
	nonce, err := UnB64(ch.Nonce)
	if err != nil {
		return false
	}
	// Domain-separated transcript: protocol, role, device, nonce — signed by
	// the enrolled device key. Connection binding is enforced by the
	// registry: the nonce is only valid on the connection it was issued to.
	sig := ConnectProof(a.cfg.DeviceKey, a.cfg.DeviceID, nonce)
	if err := ws.WriteMessage(websocket.BinaryMessage, append([]byte{FrameAuth}, mustJSON(proofJSON{Nonce: B64(nonce), Sig: B64(sig)})...)); err != nil {
		return false
	}
	mt, data, err = ws.ReadMessage()
	if err != nil || mt != websocket.BinaryMessage || len(data) < 1 || data[0] != FrameAuthOK {
		return false
	}
	a.Authed.Store(true)
	_ = ws.SetReadDeadline(time.Time{}) // authenticated: use per-op deadlines below

	sendQ := make(chan []byte, 64)
	agentClosed := make(chan struct{})
	var closeOnce sync.Once
	closeAgent := func() { closeOnce.Do(func() { close(agentClosed) }) }
	defer closeAgent()

	// writer pump (single concurrent writer, per gorilla/websocket)
	go func() {
		for {
			select {
			case b := <-sendQ:
				_ = ws.SetWriteDeadline(time.Now().Add(WriteTimeoutMillis * time.Millisecond))
				if err := ws.WriteMessage(websocket.BinaryMessage, b); err != nil {
					closeAgent()
					return
				}
			case <-agentClosed:
				return
			}
		}
	}()

	type tcpStream struct {
		conn net.Conn
	}
	streams := map[uint64]*tcpStream{}
	var streamsMu sync.Mutex
	closeStream := func(id uint64) {
		streamsMu.Lock()
		s := streams[id]
		delete(streams, id)
		streamsMu.Unlock()
		if s != nil {
			s.conn.Close()
		}
	}
	closeAllStreams := func() {
		streamsMu.Lock()
		all := make([]*tcpStream, 0, len(streams))
		for id, s := range streams {
			all = append(all, s)
			delete(streams, id)
		}
		streamsMu.Unlock()
		for _, s := range all {
			s.conn.Close()
		}
	}
	// ctx watcher: torn-down context must not leave sshd-side connections open
	go func() {
		select {
		case <-a.ctx.Done():
			closeAgent()
			closeAllStreams()
		case <-agentClosed:
			closeAllStreams()
		}
	}()
	sendFrame := func(typ byte, payload []byte) error {
		b := append([]byte{typ}, payload...)
		select {
		case sendQ <- b:
			return nil
		case <-agentClosed:
			return errors.New("closed")
		case <-time.After(WriteTimeoutMillis * time.Millisecond):
			return errors.New("send timeout")
		}
	}

	// read loop: control plane + data plane
	for {
		_ = ws.SetReadDeadline(time.Now().Add(90 * time.Second))
		mt, data, err := ws.ReadMessage()
		if err != nil {
			return a.Authed.Load() && !a.Revoked.Load()
		}
		if mt != websocket.BinaryMessage || len(data) < 1 {
			return true
		}
		switch data[0] {
		case FrameOpen:
			id, rest, err := readUvarint(data[1:])
			if err != nil {
				return true
			}
			if len(rest) > 0 {
				// A destination appeared inside the OPEN frame. The agent has
				// exactly one configured loopback target; this field is
				// counted and ignored — never dialed.
				a.DestSubstReject.Add(1)
			}
			streamsMu.Lock()
			if len(streams) >= MaxStreamsPerHost {
				streamsMu.Unlock()
				_ = sendFrame(FrameClose, appendUvarint([]byte{}, id))
				continue
			}
			streamsMu.Unlock()
			target, err := net.DialTimeout("tcp", a.cfg.PinnedSSH, 3*time.Second)
			if err != nil {
				_ = sendFrame(FrameClose, appendUvarint([]byte{}, id))
				continue
			}
			s := &tcpStream{conn: target}
			streamsMu.Lock()
			streams[id] = s
			streamsMu.Unlock()
			a.StreamsServed.Add(1)

			// sshd → agent → gateway
			chunk := a.cfg.ChunkSize
			if chunk == 0 {
				chunk = ChunkSize
			}
			go func(id uint64, c net.Conn) {
				buf := make([]byte, chunk)
				for {
					_ = c.SetReadDeadline(time.Now().Add(90 * time.Second))
					n, err := c.Read(buf)
					if n > 0 {
						a.DbgFromSSH.Add(int64(n))
						frame := appendUvarint([]byte{}, id)
						frame = append(frame, buf[:n]...)
						if sendFrame(FrameData, frame) != nil {
							return
						}
					}
					if err != nil {
						closeStream(id)
						_ = sendFrame(FrameClose, appendUvarint([]byte{}, id))
						return
					}
				}
			}(id, target)

		case FrameData:
			id, rest, err := readUvarint(data[1:])
			if err != nil {
				return true
			}
			streamsMu.Lock()
			s := streams[id]
			streamsMu.Unlock()
			if s == nil {
				continue // unknown or already-closed stream: drop
			}
			_ = s.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			a.DbgToSSH.Add(int64(len(rest)))
			if _, err := s.conn.Write(rest); err != nil {
				closeStream(id)
			}
		case FrameClose:
			id, _, err := readUvarint(data[1:])
			if err != nil {
				return true
			}
			closeStream(id)
		case FrameRevoke:
			a.Revoked.Store(true)
			streamsMu.Lock()
			for id := range streams {
				streams[id].conn.Close()
				delete(streams, id)
			}
			streamsMu.Unlock()
			closeAgent()
			return false
		default:
			return true // fail closed on unknown frame types
		}
	}
}

// WaitAuthed blocks until the agent authenticated to the gateway or timeout.
func (a *Agent) WaitAuthed(timeout time.Duration) bool {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if a.Authed.Load() {
			return true
		}
		time.Sleep(20 * time.Millisecond)
	}
	return a.Authed.Load()
}

// WaitRevoked blocks until the agent processed a revoke or timeout.
func (a *Agent) WaitRevoked(timeout time.Duration) bool {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if a.Revoked.Load() {
			return true
		}
		time.Sleep(20 * time.Millisecond)
	}
	return a.Revoked.Load()
}
