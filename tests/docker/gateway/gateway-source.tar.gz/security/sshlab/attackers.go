// Attacker capabilities exercised FROM the gateway position. These are the
// tests' concrete simulation of "the untrusted gateway uses its valid
// routing credentials to go after shell access or someone else's session".
package sshlab

import (
	"context"
	"encoding/json"
	"errors"
	"net"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"
)

func jsonUnmarshal(b []byte, v any) error { return json.Unmarshal(b, v) }

func mustJSONErr(v any) ([]byte, error) { return json.Marshal(v) }

// Capture returns the captured host-auth material (device, nonce, sig).
func (g *Gateway) Capture() (deviceID string, nonce, sig []byte, ok bool) {
	g.captured.mu.Lock()
	defer g.captured.mu.Unlock()
	return g.captured.deviceID, append([]byte(nil), g.captured.nonce...), append([]byte(nil), g.captured.sig...), g.captured.deviceID != ""
}

// WrongKeyAttempt impersonates the captured device but signs the fresh
// challenge with an attacker-held key. The suite asserts rejection.
func (g *Gateway) WrongKeyAttempt(ctx context.Context, deviceID string, k *DeviceKey) (string, error) {
	ws, err := WSDial(ctx, g.HostURL())
	if err != nil {
		return "", err
	}
	defer ws.Close()
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	if err := ws.WriteMessage(websocket.BinaryMessage, append([]byte{FrameHello}, mustJSON(authJSON{DeviceID: deviceID})...)); err != nil {
		return "", err
	}
	mt, data, err := ws.ReadMessage()
	if err != nil {
		return "closed", nil
	}
	if mt != websocket.BinaryMessage || len(data) < 1 || data[0] != FrameChallenge {
		return "no-challenge", nil
	}
	var ch challengeJSON
	if jsonUnmarshal(data[1:], &ch) != nil {
		return "", errors.New("bad challenge frame")
	}
	nonce, err := UnB64(ch.Nonce)
	if err != nil {
		return "", err
	}
	sig := ConnectProof(k, deviceID, nonce) // wrong key, fresh valid nonce
	proof, _ := mustJSONErr(proofJSON{Nonce: B64(nonce), Sig: B64(sig)})
	if err := ws.WriteMessage(websocket.BinaryMessage, append([]byte{FrameAuth}, proof...)); err != nil {
		return "", err
	}
	mt, data, err = ws.ReadMessage()
	if err != nil {
		return "closed", nil
	}
	if mt == websocket.BinaryMessage && len(data) > 0 && data[0] == FrameAuthOK {
		return "ok", nil
	}
	return "rejected", nil
}

// AttackerHostHandshake performs a full attacker host handshake against the
// gateway's own /host endpoint: HELLO(deviceID) → challenge → proof.
// nonceOverride replaces the fresh challenge with replayed material;
// sig is whatever the attacker sends. Returns the gateway verdict.
func (g *Gateway) AttackerHostHandshake(ctx context.Context, deviceID string, nonceOverride []byte, sig []byte) (verdict string, err error) {
	ws, err := WSDial(ctx, g.HostURL())
	if err != nil {
		return "", err
	}
	defer ws.Close()
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))

	if err := ws.WriteMessage(websocket.BinaryMessage, append([]byte{FrameHello}, mustJSON(authJSON{DeviceID: deviceID})...)); err != nil {
		return "", err
	}
	mt, data, err := ws.ReadMessage()
	if err != nil {
		return "", err
	}
	if mt != websocket.BinaryMessage || len(data) < 1 || data[0] != FrameChallenge {
		return "no-challenge", nil
	}
	var ch challengeJSON
	if jsonUnmarshal(data[1:], &ch) != nil {
		return "", errors.New("bad challenge frame")
	}
	nonce, err := UnB64(ch.Nonce)
	if err != nil {
		return "", err
	}
	if nonceOverride != nil {
		nonce = nonceOverride // replayed material
	}
	proof, err := mustJSONErr(proofJSON{Nonce: B64(nonce), Sig: B64(sig)})
	if err != nil {
		return "", err
	}
	if err := ws.WriteMessage(websocket.BinaryMessage, append([]byte{FrameAuth}, proof...)); err != nil {
		return "", err
	}
	mt, data, err = ws.ReadMessage()
	if err != nil {
		return "closed", nil // gateway dropped us: rejection by closure
	}
	if mt != websocket.BinaryMessage || len(data) < 1 {
		return "closed", nil
	}
	switch data[0] {
	case FrameAuthOK:
		return "ok", nil
	case FrameAuthErr:
		var e authErrJSON
		_ = jsonUnmarshal(data[1:], &e)
		return "rejected:" + e.Reason, nil
	default:
		return "unexpected-frame", nil
	}
}

// ShellAttempt is the compromised-gateway endgame: the gateway opens a
// multiplexed stream on a live host connection (it needs no client token —
// it IS the router) and speaks SSH to the real home host itself using
// clientKey, which is NOT authorized on the host. The suite asserts this
// can never yield a shell: the SSH server's userauth must reject it.
func (g *Gateway) ShellAttempt(ctx context.Context, clientKey ssh.Signer) (authErr error, err error) {
	g.mu.Lock()
	var hc *hostConn
	for _, h := range g.hosts {
		hc = h
		break
	}
	g.mu.Unlock()
	if hc == nil {
		return nil, errors.New("no live host conn")
	}
	id := randomStreamID()
	pipeA, pipeB := net.Pipe()
	rl := &rawLeg{id: id, in: make(chan []byte, StreamQueueChunks), closed: make(chan struct{}), peer: pipeB}
	hc.mu.Lock()
	hc.streams[id] = rl
	hc.mu.Unlock()
	defer func() {
		hc.dropStream(id, false)
		rl.close()
	}()

	// OPEN the stream on the agent leg (plain open, no destination field).
	if err := hc.sendFrame(FrameOpen, appendUvarint([]byte{}, id)); err != nil {
		return nil, err
	}

	// rl.in → pipeB (SSH server bytes arriving at the attacker)
	go func() {
		for {
			select {
			case b := <-rl.in:
				if _, err := pipeB.Write(b); err != nil {
					return
				}
			case <-rl.closed:
				return
			}
		}
	}()
	// pipeB → agent leg frames (attacker's SSH client bytes)
	go func() {
		buf := make([]byte, ChunkSize)
		for {
			n, err := pipeB.Read(buf)
			if n > 0 {
				frame := appendUvarint([]byte{}, id)
				frame = append(frame, buf[:n]...)
				_ = hc.sendFrame(FrameData, frame)
			}
			if err != nil {
				return
			}
		}
	}()

	cfg := &ssh.ClientConfig{
		User: "labuser",
		Auth: []ssh.AuthMethod{ssh.PublicKeys(clientKey)},
		// The attacker does not care about the host key; userauth must still
		// fail because the gateway's key is not authorized on the host.
		HostKeyCallback: ssh.InsecureIgnoreHostKey(),
		Timeout:         5 * time.Second,
	}
	conn, chans, reqs, err := ssh.NewClientConn(pipeA, hc.ws.RemoteAddr().String(), cfg)
	if err != nil {
		return err, nil // expected: userauth rejection from the real host sshd
	}
	// If we ever get here, close politely and report success — the test fails.
	_ = conn.Close()
	_ = chans
	_ = reqs
	return nil, nil
}

// rawLeg is a streamLeg whose peer is an in-process net.Pipe instead of a
// WebSocket client.
type rawLeg struct {
	id     uint64
	in     chan []byte
	closed chan struct{}
	close1 sync.Once
	peer   net.Conn
}

func (l *rawLeg) push(b []byte) bool {
	select {
	case l.in <- b:
		return true
	case <-l.closed:
		return false
	case <-time.After(SlowConsumerMillis * time.Millisecond):
		return false
	}
}

func (l *rawLeg) close() {
	l.close1.Do(func() {
		close(l.closed)
		if l.peer != nil {
			l.peer.Close()
		}
	})
}
