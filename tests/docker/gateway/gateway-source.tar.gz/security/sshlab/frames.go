// Host-leg frame protocol and bounds for the lab gateway⇄agent stream.
//
// This framing is FIXTURE-INTERNAL: the production wire contract is owned by
// internal/tunnel. The security property the tests need is the shape the
// design contract fixes: one persistent authenticated control+data stream,
// multiplexed opaque per-client streams with random IDs scoped to the
// connection epoch, bounded frames/queues, single-use challenge auth, and a
// revoke signal.
package sshlab

import (
	"encoding/binary"
	"errors"
)

// Frame types (first byte of every host-leg binary WebSocket message).
const (
	FrameHello     = 0x01 // agent→gw: JSON {device_id}
	FrameChallenge = 0x02 // gw→agent: JSON {nonce_b64}
	FrameAuth      = 0x03 // agent→gw: JSON {nonce_b64, sig_b64}
	FrameAuthOK    = 0x04 // gw→agent
	FrameAuthErr   = 0x05 // gw→agent: JSON {reason}
	FrameOpen      = 0x10 // gw→agent: uvarint streamID [, uvarint destLen + dest bytes — attack vector]
	FrameData      = 0x11 // both: uvarint streamID + opaque bytes
	FrameClose     = 0x12 // both: uvarint streamID
	FrameRevoke    = 0x20 // gw→agent: device revoked; close everything
)

// Bounds. Small on purpose: the negative tests must be able to trip them
// quickly on loopback.
const (
	// MaxFrameBytes is the largest accepted WebSocket message (bytes).
	MaxFrameBytes = 512 << 10
	// MaxStreamsPerHost bounds multiplexed streams per host connection.
	MaxStreamsPerHost = 32
	// StreamQueueChunks bounds bytes buffered per stream per direction as
	// chunks of ChunkSize before the sender is declared a slow consumer.
	StreamQueueChunks = 4
	ChunkSize         = 32 << 10
	// AuthTimeout bounds the unauthenticated window of any leg.
	AuthTimeout = 10
	// SlowConsumerMillis bounds how long a full stream queue may stall
	// before the stream (and its connection) is killed.
	SlowConsumerMillis = 2000
	// WriteTimeoutMillis bounds single WebSocket writes.
	WriteTimeoutMillis = 5000
)

var ErrFrameTooLarge = errors.New("frame exceeds maximum size")
var ErrTooManyStreams = errors.New("too many open streams")
var ErrSlowConsumer = errors.New("slow consumer")

func appendUvarint(b []byte, v uint64) []byte {
	return binary.AppendUvarint(b, v)
}

func readUvarint(b []byte) (uint64, []byte, error) {
	v, n := binary.Uvarint(b)
	if n <= 0 {
		return 0, nil, errors.New("bad uvarint")
	}
	return v, b[n:], nil
}
