// Lab SSH client: real golang.org/x/crypto/ssh handshake with an account
// token carried in the first WebSocket auth frame (never query params) and a
// PINNED host key. Host key verification happens during key exchange, i.e.
// strictly before any userauth material is sent — the suite asserts this
// ordering via the real sshd's auth counters.
package sshlab

import (
	"context"
	"encoding/json"
	"net"
	"net/url"
	"strings"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"
)

// ClientOpts configures a lab SSH-over-gateway client.
type ClientOpts struct {
	GatewayURL string        // ws://127.0.0.1:port/client
	Token      string        // lab account token
	ClientKey  ssh.Signer    // SSH user key
	PinnedHost ssh.PublicKey // pinned real host key (required in honest tests)
}

// RawDialWS dials the gateway over a raw TCP conn with a deliberately small
// receive buffer (slow-consumer tests must not rely on megabytes of loopback
// kernel buffering).
func RawDialWS(ctx context.Context, urlStr string, readBuf int) (*websocket.Conn, error) {
	u, err := url.Parse(urlStr)
	if err != nil {
		return nil, err
	}
	host := u.Host
	if _, _, err := net.SplitHostPort(host); err != nil {
		host = net.JoinHostPort(host, "80")
	}
	d := net.Dialer{Timeout: 5 * time.Second}
	conn, err := d.DialContext(ctx, "tcp", host)
	if err != nil {
		return nil, err
	}
	if tc, ok := conn.(*net.TCPConn); ok {
		_ = tc.SetReadBuffer(readBuf)
		_ = tc.SetWriteBuffer(64 * 1024)
	}
	wsConn, _, err := websocket.NewClient(conn, u, nil, 4096, 4096)
	return wsConn, err
}

// DialSSH connects through the gateway and completes a real SSH handshake.
func DialSSH(ctx context.Context, o ClientOpts) (*ssh.Client, error) {
	ws, err := WSDial(ctx, o.GatewayURL)
	if err != nil {
		return nil, err
	}
	n, _, err := WSAuth(ws, o.Token)
	if err != nil {
		return nil, err
	}
	return dialSSHOnConn(n, o)
}

// WSAuth sends the first-frame account token and returns the connection as a
// net.Conn ready for the SSH handshake, plus the raw underlying conn for
// liveness probes.
func WSAuth(ws *websocket.Conn, token string) (net.Conn, net.Conn, error) {
	c, err := wsToSSHConn(ws, ClientOpts{Token: token})
	if err != nil {
		return nil, nil, err
	}
	raw := c.(*WSNet).Raw()
	return c, raw, nil
}

// DialSSHConn is DialSSH over a caller-supplied transport (tests wrap it to
// simulate consumers that stop reading).
func DialSSHConn(ctx context.Context, o ClientOpts, transport net.Conn) (*ssh.Client, error) {
	return dialSSHOnConn(transport, o)
}

func dialSSHOnConn(n net.Conn, o ClientOpts) (*ssh.Client, error) {
	cfg := &ssh.ClientConfig{
		User:            "lab",
		Auth:            []ssh.AuthMethod{ssh.PublicKeys(o.ClientKey)},
		HostKeyCallback: ssh.FixedHostKey(o.PinnedHost),
		Timeout:         10 * time.Second,
	}
	c, chans, reqs, err := ssh.NewClientConn(n, o.GatewayURL, cfg)
	if err != nil {
		n.Close()
		return nil, err
	}
	return ssh.NewClient(c, chans, reqs), nil
}

func wsToSSHConn(ws *websocket.Conn, o ClientOpts) (net.Conn, error) {
	tok, err := json.Marshal(clientAuthJSON{Token: o.Token})
	if err != nil {
		ws.Close()
		return nil, err
	}
	if err := ws.WriteMessage(websocket.TextMessage, tok); err != nil {
		ws.Close()
		return nil, err
	}
	return NewWSNet(ws), nil
}

// HostKeyRejected reports whether err stems from the pinned-host-key
// verification (x/crypto wraps handshake errors without Unwrap, so match on
// the stable message text).
func HostKeyRejected(err error) bool {
	return err != nil && strings.Contains(err.Error(), "host key mismatch")
}
