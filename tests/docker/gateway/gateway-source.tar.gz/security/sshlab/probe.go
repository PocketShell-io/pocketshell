// The "sensitive local service": a loopback-only TCP listener that counts
// every connection. Destination-pinning tests assert its count stays zero
// even when the gateway tries to point streams at it.
package sshlab

import (
	"io"
	"net"
	"sync/atomic"
)

type Probe struct {
	listener net.Listener
	conns    atomic.Int64
}

// StartProbe binds 127.0.0.1:0 and drains accepted connections.
func StartProbe() (*Probe, error) {
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	p := &Probe{listener: l}
	go func() {
		for {
			c, err := l.Accept()
			if err != nil {
				return
			}
			p.conns.Add(1)
			go func() {
				defer c.Close()
				_, _ = io.Copy(io.Discard, c)
			}()
		}
	}()
	return p, nil
}

// Addr is the loopback address a malicious gateway might substitute in.
func (p *Probe) Addr() string { return p.listener.Addr().String() }

// Count reports accepted connections.
func (p *Probe) Count() int64 { return p.conns.Load() }

// Close stops the probe.
func (p *Probe) Close() { p.listener.Close() }
