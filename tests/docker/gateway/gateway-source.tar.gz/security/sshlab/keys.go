// Ephemeral lab key material. Nothing here is reused across test runs and
// nothing here is a real credential.
package sshlab

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"

	"golang.org/x/crypto/ssh"
)

// SSHKey is an ephemeral SSH key pair (used for host keys and client keys).
type SSHKey struct {
	Signer ssh.Signer
	Public ssh.PublicKey
}

// NewSSHKey generates a fresh Ed25519 SSH key.
func NewSSHKey() (*SSHKey, error) {
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	signer, err := ssh.NewSignerFromKey(priv)
	if err != nil {
		return nil, err
	}
	return &SSHKey{Signer: signer, Public: signer.PublicKey()}, nil
}

// Fingerprint is the SHA-256 authorized_keys-style fingerprint.
func (k *SSHKey) Fingerprint() string { return ssh.FingerprintSHA256(k.Public) }

// AuthorizedLine is the authorized_keys line for this public key.
func (k *SSHKey) AuthorizedLine() string {
	return string(ssh.MarshalAuthorizedKey(k.Public))
}

// DeviceKey is an ephemeral Ed25519 device identity key used to sign
// enrollment/connection challenge transcripts (proof of possession).
type DeviceKey struct {
	Priv ed25519.PrivateKey
	Pub  ed25519.PublicKey
}

// NewDeviceKey generates a fresh device identity key.
func NewDeviceKey() (*DeviceKey, error) {
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	return &DeviceKey{Priv: priv, Pub: pub}, nil
}

// Sign returns the detached signature over msg.
func (k *DeviceKey) Sign(msg []byte) []byte {
	return ed25519.Sign(k.Priv, msg)
}

// B64 helpers shared by transcript handling.
func B64(b []byte) string { return base64.RawStdEncoding.EncodeToString(b) }

func UnB64(s string) ([]byte, error) { return base64.RawStdEncoding.DecodeString(s) }
