// net.Conn over a single WebSocket connection, plus dial helpers. Used by
// the SSH client (transport over the gateway client leg), by the gateway's
// host-key MITM, and by the gateway's own shell attempt.
package sshlab

import (
	"context"
	"net"
	"time"

	"github.com/gorilla/websocket"
)

// WSNet adapts one WebSocket to net.Conn. Binary messages carry bytes; a
// TEXT message is treated as a fatal protocol error carrying its payload
// (the lab signals leg-level auth/routing failures that way before raw mode).
type WSNet struct {
	ws     *websocket.Conn
	rdBuf  []byte
	wrMu   chan struct{} // gorilla allows one concurrent writer
	closed chan struct{}
}

// NewWSNet wraps an upgraded WebSocket.
func NewWSNet(ws *websocket.Conn) *WSNet {
	return &WSNet{ws: ws, wrMu: make(chan struct{}, 1), closed: make(chan struct{})}
}

// WSDial dials a lab ws:// URL (loopback only — never a production endpoint).
func WSDial(ctx context.Context, url string) (*websocket.Conn, error) {
	d := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := d.DialContext(ctx, url, nil)
	return ws, err
}

func (n *WSNet) Read(b []byte) (int, error) {
	if len(n.rdBuf) == 0 {
		mt, data, err := n.ws.ReadMessage()
		if err != nil {
			return 0, err
		}
		if mt != websocket.BinaryMessage {
			n.ws.Close()
			close(n.closed)
			return 0, &protocolError{msg: string(data)}
		}
		n.rdBuf = data
	}
	c := copy(b, n.rdBuf)
	n.rdBuf = n.rdBuf[c:]
	return c, nil
}

type protocolError struct{ msg string }

func (e *protocolError) Error() string { return "lab protocol error: " + e.msg }

// ProtocolError reports whether err is the text-frame protocol error.
func ProtocolError(err error) (string, bool) {
	for e := err; e != nil; {
		if pe, ok := e.(*protocolError); ok {
			return pe.msg, true
		}
		u, ok := e.(interface{ Unwrap() error })
		if !ok {
			return "", false
		}
		e = u.Unwrap()
	}
	return "", false
}

func (n *WSNet) Write(b []byte) (int, error) {
	n.wrMu <- struct{}{}
	defer func() { <-n.wrMu }()
	_ = n.ws.SetWriteDeadline(time.Now().Add(WriteTimeoutMillis * time.Millisecond))
	if err := n.ws.WriteMessage(websocket.BinaryMessage, b); err != nil {
		return 0, err
	}
	return len(b), nil
}

func (n *WSNet) Close() error {
	select {
	case <-n.closed:
	default:
		close(n.closed)
	}
	return n.ws.Close()
}

func (n *WSNet) LocalAddr() net.Addr  { return n.ws.LocalAddr() }
func (n *WSNet) RemoteAddr() net.Addr { return n.ws.RemoteAddr() }

// Raw exposes the underlying transport for non-consuming liveness probes
// (zero-length reads). Tests use it to wait out a stalled consumer without
// draining bytes.
func (n *WSNet) Raw() net.Conn { return n.ws.UnderlyingConn() }

func (n *WSNet) SetDeadline(t time.Time) error {
	if err := n.SetReadDeadline(t); err != nil {
		return err
	}
	return n.ws.SetWriteDeadline(t)
}

func (n *WSNet) SetReadDeadline(t time.Time) error  { return n.ws.SetReadDeadline(t) }
func (n *WSNet) SetWriteDeadline(t time.Time) error { return n.ws.SetWriteDeadline(t) }
