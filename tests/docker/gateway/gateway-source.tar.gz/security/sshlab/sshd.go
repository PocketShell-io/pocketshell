// In-process lab SSH server (golang.org/x/crypto/ssh), public-key-only.
// This is the "home SSH endpoint" of every lab topology. It counts
// connections, userauth attempts and granted shells so tests can observe
// exactly how far an attacker got — e.g. a host-key rejection on the client
// must leave authAttempts untouched.
//
// Exec requests are restricted to the benign sentinel: argv[0] must be
// exactly "echo". Shell/pty/subsystem requests are denied.
package sshlab

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net"
	"os/exec"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/crypto/ssh"
)

// SSHDStats are observable counters for assertions.
type SSHDStats struct {
	Connections   int64
	AuthAttempts  int64
	AuthAccepted  int64
	ShellsGranted int64 // exec requests actually executed
	AuthDenied    int64
	ClosedConns   int64 // server-side connections that have finished
}

type Server struct {
	listener   net.Listener
	config     *ssh.ServerConfig
	authorized map[string]bool // fingerprints
	closed     chan struct{}

	totalConns   atomic.Int64
	authAttempts atomic.Int64
	authAccepted atomic.Int64
	authDenied   atomic.Int64
	shells       atomic.Int64
	closedConns  atomic.Int64
	wg           sync.WaitGroup

	lastHandshakeErrMu sync.Mutex
	lastHandshakeErr   string
}

// LastHandshakeErr returns the most recent server-side handshake error (lab
// diagnostics; production must not log pre-auth detail this verbosely).
func (s *Server) LastHandshakeErr() string {
	s.lastHandshakeErrMu.Lock()
	defer s.lastHandshakeErrMu.Unlock()
	return s.lastHandshakeErr
}

// StartSSHD binds 127.0.0.1:0 with the given host key and authorized client
// public keys. Only the "publickey" method is ever offered: password and
// keyboard-interactive callbacks are not registered at all.
func StartSSHD(hostKey ssh.Signer, authorized ...ssh.PublicKey) (*Server, error) {
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	s := &Server{
		listener:   l,
		authorized: map[string]bool{},
		closed:     make(chan struct{}),
	}
	for _, k := range authorized {
		s.authorized[string(k.Marshal())] = true
	}
	s.config = &ssh.ServerConfig{
		ServerVersion: "SSH-2.0-pocketshell-sshd-lab",
		PublicKeyCallback: func(conn ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			s.authAttempts.Add(1)
			if s.authorized[string(key.Marshal())] {
				s.authAccepted.Add(1)
				return &ssh.Permissions{Extensions: map[string]string{"fingerprint": ssh.FingerprintSHA256(key)}}, nil
			}
			s.authDenied.Add(1)
			return nil, fmt.Errorf("publickey rejected")
		},
		// Deliberately NO PasswordCallback / KeyboardInteractiveCallback:
		// the server never advertises password authentication.
	}
	s.config.AddHostKey(hostKey)
	s.wg.Add(1)
	go s.serve()
	return s, nil
}

// Addr is the loopback dial address pinned into the host agent config.
func (s *Server) Addr() string { return s.listener.Addr().String() }

// Stats returns a snapshot of the counters.
func (s *Server) Stats() SSHDStats {
	return SSHDStats{
		Connections:   s.totalConns.Load(),
		AuthAttempts:  s.authAttempts.Load(),
		AuthAccepted:  s.authAccepted.Load(),
		AuthDenied:    s.authDenied.Load(),
		ShellsGranted: s.shells.Load(),
		ClosedConns:   s.closedConns.Load(),
	}
}

func (s *Server) Close() {
	select {
	case <-s.closed:
		return
	default:
		close(s.closed)
	}
	s.listener.Close()
	s.wg.Wait()
}

func (s *Server) serve() {
	defer s.wg.Done()
	for {
		c, err := s.listener.Accept()
		if err != nil {
			return
		}
		s.totalConns.Add(1)
		s.wg.Add(1)
		go func() {
			defer s.wg.Done()
			s.handle(c)
		}()
	}
}

// loginGraceTime bounds the unauthenticated phase up to and including the
// SSH version exchange, mirroring real sshd's LoginGraceTime: garbage or
// silent pre-auth bytes (e.g. an admitted client leg forwarding junk that is
// NOT a valid SSH version line) must end in a server-side close, never an
// immortal connection.
const loginGraceTime = 5 * time.Second

func (s *Server) handle(c net.Conn) {
	defer func() {
		s.closedConns.Add(1)
		_ = c.Close()
	}()
	// Pre-auth bound: version exchange + KEX + userauth must all complete
	// within the grace window; the deadline is lifted once authenticated.
	_ = c.SetDeadline(time.Now().Add(loginGraceTime))
	sconn, chans, greqs, err := ssh.NewServerConn(c, s.config)
	if err != nil {
		s.lastHandshakeErrMu.Lock()
		s.lastHandshakeErr = err.Error()
		s.lastHandshakeErrMu.Unlock()
		return // includes pre-auth disconnects (host-key failures upstream)
	}
	_ = c.SetDeadline(time.Time{})
	defer sconn.Close()
	go func() {
		for req := range greqs {
			if req.WantReply {
				_ = req.Reply(false, nil)
			}
		}
	}()
	for newCh := range chans {
		if newCh.ChannelType() != "session" {
			newCh.Reject(ssh.UnknownChannelType, "sessions only")
			continue
		}
		ch, reqs, err := newCh.Accept()
		if err != nil {
			continue
		}
		s.wg.Add(1)
		go func() {
			defer s.wg.Done()
			s.session(ch, reqs)
		}()
	}
}

func (s *Server) session(ch ssh.Channel, reqs <-chan *ssh.Request) {
	defer ch.Close()
	for req := range reqs {
		switch req.Type {
		case "exec":
			var p struct{ Command string }
			if ssh.Unmarshal(req.Payload, &p) != nil {
				req.Reply(false, nil)
				return
			}
			path, args, ok := s.sentinelArgv(p.Command)
			if !ok {
				req.Reply(false, nil)
				fmt.Fprintf(ch.Stderr(), "only benign echo/seq commands are allowed in this lab\r\n")
				sendExit(ch, 111)
				return
			}
			s.shells.Add(1)
			req.Reply(true, nil)
			status := s.execStreaming(ch, path, args)
			sendExit(ch, status)
			return
		case "shell", "pty-req", "pty", "subsystem", "env":
			req.Reply(false, nil)
			if req.Type == "shell" {
				fmt.Fprintf(ch.Stderr(), "interactive shells are disabled in this lab\r\n")
				sendExit(ch, 111)
				return
			}
		default:
			if req.WantReply {
				req.Reply(false, nil)
			}
		}
	}
}

// sentinelArgv validates the lab exec allowlist and returns the real binary
// to run — real command execution through real SSH framing:
//   - `echo ...`  — the sentinel used by every positive control
//   - `seq a b c` — numeric-args-only deterministic output generator used
//     solely to drive the slow-consumer test beyond client window buffers
func (s *Server) sentinelArgv(cmd string) (path string, args []string, ok bool) {
	argv, err := splitSimple(cmd)
	if err != nil || len(argv) == 0 {
		return "", nil, false
	}
	switch argv[0] {
	case "echo":
		return "/bin/echo", argv[1:], true
	case "seq":
		if (len(argv) != 3 && len(argv) != 4) || !allNumeric(argv[1:]) {
			return "", nil, false
		}
		return "/usr/bin/seq", argv[1:], true
	default:
		return "", nil, false
	}
}

// execStreaming runs the allowlisted binary and streams its stdout through
// the SSH channel as it is produced (respecting flow control), then waits.
func (s *Server) execStreaming(ch ssh.Channel, path string, args []string) int {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	cmdProc := exec.CommandContext(ctx, path, args...)
	stdout, err := cmdProc.StdoutPipe()
	if err != nil {
		return 126
	}
	cmdProc.Stderr = io.Discard
	if err := cmdProc.Start(); err != nil {
		return 126
	}
	buf := make([]byte, 32<<10)
	for {
		n, rerr := stdout.Read(buf)
		if n > 0 {
			if _, werr := ch.Write(buf[:n]); werr != nil {
				_ = cmdProc.Process.Kill()
				_ = cmdProc.Wait()
				return 0
			}
		}
		if rerr != nil {
			break
		}
	}
	ee := cmdProc.Wait()
	var exitErr *exec.ExitError
	if errors.As(ee, &exitErr) {
		return exitErr.ExitCode()
	}
	return 0
}

func allNumeric(args []string) bool {
	for _, a := range args {
		if a == "" {
			return false
		}
		for _, c := range a {
			if c < '0' || c > '9' {
				return false
			}
		}
	}
	return true
}

func sendExit(ch ssh.Channel, status int) {
	type exit struct{ N uint32 }
	_, _ = ch.SendRequest("exit-status", false, ssh.Marshal(exit{uint32(status)}))
}
