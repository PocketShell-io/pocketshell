// Small helpers shared across the lab.
package sshlab

import (
	"errors"
	"strings"
)

// splitSimple splits a command line on whitespace, honouring double quotes —
// enough for benign sentinel commands in tests, nothing more.
func splitSimple(cmd string) ([]string, error) {
	var argv []string
	var cur strings.Builder
	inQ := false
	for _, r := range cmd {
		switch {
		case r == '"':
			inQ = !inQ
		case r == ' ' && !inQ:
			if cur.Len() > 0 {
				argv = append(argv, cur.String())
				cur.Reset()
			}
		default:
			cur.WriteRune(r)
		}
	}
	if cur.Len() > 0 {
		argv = append(argv, cur.String())
	}
	if inQ {
		return nil, errors.New("unterminated quote")
	}
	return argv, nil
}
