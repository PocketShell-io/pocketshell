// The adversarial gateway fixture — the "untrusted gateway" of the threat
// model. It is a real WebSocket relay with valid routing credentials of its
// own and it can act maliciously: terminate and re-key the client SSH leg
// (host-key substitution), rewrite OPEN frames with an arbitrary local
// destination, route a client to another account's host connection, capture
// and replay device proofs, and hold relay/device credentials to attempt
// shell access itself. Every attack is a toggle; the honest paths implement
// the fail-closed routing contract (ownership checks, auth timeouts, frame
// and queue bounds, slow-consumer kill).
//
// This file is FIXTURE code: production replaces it with internal/tunnel.
// The point of the suite is that the trust boundary holds EVEN AGAINST this
// component when every attack toggle is on.
package sshlab

import (
	"context"
	"crypto/rand"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"
)

// AttackMode toggles the adversarial behaviors of the fixture.
type AttackMode struct {
	// HostKeyMITM terminates the client SSH leg on the gateway with its own
	// host key (full man-in-the-middle position).
	HostKeyMITM bool
	// SubstituteDest, when non-empty, is appended to every OPEN frame as a
	// "destination" the agent must refuse to honor.
	SubstituteDest string
	// CrossConnect routes a client to ANY live host connection instead of
	// only the client's own account.
	CrossConnect bool
	// CaptureProof records the first successful host auth material so tests
	// can drive replay attempts.
	CaptureProof bool
}

type authJSON struct {
	DeviceID string `json:"device_id"`
}
type challengeJSON struct {
	Nonce string `json:"nonce_b64"`
}
type proofJSON struct {
	Nonce string `json:"nonce_b64"`
	Sig   string `json:"sig_b64"`
}
type authErrJSON struct {
	Reason string `json:"reason"`
}
type clientAuthJSON struct {
	Token string `json:"token"`
}
type textErr struct {
	Error string `json:"error"`
}

// streamLeg is one multiplexed stream as the gateway sees it.
type streamLeg interface {
	push([]byte) bool // agent→leg bytes; false = slow consumer
	close()
}

// Options holds the runtime bounds of a gateway fixture instance. Zero
// fields fall back to the package constants.
type Options struct {
	MaxFrame    int // WebSocket read limit, bytes
	QueueChunks int // per-stream queued chunks before slow-consumer kill
	ChunkSize   int // chunk bytes
	SlowMillis  int // how long a full queue may stall before the kill
	MaxStreams  int // streams per host connection
}

// DefaultOptions mirrors the package constants.
func DefaultOptions() Options {
	return Options{
		MaxFrame:    MaxFrameBytes,
		QueueChunks: StreamQueueChunks,
		ChunkSize:   ChunkSize,
		SlowMillis:  SlowConsumerMillis,
		MaxStreams:  MaxStreamsPerHost,
	}
}

// Gateway is the lab (adversarial) gateway.
type Gateway struct {
	reg     *Registry
	gwID    string
	attacks AttackMode
	opts    Options

	listener net.Listener
	httpSrv  *http.Server
	upgrader websocket.Upgrader

	mu    sync.Mutex
	hosts map[string]*hostConn // deviceID -> live host conn

	mitmKey ssh.Signer

	captured struct {
		mu       sync.Mutex
		deviceID string
		nonce    []byte
		sig      []byte
	}

	// observable counters
	ClientsAuthed     atomic.Int64
	ClientsRejected   atomic.Int64
	HostAuths         atomic.Int64
	HostRejected      atomic.Int64
	StreamsOpened     atomic.Int64
	StreamsRejected   atomic.Int64
	SlowKills         atomic.Int64
	FramesDropped     atomic.Int64
	MitmConns         atomic.Int64
	MitmAuthAttempts  atomic.Int64
	RoutingErrorsSent atomic.Int64
	DbgClientToHost   atomic.Int64
	DbgHostToClient   atomic.Int64
}

type hostConn struct {
	gw      *Gateway
	dev     Device
	ws      *websocket.Conn
	sendQ   chan []byte // frames toward the agent, bounded
	streams map[uint64]streamLeg
	mu      sync.Mutex
	connID  string
	closed  chan struct{}
	close1  sync.Once
}

// clientLeg is one client WebSocket attached to a stream.
type clientLeg struct {
	id     uint64
	p      Principal
	ws     *websocket.Conn
	gw     *Gateway
	outQ   chan []byte  // agent→client frames, bounded entries
	queued atomic.Int64 // bytes currently queued toward the client
	closed chan struct{}
	close1 sync.Once
}

// maxQueueBytes is the outbound buffer bound per stream.
func (g *Gateway) maxQueueBytes() int64 {
	return int64(g.opts.QueueChunks * g.opts.ChunkSize)
}

// push enqueues agent→client bytes; admits a frame into an empty queue
// regardless of size (so healthy streams never stall on one big frame), then
// bounds the backlog by bytes. Returns false = slow consumer.
func (leg *clientLeg) push(b []byte) bool {
	limit := leg.gw.maxQueueBytes()
	deadline := time.Now().Add(time.Duration(leg.gw.opts.SlowMillis) * time.Millisecond)
	for {
		if leg.closedClosed() {
			return false
		}
		cur := leg.queued.Load()
		if cur == 0 || cur+int64(len(b)) <= limit {
			if leg.queued.CompareAndSwap(cur, cur+int64(len(b))) {
				select {
				case leg.outQ <- b:
					return true
				case <-leg.closed:
					return false
				case <-time.After(time.Duration(leg.gw.opts.SlowMillis) * time.Millisecond):
					return false
				}
			}
			continue
		}
		if time.Now().After(deadline) {
			return false
		}
		time.Sleep(5 * time.Millisecond)
	}
}

func (leg *clientLeg) closedClosed() bool {
	select {
	case <-leg.closed:
		return true
	default:
		return false
	}
}

// NewGateway starts the fixture on 127.0.0.1:<ephemeral> with default bounds.
func NewGateway(reg *Registry, attacks AttackMode) (*Gateway, error) {
	return NewGatewayWithOptions(reg, attacks, Options{})
}

// NewGatewayOnMux builds the fixture without a listener, registering its
// legs on a caller-owned mux (the Docker lab shares one port with lab-admin
// endpoints).
func NewGatewayOnMux(reg *Registry, attacks AttackMode, mux *http.ServeMux) (*Gateway, error) {
	g, err := newGateway(reg, attacks, Options{}, nil)
	if err != nil {
		return nil, err
	}
	g.RegisterOn(mux)
	reg.OnRevoked(g.onRevoked)
	return g, nil
}

// NewGatewayWithOptions starts the fixture with explicit bounds (tests use
// smaller bounds so the slow-consumer kill is observable in milliseconds).
func NewGatewayWithOptions(reg *Registry, attacks AttackMode, opts Options) (*Gateway, error) {
	if opts.MaxFrame == 0 {
		opts = DefaultOptions()
	}
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	g, err := newGateway(reg, attacks, opts, l)
	if err != nil {
		return nil, err
	}
	mux := http.NewServeMux()
	g.RegisterOn(mux)
	g.httpSrv = &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	go func() {
		_ = g.httpSrv.Serve(l)
	}()
	reg.OnRevoked(g.onRevoked)
	return g, nil
}

func newGateway(reg *Registry, attacks AttackMode, opts Options, l net.Listener) (*Gateway, error) {
	if opts.MaxFrame == 0 {
		opts = DefaultOptions()
	}
	g := &Gateway{
		reg:      reg,
		gwID:     randomHex(8),
		attacks:  attacks,
		opts:     opts,
		listener: l,
		hosts:    map[string]*hostConn{},
		upgrader: websocket.Upgrader{ReadBufferSize: 4096, WriteBufferSize: 4096},
	}
	if attacks.HostKeyMITM {
		k, err := NewSSHKey()
		if err != nil {
			return nil, err
		}
		g.mitmKey = k.Signer
	}
	return g, nil
}

// RegisterOn mounts the /host and /client legs on an external mux (the
// Docker lab serves lab-admin endpoints on the same port).
func (g *Gateway) RegisterOn(mux *http.ServeMux) {
	mux.HandleFunc("/host", g.serveHost)
	mux.HandleFunc("/client", g.serveClient)
}

// HostURL is the ws:// URL host agents dial (loopback in the lab).
func (g *Gateway) HostURL() string { return "ws://" + g.listener.Addr().String() + "/host" }

// ClientURL is the ws:// URL SSH clients dial.
func (g *Gateway) ClientURL() string { return "ws://" + g.listener.Addr().String() + "/client" }

// Close shuts the gateway down and closes all live connections.
func (g *Gateway) Close() {
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	_ = g.httpSrv.Shutdown(ctx)
	g.mu.Lock()
	hc := make([]*hostConn, 0, len(g.hosts))
	for _, h := range g.hosts {
		hc = append(hc, h)
	}
	g.mu.Unlock()
	for _, h := range hc {
		h.close()
	}
}

// HostConnCount reports live authenticated host connections.
func (g *Gateway) HostConnCount() int {
	g.mu.Lock()
	defer g.mu.Unlock()
	return len(g.hosts)
}

func randomHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return fmt.Sprintf("%x", b)
}

func randomStreamID() uint64 {
	var b [8]byte
	_, _ = rand.Read(b[:])
	return binary.BigEndian.Uint64(b[:]) >> 1
}

// --- host leg ---------------------------------------------------------------

func (g *Gateway) serveHost(w http.ResponseWriter, r *http.Request) {
	ws, err := g.upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	ws.SetReadLimit(int64(g.opts.MaxFrame))
	_ = ws.SetReadDeadline(time.Now().Add(AuthTimeout * time.Second))

	hc := &hostConn{
		gw:      g,
		ws:      ws,
		sendQ:   make(chan []byte, 64),
		streams: map[uint64]streamLeg{},
		connID:  randomHex(8),
		closed:  make(chan struct{}),
	}
	defer hc.close()

	if err := g.hostHello(hc); err != nil {
		g.HostRejected.Add(1)
		_ = hc.sendFrameRaw(FrameAuthErr, mustJSON(authErrJSON{Reason: "auth failed"}))
		ws.Close()
		return
	}

	go hc.writePump()
	hc.readPump()
}

func (g *Gateway) hostHello(hc *hostConn) error {
	ws := hc.ws
	mt, data, err := ws.ReadMessage()
	if err != nil {
		return err
	}
	if mt != websocket.BinaryMessage || len(data) < 1 || data[0] != FrameHello {
		return errors.New("expected hello")
	}
	var hello authJSON
	if json.Unmarshal(data[1:], &hello) != nil || hello.DeviceID == "" {
		return errors.New("bad hello")
	}
	nonce, err := g.reg.NewChallenge(hello.DeviceID, hc.connID)
	if err != nil {
		return fmt.Errorf("no challenge: %w", err)
	}
	if err := hc.sendFrameRaw(FrameChallenge, mustJSON(challengeJSON{Nonce: B64(nonce)})); err != nil {
		return err
	}
	mt, data, err = ws.ReadMessage()
	if err != nil {
		return err
	}
	if mt != websocket.BinaryMessage || len(data) < 1 || data[0] != FrameAuth {
		return errors.New("expected proof")
	}
	var proof proofJSON
	if json.Unmarshal(data[1:], &proof) != nil {
		return errors.New("bad proof")
	}
	nonceIn, err := UnB64(proof.Nonce)
	if err != nil {
		return errors.New("bad nonce")
	}
	sig, err := UnB64(proof.Sig)
	if err != nil {
		return errors.New("bad sig")
	}
	dev, err := g.reg.VerifyChallenge(g.gwID, hc.connID, hello.DeviceID, nonceIn, sig)
	if err != nil {
		return err
	}
	if g.attacks.CaptureProof {
		g.captured.mu.Lock()
		g.captured.deviceID, g.captured.nonce, g.captured.sig = hello.DeviceID, nonceIn, sig
		g.captured.mu.Unlock()
	}
	hc.dev = *dev
	g.mu.Lock()
	g.hosts[dev.ID] = hc
	g.mu.Unlock()
	g.HostAuths.Add(1)
	return hc.sendFrameRaw(FrameAuthOK, nil)
}

// sendFrame queues a frame for the agent-bound writer pump.
func (hc *hostConn) sendFrame(typ byte, payload []byte) error {
	b := append([]byte{typ}, payload...)
	select {
	case hc.sendQ <- b:
		return nil
	case <-hc.closed:
		return errors.New("host conn closed")
	case <-time.After(WriteTimeoutMillis * time.Millisecond):
		return errors.New("send timeout")
	}
}

// sendFrameRaw writes directly to the wire (used before the writer pump is
// running and for out-of-band signals).
func (hc *hostConn) sendFrameRaw(typ byte, payload []byte) error {
	_ = hc.ws.SetWriteDeadline(time.Now().Add(WriteTimeoutMillis * time.Millisecond))
	return hc.ws.WriteMessage(websocket.BinaryMessage, append([]byte{typ}, payload...))
}

func (hc *hostConn) writePump() {
	for {
		select {
		case b := <-hc.sendQ:
			if hc.sendFrameRaw(b[0], b[1:]) != nil {
				hc.close()
				return
			}
		case <-hc.closed:
			return
		}
	}
}

// readPump dispatches agent→gateway frames. Malformed input fails the
// connection closed; a slow consumer only kills its own stream.
func (hc *hostConn) readPump() {
	defer hc.close()
	for {
		_ = hc.ws.SetReadDeadline(time.Now().Add(90 * time.Second))
		mt, data, err := hc.ws.ReadMessage()
		if err != nil {
			return
		}
		if mt != websocket.BinaryMessage || len(data) < 1 {
			return
		}
		switch data[0] {
		case FrameData:
			id, rest, err := readUvarint(data[1:])
			if err != nil {
				return
			}
			hc.mu.Lock()
			leg := hc.streams[id]
			hc.mu.Unlock()
			if leg == nil {
				hc.gw.FramesDropped.Add(1)
				continue
			}
			hc.gw.DbgHostToClient.Add(int64(len(rest)))
			if !leg.push(rest) {
				hc.gw.SlowKills.Add(1)
				hc.dropStream(id, true)
				continue
			}
		case FrameClose:
			id, _, err := readUvarint(data[1:])
			if err != nil {
				return
			}
			hc.dropStream(id, false)
		default:
			hc.gw.FramesDropped.Add(1)
			return
		}
	}
}

// dropStream forgets a stream, notifies the agent, and tears the leg down.
func (hc *hostConn) dropStream(id uint64, notifyAgent bool) {
	hc.mu.Lock()
	leg := hc.streams[id]
	delete(hc.streams, id)
	hc.mu.Unlock()
	if leg != nil {
		if notifyAgent {
			frame := appendUvarint([]byte{}, id)
			_ = hc.sendFrame(FrameClose, frame)
		}
		leg.close()
	}
}

func (hc *hostConn) close() {
	hc.close1.Do(func() {
		close(hc.closed)
		hc.gw.mu.Lock()
		if hc.gw.hosts[hc.dev.ID] == hc {
			delete(hc.gw.hosts, hc.dev.ID)
		}
		hc.gw.mu.Unlock()
		hc.mu.Lock()
		legs := make([]streamLeg, 0, len(hc.streams))
		for _, l := range hc.streams {
			legs = append(legs, l)
		}
		hc.streams = map[uint64]streamLeg{}
		hc.mu.Unlock()
		for _, l := range legs {
			l.close()
		}
		hc.ws.Close()
	})
}

func (g *Gateway) onRevoked(deviceID string) {
	g.mu.Lock()
	hc := g.hosts[deviceID]
	g.mu.Unlock()
	if hc == nil {
		return
	}
	_ = hc.sendFrame(FrameRevoke, nil)
	go func() {
		time.Sleep(200 * time.Millisecond) // let the frame flush
		hc.close()
	}()
}

// --- client leg ---------------------------------------------------------------

func (g *Gateway) serveClient(w http.ResponseWriter, r *http.Request) {
	ws, err := g.upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	ws.SetReadLimit(int64(g.opts.MaxFrame))
	_ = ws.SetReadDeadline(time.Now().Add(AuthTimeout * time.Second))

	// First frame: account token. Never query params.
	mt, data, err := ws.ReadMessage()
	if err != nil {
		ws.Close()
		return
	}
	var auth clientAuthJSON
	if mt != websocket.TextMessage || json.Unmarshal(data, &auth) != nil {
		g.ClientsRejected.Add(1)
		_ = ws.WriteMessage(websocket.TextMessage, mustJSON(textErr{Error: "unauthorized"}))
		ws.Close()
		return
	}
	p, err := g.reg.VerifyAccountToken(auth.Token)
	if err != nil {
		g.ClientsRejected.Add(1)
		_ = ws.WriteMessage(websocket.TextMessage, mustJSON(textErr{Error: "unauthorized"}))
		ws.Close()
		return
	}
	g.ClientsAuthed.Add(1)

	if g.attacks.HostKeyMITM {
		g.runMitm(ws)
		return
	}
	g.routeStream(p, ws)
}

// runMitm terminates SSH on the gateway with its own host key and rejects
// every authentication. A client with a correctly pinned host key never gets
// past key exchange.
func (g *Gateway) runMitm(ws *websocket.Conn) {
	g.MitmConns.Add(1)
	cfg := &ssh.ServerConfig{
		ServerVersion: "SSH-2.0-gateway-mitm",
		PublicKeyCallback: func(conn ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			g.MitmAuthAttempts.Add(1)
			return nil, errors.New("gateway mitm accepts nothing")
		},
	}
	cfg.AddHostKey(g.mitmKey) // the substitution the client must refuse
	n := NewWSNet(ws)
	_, chans, reqs, err := ssh.NewServerConn(n, cfg)
	if err != nil {
		return // client refused our host key before userauth — the expected case
	}
	defer n.Close()
	go func() {
		for req := range reqs {
			if req.WantReply {
				_ = req.Reply(false, nil)
			}
		}
	}()
	for ch := range chans {
		_ = ch.Reject(ssh.UnknownChannelType, "mitm")
	}
}

// routeStream picks a host connection and opens a multiplexed stream.
func (g *Gateway) routeStream(p Principal, ws *websocket.Conn) {
	g.mu.Lock()
	var hc *hostConn
	for _, h := range g.hosts {
		if h.dev.AccountID == p.AccountID {
			hc = h
			break
		}
	}
	if hc == nil && g.attacks.CrossConnect {
		for _, h := range g.hosts {
			hc = h
			break
		}
	}
	g.mu.Unlock()
	if hc == nil {
		g.RoutingErrorsSent.Add(1)
		g.ClientsRejected.Add(1)
		_ = ws.WriteMessage(websocket.TextMessage, mustJSON(textErr{Error: "no host online for this account"}))
		ws.Close()
		return
	}

	leg := &clientLeg{
		id:     randomStreamID(),
		p:      p,
		ws:     ws,
		gw:     g,
		outQ:   make(chan []byte, g.opts.QueueChunks),
		closed: make(chan struct{}),
	}
	// Lab tuning: loopback kernel buffers (~MBs) would absorb the entire SSH
	// flow-control window before the outbound queue bound ever trips. Shrink
	// the leg's send buffer so a stalled consumer blocks the writer like it
	// would across a real network.
	if tc, ok := ws.UnderlyingConn().(*net.TCPConn); ok {
		_ = tc.SetWriteBuffer(8 * 1024)
		_ = tc.SetReadBuffer(8 * 1024)
	}
	hc.mu.Lock()
	if len(hc.streams) >= g.opts.MaxStreams {
		hc.mu.Unlock()
		g.StreamsRejected.Add(1)
		_ = ws.WriteMessage(websocket.TextMessage, mustJSON(textErr{Error: "too many streams"}))
		ws.Close()
		return
	}
	hc.streams[leg.id] = leg
	hc.mu.Unlock()
	g.StreamsOpened.Add(1)

	payload := appendUvarint([]byte{}, leg.id)
	if g.attacks.SubstituteDest != "" {
		payload = appendUvarint(payload, uint64(len(g.attacks.SubstituteDest)))
		payload = append(payload, g.attacks.SubstituteDest...)
	}
	if err := hc.sendFrame(FrameOpen, payload); err != nil {
		hc.dropStream(leg.id, false)
		_ = ws.WriteMessage(websocket.TextMessage, mustJSON(textErr{Error: "host unavailable"}))
		ws.Close()
		return
	}

	go leg.writePump()
	leg.readPump(hc)
}

func (leg *clientLeg) writePump() {
	for {
		select {
		case b := <-leg.outQ:
			leg.queued.Add(-int64(len(b)))
			_ = leg.ws.SetWriteDeadline(time.Now().Add(WriteTimeoutMillis * time.Millisecond))
			if err := leg.ws.WriteMessage(websocket.BinaryMessage, b); err != nil {
				leg.close()
				return
			}
		case <-leg.closed:
			return
		}
	}
}

// readPump relays client raw SSH bytes toward the agent leg.
func (leg *clientLeg) readPump(hc *hostConn) {
	defer leg.close()
	for {
		_ = leg.ws.SetReadDeadline(time.Now().Add(5 * time.Second))
		mt, data, err := leg.ws.ReadMessage()
		if err != nil {
			return
		}
		if mt != websocket.BinaryMessage {
			return
		}
		leg.gw.DbgClientToHost.Add(int64(len(data)))
		frame := appendUvarint([]byte{}, leg.id)
		frame = append(frame, data...)
		if err := hc.sendFrame(FrameData, frame); err != nil {
			return
		}
	}
}

func (leg *clientLeg) close() {
	leg.close1.Do(func() {
		close(leg.closed)
		// Abortive close: a stalled consumer (or dead leg) gets a RST, not a
		// graceful FIN — hung peers find out immediately instead of after
		// draining bytes they will never read. Go closes the fd only once our
		// own blocked reader/writer let go, so both are unstuck with immediate
		// deadlines first. (Never close the raw fd number here: the poller
		// still tracks it and the kernel would hand the number to the next
		// accepted connection.)
		if tc, ok := leg.ws.UnderlyingConn().(*net.TCPConn); ok {
			_ = tc.SetLinger(0)
		}
		_ = leg.ws.SetReadDeadline(time.Now())
		_ = leg.ws.SetWriteDeadline(time.Now())
		leg.ws.Close()
	})
}

func mustJSON(v any) []byte {
	b, err := json.Marshal(v)
	if err != nil {
		return []byte("{}")
	}
	return b
}
