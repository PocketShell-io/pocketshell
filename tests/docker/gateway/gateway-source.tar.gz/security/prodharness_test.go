package security

// Test-only fixtures for the production suite. Everything here is local and
// ephemeral per test run:
//
//   - locally signed RS256 JWTs shaped EXACTLY like the sync broker's
//     gateway routing credentials (iss/aud/scope/nbf/sub/email_verified,
//     ≤5-minute lifetime), served through a local JWKS endpoint and verified
//     by the REAL internal/routingauth verifier — never by a stand-in;
//   - a Google-shaped JWT used only as a NEGATIVE (the local disclosure
//     guard F-09 and the verifier must both refuse it);
//   - the WS rewriting MITM used by the ready-metadata substitution test;
//   - a WS-level freezer for the slow-consumer bound (the consumer stops
//     reading; the gateway's bounded writer must kill the leg);
//   - a mutable clock to exercise credential expiry without wall-clock
//     sleeps.
//
// No production code is modified to make these tests pass.

import (
	"bytes"
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"

	"github.com/PocketShell-io/pocketshell-gateway/internal/hostagent"
	"github.com/PocketShell-io/pocketshell-gateway/internal/routingauth"
)

const (
	prodAliceSub   = "113958430858354529072"
	prodAliceEmail = "alice@example.com"
	prodBobSub     = "990125438765432109021"
	prodBobEmail   = "bob@example.com"
	prodEveSub     = "515253545556575859601"
	prodEveEmail   = "eve@example.com" // valid person, NOT allowlisted

	// brokerIssuerLocal is the dev-lab issuer of the fixture broker. The
	// real verifier accepts it only because the fixture verifier opts into
	// AllowInsecureDev for the plain-HTTP local JWKS — the same opt-in the
	// production wiring exposes for explicit local docker proofs.
	brokerIssuerLocal = "http://sync-broker.fixture/gateway"
	brokerKid         = "prod-broker-kid-1"
)

// --- broker JWT fixtures ------------------------------------------------------

func b64urlRaw(t *testing.T, b []byte) string {
	t.Helper()
	return base64.RawURLEncoding.EncodeToString(b)
}

func bigEndianExp(e int) []byte {
	out := []byte{}
	for e > 0 {
		out = append([]byte{byte(e)}, out...)
		e >>= 8
	}
	return out
}

func signRS256JWT(t *testing.T, key *rsa.PrivateKey, header, claims map[string]any) string {
	t.Helper()
	enc := func(v map[string]any) string {
		b, err := json.Marshal(v)
		if err != nil {
			t.Fatal(err)
		}
		return base64.RawURLEncoding.EncodeToString(b)
	}
	si := enc(header) + "." + enc(claims)
	digest := sha256.Sum256([]byte(si))
	sig, err := rsa.SignPKCS1v15(rand.Reader, key, crypto.SHA256, digest[:])
	if err != nil {
		t.Fatal(err)
	}
	return si + "." + base64.RawURLEncoding.EncodeToString(sig)
}

// brokerHeader is the JOSE header of the fixture broker tokens.
func brokerHeader() map[string]any {
	return map[string]any{"alg": "RS256", "kid": brokerKid, "typ": "JWT"}
}

// brokerClaims mirrors the sync broker's issuance contract
// (docs/routing-credentials.md): fixed issuer, gateway audience, gateway
// scope, verified email, and a lifetime inside the five-minute bound.
func brokerClaims(now int64, sub, email string, lifetime time.Duration) map[string]any {
	return map[string]any{
		"iss":            brokerIssuerLocal,
		"aud":            hostagent.BrokerAudience,
		"scope":          hostagent.BrokerScope,
		"sub":            sub,
		"email":          email,
		"email_verified": true,
		"iat":            now,
		"nbf":            now,
		"exp":            now + int64(lifetime/time.Second),
	}
}

// googleShapedClaims is a Google ID token look-alike. It is only ever a
// negative: the CLI disclosure guard must refuse it before any HTTP request,
// and the routing verifier must refuse it regardless.
func googleShapedClaims(now int64, sub, email string) map[string]any {
	return map[string]any{
		"iss":            "https://accounts.google.com",
		"aud":            "google-fixture-client-id",
		"exp":            now + 3600,
		"iat":            now,
		"sub":            sub,
		"email":          email,
		"email_verified": true,
	}
}

// brokerJWKS is the JWKS document the fixture broker publishes.
func brokerJWKS(t *testing.T, key *rsa.PrivateKey) string {
	t.Helper()
	return fmt.Sprintf(`{"keys":[{"kty":"RSA","alg":"RS256","use":"sig","kid":%q,"n":%q,"e":%q}]}`,
		brokerKid, b64urlRaw(t, key.N.Bytes()), b64urlRaw(t, bigEndianExp(key.E)))
}

// startJWKSServer serves a fixed JWKS document.
func startJWKSServer(t *testing.T, body string) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("content-type", "application/json")
		_, _ = w.Write([]byte(body))
	}))
	t.Cleanup(srv.Close)
	return srv
}

// mutableClock is a controllable clock for credential-expiry scenarios. It
// starts at the real current time.
type mutableClock struct {
	now atomic.Int64
}

func newMutableClock() *mutableClock {
	c := &mutableClock{}
	c.now.Store(time.Now().Unix())
	return c
}

func (c *mutableClock) Now() time.Time { return time.Unix(c.now.Load(), 0) }

func (c *mutableClock) Advance(d time.Duration) { c.now.Add(int64(d / time.Second)) }

// --- WS MITM / proxy ----------------------------------------------------------

// wsProxy proxies a client WebSocket to target. onClientText may rewrite
// every client→server TEXT frame, onServerText every server→client TEXT
// frame. Binary frames flow unmodified in both directions. This is the
// man-in-the-middle position an untrusted gateway or network path occupies;
// the fixtures use it to prove the protocol does not depend on its honesty.
func wsProxy(t *testing.T, target string, onClientText func([]byte) []byte, onServerText func([]byte) []byte) http.Handler {
	t.Helper()
	up := websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		client, err := up.Upgrade(w, r, nil)
		if err != nil {
			return
		}
		defer client.Close()
		d := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
		server, resp, err := d.Dial(target, nil)
		if err != nil {
			if resp != nil {
				t.Logf("mitm upstream: HTTP %d", resp.StatusCode)
			}
			return
		}
		defer server.Close()
		var wg sync.WaitGroup
		wg.Add(2)
		go func() {
			defer wg.Done()
			pumpTextAware(t, server, client, onServerText)
		}()
		go func() {
			defer wg.Done()
			pumpTextAware(t, client, server, onClientText)
		}()
		wg.Wait()
	})
}

func pumpTextAware(t *testing.T, src, dst *websocket.Conn, onText func([]byte) []byte) {
	for {
		mt, data, err := src.ReadMessage()
		if err != nil {
			dst.Close()
			return
		}
		if mt == websocket.TextMessage && onText != nil {
			data = onText(data)
		}
		_ = dst.SetWriteDeadline(time.Now().Add(5 * time.Second))
		if err := dst.WriteMessage(mt, data); err != nil {
			return
		}
	}
}

// postJSONStatus posts a bearer-authenticated JSON request and returns the
// HTTP status.
func postJSONStatus(t *testing.T, url, token string, body map[string]any) int {
	t.Helper()
	var rdr io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rdr = bytes.NewReader(b)
	} else {
		rdr = bytes.NewReader([]byte("{}"))
	}
	req, err := http.NewRequest(http.MethodPost, url, rdr)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	_, _ = io.Copy(io.Discard, resp.Body)
	return resp.StatusCode
}

// postJSONBody posts a bearer JSON request and returns status + body.
func postJSONBody(t *testing.T, url, token string, body any) (int, []byte) {
	t.Helper()
	raw, _ := json.Marshal(body)
	req, err := http.NewRequest(http.MethodPost, url, bytes.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<16))
	return resp.StatusCode, b
}

// getJSON performs a bearer GET and returns status + body.
func getJSON(t *testing.T, url, token string) (int, []byte) {
	t.Helper()
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Authorization", "Bearer "+token)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<16))
	return resp.StatusCode, b
}

// parsePin parses an authorized_keys line into an ssh.PublicKey.
func parsePin(t *testing.T, line string) ssh.PublicKey {
	t.Helper()
	pk, _, _, _, err := ssh.ParseAuthorizedKey([]byte(line))
	if err != nil {
		t.Fatal(err)
	}
	return pk
}

func truncateForLog(b []byte) string {
	s := string(b)
	if len(s) > 120 {
		s = s[:120] + "..."
	}
	return s
}

// --- WS freezer (slow-consumer fixture) ----------------------------------------

// wsFreezer is a net.Conn over the client WebSocket transport that stops
// reading after N bytes: the honest simulation of a dead/hung client at the
// transport level. (SSH flow-control windows absorb an application-level slow
// reader, so the observable gateway bound must trip on a stalled transport —
// the same finding as the reference suite.) While frozen, reads block on a
// channel; Unfreeze releases them so the test can observe the server-side
// teardown that happened while the consumer was gone.
type wsFreezer struct {
	net.Conn
	stopAfter int64
	total     int64
	frozen    atomic.Bool
	release   chan struct{}
	released  atomic.Bool
}

func newWSFreezer(conn net.Conn, stopAfter int64) *wsFreezer {
	return &wsFreezer{Conn: conn, stopAfter: stopAfter, release: make(chan struct{})}
}

func (r *wsFreezer) Read(p []byte) (int, error) {
	if r.frozen.Load() {
		<-r.release
		return 0, io.EOF
	}
	n, err := r.Conn.Read(p)
	r.total += int64(n)
	if r.total >= r.stopAfter {
		r.frozen.Store(true)
	}
	return n, err
}

// Unfreeze releases a frozen reader (post-assertion recovery probe).
func (r *wsFreezer) Unfreeze() {
	if r.released.CompareAndSwap(false, true) {
		close(r.release)
	}
}

// verifyToken is a tiny helper for the credential-boundary tests: run the
// REAL routingauth verifier against a token and classify the result.
func verifyToken(t *testing.T, v *routingauth.Verifier, token string) error {
	t.Helper()
	_, err := v.VerifyToken(t.Context(), token)
	return err
}

// --- test-scoped slog (gateway + agent diagnostics into the test log) ---------

// safeTLogger forwards slog output to t.Log; safe against late writes after
// the test finished (cleanup races), which would otherwise panic.
type safeTLogger struct {
	t    *testing.T
	done atomic.Bool
}

func newTestSlogLogger(t *testing.T) *slog.Logger {
	t.Helper()
	l := &safeTLogger{t: t}
	t.Cleanup(func() { l.done.Store(true) })
	return slog.New(slog.NewTextHandler(l, &slog.HandlerOptions{Level: slog.LevelInfo}))
}

func (l *safeTLogger) Write(p []byte) (int, error) {
	if l.done.Load() {
		return len(p), nil
	}
	defer func() { _ = recover() }() // t.Log panics after completion; drop instead
	l.t.Log(strings.TrimRight(string(p), "\n"))
	return len(p), nil
}
