package security

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/security/sshlab"
	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"
)

// In-process assertion suite (reference SUT, mode "in-process").
//
// Every test boots the full chain — real x/crypto/ssh server (public-key
// only), reference destination-pinned host agent, lab identity registry, and
// the ADVERSARIAL gateway fixture — and asserts observable outcomes only:
// shell output, sshd auth counters, gateway counters, probe connection
// counts.
//
// S11 is the suite itself run under -race plus the goroutine-baseline check
// every lab registers via t.Cleanup.

const (
	acctA      = "google:acct-a-sub"
	acctAEmail = "acct-a@lab.invalid"
	acctB      = "google:acct-b-sub"
	acctBEmail = "acct-b@lab.invalid"
	sentinel   = "POCKETSHELL_SENTINEL_OK"
)

type lab struct {
	t         *testing.T
	Reg       *sshlab.Registry
	SSHD      *sshlab.Server
	Probe     *sshlab.Probe
	GW        *sshlab.Gateway
	Agent     *sshlab.Agent
	HostKey   *sshlab.SSHKey
	ClientKey *sshlab.SSHKey // authorized on SSHD
	OtherKey  *sshlab.SSHKey // authorized nowhere
	DeviceKey *sshlab.DeviceKey
	DeviceID  string
	TokA      string
	TokB      string
	goros0    int
}

func newLab(t *testing.T, attacks sshlab.AttackMode, opts sshlab.Options) *lab {
	t.Helper()
	l := &lab{t: t, DeviceID: "dev-a-" + strings.ToLower(strings.ReplaceAll(t.Name(), "/", "-"))}
	l.goros0 = runtime.NumGoroutine()

	var err error
	l.Reg = sshlab.NewRegistry()
	if l.HostKey, err = sshlab.NewSSHKey(); err != nil {
		t.Fatal(err)
	}
	if l.ClientKey, err = sshlab.NewSSHKey(); err != nil {
		t.Fatal(err)
	}
	if l.OtherKey, err = sshlab.NewSSHKey(); err != nil {
		t.Fatal(err)
	}
	if l.DeviceKey, err = sshlab.NewDeviceKey(); err != nil {
		t.Fatal(err)
	}
	if l.SSHD, err = sshlab.StartSSHD(l.HostKey.Signer, l.ClientKey.Public); err != nil {
		t.Fatal(err)
	}
	if l.Probe, err = sshlab.StartProbe(); err != nil {
		t.Fatal(err)
	}
	if l.GW, err = sshlab.NewGatewayWithOptions(l.Reg, attacks, opts); err != nil {
		t.Fatal(err)
	}
	l.TokA = l.Reg.MintAccountToken(sshlab.Principal{AccountID: acctA, Email: acctAEmail})
	l.TokB = l.Reg.MintAccountToken(sshlab.Principal{AccountID: acctB, Email: acctBEmail})

	if _, err = l.Reg.Enroll(l.TokA, l.DeviceID, l.DeviceKey.Pub, sshlab.EnrollProof(l.DeviceKey, l.DeviceID, acctA), nil); err != nil {
		t.Fatalf("enroll: %v", err)
	}
	l.startAgent()
	t.Cleanup(func() {
		time.Sleep(150 * time.Millisecond) // let teardown settle
		l.GW.Close()
		l.Probe.Close()
		l.SSHD.Close()
		if after := runtime.NumGoroutine(); after > l.goros0+8 {
			t.Errorf("goroutine leak: %d at start, %d at end (S11 bound check)", l.goros0, after)
		}
	})
	return l
}

func (l *lab) startAgent() {
	l.t.Helper()
	agent, err := sshlab.StartAgent(l.t.Context(), sshlab.AgentConfig{
		GatewayURL: l.GW.HostURL(),
		DeviceID:   l.DeviceID,
		DeviceKey:  l.DeviceKey,
		PinnedSSH:  l.SSHD.Addr(),
	})
	if err != nil {
		l.t.Fatal(err)
	}
	l.Agent = agent
	if !l.Agent.WaitAuthed(5 * time.Second) {
		l.t.Fatal("lab agent failed to authenticate to gateway")
	}
}

// restartGW replaces the gateway (different attack toggles/bounds) and
// reconnects the honest agent to it. The old agent keeps failing against the
// closed old URL — bounded retries, no connection ever established.
func (l *lab) restartGW(attacks sshlab.AttackMode, opts sshlab.Options) {
	l.t.Helper()
	l.GW.Close()
	gw, err := sshlab.NewGatewayWithOptions(l.Reg, attacks, opts)
	if err != nil {
		l.t.Fatal(err)
	}
	l.GW = gw
	l.startAgent()
}

// healthyDial is the reusable positive control: authorized SSH key through
// the gateway runs the benign sentinel and returns its output.
func (l *lab) healthyDial() (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	c, err := sshlab.DialSSH(ctx, sshlab.ClientOpts{
		GatewayURL: l.GW.ClientURL(),
		Token:      l.TokA,
		ClientKey:  l.ClientKey.Signer,
		PinnedHost: l.HostKey.Public,
	})
	if err != nil {
		return "", err
	}
	defer c.Close()
	s, err := c.NewSession()
	if err != nil {
		return "", err
	}
	defer s.Close()
	out, err := s.CombinedOutput("echo " + sentinel)
	return string(out), err
}

// recordResult appends one structured evidence line for the final report.
func recordResult(t *testing.T, id, detail string) {
	t.Helper()
	dir := filepath.Join("..", ".tmp", "security-logs")
	_ = os.MkdirAll(dir, 0o755)
	f, err := os.OpenFile(filepath.Join(dir, "results.jsonl"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	v := "PASS"
	if t.Failed() {
		v = "FAIL"
	}
	_ = json.NewEncoder(f).Encode(map[string]string{
		"id": id, "test": t.Name(), "mode": "in-process", "verdict": v, "detail": detail,
	})
}

func wantFail(t *testing.T, err error, what string) {
	t.Helper()
	if err == nil {
		t.Fatalf("%s: expected failure, got success (assertion violated)", what)
	}
	t.Logf("%s rejected as required: %v", what, err)
}

// --- S1: positive control ---------------------------------------------------

func TestS1PositiveControlAuthorizedKey(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{}, sshlab.Options{})
	out, err := l.healthyDial()
	if err != nil {
		t.Fatalf("positive control failed: %v", err)
	}
	if !strings.Contains(out, sentinel) {
		t.Fatalf("sentinel missing in output: %q", out)
	}
	st := l.SSHD.Stats()
	if st.ShellsGranted != 1 || st.AuthAccepted != 1 {
		t.Fatalf("unexpected sshd stats: %+v", st)
	}
	t.Logf("authorized key: end-to-end SSH exec through gateway returned %q; sshd=%+v", strings.TrimSpace(out), st)
	recordResult(t, "S1", "authorized key executed benign sentinel end-to-end through the relay")
}

// --- S2: unknown key + no password auth --------------------------------------

func TestS2UnknownSSHKeyAndPasswordRejected(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{}, sshlab.Options{})

	// unknown key
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_, err := sshlab.DialSSH(ctx, sshlab.ClientOpts{
		GatewayURL: l.GW.ClientURL(), Token: l.TokA, ClientKey: l.OtherKey.Signer, PinnedHost: l.HostKey.Public,
	})
	wantFail(t, err, "unknown SSH key")

	// password-only attempt against the same honest chain
	ctx2, cancel2 := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel2()
	ws, err := sshlab.WSDial(ctx2, l.GW.ClientURL())
	if err != nil {
		t.Fatal(err)
	}
	defer ws.Close()
	tok, _ := json.Marshal(map[string]string{"token": l.TokA})
	if err := ws.WriteMessage(websocket.TextMessage, tok); err != nil {
		t.Fatal(err)
	}
	n := sshlab.NewWSNet(ws)
	_, _, _, err = ssh.NewClientConn(n, l.GW.ClientURL(), &ssh.ClientConfig{
		User:            "lab",
		Auth:            []ssh.AuthMethod{ssh.Password("totally-wrong")},
		HostKeyCallback: ssh.FixedHostKey(l.HostKey.Public),
		Timeout:         10 * time.Second,
	})
	wantFail(t, err, "password authentication")
	if !strings.Contains(err.Error(), "no supported methods") {
		t.Errorf("expected server to advertise no supported methods, got: %v", err)
	}

	st := l.SSHD.Stats()
	if st.AuthAccepted != 0 || st.ShellsGranted != 0 {
		t.Fatalf("auth state corrupted: %+v", st)
	}
	if st.AuthAttempts < 1 {
		t.Errorf("sshd never saw the unknown-key attempt: %+v", st)
	}
	recordResult(t, "S2", fmt.Sprintf("unknown key rejected (attempts=%d denied=%d), password not offered, no shells", st.AuthAttempts, st.AuthDenied))
}

// --- S3: gateway credentials alone must not authenticate SSH ------------------

func TestS3GatewayCredentialsDoNotGrantShell(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{CaptureProof: true}, sshlab.Options{})
	if !l.Agent.WaitAuthed(3 * time.Second) {
		l.startAgent()
	}
	// The gateway has its own valid routing credentials and its own SSH key
	// (unauthorized on the host). It opens a stream on the agent leg itself.
	gwKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	before := l.SSHD.Stats()
	authErr, err := l.GW.ShellAttempt(context.Background(), gwKey.Signer)
	if err != nil {
		t.Fatalf("shell attempt machinery failed: %v", err)
	}
	wantFail(t, authErr, "gateway with valid relay/device credentials but unauthorized key")
	after := l.SSHD.Stats()
	if after.AuthAccepted != before.AuthAccepted || after.ShellsGranted != before.ShellsGranted {
		t.Fatalf("sshd state changed by gateway attempt: %+v -> %+v", before, after)
	}
	// The relay must still serve the honest client afterwards.
	out, err := l.healthyDial()
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("relay broken after attacker attempt: out=%q err=%v", out, err)
	}
	recordResult(t, "S3", "gateway-held credentials + own key: userauth rejected by real host sshd; relay unharmed")
}

// --- S4: host key substitution rejected before userauth -----------------------

func TestS4HostKeySubstitutionRejectedBeforeUserauth(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{HostKeyMITM: true}, sshlab.Options{})
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_, err := sshlab.DialSSH(ctx, sshlab.ClientOpts{
		GatewayURL: l.GW.ClientURL(), Token: l.TokA, ClientKey: l.ClientKey.Signer, PinnedHost: l.HostKey.Public,
	})
	wantFail(t, err, "substituted host key")
	if !sshlab.HostKeyRejected(err) {
		t.Errorf("expected host-key rejection, got: %v", err)
	}
	// Nothing ever reached the real home sshd — not even a TCP connection.
	st := l.SSHD.Stats()
	if st.Connections != 0 || st.AuthAttempts != 0 {
		t.Fatalf("real sshd saw pre-auth traffic after MITM substitution: %+v", st)
	}
	if l.GW.MitmConns.Load() < 1 {
		t.Errorf("MITM never engaged: %d", l.GW.MitmConns.Load())
	}
	if l.GW.MitmAuthAttempts.Load() != 0 {
		t.Errorf("client sent userauth material to the substituted endpoint: %d", l.GW.MitmAuthAttempts.Load())
	}
	recordResult(t, "S4", "pinned-key client refused gateway's own host key at kex; sshd conns=0 auth=0")
}

// --- S5: device proof replay / wrong key --------------------------------------

func TestS5DeviceProofReplayAndWrongKeyRejected(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{CaptureProof: true}, sshlab.Options{})
	if !l.Agent.WaitAuthed(3 * time.Second) {
		l.startAgent()
	}
	devID, nonce, sig, ok := l.GW.Capture()
	if !ok {
		l.t.Fatal("gateway captured no proof")
	}
	// (a) replay the captured material onto a fresh connection+challenge
	verdict, err := l.GW.AttackerHostHandshake(context.Background(), devID, nonce, sig)
	if err != nil {
		t.Fatal(err)
	}
	if verdict == "ok" {
		t.Fatal("replayed device proof authenticated a second host connection")
	}
	t.Logf("replayed proof verdict: %q", verdict)

	// (b) valid fresh challenge signed by a different device key
	attKey, err := sshlab.NewDeviceKey()
	if err != nil {
		t.Fatal(err)
	}
	verdict, err = l.GW.WrongKeyAttempt(context.Background(), devID, attKey)
	if err != nil {
		t.Fatal(err)
	}
	if verdict == "ok" {
		t.Fatal("wrong device key authenticated")
	}
	t.Logf("wrong-key verdict: %q", verdict)

	// (c) registry-level single-use guarantee, directly
	n2, err := l.Reg.NewChallenge(devID, "unit-conn")
	if err != nil {
		t.Fatal(err)
	}
	p := sshlab.ConnectProof(l.DeviceKey, devID, n2)
	if _, err := l.Reg.VerifyChallenge("g", "unit-conn", devID, n2, p); err != nil {
		t.Fatalf("first use of fresh challenge must succeed: %v", err)
	}
	if _, err := l.Reg.VerifyChallenge("g", "unit-conn", devID, n2, p); err == nil {
		t.Fatal("challenge accepted twice: single-use violated")
	}
	// (d) nonce bound to the connection it was issued on
	n3, _ := l.Reg.NewChallenge(devID, "conn-1")
	if _, err := l.Reg.VerifyChallenge("g", "conn-OTHER", devID, n3, sshlab.ConnectProof(l.DeviceKey, devID, n3)); err == nil {
		t.Fatal("challenge accepted on a different connection: binding violated")
	}
	if l.GW.HostConnCount() != 1 {
		t.Fatalf("attacker handshakes registered host conns: %d", l.GW.HostConnCount())
	}
	out, err := l.healthyDial()
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("honest stream broken after attacks: %q %v", out, err)
	}
	recordResult(t, "S5", "replayed proof, wrong key, double-use and cross-conn nonce all rejected; live conn unaffected")
}

// --- S6: arbitrary local destination selection rejected ------------------------

func TestS6ArbitraryDestinationNotHonored(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{}, sshlab.Options{})
	l.restartGW(sshlab.AttackMode{SubstituteDest: l.Probe.Addr()}, sshlab.Options{})

	out, err := l.healthyDial()
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("stream should still land on the pinned loopback sshd: %q %v", out, err)
	}
	if l.Agent.DestSubstReject.Load() < 1 {
		t.Errorf("agent did not count/ignore the injected destination field")
	}
	if c := l.Probe.Count(); c != 0 {
		t.Fatalf("sensitive local service received %d connections — destination pinning violated", c)
	}
	recordResult(t, "S6", "OPEN frame with attacker-chosen destination: field ignored, stream pinned to loopback sshd, probe conns=0")
}

// --- S7: cross-account isolation ------------------------------------------------

func TestS7CrossAccountIsolation(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{}, sshlab.Options{})

	// Account B enrolls its own device and has its own SSH key.
	devBKey, err := sshlab.NewDeviceKey()
	if err != nil {
		t.Fatal(err)
	}
	devB := "dev-b-1"
	if _, err := l.Reg.Enroll(l.TokB, devB, devBKey.Pub, sshlab.EnrollProof(devBKey, devB, acctB), nil); err != nil {
		t.Fatal(err)
	}
	clientKeyB, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}

	// B has no host online: routing must refuse, not fall back to A's host.
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_, err = sshlab.DialSSH(ctx, sshlab.ClientOpts{
		GatewayURL: l.GW.ClientURL(), Token: l.TokB, ClientKey: clientKeyB.Signer, PinnedHost: l.HostKey.Public,
	})
	wantFail(t, err, "B dial with no B-host online")
	if l.GW.RoutingErrorsSent.Load() < 1 {
		t.Errorf("gateway did not report a routing error for B")
	}
	st := l.SSHD.Stats()
	if st.Connections != 0 || st.AuthAttempts != 0 {
		t.Fatalf("B routing failure leaked toward A's host: %+v", st)
	}

	// Identity plane: B sees only B's devices and cannot revoke A's.
	devs, err := l.Reg.ListDevices(l.TokB)
	if err != nil {
		t.Fatal(err)
	}
	if len(devs) != 1 || devs[0].ID != devB {
		t.Fatalf("B listed devices outside its account: %+v", devs)
	}
	if err := l.Reg.Revoke(l.TokB, l.DeviceID); err == nil {
		t.Fatal("B revoked A's device: owner-only violated")
	}
	if _, err := l.Reg.Enroll(l.TokB, "dev-b-2", devBKey.Pub, sshlab.EnrollProof(devBKey, "dev-b-2", acctB), nil); err != nil {
		t.Fatalf("B enrolling its own second device must succeed: %v", err)
	}
	if _, err := l.Reg.VerifyAccountToken("forged-token"); err == nil {
		t.Fatal("forged account token accepted")
	}

	// Compromised-gateway mode: malicious routing hands B's stream to A's
	// agent anyway — the SSH layer must still refuse B's key on A's host.
	l.restartGW(sshlab.AttackMode{CrossConnect: true}, sshlab.Options{})
	ctx2, cancel2 := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel2()
	_, err = sshlab.DialSSH(ctx2, sshlab.ClientOpts{
		GatewayURL: l.GW.ClientURL(), Token: l.TokB, ClientKey: clientKeyB.Signer, PinnedHost: l.HostKey.Public,
	})
	wantFail(t, err, "B routed onto A's host by malicious gateway")
	st = l.SSHD.Stats()
	if st.AuthAccepted != 0 || st.ShellsGranted != 0 {
		t.Fatalf("B gained shell on A's host: %+v", st)
	}
	if st.AuthDenied < 1 {
		t.Errorf("A's sshd never evaluated B's key (expected rejection): %+v", st)
	}
	out, err := l.healthyDial()
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("A's own access broken: %q %v", out, err)
	}
	recordResult(t, "S7", "honest gateway refuses cross-account routing; even when maliciously routed, B's key is rejected on A's host; owner-only identity checks hold")
}

// --- S8: revocation --------------------------------------------------------------

func TestS8RevocationDisconnectsAndSticks(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{}, sshlab.Options{})
	if out, err := l.healthyDial(); err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("pre-revoke baseline failed: %q %v", out, err)
	}

	// Owner revokes; registry persists before notifying.
	if err := l.Reg.Revoke(l.TokA, l.DeviceID); err != nil {
		t.Fatal(err)
	}
	if !l.Agent.WaitRevoked(3 * time.Second) {
		t.Fatal("agent did not observe revocation within 3s")
	}
	deadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(deadline) && l.GW.HostConnCount() > 0 {
		time.Sleep(50 * time.Millisecond)
	}
	if l.GW.HostConnCount() != 0 {
		t.Fatalf("revoked device still connected: %d conns", l.GW.HostConnCount())
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	_, err := sshlab.DialSSH(ctx, sshlab.ClientOpts{
		GatewayURL: l.GW.ClientURL(), Token: l.TokA, ClientKey: l.ClientKey.Signer, PinnedHost: l.HostKey.Public,
	})
	wantFail(t, err, "client dial after revocation")
	// An attacker re-running the exact valid device handshake must also fail.
	verdict, err := l.GW.AttackerHostHandshake(ctx, l.DeviceID, nil, nil)
	if err == nil && verdict == "ok" {
		t.Fatal("revoked device re-authenticated")
	}
	t.Logf("revoked device handshake verdict: %q (err=%v)", verdict, err)

	// No silent key replacement for the revoked device ID.
	newKey, err := sshlab.NewDeviceKey()
	if err != nil {
		t.Fatal(err)
	}
	if _, err := l.Reg.Enroll(l.TokA, l.DeviceID, newKey.Pub, sshlab.EnrollProof(newKey, l.DeviceID, acctA), nil); err == nil {
		t.Fatal("revoked device re-enrolled with a different key without current-key proof")
	}
	recordResult(t, "S8", "revocation: agent torn down, reconnect + attacker handshake refused, silent re-key refused")
}

// --- S9: malformed frames ----------------------------------------------------------

func TestS9MalformedFramesFailClosed(t *testing.T) {
	l := newLab(t, sshlab.AttackMode{}, sshlab.Options{})
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()

	// (a) oversized frame on the host leg
	ws, err := sshlab.WSDial(ctx, l.GW.HostURL())
	if err != nil {
		t.Fatal(err)
	}
	_ = ws.WriteMessage(websocket.BinaryMessage, make([]byte, 600<<10))
	if err := waitClosed(ctx, ws); err != nil {
		t.Fatalf("oversized frame did not close the connection: %v", err)
	}

	// (b) garbage token on the client leg
	ws2, err := sshlab.WSDial(ctx, l.GW.ClientURL())
	if err != nil {
		t.Fatal(err)
	}
	_ = ws2.WriteMessage(websocket.TextMessage, []byte(`{"token": 12345}`))
	if err := waitClosed(ctx, ws2); err != nil {
		t.Fatalf("garbage client token did not close: %v", err)
	}

	// (c) OPEN before authentication on the host leg
	ws3, err := sshlab.WSDial(ctx, l.GW.HostURL())
	if err != nil {
		t.Fatal(err)
	}
	_ = ws3.WriteMessage(websocket.BinaryMessage, append([]byte{0x10}, 0x01))
	if err := waitClosed(ctx, ws3); err != nil {
		t.Fatalf("pre-auth OPEN did not close: %v", err)
	}

	// (d) garbage instead of the signed proof
	ws4, err := sshlab.WSDial(ctx, l.GW.HostURL())
	if err != nil {
		t.Fatal(err)
	}
	_ = ws4.WriteMessage(websocket.BinaryMessage, append([]byte{0x01}, []byte(`{"device_id":"`+l.DeviceID+`"}`)...))
	if err := ws4.WriteMessage(websocket.BinaryMessage, []byte{0x03, 'n', 'o', 't', 'j', 's', 'o', 'n'}); err != nil {
		t.Fatal(err)
	}
	if err := waitClosed(ctx, ws4); err != nil {
		t.Fatalf("garbage proof did not close: %v", err)
	}

	// (e) authenticated peer sends truncated DATA framing: its conn dies,
	// the honest agent is untouched.
	ws5, err := rawAuthedHostConn(ctx, l)
	if err != nil {
		t.Fatal(err)
	}
	_ = ws5.WriteMessage(websocket.BinaryMessage, []byte{0x11, 0xff}) // FrameData, broken uvarint
	if err := waitClosed(ctx, ws5); err != nil {
		t.Fatalf("truncated DATA did not close the attacker conn: %v", err)
	}
	out, err := l.healthyDial()
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("honest stream broken by malformed-frame attacker: %q %v", out, err)
	}
	recordResult(t, "S9", "oversized/garbage/pre-auth/truncated frames each fail closed; honest connections unaffected")
}

// rawAuthedHostConn completes a legitimate second-device handshake and
// returns the raw connection (used to test post-auth malformed input).
func rawAuthedHostConn(ctx context.Context, l *lab) (*websocket.Conn, error) {
	k, err := sshlab.NewDeviceKey()
	if err != nil {
		return nil, err
	}
	devID := l.DeviceID + "-second"
	if _, err := l.Reg.Enroll(l.TokA, devID, k.Pub, sshlab.EnrollProof(k, devID, acctA), nil); err != nil {
		return nil, err
	}
	ws, err := sshlab.WSDial(ctx, l.GW.HostURL())
	if err != nil {
		return nil, err
	}
	if err := ws.WriteMessage(websocket.BinaryMessage, append([]byte{0x01}, []byte(`{"device_id":"`+devID+`"}`)...)); err != nil {
		return nil, err
	}
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, data, err := ws.ReadMessage()
	if err != nil {
		return nil, err
	}
	if len(data) < 1 || data[0] != 0x02 {
		return nil, fmt.Errorf("expected challenge, got %#v", data)
	}
	var ch struct {
		Nonce string `json:"nonce_b64"`
	}
	if err := json.Unmarshal(data[1:], &ch); err != nil {
		return nil, err
	}
	nonce, err := sshlab.UnB64(ch.Nonce)
	if err != nil {
		return nil, err
	}
	proof := sshlab.ConnectProof(k, devID, nonce)
	body, _ := json.Marshal(struct {
		Nonce string `json:"nonce_b64"`
		Sig   string `json:"sig_b64"`
	}{sshlab.B64(nonce), sshlab.B64(proof)})
	if err := ws.WriteMessage(websocket.BinaryMessage, append([]byte{0x03}, body...)); err != nil {
		return nil, err
	}
	_, data, err = ws.ReadMessage()
	if err != nil {
		return nil, err
	}
	if len(data) < 1 || data[0] != 0x04 {
		return nil, fmt.Errorf("expected AUTH_OK, got %#v", data)
	}
	_ = ws.SetReadDeadline(time.Time{})
	return ws, nil
}

func waitClosed(ctx context.Context, ws *websocket.Conn) error {
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	done := make(chan error, 1)
	go func() {
		for {
			if _, _, err := ws.ReadMessage(); err != nil {
				done <- nil
				return
			}
		}
	}()
	select {
	case err := <-done:
		return err
	case <-ctx.Done():
		return errors.New("timeout waiting for connection close")
	}
}

// --- S10: slow consumer -----------------------------------------------------------

// readStopper is a transport that stops reading after N bytes — the honest
// simulation of a dead/hung client at the TCP level (an app-level slow reader
// is absorbed by the SSH flow-control window, so the observable gateway bound
// must trip on a stalled transport instead). While frozen it probes with
// zero-length reads under a short deadline, which consumes no bytes but
// surfaces the server-side close.
type readStopper struct {
	conn      net.Conn        // the SSH transport
	raw       syscall.RawConn // underlying socket: SO_ERROR liveness probes
	stopAfter int64
	total     int64
	frozen    bool
}

func (r *readStopper) Write(p []byte) (int, error)   { return r.conn.Write(p) }
func (r *readStopper) Close() error                  { return r.conn.Close() }
func (r *readStopper) LocalAddr() net.Addr           { return r.conn.LocalAddr() }
func (r *readStopper) RemoteAddr() net.Addr          { return r.conn.RemoteAddr() }
func (r *readStopper) SetDeadline(t time.Time) error { return r.conn.SetDeadline(t) }
func (r *readStopper) SetReadDeadline(t time.Time) error {
	return r.conn.SetReadDeadline(t)
}
func (r *readStopper) SetWriteDeadline(t time.Time) error {
	return r.conn.SetWriteDeadline(t)
}

func (r *readStopper) Read(p []byte) (int, error) {
	if r.frozen {
		// Consumer is gone: never read another byte (draining would defeat
		// the freeze). Poll SO_ERROR instead — the gateway kills stalled legs
		// with an abortive close, and the RST surfaces as ECONNRESET here
		// without consuming anything.
		for {
			sockErr := 0
			_ = r.raw.Control(func(fd uintptr) {
				sockErr, _ = syscall.GetsockoptInt(int(fd), syscall.SOL_SOCKET, syscall.SO_ERROR)
			})
			if sockErr != 0 {
				return 0, syscall.Errno(sockErr) // e.g. ECONNRESET from the kill
			}
			time.Sleep(50 * time.Millisecond)
		}
	}
	n, err := r.conn.Read(p)
	r.total += int64(n)
	if r.total >= r.stopAfter {
		r.frozen = true
	}
	return n, err
}

func TestS10SlowConsumerKilledAndBounded(t *testing.T) {
	// outbound bound: 2 chunks x 8KB = 16KB backlog allowed, 400ms grace.
	l := newLab(t, sshlab.AttackMode{}, sshlab.Options{QueueChunks: 2, ChunkSize: 8192, SlowMillis: 400})
	l.Agent = nil // replaced below with an 8KB-chunk agent
	agent, err := sshlab.StartAgent(t.Context(), sshlab.AgentConfig{
		GatewayURL: l.GW.HostURL(), DeviceID: l.DeviceID, DeviceKey: l.DeviceKey,
		PinnedSSH: l.SSHD.Addr(), ChunkSize: 8192,
	})
	if err != nil {
		t.Fatal(err)
	}
	l.Agent = agent
	if !l.Agent.WaitAuthed(5 * time.Second) {
		t.Fatal("agent failed to authenticate")
	}

	ctx, cancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer cancel()
	ws, err := sshlab.RawDialWS(ctx, l.GW.ClientURL(), 8*1024)
	if err != nil {
		t.Fatal(err)
	}
	transport, raw, err := sshlab.WSAuth(ws, l.TokA)
	if err != nil {
		t.Fatal(err)
	}
	src := raw.(interface {
		SyscallConn() (syscall.RawConn, error)
	})
	rawRC, err := src.SyscallConn()
	if err != nil {
		t.Fatal(err)
	}
	stopper := &readStopper{conn: transport, raw: rawRC, stopAfter: 8192}
	c, err := sshlab.DialSSHConn(ctx, sshlab.ClientOpts{
		GatewayURL: l.GW.ClientURL(), Token: l.TokA, ClientKey: l.ClientKey.Signer, PinnedHost: l.HostKey.Public,
	}, stopper)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	s, err := c.NewSession()
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	// ~1.3MB of benign deterministic output that we never drain: the
	// transport freezes after the first 8KB frame.
	if err := s.Start("seq 1 200000"); err != nil {
		t.Fatal(err)
	}
	start := time.Now()
	// The gateway must declare the stalled stream dead within its bound.
	deadline := time.Now().Add(15 * time.Second)
	for l.GW.SlowKills.Load() < 1 && time.Now().Before(deadline) {
		time.Sleep(20 * time.Millisecond)
	}
	if l.GW.SlowKills.Load() < 1 {
		t.Fatal("slow consumer was not killed within 15s: unbounded queue suspected")
	}
	t.Logf("slow-consumer kill recorded after %s", time.Since(start).Round(time.Millisecond))
	// The frozen client must observe the teardown: conn Wait returns when
	// the transport dies (its read loop probes the closed socket).
	broken := make(chan error, 1)
	go func() { broken <- c.Wait() }()
	select {
	case err := <-broken:
		t.Logf("frozen client observed teardown after %s: %v", time.Since(start).Round(time.Millisecond), err)
	case <-time.After(20 * time.Second):
		t.Fatal("frozen client never observed the kill")
	}
	// service recovers
	out, err := l.healthyDial()
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("relay broken after slow-consumer kill: %q %v", out, err)
	}
	recordResult(t, "S10", fmt.Sprintf("stalled transport: stream killed after %s, service recovered", time.Since(start).Round(time.Millisecond)))
}
