//go:build opuslab

package opus

import (
	"encoding/json"
	"fmt"
	"strings"
	"testing"
	"time"
)

func needSiblings(t *testing.T) {
	t.Helper()
	if L.idp == nil {
		t.Skip("sibling-source mode only (OPUS_LAB_MODE=siblings)")
	}
}

func needEnrolled(t *testing.T) {
	t.Helper()
	needSiblings(t)
	if enrollErr != nil {
		t.Fatalf("real host-agent enrollment against the real gateway failed: %v", enrollErr)
	}
}

// handshake runs only the client WebSocket auth (no SSH) and reports
// whether the gateway answered "ready".
func (l *lab) handshake(device, tokenName string) (bool, string) {
	out, code := l.sh("client", wsProxy(device, tokenName)+" </dev/null")
	ready := !strings.Contains(out, "gateway refused") && !strings.Contains(out, "handshake:") && code == 0
	return ready, out
}

func (l *lab) apiCall(method, path, tokenName string) (int, string) {
	out, _ := l.sh("client", fmt.Sprintf("/lab/bin/siblingprobe api -base %s -method %s -path %s -token-file /lab/tok/%s", gwBase, method, path, tokenName))
	var r struct {
		Status int    `json:"status"`
		Body   string `json:"body"`
	}
	_ = json.Unmarshal([]byte(strings.TrimSpace(out)), &r)
	return r.Status, out
}

// The new API accepts only sync-broker scoped credentials: exact issuer,
// audience pocketshell-gateway, scope pocketshell.gateway, verified and
// allowlisted email, and a lifetime within the five-minute broker bound.
// Every variant is signed by the SAME lab key the gateway trusts, so only
// the claim checks under test can tell them apart. Each case runs on both
// gateway entry points that take a bearer: the client SSH route and the
// identity API.
func TestScopedCredentialPolicy(t *testing.T) {
	needEnrolled(t)
	now := time.Now()
	otherKey := newLabIdP()
	otherKey.kid = L.idp.kid
	cases := []struct {
		name   string
		token  string
		accept bool
	}{
		{"broker-valid", L.idp.sign(alice.broker(5 * time.Minute)), true},
		{"google-id-token", L.idp.sign(alice.google(5 * time.Minute)), false},
		{"google-token-with-gateway-aud", L.idp.sign(with(alice.google(5*time.Minute), "aud", brokerAudience, "scope", brokerScope)), false},
		{"wrong-audience", L.idp.sign(with(alice.broker(5*time.Minute), "aud", "pocketshell-sync")), false},
		{"audience-array", L.idp.sign(with(alice.broker(5*time.Minute), "aud", []string{brokerAudience})), false},
		{"issuer-prefix", L.idp.sign(with(alice.broker(5*time.Minute), "iss", labBrokerIssuer+"/")), false},
		{"missing-scope", L.idp.sign(with(alice.broker(5*time.Minute), "scope", nil)), false},
		{"wrong-scope", L.idp.sign(with(alice.broker(5*time.Minute), "scope", "pocketshell.sync")), false},
		{"lifetime-1h", L.idp.sign(alice.broker(time.Hour)), false},
		{"lifetime-9m", L.idp.sign(alice.broker(9 * time.Minute)), false},
		{"missing-iat", L.idp.sign(with(alice.broker(5*time.Minute), "iat", nil, "nbf", nil)), false},
		{"not-yet-valid", L.idp.sign(with(alice.broker(5*time.Minute), "nbf", now.Add(3*time.Minute).Unix(), "iat", now.Add(3*time.Minute).Unix(), "exp", now.Add(8*time.Minute).Unix())), false},
		{"expired", L.idp.sign(with(alice.broker(5*time.Minute), "iat", now.Add(-10*time.Minute).Unix(), "nbf", now.Add(-10*time.Minute).Unix(), "exp", now.Add(-5*time.Minute).Unix())), false},
		{"exp-string", L.idp.sign(with(alice.broker(5*time.Minute), "exp", fmt.Sprint(now.Add(5*time.Minute).Unix()))), false},
		{"email-unverified", L.idp.sign(with(alice.broker(5*time.Minute), "email_verified", false)), false},
		{"email-verified-string", L.idp.sign(with(alice.broker(5*time.Minute), "email_verified", "true")), false},
		{"not-allowlisted", L.idp.sign(carol.broker(5 * time.Minute)), false},
		{"untrusted-signer-same-kid", otherKey.sign(alice.broker(5 * time.Minute)), false},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			L.writeTok("case", c.token)
			ready, out := L.handshake("home-a", "case")
			if ready != c.accept {
				t.Errorf("client route: accepted=%v want %v\n%s", ready, c.accept, out)
			}
			status, aout := L.apiCall("GET", "/identity/v1/devices", "case")
			if (status == 200) != c.accept {
				t.Errorf("identity API: status=%d want accept=%v\n%s", status, c.accept, aout)
			}
		})
	}
}

// A client must never hand the original Google ID token to the new
// gateway: the gateway is untrusted, and that token carries sync
// authority. The recorder stands in for a gateway and logs only the iss
// claim of whatever bearer the real pocketshell-link sends it.
func TestHostCLINeverSendsGoogleToken(t *testing.T) {
	needSiblings(t)
	L.writeTok("google", L.idp.sign(alice.google(5*time.Minute)))
	out, _ := L.enroll("home-g", "/lab/agentcfg-g", "google", "http://idp:8081")
	for _, e := range L.events("idp", "recorder.jsonl") {
		if e["iss"] == googleIssuer {
			t.Fatalf("pocketshell-link sent a Google-issued ID token to the gateway (%s); it must refuse locally before any request.\n%s", e["path"], out)
		}
	}
}

// Ownership is the verified account, not anything the client claims.
func TestCrossOwnerDenied(t *testing.T) {
	needEnrolled(t)
	L.refreshTokens()
	if ready, out := L.handshake("home-a", "bob"); ready {
		t.Errorf("bob reached alice's device:\n%s", out)
	}
	if ready, out := L.handshake("home-b", "alice"); ready {
		t.Errorf("alice reached bob's device:\n%s", out)
	}
	if status, out := L.apiCall("GET", "/identity/v1/devices", "bob"); status != 200 || strings.Contains(out, "home-a") {
		t.Errorf("bob's device list: status %d, must not list home-a:\n%s", status, out)
	}
	if status, out := L.apiCall("POST", "/identity/v1/devices/home-a/revoke", "bob"); status >= 200 && status < 300 {
		t.Errorf("bob revoked alice's device: %d\n%s", status, out)
	}
	if ready, out := L.handshake("home-a", "alice"); !ready {
		t.Errorf("positive control: alice no longer reaches home-a after bob's attempts:\n%s", out)
	}
}

type probeResult struct {
	Accepted  bool   `json:"accepted"`
	ReplyType string `json:"reply_type"`
	ReplyCode string `json:"reply_code"`
}

func (l *lab) hostProbe(t *testing.T, args string) probeResult {
	t.Helper()
	out, code := l.sh("client", "/lab/bin/siblingprobe hostauth "+args)
	var r probeResult
	if code != 0 || json.Unmarshal([]byte(strings.TrimSpace(out)), &r) != nil {
		t.Fatalf("probe failed (exit %d): %s", code, out)
	}
	return r
}

// Device proofs are bound to one connection's challenge and one device.
// Uses bob's enrolled (not running) home-b key so alice's agent is not
// superseded.
func TestHostProofReplayRejected(t *testing.T) {
	needEnrolled(t)
	if r := L.hostProbe(t, "-mode fresh -key /lab/keys/device_b_pkcs8.pem -device home-b"); !r.Accepted {
		t.Fatalf("positive control: fresh proof for home-b refused: %+v", r)
	}
	if r := L.hostProbe(t, "-mode replay -key /lab/keys/device_b_pkcs8.pem -device home-b"); r.Accepted {
		t.Errorf("proof from another connection's challenge accepted: %+v", r)
	}
	if r := L.hostProbe(t, "-mode otherdevice -key /lab/keys/device_b_pkcs8.pem -device home-b -claim home-a"); r.Accepted {
		t.Errorf("home-b's key authenticated as home-a: %+v", r)
	}
}

// P6: no stream ever reached a destination other than the agent's
// configured loopback sshd, after every SSH test above. The suite runs
// alphabetically; this file's tests precede ssh_test.go, so the check is
// repeated in zz_revocation_test.go at the end.
func assertNoDecoyContact(t *testing.T) {
	t.Helper()
	for _, f := range []struct{ svc, file string }{{"home", "home-sentinel.jsonl"}, {"lan", "lan-sentinel.jsonl"}} {
		if n := len(L.events(f.svc, f.file)) - count(L.events(f.svc, f.file), "listening"); n != 0 {
			t.Errorf("%s decoy recorded %d events: the agent reached a non-configured endpoint", f.svc, n)
		}
	}
}

// Account admission-token expiry and SSH session duration are separate
// policies. The tunnel checks the token only at admission and bounds the
// session with MaxSessionDuration (default 12h). This test records the
// actual behaviour: a session admitted with a token that expires 15s
// later keeps running past that expiry. It fails if anyone claims
// expiry-driven termination while the runtime does not enforce it, and
// passes as evidence of the chosen bounded policy otherwise.
func TestSessionOutlivesAdmissionTokenByPolicy(t *testing.T) {
	needEnrolled(t)
	L.writeTok("short", L.idp.sign(with(alice.broker(15*time.Second))))
	start := time.Now()
	script := "ssh " + sshOpts(wsProxy("home-a", "short")) + " -o BatchMode=yes -i /lab/keys/user_ed25519 labuser@home-lab " +
		shellQuote("sleep 50; "+L.cmd)
	out, code := L.sh("client", script)
	if code != 0 || !strings.Contains(out, L.sentinel) {
		t.Fatalf("session admitted with a 15s token did not run to completion after %s (exit %d):\n%s", time.Since(start), code, out)
	}
	t.Logf("session ran %s, beyond the 15s token (+30s verifier leeway): token expiry is admission-only; session bound is MaxSessionDuration", time.Since(start).Round(time.Second))
}

// The real host CLI must enroll against the real identity service. This is
// the actual-source regression for F-08 (and C1); the rest of the suite
// uses the lab-only adapter when it fails, so it does not mask the bug.
func TestRealCLIEnrollment(t *testing.T) {
	needSiblings(t)
	if cliEnrollErr != nil {
		t.Fatal(cliEnrollErr)
	}
}

// The real host CLI must keep a tunnel up. Regression for F-11.
func TestRealCLIRun(t *testing.T) {
	needSiblings(t)
	if cliRunErr != nil {
		t.Fatal(cliRunErr)
	}
}
