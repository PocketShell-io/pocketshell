//go:build opuslab

package opus

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"math/big"
	"time"
)

// Lab-only trust roots. The issuer is a plain-http lab URL; the gateway
// accepts it only with -broker-allow-insecure-dev in dev-listen mode.
const (
	labBrokerIssuer = "http://idp:8080"
	brokerAudience  = "pocketshell-gateway"
	brokerScope     = "pocketshell.gateway"
	googleIssuer    = "https://accounts.google.com"
)

// labIdP signs RS256 JWTs with a per-run key. It mints both sync-broker
// scoped gateway tokens (the only credential the new API may accept) and
// Google-shaped ID tokens (which the new API must refuse and which a
// client must never send to the gateway).
type labIdP struct {
	key *rsa.PrivateKey
	kid string
}

func newLabIdP() *labIdP {
	k, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		panic(err)
	}
	return &labIdP{key: k, kid: "opus-lab-" + randHex(4)}
}

func (p *labIdP) jwks() []byte {
	b64 := base64.RawURLEncoding.EncodeToString
	doc := map[string]any{"keys": []map[string]string{{
		"kty": "RSA", "alg": "RS256", "use": "sig", "kid": p.kid,
		"n": b64(p.key.N.Bytes()),
		"e": b64(big.NewInt(int64(p.key.E)).Bytes()),
	}}}
	out, _ := json.Marshal(doc)
	return out
}

// account is a lab Google identity (subject + verified email).
type account struct{ sub, email string }

var (
	alice = account{"opus-alice-1001", "alice@opus-lab.invalid"}
	bob   = account{"opus-bob-2002", "bob@opus-lab.invalid"}
	carol = account{"opus-carol-3003", "carol@opus-lab.invalid"} // not allowlisted
)

// broker returns the claims the sync broker mints for a: exact issuer,
// gateway audience and scope, five-minute lifetime.
func (a account) broker(ttl time.Duration) map[string]any {
	now := time.Now()
	return map[string]any{
		"iss": labBrokerIssuer, "aud": brokerAudience, "scope": brokerScope,
		"sub": a.sub, "email": a.email, "email_verified": true,
		"iat": now.Unix(), "nbf": now.Unix(), "exp": now.Add(ttl).Unix(),
	}
}

// google returns Google-ID-token-shaped claims for a.
func (a account) google(ttl time.Duration) map[string]any {
	now := time.Now()
	return map[string]any{
		"iss": googleIssuer, "aud": "opus-lab-client.apps.googleusercontent.com",
		"sub": a.sub, "email": a.email, "email_verified": true,
		"iat": now.Unix(), "exp": now.Add(ttl).Unix(),
	}
}

// sign returns a compact RS256 JWS over claims.
func (p *labIdP) sign(claims map[string]any) string {
	b64 := base64.RawURLEncoding.EncodeToString
	h, _ := json.Marshal(map[string]string{"alg": "RS256", "kid": p.kid, "typ": "JWT"})
	c, _ := json.Marshal(claims)
	signing := b64(h) + "." + b64(c)
	d := sha256.Sum256([]byte(signing))
	sig, err := rsa.SignPKCS1v15(rand.Reader, p.key, crypto.SHA256, d[:])
	if err != nil {
		panic(err)
	}
	return signing + "." + b64(sig)
}

func with(c map[string]any, kv ...any) map[string]any {
	for i := 0; i+1 < len(kv); i += 2 {
		if kv[i+1] == nil {
			delete(c, kv[i].(string))
			continue
		}
		c[kv[i].(string)] = kv[i+1]
	}
	return c
}
