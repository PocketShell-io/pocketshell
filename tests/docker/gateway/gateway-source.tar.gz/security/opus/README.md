# Opus review suite

Independent defensive checks that an untrusted gateway cannot obtain shell
access to a home SSH server without the user's authorized SSH key. Threat
model, property list, findings and verdict: `docs/opus-security-review.md`.

Everything here is behind the `opuslab` build tag and `OPUS_LAB=1`, and runs
only in the disposable Docker Compose project `gateway-opus-test` (internal
network, no published ports, per-run ephemeral keys under `.tmp/opus-lab/`).

    OPUS_LAB=1 /usr/local/go/bin/go test -tags opuslab -count=1 -v ./security/opus/

Fixtures (`fixtures/`) only record, refuse or forward to a fixed lab upstream:
`honeyssh` (wrong-host-key SSH endpoint that logs userauth attempts),
`tcpsentinel` (decoy listener), `bytepipe` (fixed-route forwarder).

Sibling-source mode builds the real gateway, `pocketshell-link` and the
`siblingprobe` driver from an untracked, hashed staging copy of the
current worker sources (`scripts/stage-siblings.sh`). This is
pre-integration evidence, and the root must rerun it on the accepted tree:

    OPUS_LAB=1 OPUS_LAB_MODE=siblings /usr/local/go/bin/go test -tags opuslab -count=1 -v ./security/opus/

`siblingprobe` (build tag `opussiblings`, compiled only inside the staging
tree) checks host-proof replay and owner-scoped API calls. It also carries
two labelled lab-only stand-ins (`enroll`, `agent`) for runtime bugs F-08
and F-11. Each stand-in has its own failing regression test.
