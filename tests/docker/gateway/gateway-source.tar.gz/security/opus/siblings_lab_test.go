//go:build opuslab

package opus

import (
	"crypto/ed25519"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

// Sibling-source mode (OPUS_LAB_MODE=siblings) builds the real gateway,
// host agent CLI and a probe from an untracked staging copy of the exact
// sibling worktree sources (see scripts/stage-siblings.sh and MANIFEST.txt
// in the run directory). It is pre-integration evidence only; the
// coordinator's integrated commit must be rerun with the same suite.

const gwBase = "http://gateway:8080"

func wsProxy(device, tokenName string) string {
	return fmt.Sprintf("/lab/bin/wsclient -url ws://gateway:8080/api/v1/hosts/%s/ssh -device %s -token-file /lab/tok/%s -ready-out /lab/out/ready.jsonl",
		device, device, tokenName)
}

func (l *lab) stageSiblings(root string) error {
	stage := filepath.Join(l.run, "stage")
	cmd := exec.Command(filepath.Join(root, "security/opus/scripts/stage-siblings.sh"), stage)
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("stage siblings: %v\n%s", err, out)
	}
	l.manifest = filepath.Join(stage, "MANIFEST.txt")
	probeDir := filepath.Join(stage, "src", "cmd", "opus-siblingprobe")
	if err := os.MkdirAll(probeDir, 0o755); err != nil {
		return err
	}
	src, err := os.ReadFile(filepath.Join(root, "security/opus/fixtures/siblingprobe/main.go"))
	if err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(probeDir, "main.go"), src, 0o644); err != nil {
		return err
	}
	for name, pkg := range map[string]string{"gateway": ".", "pocketshell-link": "./cmd/pocketshell-link", "siblingprobe": "./cmd/opus-siblingprobe"} {
		cmd := exec.Command(goBin, "build", "-trimpath", "-tags", "opussiblings", "-o", filepath.Join(l.run, "bin", name), pkg)
		cmd.Dir = filepath.Join(stage, "src")
		cmd.Env = append(os.Environ(), "CGO_ENABLED=0", "GOOS=linux")
		if out, err := cmd.CombinedOutput(); err != nil {
			return fmt.Errorf("build %s from staged siblings: %v\n%s", name, err, out)
		}
	}
	l.idp = newLabIdP()
	return os.WriteFile(filepath.Join(l.run, "idp", "jwks.json"), l.idp.jwks(), 0o644)
}

// writeTok stores a lab token where client/home containers can read it.
func (l *lab) writeTok(name, tok string) {
	if err := os.WriteFile(filepath.Join(l.run, "tok", name), []byte(tok+"\n"), 0o644); err != nil {
		panic(err)
	}
}

func (l *lab) refreshTokens() {
	l.writeTok("alice", l.idp.sign(alice.broker(5*time.Minute)))
	l.writeTok("bob", l.idp.sign(bob.broker(5*time.Minute)))
}

func (l *lab) hostFingerprint() string {
	raw, err := os.ReadFile(filepath.Join(l.run, "keys/client/home_host.pub"))
	if err != nil {
		panic(err)
	}
	pk, _, _, _, err := ssh.ParseAuthorizedKey(raw)
	if err != nil {
		panic(err)
	}
	return ssh.FingerprintSHA256(pk)
}

// enroll runs the real pocketshell-link enroll as the unprivileged agent
// user, token piped on stdin from a lab token file.
func (l *lab) enroll(device, cfgDir, tokenName, server string) (string, int) {
	script := fmt.Sprintf("install -d -o agent -g agent -m 0700 %s && cat /lab/tok/%s | su agent -s /bin/sh -c %s",
		cfgDir, tokenName, shellQuote(fmt.Sprintf(
			"/lab/bin/pocketshell-link enroll --token-stdin --server %s --insecure-dev --device-id %s --ssh-host 127.0.0.1:22 --config-dir %s --expect-host-key %s",
			server, device, cfgDir, l.hostFingerprint())))
	return l.sh("home", script)
}

var enrollErr error

// cliEnrollErr records the real pocketshell-link enroll result; the suite
// falls back to the lab-only siblingprobe adapter when it fails (F-08).
var cliEnrollErr, cliRunErr error

// adapterEnroll runs the lab-only enrollment adapter as the agent user.
func (l *lab) adapterEnroll(device, cfgDir, tokenName string) (string, int) {
	script := fmt.Sprintf("install -d -o agent -g agent -m 0700 %s && su agent -s /bin/sh -c %s", cfgDir, shellQuote(fmt.Sprintf(
		"/lab/bin/siblingprobe enroll -base %s -token-file /lab/tok/%s -device %s -config-dir %s -host-key-file /lab/keys/home_host.pub",
		gwBase, tokenName, device, cfgDir)))
	return l.sh("home", script)
}

func (l *lab) enrollAndRunAgent() error {
	l.refreshTokens()
	l.before = l.refreshTokens
	if out, code := l.enroll("home-a", "/lab/agentcfg", "alice", gwBase); code != 0 {
		cliEnrollErr = fmt.Errorf("pocketshell-link enroll home-a failed (exit %d):\n%s", code, out)
		_, _ = l.sh("home", "rm -rf /lab/agentcfg")
		if out, code := l.adapterEnroll("home-a", "/lab/agentcfg", "alice"); code != 0 {
			enrollErr = fmt.Errorf("adapter enroll home-a failed (exit %d):\n%s", code, out)
			return nil // reported by the tests; the remaining checks still run
		}
	}
	if out, code := l.adapterEnroll("home-b", "/lab/agentcfg-b", "bob"); code != 0 {
		enrollErr = fmt.Errorf("bob enroll home-b failed (exit %d):\n%s", code, out)
		return nil
	}
	// Real CLI first (F-11 regression evidence in agent.log); if it is not
	// connected after a few seconds, the lab-only launcher runs the real
	// hostagent.Agent with the missing clock supplied.
	if out, err := l.dc("exec", "-d", "home", "su", "agent", "-s", "/bin/sh", "-c",
		"exec /lab/bin/pocketshell-link run --server "+gwBase+" --insecure-dev --config-dir /lab/agentcfg >>/lab/out/agent.log 2>&1"); err != nil {
		return fmt.Errorf("start agent: %v\n%s", err, out)
	}
	connected := func() bool {
		b, _ := os.ReadFile(filepath.Join(l.run, "out/gateway/gateway.log"))
		return strings.Contains(string(b), "tunnel: host connected")
	}
	if !waitFor(5*time.Second, connected) {
		b, _ := os.ReadFile(filepath.Join(l.run, "out/home/agent.log"))
		cliRunErr = fmt.Errorf("pocketshell-link run did not connect:\n%s", b)
		if out, err := l.dc("exec", "-d", "home", "su", "agent", "-s", "/bin/sh", "-c",
			"exec /lab/bin/siblingprobe agent -config-dir /lab/agentcfg >>/lab/out/agent-adapter.log 2>&1"); err != nil {
			return fmt.Errorf("start adapter agent: %v\n%s", err, out)
		}
	}
	deadline := time.Now().Add(30 * time.Second)
	for time.Now().Before(deadline) {
		if b, _ := os.ReadFile(filepath.Join(l.run, "out/gateway/gateway.log")); strings.Contains(string(b), "tunnel: host connected") {
			break
		}
		time.Sleep(500 * time.Millisecond)
	}
	// Lab copies of the enrolled device keys, so the suite can try them as
	// SSH keys (P4) and drive proof replay probes. Deleted by collect().
	for _, k := range []struct{ src, pkcs8, openssh string }{
		{"/lab/agentcfg/device_ed25519.pem", "device_pkcs8.pem", "device_ed25519"},
		{"/lab/agentcfg-b/device_ed25519.pem", "device_b_pkcs8.pem", ""},
	} {
		out, code := l.sh("home", "cat "+k.src)
		if code != 0 {
			return fmt.Errorf("read device key: %s", out)
		}
		if err := os.WriteFile(filepath.Join(l.run, "keys/client", k.pkcs8), []byte(out), 0o644); err != nil {
			return err
		}
		if k.openssh == "" {
			continue
		}
		blk, _ := pem.Decode([]byte(out))
		if blk == nil {
			return fmt.Errorf("device key is not PEM")
		}
		key, err := x509.ParsePKCS8PrivateKey(blk.Bytes)
		if err != nil {
			return err
		}
		if err := os.WriteFile(filepath.Join(l.run, "keys/client", k.openssh), privPEM(key.(ed25519.PrivateKey)), 0o644); err != nil {
			return err
		}
	}
	l.gatewaySecrets["broker-token"] = "/lab/tok/alice"
	return nil
}
