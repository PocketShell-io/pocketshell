#!/bin/sh
# Installs per-run lab material with sshd's StrictModes ownership and
# starts sshd on loopback plus decoy listeners. LAB_PASSWORD is a random
# per-run value so the password-disabled check uses a password that is
# actually correct.
set -eu
install -m 0600 -o root -g root /lab/keys/home_host_ed25519 /etc/ssh/lab_host_ed25519_key
install -d -m 0755 -o root -g root /etc/ssh/authorized_keys
install -m 0644 -o root -g root /lab/keys/authorized_keys /etc/ssh/authorized_keys/labuser
echo "labuser:${LAB_PASSWORD}" | chpasswd >/dev/null
# The account-level secrets the gateway may know must not be shell
# credentials; also install the agent identity directory for the agent user.
install -d -m 0700 -o agent -g agent /home/agent/.config
mkdir -p /lab/out
chmod 0777 /lab/out
/usr/sbin/sshd -E /lab/out/home-sshd.log
/lab/bin/tcpsentinel -listen 127.0.0.1:2222 -log /lab/out/home-sentinel.jsonl &
exec "$@"
