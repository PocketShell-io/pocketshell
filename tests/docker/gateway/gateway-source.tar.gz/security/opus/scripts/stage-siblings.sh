#!/bin/sh
# Assemble a read-only, untracked staging copy of the exact sibling runtime
# sources the Opus lab tests before the coordinator's integrated commit
# exists. Nothing here is committed; the manifest records SHA-256 of every
# staged file so results can be tied to source. Usage:
#   stage-siblings.sh <out-dir>
# Overridable: OPUS_SRC_ROOT (relay.go, go.mod, go.sum),
# OPUS_SRC_IDENTITY (internal/identity + internal/routingauth),
# OPUS_SRC_TUNNEL (internal/tunnel, internal/hostagent, cmd/pocketshell-link).
set -eu
out=${1:?out dir}
root=${OPUS_SRC_ROOT:-/home/alexey/git/pocketshell-gateway-integration}
ident=${OPUS_SRC_IDENTITY:-/home/alexey/git/pocketshell-gateway}
tun=${OPUS_SRC_TUNNEL:-/home/alexey/git/pocketshell-gateway-tunnel}
mkdir -p "$out/src/internal" "$out/src/cmd"
cp "$root/relay.go" "$root/go.mod" "$root/go.sum" "$out/src/"
cp -R "$ident/internal/identity" "$ident/internal/routingauth" "$out/src/internal/"
cp -R "$tun/internal/tunnel" "$tun/internal/hostagent" "$out/src/internal/"
cp -R "$tun/cmd/pocketshell-link" "$out/src/cmd/"
# Drop sibling tests and stray build outputs: the lab tests binaries only.
find "$out/src" -name '*_test.go' -delete
find "$out/src" -type f ! -name '*.go' ! -name go.mod ! -name go.sum -delete
{
  echo "# Opus sibling staging manifest $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  for r in "$root" "$ident" "$tun"; do
    printf 'repo %s head %s dirty %s\n' "$r" "$(git -C "$r" rev-parse --short HEAD)" "$(git -C "$r" status --porcelain | wc -l)"
  done
  (cd "$out/src" && find . -type f | LC_ALL=C sort | xargs sha256sum)
} > "$out/MANIFEST.txt"
echo "$out/MANIFEST.txt"
