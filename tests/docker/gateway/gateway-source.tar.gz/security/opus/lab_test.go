//go:build opuslab

// Package opus is the Opus independent review suite for the PocketShell
// gateway. These tests drive a disposable Docker lab (compose project
// gateway-opus-test, internal network, no published ports) and exercise
// ordinary SSH authentication and isolation properties with per-run lab
// identities. See security/opus/README.md for how to run them.
package opus

import (
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"golang.org/x/crypto/ssh"
)

const (
	project  = "gateway-opus-test"
	image    = "gateway-opus-test/lab:local"
	hostKeyA = "home-lab" // HostKeyAlias the client pins
	goBin    = "/usr/local/go/bin/go"
)

// lab holds per-run state. One lab is shared by all tests in a run.
type lab struct {
	run      string // absolute run directory (bin, keys, out)
	compose  string // compose file
	password string // correct labuser password, which sshd must refuse
	sentinel string // per-run value only a remote shell can print
	cmd      string // benign remote command that prints sentinel
	env      []string
	tr       transport
	// gatewaySecrets maps a label to a file in the client container holding
	// a secret the gateway knows (bearer tokens, routing IDs).
	gatewaySecrets map[string]string
	// siblings mode: lab IdP, staged source manifest, enrolled device.
	idp      *labIdP
	manifest string
	before   func() // refreshes short-lived tokens before each SSH attempt
}

// transport is how the SSH client inside the "client" container reaches
// the home host's loopback sshd. Honest routes the stream to the real home
// host; Substituted routes it to an SSH server the gateway controls.
type transport struct {
	Honest      string
	Substituted string
}

var L *lab

func TestMain(m *testing.M) {
	if os.Getenv("OPUS_LAB") == "" {
		fmt.Println("opus lab: set OPUS_LAB=1 to run (requires Docker)")
		os.Exit(0)
	}
	l, err := setup()
	if err != nil {
		fmt.Fprintln(os.Stderr, "opus lab setup:", err)
		if l != nil {
			l.teardown()
		}
		os.Exit(2)
	}
	L = l
	code := m.Run()
	l.collect()
	if os.Getenv("OPUS_LAB_KEEP") == "" {
		l.teardown()
	}
	os.Exit(code)
}

func repoRoot() string {
	wd, _ := os.Getwd()
	return filepath.Clean(filepath.Join(wd, "..", ".."))
}

func setup() (*lab, error) {
	root := repoRoot()
	run := filepath.Join(root, ".tmp", "opus-lab", time.Now().UTC().Format("20060102T150405Z"))
	nonce := randHex(8)
	// The command never contains the sentinel literally (the two halves are
	// joined by the remote printf), so verbose client logs cannot fake it.
	l := &lab{run: run, password: randHex(16), sentinel: "OPUS-SENTINEL-" + nonce,
		cmd: "printf '%s%s\\n' OPUS-SENTINEL- " + nonce}
	for _, d := range []string{"bin", "keys/home", "keys/client", "tok", "idp", "out/home", "out/gateway", "out/lan", "out/client", "out/idp"} {
		if err := os.MkdirAll(filepath.Join(run, d), 0o755); err != nil {
			return nil, err
		}
	}
	for _, f := range []string{"honeyssh", "tcpsentinel", "bytepipe", "labjwks", "wsclient"} {
		cmd := exec.Command(goBin, "build", "-trimpath", "-o", filepath.Join(run, "bin", f), "./security/opus/fixtures/"+f)
		cmd.Dir = root
		cmd.Env = append(os.Environ(), "CGO_ENABLED=0", "GOOS=linux")
		if out, err := cmd.CombinedOutput(); err != nil {
			return nil, fmt.Errorf("build %s: %v\n%s", f, err, out)
		}
	}
	if err := l.writeKeys(); err != nil {
		return nil, err
	}
	if out, err := exec.Command("docker", "build", "-q", "-t", image, filepath.Join(root, "security/opus/lab")).CombinedOutput(); err != nil {
		return nil, fmt.Errorf("docker build: %v\n%s", err, out)
	}

	switch mode := os.Getenv("OPUS_LAB_MODE"); mode {
	case "", "baseline":
		l.compose = filepath.Join(root, "security/opus/lab/compose.baseline.yaml")
		l.tr = transport{Honest: "nc gateway 2201", Substituted: "nc gateway 2202"}
	case "siblings":
		if err := l.stageSiblings(root); err != nil {
			return nil, err
		}
		l.compose = filepath.Join(root, "security/opus/lab/compose.siblings.yaml")
		l.tr = transport{Honest: wsProxy("home-a", "alice"), Substituted: "nc gateway 2202"}
	default:
		return nil, fmt.Errorf("unknown OPUS_LAB_MODE %q", mode)
	}
	l.env = append(os.Environ(), "LAB_RUN="+run, "LAB_PASSWORD="+l.password)
	l.teardown() // stale project from an interrupted run
	if out, err := l.dc("up", "-d", "--wait", "--wait-timeout", "60"); err != nil {
		return l, fmt.Errorf("compose up: %v\n%s", err, out)
	}
	if err := l.waitSSHD(); err != nil {
		return l, err
	}
	if l.idp != nil {
		return l, l.enrollAndRunAgent()
	}
	return l, nil
}

func (l *lab) writeKeys() error {
	hostPub, hostPriv := newKey()
	userPub, userPriv := newKey()
	unknownPub, unknownPriv := newKey()
	_ = unknownPub
	// A stand-in for credentials an untrusted gateway legitimately holds or
	// observes (device registration key). It is deliberately not authorized.
	_, devicePriv := newKey()

	files := map[string][]byte{
		"keys/home/home_host_ed25519":  privPEM(hostPriv),
		"keys/home/authorized_keys":    ssh.MarshalAuthorizedKey(userPub),
		"keys/home/home_host.pub":      ssh.MarshalAuthorizedKey(hostPub),
		"keys/client/user_ed25519":     privPEM(userPriv),
		"keys/client/unknown_ed25519":  privPEM(unknownPriv),
		"keys/client/device_ed25519":   privPEM(devicePriv),
		"keys/client/known_hosts":      []byte(hostKeyA + " " + string(ssh.MarshalAuthorizedKey(hostPub))),
		"keys/client/home_host.pub":    ssh.MarshalAuthorizedKey(hostPub),
		"keys/client/lab_password.txt": []byte(l.password),
		"keys/client/routing_id.txt":   []byte("route-" + randHex(16)),
	}
	l.gatewaySecrets = map[string]string{"routing-id": "/lab/keys/routing_id.txt"}
	for name, data := range files {
		if err := os.WriteFile(filepath.Join(l.run, name), data, 0o600); err != nil {
			return err
		}
	}
	// authorized_keys and the pinned host key are public; the entrypoint
	// reinstalls them with root ownership anyway.
	_ = os.Chmod(filepath.Join(l.run, "keys/home/home_host.pub"), 0o644)
	return os.Chmod(filepath.Join(l.run, "keys/home/authorized_keys"), 0o644)
}

func newKey() (ssh.PublicKey, ed25519.PrivateKey) {
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		panic(err)
	}
	sp, err := ssh.NewPublicKey(pub)
	if err != nil {
		panic(err)
	}
	return sp, priv
}

func privPEM(k ed25519.PrivateKey) []byte {
	b, err := ssh.MarshalPrivateKey(k, "opus lab ephemeral")
	if err != nil {
		panic(err)
	}
	return pem.EncodeToMemory(b)
}

func randHex(n int) string {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		panic(err)
	}
	return hex.EncodeToString(b)
}

func (l *lab) dc(args ...string) (string, error) {
	full := append([]string{"compose", "-p", project, "-f", l.compose}, args...)
	cmd := exec.Command("docker", full...)
	cmd.Env = l.env
	var buf bytes.Buffer
	cmd.Stdout, cmd.Stderr = &buf, &buf
	err := cmd.Run()
	return buf.String(), err
}

// sh runs a shell command inside a lab service and returns combined output
// and the exit code.
func (l *lab) sh(service, script string) (string, int) {
	out, err := l.dc("exec", "-T", service, "sh", "-c", script)
	if err == nil {
		return out, 0
	}
	if ee, ok := err.(*exec.ExitError); ok {
		return out, ee.ExitCode()
	}
	return out + "\n" + err.Error(), -1
}

func (l *lab) teardown() {
	if l.compose == "" {
		return
	}
	_, _ = l.dc("down", "-v", "--remove-orphans", "-t", "2")
}

// collect copies container logs into the run directory as evidence and
// deletes the ephemeral private keys.
func (l *lab) collect() {
	if out, err := l.dc("logs", "--no-color", "-t"); err == nil {
		_ = os.WriteFile(filepath.Join(l.run, "out", "compose.log"), []byte(out), 0o644)
	}
	for _, f := range []string{"keys/home/home_host_ed25519", "keys/client/user_ed25519", "keys/client/unknown_ed25519", "keys/client/device_ed25519", "keys/client/device_pkcs8.pem", "keys/client/device_b_pkcs8.pem", "keys/client/lab_password.txt"} {
		_ = os.Remove(filepath.Join(l.run, f))
	}
	_ = os.RemoveAll(filepath.Join(l.run, "tok"))
}

func (l *lab) waitSSHD() error {
	deadline := time.Now().Add(30 * time.Second)
	for time.Now().Before(deadline) {
		if out, code := l.sh("home", "nc -z 127.0.0.1 22 && echo up"); code == 0 && strings.Contains(out, "up") {
			return nil
		}
		time.Sleep(500 * time.Millisecond)
	}
	return fmt.Errorf("home sshd did not start")
}

// sshOpts are the client options shared by every SSH attempt: pinned host
// key under a fixed alias, no ambient config, agent or known_hosts, and
// only the explicitly named identity.
func sshOpts(proxy string) string {
	return strings.Join([]string{
		"-F /dev/null",
		"-o StrictHostKeyChecking=yes",
		"-o UserKnownHostsFile=/lab/keys/known_hosts",
		"-o GlobalKnownHostsFile=/dev/null",
		"-o HostKeyAlias=" + hostKeyA,
		"-o UpdateHostKeys=no",
		"-o IdentitiesOnly=yes",
		"-o IdentityAgent=none",
		"-o ConnectTimeout=15",
		"-o ServerAliveInterval=5",
		fmt.Sprintf("-o ProxyCommand=%q", proxy),
	}, " ")
}

// sshAs runs ssh from the client container with the given extra options.
func (l *lab) ssh(proxy, extra, remote string) (string, int) {
	if l.before != nil {
		l.before()
	}
	script := fmt.Sprintf("ssh %s %s labuser@home-lab %s", sshOpts(proxy), extra, shellQuote(remote))
	return l.sh("client", script)
}

func shellQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'" }

type jsonEvent map[string]string

func (l *lab) events(service, file string) []jsonEvent {
	data, err := os.ReadFile(filepath.Join(l.run, "out", service, file))
	if err != nil {
		return nil
	}
	var evs []jsonEvent
	for _, line := range bytes.Split(data, []byte("\n")) {
		if len(bytes.TrimSpace(line)) == 0 {
			continue
		}
		var e jsonEvent
		if json.Unmarshal(line, &e) == nil {
			evs = append(evs, e)
		}
	}
	return evs
}

func count(evs []jsonEvent, event string) int {
	n := 0
	for _, e := range evs {
		if e["event"] == event {
			n++
		}
	}
	return n
}
