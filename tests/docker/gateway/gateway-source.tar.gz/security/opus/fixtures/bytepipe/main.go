// Command bytepipe is a lab-only TCP byte forwarder for the Opus review
// suite. Each -route maps a listen address to one fixed upstream, so a
// gateway-role container can model "honest forwarding" on one port and
// "routing substituted to a different SSH server" on another. It never
// inspects, injects or interprets bytes; it only chooses the upstream.
package main

import (
	"flag"
	"io"
	"log"
	"net"
	"strings"
	"sync"
	"time"
)

type routes []string

func (r *routes) String() string     { return strings.Join(*r, ",") }
func (r *routes) Set(v string) error { *r = append(*r, v); return nil }

func main() {
	var rs routes
	flag.Var(&rs, "route", "listen=upstream (repeatable), e.g. :2201=home:2200")
	flag.Parse()
	if len(rs) == 0 {
		log.Fatal("no -route")
	}
	var wg sync.WaitGroup
	for _, r := range rs {
		listen, upstream, ok := strings.Cut(r, "=")
		if !ok {
			log.Fatalf("bad route %q", r)
		}
		ln, err := net.Listen("tcp", listen)
		if err != nil {
			log.Fatal(err)
		}
		log.Printf("route %s -> %s", ln.Addr(), upstream)
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				c, err := ln.Accept()
				if err != nil {
					return
				}
				go forward(c, upstream)
			}
		}()
	}
	wg.Wait()
}

func forward(c net.Conn, upstream string) {
	defer c.Close()
	u, err := net.DialTimeout("tcp", upstream, 5*time.Second)
	if err != nil {
		log.Printf("dial %s: %v", upstream, err)
		return
	}
	defer u.Close()
	done := make(chan struct{}, 2)
	go func() { _, _ = io.Copy(u, c); done <- struct{}{} }()
	go func() { _, _ = io.Copy(c, u); done <- struct{}{} }()
	<-done
}
