// Command tcpsentinel is a lab-only decoy listener for the Opus review
// suite. It listens on one or more TCP addresses, records each accepted
// connection as one JSON line and closes it immediately. It stands in for
// "other services" the host agent must never forward to: a second loopback
// port on the home host and a neighbour on the lab LAN. Any recorded
// connection from the agent is a failed assertion.
package main

import (
	"encoding/json"
	"flag"
	"log"
	"net"
	"os"
	"strings"
	"sync"
	"time"
)

func main() {
	listen := flag.String("listen", "127.0.0.1:2222", "comma-separated TCP listen addresses")
	logPath := flag.String("log", "/lab/out/sentinel.jsonl", "JSON-lines connection log")
	flag.Parse()

	f, err := os.OpenFile(*logPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		log.Fatal(err)
	}
	var mu sync.Mutex
	enc := json.NewEncoder(f)
	write := func(kind, local, remote string) {
		mu.Lock()
		defer mu.Unlock()
		_ = enc.Encode(map[string]string{
			"time":   time.Now().UTC().Format(time.RFC3339Nano),
			"event":  kind,
			"local":  local,
			"remote": remote,
		})
		_ = f.Sync()
	}

	var wg sync.WaitGroup
	for _, addr := range strings.Split(*listen, ",") {
		addr = strings.TrimSpace(addr)
		if addr == "" {
			continue
		}
		ln, err := net.Listen("tcp", addr)
		if err != nil {
			log.Fatal(err)
		}
		write("listening", ln.Addr().String(), "")
		wg.Add(1)
		go func(ln net.Listener) {
			defer wg.Done()
			for {
				c, err := ln.Accept()
				if err != nil {
					return
				}
				write("accept", c.LocalAddr().String(), c.RemoteAddr().String())
				_ = c.Close()
			}
		}(ln)
	}
	wg.Wait()
}
