//go:build opussiblings

// Command siblingprobe drives the real gateway's host-agent and identity
// APIs from inside the disposable Opus lab, using the actual
// internal/identity and internal/tunnel code (it is compiled only inside
// the untracked sibling staging tree, never in this repository's build).
// It never touches SSH: it checks that a captured device proof cannot be
// replayed on another connection or for another device, and exercises
// owner-scoped listing and revocation. Tokens are read from files only.
//
//	siblingprobe hostauth -mode fresh|replay|otherdevice -key PEM -device ID [-claim ID]
//	siblingprobe api -method GET|POST -path /identity/v1/... -token-file F
//	siblingprobe agent -config-dir DIR   (lab-only stand-in for `pocketshell-link run`, F-11)
//	siblingprobe enroll -token-file F -device ID -config-dir DIR -host-key-file F
//
// enroll is a LAB-ONLY adapter used because the real pocketshell-link
// enroll cannot parse identity's current challenge transcript (finding
// F-08). It signs with the actual identity.SignEnrollment and writes the
// actual hostagent config/key files, so `pocketshell-link run` and the
// real host-auth protocol are still exercised end to end.
package main

import (
	"crypto/ed25519"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
	"time"

	"bytes"
	"context"
	"log/slog"
	"strconv"

	"github.com/PocketShell-io/pocketshell-gateway/internal/hostagent"
	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
	"github.com/gorilla/websocket"
)

func main() {
	if len(os.Args) < 2 {
		fail("usage: siblingprobe hostauth|api ...")
	}
	switch os.Args[1] {
	case "hostauth":
		hostauth(os.Args[2:])
	case "api":
		api(os.Args[2:])
	case "enroll":
		enroll(os.Args[2:])
	case "agent":
		agent(os.Args[2:])
	default:
		fail("unknown subcommand")
	}
}

func fail(msg string) {
	fmt.Fprintln(os.Stderr, "siblingprobe:", msg)
	os.Exit(2)
}

func out(v map[string]any) {
	b, _ := json.Marshal(v)
	fmt.Println(string(b))
}

func loadKey(path string) ed25519.PrivateKey {
	raw, err := os.ReadFile(path)
	if err != nil {
		fail(err.Error())
	}
	blk, _ := pem.Decode(raw)
	if blk == nil {
		fail("no pem")
	}
	k, err := x509.ParsePKCS8PrivateKey(blk.Bytes)
	if err != nil {
		fail(err.Error())
	}
	return k.(ed25519.PrivateKey)
}

func dialChallenge(url string) (*websocket.Conn, tunnel.HostChallenge) {
	d := websocket.Dialer{HandshakeTimeout: 10 * time.Second}
	ws, _, err := d.Dial(url, nil)
	if err != nil {
		fail("dial: " + err.Error())
	}
	_ = ws.SetReadDeadline(time.Now().Add(10 * time.Second))
	var ch tunnel.HostChallenge
	if err := ws.ReadJSON(&ch); err != nil {
		fail("challenge: " + err.Error())
	}
	return ws, ch
}

func sign(key ed25519.PrivateKey, ch tunnel.HostChallenge, device string) string {
	ic, err := ch.ToIdentityChallenge(device)
	if err != nil {
		fail(err.Error())
	}
	sig, err := identity.Sign(key, ic)
	if err != nil {
		fail(err.Error())
	}
	return base64.StdEncoding.EncodeToString(sig)
}

// hostauth: fresh is the positive control (the real device key signs this
// connection's challenge). replay signs connection 1's challenge and
// presents it on connection 2. otherdevice signs a valid proof for -device
// but claims -claim (another device ID).
func hostauth(args []string) {
	fs := flag.NewFlagSet("hostauth", flag.ExitOnError)
	url := fs.String("url", "ws://gateway:8080"+tunnel.PathAgentConnect, "agent endpoint")
	mode := fs.String("mode", "fresh", "fresh|replay|otherdevice")
	keyPath := fs.String("key", "", "device PKCS#8 PEM (lab copy)")
	device := fs.String("device", "", "device ID the key is enrolled for")
	claim := fs.String("claim", "", "device ID to claim (otherdevice)")
	_ = fs.Parse(args)
	key := loadKey(*keyPath)

	ws, ch := dialChallenge(*url)
	defer ws.Close()
	claimed, sig := *device, ""
	switch *mode {
	case "fresh":
		sig = sign(key, ch, *device)
	case "replay":
		ws1, ch1 := dialChallenge(*url)
		sig = sign(key, ch1, *device) // captured proof from connection 1
		ws1.Close()
	case "otherdevice":
		claimed = *claim
		sig = sign(key, ch, *device)
	default:
		fail("bad mode")
	}
	_ = ws.WriteJSON(tunnel.HostAuth{Type: "auth", V: tunnel.ProtocolVersion, DeviceID: claimed, Signature: sig})
	_ = ws.SetReadDeadline(time.Now().Add(10 * time.Second))
	_, msg, err := ws.ReadMessage()
	reply := map[string]any{}
	if err == nil {
		_ = json.Unmarshal(msg, &reply)
	}
	out(map[string]any{"mode": *mode, "claimed": claimed, "accepted": reply["type"] == "ok", "reply_type": reply["type"], "reply_code": reply["code"]})
}

func api(args []string) {
	fs := flag.NewFlagSet("api", flag.ExitOnError)
	base := fs.String("base", "http://gateway:8080", "gateway base URL")
	method := fs.String("method", "GET", "HTTP method")
	path := fs.String("path", "/identity/v1/devices", "API path")
	tokenFile := fs.String("token-file", "", "bearer token file")
	_ = fs.Parse(args)
	tok, err := os.ReadFile(*tokenFile)
	if err != nil {
		fail(err.Error())
	}
	req, _ := http.NewRequest(*method, *base+*path, strings.NewReader(""))
	req.Header.Set("Authorization", "Bearer "+strings.TrimSpace(string(tok)))
	req.Header.Set("Content-Type", "application/json")
	res, err := (&http.Client{Timeout: 15 * time.Second}).Do(req)
	if err != nil {
		fail(err.Error())
	}
	defer res.Body.Close()
	body, _ := io.ReadAll(io.LimitReader(res.Body, 64<<10))
	out(map[string]any{"status": res.StatusCode, "body": string(body)})
}

func post(base, path, token string, body any) (int, []byte) {
	raw, _ := json.Marshal(body)
	req, _ := http.NewRequest("POST", base+path, bytes.NewReader(raw))
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	res, err := (&http.Client{Timeout: 15 * time.Second}).Do(req)
	if err != nil {
		fail(err.Error())
	}
	defer res.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(res.Body, 64<<10))
	return res.StatusCode, b
}

// parseTranscript strips the identity domain separator, reads the eight
// length-prefixed fields and accepts the result only if the actual
// identity encoder reproduces the input byte for byte.
func parseTranscript(full []byte, id string) *identity.Challenge {
	const sep = "pocketshell-challenge-v1"
	t, ok := bytes.CutPrefix(full, []byte(sep))
	if !ok {
		fail("transcript: missing domain separator")
	}
	var f []string
	for i := 0; i < 8; i++ {
		if len(t) < 4 {
			fail("transcript: truncated")
		}
		n := int(t[0])<<24 | int(t[1])<<16 | int(t[2])<<8 | int(t[3])
		t = t[4:]
		if n > len(t) {
			fail("transcript: overrun")
		}
		f, t = append(f, string(t[:n])), t[n:]
	}
	exp, err := strconv.ParseInt(f[7], 10, 64)
	if err != nil || len(t) != 0 {
		fail("transcript: malformed")
	}
	ch := &identity.Challenge{ID: id, Role: f[0], Protocol: f[1], Domain: f[2], DeviceID: f[3], AccountID: f[4],
		Nonce: f[5], ConnectionNonce: f[6], ExpiresAt: time.Unix(exp, 0).UTC()}
	if re, err := ch.Transcript(); err != nil || !bytes.Equal(re, full) {
		fail("transcript: does not round-trip the identity encoding")
	}
	return ch
}

func enroll(args []string) {
	fs := flag.NewFlagSet("enroll", flag.ExitOnError)
	base := fs.String("base", "http://gateway:8080", "gateway base URL")
	tokenFile := fs.String("token-file", "", "broker token file")
	device := fs.String("device", "", "device ID")
	dir := fs.String("config-dir", "", "hostagent config dir")
	hostKeyFile := fs.String("host-key-file", "", "pinned sshd host key line (independently provisioned)")
	_ = fs.Parse(args)
	tokRaw, err := os.ReadFile(*tokenFile)
	if err != nil {
		fail(err.Error())
	}
	tok := strings.TrimSpace(string(tokRaw))
	hk, err := os.ReadFile(*hostKeyFile)
	if err != nil {
		fail(err.Error())
	}
	hostKey := strings.TrimSpace(string(hk))
	key, _, err := hostagent.LoadOrCreateKey(hostagent.KeyPath(*dir))
	if err != nil {
		fail(err.Error())
	}
	status, body := post(*base, "/identity/v1/challenge", tok, map[string]string{"device_id": *device})
	if status != 200 && status != 201 {
		out(map[string]any{"step": "challenge", "status": status, "body": string(body)})
		os.Exit(1)
	}
	var cr struct {
		ChallengeID string `json:"challenge_id"`
		Transcript  string `json:"transcript"`
	}
	_ = json.Unmarshal(body, &cr)
	tr, err := base64.StdEncoding.DecodeString(cr.Transcript)
	if err != nil {
		fail("transcript encoding")
	}
	ch := parseTranscript(tr, cr.ChallengeID)
	pub := key.Public().(ed25519.PublicKey)
	sig, err := identity.SignEnrollment(key, pub, ch, hostKey, false)
	if err != nil {
		fail(err.Error())
	}
	status, body = post(*base, "/identity/v1/enroll", tok, map[string]any{
		"device_id": *device, "public_key": base64.StdEncoding.EncodeToString(pub), "ssh_host_key": hostKey,
		"challenge_id": cr.ChallengeID, "signature": base64.StdEncoding.EncodeToString(sig), "re_enroll": false,
	})
	if status != 200 && status != 201 {
		out(map[string]any{"step": "enroll", "status": status, "body": string(body)})
		os.Exit(1)
	}
	if err := hostagent.SaveConfig(*dir, &hostagent.Config{Server: *base, DeviceID: *device, SSHHost: "127.0.0.1:22",
		SSHHostKey: hostKey, CreatedAt: time.Now().UTC()}); err != nil {
		fail(err.Error())
	}
	out(map[string]any{"step": "done", "status": status, "device": *device})
}

// agent mirrors hostagent.RunAgent exactly except that it supplies the
// AgentConfig.Now clock RunAgent leaves nil (finding F-11: the real
// `pocketshell-link run` panics on its first loop iteration). The agent
// loop, host auth, mux and loopback dialing are the real hostagent code.
func agent(args []string) {
	fs := flag.NewFlagSet("agent", flag.ExitOnError)
	dir := fs.String("config-dir", "", "hostagent config dir")
	_ = fs.Parse(args)
	cfg, err := hostagent.LoadConfig(*dir)
	if err != nil {
		fail(err.Error())
	}
	wsURL, _, err := hostagent.NormalizeServerURL(cfg.Server, true)
	if err != nil {
		fail(err.Error())
	}
	key, err := hostagent.LoadKey(hostagent.KeyPath(*dir))
	if err != nil {
		fail(err.Error())
	}
	addr, err := hostagent.ValidateLoopback(cfg.SSHHost)
	if err != nil {
		fail(err.Error())
	}
	a := hostagent.NewAgent(hostagent.AgentConfig{ServerURL: wsURL, DeviceID: cfg.DeviceID, Key: key, SSHHost: addr,
		Logger: slog.New(slog.NewTextHandler(os.Stderr, nil)), Now: time.Now})
	fmt.Fprintln(os.Stderr, "siblingprobe agent exited:", a.Run(context.Background()))
}
