// Command wsclient is the Opus lab's SSH ProxyCommand for the v1 client
// endpoint: it sends the JSON auth frame (token read from a file, never
// argv or URL), waits for "ready", then shuttles raw SSH bytes between
// stdin/stdout and binary WebSocket messages. OpenSSH on top verifies the
// home host key against a known_hosts file provisioned independently of
// the gateway.
//
// -trust-ready-known-hosts models a client that (incorrectly) trusts the
// host key the gateway sends in "ready": it writes that key as the pin
// before SSH verifies it. The review uses it only to demonstrate why the
// pin must come from local enrollment.
package main

import (
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"time"

	"github.com/gorilla/websocket"
)

func main() {
	url := flag.String("url", "", "client WebSocket URL, e.g. ws://gateway:8080/api/v1/hosts/<id>/ssh")
	device := flag.String("device", "", "device ID")
	tokenFile := flag.String("token-file", "", "file containing the account ID token")
	readyOut := flag.String("ready-out", "", "append the gateway's ready message here (evidence)")
	trustReady := flag.String("trust-ready-known-hosts", "", "DEMO ONLY: write ready.ssh_host_key as the pin at this path")
	alias := flag.String("alias", "home-lab", "HostKeyAlias used in the written known_hosts line")
	flag.Parse()
	log.SetPrefix("wsclient: ")
	log.SetFlags(0)

	tok, err := os.ReadFile(*tokenFile)
	if err != nil {
		log.Fatal(err)
	}
	d := websocket.Dialer{HandshakeTimeout: 10 * time.Second}
	ws, _, err := d.Dial(*url, nil)
	if err != nil {
		log.Fatal(err)
	}
	defer ws.Close()
	auth, _ := json.Marshal(map[string]any{"type": "auth", "v": 1, "token": strings.TrimSpace(string(tok)), "device_id": *device})
	if err := ws.WriteMessage(websocket.TextMessage, auth); err != nil {
		log.Fatal(err)
	}
	_ = ws.SetReadDeadline(time.Now().Add(20 * time.Second))
	mt, msg, err := ws.ReadMessage()
	if err != nil {
		log.Fatalf("handshake: %v", err)
	}
	if mt != websocket.TextMessage {
		log.Fatal("handshake: expected JSON")
	}
	var ready struct {
		Type       string `json:"type"`
		Code       string `json:"code"`
		SSHHostKey string `json:"ssh_host_key"`
	}
	if err := json.Unmarshal(msg, &ready); err != nil {
		log.Fatalf("handshake: %v", err)
	}
	if *readyOut != "" {
		if f, err := os.OpenFile(*readyOut, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644); err == nil {
			fmt.Fprintf(f, "%s\n", msg)
			f.Close()
		}
	}
	if ready.Type != "ready" {
		log.Fatalf("gateway refused: type=%s code=%s", ready.Type, ready.Code)
	}
	if *trustReady != "" {
		line := *alias + " " + strings.TrimSpace(ready.SSHHostKey) + "\n"
		if err := os.WriteFile(*trustReady, []byte(line), 0o644); err != nil {
			log.Fatal(err)
		}
	}
	_ = ws.SetReadDeadline(time.Time{})

	errc := make(chan error, 2)
	go func() {
		buf := make([]byte, 32<<10)
		for {
			n, err := os.Stdin.Read(buf)
			if n > 0 {
				if werr := ws.WriteMessage(websocket.BinaryMessage, buf[:n]); werr != nil {
					errc <- werr
					return
				}
			}
			if err != nil {
				errc <- err
				return
			}
		}
	}()
	go func() {
		for {
			mt, data, err := ws.ReadMessage()
			if err != nil {
				errc <- err
				return
			}
			if mt != websocket.BinaryMessage {
				errc <- errors.New("non-binary message after ready")
				return
			}
			if _, err := os.Stdout.Write(data); err != nil {
				errc <- err
				return
			}
		}
	}()
	if err := <-errc; err != nil && !errors.Is(err, io.EOF) {
		var ce *websocket.CloseError
		if !errors.As(err, &ce) {
			log.Print(err)
		}
	}
}
