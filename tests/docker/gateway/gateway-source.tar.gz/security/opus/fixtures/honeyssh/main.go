// Command honeyssh is a lab-only recording SSH endpoint used by the Opus
// review suite. It plays the part of an SSH server substituted by an
// untrusted gateway: it presents its own (wrong) host key, records every
// authentication attempt it receives as one JSON line, and rejects all of
// them. The review asserts that a client with a pinned host key aborts the
// handshake before this endpoint ever sees an authentication request.
//
// It accepts no credentials, never opens a session and runs only inside the
// disposable gateway-opus-test Docker network.
package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"errors"
	"flag"
	"log"
	"net"
	"os"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

type event struct {
	Time   string `json:"time"`
	Event  string `json:"event"`
	Remote string `json:"remote,omitempty"`
	User   string `json:"user,omitempty"`
	Method string `json:"method,omitempty"`
	Err    string `json:"err,omitempty"`
}

type recorder struct {
	mu  sync.Mutex
	enc *json.Encoder
	f   *os.File
}

func (r *recorder) write(e event) {
	e.Time = time.Now().UTC().Format(time.RFC3339Nano)
	r.mu.Lock()
	defer r.mu.Unlock()
	_ = r.enc.Encode(e)
	_ = r.f.Sync()
}

func main() {
	listen := flag.String("listen", ":2022", "TCP listen address")
	logPath := flag.String("log", "/lab/out/honeyssh.jsonl", "JSON-lines event log")
	flag.Parse()

	f, err := os.OpenFile(*logPath, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		log.Fatal(err)
	}
	rec := &recorder{enc: json.NewEncoder(f), f: f}

	// A fresh host key per process: by construction it is never the pinned
	// home host key.
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		log.Fatal(err)
	}
	signer, err := ssh.NewSignerFromKey(priv)
	if err != nil {
		log.Fatal(err)
	}
	reject := errors.New("rejected by lab fixture")
	cfg := &ssh.ServerConfig{
		PublicKeyCallback: func(ssh.ConnMetadata, ssh.PublicKey) (*ssh.Permissions, error) {
			return nil, reject
		},
		PasswordCallback: func(ssh.ConnMetadata, []byte) (*ssh.Permissions, error) {
			return nil, reject
		},
		KeyboardInteractiveCallback: func(ssh.ConnMetadata, ssh.KeyboardInteractiveChallenge) (*ssh.Permissions, error) {
			return nil, reject
		},
		// Records every userauth request, including "none". Secrets are not
		// recorded: only the method name and user.
		AuthLogCallback: func(c ssh.ConnMetadata, method string, err error) {
			e := event{Event: "auth", Remote: c.RemoteAddr().String(), User: c.User(), Method: method}
			if err != nil {
				e.Err = err.Error()
			}
			rec.write(e)
		},
		MaxAuthTries: 6,
	}
	cfg.AddHostKey(signer)

	ln, err := net.Listen("tcp", *listen)
	if err != nil {
		log.Fatal(err)
	}
	rec.write(event{Event: "listening", Remote: ln.Addr().String()})
	for {
		c, err := ln.Accept()
		if err != nil {
			log.Fatal(err)
		}
		go func(c net.Conn) {
			defer c.Close()
			_ = c.SetDeadline(time.Now().Add(30 * time.Second))
			rec.write(event{Event: "accept", Remote: c.RemoteAddr().String()})
			_, _, _, err := ssh.NewServerConn(c, cfg)
			e := event{Event: "handshake-end", Remote: c.RemoteAddr().String()}
			if err != nil {
				e.Err = err.Error()
			}
			rec.write(e)
		}(c)
	}
}
