// Command labjwks serves one static JWKS document over plain HTTP inside
// the disposable Opus review lab, standing in for the sync broker's
// GET /gateway/jwks (and, for older fixtures, Google's /certs). The key
// pair is generated per run by the test driver; tokens signed with it are
// only accepted by a gateway explicitly configured with this lab URL
// (-broker-allow-insecure-dev). LAB ONLY: never a production trust root.
//
// With -record, it also stands in for a gateway identity API: every
// /identity/v1/ request is refused with 401 and only the bearer token's
// unverified "iss" claim is recorded (never the token itself). The review
// uses it to see which credential a real client would send to a gateway.
package main

import (
	"encoding/base64"
	"encoding/json"
	"flag"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

func main() {
	listen := flag.String("listen", ":8080", "listen address")
	file := flag.String("jwks", "/lab/idp/jwks.json", "JWKS JSON file")
	record := flag.String("record", "", "JSONL file recording the iss claim of bearer tokens sent to /identity/v1/")
	flag.Parse()
	body, err := os.ReadFile(*file)
	if err != nil {
		log.Fatal(err)
	}
	serveJWKS := func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write(body)
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/certs", serveJWKS)
	mux.HandleFunc("/gateway/jwks", serveJWKS)
	if *record != "" {
		var mu sync.Mutex
		mux.HandleFunc("/identity/v1/", func(w http.ResponseWriter, r *http.Request) {
			ev := map[string]string{"event": "bearer", "path": r.URL.Path, "iss": issOf(r.Header.Get("Authorization"))}
			line, _ := json.Marshal(ev)
			mu.Lock()
			if f, err := os.OpenFile(*record, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644); err == nil {
				_, _ = f.Write(append(line, '\n'))
				f.Close()
			}
			mu.Unlock()
			http.Error(w, "recorder", http.StatusUnauthorized)
		})
	}
	srv := &http.Server{Addr: *listen, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	log.Fatal(srv.ListenAndServe())
}

// issOf returns the unverified iss claim of a bearer JWT, or a marker.
func issOf(h string) string {
	tok, ok := strings.CutPrefix(h, "Bearer ")
	if !ok {
		return "<no-bearer>"
	}
	parts := strings.Split(tok, ".")
	if len(parts) != 3 {
		return "<not-jwt>"
	}
	raw, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return "<bad-claims>"
	}
	var c struct {
		Iss string `json:"iss"`
	}
	if json.Unmarshal(raw, &c) != nil {
		return "<bad-claims>"
	}
	return c.Iss
}
