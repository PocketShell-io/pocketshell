//go:build opuslab

package opus

import (
	"strings"
	"testing"
	"time"
)

// Positive control: the authorized lab key runs a benign echo of a per-run
// sentinel through the transport. Every negative case below is only
// meaningful because this one passes on the same path.
func TestPositiveControlAuthorizedKey(t *testing.T) {
	out, code := L.ssh(L.tr.Honest, "-o BatchMode=yes -i /lab/keys/user_ed25519", L.cmd)
	if code != 0 || !strings.Contains(out, L.sentinel) {
		t.Fatalf("authorized key did not reach the sentinel (exit %d):\n%s", code, out)
	}
}

// An SSH key that is not in authorized_keys is refused by the home sshd.
func TestUnauthorizedKeyRejected(t *testing.T) {
	out, code := L.ssh(L.tr.Honest, "-o BatchMode=yes -i /lab/keys/unknown_ed25519", L.cmd)
	assertDenied(t, out, code)
}

// No identity at all ("none" auth) is refused.
func TestNoCredentialRejected(t *testing.T) {
	out, code := L.ssh(L.tr.Honest, "-o BatchMode=yes -o PubkeyAuthentication=no", L.cmd)
	assertDenied(t, out, code)
}

// Password and keyboard-interactive are disabled even when the client
// presents the correct account password, and sshd advertises only
// publickey.
func TestPasswordLoginDisabled(t *testing.T) {
	extra := "-o BatchMode=no -o PubkeyAuthentication=no -o PreferredAuthentications=password,keyboard-interactive -o NumberOfPasswordPrompts=1 -v"
	script := "sshpass -f /lab/keys/lab_password.txt ssh " + sshOpts(L.tr.Honest) + " " + extra + " labuser@home-lab " + shellQuote(L.cmd)
	out, code := L.sh("client", script)
	assertDenied(t, out, code)
	if !strings.Contains(out, "Authentications that can continue: publickey\r\n") &&
		!strings.Contains(out, "Authentications that can continue: publickey\n") {
		t.Errorf("sshd advertised methods other than publickey:\n%s", out)
	}
}

// Credentials the gateway holds or observes (device registration key,
// account token, lab routing secrets) are not SSH credentials.
func TestGatewayHeldCredentialsAreNotShellCredentials(t *testing.T) {
	t.Run("device-key-as-ssh-key", func(t *testing.T) {
		out, code := L.ssh(L.tr.Honest, "-o BatchMode=yes -i /lab/keys/device_ed25519", L.cmd)
		assertDenied(t, out, code)
	})
	t.Run("root-with-authorized-key", func(t *testing.T) {
		script := "ssh " + sshOpts(L.tr.Honest) + " -o BatchMode=yes -i /lab/keys/user_ed25519 root@home-lab " + shellQuote(L.cmd)
		out, code := L.sh("client", script)
		assertDenied(t, out, code)
	})
	for name, file := range gatewaySecretFiles() {
		t.Run(name+"-as-password", func(t *testing.T) {
			extra := "-o BatchMode=no -o PubkeyAuthentication=no -o PreferredAuthentications=password,keyboard-interactive -o NumberOfPasswordPrompts=1"
			script := "sshpass -f " + file + " ssh " + sshOpts(L.tr.Honest) + " " + extra + " labuser@home-lab " + shellQuote(L.cmd)
			out, code := L.sh("client", script)
			assertDenied(t, out, code)
		})
	}
}

// The gateway substitutes the routed SSH server. The client must refuse the
// unpinned host key before it sends any user authentication request; the
// substituted server records zero userauth attempts.
func TestSubstitutedHostKeyRefusedBeforeAuth(t *testing.T) {
	before := count(L.events("gateway", "honeyssh.jsonl"), "auth")
	out, code := L.ssh(L.tr.Substituted, "-vvv -o BatchMode=yes -i /lab/keys/user_ed25519", L.cmd)
	if code == 0 || strings.Contains(out, L.sentinel) {
		t.Fatalf("client accepted a substituted host (exit %d):\n%s", code, out)
	}
	if !strings.Contains(out, "Host key verification failed") {
		t.Fatalf("expected host key verification failure:\n%s", out)
	}
	for _, marker := range []string{"SSH2_MSG_SERVICE_ACCEPT", "Authentications that can continue", "Offering public key", "Server accepts key"} {
		if strings.Contains(out, marker) {
			t.Errorf("client progressed to user authentication (%q) after a host key mismatch", marker)
		}
	}
	time.Sleep(time.Second)
	evs := L.events("gateway", "honeyssh.jsonl")
	if count(evs, "accept") == 0 {
		t.Fatalf("substituted server never saw the connection; the test did not exercise substitution")
	}
	if got := count(evs, "auth") - before; got != 0 {
		t.Fatalf("substituted server received %d userauth requests", got)
	}
}

// The home sshd is reachable only on its loopback interface: nothing in the
// lab network can connect to it directly.
func TestHomeSSHDNotReachableFromLabNetwork(t *testing.T) {
	out, code := L.sh("client", "nc -z -w 3 home 22 && echo OPEN")
	if code == 0 || strings.Contains(out, "OPEN") {
		t.Fatalf("home:22 reachable from the lab network:\n%s", out)
	}
	out, _ = L.sh("home", "netstat -ltn")
	for _, line := range strings.Split(out, "\n") {
		f := strings.Fields(line)
		if len(f) >= 4 && f[0] == "tcp" && strings.HasSuffix(f[3], ":22") && !strings.HasPrefix(f[3], "127.0.0.1:") {
			t.Fatalf("sshd listening beyond loopback: %s", line)
		}
	}
}

// No lab container publishes a port on the Docker host.
func TestNoPublishedPorts(t *testing.T) {
	out, err := L.dc("ps", "--format", "{{.Name}} {{.Ports}}")
	if err != nil {
		t.Fatalf("compose ps: %v\n%s", err, out)
	}
	for _, line := range strings.Split(strings.TrimSpace(out), "\n") {
		if strings.Contains(line, "->") {
			t.Errorf("published port: %s", line)
		}
	}
}

func assertDenied(t *testing.T, out string, code int) {
	t.Helper()
	if code == 0 || strings.Contains(out, L.sentinel) {
		t.Fatalf("login succeeded (exit %d):\n%s", code, out)
	}
	if !strings.Contains(out, "Permission denied") {
		t.Fatalf("expected an SSH authentication refusal, got (exit %d):\n%s", code, out)
	}
	if strings.Contains(out, "Host key verification failed") {
		t.Fatalf("refusal came from host key checking, not authentication:\n%s", out)
	}
}

// gatewaySecretFiles lists, inside the client container, files holding
// secrets an untrusted gateway knows (account bearer tokens, device proofs)
// so they can be tried as SSH passwords. The baseline uses the lab password
// file as a sentinel shape check only; integrated mode adds real tokens.
func gatewaySecretFiles() map[string]string {
	return L.gatewaySecrets
}
