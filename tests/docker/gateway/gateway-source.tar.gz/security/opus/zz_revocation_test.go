//go:build opuslab

package opus

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// Runs last (file order): revocation is destructive for the lab device.
//
// Honest-gateway revocation must cut an ACTIVE SSH session, refuse the
// agent's future registrations and every new client stream, and keep the
// revoked device key tombstoned (no re-enrollment under another ID),
// including after a gateway restart. Against a compromised gateway the
// endpoint control is the home authorized_keys file, already covered by
// P2/P4; this test is the honest-gateway guarantee only.
func TestRevocationActiveAndFuture(t *testing.T) {
	needEnrolled(t)
	t.Cleanup(func() { assertNoDecoyContact(t) })
	L.refreshTokens()

	// Active session: prints the sentinel then idles for two minutes.
	_ = os.Remove(filepath.Join(L.run, "out/client/long.log"))
	long := "ssh " + sshOpts(wsProxy("home-a", "alice")) + " -o BatchMode=yes -i /lab/keys/user_ed25519 labuser@home-lab " +
		shellQuote(L.cmd+"; sleep 120") + " >/lab/out/long.log 2>&1; echo EXIT=$? >>/lab/out/long.log"
	if out, err := L.dc("exec", "-d", "client", "sh", "-c", long); err != nil {
		t.Fatalf("start long session: %v\n%s", err, out)
	}
	readLong := func() string {
		b, _ := os.ReadFile(filepath.Join(L.run, "out/client/long.log"))
		return string(b)
	}
	if !waitFor(20*time.Second, func() bool { return strings.Contains(readLong(), L.sentinel) }) {
		t.Fatalf("positive control: long session never reached the sentinel:\n%s", readLong())
	}

	revokedAt := time.Now()
	if status, out := L.apiCall("POST", "/identity/v1/devices/home-a/revoke", "alice"); status < 200 || status > 299 {
		t.Fatalf("owner revoke failed: %d\n%s", status, out)
	}
	if !waitFor(15*time.Second, func() bool { return strings.Contains(readLong(), "EXIT=") }) {
		t.Errorf("active SSH session still running %s after revocation:\n%s", time.Since(revokedAt).Round(time.Second), readLong())
	}
	if out := readLong(); strings.Contains(out, "EXIT=0") {
		t.Errorf("active session ended normally rather than being cut:\n%s", out)
	}

	future := func(stage string) {
		if ready, out := L.handshake("home-a", "alice"); ready {
			t.Errorf("%s: new client stream to revoked device accepted:\n%s", stage, out)
		}
		if r := L.hostProbe(t, "-mode fresh -key /lab/keys/device_pkcs8.pem -device home-a"); r.Accepted {
			t.Errorf("%s: revoked device key re-registered as host: %+v", stage, r)
		}
		// Same device key, new device ID: the key tombstone must hold.
		cfg := "/lab/agentcfg-dup-" + strings.ReplaceAll(stage, " ", "-")
		L.refreshTokens()
		out, code := L.sh("home", "install -d -o agent -g agent -m 0700 "+cfg+" && cp /lab/agentcfg/device_ed25519.pem "+cfg+"/ && chown agent:agent "+cfg+"/device_ed25519.pem")
		if code != 0 {
			t.Fatalf("copy device key: %s", out)
		}
		if out, code := L.adapterEnroll("home-a-dup-"+strings.ReplaceAll(stage, " ", "-"), cfg, "alice"); code == 0 || !strings.Contains(out, `"step":"enroll"`) {
			t.Errorf("%s: revoked device key re-enrolled under a new device ID:\n%s", stage, out)
		}
	}
	future("after revoke")

	if out, err := L.dc("restart", "-t", "2", "gateway"); err != nil {
		t.Fatalf("restart gateway: %v\n%s", err, out)
	}
	if !waitFor(20*time.Second, func() bool {
		_, code := L.sh("client", "nc -z gateway 8080")
		return code == 0
	}) {
		t.Fatalf("gateway did not come back after restart")
	}
	future("after restart")
	if ready, out := L.handshake("home-b", "bob"); strings.Contains(out, "unauthorized") {
		t.Errorf("positive control after restart: bob's token refused (ready=%v):\n%s", ready, out)
	}
}

func waitFor(d time.Duration, f func() bool) bool {
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		if f() {
			return true
		}
		time.Sleep(500 * time.Millisecond)
	}
	return false
}
