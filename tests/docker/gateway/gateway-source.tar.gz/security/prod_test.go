package security

// Production-SUT suite: every scenario below drives the REAL packages —
//
//	internal/identity   (real HTTP API /identity/v1/*, real challenge
//	                     issuance + single-use consumption, real v2
//	                     SignEnrollment verification, real persist-before-
//	                     notify revocation incl. uncertain-durability
//	                     containment, injected-store-fault support through
//	                     NewFileStore + WithDirSyncHook)
//	internal/routingauth(real broker-credential verifier: RS256 JWKS, exact
//	                     iss/aud/scope, ≤5min lifetime, nbf, verified email,
//	                     allowlist — fed with locally signed ephemeral JWTs)
//	internal/tunnel     (real gateway Service: server-first challenge +
//	                     identity.Sign verification on /api/v1/agent/connect;
//	                     {type:auth,v:1,token,device_id} → ready → opaque SSH
//	                     on /api/v1/hosts/{id}/ssh; bounded limits)
//	internal/hostagent  (real Enroll with the F-09 local disclosure guard,
//	                     real NewAgent/Run with the default clock, real
//	                     loopback-only destination validation)
//	cmd/pocketshell-link(the real CLI binary: enroll/run/show with --server,
//	                     --insecure-dev and --dev-broker-issuer)
//
// The home sshd is the lab SSH server (public-key-only, exec allowlist
// limited to benign sentinel commands) and the client is the real
// golang.org/x/crypto/ssh client with an INDEPENDENTLY provisioned host-key
// pin: the ready message's ssh_host_key is treated as advisory metadata and
// cross-checked, never trusted. No production code is modified to make these
// tests pass; failing cases are reported, not waived.
//
// Copied production trees are READ-ONLY snapshots (untracked; sha256 pinned
// in .tmp/prodsnap-receipt.txt).

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"

	"github.com/PocketShell-io/pocketshell-gateway/internal/hostagent"
	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/routingauth"
	"github.com/PocketShell-io/pocketshell-gateway/internal/testtoolchain"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel/wsnet"
	"github.com/PocketShell-io/pocketshell-gateway/security/sshlab"
)

// --- world ---------------------------------------------------------------------

type prodWorld struct {
	t *testing.T

	brokerKey   *rsa.PrivateKey
	brokerClock *mutableClock
	verifier    *routingauth.Verifier
	jwksSrv     *httptest.Server

	idSvc  *identity.Service
	svc    *tunnel.Service
	url    string // one origin serving BOTH the identity and tunnel APIs
	apiHit atomic.Int64

	sshd  *sshlab.Server
	probe *sshlab.Probe

	devKey       ed25519.PrivateKey
	deviceID     string
	pinLine      string // INDEPENDENT host-key pin (authorized_keys line)
	clientSigner ssh.Signer
	otherSigner  ssh.Signer // enrolled nowhere, authorized nowhere

	agentDone chan error
	agentStop context.CancelFunc
}

type prodOptions struct {
	// mutateLimits adjusts the gateway Limits (values are clamped by the
	// production hard ceilings — that clamping is itself under test).
	mutateLimits func(*tunnel.Limits)
	// newStore replaces the default in-memory registry (durability tests
	// inject a real NewFileStore with a dir-sync fault hook).
	newStore func(t *testing.T) identity.DeviceStore
}

// countingHandler counts requests reaching the combined identity+tunnel
// origin, so the F-09 disclosure guard can be proven to fail BEFORE any
// HTTP request.
type countingHandler struct {
	next http.Handler
	hit  *atomic.Int64
}

func (h countingHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	h.hit.Add(1)
	h.next.ServeHTTP(w, r)
}

func newProdWorld(t *testing.T, opts prodOptions) *prodWorld {
	t.Helper()
	w := &prodWorld{
		t:         t,
		deviceID:  "prod-dev-1",
		agentDone: make(chan error, 1),
	}

	// Lab home sshd + independent pin + sensitive-service probe.
	hostKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	clientKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	w.clientSigner = clientKey.Signer
	otherKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	w.otherSigner = otherKey.Signer
	if _, w.devKey, err = ed25519.GenerateKey(rand.Reader); err != nil {
		t.Fatal(err)
	}
	if w.sshd, err = sshlab.StartSSHD(hostKey.Signer, clientKey.Public); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(w.sshd.Close)
	w.pinLine = strings.TrimSpace(hostKey.AuthorizedLine())
	if w.probe, err = sshlab.StartProbe(); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(w.probe.Close)

	// Real routingauth verifier against a locally signed broker JWKS.
	w.brokerClock = newMutableClock()
	w.brokerKey, err = rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	w.jwksSrv = startJWKSServer(t, brokerJWKS(t, w.brokerKey))
	if w.verifier, err = routingauth.NewVerifier(routingauth.Config{
		Issuer:           brokerIssuerLocal,
		JWKSURL:          w.jwksSrv.URL,
		Allowlist:        []string{prodAliceEmail, prodBobEmail},
		AllowInsecureDev: true, // local fixture: plain-HTTP JWKS (never relaxes token verification)
		Clock:            w.brokerClock.Now,
		Logger:           func(string, ...any) {},
	}); err != nil {
		t.Fatal(err)
	}

	// Real identity service backed by the broker verifier (production
	// wiring: the relay passes the shared routingauth verifier here) and a
	// real registry store.
	store := identity.DeviceStore(identity.NewMemoryStore())
	if opts.newStore != nil {
		store = opts.newStore(t)
	}
	if w.idSvc, err = identity.NewService(identity.Config{
		Verifier:  w.verifier,
		Store:     store,
		Domain:    "127.0.0.1",
		Allowlist: []string{prodAliceEmail, prodBobEmail}, // unused with Verifier, kept explicit
		Logger:    func(string, ...any) {},
	}); err != nil {
		t.Fatal(err)
	}

	// Real tunnel gateway with the documented adapters + revoke wiring.
	limits := tunnel.Limits{
		HandshakeTimeout: 5 * time.Second,
		PongWait:         60 * time.Second,
		PingInterval:     20 * time.Second,
	}
	if opts.mutateLimits != nil {
		opts.mutateLimits(&limits)
	}
	auth := w.idSvc.TokenAuthenticator()
	if w.svc, err = tunnel.NewService(tunnel.ServiceOptions{
		Store: tunnel.DeviceStoreFunc(func(id string) (tunnel.Device, error) {
			d, err := w.idSvc.Store().GetDevice(id)
			if err != nil {
				return tunnel.Device{}, err
			}
			return tunnel.Device{ID: d.ID, AccountID: d.AccountID, PublicKey: d.PublicKey, SSHHostKey: d.SSHHostKey, Revoked: d.Revoked}, nil
		}),
		Authenticate: tunnel.AuthenticateFunc(func(ctx context.Context, tok string) (tunnel.Principal, error) {
			p, err := auth(ctx, tok)
			return tunnel.Principal(p), err
		}),
		Limits: limits,
		Logger: newTestSlogLogger(t),
	}); err != nil {
		t.Fatal(err)
	}
	w.idSvc.OnRevoke(func(d identity.Device) { w.svc.RevokeDevice(d.ID) })

	// ONE origin, like the production relay: /identity/v1/* on the identity
	// service, /api/v1/* on the tunnel gateway.
	mux := http.NewServeMux()
	mux.Handle("/identity/", w.idSvc.Handler())
	mux.Handle("/", w.svc)
	origin := httptest.NewServer(countingHandler{next: mux, hit: &w.apiHit})
	t.Cleanup(origin.Close)
	w.url = "ws" + strings.TrimPrefix(origin.URL, "http")

	// Enrollment through the REAL identity HTTP API with the production
	// enrollment client (canonical ChallengeFromWire + SignEnrollment path,
	// single-use challenge, local broker-credential disclosure guard).
	w.enrollViaCLIContract(w.deviceID, w.devKey)
	return w
}

// token mints a fresh five-minute broker routing credential for sub/email —
// the exact token shape the CLI accepts and the gateway verifies.
func (w *prodWorld) token(sub, email string) string {
	w.t.Helper()
	return signRSJWTFor(w, sub, email, hostagent.BrokerMaxLifetime)
}

func signRSJWTFor(w *prodWorld, sub, email string, lifetime time.Duration) string {
	return signRS256JWT(w.t, w.brokerKey, brokerHeader(),
		brokerClaims(w.brokerClock.Now().Unix(), sub, email, lifetime))
}

// httpBase is the same origin as w.url over plain HTTP (the identity API
// base the CLI derives from --server).
func (w *prodWorld) httpBase() string {
	return "http" + strings.TrimPrefix(w.url, "ws")
}

func (w *prodWorld) aliceToken() string { return w.token(prodAliceSub, prodAliceEmail) }
func (w *prodWorld) bobToken() string   { return w.token(prodBobSub, prodBobEmail) }
func (w *prodWorld) eveToken() string   { return w.token(prodEveSub, prodEveEmail) }

// enrollViaCLIContract enrolls deviceID/key exactly the way the CLI does:
// hostagent.Enroll against the real API, dev broker policy (the
// --dev-broker-issuer + --insecure-dev contract).
func (w *prodWorld) enrollViaCLIContract(deviceID string, key ed25519.PrivateKey) string {
	w.t.Helper()
	policy := hostagent.ProductionBrokerPolicy()
	policy.Issuer = brokerIssuerLocal // the --dev-broker-issuer lab override
	id, err := hostagent.Enroll(context.Background(), hostagent.EnrollRequest{
		APIBase:    w.httpBase(),
		Token:      w.token(prodAliceSub, prodAliceEmail),
		Policy:     policy,
		DeviceID:   deviceID,
		Key:        key,
		SSHHostKey: w.pinLine,
	})
	if err != nil {
		w.t.Fatalf("production enrollment of %s failed: %v", deviceID, err)
	}
	return id
}

func (w *prodWorld) startAgent() {
	w.t.Helper()
	w.startAgentFor(w.deviceID, w.devKey, nil)
}

func (w *prodWorld) startAgentFor(deviceID string, key ed25519.PrivateKey, tuneLimits func(*tunnel.Limits)) {
	w.t.Helper()
	ctx, cancel := context.WithCancel(context.Background())
	w.agentStop = cancel
	agentLimits := tunnel.Limits{HandshakeTimeout: 5 * time.Second, PongWait: 60 * time.Second}
	if tuneLimits != nil {
		tuneLimits(&agentLimits)
	}
	agent := hostagent.NewAgent(hostagent.AgentConfig{
		ServerURL: w.url,
		DeviceID:  deviceID,
		Key:       key,
		SSHHost:   w.sshd.Addr(),
		Limits:    agentLimits,
		Logger:    newTestSlogLogger(w.t),
	})
	done := w.agentDone
	if deviceID != w.deviceID {
		done = make(chan error, 1)
	}
	go func() { done <- agent.Run(ctx) }()
	deadline := time.Now().Add(15 * time.Second)
	for time.Now().Before(deadline) {
		if w.svc.IsDeviceConnected(deviceID) {
			return
		}
		time.Sleep(50 * time.Millisecond)
	}
	w.t.Fatalf("production agent for %s never connected", deviceID)
}

// dialClientAt performs the documented client handshake against urlBase:
// text {type:auth,v:1,token,device_id}, then awaits ready.
func (w *prodWorld) dialClientAt(urlBase, token string) (*websocket.Conn, string, *tunnel.ErrMsg, error) {
	w.t.Helper()
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, resp, err := dialer.Dial(urlBase+"/api/v1/hosts/"+w.deviceID+"/ssh", nil)
	if err != nil {
		code := 0
		if resp != nil {
			code = resp.StatusCode
		}
		return nil, "", nil, fmt.Errorf("dial: HTTP %d: %w", code, err)
	}
	_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
	auth, _ := json.Marshal(tunnel.ClientAuth{Type: "auth", V: tunnel.ProtocolVersion, Token: token, DeviceID: w.deviceID})
	if err := ws.WriteMessage(websocket.TextMessage, auth); err != nil {
		ws.Close()
		return nil, "", nil, err
	}
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		ws.Close()
		return nil, "", nil, err
	}
	var generic map[string]any
	_ = json.Unmarshal(raw, &generic)
	if generic["type"] == "error" {
		var em tunnel.ErrMsg
		_ = json.Unmarshal(raw, &em)
		ws.Close()
		return nil, "", &em, errors.New("rejected: " + em.Code)
	}
	var ready tunnel.ReadyMsg
	if err := json.Unmarshal(raw, &ready); err != nil || ready.Type != "ready" {
		ws.Close()
		return nil, "", nil, fmt.Errorf("unexpected reply %s", string(raw))
	}
	_ = ws.SetReadDeadline(time.Time{})
	return ws, ready.SSHHostKey, nil, nil
}

func (w *prodWorld) dialClient(token string) (*websocket.Conn, string, *tunnel.ErrMsg, error) {
	return w.dialClientAt(w.url, token)
}

// rawAgentHello dials the production agent leg and reads its challenge.
func (w *prodWorld) rawAgentHello() (*websocket.Conn, *tunnel.HostChallenge, error) {
	w.t.Helper()
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := dialer.Dial(w.url+"/api/v1/agent/connect", nil)
	if err != nil {
		return nil, nil, err
	}
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		ws.Close()
		return nil, nil, err
	}
	var ch tunnel.HostChallenge
	if err := json.Unmarshal(raw, &ch); err != nil || ch.Type != "challenge" {
		ws.Close()
		return nil, nil, fmt.Errorf("expected challenge, got %s", truncateForLog(raw))
	}
	return ws, &ch, nil
}

// rawAgentSendAuth signs ch with key and sends the auth frame.
func rawAgentSendAuth(t *testing.T, ws *websocket.Conn, key ed25519.PrivateKey, ch *tunnel.HostChallenge, deviceID string) error {
	t.Helper()
	ich, err := ch.ToIdentityChallenge(deviceID)
	if err != nil {
		return err
	}
	sig, err := identity.Sign(key, ich)
	if err != nil {
		return err
	}
	auth, _ := json.Marshal(tunnel.HostAuth{Type: "auth", V: tunnel.ProtocolVersion, DeviceID: deviceID, Signature: base64.StdEncoding.EncodeToString(sig)})
	_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
	return ws.WriteMessage(websocket.TextMessage, auth)
}

func rawAgentReadVerdict(ws *websocket.Conn) (string, error) {
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		return "closed", nil
	}
	return string(raw), nil
}

// sshOverConn runs a real SSH client over a post-ready client WebSocket with
// the INDEPENDENT host-key pin and runs the benign sentinel.
func sshOverConn(ws *websocket.Conn, pin ssh.PublicKey, userKey ssh.Signer) (*ssh.Client, string, error) {
	cl, err := sshClientOn(wsnet.Wrap(ws), ssh.FixedHostKey(pin), userKey)
	if err != nil {
		return nil, "", err
	}
	s, err := cl.NewSession()
	if err != nil {
		cl.Close()
		return cl, "", err
	}
	defer s.Close()
	out, err := s.CombinedOutput("echo " + sentinel)
	return cl, string(out), err
}

// sshClientOn runs the real SSH client over any transport (the wsnet wrap of
// a client WebSocket, or the freezer used by the slow-consumer test).
func sshClientOn(transport net.Conn, hk ssh.HostKeyCallback, userKey ssh.Signer) (*ssh.Client, error) {
	cfg := &ssh.ClientConfig{
		User:            "produser",
		Auth:            []ssh.AuthMethod{ssh.PublicKeys(userKey)},
		HostKeyCallback: hk,
		Timeout:         10 * time.Second,
	}
	c, chans, reqs, err := ssh.NewClientConn(transport, "tunnel", cfg)
	if err != nil {
		transport.Close()
		return nil, err
	}
	return ssh.NewClient(c, chans, reqs), nil
}

func samePinLine(a, b string) bool {
	na := strings.Fields(a)
	nb := strings.Fields(b)
	if len(na) < 2 || len(nb) < 2 {
		return false
	}
	return na[0] == nb[0] && na[1] == nb[1]
}

func waitWSClose(t *testing.T, ws *websocket.Conn, within time.Duration) error {
	t.Helper()
	done := make(chan error, 1)
	go func() {
		// No read deadline here: a deadline error would be OUR timeout, not
		// the server closing the connection. Only a real close (or protocol
		// error surfacing as one) ends this loop; the outer select bounds it.
		for {
			if _, _, err := ws.ReadMessage(); err != nil {
				done <- nil
				return
			}
		}
	}()
	select {
	case err := <-done:
		return err
	case <-time.After(within + 2*time.Second):
		return errors.New("timeout waiting for connection close")
	}
}

func recordProdResult(t *testing.T, id, detail string) {
	t.Helper()
	dir := filepath.Join("..", ".tmp", "security-logs")
	_ = os.MkdirAll(dir, 0o755)
	f, err := os.OpenFile(filepath.Join(dir, "results.jsonl"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	defer f.Close()
	v := "PASS"
	if t.Failed() {
		v = "FAIL"
	}
	_, _ = fmt.Fprintf(f, "{\"id\":%q,\"test\":%q,\"mode\":\"production-inprocess\",\"verdict\":%q,\"detail\":%q}\n",
		id, t.Name(), v, detail)
}

// --- P1: production positive control -------------------------------------------

func TestP1ProductionPositiveControl(t *testing.T) {
	w := newProdWorld(t, prodOptions{})
	w.startAgent()

	ws, advisory, em, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatalf("client dial: %v (em=%+v)", err, em)
	}
	// O1 cross-check: advisory metadata must match the independent pin —
	// and would be checked by a real client BEFORE any SSH userauth.
	if !samePinLine(w.pinLine, advisory) {
		t.Fatalf("advisory %q differs from independent pin %q", advisory, w.pinLine)
	}
	cl, out, err := sshOverConn(ws, parsePin(t, w.pinLine), w.clientSigner)
	if err != nil {
		t.Fatalf("SSH over production tunnel failed: %v", err)
	}
	defer cl.Close()
	if !strings.Contains(out, sentinel) {
		t.Fatalf("sentinel missing: %q", out)
	}
	st := w.sshd.Stats()
	if st.AuthAccepted != 1 || st.ShellsGranted != 1 {
		t.Fatalf("sshd counters: %+v", st)
	}
	recordProdResult(t, "P1", "real broker-token admission + real identity enrollment + real tunnel gateway + real hostagent: authorized key ran benign sentinel end-to-end")
}

// --- P2: wrong key / password denied over the production tunnel -----------------

func TestP2ProductionWrongKeyAndPasswordDenied(t *testing.T) {
	w := newProdWorld(t, prodOptions{})
	w.startAgent()

	ws, advisory, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	if !samePinLine(w.pinLine, advisory) {
		t.Fatal("advisory mismatch")
	}
	if _, _, err := sshOverConn(ws, parsePin(t, w.pinLine), w.otherSigner); err == nil {
		t.Fatal("unknown SSH key gained shell over the production tunnel")
	} else {
		t.Logf("unknown key rejected: %v", err)
	}

	// password-only attempt
	ws2, _, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	n := wsnet.Wrap(ws2)
	cfg := &ssh.ClientConfig{
		User:            "produser",
		Auth:            []ssh.AuthMethod{ssh.Password("totally-wrong")},
		HostKeyCallback: ssh.FixedHostKey(parsePin(t, w.pinLine)),
		Timeout:         10 * time.Second,
	}
	if _, _, _, err := ssh.NewClientConn(n, "tunnel", cfg); err == nil {
		t.Fatal("password authentication succeeded")
	} else if !strings.Contains(err.Error(), "no supported methods") {
		t.Errorf("expected no supported methods, got: %v", err)
	} else {
		t.Logf("password-only rejected: %v", err)
	}
	st := w.sshd.Stats()
	if st.AuthAccepted != 0 || st.ShellsGranted != 0 {
		t.Fatalf("sshd counters corrupted: %+v", st)
	}
	recordProdResult(t, "P2", "unknown key + password-only both denied by the home sshd through the production tunnel")
}

// --- P3: advisory host-key substitution fails before userauth -------------------

func TestP3ProductionHostKeySubstitutionBeforeAuth(t *testing.T) {
	w := newProdWorld(t, prodOptions{})
	w.startAgent()

	other, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	bogusLine := strings.TrimSpace(other.AuthorizedLine())
	clientPath := "/api/v1/hosts/" + w.deviceID + "/ssh"
	proxy := wsProxy(t, w.url+clientPath, nil, func(b []byte) []byte {
		var ready map[string]any
		if json.Unmarshal(b, &ready) == nil && ready["type"] == "ready" {
			ready["ssh_host_key"] = bogusLine
			out, _ := json.Marshal(ready)
			return out
		}
		return b
	})
	mitmSrv := httptest.NewServer(proxy)
	defer mitmSrv.Close()
	mitmURL := "ws" + strings.TrimPrefix(mitmSrv.URL, "http")

	// (a) A contract-abiding client cross-checks the advisory against the
	// independent pin and aborts BEFORE any SSH userauth. (The home sshd MAY
	// see a pre-auth transport connection: opening the client leg makes the
	// AGENT dial its own pinned loopback sshd — the trusted home side — but
	// no key attempt, attacker-controlled or otherwise, may happen.)
	baseline := w.sshd.Stats()
	ws, advisory, _, err := w.dialClientAt(mitmURL, w.aliceToken())
	if err != nil {
		t.Fatalf("MITM broke the client handshake itself: %v", err)
	}
	if samePinLine(w.pinLine, advisory) {
		t.Fatal("MITM-ready advisory unexpectedly matched the pin")
	}
	ws.Close() // the pin cross-check fails -> no SSH client is ever started
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if w.sshd.Stats().ClosedConns > baseline.ClosedConns {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if after := w.sshd.Stats(); after.AuthAttempts != baseline.AuthAttempts || after.AuthAccepted != baseline.AuthAccepted {
		t.Fatalf("userauth reached the home sshd under advisory substitution: %+v -> %+v", baseline, after)
	}

	// (b) The advisory rewrite is INERT against the pin: the tunnel's SSH
	// bytes are end-to-end, so a client that verifies the independent pin
	// still lands on the real home sshd with the real pinned key — the
	// rewritten metadata was never a trust source. (A MITM that wants to
	// substitute the SSH host key must terminate SSH itself, and then fails
	// the pin: that position is the reference suite's MITM, S3/D3.)
	ws2, _, _, err := w.dialClientAt(mitmURL, w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	before := w.sshd.Stats()
	cl, out, err := sshOverConn(ws2, parsePin(t, w.pinLine), w.clientSigner)
	if err != nil {
		t.Fatalf("pin-verified client failed through the metadata-rewriting MITM: %v", err)
	}
	cl.Close()
	if !strings.Contains(out, sentinel) {
		t.Fatalf("sentinel missing: %q", out)
	}
	if after := w.sshd.Stats(); after.AuthAccepted != before.AuthAccepted+1 || after.ShellsGranted != before.ShellsGranted+1 {
		t.Fatalf("session did not land on the real home sshd: %+v -> %+v", before, after)
	}
	t.Logf("advisory rewrite changed nothing: SSH session landed on the real pinned home sshd")
	recordProdResult(t, "P3", "rewritten ready metadata: contract client aborts pre-userauth; pin-verified client unaffected (session provably on the real home sshd); advisory is not a trust source")
}

// --- P4: device proof replay / wrong key / enrollment replay ---------------------

func TestP4ProductionDeviceProofReplayAndWrongKey(t *testing.T) {
	w := newProdWorld(t, prodOptions{})
	w.startAgent()

	// (a) wrong device key signs a fresh valid challenge for the enrolled device
	_, attKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	wsBad, chBad, err := w.rawAgentHello()
	if err != nil {
		t.Fatal(err)
	}
	if err := rawAgentSendAuth(t, wsBad, attKey, chBad, w.deviceID); err != nil {
		t.Fatal(err)
	}
	verdict, err := rawAgentReadVerdict(wsBad)
	wsBad.Close()
	if err == nil && strings.Contains(verdict, `"type":"ok"`) {
		t.Fatal("wrong device key authenticated to the production gateway")
	}
	t.Logf("wrong-key verdict: %s", truncateForLog([]byte(verdict)))

	// (b) host-leg replay: capture a REAL agent's signed auth frame through
	// a MITM proxy on a second enrolled device, then replay it against a
	// fresh challenge. The signature is valid — but over challenge #1.
	dev2 := "prod-dev-2"
	_, key2, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	w.enrollViaCLIContract(dev2, key2)

	var captured atomic.Pointer[string]
	agentPath := "/api/v1/agent/connect"
	proxy := wsProxy(t, w.url+agentPath, func(b []byte) []byte {
		var auth map[string]any
		if json.Unmarshal(b, &auth) == nil && auth["type"] == "auth" {
			s := string(b)
			captured.Store(&s)
		}
		return b
	}, nil)
	mitmSrv := httptest.NewServer(proxy)
	defer mitmSrv.Close()
	mitmURL := "ws" + strings.TrimPrefix(mitmSrv.URL, "http")

	agent2 := hostagent.NewAgent(hostagent.AgentConfig{
		ServerURL:        mitmURL, // dials THROUGH the capture proxy
		DeviceID:         dev2,
		Key:              key2,
		SSHHost:          w.sshd.Addr(),
		HandshakeTimeout: 5 * time.Second,
		Logger:           slog.New(slog.NewTextHandler(io.Discard, nil)),
	})
	ctx2, cancel2 := context.WithCancel(context.Background())
	defer cancel2()
	done2 := make(chan error, 1)
	go func() { done2 <- agent2.Run(ctx2) }()
	deadline := time.Now().Add(15 * time.Second)
	for time.Now().Before(deadline) {
		if captured.Load() != nil && w.svc.IsDeviceConnected(dev2) {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if captured.Load() == nil {
		t.Fatal("MITM never captured the agent auth frame")
	}

	ws2, ch2, err := w.rawAgentHello()
	if err != nil {
		t.Fatal(err)
	}
	_ = ws2.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if err := ws2.WriteMessage(websocket.TextMessage, []byte(*captured.Load())); err != nil {
		t.Fatal(err)
	}
	_ = ch2 // the NEW challenge is ignored by the replaying attacker
	verdict, err = rawAgentReadVerdict(ws2)
	ws2.Close()
	if err == nil && strings.Contains(verdict, `"type":"ok"`) {
		t.Fatal("replayed device proof authenticated a second host connection")
	}
	t.Logf("replay verdict: %s", truncateForLog([]byte(verdict)))

	// (c) enrollment challenge replay at the REAL identity API: the same
	// signed enrollment submitted twice must fail the second time (single-use
	// challenge consumption).
	repDev, repKey := "prod-replay-dev", mustDevKey(t)
	repTok := w.token(prodAliceSub, prodAliceEmail)
	apiBase := w.httpBase()
	status, chJSON := postJSONBody(t, apiBase+"/identity/v1/challenge", repTok,
		map[string]string{"device_id": repDev})
	if status != 200 {
		t.Fatalf("challenge status %d: %s", status, chJSON)
	}
	var chResp struct {
		ChallengeID string `json:"challenge_id"`
	}
	if err := json.Unmarshal(chJSON, &chResp); err != nil {
		t.Fatal(err)
	}
	// Build the canonical enrollment proof the server verifies.
	var wire struct {
		Nonce           string `json:"nonce"`
		ConnectionNonce string `json:"connection_nonce"`
		Domain          string `json:"domain"`
		ExpiresAt       int64  `json:"expires_at"`
	}
	if err := json.Unmarshal(chJSON, &wire); err != nil {
		t.Fatal(err)
	}
	ich, err := identity.ChallengeFromWire(chResp.ChallengeID, repDev, identity.GoogleAccountID(prodAliceSub),
		identity.RoleEnroll, identity.ProtocolIdentity, wire.Domain, wire.Nonce, wire.ConnectionNonce, wire.ExpiresAt)
	if err != nil {
		t.Fatal(err)
	}
	pub, _ := repKey.Public().(ed25519.PublicKey)
	sig, err := identity.SignEnrollment(repKey, pub, ich, w.pinLine, false)
	if err != nil {
		t.Fatal(err)
	}
	enrollBody := map[string]any{
		"device_id":    repDev,
		"public_key":   base64.StdEncoding.EncodeToString(pub),
		"ssh_host_key": w.pinLine,
		"challenge_id": chResp.ChallengeID,
		"signature":    base64.StdEncoding.EncodeToString(sig),
		"re_enroll":    false,
	}
	status, body := postJSONBody(t, apiBase+"/identity/v1/enroll", repTok, enrollBody)
	if status != 200 && status != 201 {
		t.Fatalf("canonical enrollment failed: HTTP %d %s", status, body)
	}
	status, body = postJSONBody(t, apiBase+"/identity/v1/enroll", repTok, enrollBody)
	if status == 200 || status == 201 {
		t.Fatalf("replayed enrollment ACCEPTED (HTTP %d): %s", status, body)
	}
	t.Logf("enrollment replay rejected: HTTP %d %s", status, body)

	// (d) modified proof denial: a correctly signed enrollment whose
	// ssh_host_key is then MODIFIED before submission must fail proof
	// verification — the signature covers the exact submitted values.
	modDev, modKey := "prod-modproof-dev", mustDevKey(t)
	status, chJSON = postJSONBody(t, apiBase+"/identity/v1/challenge", repTok,
		map[string]string{"device_id": modDev})
	if status != 200 {
		t.Fatalf("challenge status %d: %s", status, chJSON)
	}
	if err := json.Unmarshal(chJSON, &chResp); err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(chJSON, &wire); err != nil {
		t.Fatal(err)
	}
	ich, err = identity.ChallengeFromWire(chResp.ChallengeID, modDev, identity.GoogleAccountID(prodAliceSub),
		identity.RoleEnroll, identity.ProtocolIdentity, wire.Domain, wire.Nonce, wire.ConnectionNonce, wire.ExpiresAt)
	if err != nil {
		t.Fatal(err)
	}
	modPub, _ := modKey.Public().(ed25519.PublicKey)
	sig, err = identity.SignEnrollment(modKey, modPub, ich, w.pinLine, false)
	if err != nil {
		t.Fatal(err)
	}
	otherKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	modBody := map[string]any{
		"device_id":    modDev,
		"public_key":   base64.StdEncoding.EncodeToString(modPub),
		"ssh_host_key": strings.TrimSpace(otherKey.AuthorizedLine()), // MODIFIED after signing
		"challenge_id": chResp.ChallengeID,
		"signature":    base64.StdEncoding.EncodeToString(sig),
		"re_enroll":    false,
	}
	status, body = postJSONBody(t, apiBase+"/identity/v1/enroll", repTok, modBody)
	if status == 200 || status == 201 {
		t.Fatalf("MODIFIED enrollment proof ACCEPTED (HTTP %d): %s", status, body)
	}
	if !strings.Contains(string(body), "proof of possession") {
		t.Fatalf("modified proof rejected for the wrong reason: HTTP %d %s", status, body)
	}
	t.Logf("modified proof rejected: HTTP %d %s", status, body)

	if !w.svc.IsDeviceConnected(w.deviceID) {
		t.Fatal("honest agent displaced by attacker handshakes")
	}
	recordProdResult(t, "P4", "wrong device key, MITM-captured proof replay and enrollment challenge replay all rejected by the real gateway/identity API; honest agent stays connected")
}

func mustDevKey(t *testing.T) ed25519.PrivateKey {
	t.Helper()
	_, k, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	return k
}

// --- P5: cross-owner denial -------------------------------------------------------

func TestP5ProductionCrossOwnerDenied(t *testing.T) {
	w := newProdWorld(t, prodOptions{})
	w.startAgent()

	// bob is a VERIFIED, allowlisted account — but not this device's owner.
	_, _, em, err := w.dialClient(w.bobToken())
	if err == nil {
		t.Fatal("bob authenticated to alice's device")
	}
	if em == nil || em.Code != "not_found" {
		t.Fatalf("unexpected rejection shape: %+v", em)
	}
	t.Logf("cross-owner dial rejected: code=%q message=%q", em.Code, em.Message)

	// bob cannot revoke alice's device either (owner-checked at the API).
	apiBase := w.httpBase()
	if status := postJSONStatus(t, apiBase+"/identity/v1/devices/"+w.deviceID+"/revoke", w.bobToken(), nil); status != 404 {
		t.Fatalf("cross-owner revoke status %d, want 404", status)
	}
	// bob's device list never shows alice's devices.
	status, body := getJSON(t, apiBase+"/identity/v1/devices", w.bobToken())
	if status != 200 {
		t.Fatalf("list status %d", status)
	}
	if strings.Contains(string(body), w.deviceID) {
		t.Fatalf("bob's listing leaked alice's device: %s", body)
	}
	// eve is verified by Google-shaped identity but NOT allowlisted: the
	// verifier itself refuses her credential.
	_, _, emEve, err := w.dialClient(w.eveToken())
	if err == nil {
		t.Fatal("non-allowlisted account admitted")
	}
	if emEve == nil || emEve.Code != "unauthorized" {
		t.Fatalf("unexpected eve rejection shape: %+v", emEve)
	}
	if st := w.sshd.Stats(); st.Connections != 0 {
		t.Fatalf("attacker dials reached the home sshd: %+v", st)
	}
	recordProdResult(t, "P5", "verified non-owner denied at the routing layer (uniform not_found); cross-owner revoke 404; listing isolation; non-allowlisted credential refused by the real verifier")
}

// --- P6: loopback-only destination + protocol carries no destination ---------------

func TestP6ProductionLoopbackOnlyAndNoDestination(t *testing.T) {
	// (a) the agent's dial-target validation is loopback-only.
	if _, err := hostagent.ValidateLoopback("10.1.2.3:22"); err == nil {
		t.Fatal("non-loopback SSH target accepted by production agent validation")
	}
	if _, err := hostagent.ValidateLoopback("169.254.169.254:80"); err == nil {
		t.Fatal("link-local metadata endpoint accepted")
	}
	if _, err := hostagent.ValidateLoopback("internal-host:22"); err == nil {
		t.Fatal("hostname accepted")
	}
	if _, err := hostagent.ValidateLoopback("127.0.0.1:22"); err != nil {
		t.Fatalf("loopback target refused: %v", err)
	}

	// (b) the OPEN frame the gateway sends carries NO destination field:
	// arbitrary local destination selection is not expressible on the wire.
	w := newProdWorld(t, prodOptions{})
	raw, ch, err := w.rawAgentHello()
	if err != nil {
		t.Fatal(err)
	}
	if err := rawAgentSendAuth(t, raw, w.devKey, ch, w.deviceID); err != nil {
		t.Fatal(err)
	}
	verdict, err := rawAgentReadVerdict(raw)
	if err != nil || !strings.Contains(verdict, `"type":"ok"`) {
		t.Fatalf("raw agent handshake failed: %s %v", truncateForLog([]byte(verdict)), err)
	}
	clientDone := make(chan error, 1)
	go func() {
		_, _, _, err := w.dialClient(w.aliceToken())
		clientDone <- err
	}()
	_ = raw.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, openRaw, err := raw.ReadMessage()
	if err != nil {
		t.Fatalf("no OPEN frame arrived: %v", err)
	}
	f, err := tunnel.ParseFrame(openRaw)
	if err != nil {
		t.Fatalf("OPEN frame unparseable: %v", err)
	}
	if f.Type != tunnel.FrameOpen {
		t.Fatalf("expected OPEN frame, got type %d", f.Type)
	}
	if len(f.Payload) != 0 {
		t.Fatalf("OPEN frame carries %d payload bytes — an arbitrary-destination vector", len(f.Payload))
	}
	if c := w.probe.Count(); c != 0 {
		t.Fatalf("sensitive local service got connections: %d", c)
	}
	recordProdResult(t, "P6", "loopback-only validation enforced (private/link-local/hostname refused); OPEN frame has zero payload (no destination expressible); probe untouched")
}

// --- P7: revocation tears down active and denies future ------------------------------

func TestP7ProductionRevocation(t *testing.T) {
	w := newProdWorld(t, prodOptions{})
	w.startAgent()

	ws, advisory, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	if !samePinLine(w.pinLine, advisory) {
		t.Fatal("advisory mismatch")
	}
	cl, out, err := sshOverConn(ws, parsePin(t, w.pinLine), w.clientSigner)
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("pre-revoke baseline failed: %q %v", out, err)
	}

	// Revoke through the REAL identity HTTP API (owner-only, durable,
	// persist-before-notify).
	apiBase := w.httpBase()
	status := postJSONStatus(t, apiBase+"/identity/v1/devices/"+w.deviceID+"/revoke", w.aliceToken(), nil)
	if status != 200 {
		t.Fatalf("revoke HTTP status %d", status)
	}

	watchErr := make(chan error, 1)
	go func() { watchErr <- cl.Wait() }()
	select {
	case err := <-watchErr:
		t.Logf("active session torn down after revoke: %v", err)
	case <-time.After(10 * time.Second):
		t.Fatal("active session survived revocation")
	}

	select {
	case err := <-w.agentDone:
		if err == nil {
			t.Fatal("agent Run returned nil after revocation")
		}
		t.Logf("production agent Run returned: %v", err)
	case <-time.After(40 * time.Second):
		t.Fatal("agent never reported the revocation")
	}

	if _, _, em, err := w.dialClient(w.aliceToken()); err == nil {
		t.Fatal("client dial succeeded after revocation")
	} else {
		t.Logf("future dial denied (err=%v em=%+v)", err, em)
	}
	recordProdResult(t, "P7", "real API revocation: active session torn down, agent surfaced fatal rejection, future dials denied")
}

// --- P8: malformed frames fail closed -------------------------------------------------

func TestP8ProductionMalformedFrames(t *testing.T) {
	w := newProdWorld(t, prodOptions{})
	w.startAgent()

	// (a) binary frame instead of the JSON auth
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	wsA, _, err := dialer.Dial(w.url+"/api/v1/hosts/"+w.deviceID+"/ssh", nil)
	if err != nil {
		t.Fatal(err)
	}
	_ = wsA.SetWriteDeadline(time.Now().Add(5 * time.Second))
	_ = wsA.WriteMessage(websocket.BinaryMessage, []byte{0xff, 0x00, 0x01})
	if err := waitWSClose(t, wsA, 5*time.Second); err != nil {
		t.Fatalf("binary-instead-of-auth not closed: %v", err)
	}

	// (b) oversized frame after auth
	wsB, _, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	huge := make([]byte, 2<<20)
	_ = wsB.SetWriteDeadline(time.Now().Add(10 * time.Second))
	if err := wsB.WriteMessage(websocket.BinaryMessage, huge); err != nil {
		t.Logf("oversized write rejected by client limiter: %v", err)
	}
	if err := waitWSClose(t, wsB, 5*time.Second); err != nil {
		t.Fatalf("oversized frame did not close the client: %v", err)
	}

	// (c) garbage "SSH bytes" on an admitted client leg: the gateway treats
	// the leg as opaque and forwards, so the teardown must come from the
	// home sshd rejecting the invalid SSH version line (lab sshd bounds the
	// pre-auth phase like real sshd's LoginGraceTime) — end to end.
	garbageBase := w.sshd.Stats().ClosedConns
	wsC, _, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	_ = wsC.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if err := wsC.WriteMessage(websocket.BinaryMessage, []byte{0x01, 0x02, 0x03}); err != nil {
		t.Fatal(err)
	}
	if err := waitWSClose(t, wsC, 10*time.Second); err != nil {
		t.Fatalf("garbage-SSH-bytes session not torn down: %v", err)
	}
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) {
		if w.sshd.Stats().ClosedConns > garbageBase {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if after := w.sshd.Stats(); after.ClosedConns <= garbageBase {
		t.Fatalf("home sshd still holds the garbage stream's connection: %+v", after)
	}

	// (d) TEXT frame after the handshake (JSON after binary = violation)
	wsD, _, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	_ = wsD.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if err := wsD.WriteMessage(websocket.TextMessage, []byte(`{"type":"auth","v":1}`)); err != nil {
		t.Fatal(err)
	}
	if err := waitWSClose(t, wsD, 5*time.Second); err != nil {
		t.Fatalf("post-handshake JSON not closed: %v", err)
	}

	// the gateway still serves honest traffic after all of the above
	recStart := time.Now()
	ws, advisory, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatalf("gateway unhealthy after malformed frames: %v", err)
	}
	if !samePinLine(w.pinLine, advisory) {
		t.Fatal("advisory mismatch")
	}
	cl, out, err := sshOverConn(ws, parsePin(t, w.pinLine), w.clientSigner)
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("honest session broken after malformed-frame attackers: %q %v", out, err)
	}
	cl.Close()
	t.Logf("honest recovery after malformed frames: dial+SSH in %s", time.Since(recStart).Round(time.Millisecond))
	recordProdResult(t, "P8", "binary-before-auth, oversized, truncated-header and post-handshake-JSON frames each fail closed; honest sessions unaffected")
}

// --- P9: slow consumer bounded -----------------------------------------------------------

func TestP9ProductionSlowConsumerBounded(t *testing.T) {
	w := newProdWorld(t, prodOptions{mutateLimits: func(l *tunnel.Limits) {
		l.StreamWindow = 16 << 10
		l.WSWriteTimeout = 500 * time.Millisecond
		l.PongWait = 10 * time.Second
		l.PingInterval = 2 * time.Second
	}})
	// The agent runs with the SAME stream window as the gateway — the
	// shipped configuration (both sides resolve 64 KiB by default and the
	// relay passes the same -tunnel-stream-window to both roles' limits).
	// A mismatched-but-valid window configuration is a separate finding:
	// the mux does not negotiate the window on the wire (mux.go sendWin vs
	// receive enforcement), reported in .tmp/security-requests.md.
	w.startAgentFor(w.deviceID, w.devKey, func(l *tunnel.Limits) {
		l.StreamWindow = 16 << 10
	})

	ws, advisory, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	if !samePinLine(w.pinLine, advisory) {
		t.Fatal("advisory mismatch")
	}
	freezer := newWSFreezer(wsnet.Wrap(ws), 8192)
	t.Cleanup(freezer.Unfreeze)
	cl, err := sshClientOn(freezer, ssh.FixedHostKey(parsePin(t, w.pinLine)), w.clientSigner)
	if err != nil {
		t.Fatal(err)
	}
	s, err := cl.NewSession()
	if err != nil {
		t.Fatal(err)
	}
	if _, err := s.StdoutPipe(); err != nil {
		t.Fatal(err)
	}
	if err := s.Start("seq 1 200000"); err != nil {
		t.Fatal(err)
	}
	sessStart := time.Now()
	// The consumer freezes after the first 8KB. The gateway's writes to the
	// dead transport must hit WSWriteTimeout and tear the session down —
	// observable server-side: the home sshd's connection for the stalled
	// session closes (stream reset propagated host-ward) while the host
	// control connection survives.
	baselineClosed := w.sshd.Stats().ClosedConns
	deadline := time.Now().Add(15 * time.Second)
	killed := false
	for time.Now().Before(deadline) {
		if w.sshd.Stats().ClosedConns > baselineClosed {
			killed = true
			break
		}
		time.Sleep(100 * time.Millisecond)
	}
	elapsed := time.Since(sessStart)
	if !killed {
		t.Fatal("stalled client session was not killed within 15s: unbounded queue suspected")
	}
	if base := w.sshd.Stats(); base.Connections < 1 {
		t.Fatalf("unexpected sshd state: %+v", base)
	}
	// The stalled leg's death must not have taken the device down: the host
	// agent control connection survives and the gateway serves new clients.
	if !w.svc.IsDeviceConnected(w.deviceID) {
		t.Fatal("host control connection lost to a stalled client session")
	}
	ws2, _, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatalf("gateway unhealthy after slow-consumer kill: %v", err)
	}
	cl2, out, err := sshOverConn(ws2, parsePin(t, w.pinLine), w.clientSigner)
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("honest session broken after slow-kill: %q %v", out, err)
	}
	cl2.Close()
	t.Logf("stalled consumer killed in %s (sshd conn closed); service recovered", elapsed.Round(time.Millisecond))
	recordProdResult(t, "P9", fmt.Sprintf("stalled transport torn down in %s (production WSWriteTimeout/StreamWindow); host leg survived; gateway recovered", elapsed.Round(time.Millisecond)))
}

// --- P10: routing-credential boundary (real routingauth verifier) --------------------

func TestP10RoutingCredentialBoundary(t *testing.T) {
	w := newProdWorld(t, prodOptions{})

	t.Run("positive control", func(t *testing.T) {
		tok := w.aliceToken()
		if err := verifyToken(t, w.verifier, tok); err != nil {
			t.Fatalf("valid broker credential rejected: %v", err)
		}
	})
	negative := func(name, why string, mutate func(claims map[string]any) map[string]any, header map[string]any, tokenOverride string) {
		t.Run(name, func(t *testing.T) {
			var tok string
			if tokenOverride != "" {
				tok = tokenOverride
			} else {
				if header == nil {
					header = brokerHeader()
				}
				if mutate == nil {
					mutate = func(c map[string]any) map[string]any { return c }
				}
				claims := brokerClaims(w.brokerClock.Now().Unix(), prodAliceSub, prodAliceEmail, hostagent.BrokerMaxLifetime)
				tok = signRS256JWT(t, w.brokerKey, header, mutate(claims))
			}
			if err := verifyToken(t, w.verifier, tok); err == nil {
				t.Fatalf("accepted: %s", why)
			} else {
				t.Logf("%s rejected: %v", name, err)
			}
		})
	}
	mut := func(f func(map[string]any)) func(map[string]any) map[string]any {
		return func(c map[string]any) map[string]any {
			f(c)
			return c
		}
	}
	now := w.brokerClock.Now().Unix()

	negative("google issuer", "a Google ID token must never route SSH",
		mut(func(c map[string]any) { c["iss"] = "https://accounts.google.com" }), nil, "")
	negative("wrong audience", "token minted for another relying party",
		mut(func(c map[string]any) { c["aud"] = "other-service" }), nil, "")
	negative("audience array", "broker contract is a single string aud",
		mut(func(c map[string]any) { c["aud"] = []string{hostagent.BrokerAudience} }), nil, "")
	negative("wrong scope", "credential without the gateway route scope",
		mut(func(c map[string]any) { c["scope"] = "pocketshell.other" }), nil, "")
	negative("missing scope", "blank-check credential",
		mut(func(c map[string]any) { delete(c, "scope") }), nil, "")
	negative("expired", "already past exp",
		mut(func(c map[string]any) { c["exp"] = now - 60 }), nil, "")
	negative("zero expiry", "verifier did not propagate a lifetime",
		mut(func(c map[string]any) { c["exp"] = 0 }), nil, "")
	negative("lifetime beyond broker bound", "6-minute lifetime exceeds the 5-minute maximum",
		func(c map[string]any) map[string]any {
			return brokerClaims(now, prodAliceSub, prodAliceEmail, 6*time.Minute)
		}, nil, "")
	negative("future iat", "credential minted in the future",
		mut(func(c map[string]any) { c["iat"] = now + 600; c["nbf"] = now + 600; c["exp"] = now + 900 }), nil, "")
	negative("missing nbf", "broker always binds not-before",
		mut(func(c map[string]any) { delete(c, "nbf") }), nil, "")
	negative("unverified email", "email_verified=false",
		mut(func(c map[string]any) { c["email_verified"] = false }), nil, "")
	negative("empty subject", "no stable identity",
		mut(func(c map[string]any) { c["sub"] = "" }), nil, "")
	negative("non-allowlisted account", "verified but not enrolled in the rollout",
		func(c map[string]any) map[string]any {
			return brokerClaims(now, prodEveSub, prodEveEmail, hostagent.BrokerMaxLifetime)
		}, nil, "")
	negative("alg none", "unsigned token",
		nil, map[string]any{"alg": "none", "kid": brokerKid}, strings.Join([]string{
			b64urlRaw(t, []byte(`{"alg":"none","kid":"`+brokerKid+`"}`)),
			func() string {
				b, _ := json.Marshal(brokerClaims(now, prodAliceSub, prodAliceEmail, hostagent.BrokerMaxLifetime))
				return b64urlRaw(t, b)
			}(), "",
		}, "."))
	negative("bad signature", "signed by the wrong key",
		nil, nil, func() string {
			wrong, err := rsa.GenerateKey(rand.Reader, 2048)
			if err != nil {
				t.Fatal(err)
			}
			return signRS256JWT(t, wrong, brokerHeader(), brokerClaims(now, prodAliceSub, prodAliceEmail, hostagent.BrokerMaxLifetime))
		}())
	negative("unknown kid", "key not published by the broker JWKS",
		nil, map[string]any{"alg": "RS256", "kid": "ghost-kid"}, "")

	t.Run("expiry after admission wait", func(t *testing.T) {
		tok := w.aliceToken()
		if err := verifyToken(t, w.verifier, tok); err != nil {
			t.Fatal(err)
		}
		w.brokerClock.Advance(10 * time.Minute)
		if err := verifyToken(t, w.verifier, tok); err == nil {
			t.Fatal("credential accepted past its expiry")
		} else {
			t.Logf("expired credential re-rejected: %v", err)
		}
		// The gateway's admission path uses the same verifier: a client
		// presenting the expired credential is refused, even though the
		// device is enrolled and connected.
		w.startAgent()
		if _, _, em, err := w.dialClient(tok); err == nil {
			t.Fatal("expired credential admitted a client session")
		} else if em == nil || em.Code != "unauthorized" {
			t.Fatalf("unexpected admission shape: %+v", em)
		}
	})

	t.Run("f09 google token never leaves the machine", func(t *testing.T) {
		gtok := signRS256JWT(t, w.brokerKey, map[string]any{"alg": "RS256", "kid": brokerKid},
			googleShapedClaims(time.Now().Unix(), prodAliceSub, prodAliceEmail))
		// Local disclosure guard, production policy:
		if err := hostagent.ValidateBrokerCredential(gtok, hostagent.ProductionBrokerPolicy(), time.Now()); err == nil {
			t.Fatal("local guard accepted a Google ID token")
		} else if !strings.Contains(err.Error(), "GOOGLE") {
			t.Fatalf("guard rejected for the wrong reason: %v", err)
		} else {
			t.Logf("local guard: %v", err)
		}
		// The CLI-level Enroll must refuse BEFORE any HTTP request.
		hitsBefore := w.apiHit.Load()
		policy := hostagent.ProductionBrokerPolicy()
		if _, err := hostagent.Enroll(context.Background(), hostagent.EnrollRequest{
			APIBase:    w.httpBase(),
			Token:      gtok,
			Policy:     policy,
			DeviceID:   "prod-f09-dev",
			Key:        mustDevKey(t),
			SSHHostKey: w.pinLine,
		}); err == nil {
			t.Fatal("Enroll transmitted a Google ID token")
		}
		if hits := w.apiHit.Load(); hits != hitsBefore {
			t.Fatalf("Google token caused %d HTTP request(s); it must be refused locally with zero requests", hits-hitsBefore)
		}
		// And the broker-shaped lifetime ceiling is enforced locally too.
		longTok := signRS256JWT(t, w.brokerKey, brokerHeader(),
			brokerClaims(time.Now().Unix(), prodAliceSub, prodAliceEmail, 30*time.Minute))
		if err := hostagent.ValidateBrokerCredential(longTok, hostagent.BrokerPolicy{
			Issuer:      brokerIssuerLocal,
			Audience:    hostagent.BrokerAudience,
			Scope:       hostagent.BrokerScope,
			MaxLifetime: hostagent.BrokerMaxLifetime,
		}, time.Now()); err == nil {
			t.Fatal("local guard accepted a 30-minute credential")
		} else {
			t.Logf("lifetime guard: %v", err)
		}
	})

	recordProdResult(t, "P10", "real routingauth verifier: 16 credential-boundary negatives rejected, expiry-after-wait fails admission, Google ID token refused locally with zero HTTP")
}

// --- P11: session bound is separate from the admission credential --------------------

func TestP11SessionBoundSeparateFromAdmission(t *testing.T) {
	// Production constants: five-minute admission lifetime vs 12h default /
	// 24h hard session bound.
	if got := (tunnel.Limits{}.Resolved()).MaxSessionDuration; got != 12*time.Hour {
		t.Fatalf("default MaxSessionDuration = %s, want 12h", got)
	}
	if got := (tunnel.Limits{MaxSessionDuration: 100 * 24 * time.Hour}).Resolved().MaxSessionDuration; got != 24*time.Hour {
		t.Fatalf("hard ceiling: MaxSessionDuration = %s, want 24h clamp", got)
	}
	if routingauth.MaxTokenLifetime != 5*time.Minute {
		t.Fatalf("verifier lifetime bound = %s, want 5m", routingauth.MaxTokenLifetime)
	}
	if hostagent.BrokerMaxLifetime != 5*time.Minute {
		t.Fatalf("broker lifetime bound = %s, want 5m", hostagent.BrokerMaxLifetime)
	}

	w := newProdWorld(t, prodOptions{mutateLimits: func(l *tunnel.Limits) {
		l.MaxSessionDuration = 3 * time.Second // far inside the still-valid 5-minute credential
	}})
	w.startAgent()

	start := time.Now()
	ws, advisory, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	if !samePinLine(w.pinLine, advisory) {
		t.Fatal("advisory mismatch")
	}
	cl, out, err := sshOverConn(ws, parsePin(t, w.pinLine), w.clientSigner)
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("baseline session failed: %q %v", out, err)
	}
	// The session must die at the CONFIGURED bound while the admission
	// credential is still valid — no automatic reauthentication, no
	// unbounded session.
	done := make(chan error, 1)
	go func() { done <- cl.Wait() }()
	select {
	case werr := <-done:
		elapsed := time.Since(start)
		if elapsed < 2500*time.Millisecond {
			t.Fatalf("session killed too early (%s): the bound must be the configured MaxSessionDuration", elapsed)
		}
		if elapsed > 12*time.Second {
			t.Fatalf("session survived its bound for %s", elapsed)
		}
		t.Logf("session torn down at the configured bound after %s (credential still valid): %v", elapsed.Round(time.Millisecond), werr)
	case <-time.After(13 * time.Second):
		t.Fatal("session outlived MaxSessionDuration with a valid credential")
	}
	recordProdResult(t, "P11", "session torn down at the configured bound with a still-valid admission credential; defaults 12h/hard 24h; broker+verifier lifetime 5m; no mid-session reauth")
}

// --- P12: revocation with uncertain durability still contains ------------------------

type failingSync struct {
	fail atomic.Bool
}

func (f *failingSync) hook(*os.File) error {
	if f.fail.Load() {
		return errors.New("injected: fsync EIO")
	}
	return nil
}

func TestP12RevocationUncertainDurabilityContains(t *testing.T) {
	hook := &failingSync{}
	regPath := filepath.Join(t.TempDir(), "registry.json")
	w := newProdWorld(t, prodOptions{newStore: func(t *testing.T) identity.DeviceStore {
		fs, err := identity.NewFileStore(regPath,
			identity.WithDirSyncHook(hook.hook),
			identity.WithLimits(identity.Limits{MaxPerAccount: 32}))
		if err != nil {
			t.Fatal(err)
		}
		return fs
	}})
	w.startAgent()

	ws, advisory, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatal(err)
	}
	if !samePinLine(w.pinLine, advisory) {
		t.Fatal("advisory mismatch")
	}
	cl, out, err := sshOverConn(ws, parsePin(t, w.pinLine), w.clientSigner)
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("baseline failed: %q %v", out, err)
	}

	// Durability fault injected: the revocation IS applied (rename done,
	// dir fsync fails) but cannot be acknowledged. The HTTP layer must
	// answer 500 — and containment must fire anyway.
	hook.fail.Store(true)
	apiBase := w.httpBase()
	status, body := postJSONBody(t, apiBase+"/identity/v1/devices/"+w.deviceID+"/revoke", w.aliceToken(), nil)
	if status != 500 {
		t.Fatalf("uncertain revoke answered HTTP %d (%s); want 500 (no ACK while durability unproven)", status, body)
	}
	if !strings.Contains(string(body), "not acknowledged") {
		t.Fatalf("uncertain revoke body: %s", body)
	}
	t.Logf("uncertain revoke correctly NOT acknowledged: HTTP %d %s", status, body)

	// Containment despite the missing ACK: the ACTIVE SSH session dies.
	watchErr := make(chan error, 1)
	go func() { watchErr <- cl.Wait() }()
	select {
	case err := <-watchErr:
		t.Logf("active session torn down by UNCERTAIN revocation: %v", err)
	case <-time.After(10 * time.Second):
		t.Fatal("active session survived a durability-uncertain revocation")
	}

	// The applied state is on disk even though the caller got an error.
	raw, err := os.ReadFile(regPath)
	if err != nil {
		t.Fatal(err)
	}
	var disk struct {
		Devices []struct {
			ID      string `json:"ID"`
			Revoked bool   `json:"Revoked"`
		} `json:"devices"`
	}
	if err := json.Unmarshal(raw, &disk); err != nil {
		t.Fatalf("registry file unreadable: %v", err)
	}
	found := false
	for _, d := range disk.Devices {
		if d.ID == w.deviceID {
			found = true
			if !d.Revoked {
				t.Fatal("registry file does not carry the applied revocation")
			}
		}
	}
	if !found {
		t.Fatalf("device missing from the registry file: %s", raw)
	}

	// The device is already denied (revoked lookup wins over the file
	// ack): future dials AND future host registrations fail. Registration
	// denial is proven directly with a raw signed handshake — deterministic,
	// independent of the agent's retry loop (the agent's failure to SURFACE
	// the fatal rejection is P7's reported regression, not re-asserted here).
	if _, _, _, err := w.dialClient(w.aliceToken()); err == nil {
		t.Fatal("client admitted after revocation applied (uncertain)")
	}
	wsR, chR, err := w.rawAgentHello()
	if err != nil {
		t.Fatal(err)
	}
	if err := rawAgentSendAuth(t, wsR, w.devKey, chR, w.deviceID); err != nil {
		t.Fatal(err)
	}
	verdict, err := rawAgentReadVerdict(wsR)
	wsR.Close()
	if err == nil && strings.Contains(verdict, `"type":"ok"`) {
		t.Fatal("revoked device re-registered after an uncertain revocation")
	}
	t.Logf("future registration denied: %s", truncateForLog([]byte(verdict)))

	// Retry once durability is provable: the SAME revocation now
	// acknowledges 200 and stays terminal.
	hook.fail.Store(false)
	status, body = postJSONBody(t, apiBase+"/identity/v1/devices/"+w.deviceID+"/revoke", w.aliceToken(), nil)
	if status != 200 {
		t.Fatalf("durable revoke retry answered HTTP %d (%s); want 200", status, body)
	}
	if _, _, _, err := w.dialClient(w.aliceToken()); err == nil {
		t.Fatal("client admitted after durable revocation")
	}
	recordProdResult(t, "P12", "injected dir-fsync fault: revoke answered 500 (no ACK) yet the ACTIVE SSH session was torn down, applied state on disk, agent denied; retry after fault cleared acks 200 and stays terminal")
}

// --- P13: real CLI acceptance (enroll + run + show) ----------------------------------

func TestP13CLIAcceptance(t *testing.T) {
	if testing.Short() {
		t.Skip("CLI acceptance skipped in -short mode")
	}
	w := newProdWorld(t, prodOptions{})

	repoRoot, err := filepath.Abs("..")
	if err != nil {
		t.Fatal(err)
	}
	bin := filepath.Join(t.TempDir(), "pocketshell-link")
	build := exec.Command(testtoolchain.Go(t), "build", "-o", bin, "./cmd/pocketshell-link")
	build.Dir = repoRoot
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("building cmd/pocketshell-link failed: %v\n%s", err, out)
	}

	dir := t.TempDir()
	// The real CLI contract: --server with an explicit insecure-dev local
	// URL, token on stdin, dev broker issuer (production uses the sync
	// broker; the flag pair --insecure-dev + --dev-broker-issuer is the only
	// dev override).
	enroll := exec.Command(bin, "enroll",
		"--token-stdin",
		"--server", w.httpBase(), // http://127.0.0.1:port
		"--insecure-dev",
		"--dev-broker-issuer", brokerIssuerLocal,
		"--config-dir", dir,
		"--device-id", "cli-dev-1",
		"--ssh-host", w.sshd.Addr(),
	)
	enroll.Stdin = strings.NewReader(w.aliceToken() + "\n")
	enrollOut, err := enroll.CombinedOutput()
	if err != nil {
		t.Fatalf("CLI enroll failed: %v\n%s", err, enrollOut)
	}
	if !strings.Contains(string(enrollOut), "enrolled") {
		t.Fatalf("enroll output missing confirmation:\n%s", enrollOut)
	}
	t.Logf("CLI enroll output:\n%s", enrollOut)

	// show: prints the enrolled state without secrets.
	show := exec.Command(bin, "show", "--config-dir", dir)
	showOut, err := show.CombinedOutput()
	if err != nil {
		t.Fatalf("CLI show failed: %v\n%s", err, showOut)
	}
	if !strings.Contains(string(showOut), "cli-dev-1") || !strings.Contains(string(showOut), "pinned ssh host key") {
		t.Fatalf("show output incomplete:\n%s", showOut)
	}

	// run: the real agent process dials the production gateway.
	run := exec.Command(bin, "run", "--config-dir", dir, "--insecure-dev", "--verbose")
	var runErr bytes.Buffer
	run.Stderr = &runErr
	if err := run.Start(); err != nil {
		t.Fatalf("CLI run start: %v", err)
	}
	deadline := time.Now().Add(20 * time.Second)
	for time.Now().Before(deadline) {
		if w.svc.IsDeviceConnected("cli-dev-1") {
			break
		}
		if run.Process == nil {
			t.Fatalf("CLI run exited early:\n%s", runErr.String())
		}
		time.Sleep(100 * time.Millisecond)
	}
	if !w.svc.IsDeviceConnected("cli-dev-1") {
		_ = run.Process.Kill()
		_, _ = run.Process.Wait()
		t.Fatalf("CLI run never connected:\n%s", runErr.String())
	}

	// A real SSH client session rides the CLI-maintained tunnel.
	w.deviceID = "cli-dev-1" // dialClient targets the CLI's device
	ws, advisory, _, err := w.dialClient(w.aliceToken())
	if err != nil {
		t.Fatalf("client dial to CLI-managed device: %v", err)
	}
	if !samePinLine(w.pinLine, advisory) {
		t.Fatalf("advisory %q differs from pin %q", advisory, w.pinLine)
	}
	cl, out, err := sshOverConn(ws, parsePin(t, w.pinLine), w.clientSigner)
	if err != nil || !strings.Contains(out, sentinel) {
		t.Fatalf("SSH through CLI-run tunnel failed: %q %v", out, err)
	}
	cl.Close()
	w.deviceID = "prod-dev-1" // restore for cleanup paths

	// F-09 at the CLI boundary: a Google ID token on stdin is refused
	// locally, with zero HTTP requests and no device created.
	hitsBefore := w.apiHit.Load()
	bad := exec.Command(bin, "enroll",
		"--token-stdin",
		"--server", w.httpBase(),
		"--insecure-dev",
		"--config-dir", t.TempDir(),
		"--device-id", "cli-dev-2",
		"--ssh-host", w.sshd.Addr(),
	)
	gtok := signRS256JWT(t, w.brokerKey, map[string]any{"alg": "RS256", "kid": brokerKid},
		googleShapedClaims(time.Now().Unix(), prodAliceSub, prodAliceEmail))
	bad.Stdin = strings.NewReader(gtok + "\n")
	badOut, err := bad.CombinedOutput()
	if err == nil {
		t.Fatalf("CLI enrolled with a Google ID token:\n%s", badOut)
	}
	if !strings.Contains(string(badOut), "GOOGLE") {
		t.Fatalf("refusal did not name the credential type:\n%s", badOut)
	}
	if hits := w.apiHit.Load(); hits != hitsBefore {
		t.Fatalf("Google token caused %d HTTP request(s) from the CLI; want 0", hits-hitsBefore)
	}

	// Shut the CLI agent down; it must exit cleanly on SIGTERM.
	if err := run.Process.Signal(os.Interrupt); err != nil {
		t.Fatalf("interrupt CLI run: %v", err)
	}
	waitErr := make(chan error, 1)
	go func() { waitErr <- run.Wait() }()
	select {
	case err := <-waitErr:
		if ee, ok := err.(*exec.ExitError); ok && ee.ExitCode() != 0 {
			t.Fatalf("CLI run exit code %d:\n%s", ee.ExitCode(), runErr.String())
		}
	case <-time.After(10 * time.Second):
		_ = run.Process.Kill()
		t.Fatal("CLI run ignored SIGINT")
	}
	recordProdResult(t, "P13", "real CLI binary: enroll --token-stdin --server http://127.0.0.1 --insecure-dev --dev-broker-issuer enrolled via the real API, run connected, SSH sentinel rode the CLI tunnel, show printed the pin, Google token refused with zero HTTP")
}
