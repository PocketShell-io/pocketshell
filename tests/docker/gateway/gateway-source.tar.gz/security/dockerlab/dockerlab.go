// Package dockerlab orchestrates the Docker-executed topology of the
// security suite:
//
//	gateway container (adversarial fixture, single-file rootfs image)
//	   ⇡ ws (the only "public" leg; published to host 127.0.0.1, ephemeral)
//	real ssh(1) on the host —via secbridge stdio⇄WS— ⇘
//	home container: real OpenSSH sshd bound to 127.0.0.1 INSIDE the
//	container (no published host ports), secprobe (sensitive service),
//	destination-pinned secagent dialing out to the gateway.
//
// Everything is disposable: ephemeral keys, unique container/network names,
// full teardown in Cleanup. No public service is contacted; the only host
// port published is the gateway's own client leg on 127.0.0.1.
package dockerlab

import (
	"context"
	_ "embed"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/testtoolchain"
)

// Available reports whether the Docker CLI + daemon are usable.
func Available() bool {
	return exec.Command("docker", "info").Run() == nil
}

var (
	buildOnce sync.Once
	buildDir  string
	buildErr  error
)

// buildBinaries cross-compiles the four lab binaries once per test process.
func buildBinaries(t *testing.T) string {
	t.Helper()
	buildOnce.Do(func() {
		buildDir, buildErr = os.MkdirTemp("", "psec-lab-bin-")
		if buildErr != nil {
			return
		}
		for _, cmd := range []string{"secgw", "secagent", "secbridge", "secprobe"} {
			out := filepath.Join(buildDir, cmd)
			pkg := fmt.Sprintf("github.com/PocketShell-io/pocketshell-gateway/security/dockerlab/cmd/%s", cmd)
			c := exec.Command(testtoolchain.Go(t), "build", "-trimpath", "-o", out, pkg)
			c.Env = append(os.Environ(), "CGO_ENABLED=0", "GOOS=linux", "GOARCH=amd64")
			if b, err := c.CombinedOutput(); err != nil {
				buildErr = fmt.Errorf("build %s: %v: %s", cmd, err, b)
				return
			}
		}
	})
	if buildErr != nil {
		t.Fatalf("lab binary build: %v", buildErr)
	}
	return buildDir
}

// Lab is one disposable Docker topology.
type Lab struct {
	t         *testing.T
	binDir    string
	tmpDir    string
	network   string
	gwName    string
	homeName  string
	homeImage string
	gwPort    int    // host-loopback published port of the gateway client leg
	Token     string // lab account token
	clientKey string // path
	knownHsts string // path
}

var (
	nameSuffix = strconv.FormatInt(time.Now().UnixNano()%1_000_000_000, 10)
	tCounter   atomic.Int64
)

func tNext() int { return int(tCounter.Add(1)) }

// Start brings up the gateway + home containers. attacks is the secgw
// -attacks argument ("" = honest gateway).
func Start(t *testing.T, attacks string) *Lab {
	t.Helper()
	if !Available() {
		t.Fatal("Docker is required for the real OpenSSH security gates")
	}
	l := &Lab{
		t:        t,
		binDir:   buildBinaries(t),
		network:  fmt.Sprintf("psec-net-%s-%d", nameSuffix, tNext()),
		gwName:   fmt.Sprintf("psec-gw-%s-%d", nameSuffix, tNext()),
		homeName: fmt.Sprintf("psec-home-%s-%d", nameSuffix, tNext()),
	}
	l.homeImage = l.homeName + "-image"
	t.Cleanup(l.Teardown)

	var err error
	l.tmpDir, err = os.MkdirTemp("", "psec-lab-run-")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { os.RemoveAll(l.tmpDir) })

	// ephemeral client SSH key pair (real OpenSSH format for ssh(1))
	l.clientKey = filepath.Join(l.tmpDir, "client_key")
	run(t, "ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", l.clientKey)
	l.knownHsts = filepath.Join(l.tmpDir, "known_hosts")

	run(t, "docker", "network", "create", l.network)
	l.startGateway(attacks)
	l.startHome()
	l.waitHomeReady()
	l.pinHostKey()

	l.Token = l.httpGet(fmt.Sprintf("http://127.0.0.1:%d/lab/token", l.gwPort))
	if l.Token == "" {
		l.t.Fatal("empty lab token from gateway")
	}
	return l
}

// startGateway builds a single-file rootfs image from the static binary.
func (l *Lab) startGateway(attacks string) {
	l.t.Helper()
	img := "psec-gw-img-" + nameSuffix
	sh := fmt.Sprintf("tar -C %s -c secgw | docker import - %s", l.binDir, img)
	if b, err := exec.Command("sh", "-c", sh).CombinedOutput(); err != nil {
		l.t.Fatalf("import gw image: %v: %s", err, b)
	}
	args := []string{"docker", "run", "-d", "--name", l.gwName,
		"--network", l.network,
		"--network-alias", "gateway",
		"-p", "127.0.0.1::8080",
		"--entrypoint", "/secgw",
		img,
		"-listen", ":8080"}
	if attacks != "" {
		args = append(args, "-attacks", attacks)
	}
	run(l.t, args...)
	out := run(l.t, "docker", "port", l.gwName, "8080")
	l.gwPort = parseHostPort(l.t, out)
}

const homeStart = `#!/bin/sh
set -ex
rm -f /etc/ssh/ssh_host_*
ssh-keygen -A
cat > /etc/ssh/sshd_config <<'EOF'
Port 22
ListenAddress 127.0.0.1
HostKey /etc/ssh/ssh_host_ed25519_key
PermitRootLogin prohibit-password
PubkeyAuthentication yes
PasswordAuthentication no
KbdInteractiveAuthentication no
AuthorizedKeysFile /authorized_keys
PidFile /run/sshd.pid
LogLevel VERBOSE
EOF
mkdir -p /run/sshd
chmod 600 /authorized_keys
chown root:root /authorized_keys
/usr/sbin/sshd -E /sshd.log
/secprobe -listen 127.0.0.1:9999 -count-file /probe-count &
exec /secagent -gw ws://gateway:8080/host -admin http://gateway:8080 -device-id lab-device-1 -device-key /device.key -pinned-ssh 127.0.0.1:22 -status /agent-status
`

//go:embed Dockerfile
var homeDockerfile string

// buildHomeImage builds the declared fixture locally; missing images must never
// fall back to pulling an unrelated tag from a registry. Each lab owns its tag.
func buildHomeImage(tag string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	cmd := exec.CommandContext(ctx, "docker", "build", "--pull=false", "--tag", tag, "-")
	cmd.Stdin = strings.NewReader(homeDockerfile)
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("build OpenSSH fixture: %w: %s", err, out)
	}
	return nil
}

func (l *Lab) startHome() {
	l.t.Helper()
	if err := buildHomeImage(l.homeImage); err != nil {
		l.t.Fatal(err)
	}
	run(l.t, "docker", "create", "--pull=never", "--name", l.homeName,
		"--network", l.network,
		"--entrypoint", "/bin/sh",
		l.homeImage,
		"/psstart.sh")

	clientPub, err := os.ReadFile(l.clientKey + ".pub")
	if err != nil {
		l.t.Fatal(err)
	}
	l.copyHome("/psstart.sh", homeStart, 0o755)
	l.copyHome("/authorized_keys", string(clientPub)+"\n", 0o644)
	for _, b := range []string{"secagent", "secprobe"} {
		run(l.t, "docker", "cp", filepath.Join(l.binDir, b), l.homeName+":/"+b)
	}
	run(l.t, "docker", "start", l.homeName)
}

func (l *Lab) copyHome(name, content string, mode os.FileMode) {
	l.t.Helper()
	host := filepath.Join(l.tmpDir, "copy-"+strings.ReplaceAll(strings.TrimPrefix(name, "/"), "/", "-"))
	if err := os.WriteFile(host, []byte(content), mode); err != nil {
		l.t.Fatal(err)
	}
	run(l.t, "docker", "cp", host, l.homeName+":"+name)
}

// waitHomeReady polls the agent status file inside the home container.
func (l *Lab) waitHomeReady() {
	l.t.Helper()
	deadline := time.Now().Add(60 * time.Second)
	for time.Now().Before(deadline) {
		out, err := l.ExecHome("cat /agent-status 2>/dev/null")
		if err == nil && strings.TrimSpace(out) == "authed" {
			return
		}
		time.Sleep(500 * time.Millisecond)
	}
	logs, _ := l.ExecHome("cat /agent.log /sshd.log 2>&1")
	l.t.Fatalf("home never came up; logs:\n%s", logs)
}

// pinHostKey extracts the real home sshd host key and pins it into
// known_hosts (the enrollment step of the contract).
func (l *Lab) pinHostKey() {
	l.t.Helper()
	pub, _ := l.ExecHome("cat /etc/ssh/ssh_host_ed25519_key.pub")
	pub = strings.TrimSpace(pub)
	if pub == "" {
		l.t.Fatal("no host key published by home container")
	}
	if err := os.WriteFile(l.knownHsts,
		[]byte("pocketshell-lab "+pub+"\n"), 0o644); err != nil {
		l.t.Fatal(err)
	}
}

// ExecHome runs a command inside the home container.
func (l *Lab) ExecHome(cmd string) (string, error) {
	out, err := exec.Command("docker", "exec", l.homeName, "/bin/sh", "-c", cmd).CombinedOutput()
	return string(out), err
}

// ClientURL is the host-loopback URL of the gateway client leg.
func (l *Lab) ClientURL() string {
	return fmt.Sprintf("ws://127.0.0.1:%d/client", l.gwPort)
}

// RunSSH runs the host's real OpenSSH client with the lab client key.
func (l *Lab) RunSSH(t *testing.T, remoteCmd string, extraArgs ...string) (string, string, int) {
	return l.RunSSHAs(t, l.clientKey, remoteCmd, extraArgs...)
}

// RunSSHAs is RunSSH with an explicit client identity path (unknown-key
// tests pass a different ephemeral key).
func (l *Lab) RunSSHAs(t *testing.T, keyPath, remoteCmd string, extraArgs ...string) (stdout, stderr string, exit int) {
	t.Helper()
	bridge := filepath.Join(l.binDir, "secbridge")
	proxy := fmt.Sprintf("%s -url %s -token %s", bridge, l.ClientURL(), l.Token)
	base := []string{
		"-F", "none",
		"-i", keyPath,
		"-o", "UserKnownHostsFile=" + l.knownHsts,
		"-o", "GlobalKnownHostsFile=/dev/null",
		"-o", "HostKeyAlias=pocketshell-lab",
		"-o", "StrictHostKeyChecking=yes",
		"-o", "IdentitiesOnly=yes",
		"-o", "BatchMode=yes",
		"-o", "ConnectTimeout=15",
		"-o", "ProxyCommand=" + proxy,
	}
	cmd := exec.Command("ssh", append(base, extraArgs...)...)
	cmd.Args = append(cmd.Args, "root@pocketshell-lab", remoteCmd)
	var outBuf, errBuf strings.Builder
	cmd.Stdout = &outBuf
	cmd.Stderr = &errBuf
	err := cmd.Run()
	exit = 0
	if ee, ok := err.(*exec.ExitError); ok {
		exit = ee.ExitCode()
	} else if err != nil {
		t.Fatalf("ssh exec: %v", err)
	}
	return outBuf.String(), errBuf.String(), exit
}

// GWAttackerResult reads the compromised-gateway attacker outcome via the
// lab HTTP endpoint (the gateway container runs from a single-file rootfs
// and has no shell tools).
func (l *Lab) GWAttackerResult() (string, error) {
	out, err := exec.Command("wget", "-qO-", "-T", "3",
		fmt.Sprintf("http://127.0.0.1:%d/lab/attacker-result", l.gwPort)).Output()
	if err != nil || len(out) == 0 {
		return "", fmt.Errorf("no result yet (wget: %v)", err)
	}
	return strings.TrimSpace(string(out)), nil
}

// Teardown removes containers, the network and the lab-owned SSH image.
func (l *Lab) Teardown() {
	_ = exec.Command("docker", "rm", "-f", l.gwName, l.homeName).Run()
	_ = exec.Command("docker", "network", "rm", l.network).Run()
	_ = exec.Command("docker", "image", "rm", l.homeImage).Run()
}

// --- small helpers -----------------------------------------------------------

func run(t *testing.T, args ...string) string {
	t.Helper()
	out, err := exec.Command(args[0], args[1:]...).CombinedOutput()
	if err != nil {
		t.Fatalf("%v: %v\n%s", args, err, out)
	}
	return string(out)
}

func parseHostPort(t *testing.T, s string) int {
	t.Helper()
	re := regexp.MustCompile(`127\.0\.0\.1:(\d+)`)
	m := re.FindStringSubmatch(s)
	if m == nil {
		t.Fatalf("no published port in %q", s)
	}
	n, err := strconv.Atoi(m[1])
	if err != nil {
		t.Fatal(err)
	}
	return n
}

func (l *Lab) httpGet(url string) string {
	resp, err := http.Get(url)
	if err != nil {
		l.t.Logf("http get %s: %v", url, err)
		return ""
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(resp.Body)
	if err != nil {
		return ""
	}
	// tolerate a JSON error body: the token endpoint returns raw text
	var probe map[string]string
	if json.Valid(b) && json.Unmarshal(b, &probe) == nil {
		return ""
	}
	return strings.TrimSpace(string(b))
}
