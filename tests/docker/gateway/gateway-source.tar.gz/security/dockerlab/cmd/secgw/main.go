// secgw — the lab gateway fixture as a container binary. Serves the /host
// and /client legs plus lab-admin endpoints (token mint, device enrollment,
// attacker result file). This whole program is a TEST FIXTURE: production
// replaces it with internal/tunnel + internal/identity behind the real
// gateway process.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/security/sshlab"
)

type enrollReq struct {
	Token    string `json:"token"`
	DeviceID string `json:"device_id"`
	Pub      string `json:"pub_b64"`
	Proof    string `json:"proof_b64"`
}

func main() {
	listen := flag.String("listen", ":8080", "listen address")
	attacksFlag := flag.String("attacks", "", "csv: mitm, cross, subst=ADDR, shell")
	account := flag.String("account", "google:lab-acct-a", "lab account subject")
	resultFile := flag.String("result", "/attacker-result", "attacker outcome file")
	flag.Parse()

	reg := sshlab.NewRegistry()
	token := reg.MintAccountToken(sshlab.Principal{AccountID: *account, Email: "lab@invalid"})

	var attacks sshlab.AttackMode
	for _, a := range strings.Split(*attacksFlag, ",") {
		a = strings.TrimSpace(a)
		switch {
		case a == "mitm":
			attacks.HostKeyMITM = true
		case a == "cross":
			attacks.CrossConnect = true
		case a == "capture":
			attacks.CaptureProof = true
		case strings.HasPrefix(a, "subst="):
			attacks.SubstituteDest = strings.TrimPrefix(a, "subst=")
		case a == "shell":
			attacks.CaptureProof = true // capture not needed; marker for readability
		case a == "":
		default:
			log.Fatalf("unknown attack %q", a)
		}
	}

	mux := http.NewServeMux()
	gw, err := sshlab.NewGatewayOnMux(reg, attacks, mux)
	if err != nil {
		log.Fatal(err)
	}
	mux.HandleFunc("/lab/token", func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(token))
	})
	mux.HandleFunc("/lab/attacker-result", func(w http.ResponseWriter, r *http.Request) {
		b, err := os.ReadFile(*resultFile)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		_, _ = w.Write(b)
	})
	mux.HandleFunc("/lab/enroll", func(w http.ResponseWriter, r *http.Request) {
		var req enrollReq
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "bad request", 400)
			return
		}
		pub, err1 := sshlab.UnB64(req.Pub)
		proof, err2 := sshlab.UnB64(req.Proof)
		if err1 != nil || err2 != nil || len(pub) != 32 {
			http.Error(w, "bad fields", 400)
			return
		}
		if _, err := reg.Enroll(req.Token, req.DeviceID, pub, proof, nil); err != nil {
			http.Error(w, "enroll failed", 401)
			return
		}
		w.WriteHeader(204)
	})

	// Gateway-shell attacker mode: as soon as a device registers, the
	// "compromised gateway" opens a stream on the agent leg and tries SSH
	// with its own (unauthorized) key. Outcome lands in the result file.
	if strings.Contains(*attacksFlag, "shell") {
		go func() {
			own, err := sshlab.NewSSHKey()
			if err != nil {
				writeResult(*resultFile, "error: "+err.Error())
				return
			}
			deadline := time.Now().Add(60 * time.Second)
			for gw.HostConnCount() == 0 {
				if time.Now().After(deadline) {
					writeResult(*resultFile, "error: no host connected")
					return
				}
				time.Sleep(200 * time.Millisecond)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
			defer cancel()
			authErr, err := gw.ShellAttempt(ctx, own.Signer)
			switch {
			case err != nil:
				writeResult(*resultFile, "error: "+err.Error())
			case authErr != nil:
				// expected: the real home sshd rejected the gateway's key
				writeResult(*resultFile, "rejected: "+authErr.Error())
			default:
				writeResult(*resultFile, "SHELL-GRANTED") // would be a critical finding
			}
		}()
	}

	srv := &http.Server{Addr: *listen, Handler: mux, ReadHeaderTimeout: 10 * time.Second}
	log.Printf("secgw (lab fixture) listening on %s attacks=%q", *listen, *attacksFlag)
	log.Fatal(srv.ListenAndServe())
}

func writeResult(path, s string) {
	log.Printf("attacker outcome: %s", s)
	_ = os.WriteFile(path, []byte(fmt.Sprintf("%s\n", s)), 0o644)
}
