// secprobe — the "sensitive local service": a loopback-only listener inside
// the home container that counts every accepted connection into a file. The
// destination-pinning tests assert this count stays zero even when the
// gateway substitutes the stream destination.
package main

import (
	"flag"
	"io"
	"log"
	"net"
	"os"
	"strconv"
	"sync/atomic"
)

func main() {
	listen := flag.String("listen", "127.0.0.1:9999", "listen address (loopback only)")
	countFile := flag.String("count-file", "/probe-count", "connection count file")
	flag.Parse()

	l, err := net.Listen("tcp", *listen)
	if err != nil {
		log.Fatal(err)
	}
	var count atomic.Int64
	for {
		c, err := l.Accept()
		if err != nil {
			log.Fatal(err)
		}
		n := count.Add(1)
		_ = os.WriteFile(*countFile, []byte(strconv.FormatInt(n, 10)+"\n"), 0o644)
		go func() {
			defer c.Close()
			_, _ = io.Copy(io.Discard, c)
		}()
	}
}
