// secagent — the lab host agent as a container binary: generates (or loads)
// its device identity key, enrolls itself against the gateway's lab-admin
// endpoint, then runs the destination-pinned agent loop. FIXTURE: production
// replaces it with internal/hostagent + cmd/pocketshell-link.
package main

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/security/sshlab"
)

func main() {
	gw := flag.String("gw", "ws://gateway:8080/host", "host-leg ws url")
	admin := flag.String("admin", "http://gateway:8080", "lab admin http base")
	deviceID := flag.String("device-id", "lab-device-1", "device id")
	keyPath := flag.String("device-key", "/device.key", "device key file (created 0600 if missing)")
	pinnedSSH := flag.String("pinned-ssh", "127.0.0.1:22", "the ONLY local dial target")
	statusFile := flag.String("status", "/agent-status", "status file (authed when up)")
	flag.Parse()

	key, err := loadOrCreateKey(*keyPath)
	if err != nil {
		log.Fatal(err)
	}
	token, err := httpBody(*admin + "/lab/token")
	if err != nil {
		log.Fatalf("fetch lab token: %v", err)
	}
	if err := enroll(*admin, token, *deviceID, key); err != nil {
		log.Fatalf("enroll: %v", err)
	}
	log.Printf("device %s enrolled", *deviceID)

	ctx := context.Background()
	agent, err := sshlab.StartAgent(ctx, sshlab.AgentConfig{
		GatewayURL: *gw,
		DeviceID:   *deviceID,
		DeviceKey:  key,
		PinnedSSH:  *pinnedSSH,
	})
	if err != nil {
		log.Fatal(err)
	}
	if !agent.WaitAuthed(30 * time.Second) {
		log.Fatal("agent failed to authenticate")
	}
	_ = os.WriteFile(*statusFile, []byte("authed\n"), 0o644)
	log.Printf("agent online; pinned SSH endpoint %s", *pinnedSSH)
	select {} // run until the container stops
}

func loadOrCreateKey(path string) (*sshlab.DeviceKey, error) {
	if seed, err := os.ReadFile(path); err == nil {
		if len(seed) != ed25519.SeedSize {
			return nil, fmt.Errorf("bad key file size %d", len(seed))
		}
		return &sshlab.DeviceKey{Priv: ed25519.NewKeyFromSeed(seed), Pub: ed25519.NewKeyFromSeed(seed).Public().(ed25519.PublicKey)}, nil
	}
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, err
	}
	if err := os.WriteFile(path, priv.Seed(), 0o600); err != nil {
		return nil, err
	}
	return &sshlab.DeviceKey{Priv: priv, Pub: priv.Public().(ed25519.PublicKey)}, nil
}

func httpBody(url string) (string, error) {
	resp, err := http.Get(url)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}
	if resp.StatusCode != 200 {
		return "", fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return string(b), nil
}

func enroll(admin, token, deviceID string, key *sshlab.DeviceKey) error {
	body, _ := json.Marshal(map[string]string{
		"token":     token,
		"device_id": deviceID,
		"pub_b64":   sshlab.B64(key.Pub),
		"proof_b64": sshlab.B64(sshlab.EnrollProof(key, deviceID, "google:lab-acct-a")),
	})
	resp, err := http.Post(admin+"/lab/enroll", "application/json", bytes.NewReader(body))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 204 {
		b, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("HTTP %d: %s", resp.StatusCode, b)
	}
	return nil
}
