// secbridge — stdio ⇄ gateway WebSocket bridge for the real OpenSSH client.
// Used as the ssh(1) ProxyCommand: whatever ssh writes to stdin is carried as
// binary WebSocket frames to the gateway's client leg and vice versa. This
// mirrors the production contract "per-client WS endpoint sends raw SSH
// binary bytes after authentication" so real ssh interoperates unmodified.
package main

import (
	"context"
	"encoding/json"
	"flag"
	"io"
	"log"
	"os"

	"github.com/PocketShell-io/pocketshell-gateway/security/sshlab"
	"github.com/gorilla/websocket"
)

func main() {
	url := flag.String("url", "", "gateway client ws url")
	token := flag.String("token", "", "lab account token")
	flag.Parse()
	if *url == "" || *token == "" {
		log.Fatal("-url and -token required")
	}

	ws, err := sshlab.WSDial(context.Background(), *url)
	if err != nil {
		log.Fatal(err)
	}
	tok, _ := json.Marshal(map[string]string{"token": *token})
	if err := ws.WriteMessage(websocket.TextMessage, tok); err != nil {
		log.Fatal(err)
	}
	n := sshlab.NewWSNet(ws)

	go func() { // stdin → gateway
		buf := make([]byte, 32<<10)
		for {
			c, err := os.Stdin.Read(buf)
			if c > 0 {
				if _, werr := n.Write(buf[:c]); werr != nil {
					return
				}
			}
			if err != nil {
				return
			}
		}
	}()
	// gateway → stdout (n.Read surfaces text-frame protocol errors too)
	buf := make([]byte, 32<<10)
	for {
		c, err := n.Read(buf)
		if c > 0 {
			if _, werr := os.Stdout.Write(buf[:c]); werr != nil {
				return
			}
		}
		if err != nil {
			if msg, isProto := sshlab.ProtocolError(err); isProto {
				log.Fatalf("gateway: %s", msg)
			}
			log.Fatal(err)
		}
		if c == 0 && err == io.EOF {
			return
		}
	}
}
