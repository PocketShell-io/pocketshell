package dockerlab

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"testing"

	"github.com/PocketShell-io/pocketshell-gateway/internal/testtoolchain"
)

// A clean runner must build the real fixture without the historical cached
// pocketshell-test:ssh image. This gate requires Docker; absence is a failure.
func TestHomeImageFromAbsentTag(t *testing.T) {
	if !Available() {
		t.Fatal("Docker is required for the clean-image regression")
	}
	tag := fmt.Sprintf("psec-home-clean-%s-%d", nameSuffix, tNext())
	if out, err := exec.Command("docker", "image", "inspect", tag).CombinedOutput(); err == nil || !strings.Contains(string(out), "No such image") {
		t.Fatalf("must begin with an absent image tag: %v: %s", err, out)
	}
	t.Cleanup(func() {
		if out, err := exec.Command("docker", "image", "rm", tag).CombinedOutput(); err != nil {
			t.Errorf("remove owned fixture image: %v: %s", err, out)
		}
	})
	if err := buildHomeImage(tag); err != nil {
		t.Fatal(err)
	}
	out, err := exec.Command("docker", "run", "--rm", "--pull=never", "--entrypoint", "/usr/sbin/sshd", tag, "-V").CombinedOutput()
	if err != nil || !strings.Contains(string(out), "OpenSSH_") {
		t.Fatalf("real sshd from newly built image: %v: %s", err, out)
	}
}

// Exercise the actual startHome path without relying on a host cache. The
// fake CLI records operations only; the separate absent-tag test runs Docker.
func TestStartHomeBuildsOwnedImageBeforeCreate(t *testing.T) {
	tmp := t.TempDir()
	program := `package main
import ("encoding/json"; "os")
func main() {
 f, err := os.OpenFile(os.Getenv("DOCKERLAB_CALL_LOG"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0600)
 if err != nil { panic(err) }; defer f.Close()
 if err := json.NewEncoder(f).Encode(os.Args[1:]); err != nil { panic(err) }
}
`
	source := filepath.Join(tmp, "fake.go")
	if err := os.WriteFile(source, []byte(program), 0600); err != nil {
		t.Fatal(err)
	}
	name := "docker"
	if runtime.GOOS == "windows" {
		name += ".exe"
	}
	if out, err := exec.Command(testtoolchain.Go(t), "build", "-o", filepath.Join(tmp, name), source).CombinedOutput(); err != nil {
		t.Fatalf("build recording CLI: %v: %s", err, out)
	}
	log := filepath.Join(tmp, "calls.jsonl")
	t.Setenv("PATH", tmp+string(os.PathListSeparator)+os.Getenv("PATH"))
	t.Setenv("DOCKERLAB_CALL_LOG", log)
	clientKey := filepath.Join(tmp, "client-key")
	if err := os.WriteFile(clientKey+".pub", []byte("fixture-public-key\n"), 0600); err != nil {
		t.Fatal(err)
	}
	l := &Lab{t: t, binDir: tmp, tmpDir: tmp, network: "recording-net",
		homeName: "recording-home", homeImage: "recording-owned-image", clientKey: clientKey}
	l.startHome()
	data, err := os.ReadFile(log)
	if err != nil {
		t.Fatal(err)
	}
	var calls [][]string
	for _, line := range strings.Split(strings.TrimSpace(string(data)), "\n") {
		var args []string
		if err := json.Unmarshal([]byte(line), &args); err != nil {
			t.Fatal(err)
		}
		calls = append(calls, args)
	}
	if len(calls) < 2 || strings.Join(calls[0], " ") != "build --pull=false --tag recording-owned-image -" {
		t.Fatalf("startHome must build its owned image before create: %v", calls)
	}
	create := strings.Join(calls[1], " ")
	if create != "create --pull=never --name recording-home --network recording-net --entrypoint /bin/sh recording-owned-image /psstart.sh" {
		t.Fatalf("startHome must create from its built tag with pulls disabled: %v", calls)
	}
}
