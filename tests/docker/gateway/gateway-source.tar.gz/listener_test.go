package main

// A15 regressions: aggregate admission is bounded on the RAW listener,
// before TLS or HTTP parsing. Unparsed sockets, hijacked WebSocket
// sessions and mid-request connections all count against one semaphore;
// slots are released when the socket closes (hijack-safe) and on
// shutdown. Controlled small limits below prove the property; production
// runs maxServiceConns=256 / maxACMEConns=32.

import (
	"context"
	"fmt"
	"net"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/net/netutil"
)

// listenerBounds are the production factory's bounds, shortened for test
// speed. The factory itself — deadline wiring, MaxHeaderBytes, HTTP/2
// disabled — is exactly what main runs.
var listenerBounds = httpServerBounds{
	readHeaderTimeout: 5 * time.Second,
	readTimeout:       10 * time.Second,
	idleTimeout:       30 * time.Second,
	maxHeaderBytes:    prodMaxHeaderBytes,
}

// serveBounded starts the PRODUCTION server factory on an explicitly
// limited raw listener and returns its base URL plus the shutdown handle.
func serveBounded(t *testing.T, handler http.Handler, limit int) (baseURL string, shutdown func()) {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	srv := newGatewayServer(handler, nil, listenerBounds)
	limited := netutil.LimitListener(ln, limit)
	done := make(chan struct{})
	go func() {
		defer close(done)
		_ = srv.Serve(limited)
	}()
	return "http://" + ln.Addr().String(), func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		_ = srv.Shutdown(ctx)
		<-done
	}
}

// idleConn opens a TCP connection that sends nothing: it occupies an
// admission slot purely by having been accepted (pre-parse).
func idleConn(t *testing.T, addr string) net.Conn {
	t.Helper()
	c, err := net.DialTimeout("tcp", addr, 2*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	return c
}

func TestLimitListenerCapsBeforeRequestParsing(t *testing.T) {
	handlerHits := make(chan struct{}, 8)
	mux := http.NewServeMux()
	mux.HandleFunc("/probe", func(w http.ResponseWriter, _ *http.Request) {
		handlerHits <- struct{}{}
		w.WriteHeader(http.StatusOK)
	})
	baseURL, shutdown := serveBounded(t, mux, 2)
	defer shutdown()
	lnAddr := strings.TrimPrefix(baseURL, "http://")

	// Two accepted-but-silent sockets fill the pool before any HTTP
	// parsing happens on them.
	c1 := idleConn(t, lnAddr)
	defer c1.Close()
	c2 := idleConn(t, lnAddr)
	defer c2.Close()

	// A real client cannot be served while the unparsed sockets hold the
	// slots: admission is NOT based on HTTP-level reservation.
	errc := make(chan error, 1)
	go func() {
		res, err := http.Get(baseURL + "/probe")
		if err != nil {
			errc <- err
			return
		}
		res.Body.Close()
		errc <- nil
	}()
	select {
	case <-handlerHits:
		t.Fatal("request served while pre-parse sockets should have exhausted admission")
	case err := <-errc:
		if err == nil {
			t.Fatal("request completed while admission was full")
		}
		// expected: the client eventually times out / is not served
	case <-time.After(700 * time.Millisecond):
		// expected: still blocked, no handler hit
	}
	select {
	case <-handlerHits:
		t.Fatal("handler ran while admission was full")
	default:
	}

	// Disconnecting one unparsed socket frees its slot immediately —
	// release is close-based, not request-lifecycle-based.
	c1.Close()
	select {
	case <-handlerHits:
	case <-time.After(3 * time.Second):
		t.Fatal("request never served after a slot freed")
	}
	if err := <-errc; err != nil {
		t.Fatalf("probe after release failed: %v", err)
	}
}

func TestLimitListenerHijackedWebSocketCountsAndReleases(t *testing.T) {
	_, port := echoListener(t)
	r := testRelay()
	r.allowPrivateHosts = true
	baseURL, shutdown := serveBounded(t, r, 2)
	defer shutdown()
	lnAddr := strings.TrimPrefix(baseURL, "http://")

	// Slot 1: a hijacked WebSocket session (the http server no longer
	// owns this connection; the relay pipes it for its lifetime).
	ws, _, err := (&websocket.Dialer{HandshakeTimeout: 3 * time.Second}).
		Dial(fmt.Sprintf("ws://%s/?host=127.0.0.1&port=%d&token=good-token", lnAddr, port), nil)
	if err != nil {
		t.Fatal(err)
	}

	// Slot 2: another accepted-but-silent socket.
	c2 := idleConn(t, lnAddr)

	// The pool is full: a new request is not served.
	errc := make(chan error, 1)
	go func() {
		res, err := http.Get(baseURL + "/") // relay answers 426 to plain GETs
		if err == nil {
			res.Body.Close()
		}
		errc <- err
	}()
	select {
	case err := <-errc:
		if err == nil {
			t.Fatal("request served while a hijacked WS and an idle socket held the pool")
		}
	case <-time.After(700 * time.Millisecond):
	}

	// Closing the hijacked session releases its slot: the tunneling code
	// closing the underlying conn is exactly the release path.
	ws.Close()
	select {
	case err := <-errc:
		if err != nil {
			t.Fatalf("request after WS release failed: %v", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("request never served after hijacked WS closed")
	}
	c2.Close()
}

func TestLimitListenerShutdownReleasesSlots(t *testing.T) {
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
	baseURL, shutdown := serveBounded(t, mux, 1)
	lnAddr := strings.TrimPrefix(baseURL, "http://")

	// Fill the only slot with a silent socket.
	c := idleConn(t, lnAddr)

	// Shutdown must complete despite the held slot (server closes
	// tracked idle conns / cancels via context), and the bound listener
	// must stop accepting.
	done := make(chan struct{})
	go func() {
		shutdown()
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("shutdown did not complete while a slot was held")
	}
	c.Close()

	// After shutdown the listener refuses new work.
	if _, err := http.Get(baseURL + "/"); err == nil {
		t.Error("server served a request after shutdown")
	}
}

func TestLimitListenerIndependentPools(t *testing.T) {
	// The ACME pool is independent of the service pool: filling one must
	// never consume the other's slots, and closing a full pool releases
	// its blocked Accept.
	ln1, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln1.Close()
	ln2, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln2.Close()
	lim1 := netutil.LimitListener(ln1, 1)
	lim2 := netutil.LimitListener(ln2, 1)

	// Fill lim1's single slot: a client connects, Accept returns the
	// server-side conn and holds the slot until it closes.
	c1 := idleConn(t, ln1.Addr().String())
	defer c1.Close()
	conn1, err := lim1.Accept()
	if err != nil {
		t.Fatal(err)
	}
	defer conn1.Close()

	// lim1 at capacity: a further Accept blocks.
	blocked := make(chan error, 1)
	go func() {
		_, err := lim1.Accept()
		blocked <- err
	}()
	select {
	case err := <-blocked:
		t.Fatalf("blocked Accept returned while pool full: %v", err)
	case <-time.After(200 * time.Millisecond):
	}

	// lim2 is unaffected by lim1's held slot (independent semaphores).
	c2 := idleConn(t, ln2.Addr().String())
	defer c2.Close()
	conn2, err := lim2.Accept()
	if err != nil {
		t.Fatalf("independent pool wrongly blocked: %v", err)
	}
	conn2.Close()

	// lim1.Close releases the blocked Accept with an error.
	if err := lim1.Close(); err != nil {
		t.Fatalf("close: %v", err)
	}
	select {
	case err := <-blocked:
		if err == nil {
			t.Error("blocked Accept survived listener close with a nil error")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("blocked Accept did not unblock on listener close")
	}
}
