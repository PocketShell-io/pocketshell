package main

// Tests for the scoped-credential wiring (finding C2) against the REAL
// internal/routingauth module: the root factory maps operator flags onto
// routingauth.Config (five-minute contract lifetime, strict issuer,
// audience and scope), and the production expiry/context gate sits on top.
// The broker is a real in-test RSA key + JWKS endpoint served over TLS
// with a locally trusted CA — TLS verification is real, never skipped,
// and no http:// shim exists at the wiring site.

import (
	"context"
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"math/big"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/routingauth"
)

type testBroker struct {
	issuer    string // the exact iss claim (external-looking, https)
	jwksURL   string // local TLS endpoint the verifier may fetch
	key       *rsa.PrivateKey
	kid       string
	tlsClient *http.Client
	now       time.Time
	srv       *httptest.Server
}

func newTestBroker(t *testing.T) *testBroker {
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	b := &testBroker{
		issuer: "https://broker.example",
		key:    key,
		kid:    "test-key-1",
		now:    time.Now(),
	}
	// Real TLS with a real (test-CA) chain: the verifier's client trusts
	// exactly this CA, so certificate verification is exercised for real.
	b.srv = httptest.NewTLSServer(jwksHandler(b))
	t.Cleanup(b.srv.Close)
	b.tlsClient = trustedClient(t, b.srv)
	b.jwksURL = b.srv.URL + "/gateway/jwks"
	return b
}

// newPlainTestBroker is the subprocess fixture broker: a real RSA key and
// JWKS endpoint over PLAIN HTTP, pairing with the real binary's
// -broker-allow-insecure-dev opt-in (routingauth's own dev mode — token
// verification stays fully on; there is no insecure shim at the wiring
// site). Issued tokens verify against this endpoint over real HTTP, so the
// subprocess exercises the production identity/tunnel wiring end to end.
func newPlainTestBroker(t *testing.T) *testBroker {
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	b := &testBroker{
		issuer: "http://broker.example.dev",
		key:    key,
		kid:    "test-key-1",
		now:    time.Now(),
	}
	b.srv = httptest.NewServer(jwksHandler(b))
	t.Cleanup(b.srv.Close)
	b.tlsClient = b.srv.Client()
	b.jwksURL = b.srv.URL + "/gateway/jwks"
	return b
}

// jwksHandler serves the broker's RSA public key as a JWKS document.
func jwksHandler(b *testBroker) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		pub := b.key.Public().(*rsa.PublicKey)
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{
			"keys": []map[string]string{{
				"kty": "RSA",
				"alg": "RS256",
				"kid": b.kid,
				"n":   base64.RawURLEncoding.EncodeToString(pub.N.Bytes()),
				"e":   base64.RawURLEncoding.EncodeToString(big.NewInt(int64(pub.E)).Bytes()),
			}},
		})
	})
}

// trustedClient returns an http.Client whose RootCAs is exactly the test
// server's CA — real TLS verification, pinned to the fixture authority.
func trustedClient(t *testing.T, srv *httptest.Server) *http.Client {
	t.Helper()
	tr := srv.Client().Transport.(*http.Transport).Clone()
	return &http.Client{Transport: tr, Timeout: 10 * time.Second}
}

func (b *testBroker) sign(t *testing.T, claims map[string]any) string {
	t.Helper()
	b64 := func(v any) string {
		raw, err := json.Marshal(v)
		if err != nil {
			t.Fatal(err)
		}
		return base64.RawURLEncoding.EncodeToString(raw)
	}
	if _, ok := claims["scope"]; !ok {
		claims["scope"] = routingauth.ScopeGatewayRoute
	}
	head := b64(map[string]string{"alg": "RS256", "kid": b.kid})
	body := b64(claims)
	digest := sha256.Sum256([]byte(head + "." + body))
	sig, err := rsa.SignPKCS1v15(rand.Reader, b.key, crypto.SHA256, digest[:])
	if err != nil {
		t.Fatal(err)
	}
	return head + "." + body + "." + base64.RawURLEncoding.EncodeToString(sig)
}

func (b *testBroker) validClaims() map[string]any {
	return map[string]any{
		"iss":            b.issuer,
		"aud":            routingauth.Audience,
		"sub":            "sub-owner-1",
		"email":          "ops@example.com",
		"email_verified": true,
		"exp":            b.now.Add(4 * time.Minute).Unix(),
		"iat":            b.now.Unix(),
		"nbf":            b.now.Unix(),
		"scope":          routingauth.ScopeGatewayRoute,
	}
}

// newVerifierFor is the production wiring under test: the root factory
// over the real routingauth module, pointed at the test broker's TLS
// endpoint with its CA trusted.
func newVerifierFor(t *testing.T, b *testBroker, allow []string) identity.TokenVerifier {
	t.Helper()
	v, err := newBrokerVerifier(brokerConfig{
		issuer:   b.issuer,
		jwksURL:  b.jwksURL,
		audience: routingauth.Audience,
		allow:    allow,
		client:   b.tlsClient,
		clock:    func() time.Time { return b.now },
	})
	if err != nil {
		t.Fatal(err)
	}
	return v
}

func TestBrokerWiringAcceptsScopedToken(t *testing.T) {
	b := newTestBroker(t)
	v := newVerifierFor(t, b, []string{"ops@example.com"})

	p, err := v.VerifyToken(context.Background(), b.sign(t, b.validClaims()))
	if err != nil {
		t.Fatalf("valid broker token rejected: %v", err)
	}
	if p.AccountID != "google:sub-owner-1" {
		t.Errorf("AccountID = %q, want google:sub-owner-1 (stable issuer+sub)", p.AccountID)
	}
	if p.Email != "ops@example.com" {
		t.Errorf("Email = %q", p.Email)
	}
	if p.ExpiresAt.IsZero() || !p.ExpiresAt.After(b.now) {
		t.Errorf("ExpiresAt = %v, want populated future expiry carried into the principal", p.ExpiresAt)
	}
}

func TestBrokerWiringStrictContract(t *testing.T) {
	b := newTestBroker(t)
	v := newVerifierFor(t, b, []string{"ops@example.com"})

	cases := []struct {
		name   string
		mutate func(map[string]any)
	}{
		{"wrong issuer", func(c map[string]any) { c["iss"] = "https://evil.example" }},
		{"Google issuer (C2)", func(c map[string]any) {
			c["iss"] = "https://accounts.google.com"
			c["aud"] = "1035162854462-kkqius5o2ni136ed6l58iig5pdpeh4u6.apps.googleusercontent.com"
		}},
		{"wrong audience", func(c map[string]any) { c["aud"] = "pocketshell-sync" }},
		{"wrong scope", func(c map[string]any) { c["scope"] = "pocketshell.sync" }},
		{"missing scope", func(c map[string]any) { c["scope"] = "" }},
		{"expired", func(c map[string]any) { c["exp"] = b.now.Add(-time.Minute).Unix() }},
		{"zero expiry", func(c map[string]any) { c["exp"] = 0 }},
		{"lifetime over the 5m broker contract", func(c map[string]any) {
			c["iat"] = b.now.Add(-6 * time.Minute).Unix()
			c["exp"] = b.now.Add(4 * time.Minute).Unix()
		}},
		{"non-allowlisted owner", func(c map[string]any) { c["email"] = "stranger@example.com" }},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			claims := b.validClaims()
			tc.mutate(claims)
			if _, err := v.VerifyToken(context.Background(), b.sign(t, claims)); err == nil {
				t.Fatal("relaxed credential accepted — the new API must fail closed")
			}
		})
	}

	// Empty allowlist denies everyone (fail closed, wiring-level).
	denyAll := newVerifierFor(t, b, nil)
	if _, err := denyAll.VerifyToken(context.Background(), b.sign(t, b.validClaims())); err == nil {
		t.Error("empty allowlist must deny everyone")
	}
	// The gate re-checks cancellation at admission.
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	gate := expiryGate{inner: v}
	if _, err := gate.VerifyToken(ctx, b.sign(t, b.validClaims())); err == nil {
		t.Error("cancelled admission context must be rejected by the gate")
	}
}

func TestBrokerFactoryFailsClosedOnInsecureConfig(t *testing.T) {
	b := newTestBroker(t)
	// http:// JWKS: routingauth refuses it — the wiring site does not
	// carry (and must never grow) an insecure shim.
	_, err := newBrokerVerifier(brokerConfig{
		issuer:   b.issuer,
		jwksURL:  "http://127.0.0.1:1/gateway/jwks",
		audience: routingauth.Audience,
		allow:    []string{"ops@example.com"},
	})
	if err == nil {
		t.Fatal("http:// JWKS accepted — the insecure shim must stay removed")
	}
	// Missing issuer likewise.
	if _, err := newBrokerVerifier(brokerConfig{jwksURL: b.jwksURL, audience: routingauth.Audience}); err == nil {
		t.Fatal("missing issuer accepted")
	}
}

func TestBrokerFactoryInsecureDevIsTheModuleOptIn(t *testing.T) {
	// The dev fixture contract (-broker-allow-insecure-dev, Opus lab) is
	// routingauth's OWN AllowInsecureDev mode, not a root-side bypass: a
	// plain-http lab JWKS is accepted only when the flag is set, and the
	// token itself is still fully verified (signature, issuer, audience,
	// scope, lifetime, allowlist).
	b := newTestBroker(t)
	plain := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		pub := b.key.Public().(*rsa.PublicKey)
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{
			"keys": []map[string]string{{
				"kty": "RSA",
				"alg": "RS256",
				"kid": b.kid,
				"n":   base64.RawURLEncoding.EncodeToString(pub.N.Bytes()),
				"e":   base64.RawURLEncoding.EncodeToString(big.NewInt(int64(pub.E)).Bytes()),
			}},
		})
	}))
	t.Cleanup(plain.Close)
	insecure := brokerConfig{
		issuer:      "http://broker.example.dev",
		jwksURL:     plain.URL + "/gateway/jwks",
		audience:    routingauth.Audience,
		allow:       []string{"ops@example.com"},
		client:      plain.Client(),
		clock:       func() time.Time { return b.now },
		insecureDev: true,
	}
	claims := b.validClaims()
	claims["iss"] = insecure.issuer
	v, err := newBrokerVerifier(insecure)
	if err != nil {
		t.Fatalf("dev-insecure verifier refused: %v", err)
	}
	if _, err := v.VerifyToken(context.Background(), b.sign(t, claims)); err != nil {
		t.Fatalf("valid token rejected under dev-insecure mode: %v", err)
	}
	// The same config without the flag fails closed.
	insecure.insecureDev = false
	if _, err := newBrokerVerifier(insecure); err == nil {
		t.Fatal("plain-http broker URLs accepted without the dev opt-in")
	}
	// And a bad token is still a bad token in dev mode.
	insecure.insecureDev = true
	v2, err := newBrokerVerifier(insecure)
	if err != nil {
		t.Fatal(err)
	}
	bad := b.validClaims()
	bad["iss"] = insecure.issuer
	bad["scope"] = "pocketshell.sync"
	if _, err := v2.VerifyToken(context.Background(), b.sign(t, bad)); err == nil {
		t.Fatal("wrong-scope token accepted under dev-insecure mode")
	}
}

func TestExpiryGateRejectsZeroAndExpired(t *testing.T) {
	now := time.Now()
	gate := expiryGate{
		inner: stubVerifier{accountID: "google:x", email: "ops@example.com"},
		now:   func() time.Time { return now },
	}
	p, err := gate.VerifyToken(context.Background(), "good-bearer")
	if err != nil {
		t.Fatalf("populated future expiry must pass: %v", err)
	}
	if p.ExpiresAt.IsZero() {
		t.Fatal("gate must preserve the populated ExpiresAt")
	}

	zero := expiryGate{
		inner: zeroExpiryStub{},
		now:   func() time.Time { return now },
	}
	if _, err := zero.VerifyToken(context.Background(), "good-bearer"); err == nil {
		t.Error("zero-expiry principal must be rejected (identity round two item 9)")
	}

	expired := expiryGate{
		inner: fixedExpiryStub{at: now.Add(-time.Second)},
		now:   func() time.Time { return now },
	}
	if _, err := expired.VerifyToken(context.Background(), "good-bearer"); err == nil {
		t.Error("expired principal must be rejected")
	}
}

// zeroExpiryStub is the explicitly named stub for the zero-expiry case: it
// exists ONLY so the gate's rejection is proven against a verifier that
// forgets expiry. Production wiring (main) always wraps with the gate.
type zeroExpiryStub struct{}

func (zeroExpiryStub) VerifyToken(context.Context, string) (identity.Principal, error) {
	return identity.Principal{AccountID: "google:x", Email: "ops@example.com"}, nil
}

type fixedExpiryStub struct{ at time.Time }

func (s fixedExpiryStub) VerifyToken(context.Context, string) (identity.Principal, error) {
	return identity.Principal{AccountID: "google:x", Email: "ops@example.com", ExpiresAt: s.at}, nil
}
