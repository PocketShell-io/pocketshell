package main

// A19 and A18 regressions against the ACTUAL production wiring
// (handlerTracker.track(mux) + newGatewayServer + tls.NewListener +
// server.Serve — the exact composition run() serves, including the
// root-owned handler lifecycle wrapper):
//
//   - A19: the production TLS policy — built by the SHARED constructor
//     productionTLSConfig, the exact function run() calls — must never
//     negotiate HTTP/2 (h2 multiplexing would carry unbounded concurrent
//     streams per socket past the raw-connection admission cap and past
//     the per-request body budget). HTTP/1.1 stays fully functional over
//     fully VERIFIED TLS (the client trusts the fixture CA; verification
//     is never bypassed), and the autocert manager's cert selection
//     (GetCertificate + HostPolicy) stays functional through the factory.
//     The cached-certificate fixture proves selection only, never an ACME
//     issuance claim; the HTTP-01 challenge policy on :80 is untouched.
//   - A18: request bodies are read under a real transport deadline, and
//     the requests under test are CANONICAL — valid JSON, valid fields —
//     so earlier field validation cannot mask a deadline bug. Four
//     distinct stall shapes (silent body, incomplete JSON gone silent,
//     valid JSON with a stalled trailing body, transport read error) are
//     proven over plain HTTP AND over TLS. The read-error shape is not
//     allowed to pass vacuously: over plain TCP the client HALF-CLOSES
//     (write side only, read side retained) and the server's REAL response
//     bytes must arrive; over TLS (no half-close exists) the server-side
//     challenge counter — attached inside the production composition —
//     must record a completed handler with a non-2xx decision. A full
//     client close followed by a read of the same closed socket yields an
//     immediate local error and proves nothing, so it is never accepted as
//     evidence. No 2xx and no issued challenge anywhere: a device-absence
//     check alone cannot detect an erroneously issued challenge because
//     the challenge endpoint never creates a device. Closes happen within
//     the identity service's own network deadline (Config.RequestReadDeadline,
//     wired nonzero by the root factory) — far inside the whole-server
//     ReadTimeout, which remains only the weaker outer bound shared with
//     every other route. Upgraded (hijacked) WebSocket sessions — legacy
//     SSH proxy and tunnel clients alike — keep working far beyond the
//     HTTP request bound.

import (
	"bufio"
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"math/big"
	"net"
	"net/http"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/acme/autocert"
	"golang.org/x/net/netutil"

	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// --- fixtures ---------------------------------------------------------------

// memCertCache is an autocert.Cache preloaded with one certificate, so
// manager.GetCertificate works fully offline.
type memCertCache struct {
	data map[string][]byte
}

func (c *memCertCache) Get(_ context.Context, key string) ([]byte, error) {
	if b, ok := c.data[key]; ok {
		return b, nil
	}
	return nil, autocert.ErrCacheMiss
}

func (c *memCertCache) Put(_ context.Context, key string, b []byte) error {
	c.data[key] = b
	return nil
}

func (c *memCertCache) Delete(_ context.Context, key string) error {
	delete(c.data, key)
	return nil
}

// fixtureCA is the trusted test authority of the TLS regressions: client
// configurations trust EXACTLY this CA via RootCAs, so certificate
// verification is real end to end — no test bypasses it with
// InsecureSkipVerify.
type fixtureCA struct {
	caCert *x509.Certificate
	caKey  *ecdsa.PrivateKey
	pool   *x509.CertPool
}

func newFixtureCA(t *testing.T) *fixtureCA {
	t.Helper()
	caKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	tmpl := x509.Certificate{
		SerialNumber:          big.NewInt(1),
		Subject:               pkix.Name{CommonName: "pocketshell test CA"},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().Add(24 * time.Hour),
		KeyUsage:              x509.KeyUsageCertSign,
		BasicConstraintsValid: true,
		IsCA:                  true,
	}
	caDER, err := x509.CreateCertificate(rand.Reader, &tmpl, &tmpl, &caKey.PublicKey, caKey)
	if err != nil {
		t.Fatal(err)
	}
	caCert, err := x509.ParseCertificate(caDER)
	if err != nil {
		t.Fatal(err)
	}
	pool := x509.NewCertPool()
	pool.AddCert(caCert)
	return &fixtureCA{caCert: caCert, caKey: caKey, pool: pool}
}

// leafCertPEM mints one CA-signed leaf cert (with its private key —
// autocert's cache format is key PEM first, then the certificate chain,
// parsed via tls.X509KeyPair) for host. Test fixture only: the cached-cert
// fixtures prove SELECTION (GetCertificate/HostPolicy), never an ACME
// issuance claim.
func (f *fixtureCA) leafCertPEM(t *testing.T, host string) []byte {
	t.Helper()
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	tmpl := x509.Certificate{
		SerialNumber: big.NewInt(2),
		Subject:      pkix.Name{CommonName: host},
		DNSNames:     []string{host},
		NotBefore:    time.Now().Add(-time.Hour),
		NotAfter:     time.Now().Add(24 * time.Hour),
		KeyUsage:     x509.KeyUsageDigitalSignature,
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
	}
	der, err := x509.CreateCertificate(rand.Reader, &tmpl, f.caCert, &key.PublicKey, f.caKey)
	if err != nil {
		t.Fatal(err)
	}
	keyDER, err := x509.MarshalECPrivateKey(key)
	if err != nil {
		t.Fatal(err)
	}
	return append(
		pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDER}),
		pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})...,
	)
}

// clientConfig is a verification-complete client config for host: the
// fixture CA is the only trusted root, so a handshake either verifies the
// served chain for real or fails. Optional ALPN offerings.
func (f *fixtureCA) clientConfig(host string, alpn ...string) *tls.Config {
	cfg := &tls.Config{
		ServerName: host,
		RootCAs:    f.pool,
		MinVersion: tls.VersionTLS12,
	}
	if len(alpn) > 0 {
		cfg.NextProtos = alpn
	}
	return cfg
}

// serveProductionFactory starts the exact production wiring — the tracked
// handler (handlerTracker.track, the wrapper run() serves behind), bounded
// raw listener + (optionally TLS) factory server, Serve on tls.NewListener
// — and returns its host:port and a shutdown handle. The tracker wrapper
// is part of the production composition, so every regression here also
// exercises the ResponseController/Hijacker pass-through (identity's body
// deadline must survive the wrapper; WebSocket upgrades must hijack
// through it).
func serveProductionFactory(t *testing.T, handler http.Handler, tlsCfg *tls.Config, b httpServerBounds, limit int) (addr string, shutdown func()) {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	srv := newGatewayServer(newHandlerTracker().track(handler), tlsCfg, b)
	bounded := netutil.LimitListener(ln, limit)
	done := make(chan struct{})
	go func() {
		defer close(done)
		if tlsCfg != nil {
			_ = srv.Serve(tls.NewListener(bounded, srv.TLSConfig))
			return
		}
		_ = srv.Serve(bounded)
	}()
	shutdown = func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		_ = srv.Shutdown(ctx)
		<-done
	}
	return ln.Addr().String(), shutdown
}

// shortBounds are the factory bounds with production structure but
// test-speed deadlines (the production values are in the consts).
func shortBounds() httpServerBounds {
	return httpServerBounds{
		readHeaderTimeout: 300 * time.Millisecond,
		readTimeout:       500 * time.Millisecond,
		idleTimeout:       2 * time.Second,
		maxHeaderBytes:    prodMaxHeaderBytes,
	}
}

// longServerBounds keeps the production factory structure but a LONG
// whole-request read bound: the stalled-body regression below proves the
// identity service's own network deadline (testIdentityReadDeadline, wired
// through buildRegistryWith) closes stalled bodies well before the server
// bound could — the layering the strict-body discipline intends.
func longServerBounds() httpServerBounds {
	return httpServerBounds{
		readHeaderTimeout: 300 * time.Millisecond,
		readTimeout:       10 * time.Second,
		idleTimeout:       2 * time.Second,
		maxHeaderBytes:    prodMaxHeaderBytes,
	}
}

// --- A19: the shared production TLS policy, HTTP/2 disabled ------------------

// TestProductionTLSPolicyIsTheSharedConstructorH1Only tests the ACTUAL
// production constructor (productionTLSConfig — run() builds its listener
// config through this exact function) through the actual serving path: a
// client offering h2 AND http/1.1, verifying the served chain against the
// fixture CA (no verification bypass), must land on HTTP/1.1 and complete
// a real request, while the autocert manager's certificate SELECTION
// (cached fixture cert + HostPolicy) stays functional. The cached
// certificate proves selection only — never an ACME issuance claim; the
// deliberate HTTP-01 policy on :80 is untouched by this test.
func TestProductionTLSPolicyIsTheSharedConstructorH1Only(t *testing.T) {
	const host = "gateway.test"
	ca := newFixtureCA(t)

	// The constructor IS the policy: pins, not parallels.
	pol := productionTLSConfig(nil)
	if got := pol.NextProtos; len(got) != 1 || got[0] != "http/1.1" {
		t.Fatalf("productionTLSConfig ALPN = %v, want exactly [http/1.1]", got)
	}
	if pol.MinVersion != tls.VersionTLS12 {
		t.Fatalf("productionTLSConfig MinVersion = %v, want TLS 1.2", pol.MinVersion)
	}
	if pol.GetCertificate != nil {
		t.Fatal("productionTLSConfig must pass the caller's GetCertificate through")
	}

	cache := &memCertCache{data: map[string][]byte{host: ca.leafCertPEM(t, host)}}
	manager := &autocert.Manager{
		Prompt:     autocert.AcceptTOS,
		HostPolicy: hostWhitelist(host),
		Cache:      cache,
	}
	r := testRelay()
	tlsCfg := productionTLSConfig(manager.GetCertificate)
	addr, shutdown := serveProductionFactory(t, newHandler(r, nil), tlsCfg, serviceServerBounds, maxServiceConns)
	defer shutdown()

	// A client offering both h2 and http/1.1 must land on HTTP/1.1 over a
	// chain it can VERIFY (fixture CA), and a normal request over that
	// connection must work end to end.
	conn, err := tls.DialWithDialer(&net.Dialer{Timeout: 3 * time.Second}, "tcp", addr, ca.clientConfig(host, "h2", "http/1.1"))
	if err != nil {
		t.Fatalf("verified TLS dial offering h2+http/1.1: %v", err)
	}
	defer conn.Close()
	if got := conn.ConnectionState().NegotiatedProtocol; got != "http/1.1" {
		t.Fatalf("negotiated ALPN %q, want http/1.1 (HTTP/2 must stay disabled on the gateway)", got)
	}
	if !conn.ConnectionState().HandshakeComplete || len(conn.ConnectionState().PeerCertificates) == 0 {
		t.Fatal("handshake did not complete with a served certificate chain")
	}
	req := "GET /healthz HTTP/1.1\r\nHost: " + host + "\r\nConnection: close\r\n\r\n"
	if _, err := conn.Write([]byte(req)); err != nil {
		t.Fatal(err)
	}
	res, err := http.ReadResponse(bufio.NewReader(conn), nil)
	if err != nil {
		t.Fatalf("HTTP/1.1 request over the negotiated connection: %v", err)
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("healthz over HTTP/1.1 = %d, want 200", res.StatusCode)
	}
	var h map[string]string
	if err := json.NewDecoder(res.Body).Decode(&h); err != nil || h["service"] != "pocketshell-gateway" {
		t.Fatalf("healthz body = %v err=%v", h, err)
	}

	// The production server object carries the explicit h2 kill switch.
	srv := newGatewayServer(nil, tlsCfg, serviceServerBounds)
	if srv.TLSNextProto == nil || len(srv.TLSNextProto) != 0 {
		t.Fatalf("TLSNextProto = %#v, want a non-nil empty map (net/http must never register its h2 handler)", srv.TLSNextProto)
	}

	// The autocert configuration stays functional through the factory: a
	// whitelisted SNI completes a VERIFIED handshake with the manager's
	// cached certificate; a non-whitelisted SNI is refused before any
	// certificate exists.
	ok, err := tls.DialWithDialer(&net.Dialer{Timeout: 3 * time.Second}, "tcp", addr, ca.clientConfig(host, "http/1.1"))
	if err != nil {
		t.Fatalf("cert selection broken for whitelisted host: %v", err)
	}
	ok.Close()
	if _, err := tls.DialWithDialer(&net.Dialer{Timeout: 3 * time.Second}, "tcp", addr,
		&tls.Config{ServerName: "evil.test", RootCAs: ca.pool}); err == nil {
		t.Fatal("non-whitelisted SNI completed a handshake — autocert HostPolicy bypassed")
	}
}

// --- A18: bounded request-body reads, canonical requests, inspected responses -

// stalledCase is one canonical identity request whose body never reaches
// its definitive end. The shapes are DISTINCT (the old regression sent the
// same incomplete-JSON-plus-whitespace body for every case name), and the
// valid-JSON shape is fully canonical — valid fields, valid device id — so
// earlier invalid-field validation cannot mask a deadline bug: only the
// strict decoder's definitive-END discipline can stall it.
type stalledCase struct {
	name       string
	deviceID   string
	contentLen int    // advertised Content-Length (never satisfied where it matters)
	body       string // bytes written immediately after the headers
	drip       bool   // keep the body alive with trailing whitespace drips
	abort      bool   // write the body then end the write side abruptly (read-error case; half-close where the transport supports it)
}

// stalledCases covers the four stall shapes the corrections demand:
//   - silent: headers only, the body never starts;
//   - incomplete-silent: an OPEN JSON object then silence (the strict
//     decoder must wait for more input);
//   - valid-trailing-stall: a COMPLETE canonical JSON value followed by
//     whitespace drips under an unsatisfied Content-Length — the first
//     decode succeeds, and only the "second decode must return exactly
//     io.EOF" definitive-end discipline keeps waiting;
//   - read-error: a short body then the client's write side ends abruptly
//     (TCP half-close retaining the read side; a full close on TLS, where
//     the server-side counter carries the proof).
var stalledCases = []stalledCase{
	{name: "silent-body", deviceID: "stall-silent", contentLen: 512, body: ""},
	{name: "incomplete-json-silent", deviceID: "stall-open", contentLen: 512,
		body: `{"device_id":"stall-open"`},
	{name: "valid-json-stalled-trailer", deviceID: "stall-trailer", contentLen: 512,
		body: `{"device_id":"stall-trailer"}`, drip: true},
	{name: "read-error", deviceID: "stall-abort", contentLen: 512,
		body: `{"device_id":"stall-abort"}`, abort: true},
}

// stalledConn opens a real connection (plain TCP or TLS with the fixture
// CA — verification complete, never bypassed), sends complete request
// headers for an identity challenge, then applies the case's body shape.
func stalledConn(t *testing.T, addr, tlsHost string, ca *fixtureCA, c stalledCase) net.Conn {
	t.Helper()
	var conn net.Conn
	var err error
	if ca != nil {
		conn, err = tls.DialWithDialer(&net.Dialer{Timeout: 2 * time.Second}, "tcp", addr, ca.clientConfig(tlsHost, "http/1.1"))
	} else {
		conn, err = net.DialTimeout("tcp", addr, 2*time.Second)
	}
	if err != nil {
		t.Fatalf("dial %s: %v", c.name, err)
	}
	head := fmt.Sprintf("POST /identity/v1/challenge HTTP/1.1\r\n"+
		"Host: %s\r\nAuthorization: Bearer good-bearer\r\n"+
		"Content-Type: application/json\r\nContent-Length: %d\r\n\r\n", tlsHost, c.contentLen)
	if _, err := conn.Write([]byte(head)); err != nil {
		t.Fatalf("%s: headers: %v", c.name, err)
	}
	if c.body != "" {
		if _, err := conn.Write([]byte(c.body)); err != nil {
			t.Fatalf("%s: body: %v", c.name, err)
		}
	}
	if c.abort {
		// Read-error shape: the request is short of its Content-Length and
		// the client vanishes — the server's body read fails, it must never
		// turn into an issued challenge. Where the transport supports it
		// (plain TCP), only the WRITE side is closed: the client RETAINS
		// its read side, so the server's actual response can be received
		// and inspected — a full close would make every later read an
		// immediate local error and the no-challenge assertion vacuous.
		// TLS has no half-close; there the observation is server-side, via
		// the challenge counter (see the test).
		if tc, ok := conn.(*net.TCPConn); ok {
			if err := tc.CloseWrite(); err != nil {
				t.Fatalf("%s: half-close: %v", c.name, err)
			}
			return conn
		}
		_ = conn.Close()
		return conn
	}
	if c.drip {
		go func() {
			tick := time.NewTicker(40 * time.Millisecond)
			defer tick.Stop()
			for range tick.C {
				if _, err := conn.Write([]byte(" ")); err != nil {
					return
				}
			}
		}()
	}
	return conn
}

// readUntilClose reads everything the server sends back until the
// connection closes, within `within`. A read TIMEOUT on our side is a
// failure: it means the connection is still open and only our own deadline
// fired (the false pass the corrections forbid). Returns the collected
// bytes so the ACTUAL response can be inspected — the old helper discarded
// them, which made "no issued challenge" unprovable.
func readUntilClose(t *testing.T, conn net.Conn, within time.Duration) []byte {
	t.Helper()
	conn.SetReadDeadline(time.Now().Add(within))
	var out []byte
	buf := make([]byte, 1024)
	for {
		n, err := conn.Read(buf)
		out = append(out, buf[:n]...)
		if err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				t.Fatalf("connection still open after %s — the transport body deadline is not enforced", within)
			}
			return out
		}
	}
}

// assertNoChallengeIssued inspects the actual response bytes: no 2xx
// status line and no challenge payload may appear. The challenge endpoint
// never creates device state, so a GetDevice absence check alone cannot
// detect an erroneously issued challenge; the response bytes are the
// issuance signal available at the root wiring (the identity package's
// per-account outstanding-challenge count is not exported).
func assertNoChallengeIssued(t *testing.T, res []byte, what string) {
	t.Helper()
	if bytes.Contains(res, []byte(" 200 ")) || bytes.Contains(res, []byte("201 ")) {
		t.Fatalf("%s: server answered 2xx on a request that never completed its body: %q", what, res)
	}
	if bytes.Contains(res, []byte("challenge_id")) {
		t.Fatalf("%s: a challenge was issued for a request that never completed its body: %q", what, res)
	}
}

// challengeCounter is the SERVER-SIDE issuance observability for the
// read-error shape over TLS (which has no half-close, so the client cannot
// retain a read side and inspect the wire). It wraps the SAME handler the
// production factory serves — inside tracker.track(newHandler(...)), not a
// parallel path — and records, for every completed /identity/v1/challenge
// request, the response status the handler actually decided on. The status
// is the issuance signal: a 2xx here is an issued challenge. The record is
// taken after ServeHTTP returns, so a completion also proves HANDLER
// COMPLETION — including when the client transport has already vanished.
type challengeCounter struct {
	mu        sync.Mutex
	statuses  []int
	completed chan struct{} // signals every recorded completion
}

func newChallengeCounter() *challengeCounter {
	return &challengeCounter{completed: make(chan struct{}, 64)}
}

// wrap mounts the recorder around next for the challenge path only; other
// routes (including every WebSocket upgrade) pass through untouched, so the
// Hijacker contract is never crossed by the recorder.
func (c *challengeCounter) wrap(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		if req.URL.Path != "/identity/v1/challenge" {
			next.ServeHTTP(w, req)
			return
		}
		rec := &challengeStatusRecorder{ResponseWriter: w}
		next.ServeHTTP(rec, req)
		c.mu.Lock()
		c.statuses = append(c.statuses, rec.status)
		c.mu.Unlock()
		c.completed <- struct{}{}
	})
}

// snapshot returns the statuses recorded so far, oldest first.
func (c *challengeCounter) snapshot() []int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return append([]int(nil), c.statuses...)
}

// waitForCompletions blocks until at least n completions are recorded or
// the window expires (failure: the handler never completed, so
// non-admission after the transport read error is UNPROVEN).
func (c *challengeCounter) waitForCompletions(t *testing.T, n int, within time.Duration) []int {
	t.Helper()
	deadline := time.After(within)
	for {
		got := c.snapshot()
		if len(got) >= n {
			return got
		}
		select {
		case <-c.completed:
		case <-deadline:
			t.Fatalf("challenge handler completed only %d/%d times within %s (statuses so far: %v)",
				len(got), n, within, got)
		}
	}
}

// challengeStatusRecorder captures the response status the handler wrote.
// Unwrap keeps http.ResponseController (identity's SetReadDeadline body
// deadline) functional across the recorder; Flush is forwarded.
type challengeStatusRecorder struct {
	http.ResponseWriter
	status int
}

func (r *challengeStatusRecorder) WriteHeader(code int) {
	if r.status == 0 {
		r.status = code
	}
	r.ResponseWriter.WriteHeader(code)
}

func (r *challengeStatusRecorder) Write(b []byte) (int, error) {
	if r.status == 0 {
		r.status = http.StatusOK
	}
	return r.ResponseWriter.Write(b)
}

func (r *challengeStatusRecorder) Unwrap() http.ResponseWriter { return r.ResponseWriter }

func (r *challengeStatusRecorder) Flush() {
	if f, ok := r.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

func TestRequestBodyDeadlineBoundsStalledIdentityRequests(t *testing.T) {
	api := registryTestAPI(t)
	// The challenge counter rides INSIDE the composition the production
	// factory serves — tracker.track(counter.wrap(newHandler(...))) — so a
	// recorded completion is a real server-side observation of the actual
	// handler chain, never a parallel path.
	counter := newChallengeCounter()
	handler := counter.wrap(newHandler(testRelay(), api))
	// The server's whole-request bound is 10s here — LONGER than the
	// identity deadline wired through buildRegistryWith (900ms test value).
	// A stalled identity body must therefore be closed by the identity
	// service's own network deadline (http.ResponseController.SetReadDeadline
	// in decodeStrict — through the tracker wrapper's Unwrap, since the
	// factory serves the production composition), proving root wires a
	// real, effective, nonzero identity transport deadline instead of
	// leaning on the shared server bound alone.
	b := longServerBounds()
	if b.readTimeout <= testIdentityReadDeadline*2 {
		t.Fatalf("test misconfigured: server bound %s must exceed the identity deadline window", b.readTimeout)
	}
	ca := newFixtureCA(t)
	const tlsHost = "gateway.test"
	cache := &memCertCache{data: map[string][]byte{tlsHost: ca.leafCertPEM(t, tlsHost)}}
	manager := &autocert.Manager{
		Prompt:     autocert.AcceptTOS,
		HostPolicy: hostWhitelist(tlsHost),
		Cache:      cache,
	}

	for _, transport := range []struct {
		name    string
		tlsCfg  *tls.Config
		tlsHost string
		ca      *fixtureCA
	}{
		{name: "http"},
		{name: "tls", tlsCfg: productionTLSConfig(manager.GetCertificate), tlsHost: tlsHost, ca: ca},
	} {
		t.Run(transport.name, func(t *testing.T) {
			addr, shutdown := serveProductionFactory(t, handler, transport.tlsCfg, b, maxServiceConns)
			defer shutdown()
			base := "http://" + addr
			client := &http.Client{Timeout: 5 * time.Second}
			if transport.ca != nil {
				base = "https://" + addr
				client = &http.Client{
					Transport: &http.Transport{TLSClientConfig: transport.ca.clientConfig(transport.tlsHost)},
					Timeout:   5 * time.Second,
				}
			}

			// Positive control BEFORE the stalls: the endpoint is live,
			// admitting, and issuing challenges normally over THIS
			// transport — a stalled-case "close" cannot be a dead server.
			res, body := postChallengeClient(t, client, base, "good-bearer", "control-pre")
			if res.StatusCode != http.StatusOK || !strings.Contains(string(body), "challenge_id") {
				t.Fatalf("pre-stall control challenge = %d: %s", res.StatusCode, body)
			}

			for _, c := range stalledCases {
				t.Run(c.name, func(t *testing.T) {
					before := len(counter.snapshot())
					conn := stalledConn(t, addr, transport.tlsHost, transport.ca, c)
					defer conn.Close()
					// Closed by the identity deadline — long before the 10s
					// server bound could fire — and the ACTUAL response
					// bytes (may be empty) carry no 2xx and no challenge.
					res := readUntilClose(t, conn, testIdentityReadDeadline+1500*time.Millisecond)
					assertNoChallengeIssued(t, res, c.name)
					if !c.abort {
						return
					}
					// Read-error shape: the wire bytes above are only
					// evidence when the client RETAINED its read side.
					if transport.ca == nil {
						// Plain TCP: stalledConn half-closed, so what we
						// collected is the server's REAL response — an
						// empty collection would be a local artifact, not
						// evidence (the vacuous pass this regression
						// exists to kill).
						if !bytes.Contains(res, []byte("HTTP/1.1")) {
							t.Fatalf("read-error (http): no actual server response observed after the half-close (got %q)", res)
						}
					} else {
						// TLS has no half-close: the full client close makes
						// any local read an immediate artifact, so the WIRE
						// is not observable here — the server-side counter
						// is the evidence (do NOT accept the local read
						// error as proof of anything).
						if len(res) != 0 {
							t.Logf("read-error (tls): unexpected bytes after full close: %q", res)
						}
					}
					// Server-side, both transports: the challenge handler
					// must have COMPLETED after the transport read error,
					// and its own response decision must be non-2xx — no
					// challenge was issued for a body that never ended.
					statuses := counter.waitForCompletions(t, before+1, testIdentityReadDeadline+1500*time.Millisecond)
					if st := statuses[before]; st/100 == 2 {
						t.Fatalf("read-error: challenge handler completed with status %d — a challenge was issued after the transport read error", st)
					}
				})
			}

			// No stalled request left enroll-side state behind.
			for _, c := range stalledCases {
				if _, err := api.identitySvc.DeviceStore().GetDevice(c.deviceID); err == nil {
					t.Errorf("stalled request produced device state for %q", c.deviceID)
				}
			}

			// Positive control AFTER the stalls: a canonical request inside
			// the bound still works end to end — the deadline must not
			// break the real identity flow — and field validation is still
			// active on its own merits (an invalid device id is rejected
			// with 400, proving the stalled canonical requests were not
			// merely failing fast on validation).
			res, body = postChallengeClient(t, client, base, "good-bearer", "control-post")
			if res.StatusCode != http.StatusOK || !strings.Contains(string(body), "challenge_id") {
				t.Fatalf("post-stall control challenge = %d: %s", res.StatusCode, body)
			}
			badRes, _ := postChallengeClient(t, client, base, "good-bearer", "not a valid id")
			if badRes.StatusCode != http.StatusBadRequest {
				t.Fatalf("invalid device id = %d, want 400", badRes.StatusCode)
			}
		})
	}
}

func TestUpgradedSessionsSurviveHTTPBodyDeadline(t *testing.T) {
	api := registryTestAPI(t)
	r := testRelay()
	r.allowPrivateHosts = true
	addr, shutdown := serveProductionFactory(t, newHandler(r, api), nil, shortBounds(), maxServiceConns)
	defer shutdown()
	b := shortBounds()

	// Legacy SSH proxy: the upgrade hijacks the connection out from under
	// net/http, so the whole-request read deadline must not apply to the
	// session. A real client keeps a read loop running (that is what
	// services the server's pings), so the test does too while it holds
	// the session open far longer than the HTTP bound.
	_, sshPort := echoListener(t)
	ws, _, err := (&websocket.Dialer{HandshakeTimeout: 3 * time.Second}).
		Dial(fmt.Sprintf("ws://%s/?host=127.0.0.1&port=%d&token=good-token", addr, sshPort), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer ws.Close()
	wsFrames := make(chan []byte, 8)
	go func() {
		defer close(wsFrames)
		for {
			_, got, err := ws.ReadMessage()
			if err != nil {
				return
			}
			wsFrames <- got
		}
	}()
	ws.SetWriteDeadline(time.Now().Add(3 * time.Second))
	if err := ws.WriteMessage(websocket.BinaryMessage, []byte("ping-bytes")); err != nil {
		t.Fatal(err)
	}
	time.Sleep(3*b.readTimeout + 500*time.Millisecond) // 3× the HTTP body bound
	select {
	case got := <-wsFrames:
		if string(got) != "ping-bytes" {
			t.Fatalf("session echo mismatch: %q", got)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("session did not deliver the pre-deadline echo after the HTTP bound")
	}
	// Fresh traffic after the bound: the hijacked session is governed by
	// the pipe's own deadlines, not the request read deadline.
	ws.SetWriteDeadline(time.Now().Add(3 * time.Second))
	if err := ws.WriteMessage(websocket.BinaryMessage, []byte("post-bound")); err != nil {
		t.Fatalf("session dead after the HTTP bound: %v", err)
	}
	select {
	case got := <-wsFrames:
		if string(got) != "post-bound" {
			t.Fatalf("post-bound echo mismatch: %q", got)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("no post-bound echo")
	}

	// Same property for the tunnel's upgraded sessions: a real host agent
	// and a client session stay up and carry SSH bytes beyond the HTTP
	// request bound.
	key := ed25519.NewKeyFromSeed([]byte("body deadline seed 32 bytes!!!!!"))
	enrollOverHTTP(t, "http://"+addr, "good-bearer", "laptop-1", key, false)
	stopAgent, _ := startRealAgent(t, api, "http://"+addr, "laptop-1", key, fmt.Sprintf("127.0.0.1:%d", sshPort))
	defer stopAgent()

	cws, _, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial(fmt.Sprintf("ws://%s/api/v1/hosts/laptop-1/ssh", addr), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer cws.Close()
	if err := cws.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.ClientAuth{
		Type: "auth", V: tunnel.ProtocolVersion, Token: "good-bearer", DeviceID: "laptop-1",
	})); err != nil {
		t.Fatal(err)
	}
	var ready tunnel.ReadyMsg
	readJSONWS(t, cws, &ready)
	if ready.Type != "ready" {
		t.Fatalf("client got %q, want ready", ready.Type)
	}
	cwsFrames := make(chan []byte, 8)
	go func() {
		defer close(cwsFrames)
		for {
			_, got, err := cws.ReadMessage()
			if err != nil {
				return
			}
			cwsFrames <- got
		}
	}()
	payload := []byte("SSH-2.0-sustained\r\n")
	cws.SetWriteDeadline(time.Now().Add(3 * time.Second))
	if err := cws.WriteMessage(websocket.BinaryMessage, payload); err != nil {
		t.Fatal(err)
	}
	time.Sleep(3*b.readTimeout + 500*time.Millisecond)
	select {
	case got := <-cwsFrames:
		if string(got) != string(payload) {
			t.Fatalf("tunnel echo mismatch: %q", got)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("tunnel session did not survive the HTTP body bound")
	}
}
