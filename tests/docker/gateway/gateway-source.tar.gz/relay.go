// PocketShell dumb relay — the AWS sibling of the browser-direct SSH work.
//
// The whole point is that there is nothing here to read: the browser speaks
// SSH itself (pocketshell-web src/terminal/direct.ts) and this process
// ferries bytes between its WebSocket and a TCP stream toward host:port.
// The only intelligence is the front door: the Google ID token is verified
// (JWKS + audience + email allowlist) before the TCP leg opens, so the
// endpoint is not an open relay.
//
// The wire protocol is FROZEN to the reference worker
// (pocketshell-web relay/src/worker.ts):
//
//	GET  upgrade?token=<ID token>&host=<host>&port=<n>
//	400  bad host or port            (malformed/undialable host, port range,
//	                                 or DNS that resolves to a forbidden IP)
//	401  unauthorized                (token missing/invalid/not allowlisted)
//	426  pocketshell relay           (not a WebSocket upgrade)
//	502  dial failed                 (TCP leg refused/timed out)
//	101  Switching Protocols         → opaque binary frames both directions
//
// Hardening added on top of the frozen contract (new statuses only fire on
// requests that previously failed one way or another):
//
//	403  cross-origin browser request (Origin header not in -origins)
//	429  per-account session cap
//	503  relay full / handshake bound / handshake timeout
//	GET  /healthz → 200 {"service","version","commit","status",
//	                     "registry","tunnel"}
//
// Requests that never carried an Origin header (CLI, tests, health probes)
// are not browser requests; they skip the origin gate and still require the
// token.
//
// The new versioned API (device registry under /identity/v1/ and the
// reverse tunnel under /api/v1/) is DISABLED unless -registry names state
// under /var/lib/pocketshell-relay. It authenticates exclusively with
// short-lived scoped credentials issued by the trusted sync broker
// (POST /gateway/token, RS256, exact issuer/audience) — NEVER with a
// Google ID token, whose bearer would grant sync vault authority (finding
// C2). The legacy endpoint keeps Google-ID-token-in-query for wire
// compatibility only. Fail closed is the default and the deployed stack
// does not pass -registry.
//
// Deploy: see README.md in this directory. One t4g.nano covers personal
// use; the client keepalive (30 s) keeps NAT mappings and this process
// happy for the life of a session.
package main

import (
	"bufio"
	"context"
	"crypto"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/subtle"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"log"
	"log/slog"
	"math/big"
	"net"
	"net/http"
	"net/netip"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/acme"
	"golang.org/x/crypto/acme/autocert"
	"golang.org/x/net/netutil"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/routingauth"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// Build identity, injected at link time by CI:
//
//	go build -ldflags "-X main.version=v1.2.3 -X main.commit=$(git rev-parse HEAD)" .
//
// Left at the dev defaults by plain `go build` so /healthz always answers
// with something honest.
var (
	version = "dev"
	commit  = "unknown"
)

// registryBaseDir is the only place the new API may keep its state. Overridden
// in tests; production binaries must never see a different value.
var registryBaseDir = "/var/lib/pocketshell-relay"

// registryPosture is what /healthz reports about the new API. It is a
// package var (not a flag echo) so the reported posture reflects whether the
// identity service actually CONSTRUCTED — a configured-but-broken registry
// reports "failed" and serves no endpoints.
var registryPosture = "disabled"

// defaultOrigins is what -origins falls back to. These are the two hostnames
// that serve the PocketShell web app today (aws-infra/sandbox/pocketshell-web:
// app. is the canonical CloudFront alias, apex serves the same SPA). Dev
// localhost is deliberately NOT a default — pass -origins explicitly.
const defaultOrigins = "https://app.pocketshell.io,https://pocketshell.io"

var hostPattern = regexp.MustCompile(`^[a-z0-9.:-]+$`)

// isDialableHost is the syntactic pre-filter, before any DNS: only plausible
// public SSH endpoint names get resolved at all. Mirrors the worker's SSRF
// guard: no loopback, no link-local, no private ranges, no ambient metadata
// games by name.
func isDialableHost(host string) bool {
	if !hostPattern.MatchString(host) {
		return false
	}
	if host == "localhost" || strings.HasSuffix(host, ".internal") || strings.HasSuffix(host, ".local") {
		return false
	}
	if v4 := splitIPv4(host); v4 != nil {
		a, b := v4[0], v4[1]
		if a == 0 || a == 127 || a == 10 || a == 169 || (a == 192 && b == 168) || (a == 172 && b >= 16 && b <= 31) {
			return false
		}
	}
	return true
}

func splitIPv4(host string) []int {
	parts := strings.Split(host, ".")
	if len(parts) != 4 {
		return nil
	}
	out := make([]int, 4)
	for i, p := range parts {
		// Leading zeros and non-digits are not an IPv4 we dial.
		if len(p) == 0 || len(p) > 3 {
			return nil
		}
		n := 0
		for _, c := range p {
			if c < '0' || c > '9' {
				return nil
			}
			n = n*10 + int(c-'0')
		}
		if n > 255 {
			return nil
		}
		out[i] = n
	}
	return out
}

// --- IP vetting: the authoritative gate, applied to resolved addresses -----

// forbiddenV4 is the non-routable / infrastructure IPv4 space. Anything in
// here may not be dialed even if DNS says the target lives there: IMDS
// (169.254.169.254), CGNAT (100.64/10), benchmarking, documentation, and the
// usual RFC1918 + loopback suspects.
var forbiddenV4 = []netip.Prefix{
	p4("0.0.0.0/8"),       // "this network"
	p4("10.0.0.0/8"),      // RFC1918
	p4("100.64.0.0/10"),   // CGNAT (covers 100.100.100.200 style metadata)
	p4("127.0.0.0/8"),     // loopback
	p4("169.254.0.0/16"),  // link-local incl. EC2 IMDS 169.254.169.254
	p4("172.16.0.0/12"),   // RFC1918
	p4("192.0.0.0/24"),    // IETF protocol assignments
	p4("192.0.2.0/24"),    // TEST-NET-1
	p4("192.88.99.0/24"),  // 6to4 relay anycast (deprecated)
	p4("192.168.0.0/16"),  // RFC1918
	p4("198.18.0.0/15"),   // benchmarking
	p4("198.51.100.0/24"), // TEST-NET-2
	p4("203.0.113.0/24"),  // TEST-NET-3
	p4("224.0.0.0/4"),     // multicast
	p4("240.0.0.0/4"),     // reserved, incl. 255.255.255.255
}

// forbiddenV6 covers special ranges inside the global unicast 2000::/3 that
// we still refuse (tunnelled IPv4, documentation, ORCHID, benchmarking).
// Everything outside 2000::/3 — loopback, ULA (incl. fd00:ec2::254 IMDS),
// link-local, multicast, unspecified — is refused wholesale below.
var forbiddenV6 = []netip.Prefix{
	p6("2001::/32"),     // Teredo (embeds an IPv4 address)
	p6("2001:2::/48"),   // benchmarking
	p6("2001:10::/28"),  // ORCHID
	p6("2001:20::/28"),  // ORCHIDv2
	p6("2001:db8::/32"), // documentation
	p6("2002::/16"),     // 6to4 (embeds an IPv4 address)
}

func p4(s string) netip.Prefix { return netip.MustParsePrefix(s) }
func p6(s string) netip.Prefix { return netip.MustParsePrefix(s) }

// isForbiddenIP reports whether addr may never be dialed. Mapped IPv4
// (::ffff:a.b.c.d) is unmapped first and judged by the IPv4 rules, so
// ::ffff:127.0.0.1 is as dead as 127.0.0.1.
func isForbiddenIP(addr netip.Addr) bool {
	a := addr.Unmap()
	if a.Is4() {
		ov4 := a.As4()
		ip := netip.AddrFrom4(ov4)
		for _, p := range forbiddenV4 {
			if p.Contains(ip) {
				return true
			}
		}
		return false
	}
	if !a.Is6() {
		return true // unknown shape: fail closed
	}
	if !p6("2000::/3").Contains(a) {
		return true // not global unicast: loopback/ULA/link-local/multicast/…
	}
	for _, p := range forbiddenV6 {
		if p.Contains(a) {
			return true
		}
	}
	return false
}

// vetResolved applies the IP gate to a DNS answer. One poisoned record
// poisons the whole answer: we never dial a host whose resolution mixed a
// forbidden address in (fail closed against round-robin rebinding).
func vetResolved(addrs []netip.Addr) []netip.Addr {
	if len(addrs) == 0 {
		return nil
	}
	vetted := make([]netip.Addr, 0, len(addrs))
	for _, a := range addrs {
		if isForbiddenIP(a) {
			return nil
		}
		vetted = append(vetted, a)
	}
	return vetted
}

// --- Google ID token verification (RS256, JWKS cached one hour) -----------

type jwksCache struct {
	mu      sync.Mutex
	keys    map[string]*rsa.PublicKey
	fetched time.Time
}

var jwks = &jwksCache{}

type jwkSet struct {
	Keys []struct {
		Kid string `json:"kid"`
		N   string `json:"n"`
		E   string `json:"e"`
	} `json:"keys"`
}

func (c *jwksCache) get(ctx context.Context, kid string) (*rsa.PublicKey, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.keys == nil || time.Since(c.fetched) > time.Hour {
		fetchCtx, cancel := context.WithTimeout(ctx, 10*time.Second)
		defer cancel()
		req, err := http.NewRequestWithContext(fetchCtx, http.MethodGet, "https://www.googleapis.com/oauth2/v3/certs", nil)
		if err != nil {
			return nil, err
		}
		res, err := http.DefaultClient.Do(req)
		if err != nil {
			return nil, err
		}
		defer res.Body.Close()
		if res.StatusCode != http.StatusOK {
			return nil, fmt.Errorf("jwks fetch: HTTP %d", res.StatusCode)
		}
		var set jwkSet
		if err := json.NewDecoder(res.Body).Decode(&set); err != nil {
			return nil, err
		}
		keys := make(map[string]*rsa.PublicKey, len(set.Keys))
		for _, k := range set.Keys {
			n, err := base64.RawURLEncoding.DecodeString(k.N)
			if err != nil {
				continue
			}
			e, err := base64.RawURLEncoding.DecodeString(k.E)
			if err != nil || len(e) > 4 {
				continue
			}
			exp := 0
			for _, b := range e {
				exp = exp<<8 | int(b)
			}
			keys[k.Kid] = &rsa.PublicKey{N: new(big.Int).SetBytes(n), E: exp}
		}
		if len(keys) == 0 {
			return nil, errors.New("jwks had no usable keys")
		}
		c.keys = keys
		c.fetched = time.Now()
	}
	key, ok := c.keys[kid]
	if !ok {
		return nil, errors.New("unknown kid")
	}
	return key, nil
}

// verifyGoogleToken returns the verified email, or "". Claims checks mirror
// the bridge Lambda and the reference worker exactly. The legacy endpoint
// keeps token-in-query for wire compatibility; new endpoints must never do
// this.
func verifyGoogleToken(ctx context.Context, token, clientID string, allowlist []string) string {
	if token == "" {
		return ""
	}
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return ""
	}
	decode := func(s string) ([]byte, bool) {
		b, err := base64.RawURLEncoding.DecodeString(s)
		if err != nil {
			// Tolerate padding, as the worker's decoder does.
			pad := (4 - len(s)%4) % 4
			b, err = base64.URLEncoding.DecodeString(s + strings.Repeat("=", pad))
			if err != nil {
				return nil, false
			}
		}
		return b, true
	}
	var header struct {
		Alg string `json:"alg"`
		Kid string `json:"kid"`
	}
	var claims struct {
		Iss           string `json:"iss"`
		Aud           any    `json:"aud"`
		Exp           int64  `json:"exp"`
		Email         string `json:"email"`
		EmailVerified bool   `json:"email_verified"`
	}
	hb, ok1 := decode(parts[0])
	cb, ok2 := decode(parts[1])
	if !ok1 || !ok2 || json.Unmarshal(hb, &header) != nil || json.Unmarshal(cb, &claims) != nil {
		return ""
	}
	if header.Alg != "RS256" {
		return ""
	}
	aud, ok := claims.Aud.(string)
	if !ok {
		return ""
	}
	if claims.Iss != "accounts.google.com" && claims.Iss != "https://accounts.google.com" {
		return ""
	}
	if aud != clientID || time.Now().Unix() >= claims.Exp || !claims.EmailVerified {
		return ""
	}
	if len(allowlist) == 0 {
		return "" // fail closed, like the worker
	}
	email := strings.ToLower(claims.Email)
	allowed := false
	for _, a := range allowlist {
		if subtle.ConstantTimeCompare([]byte(email), []byte(strings.ToLower(a))) == 1 {
			allowed = true
			break
		}
	}
	if !allowed {
		return ""
	}

	key, err := jwks.get(ctx, header.Kid)
	if err != nil {
		log.Printf("jwks: %v", err)
		return ""
	}
	sig, okSig := decode(parts[2])
	if !okSig {
		return ""
	}
	digest := sha256.Sum256([]byte(parts[0] + "." + parts[1]))
	if err := rsa.VerifyPKCS1v15(key, crypto.SHA256, digest[:], sig); err != nil {
		return ""
	}
	return email
}

// --- scoped routing credentials (broker JWTs) ------------------------------
//
// The new API (identity registry + reverse tunnel) NEVER accepts Google ID
// tokens: a Google web bearer would grant the gateway the same sync
// GET/PUT/DELETE authority over the encrypted vault as the web client
// (finding C2). The trusted sync service instead exchanges a Google
// session for a short-lived (<=5 min) RS256 JWT with issuer = exact API
// base, audience = pocketshell-gateway, a fixed routing scope and the
// verified Google owner. The issuer and its JWKS are pinned here as
// constants plus operator flags — they are never discovered through the
// gateway itself, and TLS is never skipped.
//
// Verification is the shared internal/routingauth module (one verifier for
// every consumer; no duplicated crypto, claim or cache logic at the
// wiring site). newBrokerVerifier is only the wiring factory: it maps the
// operator-facing flags onto routingauth.Config and pins the contract
// values that the gateway is responsible for (the five-minute broker
// lifetime — the module's generic default is looser).

const (
	// defaultBrokerIssuer is the trusted sync API base. POST /gateway/token
	// exchanges an authorized Google session for a scoped gateway JWT;
	// GET /gateway/jwks publishes the signing keys.
	defaultBrokerIssuer = "https://a7sota2qic.execute-api.eu-west-1.amazonaws.com"
	// brokerMaxLifetime enforces the broker contract end to end: the sync
	// service caps issuance at five minutes, so anything materially longer
	// was not minted by the broker (security review round three, item 3).
	brokerMaxLifetime = 5 * time.Minute
)

// newBrokerVerifier maps the operator-facing broker configuration onto the
// shared routingauth verifier. It fails closed on anything routingauth
// rejects (missing issuer, https-only URLs in production). insecureDev is
// the explicit dev opt-in: it is passed straight to routingauth's
// AllowInsecureDev so plain-HTTP lab fixtures can pin their URLs — there is
// no insecure shim at this wiring site, and validateConfig refuses the
// opt-in next to a public domain.
func newBrokerVerifier(cfg brokerConfig) (identity.TokenVerifier, error) {
	v, err := routingauth.NewVerifier(routingauth.Config{
		Issuer:           cfg.issuer,
		JWKSURL:          cfg.jwksURL,
		Audience:         cfg.audience,
		Allowlist:        cfg.allow,
		HTTPClient:       cfg.client,
		Clock:            cfg.clock,
		MaxLifetime:      brokerMaxLifetime,
		AllowInsecureDev: cfg.insecureDev,
		Logger: func(format string, args ...any) {
			log.Printf("broker: "+format, args...)
		},
	})
	if err != nil {
		return nil, err
	}
	return v, nil
}

// brokerConfig pins the trusted credential broker. Everything is explicit
// configuration; nothing is discovered at runtime through the gateway.
type brokerConfig struct {
	issuer      string // exact token issuer (iss), https per routingauth
	jwksURL     string // signing keys of the broker, https per routingauth
	audience    string // required aud claim
	allow       []string
	client      *http.Client
	clock       func() time.Time
	insecureDev bool // DEV ONLY: plain-http broker URLs (lab fixtures)
}

// expiryGate wraps any TokenVerifier and refuses principals without a
// populated, unexpired ExpiresAt (identity review round two, item 9). The
// production wiring always applies it; only explicit test stubs bypass it.
type expiryGate struct {
	inner identity.TokenVerifier
	now   func() time.Time
}

func (g expiryGate) VerifyToken(ctx context.Context, token string) (identity.Principal, error) {
	// Admission gate: a cancelled or timed-out handshake context rejects
	// before any verification work (round three, item 3).
	if err := ctx.Err(); err != nil {
		return identity.Principal{}, fmt.Errorf("admission context: %w", err)
	}
	p, err := g.inner.VerifyToken(ctx, token)
	if err != nil {
		return identity.Principal{}, err
	}
	nowFn := g.now
	if nowFn == nil {
		nowFn = time.Now
	}
	if p.ExpiresAt.IsZero() {
		return identity.Principal{}, errors.New("verifier returned a principal without expiry")
	}
	if !nowFn().Before(p.ExpiresAt) {
		return identity.Principal{}, errors.New("principal expired")
	}
	return p, nil
}

// --- the pipe --------------------------------------------------------------

const (
	dialTimeout    = 10 * time.Second
	handshakeTime  = 15 * time.Second
	wsWriteTimeout = 15 * time.Second
	wsPingPeriod   = 25 * time.Second // must stay below wsPongWait
	wsPongWait     = 90 * time.Second
	maxFrame       = 512 * 1024
	maxSessions    = 64
	maxPerAccount  = 8
	maxHandshakes  = 128 // concurrent pre-pipe phases (auth+DNS+dial)
	tcpChunk       = 32 * 1024

	// A15 aggregate admission bounds, applied on the RAW listener before
	// TLS or HTTP parsing: every accepted socket — legacy WS (including
	// hijacked), tunnel host agents and clients, unauthenticated
	// handshakes mid-parse — counts against one pool, so socket and
	// buffer memory are bounded ahead of any request work on the
	// 512 MiB t4g.nano. Sockets above the cap stay in the kernel backlog
	// (never parsed, never buffered by us) until a slot frees. The ACME
	// :80 listener gets its own independent, smaller pool. These are
	// availability bounds, not a DDoS claim.
	maxServiceConns = 256
	maxACMEConns    = 32
)

// hostPort is a validated dial target.
type hostPort struct {
	host string
	port int
}

// wsWriter serializes every write on the websocket — data frames, pings and
// close frames share one mutex, as gorilla requires — and puts a deadline on
// each so a wedged client cannot park a goroutine forever.
type wsWriter struct {
	ws           *websocket.Conn
	writeTimeout time.Duration
	mu           sync.Mutex
}

func (w *wsWriter) write(data []byte) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	_ = w.ws.SetWriteDeadline(time.Now().Add(w.writeTimeout))
	return w.ws.WriteMessage(websocket.BinaryMessage, data)
}

func (w *wsWriter) ping() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.ws.WriteControl(websocket.PingMessage, nil, time.Now().Add(w.writeTimeout))
}

type relay struct {
	clientID string
	allow    []string
	skipAuth bool
	// DEV ONLY (-dev-allow-private-hosts): lifts the SSRF guard so local
	// e2e can dial a docker sshd on loopback. Never set in production.
	allowPrivateHosts bool

	// origins is the exact browser-origin allowlist (scheme://host, no
	// paths). Requests WITHOUT an Origin header are not browser requests
	// and skip this gate — they still need the token.
	origins map[string]bool

	// authenticate maps a raw credential to an account key, "" = deny.
	// Legacy wiring: verifyGoogleToken (account = verified email). New
	// endpoints will key on identity.Principal (issuer+sub), never email.
	authenticate func(ctx context.Context, token string) string

	// resolver/dialFunc are seams for tests; production uses the defaults.
	resolver interface {
		LookupNetIP(ctx context.Context, network, host string) ([]netip.Addr, error)
	}
	dialFunc func(ctx context.Context, network, addr string) (net.Conn, error)

	global     chan struct{} // bounded live sessions
	handshakes chan struct{} // bounded auth/dial phases
	mu         sync.Mutex
	perAccount map[string]int

	// sessions counts every in-flight ServeHTTP invocation. Hijacked
	// WebSocket sessions (legacy SSH proxy and tunnel alike) are invisible
	// to http.Server.Shutdown, so the lifecycle waits on this to hold
	// process exit until their teardown completes.
	sessions sync.WaitGroup

	baseCtx context.Context // cancelled on shutdown; nil in tests

	// Timing knobs; defaults are the consts above, shortened in tests.
	handshakeTimeout time.Duration
	pongWait         time.Duration
	pingPeriod       time.Duration
	readLimit        int64

	upgrader websocket.Upgrader
}

func newRelay() *relay {
	r := &relay{
		resolver:         net.DefaultResolver,
		global:           make(chan struct{}, maxSessions),
		handshakes:       make(chan struct{}, maxHandshakes),
		perAccount:       make(map[string]int),
		handshakeTimeout: handshakeTime,
		pongWait:         wsPongWait,
		pingPeriod:       wsPingPeriod,
		readLimit:        maxFrame,
		upgrader: websocket.Upgrader{
			HandshakeTimeout:  handshakeTime,
			ReadBufferSize:    4096,
			WriteBufferSize:   4096,
			EnableCompression: false,                                    // frozen wire is raw binary; no permessage-deflate
			CheckOrigin:       func(*http.Request) bool { return true }, // enforced earlier, with a reason
		},
	}
	r.dialFunc = func(ctx context.Context, network, addr string) (net.Conn, error) {
		d := &net.Dialer{Timeout: dialTimeout}
		return d.DialContext(ctx, network, addr)
	}
	return r
}

// checkOrigin enforces the exact-origin allowlist for browser requests.
// headerless requests (curl, tests, monitors) pass — the token still gates
// them.
func (r *relay) originAllowed(req *http.Request) bool {
	origin := req.Header.Get("Origin")
	if origin == "" {
		return true
	}
	u, err := url.Parse(origin)
	if err != nil || u.Scheme == "" || u.Host == "" {
		return false
	}
	return r.origins[strings.ToLower(u.Scheme)+"://"+strings.ToLower(u.Host)]
}

type reserveResult int

const (
	reserveOK reserveResult = iota
	reserveGlobalFull
	reserveAccountFull
)

// reserveCapacity takes a global slot and a per-account slot BEFORE any TCP
// work, so a flood of authorized clients cannot spend our dial budget. The
// caller must releaseCapacity exactly once unless the result is
// reserveGlobalFull (nothing was taken).
func (r *relay) reserveCapacity(account string) reserveResult {
	select {
	case r.global <- struct{}{}:
	default:
		return reserveGlobalFull
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.perAccount[account] >= maxPerAccount {
		// Give the global slot back: this request is being rejected.
		<-r.global
		return reserveAccountFull
	}
	r.perAccount[account]++
	return reserveOK
}

func (r *relay) releaseCapacity(account string) {
	r.mu.Lock()
	if r.perAccount[account]--; r.perAccount[account] <= 0 {
		delete(r.perAccount, account)
	}
	r.mu.Unlock()
	<-r.global
}

// resolveAndVet resolves host once, vetts every answer, and returns the
// numeric addresses the dialer may use. The dial never resolves again, so a
// rebinding resolver cannot swap the address between vet and dial.
func (r *relay) resolveAndVet(ctx context.Context, host string) []netip.Addr {
	addrs, err := r.resolver.LookupNetIP(ctx, "ip", host)
	if err != nil || len(addrs) == 0 {
		return nil
	}
	return vetResolved(addrs)
}

// connectTarget dials the vetted numeric addresses in order. dev mode
// (allowPrivateHosts) dials the hostname as-is so local e2e can reach
// loopback sshd containers.
func (r *relay) connectTarget(ctx context.Context, t hostPort) (net.Conn, error) {
	if r.allowPrivateHosts {
		return r.dialFunc(ctx, "tcp", net.JoinHostPort(t.host, fmt.Sprint(t.port)))
	}
	vetted := r.resolveAndVet(ctx, t.host)
	if len(vetted) == 0 {
		return nil, errForbiddenHost
	}
	allowed := make(map[netip.Addr]bool, len(vetted))
	for _, a := range vetted {
		allowed[a.Unmap()] = true
	}
	var lastErr error = errForbiddenHost
	for _, a := range vetted {
		addr := net.JoinHostPort(a.Unmap().String(), fmt.Sprint(t.port))
		conn, err := r.dial(ctx, addr, allowed)
		if err == nil {
			return conn, nil
		}
		lastErr = err
	}
	return nil, lastErr
}

// dial opens one numeric address. allowed (when non-nil) is re-checked from
// inside the Dialer's Control callback: the address the library is about to
// connect to must be one of the vetted set — the belt to the resolve-once
// suspenders.
func (r *relay) dial(ctx context.Context, addr string, allowed map[netip.Addr]bool) (net.Conn, error) {
	if r.dialFunc != nil {
		return r.dialFunc(ctx, "tcp", addr)
	}
	d := &net.Dialer{Timeout: dialTimeout}
	if allowed != nil {
		d.Control = vettedControl(allowed)
	}
	return d.DialContext(ctx, "tcp", addr)
}

// vettedControl is a net.Dialer Control that refuses any address outside the
// vetted set.
func vettedControl(allowed map[netip.Addr]bool) func(network, address string, c syscall.RawConn) error {
	return func(network, address string, _ syscall.RawConn) error {
		host, _, err := net.SplitHostPort(address)
		if err != nil {
			return err
		}
		ip, err := netip.ParseAddr(host)
		if err != nil {
			return err
		}
		if !allowed[ip.Unmap()] {
			return fmt.Errorf("address %v escaped vetting", ip)
		}
		return nil
	}
}

var errForbiddenHost = errors.New("host resolves to forbidden address")

func (r *relay) ServeHTTP(w http.ResponseWriter, req *http.Request) {
	// Tracked from the first line (before any hijack) so the lifecycle's
	// wait cannot slip through the window between hijack and registration.
	r.sessions.Add(1)
	defer r.sessions.Done()
	if !websocket.IsWebSocketUpgrade(req) {
		http.Error(w, "pocketshell relay (websocket only)\n", http.StatusUpgradeRequired)
		return
	}
	// Bound the unauthenticated phase (token crypto, JWKS, DNS, dial
	// attempts) independently of the session pool.
	select {
	case r.handshakes <- struct{}{}:
	default:
		http.Error(w, "relay busy", http.StatusServiceUnavailable)
		return
	}
	ws, tcp, account, t, reserved, ok := r.establish(w, req)
	<-r.handshakes
	if reserved && !ok {
		r.releaseCapacity(account) // rejection after reservation: give both slots back
		return
	}
	if !ok {
		return // response already written, nothing reserved
	}
	defer func() {
		r.releaseCapacity(account)
		tcp.Close()
		ws.ws.Close()
	}()
	log.Printf("[%s] %s:%d open", account, t.host, t.port)
	start := time.Now()
	r.pipe(ws, tcp)
	log.Printf("[%s] %s:%d closed after %s", account, t.host, t.port, time.Since(start).Round(time.Second))
}

// establish runs the entire gated pre-pipe phase. It never releases the
// handshake slot; on success the caller owns one reserved capacity pair and
// must release it when the session ends. Every rejection path writes its own
// response.
func (r *relay) establish(w http.ResponseWriter, req *http.Request) (ws *wsWriter, tcp net.Conn, account string, t hostPort, reserved, ok bool) {
	fail := func(code int, msg string) {
		http.Error(w, msg, code)
	}

	q := req.URL.Query()
	t = hostPort{host: q.Get("host")}
	if raw := q.Get("port"); raw != "" {
		if n, err := parsePort(raw); err == nil {
			t.port = n
		}
	}
	if t.host == "" || t.port < 1 || (!r.allowPrivateHosts && !isDialableHost(t.host)) {
		fail(http.StatusBadRequest, "bad host or port")
		return nil, nil, "", t, false, false
	}

	if !r.originAllowed(req) {
		fail(http.StatusForbidden, "cross-origin not allowed")
		return nil, nil, "", t, false, false
	}

	ctx, cancel := context.WithTimeout(req.Context(), r.handshakeTimeout)
	defer cancel()

	if r.skipAuth {
		account = "dev@local"
	} else if r.authenticate != nil {
		account = r.authenticate(ctx, q.Get("token"))
	} else {
		account = verifyGoogleToken(ctx, q.Get("token"), r.clientID, r.allow)
	}
	if account == "" {
		fail(http.StatusUnauthorized, "unauthorized")
		return nil, nil, "", t, false, false
	}

	if res := r.reserveCapacity(account); res != reserveOK {
		if res == reserveGlobalFull {
			fail(http.StatusServiceUnavailable, "relay full")
		} else {
			fail(http.StatusTooManyRequests, "too many sessions for account")
		}
		return nil, nil, "", t, false, false
	}
	reserved = true

	var err error
	tcp, err = r.connectTarget(ctx, t)
	if err != nil {
		if errors.Is(err, errForbiddenHost) {
			log.Printf("[%s] dial %s:%d rejected: %v", account, t.host, t.port, err)
			fail(http.StatusBadRequest, "bad host or port")
		} else {
			log.Printf("[%s] dial %s:%d failed: %v", account, t.host, t.port, err)
			fail(http.StatusBadGateway, "dial failed")
		}
		return nil, nil, "", t, true, false
	}

	wsConn, err := r.upgrader.Upgrade(w, req, nil)
	if err != nil {
		tcp.Close()
		return nil, nil, "", t, true, false // Upgrade already wrote the error
	}
	return &wsWriter{ws: wsConn, writeTimeout: wsWriteTimeout}, tcp, account, t, true, true
}

func parsePort(raw string) (int, error) {
	if len(raw) > 5 {
		return 0, errors.New("port too long")
	}
	n := 0
	for _, c := range raw {
		if c < '0' || c > '9' {
			return 0, errors.New("port not numeric")
		}
		n = n*10 + int(c-'0')
	}
	if n < 1 || n > 65535 {
		return 0, errors.New("port out of range")
	}
	return n, nil
}

// pipe copies bytes both ways until either leg closes. WebSocket frames
// carry the SSH bytes opaquely; text frames from the client are accepted
// and re-sent as bytes, exactly like the reference worker.
//
// Boundedness: the client→TCP leg reads at most r.readLimit per message
// (never lifted, not even in dev mode) and writes straight through to the
// TCP socket — no unbounded queue. The TCP→client leg reads 32 KiB chunks
// and every websocket write carries a deadline; a stalled client kills the
// session instead of piling up memory. Server-side pings keep NAT mappings
// alive on quiet sessions and the pong/data read deadline reaps dead
// clients.
func (r *relay) pipe(w *wsWriter, tcp net.Conn) {
	base := r.baseCtx
	pongWait := r.pongWait
	done := make(chan struct{})
	var once sync.Once
	// halt tears down BOTH legs. Closing the underlying conn (not the
	// gorilla wrapper) is what unblocks every party: the main loop's
	// tcp.Read and the reader's ws.ReadMessage. Without it, a client
	// disconnect would strand the session and its reserved capacity.
	halt := func() {
		once.Do(func() {
			tcp.Close()
			w.ws.UnderlyingConn().Close()
		})
	}
	defer halt()

	// Shutdown path: a cancelled base context tears both legs down.
	if base != nil {
		go func() {
			select {
			case <-base.Done():
				halt()
			case <-done:
			}
		}()
	}

	// client → TCP. Any exit from this loop is a dead session: it closes
	// the TCP leg so the main loop cannot strand.
	go func() {
		defer close(done)
		defer halt()
		w.ws.SetReadLimit(r.readLimit)
		_ = w.ws.SetReadDeadline(time.Now().Add(pongWait))
		w.ws.SetPongHandler(func(string) error {
			return w.ws.SetReadDeadline(time.Now().Add(pongWait))
		})
		for {
			_, data, err := w.ws.ReadMessage()
			if err != nil {
				return
			}
			_ = w.ws.SetReadDeadline(time.Now().Add(pongWait))
			// Text frames are forwarded as their bytes, exactly like the
			// frozen worker; binary frames pass through verbatim.
			if len(data) > 0 {
				if _, err := tcp.Write(data); err != nil {
					return
				}
			}
		}
	}()

	// Ping ticker on the serialized writer; NAT keepalive + liveness probe.
	go func() {
		ticker := time.NewTicker(r.pingPeriod)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				if err := w.ping(); err != nil {
					halt()
					return
				}
			case <-done:
				return
			}
		}
	}()

	buf := make([]byte, tcpChunk)
	for {
		n, err := tcp.Read(buf)
		if n > 0 {
			if werr := w.write(buf[:n]); werr != nil {
				break
			}
		}
		if err != nil {
			break
		}
	}
	halt()
	<-done
}

// waitIdle blocks until every live relay session — including the hijacked
// WebSocket legs that http.Server.Shutdown does not track — has finished
// tearing down. On the shutdown path the base context closes both legs of
// each session, so the wait is bounded by local teardown, not by clients.
func (r *relay) waitIdle() { r.sessions.Wait() }

// waitIdleBounded is the drain's bounded join for the legacy session
// WaitGroup: true when every session finished within bound, false when the
// bound expired with sessions still live. run never waits forever for a
// session that cannot finish — the false return is recorded as the
// lifecycle error. The waiter goroutine parked in WaitGroup.Wait after a
// timeout is not invented termination: run is returning a hard error and
// the process exits, so the goroutine never outlives it.
func (r *relay) waitIdleBounded(bound time.Duration) bool {
	done := make(chan struct{})
	go func() {
		r.sessions.Wait()
		close(done)
	}()
	select {
	case <-done:
		return true
	case <-time.After(bound):
		return false
	}
}

// --- root-owned handler lifecycle (drain correctness) ------------------------

// handlerTracker is the lifecycle authority over every in-flight
// service-port handler. It exists because http.Server.Shutdown tracks only
// active, non-hijacked requests: the moment a handler hijacks its
// connection — every WebSocket upgrade on this service, the legacy relay
// and the tunnel alike — the HTTP server forgets it. And the tunnel
// service's own Close covers registered host agents only: an UPGRADED host
// agent that has not yet produced its signed proof, a client WebSocket
// parked before its first auth frame, and client bridges are invisible to
// both. Without root-owned tracking, run could return success while those
// handlers were still parked on their handshake deadlines (up to the
// tunnel's HandshakeTimeout) with live sockets.
//
// The tracker closes that gap with four primitives:
//
//   - track: counts a handler from its first line (before any hijack),
//     mirroring relay.sessions;
//   - the response-writer wrapper records every hijacked socket, so the
//     drain owns connections net/http no longer knows about;
//   - beginDrain engages the admission shutter (a handler entering after
//     it is refused with 503 — no new upgrades mid-drain) and
//     force-closes every recorded hijacked socket, so parked pre-auth
//     handlers unblock at once instead of surviving HandshakeTimeout;
//   - waitIdle joins handler completion. Race-free by construction: adds
//     are refused once the shutter is engaged, so no increment can race
//     the wait.
//
// The wrapper preserves the handler-visible ResponseWriter contract:
// Hijack is delegated (and observed), Unwrap lets http.ResponseController
// reach the real writer's deadline APIs (identity's body deadline depends
// on it), and Flush is forwarded.
type handlerTracker struct {
	mu       sync.Mutex
	cond     *sync.Cond
	inFlight int
	closed   bool
	live     map[net.Conn]struct{}

	// doneGate is a TEST-ONLY deterministic seam (nil in production): when
	// non-nil, handler completion parks on it until it is closed, holding
	// completions observable so a regression can prove that run() joins
	// handler teardown before returning. Armed via armDoneGate under the
	// tracker lock.
	doneGate chan struct{}
}

func newHandlerTracker() *handlerTracker {
	t := &handlerTracker{live: map[net.Conn]struct{}{}}
	t.cond = sync.NewCond(&t.mu)
	return t
}

// armDoneGate engages the TEST-ONLY completion seam. Under the tracker
// lock so handler goroutines observe it race-free.
func (t *handlerTracker) armDoneGate(gate chan struct{}) {
	t.mu.Lock()
	t.doneGate = gate
	t.mu.Unlock()
}

// track wraps handler so every invocation is counted, shuttered after
// beginDrain, and every socket it hijacks is owned by the tracker.
func (t *handlerTracker) track(handler http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
		t.mu.Lock()
		if t.closed {
			t.mu.Unlock()
			http.Error(w, "gateway shutting down", http.StatusServiceUnavailable)
			return
		}
		t.inFlight++
		t.mu.Unlock()
		tw := &trackingResponseWriter{ResponseWriter: w, tracker: t}
		defer tw.done()
		handler.ServeHTTP(tw, req)
	})
}

// register records a hijacked connection. Called from the wrapper's
// Hijack — the single point where a handler takes its socket out from
// under net/http.
func (t *handlerTracker) register(conn net.Conn) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.closed {
		// The drain started while this handler was mid-upgrade: force-close
		// the socket immediately; the handler observes the close and exits,
		// and waitIdle still joins its completion.
		_ = conn.Close()
		return
	}
	t.live[conn] = struct{}{}
}

// beginDrain engages the admission shutter and force-closes every tracked
// hijacked socket. Idempotent.
func (t *handlerTracker) beginDrain() {
	t.mu.Lock()
	if t.closed {
		t.mu.Unlock()
		return
	}
	t.closed = true
	conns := make([]net.Conn, 0, len(t.live))
	for c := range t.live {
		conns = append(conns, c)
	}
	t.live = map[net.Conn]struct{}{}
	t.mu.Unlock()
	for _, c := range conns {
		_ = c.Close()
	}
}

// waitIdle joins every in-flight handler. Reached only after beginDrain in
// the lifecycle, so no admission can add work from that point on.
func (t *handlerTracker) waitIdle() {
	t.mu.Lock()
	defer t.mu.Unlock()
	for t.inFlight > 0 {
		t.cond.Wait()
	}
}

// waitIdleBounded joins handler completion like waitIdle but gives up after
// bound, returning false with handlers still live. This is the drain's
// explicit bounded-join policy: a handler that cannot finish (non-cooperative,
// parked somewhere no signal reaches) must turn into a recorded lifecycle
// error, never an unbounded wait and never a silent success. The timer fires
// under the lock and broadcasts, so the wait wakes deterministically; the
// timer is stopped on every return.
func (t *handlerTracker) waitIdleBounded(bound time.Duration) bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.inFlight == 0 {
		return true
	}
	timedOut := false
	timer := time.AfterFunc(bound, func() {
		t.mu.Lock()
		timedOut = true
		t.mu.Unlock()
		t.cond.Broadcast()
	})
	defer timer.Stop()
	for t.inFlight > 0 {
		t.cond.Wait()
		if timedOut {
			return t.inFlight == 0
		}
	}
	return true
}

// inFlightCount reports the number of currently tracked handlers.
func (t *handlerTracker) inFlightCount() int {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.inFlight
}

// trackingResponseWriter observes hijacks and otherwise forwards the
// handler-facing ResponseWriter contract untouched.
type trackingResponseWriter struct {
	http.ResponseWriter
	tracker  *handlerTracker
	hijacked net.Conn
}

// Hijack delegates to the real hijacker and hands the socket to the
// tracker. gorilla's Upgrader asserts http.Hijacker on the writer it is
// given, so this method is what keeps every upgrade path (legacy relay,
// tunnel agent, tunnel client) working through the wrapper.
func (w *trackingResponseWriter) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	h, ok := w.ResponseWriter.(http.Hijacker)
	if !ok {
		return nil, nil, errors.New("trackingResponseWriter: underlying writer is not a Hijacker")
	}
	conn, brw, err := h.Hijack()
	if err == nil {
		w.hijacked = conn
		w.tracker.register(conn)
	}
	return conn, brw, err
}

// Unwrap lets http.ResponseController cross the wrapper: identity's
// strict body decoder sets its network deadline through
// ResponseController.SetReadDeadline, which must land on the real writer.
func (w *trackingResponseWriter) Unwrap() http.ResponseWriter { return w.ResponseWriter }

func (w *trackingResponseWriter) Flush() {
	if f, ok := w.ResponseWriter.(http.Flusher); ok {
		f.Flush()
	}
}

// done records one handler completion after its tracked socket (if any)
// is deregistered. TEST-ONLY: with doneGate armed, completion parks first,
// so the drain join is observably still waiting on this handler.
func (w *trackingResponseWriter) done() {
	w.tracker.mu.Lock()
	gate := w.tracker.doneGate
	w.tracker.mu.Unlock()
	if gate != nil {
		<-gate
	}
	w.tracker.unregister(w.hijacked)
	w.tracker.mu.Lock()
	w.tracker.inFlight--
	if w.tracker.inFlight == 0 {
		w.tracker.cond.Broadcast()
	}
	w.tracker.mu.Unlock()
}

func (t *handlerTracker) unregister(conn net.Conn) {
	if conn == nil {
		return
	}
	t.mu.Lock()
	delete(t.live, conn)
	t.mu.Unlock()
}

// --- HTTP server factory (A15/A18/A19) --------------------------------------

// httpServerBounds are the per-server transport bounds. Production values
// are the consts below; tests reuse the SAME factory with shortened bounds
// so the regressions exercise the real wiring, not a parallel struct.
type httpServerBounds struct {
	readHeaderTimeout time.Duration
	readTimeout       time.Duration // whole request incl. body (A18)
	idleTimeout       time.Duration
	maxHeaderBytes    int
}

// Production transport bounds. The 32 KiB header bound comfortably fits the
// largest declared credential (8 KiB broker JWT, 8 KiB legacy Google ID
// token in the request line) plus normal header sets, while still bounding
// header parsing on the 512 MiB box. The 60 s whole-request read deadline
// (A18) covers headers + body: identity's own AuthTimeout context cannot
// unblock a stalled Body.Read — only a transport deadline can — and after
// an upgrade gorilla clears the conn deadlines, so long-lived WebSocket
// sessions are governed by their own pipe/mux deadlines, not this one.
const (
	prodReadHeaderTimeout = 10 * time.Second
	prodReadTimeout       = 60 * time.Second
	prodIdleTimeout       = 120 * time.Second
	prodMaxHeaderBytes    = 32 * 1024
)

var (
	serviceServerBounds = httpServerBounds{
		readHeaderTimeout: prodReadHeaderTimeout,
		readTimeout:       prodReadTimeout,
		idleTimeout:       prodIdleTimeout,
		maxHeaderBytes:    prodMaxHeaderBytes,
	}
	// The ACME :80 listener serves only challenge GETs and /healthz; its
	// body deadline is tight and its pool is separate (maxACMEConns).
	acmeServerBounds = httpServerBounds{
		readHeaderTimeout: prodReadHeaderTimeout,
		readTimeout:       prodReadHeaderTimeout + prodReadTimeout/2,
		idleTimeout:       30 * time.Second,
		maxHeaderBytes:    prodMaxHeaderBytes,
	}
)

// Coordinated shutdown budgets: the service port drains live (non-hijacked)
// requests for up to 25s; the ACME :80 challenge server drains independently
// and tighter. When a Shutdown bound is spent, the drain stops waiting on
// clients: the server's owned request contexts are cancelled and every
// ordinary (non-hijacked) connection is force-closed with the standard
// http.Server.Close — a handler blocked on a dead client unblocks and the
// final join can complete. Hijacked sessions are not covered by either
// budget — they are force-closed at drain start by beginDrain and waited on
// separately. handlerJoinTimeout is the explicit bound on that final join:
// run never waits forever for a handler or legacy session that cannot
// finish, and never reports an incomplete drain as success.
const (
	serviceDrainTimeout = 25 * time.Second
	acmeDrainTimeout    = 5 * time.Second
	handlerJoinTimeout  = 10 * time.Second
)

// serviceDrainBound / acmeDrainBound / handlerJoinBound resolve the drain
// bounds: an explicit (test) value wins, the zero value is the production
// const. Test-only seams — production wiring never sets the fields.
func (cfg runtimeConfig) serviceDrainBound() time.Duration {
	if cfg.serviceDrain > 0 {
		return cfg.serviceDrain
	}
	return serviceDrainTimeout
}

func (cfg runtimeConfig) acmeDrainBound() time.Duration {
	if cfg.acmeDrain > 0 {
		return cfg.acmeDrain
	}
	return acmeDrainTimeout
}

func (cfg runtimeConfig) handlerJoinBound() time.Duration {
	if cfg.handlerJoin > 0 {
		return cfg.handlerJoin
	}
	return handlerJoinTimeout
}

// newGatewayServer builds the production HTTP server for the service port
// and (with acmeServerBounds) the ACME challenge port. HTTP/2 is explicitly
// DISABLED (finding A19): this is a WebSocket/JSON gateway whose admission
// is per-connection (the raw bounded listener), and HTTP/2 would multiplex
// unbounded concurrent streams per socket past that cap and past the body
// deadline budget. The non-nil empty TLSNextProto map is the documented
// switch that stops net/http from registering its bundled h2 handler, and
// the production TLS config never offers "h2" via ALPN (see main). TLS
// handshakes are bounded because net/http sets its header read deadline on
// the raw conn before the first read, and a tls.Conn performs its
// handshake lazily inside that first read.
func newGatewayServer(handler http.Handler, tlsCfg *tls.Config, b httpServerBounds) *http.Server {
	return &http.Server{
		Handler:           handler,
		ReadHeaderTimeout: b.readHeaderTimeout,
		ReadTimeout:       b.readTimeout,
		IdleTimeout:       b.idleTimeout,
		MaxHeaderBytes:    b.maxHeaderBytes,
		TLSConfig:         tlsCfg,
		TLSNextProto:      map[string]func(*http.Server, *tls.Conn, http.Handler){},
	}
}

// productionTLSConfig is THE TLS policy constructor for the service port:
// run builds its listener config through this exact function, and the ALPN
// regression tests it directly — there is no parallel policy struct.
// Certificates come from the autocert manager (HTTP-01 on :80;
// TLS-ALPN-01 is not offered), the floor is TLS 1.2, and ALPN advertises
// ONLY http/1.1: together with the empty TLSNextProto map in
// newGatewayServer this pins HTTP/2 off (A19), so per-socket admission and
// the body-read deadline cannot be multiplexed past.
func productionTLSConfig(getCertificate func(*tls.ClientHelloInfo) (*tls.Certificate, error)) *tls.Config {
	return &tls.Config{
		GetCertificate: getCertificate,
		MinVersion:     tls.VersionTLS12,
		NextProtos:     []string{"http/1.1"},
	}
}

// --- health ----------------------------------------------------------------

func healthz(w http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodGet && req.Method != http.MethodHead {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(map[string]string{
		"service":  "pocketshell-gateway",
		"version":  version,
		"commit":   commit,
		"status":   "ok",
		"registry": registryPosture,
		"tunnel":   tunnelPosture,
	})
}

// --- main / wiring ---------------------------------------------------------

// splitList parses a comma-separated flag into a clean slice.
func splitList(raw string) []string {
	var out []string
	for _, e := range strings.Split(raw, ",") {
		if e = strings.TrimSpace(e); e != "" {
			out = append(out, strings.ToLower(e))
		}
	}
	return out
}

// parseOrigins turns the -origins flag (or the default) into the exact-match
// set. Only http(s) scheme://host entries are accepted; anything with a path,
// userinfo, or another scheme is dropped, so a sloppy flag can't quietly
// widen the gate.
func parseOrigins(raw string) map[string]bool {
	set := make(map[string]bool)
	for _, o := range splitList(raw) {
		u, err := url.Parse(o)
		if err != nil || (u.Scheme != "https" && u.Scheme != "http") || u.Host == "" {
			continue
		}
		if u.Path != "" && u.Path != "/" {
			continue
		}
		if u.User != nil {
			continue
		}
		set[strings.ToLower(u.Scheme)+"://"+strings.ToLower(u.Host)] = true
	}
	return set
}

// hostWhitelist is the autocert HostPolicy over canonical + aliases. Case
// is folded; exact names only, no suffix wildcards — a stray hostname must
// never trigger an ACME order.
func hostWhitelist(names ...string) func(context.Context, string) error {
	allowed := make(map[string]bool, len(names))
	for _, n := range names {
		if n = strings.ToLower(strings.TrimSuffix(strings.TrimSpace(n), ".")); n != "" {
			allowed[n] = true
		}
	}
	return func(_ context.Context, host string) error {
		host = strings.ToLower(strings.TrimSuffix(host, "."))
		if _, ok := allowed[host]; ok {
			return nil
		}
		return fmt.Errorf("host %q not in configured whitelist", host)
	}
}

// validateRegistryPath enforces the state-location rule: the new API may
// only be enabled with its durable state under /var/lib/pocketshell-relay.
// Empty means disabled, which is the fail-closed default.
func validateRegistryPath(p string) error {
	if p == "" {
		return nil
	}
	if !filepath.IsAbs(p) {
		return fmt.Errorf("-registry must be an absolute path under %s", registryBaseDir)
	}
	clean := filepath.Clean(p)
	if clean != registryBaseDir && !strings.HasPrefix(clean, registryBaseDir+string(filepath.Separator)) {
		return fmt.Errorf("-registry must live under %s", registryBaseDir)
	}
	return nil
}

// validateConfig holds the startup invariants main refuses to violate.
// brokerInsecure is the -broker-allow-insecure-dev opt-in: plain-http broker
// URLs may exist only on a dev-listen (domain-less) process, never next to
// a production TLS listener.
func validateConfig(domain string, skipAuth, allowPrivate, brokerInsecure bool, allowlist []string, registry string) error {
	if (skipAuth || allowPrivate) && domain != "" {
		return errors.New("-dev-* flags must not be combined with a public domain")
	}
	if (skipAuth || allowPrivate) && registry != "" {
		return errors.New("-dev-* flags must not be combined with -registry (no unauthenticated bypass next to the new API)")
	}
	if brokerInsecure && domain != "" {
		return errors.New("-broker-allow-insecure-dev must not be combined with a public domain")
	}
	if domain != "" && len(allowlist) == 0 {
		return errors.New("refusing to start with an empty allowlist (fail closed); pass -allow or use a dev flag")
	}
	return validateRegistryPath(registry)
}

// stringFlag is a flag.Value that remembers whether it was explicitly set,
// so an explicit `-origins=` (deny all browser origins) is distinguishable
// from an untouched default.
type stringFlag struct {
	set bool
	val string
}

func (f *stringFlag) String() string { return f.val }
func (f *stringFlag) Set(s string) error {
	f.set = true
	f.val = s
	return nil
}

// tunnelPosture is what /healthz reports about the reverse tunnel: it is
// only "enabled" when the tunnel service itself constructed — a configured
// registry alone is NOT a running tunnel.
var tunnelPosture = "disabled"

// newAPI bundles the successfully constructed new-API services. A nil
// field means that piece is not serving; posture vars carry the reason.
type newAPI struct {
	identitySvc *identity.Service
	tunnelSvc   *tunnel.Service
}

// handler returns the mux subtree handler for each service, nil when the
// service did not construct (fail closed: nothing is mounted).
func (n *newAPI) identityHandler() http.Handler {
	if n == nil || n.identitySvc == nil {
		return nil
	}
	return n.identitySvc.Handler()
}

func (n *newAPI) tunnelHandler() http.Handler {
	if n == nil || n.tunnelSvc == nil {
		return nil
	}
	return n.tunnelSvc
}

// close tears the tunnel down (SIGTERM path): every host agent and client
// stream disconnects, and the service refuses new work.
func (n *newAPI) close() {
	if n != nil && n.tunnelSvc != nil {
		n.tunnelSvc.Close()
	}
}

// sortedOrigins renders the origin set as a stable sorted list (for the
// tunnel service's allowlist and for logs).
func sortedOrigins(set map[string]bool) []string {
	out := make([]string, 0, len(set))
	for o := range set {
		out = append(out, o)
	}
	sort.Strings(out)
	return out
}

// newHandler routes /healthz (plain JSON for CI, no auth, no secrets) to
// healthz, the identity registry API (when a registry is configured) to
// /identity/v1/, the reverse tunnel (when it constructed) to /api/v1/, and
// everything else — including the legacy WS endpoint at "/" — to the relay.
// The tunnel service owns its published client route
// /api/v1/hosts/{deviceID}/ssh end to end (parseClientSSHPath), so root
// wiring adds no path rewriting — one API contract, owned by one package.
func newHandler(r *relay, api *newAPI) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/healthz", healthz)
	if h := api.identityHandler(); h != nil {
		mux.Handle("/identity/v1/", h)
	}
	if h := api.tunnelHandler(); h != nil {
		mux.Handle("/api/v1/", h)
	}
	mux.Handle("/", r)
	return mux
}

// buildRegistry constructs the identity service for the new versioned API.
// The verifier is the scoped broker-JWT verifier — a Google ID token is
// NEVER accepted here (finding C2): a Google bearer would carry sync CRUD
// authority over the encrypted vault into the gateway. Fails closed: nil
// service + "failed" posture on any error; the legacy proxy keeps running.
func buildRegistry(domain string, storePath string, verifier identity.TokenVerifier) *identity.Service {
	return buildRegistryWith(identity.Config{
		Verifier:  verifier,
		StorePath: storePath,
		Domain:    domain,
		Logger:    func(format string, args ...any) { log.Printf("identity: "+format, args...) },
	})
}

// identityRequestReadDeadline is the network read deadline the root wiring
// hands to the identity service (Config.RequestReadDeadline). Identity's
// strict body decoder waits for the definitive END of the body, so a body
// stalled forever needs a real network deadline to unblock it. The
// whole-server 60s ReadTimeout covers that route only as an outer bound
// shared with every other route — weaker than the strict-body discipline
// intends — so identity bodies get their own tighter bound (matching the
// legacy auth/handshake budget) through http.ResponseController, which
// becomes the EFFECTIVE deadline on those routes (the handler's
// SetReadDeadline overrides the server's absolute one).
const identityRequestReadDeadline = 15 * time.Second

// effectiveRequestReadDeadline preserves an explicit operator/test value
// and fills the production default only when unset.
func effectiveRequestReadDeadline(d time.Duration) time.Duration {
	if d != 0 {
		return d
	}
	return identityRequestReadDeadline
}

func buildRegistryWith(cfg identity.Config) *identity.Service {
	registryPosture = "disabled"
	tunnelPosture = "disabled"
	// Configured means either a durable path (production main) or an
	// injected store (identity's documented test/e2e seam). Neither is
	// the fail-closed disabled default.
	if cfg.StorePath == "" && cfg.Store == nil {
		return nil
	}
	cfg.RequestReadDeadline = effectiveRequestReadDeadline(cfg.RequestReadDeadline)
	svc, err := identity.NewService(cfg)
	if err != nil {
		registryPosture = "failed"
		log.Printf("registry DISABLED (fail closed): %v", err)
		return nil
	}
	registryPosture = "enabled"
	log.Printf("registry enabled at %s (identity API under /identity/v1/, scoped broker credentials only)", cfg.StorePath)
	return svc
}

// typed adapters between the identity and tunnel packages. Both sides use
// distinct named types; the mappings below are the ONLY conversion points
// and they copy field by field (no struct-cast shortcuts), so a field added
// to either side is a compile-visible wiring decision.

// tunnelStoreAdapter adapts identity.DeviceStore (enrolled devices) to the
// read path the tunnel service requires.
type tunnelStoreAdapter struct {
	inner identity.DeviceStore
}

func (a tunnelStoreAdapter) GetDevice(id string) (tunnel.Device, error) {
	d, err := a.inner.GetDevice(id)
	if err != nil {
		return tunnel.Device{}, err
	}
	return tunnel.Device{
		ID:         d.ID,
		AccountID:  d.AccountID,
		PublicKey:  d.PublicKey,
		SSHHostKey: d.SSHHostKey,
		Revoked:    d.Revoked,
	}, nil
}

// tunnelAuthAdapter adapts the identity service's token authenticator (the
// expiry-gated scoped-credential verifier) to the tunnel's authenticate
// contract. The tunnel's Principal now carries ExpiresAt and fails closed
// on a zero/expired value at admission, so the field is copied — admission
// expiry is preserved end to end through the only conversion point.
// SESSION-LIFETIME POLICY (finding F-14, stated honestly): the short
// broker JWT governs ADMISSION; an admitted session is bounded by the
// tunnel's absolute MaxSessionDuration, not re-checked against the token's
// exp mid-session.
type tunnelAuthAdapter struct {
	inner identity.Authenticate
}

func (a tunnelAuthAdapter) Authenticate(ctx context.Context, token string) (tunnel.Principal, error) {
	p, err := a.inner(ctx, token)
	if err != nil {
		return tunnel.Principal{}, err
	}
	return tunnel.Principal{
		AccountID: p.AccountID,
		Email:     p.Email,
		ExpiresAt: p.ExpiresAt,
	}, nil
}

// tunnelPresenceAdapter adapts the tunnel's ready-host snapshot to the
// identity service's presence source (GET /identity/v1/devices). Field by
// field, like the other adapters: presence is derived from the ACTUAL
// ready host-agent state, never from the durable registry alone.
type tunnelPresenceAdapter struct {
	inner *tunnel.Service
}

func (a tunnelPresenceAdapter) Snapshot(accountID string, deviceIDs []string) (time.Time, map[string]identity.DevicePresence) {
	observed, live := a.inner.PresenceSnapshot(accountID, deviceIDs)
	out := make(map[string]identity.DevicePresence, len(live))
	for id, p := range live {
		out[id] = identity.DevicePresence{
			Online:         p.Online,
			ConnectedSince: p.ConnectedSince,
			Session:        p.Session,
		}
	}
	return observed, out
}

// buildTunnel constructs the reverse-tunnel service on top of a
// successfully constructed identity service. Returns nil (and sets the
// tunnel posture honestly) when anything is missing — a constructed
// registry alone must never be reported as a running tunnel.
func buildTunnel(idSvc *identity.Service, origins []string, limits tunnel.Limits) *tunnel.Service {
	tunnelPosture = "disabled"
	if idSvc == nil {
		return nil
	}
	svc, err := tunnel.NewService(tunnel.ServiceOptions{
		Store: tunnelStoreAdapter{inner: idSvc.DeviceStore()},
		// ServiceOptions.Authenticate is a named func type; the adapter
		// struct stays the single conversion point and the closure here is
		// plain delegation.
		Authenticate: func(ctx context.Context, token string) (tunnel.Principal, error) {
			return tunnelAuthAdapter{inner: idSvc.TokenAuthenticator()}.Authenticate(ctx, token)
		},
		AllowedOrigins: origins,
		Limits:         limits,
		Logger:         slog.Default(),
	})
	if err != nil {
		tunnelPosture = "failed"
		log.Printf("tunnel DISABLED (fail closed): %v", err)
		return nil
	}
	// Revocation ordering (finding A1, stated precisely): the identity
	// service APPLIES the revocation first (atomic rename + key tombstone)
	// and then fires OnRevoke — the callback disconnects the device's host
	// agent and every stream riding on it. The durable flush is NOT a
	// precondition of the callback: when durability is unproven the
	// containment has already fired even though the caller sees 500, and
	// only the 200 ACK is gated on the proven flush. Registrations that
	// raced the revoke lose: the tunnel samples the revocation epoch
	// before the device lookup and re-checks it under its mutex at insert
	// time.
	idSvc.OnRevoke(func(d identity.Device) {
		svc.RevokeDevice(d.ID)
	})
	// Passive presence: the device list reports, per caller-owned device,
	// whether its host agent is ready on THIS tunnel right now.
	idSvc.SetPresenceSource(tunnelPresenceAdapter{inner: svc}.Snapshot)
	tunnelPosture = "enabled"
	log.Printf("tunnel enabled (host agents under /api/v1/agent/connect, clients under /api/v1/hosts/{id}/ssh)")
	return svc
}

// runtimeConfig carries the parsed operator configuration from main into
// run, the process lifecycle entrypoint.
type runtimeConfig struct {
	domain       string
	aliases      []string
	listen       string
	acmeAddr     string
	certDir      string
	origins      map[string]bool
	clientID     string
	allow        []string
	registry     string
	broker       brokerConfig
	skipAuth     bool
	allowPrivate bool
	staging      bool
	tunnel       tunnel.Limits

	// newListener is the listener factory; the zero value (production)
	// uses net.Listen. Test-only seam: the lifecycle regressions inject a
	// factory here to drive REAL in-Serve failures (a listener that dies
	// while Serve is running) through the actual entrypoint.
	newListener func(network, addr string) (net.Listener, error)

	// newTracker is the lifecycle-tracker factory; the zero value
	// (production) builds a fresh handlerTracker. Test-only seam (mirrors
	// newListener): the drain regressions inject a tracker they hold so
	// handler completions can be parked at the deterministic doneGate seam
	// while run's join is observed.
	newTracker func() *handlerTracker

	// Drain-bound seams; the zero value uses the production consts
	// (serviceDrainBound/acmeDrainBound/handlerJoinBound resolve them).
	// Test-only: the drain-deadline regressions shorten the bounds so the
	// deadline path is driven deterministically instead of waiting out the
	// 25s production budget. Production wiring never sets these.
	serviceDrain time.Duration
	acmeDrain    time.Duration
	handlerJoin  time.Duration
}

// run is the process lifecycle entrypoint: it validates the configuration,
// wires the services, binds the listeners, and serves until ctx is
// cancelled (SIGTERM/SIGINT) or a server fails for real — then coordinates
// the FULL drain (tunnel teardown, both HTTP servers, and every hijacked
// SSH session) before returning. A clean shutdown returns nil; any real
// failure is returned and main exits non-zero.
//
// Astra P1: http.Server.Serve returns http.ErrServerClosed on every
// coordinated Shutdown. The previous log.Fatal(Serve(...)) wiring treated
// that expected return as a crash: a bare SIGTERM exited the process
// mid-drain — before the tunnel/API close finished, before the legacy
// sessions were torn down, and regardless of what the ACME goroutine was
// still doing (whose own log.Fatal could likewise kill the whole process
// the moment its server stopped). No serving path calls log.Fatal anymore:
// expected shutdown returns are handled, real failures join the same
// coordinated drain and are surfaced as run's error.
func run(ctx context.Context, cfg runtimeConfig) error {
	if err := validateConfig(cfg.domain, cfg.skipAuth, cfg.allowPrivate, cfg.broker.insecureDev, cfg.allow, cfg.registry); err != nil {
		return err
	}

	r := newRelay()
	r.clientID = cfg.clientID
	r.allow = cfg.allow
	r.skipAuth = cfg.skipAuth
	r.allowPrivateHosts = cfg.allowPrivate
	r.origins = cfg.origins

	// New API: scoped broker credentials only (never Google ID tokens),
	// wrapped in the expiry/context gate so zero-expiry, expired, or
	// cancelled admissions are rejected before any handler.
	brokerVer, err := newBrokerVerifier(cfg.broker)
	if err != nil {
		return fmt.Errorf("broker verifier: %w", err)
	}
	gated := expiryGate{inner: brokerVer}

	var api *newAPI
	if cfg.registry != "" {
		idSvc := buildRegistry(cfg.domain, cfg.registry, gated)
		api = &newAPI{identitySvc: idSvc}
		api.tunnelSvc = buildTunnel(idSvc, sortedOrigins(cfg.origins), cfg.tunnel)
	}

	// The lifecycle context: cancelled by the signal (parent context) or by
	// the first real server failure — both trigger the identical drain.
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	r.baseCtx = ctx

	// Root-owned lifecycle authority over every in-flight service-port
	// handler (see handlerTracker): http.Server.Shutdown ignores hijacked
	// sockets, and tunnel.Service.Close does not cover pre-authentication
	// upgraded agents, pre-auth clients or the bridges — the tracker is
	// what makes the drain below complete instead of merely returning.
	tracker := newHandlerTracker()
	if cfg.newTracker != nil {
		tracker = cfg.newTracker()
	}

	// Owned request-context cancellation for the drain (see the drain
	// goroutine): each HTTP server's request contexts derive from a
	// lifecycle-owned context that stays live through the graceful drain
	// window and is cancelled ONLY when that server's drain bound is spent.
	// A handler honouring req.Context() unblocks at the force-close moment;
	// no goroutine is ever killed. (Deliberately NOT a child of the
	// lifecycle context: that would cancel request contexts at drain START
	// and silently end the graceful window.)
	serviceCtx, serviceCancel := context.WithCancel(context.Background())
	defer serviceCancel()

	server := newGatewayServer(tracker.track(newHandler(r, api)), nil, serviceServerBounds)
	server.BaseContext = func(net.Listener) context.Context { return serviceCtx }

	// A15: bind and bound the RAW listener before any TLS/HTTP work. One
	// semaphore covers every accepted socket on the service port — legacy
	// WS (hijacked conns release their slot only when the tunneling code
	// closes them, which LimitListener's close-once wrapper handles),
	// tunnel agents/clients, and unparsed handshakes alike.
	bind := cfg.newListener
	if bind == nil {
		bind = net.Listen
	}
	ln, err := bind("tcp", cfg.listen)
	if err != nil {
		return err
	}
	serviceLn := netutil.LimitListener(ln, maxServiceConns)

	var challenge *http.Server
	// acmeCancel cancels the ACME server's owned request contexts (see
	// serviceCtx above); nil with no ACME server (dev).
	var acmeCancel context.CancelFunc
	// acmeServed closes when the ACME serving goroutine has returned; with
	// no ACME server (dev) it is born closed so the lifecycle wait below is
	// a no-op.
	acmeServed := make(chan struct{})
	if cfg.domain == "" {
		close(acmeServed)
	}
	// First real server failure: recorded once as the lifecycle error and
	// turned into the same coordinated shutdown a SIGTERM gets.
	var (
		failOnce sync.Once
		firstErr error
	)
	fail := func(err error) {
		if err == nil {
			return
		}
		failOnce.Do(func() {
			firstErr = err
			cancel()
		})
	}
	if cfg.domain != "" {
		hosts := append([]string{cfg.domain}, cfg.aliases...)
		manager := &autocert.Manager{
			Prompt:     autocert.AcceptTOS,
			HostPolicy: hostWhitelist(hosts...),
			Cache:      autocert.DirCache(filepath.Join(cfg.certDir, "certs")),
			Email:      "alexey.s.grigoriev@gmail.com",
		}
		if cfg.staging {
			manager.Client = &acme.Client{DirectoryURL: "https://acme-staging-v02.api.letsencrypt.org/directory"}
		}

		// Port 80: ACME challenges + plain-HTTP health probe. No redirect —
		// WS alias hostnames must not bounce, and nothing else lives here.
		// Independent, smaller admission pool: certificate churn must never
		// compete with the service port for slots.
		acmeMux := http.NewServeMux()
		acmeMux.HandleFunc("/healthz", healthz)
		acmeMux.Handle("/", manager.HTTPHandler(nil))
		acmeLn, err := bind("tcp", cfg.acmeAddr)
		if err != nil {
			// Don't leak the already-bound service port on this path: the
			// lifecycle never started serving, so nothing else owns it.
			serviceLn.Close()
			return err
		}
		challenge = newGatewayServer(acmeMux, nil, acmeServerBounds)
		challenge.Addr = cfg.acmeAddr
		acmeCtx, cancel := context.WithCancel(context.Background())
		defer cancel()
		acmeCancel = cancel
		challenge.BaseContext = func(net.Listener) context.Context { return acmeCtx }

		// ACME serving goroutine: ErrServerClosed is the expected
		// coordinated shutdown, not a crash (P1 — the old log.Fatal here
		// exited the whole process the moment this server stopped). A real
		// failure fails the lifecycle instead, cancelling the context so
		// the service server drains too, and is surfaced as run's error.
		acmeServed = make(chan struct{})
		go func() {
			defer close(acmeServed)
			log.Printf("ACME challenge server on %s (hosts: %s)", cfg.acmeAddr, strings.Join(hosts, ", "))
			if err := challenge.Serve(netutil.LimitListener(acmeLn, maxACMEConns)); !errors.Is(err, http.ErrServerClosed) {
				fail(fmt.Errorf("acme challenge server: %w", err))
			}
		}()

		// Production TLS policy: certificates come from the autocert
		// manager (HTTP-01 challenges on :80; TLS-ALPN-01 is not offered).
		// The policy is built by productionTLSConfig — THE shared constructor —
		// so the ALPN regression tests the exact function production runs,
		// not a parallel struct. (Its ALPN list is only http/1.1, which with
		// the empty TLSNextProto map pins HTTP/2 off — A19.)
		server.TLSConfig = productionTLSConfig(manager.GetCertificate)
	}

	// Drain on lifecycle exit: disconnect every tunnel host agent and
	// client stream first. The identity service has APPLIED the revocation
	// by the time OnRevoke fired (rename + tombstone precede the callback);
	// the durable flush gates only the revocation's 200 ACK, never the
	// containment — an applied-but-uncertain revoke disconnects first and
	// acknowledges later (or not at all, on a 500). Then engage the
	// root-owned admission shutter and force-close every hijacked socket
	// (invisible to Shutdown), and stop accepting and drain both HTTP
	// servers — the service port up to its 25s cap, the ACME :80 port
	// independently in 5s. A drain that fails (Shutdown deadline) is
	// recorded as the lifecycle error: run never claims a complete drain
	// that did not happen. On the deadline the drain also stops waiting on
	// clients that will not finish: the server's owned request contexts are
	// cancelled and every ordinary (non-hijacked) connection is
	// force-closed with the standard http.Server.Close, so a handler
	// blocked on a dead client unblocks instead of outliving the budget —
	// beginDrain covered only the hijacked sockets, and Close leaves those
	// alone (they are already closed and tracker-owned).
	drained := make(chan struct{})
	go func() {
		defer close(drained)
		<-ctx.Done()
		api.close()
		tracker.beginDrain()
		var wg sync.WaitGroup
		wg.Add(1)
		go func() {
			defer wg.Done()
			sctx, scancel := context.WithTimeout(context.Background(), cfg.serviceDrainBound())
			defer scancel()
			if err := server.Shutdown(sctx); err != nil {
				fail(fmt.Errorf("service drain: %w", err))
				serviceCancel()
				if cerr := server.Close(); cerr != nil {
					fail(fmt.Errorf("service force-close: %w", cerr))
				}
			}
		}()
		if challenge != nil {
			wg.Add(1)
			go func() {
				defer wg.Done()
				actx, acancel := context.WithTimeout(context.Background(), cfg.acmeDrainBound())
				defer acancel()
				if err := challenge.Shutdown(actx); err != nil {
					// Same honest policy on the ACME port: the spent
					// graceful window is recorded, then the remaining
					// ordinary connections are force-closed (its handlers
					// are plain challenge GETs / healthz, so the join here
					// is the Shutdown bound plus Close, and the Serve
					// goroutine's own exit below).
					fail(fmt.Errorf("acme drain: %w", err))
					acmeCancel()
					if cerr := challenge.Close(); cerr != nil {
						fail(fmt.Errorf("acme force-close: %w", cerr))
					}
				}
			}()
		}
		wg.Wait()
	}()

	if cfg.domain == "" {
		log.Printf("pocketshell relay (DEV, plain WS) on %s", cfg.listen)
		log.Printf("/healthz version=%s commit=%s registry=%s tunnel=%s", version, commit, registryPosture, tunnelPosture)
	} else {
		log.Printf("pocketshell relay (WSS) %s aliases=[%s] on %s", cfg.domain, strings.Join(cfg.aliases, ","), cfg.listen)
		log.Printf("/healthz version=%s commit=%s registry=%s tunnel=%s", version, commit, registryPosture, tunnelPosture)
	}

	// Serve until the lifecycle ends. Production wraps the bounded raw
	// listener in TLS (autocert stays intact: GetCertificate is consulted
	// per handshake, and Shutdown closes it, releasing the semaphore via
	// LimitListener's done channel).
	var serveErr error
	if challenge != nil {
		serveErr = server.Serve(tls.NewListener(serviceLn, server.TLSConfig))
	} else {
		serveErr = server.Serve(serviceLn)
	}
	if !errors.Is(serveErr, http.ErrServerClosed) {
		fail(fmt.Errorf("service server: %w", serveErr))
	}

	// Full-drain completion: both servers stopped, then every remaining
	// handler joined — the legacy relay's hijacked WebSocket legs
	// (relay.sessions), and every service-port handler the tracker owns:
	// tunnel host agents still before their signed proof, client
	// WebSockets still before their first auth frame, live bridges, and
	// mid-flight plain requests. beginDrain already closed their sockets,
	// and a spent Shutdown bound additionally cancelled the owned request
	// contexts and force-closed the ordinary connections, so these waits
	// are bounded by local teardown, not by clients. The join itself is
	// explicit policy, not a leap of faith: it honours handlerJoinTimeout
	// — run NEVER waits forever for a handler or legacy session that
	// cannot finish, and NEVER reports an incomplete drain as success. A
	// join that outlives the bound (or a Shutdown that hit its bound) is
	// recorded via fail as firstErr and returned: a non-nil return is the
	// honest "incomplete drain" signal.
	<-acmeServed
	<-drained
	join := cfg.handlerJoinBound()
	if !r.waitIdleBounded(join) {
		fail(fmt.Errorf("handler join: legacy relay sessions still live after %s", join))
	}
	if !tracker.waitIdleBounded(join) {
		fail(fmt.Errorf("handler join: %d tracked handler(s) still live after %s", tracker.inFlightCount(), join))
	}
	return firstErr
}

func main() {
	domain := flag.String("domain", "", "public hostname for ACME TLS (empty = plain HTTP, dev only)")
	aliases := flag.String("aliases", "", "comma-separated extra TLS hostnames (e.g. relay.pocketshell.io); whitelisted for autocert, never redirected")
	listen := flag.String("listen", ":443", "listen address for the (W)SS server")
	acmeAddr := flag.String("acme", ":80", "listen address for the ACME HTTP-01 challenge")
	certDir := flag.String("certdir", registryBaseDir, "autocert cache directory")
	origins := &stringFlag{val: defaultOrigins}
	flag.Var(origins, "origins", "comma-separated exact browser origins allowed to open the legacy WS and the new client API; pass -origins= to deny all browser origins")
	clientID := flag.String("client-id", "1035162854462-kkqius5o2ni136ed6l58iig5pdpeh4u6.apps.googleusercontent.com", "Google OAuth client ID for the LEGACY WS endpoint only; the new API accepts scoped broker credentials exclusively")
	allow := flag.String("allow", "", "comma-separated allowlist of Google account emails (empty denies everyone; enforced on the legacy proxy and on broker credentials)")
	registry := flag.String("registry", "", "identity-registry state file/directory under "+registryBaseDir+"; the new API stays disabled unless set")
	brokerIssuer := flag.String("broker-issuer", defaultBrokerIssuer, "exact issuer of scoped gateway credentials (iss claim; token endpoint POST /gateway/token)")
	brokerJWKS := flag.String("broker-jwks", defaultBrokerIssuer+"/gateway/jwks", "signing-key set URL for scoped gateway credentials")
	brokerAud := flag.String("broker-audience", routingauth.Audience, "required audience (aud claim) of scoped gateway credentials")
	brokerInsecure := flag.Bool("broker-allow-insecure-dev", false, "DEV ONLY: permit plain-http broker issuer/JWKS URLs (local fixtures via routingauth's dev mode); refused with a public domain, TLS verification never skipped")
	ver := flag.String("version", version, "build version reported by /healthz (set via -ldflags)")
	buildCommit := flag.String("commit", commit, "build commit reported by /healthz (set via -ldflags)")
	skipAuth := flag.Bool("dev-allow-any-token", false, "DEV ONLY: accept any token without verification")
	allowPrivate := flag.Bool("dev-allow-private-hosts", false, "DEV ONLY: dial loopback/private hosts (local e2e)")
	// Conservative reverse-tunnel rollout limits for the live t4g.nano
	// (512 MiB): the aggregate budget with the legacy pool is documented in
	// docs/architecture.md §6. The tunnel clamps these to its own hard
	// ceilings; these defaults keep worst-case memory in the tens of MB.
	tunnelMaxHosts := flag.Int("tunnel-max-hosts", 64, "max concurrently connected host agents (reverse tunnel)")
	tunnelMaxClients := flag.Int("tunnel-max-clients", 64, "max concurrent client SSH sessions through the tunnel (global)")
	tunnelMaxClientsAcct := flag.Int("tunnel-max-clients-account", 8, "max concurrent client SSH sessions per account")
	tunnelMaxStreams := flag.Int("tunnel-max-streams-host", 8, "max concurrent streams per host agent")
	tunnelStreamWindow := flag.Int("tunnel-stream-window", 64*1024, "per-stream flow-control window in bytes")
	tunnelChallengeCap := flag.Int("tunnel-challenge-capacity", 256, "max outstanding host-agent challenges")
	staging := flag.Bool("staging", false, "use the Let's Encrypt staging CA")
	flag.Parse()

	version, commit = *ver, *buildCommit

	allowlist := splitList(*allow)
	// The untouched default keeps production working (app.pocketshell.io,
	// pocketshell.io); an explicitly passed list replaces it, including an
	// empty one (no browser origins at all).
	cfg := runtimeConfig{
		domain:   *domain,
		aliases:  splitList(*aliases),
		listen:   *listen,
		acmeAddr: *acmeAddr,
		certDir:  *certDir,
		origins:  parseOrigins(origins.val),
		clientID: *clientID,
		allow:    allowlist,
		registry: *registry,
		broker: brokerConfig{
			issuer:      *brokerIssuer,
			jwksURL:     *brokerJWKS,
			audience:    *brokerAud,
			allow:       allowlist,
			insecureDev: *brokerInsecure,
		},
		skipAuth:     *skipAuth,
		allowPrivate: *allowPrivate,
		staging:      *staging,
		tunnel: tunnel.Limits{
			MaxHosts:             *tunnelMaxHosts,
			MaxClientsGlobal:     *tunnelMaxClients,
			MaxClientsPerAccount: *tunnelMaxClientsAcct,
			MaxStreamsPerHost:    *tunnelMaxStreams,
			StreamWindow:         *tunnelStreamWindow,
			ChallengeCapacity:    *tunnelChallengeCap,
		},
	}

	// SIGTERM/SIGINT start the coordinated drain inside run. A clean drain
	// returns nil and the process exits 0; a real failure — refused bind,
	// failed verifier, a server that died for a reason other than the
	// shutdown — surfaces here as a non-zero exit AFTER the coordinated
	// teardown (P1: the old code log.Fatal'ed Serve's ErrServerClosed and
	// exited 1 mid-drain on every normal SIGTERM).
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if err := run(ctx, cfg); err != nil {
		log.Fatal(err)
	}
}
