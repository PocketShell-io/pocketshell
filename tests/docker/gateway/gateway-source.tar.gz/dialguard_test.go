package main

// Tests for the dial guard: syntactic host pre-filter, the resolved-IP
// gate (IPv4/IPv6/mapped/private/reserved/metadata), DNS-rebinding
// defense (resolve once, dial vetted numerics only), and the Control
// belt that refuses any address that escaped vetting.

import (
	"context"
	"errors"
	"net"
	"net/netip"
	"strings"
	"testing"
)

func aip(s string) netip.Addr { return netip.MustParseAddr(s) }

func TestIsDialableHost(t *testing.T) {
	cases := []struct {
		host string
		ok   bool
	}{
		{"example.com", true},
		{"sub.example.co.uk", true},
		{"8.8.8.8", true},
		{"2606:4700::1111", true},
		{"github.com:22", true}, // pattern allows ':' — port split happens elsewhere
		{"", false},
		{"localhost", false},
		{"foo.internal", false},
		{"machine.local", false},
		{"10.0.0.1", false},
		{"127.0.0.1", false},
		{"169.254.169.254", false},
		{"192.168.1.1", false},
		{"172.16.0.1", false},
		{"172.31.9.9", false},
		{"0.0.0.9", false},
		{"EXAMPLE.COM", false}, // lowercase-only, as the frozen worker's dial set
		{"under score", false},
		{"host/slash", false},
	}
	for _, c := range cases {
		if got := isDialableHost(c.host); got != c.ok {
			t.Errorf("isDialableHost(%q) = %v, want %v", c.host, got, c.ok)
		}
	}
}

func TestIsForbiddenIP(t *testing.T) {
	forbidden := []string{
		// IPv4 specials
		"0.0.0.0", "0.1.2.3",
		"10.1.2.3",
		"100.64.0.1", "100.100.100.200", // CGNAT incl. Alibaba-style metadata
		"127.0.0.1", "127.8.8.8",
		"169.254.169.254", "169.254.1.1", // link-local incl. EC2 IMDS
		"172.16.0.9", "172.31.255.255",
		"192.0.0.1", "192.0.2.1", "192.88.99.1", "192.168.0.1",
		"198.18.0.1", "198.19.255.255", "198.51.100.7", "203.0.113.9",
		"224.0.0.5", "239.1.2.3", "240.0.0.1", "255.255.255.255",
		// IPv6 specials
		"::",
		"::1",
		"fe80::1",
		"fec0::5",                  // deprecated site-local
		"fc00::1", "fd00:ec2::254", // ULA incl. AWS IMDS over IPv6
		"ff02::1",
		"64:ff9b::169.254.169.254", // NAT64 toward metadata
		"100::1",                   // discard-only
		"2001::1",                  // Teredo
		"2001:2::1",                // benchmarking
		"2001:10::1", "2001:20::1", // ORCHID
		"2001:db8::1",   // documentation
		"2002:a00:1::",  // 6to4 embedding 10.0.0.1
		"2002:7f00:1::", // 6to4 embedding 127.0.0.1
		// mapped IPv4 judged by the IPv4 rules
		"::ffff:127.0.0.1",
		"::ffff:10.0.0.1",
		"::ffff:169.254.169.254",
		"::ffff:192.168.0.1",
	}
	for _, s := range forbidden {
		if !isForbiddenIP(aip(s)) {
			t.Errorf("isForbiddenIP(%s) = false, want true", s)
		}
	}

	public := []string{
		"8.8.8.8",
		"1.1.1.1",
		"93.184.216.34",
		"52.213.219.13", // the gateway EIP itself must stay dialable
		"2606:4700::1111",
		"2a00:1450:4001:81b::200e",
		"::ffff:8.8.8.8", // mapped public IPv4 is fine
	}
	for _, s := range public {
		if isForbiddenIP(aip(s)) {
			t.Errorf("isForbiddenIP(%s) = true, want false", s)
		}
	}
}

func TestVetResolvedMixedAnswerPoisoned(t *testing.T) {
	// A DNS answer that mixes one forbidden record poisons the whole
	// answer — round-robin rebinding must not get a free pass.
	got := vetResolved([]netip.Addr{aip("93.184.216.34"), aip("10.0.0.9")})
	if got != nil {
		t.Fatalf("vetResolved(mixed) = %v, want nil", got)
	}
	got = vetResolved([]netip.Addr{aip("93.184.216.34")})
	if len(got) != 1 || got[0] != aip("93.184.216.34") {
		t.Fatalf("vetResolved(clean) = %v, want the single address", got)
	}
	if vetResolved(nil) != nil {
		t.Fatal("vetResolved(empty) should be nil")
	}
}

type fakeResolver struct {
	addrs map[string][]netip.Addr
	err   error
	calls int
}

func (f *fakeResolver) LookupNetIP(ctx context.Context, network, host string) ([]netip.Addr, error) {
	f.calls++
	if f.err != nil {
		return nil, f.err
	}
	if a, ok := f.addrs[host]; ok {
		return a, nil
	}
	return nil, errors.New("NXDOMAIN " + host)
}

type recordingDialer struct {
	dials []string
	err   error
}

func (d *recordingDialer) dialFunc(ctx context.Context, network, addr string) (net.Conn, error) {
	d.dials = append(d.dials, addr)
	if d.err != nil {
		return nil, d.err
	}
	c1, c2 := net.Pipe()
	go func() { // drain so server writes never block the test
		buf := make([]byte, 1024)
		for {
			if _, err := c2.Read(buf); err != nil {
				c2.Close()
				return
			}
		}
	}()
	return c1, nil
}

func vettingRelay(t *testing.T, res *fakeResolver, dial *recordingDialer) *relay {
	t.Helper()
	r := newRelay()
	r.resolver = res
	r.dialFunc = dial.dialFunc
	return r
}

func TestResolveOnceDialVettedNumeric(t *testing.T) {
	res := &fakeResolver{addrs: map[string][]netip.Addr{
		"rebind.example": {aip("93.184.216.34")},
	}}
	dial := &recordingDialer{}
	r := vettingRelay(t, res, dial)

	conn, err := r.connectTarget(context.Background(), hostPort{host: "rebind.example", port: 22})
	if err != nil {
		t.Fatalf("connectTarget: %v", err)
	}
	conn.Close()

	// Dialed the vetted numeric address, not the hostname…
	if len(dial.dials) != 1 || dial.dials[0] != "93.184.216.34:22" {
		t.Fatalf("dials = %v, want exactly [93.184.216.34:22]", dial.dials)
	}
	// …and resolved exactly once, so a rebinding resolver cannot swap the
	// address between vetting and dialing.
	if res.calls != 1 {
		t.Fatalf("resolver calls = %d, want 1", res.calls)
	}
}

func TestIPv6AndMappedDialedAsNumerics(t *testing.T) {
	res := &fakeResolver{addrs: map[string][]netip.Addr{
		"v6.example":       {aip("2606:4700::1111")},
		"mapped.example":   {aip("::ffff:8.8.8.8")},
		"mappedv4.example": {aip("::ffff:10.0.0.1")},
	}}
	dial := &recordingDialer{}
	r := vettingRelay(t, res, dial)

	conn, err := r.connectTarget(context.Background(), hostPort{host: "v6.example", port: 22})
	if err != nil {
		t.Fatalf("v6 connectTarget: %v", err)
	}
	conn.Close()
	if !strings.HasPrefix(dial.dials[0], "[2606:4700::1111]:") {
		t.Fatalf("v6 dial = %q, want [2606:4700::1111]:port", dial.dials[0])
	}

	conn, err = r.connectTarget(context.Background(), hostPort{host: "mapped.example", port: 22})
	if err != nil {
		t.Fatalf("mapped connectTarget: %v", err)
	}
	conn.Close()
	if !strings.HasPrefix(dial.dials[1], "8.8.8.8:") {
		t.Fatalf("mapped-public dial = %q, want unmapped 8.8.8.8:port", dial.dials[1])
	}

	if _, err := r.connectTarget(context.Background(), hostPort{host: "mappedv4.example", port: 22}); !errors.Is(err, errForbiddenHost) {
		t.Fatalf("mapped-private err = %v, want errForbiddenHost", err)
	}
}

func TestRebindingAnswersRejected(t *testing.T) {
	res := &fakeResolver{addrs: map[string][]netip.Addr{
		"mixed.example":      {aip("93.184.216.34"), aip("10.0.0.9")},
		"allprivate.example": {aip("192.168.0.9"), aip("172.16.0.9")},
	}}
	dial := &recordingDialer{}
	r := vettingRelay(t, res, dial)

	for _, host := range []string{"mixed.example", "allprivate.example"} {
		if _, err := r.connectTarget(context.Background(), hostPort{host: host, port: 22}); !errors.Is(err, errForbiddenHost) {
			t.Errorf("%s: err = %v, want errForbiddenHost", host, err)
		}
	}
	if len(dial.dials) != 0 {
		t.Errorf("dials = %v, want none for poisoned answers", dial.dials)
	}
}

func TestResolveFailureRejected(t *testing.T) {
	res := &fakeResolver{err: errors.New("resolver down")}
	dial := &recordingDialer{}
	r := vettingRelay(t, res, dial)
	if _, err := r.connectTarget(context.Background(), hostPort{host: "down.example", port: 22}); !errors.Is(err, errForbiddenHost) {
		t.Fatalf("err = %v, want errForbiddenHost", err)
	}
	if len(dial.dials) != 0 {
		t.Fatalf("dials = %v, want none", dial.dials)
	}
}

func TestVettedControlCallback(t *testing.T) {
	allowed := map[netip.Addr]bool{aip("8.8.8.8"): true}
	ctrl := vettedControl(allowed)
	if err := ctrl("tcp", "8.8.8.8:22", nil); err != nil {
		t.Errorf("vetted address rejected: %v", err)
	}
	for _, addr := range []string{"10.0.0.1:22", "[2606:4700::1111]:22", "::ffff:8.8.8.8:22"} {
		if err := ctrl("tcp", addr, nil); err == nil {
			t.Errorf("address %s passed vetting control, want rejection", addr)
		}
	}
	if err := vettedControl(allowed)("tcp", "garbage", nil); err == nil {
		t.Error("malformed address should error")
	}
}
