package main

// Tests for the new-API integration: the identity registry and the reverse
// tunnel mounted behind the fail-closed -registry gate, posture reporting
// in /healthz, and the guarantee that the legacy relay still owns
// everything else. Uses the identity worker's test Verifier seam, so no
// Google network is involved. The stub verifier here carries populated
// expiries; the zero-expiry case is covered explicitly in
// TestExpiryGateRejectsZeroAndExpired (broker_test.go).

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// stubVerifier is an explicit TEST verifier: account verification stubbed,
// everything else real. It populates ExpiresAt so the production expiry
// gate stays engaged unless a test deliberately exercises the zero-expiry
// rejection (TestExpiryGateRejectsZeroAndExpired in broker_test.go).
type stubVerifier struct {
	accountID string
	email     string
}

func (v stubVerifier) VerifyToken(ctx context.Context, token string) (identity.Principal, error) {
	if token == "good-bearer" {
		return identity.Principal{
			AccountID: v.accountID,
			Email:     v.email,
			ExpiresAt: time.Now().Add(5 * time.Minute),
		}, nil
	}
	return identity.Principal{}, errors.New("bad token")
}

// testIdentityReadDeadline is the test-speed identity body deadline passed
// through the SAME production wiring (buildRegistryWith preserves explicit
// nonzero values; production fills identityRequestReadDeadline = 15s). The
// A18 regression uses it to prove the identity-layer network deadline —
// not the whole-server ReadTimeout — is the effective bound on identity
// bodies.
const testIdentityReadDeadline = 900 * time.Millisecond

// registryTestAPI builds a real identity service plus a real tunnel service
// on top of it (the production wiring, with only account verification
// stubbed) and returns the bundle for mux assembly.
func registryTestAPI(t *testing.T) *newAPI {
	t.Helper()
	oldRegistry, oldTunnel := registryPosture, tunnelPosture
	t.Cleanup(func() { registryPosture, tunnelPosture = oldRegistry, oldTunnel })
	idSvc := buildRegistryWith(identity.Config{
		Verifier:            stubVerifier{accountID: "google:sub-test", email: "ops@example.com"},
		StorePath:           filepath.Join(t.TempDir(), "registry.json"),
		RequestReadDeadline: testIdentityReadDeadline,
		Logger:              func(string, ...any) {},
	})
	if idSvc == nil {
		t.Fatal("registry API should have been constructed")
	}
	if registryPosture != "enabled" {
		t.Fatalf("registry posture = %q, want enabled", registryPosture)
	}
	tunSvc := buildTunnel(idSvc, []string{"https://app.pocketshell.io"}, tunnel.Limits{
		MaxHosts: 4, MaxClientsGlobal: 4, MaxClientsPerAccount: 2, MaxStreamsPerHost: 2,
	})
	if tunSvc == nil {
		t.Fatal("tunnel service should have been constructed")
	}
	if tunnelPosture != "enabled" {
		t.Fatalf("tunnel posture = %q, want enabled", tunnelPosture)
	}
	t.Cleanup(tunSvc.Close)
	return &newAPI{identitySvc: idSvc, tunnelSvc: tunSvc}
}

// The production identity wiring must always carry a NONZERO network body
// deadline (strict-identity round-nine API): the strict decoder waits for
// the definitive end of the body, and the whole-server 60s ReadTimeout is
// only the weaker outer bound shared with every route. Explicit values
// (tests, operators) are preserved.
func TestRegistryWiringFillsIdentityReadDeadline(t *testing.T) {
	if got := effectiveRequestReadDeadline(0); got != identityRequestReadDeadline || got <= 0 {
		t.Fatalf("zero config must fill the production identity deadline, got %v", got)
	}
	if got := effectiveRequestReadDeadline(3 * time.Second); got != 3*time.Second {
		t.Fatalf("explicit deadline must be preserved verbatim, got %v", got)
	}
	// The same wiring site is what production uses, so the default above is
	// not a parallel constant: buildRegistryWith applies it (behavioral
	// proof of effectiveness lives in TestRequestBodyDeadlineBoundsStalledIdentityRequests,
	// which closes stalled bodies via the identity deadline while the
	// server bound is still far away).
}

func TestNewAPIDisabledEndpointsFailClosed(t *testing.T) {
	r := testRelay()
	s := httptest.NewServer(newHandler(r, nil))
	defer s.Close()

	// Without -registry neither mount exists: requests fall through to the
	// legacy relay and are refused as non-WebSocket.
	for _, path := range []string{"/identity/v1/challenge", "/api/v1/agent/connect", "/api/v1/hosts/dev-1/ssh"} {
		res, err := http.Post(s.URL+path, "application/json", strings.NewReader(`{}`))
		if err != nil {
			t.Fatal(err)
		}
		res.Body.Close()
		if res.StatusCode < 300 {
			t.Errorf("new-API endpoint %s reachable without registry: status %d", path, res.StatusCode)
		}
	}
}

func TestNewAPIMountedAndFailClosed(t *testing.T) {
	api := registryTestAPI(t)
	r := testRelay()
	s := httptest.NewServer(newHandler(r, api))
	defer s.Close()

	health := func() map[string]string {
		res, err := http.Get(s.URL + "/healthz")
		if err != nil {
			t.Fatal(err)
		}
		defer res.Body.Close()
		var out map[string]string
		if err := json.NewDecoder(res.Body).Decode(&out); err != nil {
			t.Fatal(err)
		}
		return out
	}
	h := health()
	if h["registry"] != "enabled" || h["tunnel"] != "enabled" {
		t.Fatalf("healthz postures = %+v, want registry=enabled tunnel=enabled", h)
	}

	post := func(path, body, bearer string) (int, []byte) {
		req, _ := http.NewRequest(http.MethodPost, s.URL+path, strings.NewReader(body))
		req.Header.Set("Content-Type", "application/json")
		if bearer != "" {
			req.Header.Set("Authorization", "Bearer "+bearer)
		}
		res, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer res.Body.Close()
		b, _ := io.ReadAll(res.Body)
		return res.StatusCode, b
	}

	// No bearer / bad bearer: 401, fail closed — on the real identity API.
	for _, bearer := range []string{"", "bad-bearer"} {
		code, _ := post("/identity/v1/challenge", `{"device_id":"laptop-1"}`, bearer)
		if code != http.StatusUnauthorized {
			t.Fatalf("challenge with bearer %q: status %d, want 401", bearer, code)
		}
	}

	// Good bearer: the identity API actually answers through our mux.
	code, body := post("/identity/v1/challenge", `{"device_id":"laptop-1"}`, "good-bearer")
	if code != http.StatusOK {
		t.Fatalf("challenge with good bearer: status %d, body %s", code, body)
	}
	var ch map[string]any
	if err := json.Unmarshal(body, &ch); err != nil {
		t.Fatalf("challenge response not JSON: %v", err)
	}
	for _, key := range []string{"challenge_id", "nonce", "transcript"} {
		if _, ok := ch[key]; !ok {
			t.Errorf("challenge response missing %q: %s", key, body)
		}
	}

	// The tunnel endpoint exists but speaks WebSocket: a plain POST is
	// refused, proving the mount is live and gated.
	code, _ = post("/api/v1/agent/connect", `{}`, "")
	if code != http.StatusUpgradeRequired && code != http.StatusMethodNotAllowed {
		t.Fatalf("agent/connect plain POST = %d, want 405/426 (mounted, WS-only)", code)
	}

	// The legacy relay still owns "/" and everything non-health.
	res, err := http.Get(s.URL + "/?host=example.com&port=22")
	if err != nil {
		t.Fatal(err)
	}
	res.Body.Close()
	if res.StatusCode != http.StatusUpgradeRequired {
		t.Fatalf("legacy root = %d, want 426", res.StatusCode)
	}
}

func TestFailedRegistryPostureInHealthz(t *testing.T) {
	oldRegistry, oldTunnel := registryPosture, tunnelPosture
	t.Cleanup(func() { registryPosture, tunnelPosture = oldRegistry, oldTunnel })
	// An unusable config (no verifier, no client ID — the new API has no
	// Google fallback) must fail construction.
	if svc := buildRegistryWith(identity.Config{StorePath: filepath.Join(t.TempDir(), "registry.json")}); svc != nil {
		t.Fatal("unconstructable registry must return nil")
	}
	if registryPosture != "failed" {
		t.Fatalf("registry posture = %q, want failed", registryPosture)
	}
	// Tunnel on top of a failed registry must NOT claim enabled.
	if svc := buildTunnel(nil, nil, tunnel.Limits{}); svc != nil {
		t.Fatal("tunnel on failed registry must return nil")
	}
	if tunnelPosture != "disabled" {
		t.Fatalf("tunnel posture = %q, want disabled (a configured registry alone is not a running tunnel)", tunnelPosture)
	}
	// With the services nil, /identity/v1/ and /api/v1/ are unmapped →
	// legacy relay → 4xx.
	s := httptest.NewServer(newHandler(testRelay(), &newAPI{}))
	defer s.Close()
	res, err := http.Post(s.URL+"/identity/v1/challenge", "application/json", strings.NewReader("{}"))
	if err != nil {
		t.Fatal(err)
	}
	res.Body.Close()
	if res.StatusCode < 400 {
		t.Fatalf("failed-registry endpoint answered %d, want rejection", res.StatusCode)
	}
}

func TestTypedStoreAdapterPreservesRevocation(t *testing.T) {
	api := registryTestAPI(t)
	dev := identity.Device{
		ID:         "laptop-1",
		AccountID:  "google:sub-test",
		SSHHostKey: "ssh-ed25519 AAAAtest laptop",
		PublicKey:  make([]byte, 32),
	}
	if err := api.identitySvc.DeviceStore().Put(dev); err != nil {
		t.Fatalf("seed device: %v", err)
	}
	// The identity→tunnel OnRevoke callback is wired in buildTunnel:
	// revoking through the identity DeviceStore must be visible to the
	// tunnel through the typed adapter (the revocation is APPLIED —
	// rename + tombstone — before the callback fires; the unproven flush
	// only withholds the 200 ACK, never the containment, finding A1).
	// Revoke returns acknowledged=false with ErrDurabilityUncertain when
	// the flush is unproven — the applied containment still reaches the
	// callback.
	revoked, _, acknowledged, err := api.identitySvc.DeviceStore().Revoke("laptop-1", "google:sub-test")
	if err != nil || !acknowledged {
		t.Fatalf("revoke: acknowledged=%v err=%v", acknowledged, err)
	}
	if !revoked.Revoked {
		t.Fatal("revoked device not returned as revoked")
	}
	got, err := tunnelStoreAdapter{inner: api.identitySvc.DeviceStore()}.GetDevice("laptop-1")
	if err != nil {
		t.Fatalf("adapter read: %v", err)
	}
	if !got.Revoked {
		t.Fatal("revoked flag must survive the typed store adapter")
	}
	if got.AccountID != dev.AccountID || got.ID != dev.ID || string(got.PublicKey) != string(dev.PublicKey) || got.SSHHostKey != dev.SSHHostKey {
		t.Fatalf("adapter lost or altered fields: %+v", got)
	}
	// Unknown devices stay errors through the adapter.
	adapter := tunnelStoreAdapter{inner: api.identitySvc.DeviceStore()}
	if _, err := adapter.GetDevice("nope"); err == nil {
		t.Fatal("unknown device must error through the adapter")
	}
	// Historical revoked keys must never be re-admitted (round three):
	// a new device reusing the revoked key under a different ID is
	// refused by the store, and the adapter surfaces the failure closed.
	reused := dev
	reused.ID = "laptop-2"
	if err := api.identitySvc.DeviceStore().Put(reused); err == nil {
		t.Fatal("revoked key re-admitted under a new device ID")
	}
	if _, err := adapter.GetDevice("laptop-2"); err == nil {
		t.Fatal("refused device must not be readable through the adapter")
	}
}
