#!/usr/bin/env bash
# PocketShell gateway — ONE-TIME CI/CD bootstrap (coordinator executes).
#
# Deploys infra/github-actions.yaml (new IAM + SSM-document objects only; it
# touches no EC2/DNS/bucket resources) and then runs a read-only verification
# of the deploy role's exact permission boundaries via iam simulate-principal-policy.
#
# This script is execute-safe by construction:
#   * creates/updates exactly one CloudFormation stack from the reviewed template
#   * performs only read/describe/simulate AWS calls otherwise
#   * prints no credentials and needs none in URLs or arguments
#   * idempotent: re-running updates the stack in place
#
# Usage (from repo root, with admin credentials in the environment):
#   scripts/bootstrap-aws.sh \
#     --bucket pocketshell-relay-relaybucket-azljzs6pn8i8 \
#     --instance-id i-0f9c18ce63cf6c26e \
#     --instance-role pocketshell-relay-RelayRole-LvjBzsqkrVMa
# All flags default to the values verified in /home/alexey/tmp/pocketshell-gateway/bootstrap-inventory.json.
set -Eeuo pipefail

log() { printf '[bootstrap] %s\n' "$*"; }
die() { printf '[bootstrap] FATAL: %s\n' "$*" >&2; exit 1; }

REPO_ROOT=$(cd "$(dirname "$0")/.." && pwd)
REGION=eu-west-1
STACK_NAME=pocketshell-gateway-bootstrap
REPOSITORY=PocketShell-io/pocketshell-gateway
BUCKET=pocketshell-relay-relaybucket-azljzs6pn8i8
INSTANCE_ID=i-0f9c18ce63cf6c26e
INSTANCE_ROLE=pocketshell-relay-RelayRole-LvjBzsqkrVMa
DEPLOY_ROLE=pocketshell-github-deploy
DEPLOY_DOC=pocketshell-gateway-deploy
CREATE_OIDC=auto # auto|true|false
# D12 (review R3): the ONE trusted OIDC subject is the coordinator-verified
# IMMUTABLE form (owner_id/repository_id from the GitHub API, cross-checked
# with .github/workflows/oidc-probe.yml). There is no blank override, no
# classic name-only fallback, no wildcard: the trust policy accepts exactly
# this subject with audience sts.amazonaws.com, and this script refuses to
# bootstrap anything else BEFORE any AWS call is made.
IMMUTABLE_SUBJECT='repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main'
EXACT_SUBJECT=$IMMUTABLE_SUBJECT
EXACT_AUDIENCE=sts.amazonaws.com
SKIP_VERIFY=0
NO_EXEC=0
PREPARE_UPDATE=''

while [ $# -gt 0 ]; do
  case "$1" in
    --region) REGION=$2; shift 2;;
    --stack-name) STACK_NAME=$2; shift 2;;
    --repository) REPOSITORY=$2; shift 2;;
    --bucket) BUCKET=$2; shift 2;;
    --instance-id) INSTANCE_ID=$2; shift 2;;
    --instance-role) INSTANCE_ROLE=$2; shift 2;;
    --deploy-role) DEPLOY_ROLE=$2; shift 2;;
    --deploy-document) DEPLOY_DOC=$2; shift 2;;
    --create-oidc) CREATE_OIDC=$2; shift 2;; # auto|true|false
    --oidc-subject)
      # Accepted ONLY when it equals the verified immutable constant. An
      # empty value, a wildcard, the classic name-only subject, or any other
      # string is refused before any AWS call (no dynamic fallback).
      EXACT_SUBJECT=$2; shift 2
      ;;
    --skip-verify) SKIP_VERIFY=1; shift;;
    --no-exec) NO_EXEC=1; shift;; # print the plan, run only read-only checks
    --prepare-update-change-set)
      [ $# -ge 2 ] && [ -n "$2" ] || die "prepare-update-change-set requires a nonempty name"
      PREPARE_UPDATE=$2; shift 2;; # CREATE only; never execute
    *) die "unknown argument: $1";;
  esac
done
if [ -n "$PREPARE_UPDATE" ]; then
  [[ "$PREPARE_UPDATE" =~ ^[A-Za-z][-A-Za-z0-9]{0,127}$ ]] || die "invalid change-set name"
fi

# --- trust-policy validation: strictly BEFORE any AWS call -------------------
[ -f "$REPO_ROOT/infra/github-actions.yaml" ] || die "template missing: infra/github-actions.yaml"
case "$EXACT_SUBJECT" in
  "") die "refusing EMPTY OIDC subject override — the verified immutable subject is required (D12)";;
  *"*"*) die "refusing wildcard OIDC subject: $EXACT_SUBJECT";;
  "$IMMUTABLE_SUBJECT") ;; # the only value the template's AllowedPattern accepts
  *) die "refusing OIDC subject '$EXACT_SUBJECT' — ONLY the verified immutable subject is accepted:
  $IMMUTABLE_SUBJECT
(run .github/workflows/oidc-probe.yml on main first; if GitHub's emitted sub
 ever changes, update IMMUTABLE_SUBJECT in this script AND the template
 default, and re-verify the immutable owner/repository IDs — never pass
 name-only or wildcard subjects)";;
esac
[ "$REPOSITORY" = "PocketShell-io/pocketshell-gateway" ] ||
  die "refusing repository override '$REPOSITORY' — the trust policy is pinned to the verified repository"

case "$CREATE_OIDC" in
  auto|true|false) ;;
  *) die "invalid --create-oidc '$CREATE_OIDC' (expected auto|true|false)";;
esac

# The template must pin the exact subject + audience; if it drifted, refuse
# before touching AWS (fail closed against a stack that would trust the
# classic name-only subject or a different audience).
template_assert() { # $1 = description, $2 = literal that MUST be in the template
  grep -qF -- "$2" "$REPO_ROOT/infra/github-actions.yaml" ||
    die "template assertion failed: $1 (missing '$2')"
}
template_assert "ExactOIDCSubject default is the verified immutable subject" \
  "Default: \"$EXACT_SUBJECT\""
template_assert "ExactOIDCSubject AllowedPattern pins the exact immutable value" \
  "AllowedPattern: \"^${EXACT_SUBJECT}\$\""
template_assert "trust audience is sts.amazonaws.com" \
  "token.actions.githubusercontent.com:aud: $EXACT_AUDIENCE"
template_assert "trust binds the exact subject (StringEquals, no wildcards)" \
  "token.actions.githubusercontent.com:sub: !Ref ExactOIDCSubject"

log "OIDC trust (D12, immutable subject pinned): $EXACT_SUBJECT"
log "OIDC audience: $EXACT_AUDIENCE (only; no wildcard, no classic name-only fallback)"

for tool in aws jq sha256sum xxd base64; do command -v "$tool" >/dev/null || die "missing tool: $tool"; done

ACCOUNT=$(aws --region "$REGION" sts get-caller-identity --output json | jq -r '.Account')
log "identity account: $ACCOUNT (region $REGION)"
[ "$ACCOUNT" = "817685572750" ] || die "unexpected account $ACCOUNT — refusing to bootstrap outside the verified PocketShell account"

ROLE_ARN="arn:aws:iam::${ACCOUNT}:role/${DEPLOY_ROLE}"
OIDC_ARN="arn:aws:iam::${ACCOUNT}:oidc-provider/token.actions.githubusercontent.com"

# OIDC provider resolution (fix for the review finding: the old script set
# CreateOidcProvider=false when it detected the provider but NEVER passed
# ExistingOidcProviderArn, so the template's false branch — which uses that
# parameter as the deploy role's Federated principal — resolved to its EMPTY
# default and no GitHub token could ever assume the role).
#
# Rules:
#   * auto (default) and explicit --create-oidc false REQUIRE a discovered,
#     validated provider: matched by the EXACT canonical ARN of THIS account
#     (never by substring), with Url exactly token.actions.githubusercontent.com
#     and a ClientIDList containing the exact sts.amazonaws.com audience.
#   * Only a genuinely absent provider — a SUCCEEDED listing that matched
#     nothing — selects create. Any list/get permission or transport failure
#     is a fatal refusal: a failed lookup must never silently select create.
#   * Explicit --create-oidc true forces create without consulting the
#     registry; a conflicting existing provider surfaces as a loud
#     CloudFormation EntityAlreadyExists failure, never a silent mismatch.
GITHUB_OIDC_HOST=token.actions.githubusercontent.com
DISCOVERED_ARN=''

discover_oidc_provider() { # sets DISCOVERED_ARN='' iff the listing succeeded and found no match
  local list_json arns arn suffix n=0 ok
  list_json=$(aws --region "$REGION" iam list-open-id-connect-providers --output json 2>&1) ||
    die "cannot list IAM OIDC providers (permission or transport failure) — refusing to guess create-vs-reuse:
  $list_json"
  # A successful AWS status alone is NOT proof of absence: jq happily iterates
  # an empty input stream, missing keys and non-string rows with exit 0. The
  # whole response must be EXACTLY ONE JSON OBJECT carrying an actual
  # OpenIDConnectProviderList ARRAY whose every entry is an object with a
  # non-empty string Arn. Empty output, a missing/non-array list key, {},
  # null or numeric Arn rows, and multiple concatenated JSON documents are
  # malformed responses and refuse — only a valid, genuinely empty array can
  # prove the provider is absent.
  ok=$(printf '%s' "$list_json" | jq -s 'length == 1 and (.[0] | type == "object")' 2>/dev/null) ||
    die "cannot parse the OIDC provider list (malformed AWS response): expected exactly one JSON object — refusing: $list_json"
  [ "$ok" = "true" ] ||
    die "cannot parse the OIDC provider list (malformed AWS response): expected exactly one JSON object — refusing: $list_json"
  ok=$(printf '%s' "$list_json" | jq -r '.OpenIDConnectProviderList | type == "array"' 2>/dev/null) ||
    die "cannot parse the OIDC provider list (malformed AWS response): OpenIDConnectProviderList must be a JSON array — refusing: $list_json"
  [ "$ok" = "true" ] ||
    die "cannot parse the OIDC provider list (malformed AWS response): OpenIDConnectProviderList must be a JSON array — refusing: $list_json"
  ok=$(printf '%s' "$list_json" | jq -e '[.OpenIDConnectProviderList[] |
    (type == "object" and (.Arn | type == "string" and length > 0))] | all' 2>/dev/null) ||
    die "cannot parse the OIDC provider list (malformed AWS response): every entry must be an object with a non-empty string Arn — refusing: $list_json"
  arns=$(printf '%s' "$list_json" | jq -r '.OpenIDConnectProviderList[].Arn') ||
    die "cannot parse the OIDC provider list (malformed AWS response) — refusing: $list_json"
  suffix=":oidc-provider/${GITHUB_OIDC_HOST}"
  while IFS= read -r arn; do
    [ -n "$arn" ] || continue
    if [ "$arn" = "$OIDC_ARN" ]; then
      n=$((n + 1))
      DISCOVERED_ARN=$arn
      continue
    fi
    if [ "${arn%"$suffix"}" != "$arn" ]; then
      die "refusing OIDC provider '$arn': the GitHub issuer path exists but the ARN is not the exact
  '$OIDC_ARN' of this account (foreign account or mangled provider)"
    fi
  done <<LIST
$arns
LIST
  [ "$n" -le 1 ] || die "ambiguous OIDC discovery: $n providers claim the exact ARN '$OIDC_ARN' — refusing"
  [ -n "$DISCOVERED_ARN" ] || return 0 # genuine absence: listing succeeded, nothing matched
  local get_json url is_array has_aud
  get_json=$(aws --region "$REGION" iam get-open-id-connect-provider \
    --open-id-connect-provider-arn "$DISCOVERED_ARN" --output json 2>&1) ||
    die "OIDC provider $DISCOVERED_ARN is registered but cannot be read (permission or transport failure) — refusing:
  $get_json"
  url=$(printf '%s' "$get_json" | jq -r '.Url // ""') ||
    die "cannot parse the OIDC provider document of $DISCOVERED_ARN — refusing: $get_json"
  case "$url" in
    "$GITHUB_OIDC_HOST") ;;
    "https://$GITHUB_OIDC_HOST") ;; # the API returns the bare host; only the scheme-prefixed exact form is also accepted
    *) die "OIDC provider $DISCOVERED_ARN is not the GitHub issuer (Url='$url') — refusing";;
  esac
  is_array=$(printf '%s' "$get_json" | jq -r '.ClientIDList | type == "array"') ||
    die "cannot read the audience list of $DISCOVERED_ARN — refusing: $get_json"
  [ "$is_array" = "true" ] || die "malformed ClientIDList on $DISCOVERED_ARN — refusing"
  has_aud=$(printf '%s' "$get_json" | jq -r --arg aud "$EXACT_AUDIENCE" \
    '[.ClientIDList[] | select(. == $aud)] | length > 0') ||
    die "cannot read the audience list of $DISCOVERED_ARN — refusing: $get_json"
  [ "$has_aud" = "true" ] ||
    die "OIDC provider $DISCOVERED_ARN does not trust audience '$EXACT_AUDIENCE' — refusing"
}

if [ "$CREATE_OIDC" = "true" ]; then
  log "CreateOidcProvider=true (--create-oidc true): the stack creates $OIDC_ARN"
else
  # auto AND explicit false must resolve a VALIDATED provider first:
  # CreateOidcProvider=false makes the role's Federated principal the
  # ExistingOidcProviderArn parameter, so leaving that at its empty default
  # would silently break federation — reuse without the exact ARN is refused.
  discover_oidc_provider
  if [ -n "$DISCOVERED_ARN" ]; then
    CREATE_OIDC=false
    log "existing GitHub OIDC provider validated in account $ACCOUNT: $DISCOVERED_ARN — CreateOidcProvider=false"
  elif [ "$CREATE_OIDC" = "false" ]; then
    die "--create-oidc false but no $GITHUB_OIDC_HOST provider is registered in account $ACCOUNT — nothing to reuse"
  else
    CREATE_OIDC=true
    log "no $GITHUB_OIDC_HOST provider registered (listing succeeded) — CreateOidcProvider=true"
  fi
fi

PARAM_OVERRIDES=(
  "GitHubRepository=$REPOSITORY"
  "ArtifactBucket=$BUCKET"
  "TargetInstanceId=$INSTANCE_ID"
  "InstanceRoleName=$INSTANCE_ROLE"
  "DeployRoleName=$DEPLOY_ROLE"
  "DeployDocumentName=$DEPLOY_DOC"
  "CreateOidcProvider=$CREATE_OIDC"
  "ExactOIDCSubject=$EXACT_SUBJECT"
)
if [ "$CREATE_OIDC" = "false" ]; then
  # Federated principal of the deploy role — must never stay at the template's
  # empty default when we are not creating the provider ourselves.
  PARAM_OVERRIDES+=("ExistingOidcProviderArn=$DISCOVERED_ARN")
fi

if [ -n "$PREPARE_UPDATE" ]; then
  log "plan: prepare UPDATE change set $PREPARE_UPDATE on $STACK_NAME; execution is separate"
else
  log "plan: cloudformation deploy --stack-name $STACK_NAME --capabilities CAPABILITY_NAMED_IAM"
fi
printf '  parameter: %s\n' "${PARAM_OVERRIDES[@]}"

# TemplateBody is limited to 51,200 bytes. Preserve the exact generated bytes;
# use the existing artifact bucket, never create a bucket or transform YAML.
TEMPLATE_SOURCE=$REPO_ROOT/infra/github-actions.yaml
TEMPLATE_SHA=$(sha256sum "$TEMPLATE_SOURCE" | awk '{print $1}')
TEMPLATE_KEY="bootstrap/templates/$TEMPLATE_SHA/github-actions.yaml"
TEMPLATE_URL="https://$BUCKET.s3.$REGION.amazonaws.com/$TEMPLATE_KEY"
log "template: sha256=$TEMPLATE_SHA url=$TEMPLATE_URL"
stage_bootstrap_template() {
  local location meta downloaded_sha checksum bytes put_error
  TEMPLATE_WORK=$(mktemp -d "${TMPDIR:-/tmp}/gateway-bootstrap-template.XXXXXX")
  trap 'rm -rf "$TEMPLATE_WORK"' EXIT
  cp "$TEMPLATE_SOURCE" "$TEMPLATE_WORK/template.yaml"
  [ "$(sha256sum "$TEMPLATE_WORK/template.yaml" | awk '{print $1}')" = "$TEMPLATE_SHA" ] ||
    die "template changed before staging — refusing"
  aws --region "$REGION" s3api head-bucket --bucket "$BUCKET" --expected-bucket-owner "$ACCOUNT" ||
    die "existing same-account template bucket is unavailable — refusing"
  location=$(aws --region "$REGION" s3api get-bucket-location --bucket "$BUCKET" \
    --expected-bucket-owner "$ACCOUNT" --output json) || die "cannot read template bucket region"
  location=$(printf '%s' "$location" | jq -ser '
    if length == 1 and (.[0] | type == "object") and
       (.[0].LocationConstraint == null or (.[0].LocationConstraint | type == "string"))
    then .[0].LocationConstraint // "us-east-1" else error("invalid bucket region") end') ||
    die "malformed template bucket region"
  [ "$location" != EU ] || location=eu-west-1
  [ "$location" = "$REGION" ] || die "template bucket region $location differs from $REGION"
  checksum=$(printf '%s' "$TEMPLATE_SHA" | xxd -r -p | base64 | tr -d '\n')
  bytes=$(wc -c <"$TEMPLATE_WORK/template.yaml" | tr -d ' ')
  if ! aws --region "$REGION" s3api put-object --bucket "$BUCKET" --key "$TEMPLATE_KEY" \
    --body "$TEMPLATE_WORK/template.yaml" --expected-bucket-owner "$ACCOUNT" \
    --if-none-match '*' --checksum-algorithm SHA256 --checksum-sha256 "$checksum" \
    --metadata "sha256=$TEMPLATE_SHA" --content-type application/yaml \
    >"$TEMPLATE_WORK/put.json" 2>"$TEMPLATE_WORK/put.err"; then
    put_error=$(cat "$TEMPLATE_WORK/put.err")
    [[ "$put_error" == *'(PreconditionFailed)'* ]] || die "template conditional upload failed — refusing"
    log "template key already exists; verifying exact bytes before reuse"
  fi
  meta=$(aws --region "$REGION" s3api get-object --bucket "$BUCKET" --key "$TEMPLATE_KEY" \
    --expected-bucket-owner "$ACCOUNT" --checksum-mode ENABLED --output json \
    "$TEMPLATE_WORK/downloaded.yaml") || die "cannot verify uploaded template bytes"
  downloaded_sha=$(sha256sum "$TEMPLATE_WORK/downloaded.yaml" | awk '{print $1}')
  [ "$downloaded_sha" = "$TEMPLATE_SHA" ] || die "uploaded template byte digest mismatch"
  printf '%s' "$meta" | jq -se --arg sha "$TEMPLATE_SHA" --arg checksum "$checksum" --argjson size "$bytes" '
    length == 1 and (.[0] | type == "object") and
    .[0].Metadata.sha256 == $sha and .[0].ChecksumSHA256 == $checksum and .[0].ContentLength == $size' >/dev/null ||
    die "uploaded template metadata/checksum/length mismatch"
}

if [ "$NO_EXEC" = "1" ]; then
  log "no-exec mode: stopping before stack mutation"
  if [ -n "$PREPARE_UPDATE" ]; then
    log "would prepare UPDATE change set $PREPARE_UPDATE using verified TemplateURL; no upload or execution"
    exit 0
  fi
else
  stage_bootstrap_template
  if [ -n "$PREPARE_UPDATE" ]; then
    CFN_PARAMETERS=()
    for parameter in "${PARAM_OVERRIDES[@]}"; do
      CFN_PARAMETERS+=("ParameterKey=${parameter%%=*},ParameterValue=${parameter#*=}")
    done
    aws --region "$REGION" cloudformation create-change-set --stack-name "$STACK_NAME" \
      --change-set-name "$PREPARE_UPDATE" --change-set-type UPDATE \
      --template-url "$TEMPLATE_URL" --capabilities CAPABILITY_NAMED_IAM \
      --parameters "${CFN_PARAMETERS[@]}" --output json
    log "UPDATE change set prepared only; quarantine unchanged until separately reviewed execution"
    exit 0
  fi
  aws --region "$REGION" cloudformation deploy \
    --stack-name "$STACK_NAME" \
    --template-file "$TEMPLATE_WORK/template.yaml" \
    --s3-bucket "$BUCKET" --s3-prefix "bootstrap/templates/$TEMPLATE_SHA" \
    --capabilities CAPABILITY_NAMED_IAM \
    --tags Project=pocketshell ManagedBy=bootstrap-aws.sh \
    --parameter-overrides "${PARAM_OVERRIDES[@]}"
  if aws --region "$REGION" cloudformation wait stack-create-complete --stack-name "$STACK_NAME" 2>/dev/null; then
    log "stack created"
  else
    log "waiting for stack update to complete (already existed)"
    aws --region "$REGION" cloudformation wait stack-update-complete --stack-name "$STACK_NAME" ||
      die "stack update did not complete cleanly — check the console, do NOT blind-retry"
  fi
  log "stack outputs:"
  aws --region "$REGION" cloudformation describe-stacks --stack-name "$STACK_NAME" \
    --query 'Stacks[0].Outputs' --output table
fi

if [ "$SKIP_VERIFY" = "1" ]; then
  log "skipping permission simulation (--skip-verify)"
  exit 0
fi

# --- read-only verification of the role permission boundaries ----------------
log "simulating deploy role permissions (read-only; iam:SimulatePrincipalPolicy)"

# B-R2 contract (official IAM simulator API/CLI, verified against the current
# AWS reference):
#   * the CLI flags are --action-names / --resource-arns / --context-entries
#     ("--actions" never existed and cannot reach the real API);
#   * the API returns ONE EvaluationResult PER ACTION; its top-level
#     EvalDecision is only the AGGREGATE (most restrictive) across every
#     requested resource, and its EvalResourceName is an ARN TEMPLATE, not
#     the simulated resource. The only per-resource truth is
#     ResourceSpecificResults[].EvalResourceDecision;
#   * MissingContextValues appear at the result level when ResourceArns is
#     blank and inside ResourceSpecificResults when real ARNs are simulated;
#     a missing condition key means the simulation did NOT prove the
#     expectation.
# Verification therefore asserts a COMPLETE census: every expected
# (action, resource) pair must be returned exactly once with exactly the
# expected decision. Missing, duplicated, conflicting, unexpected, unknown or
# null results can never satisfy an expectation — least of all a Denied one.
# EvalDecision/EvalResourceDecision values are exactly:
#   allowed | explicitDeny | implicitDeny  (compared case-insensitively).
# Expectations:
#   Allowed      — decision must be `allowed`
#   Denied       — implicit or explicit deny
#   ExplicitDeny — must be `explicitDeny` (a boundary a future Allow can
#                  never override; required for the signing-key/path fences)
pass=0; fail=0
decision_ok() { # $1 = expected level, $2 = decision
  local exp=$1 dec
  dec=$(printf '%s' "$2" | tr '[:upper:]' '[:lower:]')
  [ -n "$dec" ] || return 1 # an absent/empty result never satisfies anything
  case "$exp" in
    Allowed) [ "$dec" = "allowed" ];;
    ExplicitDeny) [ "$dec" = "explicitdeny" ];;
    Denied) [ "$dec" != "allowed" ];;
    *) return 1;;
  esac
}

sim_census() { # $1 = raw simulator response JSON → prints a status payload:
  #   "OK"               followed by one "action|resource|decision" line per
  #                      (action, resource) evaluation (resource empty = the
  #                      action was simulated without a resource, per its API
  #                      resource type '*'), or
  #   "ERR <reason>"     on ANY shape or decision violation.
  # (The status travels in the payload because command substitution runs this
  # function in a subshell: variables set here cannot reach the caller.)
  local resp=$1 ok rows
  ok=$(printf '%s' "$resp" | jq -s 'length == 1 and (.[0] | type == "object")' 2>/dev/null) ||
    { printf 'ERR response is not valid JSON\n'; return 0; }
  [ "$ok" = "true" ] || { printf 'ERR response is not exactly one JSON object\n'; return 0; }
  ok=$(printf '%s' "$resp" | jq '.EvaluationResults | type == "array"' 2>/dev/null) ||
    { printf 'ERR response is not valid JSON\n'; return 0; }
  [ "$ok" = "true" ] || { printf 'ERR EvaluationResults must be a JSON array\n'; return 0; }
  ok=$(printf '%s' "$resp" | jq '.EvaluationResults | length > 0' 2>/dev/null) ||
    { printf 'ERR response is not valid JSON\n'; return 0; }
  [ "$ok" = "true" ] || { printf 'ERR EvaluationResults must not be empty\n'; return 0; }
  ok=$(printf '%s' "$resp" | jq -e '
    [.EvaluationResults[] |
      (((.EvalActionName // "") | type == "string" and length > 0)) and
      (((.EvalDecision // "") | type == "string" and length > 0)) and
      (((.EvalDecision // "") | ascii_downcase) as $d |
        ($d == "allowed" or $d == "explicitdeny" or $d == "implicitdeny")) and
      (((.MissingContextValues // []) | type == "array" and length == 0)) and
      (((.ResourceSpecificResults // []) | type == "array")) and
      ([.ResourceSpecificResults[]? |
        (((.EvalResourceName // "") | type == "string" and length > 0)) and
        (((.EvalResourceDecision // "") | type == "string" and length > 0)) and
        (((.EvalResourceDecision // "") | ascii_downcase) as $d |
          ($d == "allowed" or $d == "explicitdeny" or $d == "implicitdeny")) and
        (((.MissingContextValues // []) | type == "array" and length == 0))
      ] | all)
    ] | all' 2>/dev/null) ||
    { printf 'ERR a result carries an unknown/null EvalDecision or EvalResourceDecision, or a non-empty MissingContextValues (unsupplied condition context)\n'; return 0; }
  rows=$(printf '%s' "$resp" | jq -r '
    .EvaluationResults[] | .EvalActionName as $a |
    if ((.ResourceSpecificResults // []) | length) > 0 then
      .ResourceSpecificResults[]
      | [$a, .EvalResourceName, (.EvalResourceDecision | ascii_downcase)] | join("|")
    else
      [$a, "", (.EvalDecision | ascii_downcase)] | join("|")
    end' 2>/dev/null) ||
    { printf 'ERR cannot extract the per-(action, resource) census from the response\n'; return 0; }
  printf 'OK\n%s\n' "$rows"
}

sim_fail() { # $1 = label, $2 = reason — count one verification failure
  printf '[bootstrap]   FAIL [verification error] %s: %s\n' "$1" "$2" >&2
  fail=$((fail + 1))
}

sim_case() { # $1 = policy source ARN, $2 = label; remaining args: optional
  # '@Key=Value' request-context entries (passed as --context-entries), then
  # expectation pairs "Level|Action|Resource" ('' Resource = the action is
  # simulated WITHOUT a resource — for actions whose API resource type is
  # '*', e.g. ssm:GetCommandInvocation). One simulate call per case; the
  # whole per-(action, resource) result census is checked against the pairs.
  local src=$1 label=$2 pair level action resource got
  shift 2
  local -a pairs=() actions=() resources=() ctxargs=() callargs=()
  local a ckey cval exp_keys obs_keys census sim_out status
  for pair in "$@"; do
    case "$pair" in
      @*)
        ckey=${pair#@}
        cval=${ckey#*=}
        ckey=${ckey%%=*}
        ctxargs+=(--context-entries "ContextKeyName=${ckey},ContextKeyValues=${cval},ContextKeyType=string")
        ;;
      *"|"*"|"*)
        level=${pair%%|*}
        a=${pair#*|}; action=${a%%|*}; resource=${a#*|}
        case "$level" in
          Allowed|Denied|ExplicitDeny) ;;
          *) sim_fail "$label" "malformed expectation '$pair' (level must be Allowed|Denied|ExplicitDeny)"; return;;
        esac
        [ -n "$action" ] || { sim_fail "$label" "malformed expectation '$pair' (empty action)"; return; }
        pairs+=("$action|$resource|$level")
        case " ${actions[*]-} " in *" $action "*) ;; *) actions+=("$action");; esac
        if [ -n "$resource" ]; then
          case " ${resources[*]-} " in *" $resource "*) ;; *) resources+=("$resource");; esac
        fi
        ;;
      *) sim_fail "$label" "malformed expectation token '$pair'"; return;;
    esac
  done
  [ "${#pairs[@]}" -gt 0 ] || { sim_fail "$label" "no expectations declared"; return; }
  callargs=(--policy-source-arn "$src" --action-names "${actions[@]}")
  [ "${#resources[@]}" -gt 0 ] && callargs+=(--resource-arns "${resources[@]}")
  [ "${#ctxargs[@]}" -gt 0 ] && callargs+=("${ctxargs[@]}")
  if ! resp=$(aws --region "$REGION" iam simulate-principal-policy --output json "${callargs[@]}"); then
    sim_fail "$label" "simulator invocation failed"
    return
  fi
  sim_out=$(sim_census "$resp")
  status=${sim_out%%$'\n'*}
  if [ "$status" != "OK" ]; then
    sim_fail "$label" "invalid simulator response: ${status#ERR }"
    return
  fi
  census=${sim_out#*$'\n'}
  exp_keys=$(printf '%s\n' "${pairs[@]}" | cut -d'|' -f1,2 | LC_ALL=C sort)
  obs_keys=$(printf '%s\n' "$census" | cut -d'|' -f1,2 | LC_ALL=C sort)
  if [ "$exp_keys" != "$obs_keys" ]; then
    sim_fail "$label" "result census mismatch — missing, duplicated, conflicting or unexpected (action, resource) results (wanted: $(printf '%s' "$exp_keys" | tr '\n' ' ')| got: $(printf '%s' "$obs_keys" | tr '\n' ' ')|)"
    return
  fi
  for pair in "${pairs[@]}"; do
    action=${pair%%|*}
    a=${pair#*|}; resource=${a%%|*}; level=${a#*|}
    got=$(printf '%s\n' "$census" | awk -F'|' -v A="$action" -v R="$resource" '$1 == A && $2 == R {print $3}')
    if decision_ok "$level" "$got"; then
      log "  PASS [$level] $label :: $action on ${resource:-<no resource>} (got: $got)"
      pass=$((pass + 1))
    else
      printf '[bootstrap]   FAIL [%s wanted, got %s] %s :: %s on %s\n' \
        "$level" "${got:-<none>}" "$label" "$action" "${resource:-<no resource>}" >&2
      fail=$((fail + 1))
    fi
  done
}

expect() { # $1 = label, rest = @Key=Value context + Level|Action|Resource pairs — deploy role
  local label=$1
  shift
  sim_case "$ROLE_ARN" "$label" "$@"
}

artifact_arn="arn:aws:s3:::${BUCKET}/artifacts/0000000000000000000000000000000000000000000000000000000000000000/gateway-linux-arm64.gz"
legacy_arn="arn:aws:s3:::${BUCKET}/relay-arm64.gz"
instance_arn="arn:aws:ec2:${REGION}:${ACCOUNT}:instance/${INSTANCE_ID}"
other_instance_arn="arn:aws:ec2:${REGION}:${ACCOUNT}:instance/i-00000000000000000"
doc_arn="arn:aws:ssm:${REGION}:${ACCOUNT}:document/${DEPLOY_DOC}"
runshell_arn="arn:aws:ssm:eu-west-1:817685572750:document/AWS-RunShellScript"

# Request context the REAL API calls carry (B-R2): the document grant is
# conditioned on ssm:DocumentType, the result-read grant on aws:ResourceAccount
# and aws:RequestedRegion. Supplying this context to the SIMULATOR is
# synthetic — see the separate live-verification gate after the checks.
expect "s3:PutObject under artifacts/" \
  "Allowed|s3:PutObject|$artifact_arn"
expect "s3:PutObject at legacy /relay-arm64.gz" \
  "Denied|s3:PutObject|$legacy_arn"
expect "s3:DeleteObject under artifacts/" \
  "ExplicitDeny|s3:DeleteObject|$artifact_arn"
expect "s3:GetObject (deploy role uploads; it never downloads)" \
  "Denied|s3:GetObject|$artifact_arn"
expect "ssm:SendCommand with $DEPLOY_DOC on pinned instance" \
  @ssm:DocumentType=Command "@aws:RequestedRegion=$REGION" "@aws:ResourceAccount=$ACCOUNT" \
  "Allowed|ssm:SendCommand|$doc_arn" "Allowed|ssm:SendCommand|$instance_arn"
expect "ssm:SendCommand with AWS-RunShellScript" \
  @ssm:DocumentType=Command "@aws:RequestedRegion=$REGION" "@aws:ResourceAccount=$ACCOUNT" \
  "ExplicitDeny|ssm:SendCommand|$runshell_arn" "Allowed|ssm:SendCommand|$instance_arn"
expect "ssm:SendCommand with $DEPLOY_DOC on OTHER instance" \
  @ssm:DocumentType=Command "@aws:RequestedRegion=$REGION" "@aws:ResourceAccount=$ACCOUNT" \
  "Allowed|ssm:SendCommand|$doc_arn" "Denied|ssm:SendCommand|$other_instance_arn"
expect "ssm:GetCommandInvocation" \
  "@aws:RequestedRegion=$REGION" "@aws:ResourceAccount=$ACCOUNT" \
  "Allowed|ssm:GetCommandInvocation|"
expect "ssm:StartSession (no interactive shell)" \
  "ExplicitDeny|ssm:StartSession|$instance_arn"
expect "ssm:StartAutomationExecution" \
  "ExplicitDeny|ssm:StartAutomationExecution|*"
expect "iam:CreateRole" \
  "ExplicitDeny|iam:CreateRole|*"
expect "ec2:AuthorizeSecurityGroupEgress" \
  "ExplicitDeny|ec2:AuthorizeSecurityGroupEgress|*"
expect "route53:ChangeResourceRecordSets" \
  "ExplicitDeny|route53:ChangeResourceRecordSets|*"

log "simulating instance role boundaries (legacy behaviour preserved + R4 denies)"

iexpect() { # $1 = label, rest = @Key=Value context + Level|Action|Resource pairs — EXISTING runtime instance role
  local label=$1
  shift
  sim_case "arn:aws:iam::${ACCOUNT}:role/${INSTANCE_ROLE}" "$label" "$@"
}

iexpect "instance role reads artifacts/" \
  "Allowed|s3:GetObject|$artifact_arn"
iexpect "instance role still reads legacy /relay-arm64.gz" \
  "Allowed|s3:GetObject|$legacy_arn"
iexpect "instance role cannot list bucket root (unchanged policy scope)" \
  "Denied|s3:ListBucket|arn:aws:s3:::${BUCKET}"
# R4: the runtime role must ITSELF fence the broker signing-key family —
# current AND previous keys, with and without the hierarchical leading slash —
# against GetParameter/GetParameters/GetParameterHistory, and deny recursive
# path retrieval (GetParametersByPath) GLOBALLY. These must be EXPLICIT denies:
# AmazonSSMManagedInstanceCore grants parameter reads on *, so an implicit
# deny would silently disappear the day someone attaches a broader read
# policy. The gateway only ever needs the public JWKS over HTTPS (docs/
# routing-credentials.md; scoped-credential-design-review requirement 1).
iexpect "instance role denied the broker signing key (current version)" \
  "ExplicitDeny|ssm:GetParameter|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/gateway-signing-key" \
  "ExplicitDeny|ssm:GetParameters|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/gateway-signing-key" \
  "ExplicitDeny|ssm:GetParameterHistory|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/gateway-signing-key"
iexpect "instance role denied the broker signing key family (previous/rotated keys)" \
  "ExplicitDeny|ssm:GetParameter|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/gateway-signing-key-previous" \
  "ExplicitDeny|ssm:GetParameters|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/gateway-signing-key-previous" \
  "ExplicitDeny|ssm:GetParameterHistory|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/gateway-signing-key-previous"
iexpect "instance role denied the whole pocketshell-sync parameter family" \
  "ExplicitDeny|ssm:GetParameter|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/anything" \
  "ExplicitDeny|ssm:GetParameters|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/anything" \
  "ExplicitDeny|ssm:GetParameterHistory|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync/anything"
iexpect "instance role denied signless (slashless) signing-key probe" \
  "ExplicitDeny|ssm:GetParameter|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/gateway-signing-key"
iexpect "instance role denied GetParametersByPath globally (ancestor traversal)" \
  "ExplicitDeny|ssm:GetParametersByPath|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/pocketshell-sync"
iexpect "instance role denied GetParametersByPath on arbitrary paths" \
  "ExplicitDeny|ssm:GetParametersByPath|arn:aws:ssm:${REGION}:${ACCOUNT}:parameter/"

if [ "$fail" -gt 0 ]; then
  printf '[bootstrap] FATAL: %d permission checks failed (%d passed)\n' "$fail" "$pass" >&2
  exit 1
fi
log "bootstrap OK: all $pass permission checks passed"
# B-R2 live-context gate (separate from this simulation and NOT dischargeable
# by it): the ssm:DocumentType / aws:ResourceAccount / aws:RequestedRegion
# values above were supplied to the simulator SYNTHETICALLY via
# --context-entries. That the LIVE ssm:SendCommand / ssm:GetCommandInvocation
# calls actually populate those keys — so the conditioned statements hold in
# production — must be verified against real AWS during the coordinator's
# bootstrap run before any activation.
log "remaining live gate: verify on the real AWS API that ssm:SendCommand and ssm:GetCommandInvocation populate"
log "remaining live gate: ssm:DocumentType, aws:ResourceAccount and aws:RequestedRegion — this simulation supplied"
log "remaining live gate: that context synthetically and does not prove live population"
log "next: set AWS_ROLE_ARN=$ROLE_ARN in .github/workflows/deploy.yml env (default already matches)"
