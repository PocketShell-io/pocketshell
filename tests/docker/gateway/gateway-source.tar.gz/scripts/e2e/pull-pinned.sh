#!/usr/bin/env bash
# Serialized, throttle-aware acquisition of the e2e fixture images, run
# BEFORE `compose up`, which then uses `--pull never --no-build`.
#
# Why: compose pulls every service's image in parallel (the legacy fixture
# fetched the same digest twice at once, next to the sshd build's FROM),
# and anonymous public ECR allows 1 image pull per second per region (AWS
# "Amazon ECR Public service quotas", not adjustable). CI hit
# "toomanyrequests: Rate exceeded" before any test ran.
#
#   pull-pinned.sh pull REF...
#       Each ref must be an exact Docker Official digest ref,
#       public.ecr.aws/docker/library/<name>@sha256:<64 hex> — no tag, no
#       mutable fallback, no other registry, no credentials. A ref already
#       present AND bound to that exact ref (RepoDigests) is reused with no
#       registry request; otherwise it is pulled, one at a time, and must be
#       bound to the exact ref afterwards.
#   pull-pinned.sh build COMPOSE_FILE PROJECT PIN
#       `docker compose -f COMPOSE_FILE -p PROJECT build` (the fixture's own
#       build services only), after the pull, so its FROM resolution is
#       never concurrent with a pull. PIN is the build's FROM.
#
# Retry is bounded exponential backoff on an explicit registry throttle
# ONLY; any other error fails at once, and exhausting the attempts fails.
#   pull:  `docker pull` output is the registry's own answer, so
#          429 / toomanyrequests / Rate exceeded is the throttle.
#   build: build output also carries RUN steps (apk, package mirrors), so a
#          429 there is NOT retried. Only BuildKit's FROM metadata
#          resolution of the exact PIN answered 429 by public ECR counts:
#            failed to resolve source metadata for PIN: ... unexpected
#            status from GET|HEAD request to https://public.ecr.aws/v2/
#            <repo>/manifests/<digest> (or /token/?...): 429 Too Many Requests
#          on one line that is not RUN-step output ("#N <secs> ...").
# Nothing is tagged, retagged or removed here. Env (tests only): DOCKER (default docker),
# PULL_PINNED_ATTEMPTS (1..8, default 5), PULL_PINNED_BACKOFF (base
# seconds 0..10, default 2, doubling).
set -euo pipefail

DOCKER=${DOCKER:-docker}
ATTEMPTS=${PULL_PINNED_ATTEMPTS:-5}
BACKOFF=${PULL_PINNED_BACKOFF:-2}
PIN_RE='^public\.ecr\.aws/docker/library/[a-z0-9._-]+@sha256:[0-9a-f]{64}$'
THROTTLE_RE='toomanyrequests|Rate exceeded|429 Too Many Requests'

die() { printf 'pull-pinned: FAIL: %s\n' "$*" >&2; exit 1; }

[[ $ATTEMPTS =~ ^[1-8]$ ]] || die "PULL_PINNED_ATTEMPTS must be 1..8 (got '$ATTEMPTS')"
[[ $BACKOFF =~ ^([0-9]|10)$ ]] || die "PULL_PINNED_BACKOFF must be 0..10 (got '$BACKOFF')"

# metadata_throttle_re PIN: the only build failure that is retried.
metadata_throttle_re() {
  local pin=${1//./\\.} repo=${1%@*} digest=${1#*@}
  repo=${repo#public.ecr.aws/}
  repo=${repo//./\\.}
  printf '%s' "failed to resolve source metadata for ${pin}: (failed to authorize: failed to fetch (anonymous|oauth) token: )?unexpected status from (GET|HEAD) request to https://public\\.ecr\\.aws/(v2/${repo}/manifests/${digest}|token/\\?[^ ]*): 429 Too Many Requests"
}

# throttled_retry WHAT CLASSIFIER_RE CMD...: run CMD; retry only when a
# non-step-output line of its output matches CLASSIFIER_RE.
throttled_retry() {
  local what=$1 re=$2 out n delay=$BACKOFF
  shift 2
  for ((n = 1; ; n++)); do
    if out=$("$@" 2>&1); then
      [ -z "$out" ] || printf '%s\n' "$out"
      ATTEMPT=$n
      return 0
    fi
    printf '%s\n' "$out" >&2
    grep -vE '^#[0-9]+ [0-9]+\.[0-9]+ ' <<<"$out" | grep -qE "$re" ||
      die "$what failed (not a registry throttle; no retry)"
    [ "$n" -lt "$ATTEMPTS" ] || die "$what still throttled after $ATTEMPTS attempts"
    printf 'pull-pinned: registry throttled %s (attempt %d/%d); retrying in %ds\n' "$what" "$n" "$ATTEMPTS" "$delay" >&2
    sleep "$delay"
    delay=$((delay * 2))
  done
}

bound() { # present locally AND bound to the exact ref
  "$DOCKER" image inspect --format '{{range .RepoDigests}}{{println .}}{{end}}' "$1" 2>/dev/null | grep -qxF "$1"
}

cmd=${1:-}
shift || true
case $cmd in
pull)
  [ $# -ge 1 ] || die "pull: no image refs given"
  for ref in "$@"; do
    [[ $ref =~ $PIN_RE ]] || die "refusing non-pinned ref '$ref' (need public.ecr.aws/docker/library/<name>@sha256:<64 hex>)"
  done
  for ref in "$@"; do
    # A repeated ref is found bound here: one acquisition per digest.
    if bound "$ref"; then
      printf 'pull-pinned: cached %s (bound, no registry request)\n' "$ref"
      continue
    fi
    throttled_retry "pull of $ref" "$THROTTLE_RE" "$DOCKER" pull --quiet "$ref" >/dev/null
    bound "$ref" || die "pulled $ref but the local image is not bound to that exact ref"
    printf 'pull-pinned: pulled %s (attempt %d, bound)\n' "$ref" "$ATTEMPT"
    # Stay under the anonymous 1 pull/second quota before the next request.
    [ "$BACKOFF" -eq 0 ] || sleep 1
  done
  ;;
build)
  [ $# -eq 3 ] || die "build: usage: build COMPOSE_FILE PROJECT PIN"
  [ -f "$1" ] || die "build: no compose file '$1'"
  [[ $3 =~ $PIN_RE ]] || die "refusing non-pinned build FROM '$3'"
  throttled_retry "compose build of $1" "$(metadata_throttle_re "$3")" "$DOCKER" compose -f "$1" -p "$2" build
  printf 'pull-pinned: built %s (attempt %d)\n' "$1" "$ATTEMPT"
  ;;
*)
  die "usage: pull-pinned.sh pull REF... | build COMPOSE_FILE PROJECT PIN"
  ;;
esac
