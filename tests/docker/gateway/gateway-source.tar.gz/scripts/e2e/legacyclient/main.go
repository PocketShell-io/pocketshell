// Command legacyclient is the Docker e2e runner for the FROZEN legacy wire
// contract: it dials the gateway over WebSocket, wraps the connection as a
// net.Conn and runs a REAL SSH session through it against the fixture sshd —
// proving bytes flow both ways end to end.
//
// Controls:
//   - positive: pinned host key + enrolled client key -> command output arrives
//   - negative: pinned WRONG host key -> handshake must fail (host key rejection)
//   - negative: correct host key + WRONG client key -> auth must fail
//
// It exits non-zero if any expectation is violated.
package main

import (
	"flag"
	"fmt"
	"net"
	"net/url"
	"os"
	"strings"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"
)

type dummyAddr struct{ network, s string }

func (dummyAddr) Network() string { return "ws" }
func (a dummyAddr) String() string {
	if a.s != "" {
		return a.s
	}
	return "ws-e2e"
}

// wsConn adapts a websocket to net.Conn for x/crypto/ssh. SSH reads are
// size-driven, so leftover frame bytes are buffered between Read calls.
type wsConn struct {
	ws      *websocket.Conn
	pending []byte
}

func (c *wsConn) Read(p []byte) (int, error) {
	for len(c.pending) == 0 {
		_, data, err := c.ws.ReadMessage()
		if err != nil {
			return 0, err
		}
		if len(data) > 0 {
			c.pending = data
		}
	}
	n := copy(p, c.pending)
	c.pending = c.pending[n:]
	return n, nil
}

func (c *wsConn) Write(p []byte) (int, error) {
	if err := c.ws.WriteMessage(websocket.BinaryMessage, p); err != nil {
		return 0, err
	}
	return len(p), nil
}

func (c *wsConn) Close() error         { return c.ws.Close() }
func (c *wsConn) LocalAddr() net.Addr  { return dummyAddr{} }
func (c *wsConn) RemoteAddr() net.Addr { return dummyAddr{s: "gateway"} }
func (c *wsConn) SetDeadline(t time.Time) error {
	_ = c.ws.SetReadDeadline(t)
	return c.ws.SetWriteDeadline(t)
}
func (c *wsConn) SetReadDeadline(t time.Time) error  { return c.ws.SetReadDeadline(t) }
func (c *wsConn) SetWriteDeadline(t time.Time) error { return c.ws.SetWriteDeadline(t) }

func dialGateway(gatewayURL, sshHost string) (net.Conn, error) {
	host, port, err := net.SplitHostPort(sshHost)
	if err != nil {
		return nil, fmt.Errorf("bad -ssh-host %q: %w", sshHost, err)
	}
	u := gatewayURL + "/upgrade?token=dev-e2e-token&host=" + url.QueryEscape(host) + "&port=" + url.QueryEscape(port)
	ws, resp, err := websocket.DefaultDialer.Dial(u, nil)
	if err != nil {
		if resp != nil {
			return nil, fmt.Errorf("ws dial %s: HTTP %d: %w", gatewayURL, resp.StatusCode, err)
		}
		return nil, fmt.Errorf("ws dial %s: %w", gatewayURL, err)
	}
	return &wsConn{ws: ws}, nil
}

func sshHandshake(conn net.Conn, cfg *ssh.ClientConfig) (*ssh.Client, error) {
	ws := &wsConn{ws: conn.(*wsConn).ws} // reuse adapter type for clarity
	c, chans, reqs, err := ssh.NewClientConn(ws, "", cfg)
	if err != nil {
		return nil, err
	}
	return ssh.NewClient(c, chans, reqs), nil
}

func mustKey(t string) ssh.PublicKey {
	pub, _, _, _, err := ssh.ParseAuthorizedKey([]byte(t))
	if err != nil {
		panic(fmt.Sprintf("parse host key: %v", err))
	}
	return pub
}

func main() {
	gateway := flag.String("gateway", "ws://gateway:8080", "gateway WebSocket base URL")
	sshHost := flag.String("ssh-host", "sshd:22", "host:port the gateway dials (dev-private-hosts mode)")
	user := flag.String("user", "e2e", "ssh user on the fixture")
	clientKey := flag.String("client-key", "/keys/client_ed25519", "client private key (enrolled)")
	hostKey := flag.String("host-key", "/keys/host_ed25519.pub", "fixture sshd public host key (pinned)")
	wrongHostKey := flag.String("wrong-host-key", "/keys/wrong_host_ed25519.pub", "a DIFFERENT public key for the host-key negative control")
	wrongClientKey := flag.String("wrong-client-key", "/keys/wrong_host_ed25519", "private key NOT enrolled, for the auth negative control")
	flag.Parse()

	fail := func(format string, args ...any) {
		fmt.Fprintf(os.Stderr, "e2e FAIL: "+format+"\n", args...)
		os.Exit(1)
	}
	pass := func(format string, args ...any) {
		fmt.Printf("e2e PASS: "+format+"\n", args...)
	}

	hostPubBytes, err := os.ReadFile(*hostKey)
	if err != nil {
		fail("read host key: %v", err)
	}
	hostPub := mustKey(string(hostPubBytes))
	wrongPubBytes, err := os.ReadFile(*wrongHostKey)
	if err != nil {
		fail("read wrong host key: %v", err)
	}
	wrongPub := mustKey(string(wrongPubBytes))

	clientSigner, err := parsePrivateKeyFile(*clientKey)
	if err != nil {
		fail("parse client key: %v", err)
	}
	rogueSigner, err := parsePrivateKeyFile(*wrongClientKey)
	if err != nil {
		fail("parse wrong-client key: %v", err)
	}

	// --- negative control 1: host key rejection ------------------------------
	conn1, err := dialGateway(*gateway, *sshHost)
	if err != nil {
		fail("dial for host-key control: %v", err)
	}
	badCfg := &ssh.ClientConfig{
		User:            *user,
		Auth:            []ssh.AuthMethod{ssh.PublicKeys(clientSigner)},
		HostKeyCallback: ssh.FixedHostKey(wrongPub), // pins the WRONG key on purpose
		Timeout:         20 * time.Second,
	}
	if _, err := sshHandshake(conn1, badCfg); err == nil {
		fail("SSH handshake succeeded against a WRONG pinned host key — host key verification is broken")
	} else {
		pass("handshake rejected wrong host key (%v)", truncate(err.Error()))
	}

	// --- negative control 2: unenrolled client key rejected ------------------
	conn2, err := dialGateway(*gateway, *sshHost)
	if err != nil {
		fail("dial for auth control: %v", err)
	}
	rogueCfg := &ssh.ClientConfig{
		User:            *user,
		Auth:            []ssh.AuthMethod{ssh.PublicKeys(rogueSigner)}, // key NOT in authorized_keys
		HostKeyCallback: ssh.FixedHostKey(hostPub),
		Timeout:         20 * time.Second,
	}
	if _, err := sshHandshake(conn2, rogueCfg); err == nil {
		fail("SSH auth succeeded with an unenrolled key")
	} else {
		pass("unenrolled client key rejected (%v)", truncate(err.Error()))
	}

	// --- positive path: real SSH command through the gateway -----------------
	conn3, err := dialGateway(*gateway, *sshHost)
	if err != nil {
		fail("dial for positive path: %v", err)
	}
	goodCfg := &ssh.ClientConfig{
		User:            *user,
		Auth:            []ssh.AuthMethod{ssh.PublicKeys(clientSigner)},
		HostKeyCallback: ssh.FixedHostKey(hostPub),
		Timeout:         20 * time.Second,
	}
	client, err := sshHandshake(conn3, goodCfg)
	if err != nil {
		fail("positive handshake: %v", err)
	}
	defer client.Close()
	session, err := client.NewSession()
	if err != nil {
		fail("new session: %v", err)
	}
	defer session.Close()
	out, err := session.CombinedOutput("echo pocketshell-e2e-ok")
	if err != nil {
		fail("run command: %v (output: %q)", err, string(out))
	}
	if !strings.Contains(string(out), "pocketshell-e2e-ok") {
		fail("command output missing marker: %q", string(out))
	}
	pass("end-to-end SSH command through the gateway returned expected output")
	fmt.Println("e2e OK")
}

func parsePrivateKeyFile(path string) (ssh.Signer, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	return ssh.ParsePrivateKey(b)
}

func truncate(s string) string {
	if len(s) > 80 {
		return s[:80] + "..."
	}
	return s
}
