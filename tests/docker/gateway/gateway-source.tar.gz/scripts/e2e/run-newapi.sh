#!/usr/bin/env bash
# Runs the production-shaped new-API Docker e2e (scripts/e2e/newapi/):
# the REAL pocketshell-link CLI enrolls and runs against the REAL gateway
# (registry + tunnel + true broker verification) toward a REAL OpenSSH,
# with independent client pins and negative controls. See that directory's
# docker-compose.yml for the exact security posture.
#
# MANDATORY GATE (review R5): this script NEVER succeeds by skipping. Any
# missing dependency — runtime sources, fixture, Docker, compose, tooling —
# fails NONZERO with the exact dependency named. There is no legacy-adapter
# fallback and no gate waiver: the tree either runs the real fixture or the
# gate is red. (On a standalone delivery checkout without the runtime, the
# expected state is this hard failure, which the combined full-source tree
# resolves.)
set -euo pipefail
cd "$(dirname "$0")/../.."

fail_missing() {
  printf 'FAIL (mandatory production gate, no successful skip): missing dependency: %s\n' "$*" >&2
  printf '  provision it or run this gate from a full-source (combined runtime) tree\n' >&2
  exit 1
}

[ -d cmd/pocketshell-link ] ||
  fail_missing "cmd/pocketshell-link not on this tree (tunnel/runtime worker sources; combined full-source checkout required)"
FIXTURE=scripts/e2e/newapi/docker-compose.yml
[ -f "$FIXTURE" ] || fail_missing "production fixture $FIXTURE"
[ -f scripts/e2e/newapi/agent-entrypoint.sh ] || fail_missing "scripts/e2e/newapi/agent-entrypoint.sh"
[ -d scripts/e2e/sshd ] || fail_missing "scripts/e2e/sshd fixture directory"

GO=${GO:-/usr/local/go/bin/go}
command -v "$GO" >/dev/null 2>&1 || GO=go
command -v "$GO" >/dev/null 2>&1 || fail_missing "Go toolchain (\$GO=$GO, fallback 'go' also absent)"
command -v docker >/dev/null 2>&1 || fail_missing "docker CLI"
docker version >/dev/null 2>&1 || fail_missing "docker daemon (docker version failed)"
docker compose version >/dev/null 2>&1 || fail_missing "docker compose plugin (docker compose version failed)"
command -v python3 >/dev/null 2>&1 || fail_missing "python3"
python3 -c 'import yaml' >/dev/null 2>&1 || fail_missing "python3 PyYAML (pip install pyyaml)"
command -v sha256sum >/dev/null 2>&1 || fail_missing "sha256sum"

mkdir -p build/e2e
echo "building the real binaries from source (gateway, pocketshell-link, broker, client)"
GOOS=linux CGO_ENABLED=0 "$GO" build -trimpath -o build/e2e/newapi-gateway .
GOOS=linux CGO_ENABLED=0 "$GO" build -trimpath -o build/e2e/newapi-link ./cmd/pocketshell-link
GOOS=linux CGO_ENABLED=0 "$GO" build -trimpath -o build/e2e/newapi-broker ./scripts/e2e/newapi/broker
GOOS=linux CGO_ENABLED=0 "$GO" build -trimpath -o build/e2e/newapi-client ./scripts/e2e/newapi/client
scripts/e2e/gen-keys.sh

# Self-audit: the fixture must never grow privileged/socket/host-network
# escapes or key material inside the gateway container.
python3 - "$FIXTURE" <<'AUDIT'
import sys, yaml
path = sys.argv[1]
c = yaml.safe_load(open(path))
bad = []
for name, svc in c.get("services", {}).items():
    if svc.get("privileged"):
        bad.append(f"{name}: privileged")
    if "network_mode" in svc and str(svc["network_mode"]).strip('"') == "host":
        bad.append(f"{name}: host network")
    if "docker.sock" in str(svc):
        bad.append(f"{name}: docker socket")
gw = c.get("services", {}).get("gateway", {})
for v in gw.get("volumes", []):
    src = str(v).split(":")[0]
    if not (src.startswith("gateway-registry") or src.endswith("/newapi-gateway")):
        bad.append(f"gateway mounts {src} (only its registry state and binary are allowed)")
if bad:
    print("FAIL: production e2e fixture posture violated:")
    for b in bad:
        print("  - " + b)
    sys.exit(1)
print("fixture posture OK: no privileged/host-network/socket; gateway mounts only its state")
AUDIT

# Serialized, digest-bound image acquisition (anonymous public ECR allows 1
# pull/second; parallel compose pulls were throttled), then the sshd build,
# then compose with no pulls and no builds of its own.
E2E_BASE=$(sed -n 's/^FROM //p' scripts/e2e/sshd/Dockerfile)
scripts/e2e/pull-pinned.sh pull "$E2E_BASE"
scripts/e2e/pull-pinned.sh build "$FIXTURE" pocketshell-newapi-e2e "$E2E_BASE"

COMPOSE="docker compose -f $FIXTURE -p pocketshell-newapi-e2e"
rc=0
$COMPOSE up --pull never --no-build --abort-on-container-exit --exit-code-from e2e || rc=$?
$COMPOSE down -v --remove-orphans >/dev/null 2>&1 || true
exit $rc
