#!/usr/bin/env bash
# Generate throwaway SSH keys for the Docker e2e (build/ is gitignored).
set -euo pipefail
cd "$(dirname "$0")/../.."
KEYS=build/e2e/keys
mkdir -p "$KEYS"
[ -f "$KEYS/client_ed25519" ] || ssh-keygen -q -t ed25519 -N '' -C pocketshell-e2e-client -f "$KEYS/client_ed25519"
[ -f "$KEYS/host_ed25519" ] || ssh-keygen -q -t ed25519 -N '' -C pocketshell-e2e-host -f "$KEYS/host_ed25519"
[ -f "$KEYS/wrong_host_ed25519" ] || ssh-keygen -q -t ed25519 -N '' -C pocketshell-e2e-wrong -f "$KEYS/wrong_host_ed25519"
chmod 600 "$KEYS"/client_ed25519 "$KEYS"/host_ed25519 "$KEYS"/wrong_host_ed25519
echo "e2e keys in $KEYS"
