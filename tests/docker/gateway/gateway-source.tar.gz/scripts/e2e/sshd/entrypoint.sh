#!/bin/sh
# sshd fixture entrypoint: strict, pubkey-only, managed-user endpoint.
set -eu

HOST_KEY="${HOST_KEY:-/keys/host_ed25519}"
CLIENT_PUB="${CLIENT_PUB:-/keys/client_ed25519.pub}"

[ -f "$HOST_KEY" ] || { echo "missing host key: $HOST_KEY" >&2; exit 1; }
[ -f "$CLIENT_PUB" ] || { echo "missing client pubkey: $CLIENT_PUB" >&2; exit 1; }

mkdir -p /run/sshd /home/e2e/.ssh
if ! id e2e >/dev/null 2>&1; then
  adduser -D -s /bin/sh -h /home/e2e e2e
fi
# adduser -D leaves the account LOCKED ('!' in shadow), which makes sshd
# refuse even pubkey auth. Replace with '*' (no password login possible,
# account unlocked for keys).
sed -i "s/^e2e:!/e2e:*/" /etc/shadow
cp "$CLIENT_PUB" /home/e2e/.ssh/authorized_keys
chmod 700 /home/e2e/.ssh
chmod 600 /home/e2e/.ssh/authorized_keys
chown -R e2e:e2e /home/e2e

cat >/etc/ssh/sshd_config <<EOF
Port 22
HostKey $HOST_KEY
PermitRootLogin no
PasswordAuthentication no
KbdInteractiveAuthentication no
PubkeyAuthentication yes
AllowUsers e2e
StrictModes yes
UseDNS no
Subsystem sftp internal-sftp
EOF

exec /usr/sbin/sshd -D -e
