// Stand-in broker token issuer for the production-shaped Docker e2e.
//
// The REAL gateway verifies scoped broker credentials cryptographically:
// RS256 signatures against a JWKS it fetches from -broker-jwks, plus exact
// iss/aud/scope/exp claims (internal/routingauth). This fixture replaces
// only the upstream ISSUER, never the gateway's verification: it mints a
// real RSA-signed token and serves the matching public key, so the gateway
// under test runs its full production verification path (the plain-HTTP
// JWKS fetch is what the gateway's -broker-allow-insecure-dev flag exists
// for, and it is refused next to a public domain).
//
// Boot sequence: generate an RSA key, write one fresh token to
// /shared/broker-token (0600; agent + client read it from the shared
// volume), then serve the JWKS at /gateway/jwks until killed.
package main

import (
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

const (
	issuer   = "http://broker:8088"
	audience = "pocketshell-gateway"
	listen   = ":8088"
	shared   = "/shared"
)

func b64(b []byte) string { return base64.RawURLEncoding.EncodeToString(b) }

func main() {
	log.SetFlags(0)
	if err := run(); err != nil {
		log.Fatalf("broker: %v", err)
	}
}

func run() error {
	key, err := rsa.GenerateKey(rand.Reader, 3072)
	if err != nil {
		return fmt.Errorf("generate broker key: %w", err)
	}
	nSum := sha256.Sum256(key.N.Bytes())
	kid := fmt.Sprintf("fx-%x", nSum[:4])

	// A real broker-shaped JWT: the gateway and the CLI's local guard both
	// check iss/aud/scope/exp; the gateway additionally verifies the
	// signature against the JWKS served below.
	header, _ := json.Marshal(map[string]string{"alg": "RS256", "typ": "JWT", "kid": kid})
	claims, _ := json.Marshal(map[string]any{
		"iss":            issuer,
		"aud":            audience,
		"scope":          "pocketshell.gateway",
		"sub":            "fixture-account-000000000001",
		"email":          "fixture@example.com",
		"email_verified": true,
		// Production-shaped: routingauth requires nbf, and the CLI's local
		// guard refuses broker credentials with a lifetime beyond 5 minutes.
		"nbf": time.Now().Add(-1 * time.Second).Unix(),
		"exp": time.Now().Add(4 * time.Minute).Unix(),
		"iat": time.Now().Unix(),
	})
	signingInput := b64(header) + "." + b64(claims)
	sum := sha256.Sum256([]byte(signingInput))
	sig, err := rsa.SignPKCS1v15(rand.Reader, key, crypto.SHA256, sum[:])
	if err != nil {
		return fmt.Errorf("sign token: %w", err)
	}
	token := signingInput + "." + b64(sig)

	if err := os.MkdirAll(shared, 0o755); err != nil {
		return err
	}
	tp := filepath.Join(shared, "broker-token")
	if err := os.WriteFile(tp, []byte(token), 0o600); err != nil {
		return fmt.Errorf("write token: %w", err)
	}
	log.Printf("broker ready: token written to %s; JWKS at %s/gateway/jwks", tp, issuer)

	mux := http.NewServeMux()
	mux.HandleFunc("/gateway/jwks", func(w http.ResponseWriter, _ *http.Request) {
		pub := &key.PublicKey
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{
			"keys": []map[string]string{{
				"kty": "RSA", "use": "sig", "alg": "RS256", "kid": kid,
				"n": b64(pub.N.Bytes()), "e": b64(bigEndianBytes(pub.E)),
			}},
		})
	})
	srv := &http.Server{Addr: listen, Handler: mux, ReadHeaderTimeout: 5 * time.Second}
	return srv.ListenAndServe()
}

func bigEndianBytes(v int) []byte {
	if v == 0 {
		return []byte{0}
	}
	n := 0
	for x := v; x > 0; x >>= 8 {
		n++
	}
	b := make([]byte, n)
	for i := n - 1; i >= 0; i-- {
		b[i] = byte(v)
		v >>= 8
	}
	return b
}
