// SSH-over-tunnel CLIENT for the production-shaped Docker e2e.
//
// This is the browser-side role of the new API, played by a real SSH
// client: it authenticates to the gateway's /api/v1 client route with a
// scoped broker token, then speaks REAL SSH (golang.org/x/crypto/ssh) end
// to end through the tunnel to the agent's local OpenSSH.
//
// Pin independence (docs/tunnel.md O1): the host key is pinned from a
// key file generated OUTSIDE every container and mounted read-only HERE;
// the ready message's ssh_host_key is advisory metadata and is never
// trusted. The agent pins the same file independently at enroll time, so
// a compromised gateway cannot move either party off the real sshd.
//
// Checks (any failure exits non-zero):
//
//	P1  auth+ready with the broker token, SSH exec through the tunnel
//	    returns the expected marker (positive end-to-end).
//	P2  a second round trip survives past the 10s handshake deadline
//	    (the F-13 regression class).
//	N1  wrong host key pin -> SSH handshake MUST fail (host key mismatch).
//	N2  wrong client key -> sshd MUST refuse the session.
//	N3  garbage token -> gateway MUST refuse the auth frame (no ready).
package main

import (
	"crypto/sha256"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"net"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"
)

// wsnet mirror: the tunnel carries opaque SSH bytes as binary frames after
// the JSON auth handshake; this adapts that to net.Conn exactly like the
// gateway's internal wsnet does client-side (the gateway itself only ever
// bridges frames and never speaks SSH).
type wsConn struct {
	ws      *websocket.Conn
	rmu     sync.Mutex
	wmu     sync.Mutex
	cur     []byte
	closed  chan struct{}
	closeOn sync.Once
}

func wrap(ws *websocket.Conn) *wsConn {
	return &wsConn{ws: ws, closed: make(chan struct{})}
}

func (c *wsConn) Read(p []byte) (int, error) {
	c.rmu.Lock()
	defer c.rmu.Unlock()
	for len(c.cur) == 0 {
		select {
		case <-c.closed:
			return 0, net.ErrClosed
		default:
		}
		t, data, err := c.ws.ReadMessage()
		if err != nil {
			return 0, err
		}
		if t != websocket.BinaryMessage {
			return 0, errors.New("non-binary frame after handshake")
		}
		c.cur = data
	}
	n := copy(p, c.cur)
	c.cur = c.cur[n:]
	return n, nil
}

func (c *wsConn) Write(p []byte) (int, error) {
	c.wmu.Lock()
	defer c.wmu.Unlock()
	if err := c.ws.WriteMessage(websocket.BinaryMessage, p); err != nil {
		return 0, err
	}
	return len(p), nil
}

func (c *wsConn) Close() error {
	c.closeOn.Do(func() { close(c.closed) })
	return c.ws.Close()
}
func (c *wsConn) LocalAddr() net.Addr                { return c.ws.LocalAddr() }
func (c *wsConn) RemoteAddr() net.Addr               { return c.ws.RemoteAddr() }
func (c *wsConn) SetReadDeadline(t time.Time) error  { return c.ws.SetReadDeadline(t) }
func (c *wsConn) SetWriteDeadline(t time.Time) error { return c.ws.SetWriteDeadline(t) }

func (c *wsConn) SetDeadline(t time.Time) error {
	if err := c.ws.SetReadDeadline(t); err != nil {
		return err
	}
	return c.ws.SetWriteDeadline(t)
}

type authFrame struct {
	Type     string `json:"type"`
	V        int    `json:"v"`
	Token    string `json:"token"`
	DeviceID string `json:"device_id"`
}

type readyFrame struct {
	Type       string `json:"type"`
	V          int    `json:"v"`
	DeviceID   string `json:"device_id"`
	SSHHostKey string `json:"ssh_host_key"`
}

var (
	flagGateway = flag.String("gateway", "ws://gateway:8080", "gateway base URL")
	flagToken   = flag.String("token-file", "/shared/broker-token", "broker token file (from the broker fixture)")
	flagDevice  = flag.String("device", "dev-newapi-e2e", "enrolled device id")
	flagHostPub = flag.String("host-pub", "/keys/host_ed25519.pub", "INDEPENDENT sshd host key pin")
	flagWrong   = flag.String("wrong-host-pub", "/keys/wrong_host_ed25519.pub", "wrong host key (negative control)")
	flagKey     = flag.String("client-key", "/keys/client_ed25519", "SSH client key the fixture sshd accepts")
	flagWrongK  = flag.String("wrong-client-key", "/keys/wrong_host_ed25519", "key the sshd must refuse")
	flagUser    = flag.String("user", "e2e", "sshd user")
	flagExpect  = flag.String("expect", "pocketshell-newapi-e2e", "marker the exec must echo back")
	flagWait    = flag.Duration("wait", 90*time.Second, "how long to retry while the agent connects")
)

func mustReadPin(path string) ssh.PublicKey {
	raw, err := os.ReadFile(path)
	if err != nil {
		fatalf("read pin %s: %v", path, err)
	}
	pk, _, _, _, err := ssh.ParseAuthorizedKey(raw)
	if err != nil {
		fatalf("parse pin %s: %v", path, err)
	}
	return pk
}

func fatalf(f string, a ...any) {
	fmt.Fprintf(os.Stderr, "client: FAIL: "+f+"\n", a...)
	os.Exit(1)
}
func passf(f string, a ...any) { fmt.Printf("client: PASS: "+f+"\n", a...) }

func token() string {
	// The broker mints the token at startup; wait briefly rather than racing
	// it (bounded, so a broken broker still fails the run loudly).
	deadline := time.Now().Add(60 * time.Second)
	var err error
	for {
		var raw []byte
		raw, err = os.ReadFile(*flagToken)
		if err == nil && len(strings.TrimSpace(string(raw))) > 0 {
			return strings.TrimSpace(string(raw))
		}
		if time.Now().After(deadline) {
			fatalf("read token: %v (waited 60s)", err)
		}
		time.Sleep(1 * time.Second)
	}
}

// dialAndAuth connects, sends the auth frame, and returns the wrapped conn
// after the ready frame. errOffline marks retryable "device not connected".
func dialAndAuth(bearer string) (*wsConn, error) {
	ws, _, err := websocket.DefaultDialer.Dial(*flagGateway+"/api/v1/hosts/"+*flagDevice+"/ssh", nil)
	if err != nil {
		return nil, fmt.Errorf("dial: %w", err)
	}
	ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
	a, _ := json.Marshal(authFrame{Type: "auth", V: 1, Token: bearer, DeviceID: *flagDevice})
	if err := ws.WriteMessage(websocket.TextMessage, a); err != nil {
		ws.Close()
		return nil, fmt.Errorf("send auth: %w", err)
	}
	ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		ws.Close()
		return nil, fmt.Errorf("await ready: %w", err)
	}
	ws.SetReadDeadline(time.Time{})
	var r readyFrame
	if err := json.Unmarshal(raw, &r); err != nil || r.Type != "ready" {
		ws.Close()
		return nil, fmt.Errorf("no ready frame: %s", raw)
	}
	return wrap(ws), nil
}

func sshOverTunnel(bearer string, pin ssh.PublicKey, signer ssh.Signer) (string, error) {
	conn, err := dialAndAuth(bearer)
	if err != nil {
		return "", err
	}
	defer conn.Close()
	cfg := &ssh.ClientConfig{
		User: *flagUser,
		Auth: []ssh.AuthMethod{ssh.PublicKeys(signer)},
		HostKeyCallback: func(_ string, _ net.Addr, key ssh.PublicKey) error {
			if string(key.Marshal()) != string(pin.Marshal()) {
				return errors.New("host key mismatch")
			}
			return nil
		},
		Timeout: 10 * time.Second,
	}
	c, chans, reqs, err := ssh.NewClientConn(conn, "pocketshell-tunnel", cfg)
	if err != nil {
		return "", fmt.Errorf("ssh handshake: %w", err)
	}
	cl := ssh.NewClient(c, chans, reqs)
	defer cl.Close()
	sess, err := cl.NewSession()
	if err != nil {
		return "", fmt.Errorf("session: %w", err)
	}
	defer sess.Close()
	out, err := sess.CombinedOutput("echo " + *flagExpect)
	if err != nil {
		return "", fmt.Errorf("exec: %w (%d bytes out)", err, len(out))
	}
	return strings.TrimSpace(string(out)), nil
}

func loadSigner(path string) ssh.Signer {
	raw, err := os.ReadFile(path)
	if err != nil {
		fatalf("read key %s: %v", path, err)
	}
	s, err := ssh.ParsePrivateKey(raw)
	if err != nil {
		fatalf("parse key %s: %v", path, err)
	}
	return s
}

func main() {
	flag.Parse()
	bearer := token()
	pin := mustReadPin(*flagHostPub)
	good := loadSigner(*flagKey)
	bad := loadSigner(*flagWrongK)
	wrongPin := mustReadPin(*flagWrong)

	// P1: the full positive path, with retry while the agent comes online.
	deadline := time.Now().Add(*flagWait)
	var out string
	var lastErr error
	for {
		out, lastErr = sshOverTunnel(bearer, pin, good)
		if lastErr == nil {
			break
		}
		if time.Now().After(deadline) {
			fatalf("P1 end-to-end SSH never succeeded (agent offline or broken): %v", lastErr)
		}
		time.Sleep(2 * time.Second)
	}
	if out != *flagExpect {
		fatalf("P1 exec returned %q, want %q", out, *flagExpect)
	}
	passf("P1 end-to-end SSH through the tunnel (exec echoed %q)", out)

	// P2: a round trip AFTER the 10s default handshake deadline (F-13 class:
	// the old code killed every session at exactly 10s).
	time.Sleep(11 * time.Second)
	out, err := sshOverTunnel(bearer, pin, good)
	if err != nil {
		fatalf("P2 round trip after the handshake deadline failed: %v", err)
	}
	if out != *flagExpect {
		fatalf("P2 exec returned %q, want %q", out, *flagExpect)
	}
	passf("P2 round trip survives past the 10s handshake deadline")

	// N1: a wrong INDEPENDENT host pin must break the SSH handshake.
	if _, err := sshOverTunnel(bearer, wrongPin, good); err == nil {
		fatalf("N1 SSH accepted the WRONG host key through the tunnel")
	}
	passf("N1 wrong host-key pin refused (ssh handshake failed as required)")

	// N2: a key the sshd does not know must not yield a session.
	if _, err := sshOverTunnel(bearer, pin, bad); err == nil {
		fatalf("N2 sshd accepted an UNKNOWN client key")
	}
	passf("N2 unknown client key refused by sshd")

	// N3: a garbage credential must be refused BEFORE any SSH flows.
	if _, err := dialAndAuth("not-a-jwt"); err == nil {
		fatalf("N3 gateway accepted a garbage token on the client route")
	}
	passf("N3 garbage token refused by the gateway client route")

	fmt.Printf("client: ALL CHECKS PASSED (pin sha256=%x)\n", sha256.Sum256(pin.Marshal()))
}
