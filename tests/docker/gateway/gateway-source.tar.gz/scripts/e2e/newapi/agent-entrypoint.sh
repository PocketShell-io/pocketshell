#!/bin/sh
# Agent fixture entrypoint: production-shaped enroll + run of the REAL
# pocketshell-link CLI against the REAL gateway (registry + tunnel + broker
# verification), with the fixture's real OpenSSH on loopback.
#
# The container shares the sshd service's network namespace (compose
# network_mode), which is exactly the production topology: the host agent
# reaches ITS OWN local sshd at 127.0.0.1:22 — the CLI refuses any
# non-loopback SSH destination and --insecure-dev never lifts that.
#
# Nothing here is an adapter: this is the actual binary a user would run.
set -eu

GATEWAY="${GATEWAY_URL:-http://gateway:8080}"
BROKER_ISSUER="${BROKER_ISSUER:-http://broker:8088}"
CONFIG_DIR="${CONFIG_DIR:-/state}"
DEVICE_ID="${DEVICE_ID:-dev-newapi-e2e}"
SSH_HOST="${SSH_HOST:-127.0.0.1:22}"
HOST_PUB="${HOST_PUB:-/keys/host_ed25519.pub}"
TOKEN_FILE="${TOKEN_FILE:-/shared/broker-token}"
CLI="${CLI:-/app/pocketshell-link}"

log() { printf '[agent] %s\n' "$*"; }

# 1. Wait for the gateway to report BOTH halves of the new API enabled.
i=0
until wget -qO- "$GATEWAY/healthz" 2>/dev/null | grep -q '"tunnel":"enabled"' && \
      wget -qO- "$GATEWAY/healthz" 2>/dev/null | grep -q '"registry":"enabled"'; do
  i=$((i + 1))
  [ "$i" -lt 90 ] || { log "gateway never reported registry+tunnel enabled:"; wget -qO- "$GATEWAY/healthz" || true; exit 1; }
  sleep 1
done
log "gateway healthz: registry+tunnel enabled"

# 2. Wait for the broker fixture's freshly minted token.
i=0
until [ -s "$TOKEN_FILE" ]; do
  i=$((i + 1))
  [ "$i" -lt 90 ] || { log "broker token never appeared at $TOKEN_FILE"; exit 1; }
  sleep 1
done
log "broker token present"

# 3. Enroll the REAL CLI: pins the REAL sshd host key over loopback,
#    independently checked against the key file (a mismatch aborts), and
#    registers the device's Ed25519 key with the gateway using the broker
#    token on stdin (never argv/URL).
PUB_LINE=$(tr -d '\n' <"$HOST_PUB")
log "enrolling device $DEVICE_ID (pinned host key: $PUB_LINE)"
"$CLI" enroll --token-stdin \
  --server "$GATEWAY" \
  --insecure-dev \
  --dev-broker-issuer "$BROKER_ISSUER" \
  --config-dir "$CONFIG_DIR" \
  --device-id "$DEVICE_ID" \
  --ssh-host "$SSH_HOST" \
  --expect-host-key "$PUB_LINE" <"$TOKEN_FILE"
log "enrolled; showing status (no secrets)"
"$CLI" show --config-dir "$CONFIG_DIR"

# 4. Maintain the reverse tunnel until compose tears the fixture down.
exec "$CLI" run --server "${GATEWAY/http/ws}" --insecure-dev --config-dir "$CONFIG_DIR" --verbose
