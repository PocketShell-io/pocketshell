// Package contracttests contains dependency-free, file-level contract tests
// for the delivery worker's CI/CD surfaces. They run as part of
// `go test ./...` so the main CI job enforces the deployment contract even
// without Python/Docker. Deeper semantic checks (parsing the YAML, running
// allowPattern accept/reject matrices) live in scripts/tests/contract.py,
// and behavioural harnesses in scripts/tests/*-harness.sh.
package contracttests

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
)

func repoPath(t *testing.T, parts ...string) string {
	t.Helper()
	// This package lives at <repo>/scripts/contracttests.
	base, err := filepath.Abs(filepath.Join("..", ".."))
	if err != nil {
		t.Fatal(err)
	}
	return filepath.Join(append([]string{base}, parts...)...)
}

func mustRead(t *testing.T, parts ...string) string {
	t.Helper()
	b, err := os.ReadFile(repoPath(t, parts...))
	if err != nil {
		t.Fatalf("read %v: %v", parts, err)
	}
	return string(b)
}

func want(t *testing.T, name, got string, cond bool) {
	t.Helper()
	if !cond {
		t.Errorf("contract violated: %s (context: %.120s)", name, got)
	}
}

func wantNo(t *testing.T, name, got string, cond bool) {
	t.Helper()
	if cond {
		t.Errorf("contract violated: %s (context: %.120s)", name, got)
	}
}

var (
	shaPinRef  = regexp.MustCompile(`uses:\s*([\w.-]+/[\w.-]+)@(\S+)`)
	awsKeyId   = regexp.MustCompile(`AKIA[0-9A-Z]{16}`)
	privateKey = regexp.MustCompile(`BEGIN [A-Z ]*PRIVATE KEY`)
	sha40      = regexp.MustCompile(`^[0-9a-f]{40}$`)
)

// checkPinnedActions fails unless every `uses:` reference in the workflow
// text is pinned to a 40-hex commit SHA.
func checkPinnedActions(t *testing.T, name, text string) {
	t.Helper()
	for _, m := range shaPinRef.FindAllStringSubmatch(text, -1) {
		if !sha40.MatchString(m[2]) {
			t.Errorf("%s: action %s@%s is not pinned to a commit SHA", name, m[1], m[2])
		}
	}
}

// TestDeployWorkflowIsolation: deploy.yml must be unreachable from anything
// but a push to main of the exact repository, must not be manually
// dispatchable, and must serialize deploys.
func TestDeployWorkflowIsolation(t *testing.T) {
	text := mustRead(t, ".github", "workflows", "deploy.yml")
	wantNo(t, "deploy.yml has no pull_request trigger", text, strings.Contains(text, "pull_request"))
	// D14: the reusable workflow is unreachable EXCEPT through ci.yml's
	// gated deploy job — an independent push/workflow_dispatch trigger would
	// deploy without the same-commit CI gate.
	wantNo(t, "deploy.yml has no workflow_dispatch trigger", text, strings.Contains(text, "workflow_dispatch:"))
	want(t, "deploy.yml is workflow_call-only", text, strings.Contains(text, "workflow_call:"))
	for _, guard := range []string{
		"github.event_name == 'push'",
		"github.ref == 'refs/heads/main'",
		"github.repository == 'PocketShell-io/pocketshell-gateway'",
	} {
		want(t, "deploy job if-guard contains "+guard, text, strings.Contains(text, guard))
	}
	want(t, "ci deploy job needs every same-commit gate", mustRead(t, ".github", "workflows", "ci.yml"),
		strings.Contains(mustRead(t, ".github", "workflows", "ci.yml"),
			"needs: [test, vet, format, vulnerability, build-arm64, e2e-docker]"))
	want(t, "ci deploy job refuses failed/cancelled/skipped needs", mustRead(t, ".github", "workflows", "ci.yml"),
		strings.Contains(mustRead(t, ".github", "workflows", "ci.yml"), "!contains(needs.*.result, 'skipped')"))
	want(t, "deploy concurrency group", text, strings.Contains(text, "group: deploy-main"))
	want(t, "deploys serialize", text, strings.Contains(text, "cancel-in-progress: false"))
	want(t, "deploy assumes the bootstrap OIDC role", text,
		strings.Contains(text, "arn:aws:iam::817685572750:role/pocketshell-github-deploy"))
	want(t, "OIDC permission granted", text, strings.Contains(text, "id-token: write"))
	wantNo(t, "no approval environment gate", text, regexp.MustCompile(`(?m)^.*environment:`).MatchString(text))
	checkPinnedActions(t, "deploy.yml", text)
}

// TestCIWorkflowCoversQualityGates: the CI workflow runs the race detector,
// vet, gofmt, govulncheck and the ARM64 build, with read-only permissions and
// pinned actions.
func TestCIWorkflowCoversQualityGates(t *testing.T) {
	text := mustRead(t, ".github", "workflows", "ci.yml")
	for _, marker := range []string{
		"make test", "make vet", "make fmt-check", "make vuln", "make artifacts", "make e2e-docker",
		// R5: the production new-API gate and every regression harness are
		// real CI steps, never `make check`-only conveniences.
		"make e2e-newapi", "make contract", "make workflow-harness",
		"make installer-harness", "make api-harness", "make bootstrap-harness",
		"make provision-harness", "make packaging-harness", "make shellcheck", "make imds-probe-harness",
		// Helper distribution matrix + wheels (release infra, non-gating).
		"make build-matrix", "make wheels", "make verify-wheels",
	} {
		want(t, "ci runs "+marker, text, strings.Contains(text, marker))
	}
	wantNo(t, "no gate step swallows failures", text, strings.Contains(text, "|| true"))
	wantNo(t, "no gate step tolerates failure", text, strings.Contains(text, "continue-on-error"))
	want(t, "ci permissions read-only", text, strings.Contains(text, "permissions:\n  contents: read"))
	checkPinnedActions(t, "ci.yml", text)
}

// TestBootstrapTemplateBoundaries: the CloudFormation bootstrap encodes the
// role's least privilege: exact-subject OIDC trust, split SendCommand grants,
// Resource-star reads constrained by account+region, explicit denies, and the
// configurable exact OIDC subject (D1/D2/D12).
func TestBootstrapTemplateBoundaries(t *testing.T) {
	text := mustRead(t, "infra", "github-actions.yaml")
	for _, marker := range []string{
		"ExactOIDCSubject",
		"sts:AssumeRoleWithWebIdentity",
		"SendCommandBoundedDocument",
		"SendCommandPinnedInstance",
		"ReadAndWaitDeployResults",
		"aws:ResourceAccount",
		"aws:RequestedRegion",
		"AWS-RunShellScript",
		"ssm:StartSession",
		"pocketshell-relay-RelayRole-LvjBzsqkrVMa",
		"artifacts/*",
		// R4: the runtime instance role must carry the broker-signing fences
		// itself (explicit denies survive future broad grants; the EC2
		// instance profile has AmazonSSMManagedInstanceCore).
		"DenyBrokerSigningKeyParameterReads",
		"ssm:GetParameterHistory",
		"DenyParameterPathTraversal",
	} {
		want(t, "bootstrap template contains "+marker, text, strings.Contains(text, marker))
	}
	// The reviewed integrity replacement keeps exact SendCommand resources;
	// document type is enforced by DescribeDocument and explicit version/hash
	// driver pins rather than a service-derived IAM condition.
	documentGrant := regexp.MustCompile(`(?s)- Sid: SendCommandBoundedDocument\n(.*?)- Sid: SendCommandPinnedInstance`).FindStringSubmatch(text)
	want(t, "one bounded document grant", text, len(documentGrant) == 2)
	if len(documentGrant) == 2 {
		want(t, "document grant exact SendCommand action", documentGrant[1], strings.Contains(documentGrant[1], "Action: [ssm:SendCommand]"))
		want(t, "document grant exact document ARN", documentGrant[1], strings.Contains(documentGrant[1], `Resource: !Sub "arn:aws:ssm:${AWS::Region}:${AWS::AccountId}:document/${DeployDocumentName}"`))
		wantNo(t, "document grant has no retired condition", documentGrant[1], strings.Contains(documentGrant[1], "Condition:"))
	}
	driver := mustRead(t, "scripts", "deploy.sh")
	for _, marker := range []string{"describe-document", "--document-version", "--document-hash", "--document-hash-type Sha256"} {
		want(t, "driver retains document integrity "+marker, driver, strings.Contains(driver, marker))
	}
	// The trust subject must never contain a wildcard literal.
	trust := text[strings.Index(text, "AssumeRolePolicyDocument"):]
	trust = trust[:max(0, min(len(trust), strings.Index(trust, "Policies:")))]
	wantNo(t, "trust policy has no wildcard subjects", trust, strings.Contains(trust, "*"))
	// allowedPatterns must be anchored and backslash-free (D3).
	for _, m := range regexp.MustCompile(`allowedPattern:\s*"([^"]+)"`).FindAllStringSubmatch(text, -1) {
		pat := m[1]
		want(t, "allowedPattern anchored: "+pat, pat, strings.HasPrefix(pat, "^") && strings.HasSuffix(pat, "$"))
		wantNo(t, "allowedPattern backslash-free (D3): "+pat, pat, strings.Contains(pat, `\`))
	}
	// Allow statements must not use wildcard actions or unbounded resources.
	allowSection := text
	wantNo(t, "no wildcard actions", allowSection, strings.Contains(allowSection, "Action: \"*\""))
	wantNo(t, "no secrets committed", text, awsKeyId.MatchString(text))
	wantNo(t, "no private keys committed", text, privateKey.MatchString(text))
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

// TestInstallerScriptSafety: the on-instance deploy script stays injection
// resistant and TLS-strict, and keeps the embedding contract.
func TestInstallerScriptSafety(t *testing.T) {
	text := mustRead(t, "scripts", "host", "install-deploy.sh")
	lines := strings.Split(text, "\n")
	want(t, "installer ends with main invocation (embed contract)", text,
		strings.HasSuffix(strings.TrimRight(text, "\n"), `main "$@"`))
	for _, marker := range []string{"flock", "atomic_write", "mv -Tf", "--resolve", "legacy", "--archive-sha256", "--binary-sha256", "b700"} {
		want(t, "installer contains "+marker, text, strings.Contains(text, marker))
	}
	// Trusted TLS: no non-comment line may disable verification.
	for _, l := range lines {
		trimmed := strings.TrimSpace(l)
		if strings.HasPrefix(trimmed, "#") {
			continue
		}
		wantNo(t, "installer never disables TLS verification (D8): "+trimmed, trimmed,
			strings.Contains(trimmed, "-k ") || strings.Contains(trimmed, "-sk") ||
				strings.Contains(trimmed, "--insecure") || strings.Contains(trimmed, " InsecureSkipVerify"))
	}
	wantNo(t, "installer has no eval", text, regexp.MustCompile(`\beval\b`).MatchString(text))
	wantNo(t, "no secrets committed", text, awsKeyId.MatchString(text))
}

// TestDeployDriverSafety: the deployer-side driver uploads immutably,
// verifies both digests plus version, and bounds its polling.
func TestDeployDriverSafety(t *testing.T) {
	text := mustRead(t, "scripts", "deploy.sh")
	for _, marker := range []string{"--if-none-match", "StandardOutputContent", "InvocationDoesNotExist",
		"AccessDenied", "binary_sha256", "manifest.json", "{Bucket:[$bucket]", "CONFLICT"} {
		want(t, "deploy.sh contains "+marker, text, strings.Contains(text, marker))
	}
	want(t, "deploy.sh fails closed on unset vars", text, strings.Contains(text, "set -Eeuo pipefail"))
	wantNo(t, "no secrets committed", text, awsKeyId.MatchString(text))
}

// TestEmbeddedScriptSync: the runCommand block inside the SSM document must
// equal scripts/host/install-deploy.sh (minus its final `main "$@"` line,
// replaced by the parameter invocation). This is the Go-side twin of the
// python check so `go test ./...` catches drift too.
func TestEmbeddedScriptSync(t *testing.T) {
	yamlText := mustRead(t, "infra", "github-actions.yaml")
	const beginMarker = "# ==== BEGIN generated from scripts/host/install-deploy.sh"
	const endMarker = "# ==== END generated ===="
	begin := strings.Index(yamlText, beginMarker)
	end := strings.Index(yamlText, endMarker)
	if begin < 0 || end < 0 || end < begin {
		t.Fatal("generated markers missing from infra/github-actions.yaml")
	}
	block := strings.Split(yamlText[begin:end+1+len(endMarker)+1], "\n")
	const indent = "                  "
	dedent := func(l string) string { return strings.TrimPrefix(l, indent) }
	embedded := make([]string, 0, len(block))
	for _, l := range block {
		embedded = append(embedded, dedent(l))
	}
	wrapper := strings.Join(embedded, "\n")
	encoded := regexp.MustCompile(`(?m)^([A-Za-z0-9+/=]+)\nPOCKETSHELL_DEPLOY_GZIP_BASE64$`).FindStringSubmatch(wrapper)
	if len(encoded) != 2 {
		t.Fatal("generated gzip/base64 payload missing")
	}
	compressed, err := base64.StdEncoding.Strict().DecodeString(encoded[1])
	if err != nil {
		t.Fatal(err)
	}
	gz, err := gzip.NewReader(bytes.NewReader(compressed))
	if err != nil {
		t.Fatal(err)
	}
	decoded, err := io.ReadAll(io.LimitReader(gz, 1<<20))
	closeErr := gz.Close()
	if err != nil || closeErr != nil || len(decoded) >= 1<<20 {
		t.Fatalf("decoded payload invalid or oversized: %v / %v", err, closeErr)
	}
	digest := fmt.Sprintf("%x", sha256.Sum256(decoded))
	if !strings.Contains(wrapper, " = "+digest+" ]") || !strings.Contains(wrapper, fmt.Sprintf(`-eq %d ]`, len(decoded))) {
		t.Fatal("committed wrapper digest/length must match decoded source")
	}
	embedded = append([]string{beginMarker}, strings.Split(strings.TrimRight(string(decoded), "\n"), "\n")...)
	// The decoded body preserves the installer source and helper order.
	src := mustRead(t, "scripts", "host", "install-deploy.sh")
	srcLines := strings.Split(strings.TrimRight(src, "\n"), "\n")
	if srcLines[len(srcLines)-1] != `main "$@"` {
		t.Fatal("installer must end with `main \"$@\"`")
	}
	body := srcLines[:len(srcLines)-1]
	got := embedded[1 : 1+len(body)]
	for i := range body {
		if got[i] != body[i] {
			t.Fatalf("embedded script drift at line %d:\n embedded: %q\n source:   %q", i+1, got[i], body[i])
		}
	}
	joined := strings.Join(embedded, "\n")
	for _, param := range []string{"{{Bucket}}", "{{ArtifactPath}}", "{{ExpectedSHA256}}", "{{BinarySHA256}}",
		"{{Version}}", "{{Revision}}", "{{Domain}}", "{{Aliases}}", "{{ServiceName}}", "{{ServiceUser}}", "{{HealthTimeoutSeconds}}", "{{CertDir}}", "{{RegistryFile}}"} {
		want(t, "invocation binds "+param, wrapper, strings.Contains(wrapper, param))
	}
	// D13 + R2: the IMDS helpers must be provisioned by the SAME runCommand,
	// before `main` runs — via the trusted provisioning preamble (validate
	// first, atomic rename, no symlink following), never via a bare
	// `cat >`/`install -d` that writes before validating.
	for _, helper := range []string{"imds-probe.sh", "imds-guard.sh"} {
		want(t, "document provisions "+helper, joined, strings.Contains(joined, helper))
	}
	for _, marker := range []string{
		"helper_install \"$HELPERS_DIR/imds-probe.sh\"",
		"helper_install \"$HELPERS_DIR/imds-guard.sh\"",
		"trusted helper provisioning preamble",
	} {
		want(t, "document contains "+marker, joined, strings.Contains(joined, marker))
	}
	helpersIdx := strings.Index(joined, "helper_install \"$HELPERS_DIR/imds-probe.sh\"")
	mainIdx := strings.LastIndex(joined, "\nmain \"$@\"")
	if helpersIdx < 0 || mainIdx < 0 || helpersIdx > mainIdx {
		t.Fatal("IMDS helpers must be provisioned BEFORE the main invocation")
	}
	prov := joined[helpersIdx:mainIdx]
	for _, banned := range []string{"install -d", "cat > '/usr", "chown root:root '/usr"} {
		wantNo(t, "provisioning has no privileged bypass: "+banned, prov, strings.Contains(prov, banned))
	}
	want(t, "provisioning refuses symlink leaves before writing", joined,
		strings.Contains(joined, `[ -L "$dest" ]`) && strings.Contains(joined, "mv -f"))
}

// TestInstallerParsesStructuredSystemd: the runtime credential audit must
// parse the REAL `systemctl show -p ExecStart/ExecStartPre --value` output
// (structured `{ path=... ; argv[]=... ; ... }` groups), refusing raw strings,
// multiple commands and privilege prefixes (review R1).
func TestInstallerParsesStructuredSystemd(t *testing.T) {
	text := mustRead(t, "scripts", "host", "install-deploy.sh")
	for _, marker := range []string{
		"exec_parse_commands",
		"argv[]",
		"exactly one is allowed",
		"is not structured systemd output",
		`EXEC_ARGV" = "$want_guard_argv"`,
	} {
		want(t, "installer structured-systemd audit contains "+marker, text, strings.Contains(text, marker))
	}
}

// TestRuntimeLeafAuthorityAndFlagsWitness: D23 (the installer must not
// path-mutate or path-read service-writable runtime content — privileged
// changes bind to opened verified inodes, leaf alignment runs as the service
// user, the pre-canonical base is reclaimed before children, aliasing and
// foreign-owned state refuse) and the D21 residuals (exactly one flags=
// witness per Ex command; the drop-in Exec ban parses systemd assignment
// syntax including whitespace around '=' and continuation lines).
func TestRuntimeLeafAuthorityAndFlagsWitness(t *testing.T) {
	installer := mustRead(t, "scripts", "host", "install-deploy.sh")
	for _, c := range []struct{ name, text string }{
		{"flags witness is required exactly once per Ex command (D21)", "exactly one authoritative flags witness is required"},
		{"duplicate Ex fields refuse instead of overwriting (D21)", "real systemd serializes each key once"},
		{"flags words validated against real systemd names (D21)", "EXEC_KNOWN_FLAG_NAMES"},
		{"drop-in Exec ban trims systemd assignment keys (D21)", "unit_trim"},
		{"continuation lines joined, unterminated refused (D21)", "unterminated continuation"},
		{"privileged leaf changes bind to opened verified inodes (D23)", "path replaced between check and open"},
		{"descriptor operations go through /proc/<pid>/fd (D23)", "/proc/$BASHPID/fd/"},
		{"pre-canonical base reclaimed before child work (D23)", "reclaimed pre-canonical service-owned base"},
		{"leaf alignment runs as the service user (D23)", `RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHOWN_BIN"`},
		{"hardlinked registry state refused by policy (D23)", "aliasing refused by policy"},
		{"foreign-owned registry state refused by policy (D23)", "must be service-owned"},
		{"legacy content adoption policy names hardlink refusals (D23)", "refused by the legacy-content policy"},
		// D23 authority residuals (delivery-authority-final): root ownership
		// is not write authority; the registry stays out of generic
		// certificate adoption; open identity is dev+inode complete; physical
		// comments are skipped before continuation processing (v252 parity).
		{"legacy descent authority proven before child work (D23)", "legacy write authority refused before descent"},
		{"effective service-user write probe guards legacy descent (D23 ACL semantics)", `gateway-authority-probe "$d" "$probe_uid"`},
		{"service authority probe identity verified", `[ "$uid" = "$2" ] || exit 3`},
		{"missing service authority witness refused", "invalid service uid authority probe witness"},
		{"registry directory kept out of generic certificate adoption (D23)", "NOT certificate-style adoptable"},
		{"registry file original policy validated before normalization (D23)", "before any normalization"},
		{"identity records carry device+inode (D23 full identity)", "'%F|%d|%i|%h|%a|%U|%g'"},
		{"stable-parent invariant documented for privileged opens (D23)", "Stable-parent invariant"},
		{"physical comments skipped before continuation (D21)", "Physical comments FIRST"},
		{"continuation decided by trailing-backslash parity (D21)", "trailing-backslash parity"},
	} {
		want(t, c.name, installer, strings.Contains(installer, c.text))
	}
	wantNo(t, "no recursive chown anywhere in the installer (D23)", installer,
		strings.Contains(installer, "chown -R"))
	wantNo(t, "no privileged content read for byte counts (D23)", installer,
		strings.Contains(installer, "wc -c"))
}

// TestActivationContract: the identity/tunnel activation configuration is
// explicitly carried end to end and enforced on the instance — the
// integration blocker this contract closes is a deploy reporting a healthy
// version/commit while the new API never mounted.
func TestActivationContract(t *testing.T) {
	installer := mustRead(t, "scripts", "host", "install-deploy.sh")
	deploy := mustRead(t, "scripts", "deploy.sh")
	makefile := mustRead(t, "Makefile")
	doc := mustRead(t, "infra", "github-actions.yaml")
	for _, c := range []struct{ name, text string }{
		{"installer derives the certs/ leaf (DirCache joins /certs)", `CERT_DATA_DIR="$CERT_CACHE/certs"`},
		{"installer pins the registry FILE into <certdir>/registry/", `"$REGISTRY_DIR" = "$CERT_CACHE/registry"`},
		{"installer requires the carried activation arguments", "missing required --certdir"},
		{"installer rewrites exactly one -certdir/-registry pair", "-certdir %s -registry %s"},
		{"installer refuses to activate without a nonempty allowlist", "nonempty -allow allowlist"},
		{"installer whitelists exactly the two canonical leaves", `unit_set_directive ReadWritePaths "$CERT_DATA_DIR $REGISTRY_DIR"`},
		{"installer refuses an empty (corrupt) registry file", "registry file exists but is EMPTY"},
		{"installer preserves an existing registry (no destructive reset)", "existing identity registry preserved"},
		{"installer refuses a symlinked registry file", "registry file is a symlink"},
		{"health gate fails on disabled registry posture", "registry posture on"},
		{"health gate fails on disabled tunnel posture", "tunnel posture on"},
		{"identity route probe demands auth rejection, never 404", "want 401 auth rejection"},
		{"tunnel route probe demands upgrade, never 404", "want 426 websocket-only"},
		{"runtime audit requires the carried -certdir on the running unit", "exactly one -certdir"},
		{"runtime audit requires the carried -registry on the running unit", "exactly one -registry"},
		{"leaf group exception keeps ancestors root-only", "ANCESTOR stays strictly root-owned"},
	} {
		want(t, c.name, installer, strings.Contains(installer, c.text))
	}
	wantNo(t, "installer never chowns the layout base to the service account", installer,
		strings.Contains(installer, `chown -R "$SERVICE_USER:$SERVICE_USER" "$CERT_CACHE"`))
	for _, c := range []struct{ name, text string }{
		{"deploy sends CertDir as a string-array parameter", "CertDir:[$certdir]"},
		{"deploy sends RegistryFile as a string-array parameter", "RegistryFile:[$registry]"},
		{"deploy pins the canonical certdir constant", "CERT_DIR=/var/lib/pocketshell-relay"},
		{"deploy pins the canonical registry FILE constant", "REGISTRY_FILE=/var/lib/pocketshell-relay/registry/devices.json"},
		{"deploy requires registry=enabled in the instance result", `'^registry=enabled$'`},
		{"deploy requires tunnel=enabled in the instance result", `'^tunnel=enabled$'`},
	} {
		want(t, c.name, deploy, strings.Contains(deploy, c.text))
	}
	want(t, "manifest carries the activation configuration (Makefile)",
		makefile, strings.Contains(makefile, `"certdir":"%s","registry":"%s"`))
	for _, c := range []struct{ name, text string }{
		{"document carries the CertDir parameter", "CertDir:"},
		{"document pins the canonical certdir", "^/var/lib/pocketshell-relay$"},
		{"document pins the canonical registry FILE", `^/var/lib/pocketshell-relay/registry/devices[.]json$`},
		{"invocation passes --certdir", `--certdir "{{CertDir}}"`},
		{"invocation passes --registry", `--registry "{{RegistryFile}}"`},
	} {
		want(t, c.name, doc, strings.Contains(doc, c.text))
	}
}

// TestNoSecretsInOwnedWorkflowsAndScripts: sweeps the delivery-owned files for
// credential-looking material.
func TestNoSecretsInOwnedWorkflowsAndScripts(t *testing.T) {
	for _, parts := range [][]string{
		{".github", "workflows", "deploy.yml"},
		{".github", "workflows", "ci.yml"},
		{".github", "workflows", "oidc-probe.yml"},
		{"scripts", "deploy.sh"},
		{"scripts", "bootstrap-aws.sh"},
		{"scripts", "gen-infra.py"},
		{"scripts", "host", "provision-helpers.sh"},
		{"scripts", "packaging", "build_wheel.py"},
		{"infra", "github-actions.yaml"},
	} {
		text := mustRead(t, parts...)
		wantNo(t, "no AWS access keys in "+parts[len(parts)-1], text, awsKeyId.MatchString(text))
		wantNo(t, "no private keys in "+parts[len(parts)-1], text, privateKey.MatchString(text))
	}
}
