#!/usr/bin/env bash
# PocketShell gateway — trusted helper provisioning preamble (D13, review R2).
#
# Embedded verbatim into the pocketshell-gateway-deploy SSM document by
# `make infra` (scripts/gen-infra.py) and executed BEFORE the deploy body's
# main(). It installs the IMDS helpers root-owned — the installer refuses to
# run without them — so it is the FIRST privileged mutation of any deploy.
# That is exactly why every trust decision happens BEFORE any mutation:
#
#   1. The helpers directory chain is audited AS GIVEN (no component may be
#      a symlink, the final one included) and again RESOLVED, mirroring the
#      installer's audit_chain rules: trusted owner/group, and NO
#      group-writable or world-writable bit — the sticky bit is NOT accepted
#      as a mitigation, because it protects against unlinking other users'
#      files but not against creating/planting new ones at a predictable
#      staging name — and no ACL that provably grants write beyond the owner
#      (checked only when getfacl exists — the mode-bit rules apply
#      regardless). The walk runs from the target down to AND INCLUDING
#      TRUST_BASE (default "/": every ancestor plus the root directory
#      itself); TRUST_BASE is normalized (trailing slashes, "//") and a
#      relative or otherwise non-absolute base is refused. A root/admin
#      attacker remains out of scope (they own the box already); what this
#      audit fences is every OTHER local principal.
#   2. The helpers directory is created only as the FINAL component of an
#      already-trusted parent: plain mkdir(2), never `install -d` or
#      `mkdir -p`, so no ancestor is created, chmod'ed or chowned as a side
#      effect.
#   3. The helper leaf itself is refused when it is a symlink (dangling
#      included), or an existing non-regular / not-trusted-owned file —
#      tamper evidence: attacker content is never blessed with chown.
#   4. The payload is staged under an unpredictable, EXCLUSIVELY created
#      (O_EXCL) mktemp name INSIDE the audited directory — a concurrent
#      untrusted writer can neither pre-create nor race the staging name —
#      and moved into place with rename(2): no write ever follows a symlink
#      and the helper is never observed half-written.
#
# The installer body re-audits these paths (verify_trusted_dir,
# verify_runtime_ownership); this preamble must already be safe on its own
# because it runs BEFORE that audit. `make infra` replaces nothing here —
# the block is copied verbatim; the env seams below exist only so the
# behavioral harness can exercise the exact generated code unprivileged.

HELPERS_DIR=${HELPERS_DIR:-/usr/local/lib/pocketshell-gateway}
TRUST_OWNER=${TRUST_OWNER:-root}
TRUST_GROUP_ID=${TRUST_GROUP_ID:-0}
TRUST_BASE=${TRUST_BASE:-/}
STAT_BIN=${STAT_BIN:-stat}
CHOWN_BIN=${CHOWN_BIN:-chown}
CHMOD_BIN=${CHMOD_BIN:-chmod}
GETFACL_BIN=${GETFACL_BIN:-getfacl}
MKTEMP_BIN=${MKTEMP_BIN:-mktemp}

helper_refuse() { # $1.. = reason — fail closed: the SSM command fails
  printf '[gateway-deploy] FATAL: helper provisioning refused: %s\n' "$*" >&2
  exit 1
}

# Normalize the trust base ONCE, before any audit runs: a non-absolute base
# (relative path, "." , "..") is refused outright — it is not a meaningful
# trust anchor; trailing slashes and duplicate slashes are collapsed via
# realpath -m so the chain matcher below sees exactly the path components
# stat will report. With the default "/", every absolute path is at or below
# the base and the audit covers the whole chain INCLUDING the root itself.
case "$TRUST_BASE" in
  /*) ;;
  *) helper_refuse "invalid TRUST_BASE '$TRUST_BASE' (must be an absolute path)";;
esac
TRUST_BASE=$(realpath -m -- "$TRUST_BASE") ||
  helper_refuse "cannot normalize TRUST_BASE '$TRUST_BASE'"
case "$TRUST_BASE" in
  /*) ;;
  *) helper_refuse "invalid normalized TRUST_BASE '$TRUST_BASE'";;
esac

helper_no_symlink_component() { # $1 = path — 0 iff NO component (leaf included) is a symlink
  local p=$1
  case "$p" in
    /*) ;;
    *) helper_refuse "helpers path must be absolute: $p";;
  esac
  while [ "$p" != "/" ]; do
    [ -L "$p" ] && return 1
    p=$(dirname "$p")
  done
  return 0
}

helper_acl_grants_write() { # $1 = path — 0 iff an ACL provably grants write beyond the owner
  command -v "$GETFACL_BIN" >/dev/null 2>&1 || return 1
  "$GETFACL_BIN" -pc -- "$1" 2>/dev/null | awk '
    /^(user|group):[^:]+:[^:]*w/ { bad = 1 }
    /^group::[^:]*w/             { bad = 1 }
    /^other::[^:]*w/             { bad = 1 }
    END { exit bad ? 0 : 1 }
  '
}

helper_chain_trusted() { # $1 = path — audit every EXISTING component from $1 down to AND INCLUDING $TRUST_BASE
  local p=$1 owner gid mode stat_out
  # Reachability of $1 from the trust base. With the default "/" EVERY
  # absolute path is at or below the base — a literal "$TRUST_BASE"/*
  # pattern would expand to //* and match nothing ordinary (the exact
  # vacuity the independent review found), so the root base is special-
  # cased instead of pattern-matched.
  if [ "$TRUST_BASE" != "/" ]; then
    case "$p" in
      "$TRUST_BASE"|"$TRUST_BASE"/*) ;;
      *) return 0;; # above the trust base: distro-controlled
    esac
  fi
  while :; do
    if [ -e "$p" ] || [ -L "$p" ]; then
      stat_out=$("$STAT_BIN" -c '%U %g %a' -- "$p" 2>/dev/null) ||
        helper_refuse "cannot stat path component: $p"
      read -r owner gid mode <<<"$stat_out"
      case "$mode" in
        ''|*[!0-7]*) helper_refuse "unusable mode reported for $p ('$mode')";;
      esac
      [ "$owner" = "$TRUST_OWNER" ] || helper_refuse "untrusted owner on $p ($owner)"
      [ "$gid" = "$TRUST_GROUP_ID" ] || helper_refuse "untrusted group on $p (gid $gid)"
      # NO world-writable component, sticky bit or not: sticky prevents
      # unlinking OTHER users' files, it does not prevent an untrusted
      # writer from creating (or racing) new entries — e.g. the staging
      # name below. Group-writable is equally refused.
      [ $((8#$mode & 8#2)) -eq 0 ] ||
        helper_refuse "world-writable path (sticky is no mitigation): $p ($mode)"
      [ $((8#$mode & 8#20)) -eq 0 ] || helper_refuse "group-writable path: $p ($mode)"
      helper_acl_grants_write "$p" && helper_refuse "ACL grants write on $p"
    fi
    [ "$p" = "$TRUST_BASE" ] && break
    p=$(dirname "$p")
  done
}

helper_dir_trusted() { # $1 = helpers dir — audit FIRST, create only as a trusted final component
  local d=$1 real
  [ "$d" != "/" ] || helper_refuse "helpers directory is /"
  helper_no_symlink_component "$d" || helper_refuse "symlink in helpers path: $d"
  helper_chain_trusted "$(dirname "$d")" # the parent chain must pre-exist trusted (distro path)
  if [ -d "$d" ]; then
    helper_chain_trusted "$d"
  elif [ ! -e "$d" ]; then
    mkdir -- "$d" || helper_refuse "cannot create $d (parents are never created or modified)"
    "$CHMOD_BIN" 0755 -- "$d"
    helper_chain_trusted "$d"
  else
    helper_refuse "helpers path exists but is not a real directory: $d"
  fi
  real=$(realpath -m -- "$d") || helper_refuse "cannot resolve $d"
  [ "$real" = "$d" ] || helper_chain_trusted "$real"
}

helper_install() { # $1 = destination file; payload = stdin — validate, stage, atomic rename
  local dest=$1 dir base tmp owner gid mode
  dir=$(dirname "$1")
  base=$(basename "$1")
  [ -n "$base" ] || helper_refuse "empty helper file name"
  helper_dir_trusted "$dir" # ALL validation happens BEFORE any mutation below
  [ -L "$dest" ] && helper_refuse "helper destination is a symlink: $dest (dangling included) — refusing"
  if [ -e "$dest" ]; then
    read -r owner gid mode <<<"$("$STAT_BIN" -c '%U %g %a' -- "$dest" 2>/dev/null)" ||
      helper_refuse "cannot stat existing helper $dest"
    { [ "$owner" = "$TRUST_OWNER" ] && [ "$gid" = "$TRUST_GROUP_ID" ]; } ||
      helper_refuse "existing helper $dest not trusted-owned ($owner:$gid) — refusing (tamper evidence)"
    [ -f "$dest" ] || helper_refuse "existing helper $dest is not a regular file"
  fi
  # Exclusive, unpredictable staging INSIDE the audited directory: mktemp
  # creates the file O_EXCL with mode 0600, so an untrusted concurrent
  # writer can neither pre-create the name (the old fixed
  # `.$base.tmp.$$` + `rm -f` allowed exactly that symlink race) nor win
  # the window before the write — the audited directory grants nobody but
  # the trusted owner create/unlink rights to begin with.
  tmp=$("$MKTEMP_BIN" -- "$dir/.${base}.tmp.XXXXXX") ||
    helper_refuse "cannot create exclusive staging file in $dir"
  cat >"$tmp" || { rm -f -- "$tmp"; helper_refuse "cannot stage $tmp"; }
  "$CHOWN_BIN" root:root -- "$tmp"
  "$CHMOD_BIN" 0755 -- "$tmp"
  mv -f -- "$tmp" "$dest" # rename(2): atomic, replaces the leaf, never follows it
}
