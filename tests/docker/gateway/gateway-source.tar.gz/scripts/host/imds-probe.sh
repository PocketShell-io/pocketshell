#!/bin/sh
# IMDSv2 reachability probe for the gateway service identity.
#
# Installed root-owned (0755) at /usr/local/lib/pocketshell-gateway/ by the
# deploy script and executed AS the service user, either inside a transient
# systemd scope carrying the unit's IPAddressDeny properties (systemd/BPF
# strategy) or under `runuser -u` (uid-firewall strategy).
#
# Exit codes (the CALLER classifies; write-out = '%{http_code} %{num_connects}'):
#   0  = blocked: curl 7 (refused/unreachable) with exactly "000 0".
#   1  = token PUT answered 200: protection INEFFECTIVE.
#   2  = NOT PROVEN: tooling/proxy failure, unexpected answer, answer then
#        transfer error, timeout AFTER a connection, malformed write-out.
#   10 = dropped: connect-phase timeout, curl 28 with "000 0" — what
#        IPAddressDeny's cgroup BPF egress drop produces on a real kernel
#        (tcp_connect ignores the dropped SYN's -EPERM). Accepted by the
#        installer ONLY with a positive unfiltered control (incident
#        2026-10-09: the pre-fix probe called this 2, so A never passed).
#   20 = --control only (root, no filter): IPv4 token answered 200. Distinct
#        because systemd-run itself exits 1 when it cannot start a unit.
# IPv4 first; 1 or 2 from either family is final; else any 10 beats 0.
# The token body is discarded (-o /dev/null), never printed or stored;
# --noproxy '*' keeps proxy errors from reading as "blocked".
set -u

IMDS_PROBE_CURL=${IMDS_PROBE_CURL:-curl}

probe() { # $1 = IMDS base URL
  command -v "$IMDS_PROBE_CURL" >/dev/null 2>&1 || return 2
  local out rc code conns
  out=$("$IMDS_PROBE_CURL" -sS --noproxy '*' \
    -o /dev/null --max-time 3 --connect-timeout 2 \
    -w '%{http_code} %{num_connects}' \
    -X PUT -H 'X-aws-ec2-metadata-token-ttl-seconds: 60' \
    "$1/latest/api/token" 2>/dev/null)
  rc=$?
  case "$out" in
    *[!0-9\ ]*|*\ *\ *) return 2 ;; # junk or more than two fields: NOT PROVEN
    [0-9][0-9][0-9]\ [0-9]*) ;;     # "ddd n…": the only valid shape
    *) return 2 ;;                   # empty/short/no count: NOT PROVEN
  esac
  code=${out%% *}
  conns=${out#* }
  case "$rc:$code" in
    0:200) return 1 ;;  # complete 200: token issued = protection ineffective
    0:*) return 2 ;;    # complete non-200 answer: unexpected, not proven
  esac
  [ "$code" = 000 ] && [ "$conns" = 0 ] || return 2 # answered or connected: never a denial
  case "$rc" in
    7) return 0 ;;      # refused/unreachable before any connection: blocked
    28) return 10 ;;    # connect-phase timeout, handshake never completed:
                        # dropped (BPF IPAddressDeny signature) — the caller
                        # requires a positive unfiltered control for this
    *) return 2 ;;      # any other curl failure: NOT PROVEN, never a denial
  esac
}

PROBE() { # $1 = IMDS base URL — maps probe() results onto the exit contract
  probe "$1"
  case $? in
    0) return 0 ;;
    1) return 1 ;;   # definitively ineffective
    10) return 10 ;; # dropped (control-gated by the caller)
    *) return 2 ;;   # infrastructure failure must not look like a denial
  esac
}

if [ "${1:-}" = --control ]; then
  # Positive control: only a complete 200 token answer counts.
  PROBE "http://169.254.169.254" && exit 2
  [ $? = 1 ] && exit 20
  exit 2
fi

v4=0
PROBE "http://169.254.169.254" || v4=$?
case "$v4" in 1|2) exit "$v4" ;; esac
v6=0
PROBE "http://[fd00:ec2::254]" || v6=$?
case "$v6" in 1|2) exit "$v6" ;; esac
[ "$v4" = 10 ] || [ "$v6" = 10 ] && exit 10
exit 0
