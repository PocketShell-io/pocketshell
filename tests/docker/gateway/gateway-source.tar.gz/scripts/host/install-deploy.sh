#!/usr/bin/env bash
# PocketShell gateway — on-instance deploy script.
#
# Embedded verbatim into the `pocketshell-gateway-deploy` SSM document
# (infra/github-actions.yaml; regenerate with `make infra`). It is the ONLY
# code the GitHub deploy role can execute on the instance; every argument is
# constrained by an anchored allowedPattern in that document AND re-validated
# here, and the artifact path's embedded digest must equal the expected
# archive digest, so parameter substitution games fail closed.
#
# Contract (docs/deployment.md; review ledger D4 D5 D6 D8 D11 D13 D14):
#   1. Under an exclusive flock (concurrent deploys serialize).
#   2. Download the SHA-addressed archive; verify gzip integrity, trusted
#      sha256 == --archive-sha256, the VERSION sidecar, the digest-bound
#      manifest (including the source revision), and the gunzipped binary's
#      own sha256 == --binary-sha256 (archive and executable have SEPARATE
#      digests), and full ARM64 ELF field validation (magic, class,
#      endianness, version, e_type, e_machine = 0xB7 0x00 LE).
#   3. D13 migration: allocate a dedicated no-login system user idempotently
#      (UID 0 and any privileged/supplementary group are refused; the group
#      set must be exactly its own group); make ONLY the certificate cache
#      and a separate registry directory writable by it; everything else
#      (releases, bin link, unit, drop-ins, state, backups, helpers) stays
#      root-owned and is DAC-audited — including an EFFECTIVE write probe
#      executed as the service user. Unit gains User=/Group=, CAP_NET_BIND_
#      SERVICE only (Ambient+Bounding), NoNewPrivileges, ProtectSystem=strict,
#      PrivateTmp, RestrictAddressFamilies, and a WHITELISTED ReadWritePaths
#      (cert cache + registry; legacy/foreign entries are dropped, never
#      carried forward). Before success, the RUNNING process is audited:
#      /proc/<pid>/status Uid/Gid/Cap* and the effective systemd properties
#      (User, Group, NoNewPrivileges, caps, ProtectSystem, ReadWritePaths,
#      IPAddressDeny/ExecStartPre pair, drop-ins).
#   4. D13 IMDS, decided in a PREFLIGHT before the unit/binary is touched:
#      strategy A (IPAddressDeny for 169.254.169.254 + fd00:ec2::254) needs
#      a differential proof — unfiltered root control gets a token, the same
#      probe AS the service user under IPAddressDeny is refused or dropped;
#      else strategy B (root ExecStartPre uid REJECT) only if
#      `imds-guard.sh --check` passes, the rule applies and a runuser probe
#      proves it (re-probed after restart); else REFUSE, nothing mutated.
#      Probe exit codes are the verdict; tooling failure never protects.
#   5. D8: after the usual identity + trusted-TLS 4xx checks on canonical and
#      aliases, the running APPLICATION is verified: /healthz over trusted
#      TLS on both names must return JSON whose version equals the deployed
#      VERSION, whose commit matches the source revision, AND whose registry
#      and tunnel postures are BOTH "enabled" — version/commit health alone
#      would happily accept a binary whose new API never mounted (the routes
#      are additionally probed: an anonymous /identity/v1/devices must be
#      auth-rejected 401 and the client-ssh route 426-upgrade-required, never
#      404). A legacy binary without /healthz can only be accepted during
#      ROLLBACK (frozen 426 behaviour, reported as healthz=legacy — never
#      claimed as a version check); a rollback to a previously ACTIVATED
#      release requires the enabled postures again.
#   6. Preserve the legacy executable on first migration; on failure restore
#      previous unit+symlink+state atomically. Exit 0 only if the new release
#      or the rollback is healthy; exit 2 when the rollback itself fails.
#
# Result lines for scripts/deploy.sh: sha256=, binary-sha256=, version=,
# commit=, healthz=, registry=, tunnel=, imds=, health=, rollback=, previous=.
#
# `main "$@"` MUST remain the last non-empty line: `make infra` replaces it
# with the SSM parameter invocation when embedding this file.
set -Eeuo pipefail

log() { printf '[gateway-deploy] %s\n' "$*"; }
die() { printf '[gateway-deploy] FATAL: %s\n' "$*" >&2; exit "${2:-1}"; }

assert_arg() { # $1 = value, $2 = anchored ERE (backslash-free), $3 = label
  printf '%s' "$1" | grep -Eq -- "$2" || die "bad $3 argument"
}

sha_of() { "$SHA_BIN" <"$1" 2>/dev/null | awk '{print $1}'; }

# Identity of the RUNNING service process (kernel-managed symlink). Health
# compares this path AND its content hash against the deployed release, so a
# unit pointing at the wrong file or a stale binary fails the deploy.
running_exe() { readlink -f "/proc/$1/exe"; }

# Runtime credential audit source (D13). A seam so the harness can exercise
# the full audit without a real kernel process: production reads /proc.
proc_status() { cat "/proc/$1/status" 2>/dev/null; }

# Effective unit property (D13). Seam for the same reason: production asks
# systemd for the MERGED value (unit + drop-ins), which is what actually runs.
systemd_prop() { "$SYSTEMCTL" show -p "$1" --value "$SERVICE"; }

# Full ARM64 ELF validation at exact offsets (D4): magic 7f 45 4c 46, class
# 02 (64-bit), data 01 (little-endian), version 01; e_type (offset 16) must
# be ET_EXEC(2) or ET_DYN(3); e_machine (offset 18) must be b7 00 —
# EM_AARCH64 (183) little-endian.
elf_is_arm64() {
  local f=$1 hdr etype emach
  [ -s "$f" ] || return 1
  hdr=$(od -An -tx1 -v -N 8 "$f" 2>/dev/null | tr -d ' \n')
  [ "$hdr" = "7f454c4602010100" ] || return 1
  etype=$(dd if="$f" bs=1 skip=16 count=2 status=none 2>/dev/null | od -An -tx1 | tr -d ' \n')
  emach=$(dd if="$f" bs=1 skip=18 count=2 status=none 2>/dev/null | od -An -tx1 | tr -d ' \n')
  [ "$emach" = "b700" ] || return 1
  case "$etype" in 0200|0300) return 0;; *) return 1;; esac
}

# Token-aware ExecStart rewrite (D11 + activation contract): substitute the
# binary path (first token), drop any existing -domain/-aliases/-certdir/
# -registry pairs, keep every other argument verbatim and in order, then
# append exactly one -domain/-aliases pair plus exactly one -certdir and one
# -registry (the carried activation configuration). The preserved arguments
# MUST carry a nonempty -allow allowlist: the new API refuses to start with
# an empty allowlist next to a public domain, so a legacy unit without one
# must fail the rewrite BEFORE any unit write, not at startup.
rewrite_exec_start() { # $1 = current ExecStart, $2 = binary link, $3 = domain, $4 = aliases, $5 = certdir, $6 = registry file
  local bin=$2 domain=$3 aliases=$4 certdir=$5 registry=$6 tok out='' i=0
  local allow_pending=0 allow_seen=0
  local -a toks
  read -r -a toks <<<"$1"
  [ "${#toks[@]}" -ge 1 ] || return 1
  while [ $i -lt ${#toks[@]} ]; do
    tok=${toks[$i]}
    if [ $i -eq 0 ]; then
      out=$bin
    elif [ "$allow_pending" = "1" ]; then
      allow_pending=0
      case "$tok" in
        ''|-*) return 1;; # -allow without a nonempty value (or value-less)
        *) allow_seen=1; out="$out $tok";;
      esac
    elif [ "$tok" = "-domain" ] || [ "$tok" = "-aliases" ] ||
      [ "$tok" = "-certdir" ] || [ "$tok" = "-registry" ]; then
      i=$((i + 1)) # drop the flag AND its value
    else
      out="$out $tok"
    fi
    [ "$tok" = "-allow" ] && allow_pending=1
    i=$((i + 1))
  done
  [ "$allow_seen" = "1" ] || return 1
  printf '%s -domain %s -aliases %s -certdir %s -registry %s' "$out" "$domain" "$aliases" "$certdir" "$registry"
}

# Set/replace a systemd directive inside the unit content (stdin → stdout).
# Drops every existing `Key=...` line and re-inserts `Key=value` at the END
# of the [Service] section (i.e. just before [Install], or at EOF). An empty
# value writes `Key=` which explicitly resets the list in systemd.
unit_set_directive() { # $1 = key, $2 = value
  local key=$1 val=$2 l inserted=0
  local -a out=()
  while IFS= read -r l; do
    [ "${l%%=*}" = "$key" ] && continue
    if [ "$inserted" = 0 ] && [ "$l" = "[Install]" ]; then
      out+=("$key=$val")
      inserted=1
    fi
    out+=("$l")
  done
  if [ "$inserted" = 0 ]; then
    out+=("$key=$val")
  fi
  printf '%s\n' "${out[@]}"
}

unit_drop_line() { # $1 = exact line to remove (every occurrence); stdin -> stdout
  local drop=$1 l
  while IFS= read -r l; do
    [ "$l" = "$drop" ] || printf '%s\n' "$l"
  done
}

# D13 IMDS verdict (imds-probe.sh codes): 0 protected; 10 (dropped) only
# with a positive control (20); anything else is NOT protected.
imds_protected() { # $1 = filtered probe rc, $2 = unfiltered control rc
  [ "$1" = 0 ] && return 0
  [ "$1" = 10 ] && [ "$2" = 20 ] && return 0
  return 1
}

# Strategy-A transient-unit probes (systemd-run --wait propagates the exit
# code); also run natively by scripts/tests/imds-native-proof.sh.
imds_control_probe() { # root, NO filter: must obtain a token (rc 20; see imds-probe.sh)
  "$SYSTEMD_RUN" --collect --quiet --wait --pipe \
    --unit="pocketshell-imds-control-$$" -p Type=oneshot \
    "$HELPERS_DIR/imds-probe.sh" --control >/dev/null 2>&1
}
imds_filtered_probe() { # AS the service user, carrying the unit's IPAddressDeny
  "$SYSTEMD_RUN" --collect --quiet --wait --pipe \
    --unit="pocketshell-imds-probe-$$" \
    -p "User=$SERVICE_USER" -p Type=oneshot \
    -p "IPAddressDeny=$IMDS_V4" -p "IPAddressDeny=$IMDS_V6" \
    "$HELPERS_DIR/imds-probe.sh" >/dev/null 2>&1
}

# --- overridable for tests; production values match the legacy layout ------
RELEASE_ROOT=${RELEASE_ROOT:-/usr/local/lib/pocketshell-gateway/releases}
BIN_LINK=${BIN_LINK:-/usr/local/bin/pocketshell-relay}
UNIT_DIR=${UNIT_DIR:-/etc/systemd/system}
STATE_DIR=${STATE_DIR:-/var/lib/pocketshell-gateway}
LEGACY_DIR=$STATE_DIR/legacy
BACKUP_DIR=$STATE_DIR/backups
HELPERS_DIR=${HELPERS_DIR:-/usr/local/lib/pocketshell-gateway}
# Activation contract (carried deployment configuration, validated in main):
# CERT_CACHE is the -certdir flag value — the autocert BASE. Both the legacy
# and the new binary store their cache under <certdir>/certs (DirCache joins
# "/certs"), so the canonical writable leaf IS the legacy cache directory and
# migration preserves it in place. REGISTRY_FILE is the -registry FILE the Go
# identity store owns (it creates/initializes the file itself; an empty
# pre-created file is corrupt). The base itself stays a root-ONLY ancestor:
# root:root 0755, never writable by the service account — only certs/ and
# registry/ are service-owned leaves, and ReadWritePaths lists exactly those
# two children.
CERT_CACHE=${CERT_CACHE:-/var/lib/pocketshell-relay}
REGISTRY_FILE=${REGISTRY_FILE:-/var/lib/pocketshell-relay/registry/devices.json}
AWS_BIN=${AWS_BIN:-aws}
SYSTEMCTL=${SYSTEMCTL:-systemctl}
SYSTEMD_RUN=${SYSTEMD_RUN:-systemd-run}
RUNUSER_BIN=${RUNUSER_BIN:-runuser}
CURL_BIN=${CURL_BIN:-curl}
SHA_BIN=${SHA_BIN:-sha256sum}
GETENT_BIN=${GETENT_BIN:-getent}
USERADD_BIN=${USERADD_BIN:-useradd}
GROUPADD_BIN=${GROUPADD_BIN:-groupadd}
USERMOD_BIN=${USERMOD_BIN:-usermod}
CHOWN_BIN=${CHOWN_BIN:-chown}
CHMOD_BIN=${CHMOD_BIN:-chmod}
ID_BIN=${ID_BIN:-id}
STAT_BIN=${STAT_BIN:-stat}
LOCK_WAIT=${LOCK_WAIT:-600}
# Who counts as the trusted administrative owner of install paths (D13).
# Overridable so the non-root harness can exercise the same checks.
TRUST_OWNER=${TRUST_OWNER:-root}
TRUST_GROUP_ID=${TRUST_GROUP_ID:-0}
# Components at or below TRUST_BASE are audited strictly, down to AND
# INCLUDING the base itself; ancestors above it are assumed distro-controlled.
# Default "/" audits EVERYTHING (the whole chain including the root directory
# — the base is special-cased, never pattern-matched: "$TRUST_BASE"/* would
# expand to //* and match nothing ordinary, which once made the production
# default vacuous). Trailing/duplicate slashes are normalized lexically; a
# non-absolute base is refused.
TRUST_BASE=${TRUST_BASE:-/}
case "$TRUST_BASE" in
  /*) ;;
  *) printf '[gateway-deploy] FATAL: TRUST_BASE must be an absolute path (got %s)\n' "$TRUST_BASE" >&2; exit 1;;
esac
until [ "$TRUST_BASE" = "/" ] || [ "${TRUST_BASE%/}" = "$TRUST_BASE" ]; do
  TRUST_BASE=${TRUST_BASE%/}
done

ARCHIVE_NAME=gateway-linux-arm64.gz
RELEASE_BIN_NAME=pocketshell-gateway
KEEP_RELEASES=3
IMDS_V4=169.254.169.254
IMDS_V6=fd00:ec2::254
# CAP_NET_BIND_SERVICE is capability 10 → bit mask 0x400 = 1024 (D13 audit).
CAP_BIND_BIT=1024
# Groups that would grant the runtime user privilege beyond its own
# (D13): any membership is refused, and the EXACT group set is enforced
# separately (own primary group only).
DANGEROUS_GROUPS="wheel sudo admin root adm docker systemd-journal systemd-network systemd-resolve shadow operator lpadmin video disk"
# Plain GET (no upgrade) must be answered by the frozen wire contract with a
# 4xx; any of these proves the TLS listener + router are alive on the name.
# 403 is deliberately NOT accepted: autocert rejects unknown-SNI requests and
# we must never weaken to "some 4xx" (D8: no disabling TLS security to pass).
ACCEPTED_HEALTH_CODES="400 401 426"

TMP_DIR=''   # cleaned by the EXIT trap; guarded so it is never empty (D6)
PROBE_DIR='' # TLS/healthz response scratch — kept alive through rollback so
             # the restored-configuration re-check never writes outside it
             # (the old code cleaned TMP_DIR before the rollback health pass).
cleanup() {
  if [ -n "$TMP_DIR" ]; then
    rm -rf "$TMP_DIR"
    TMP_DIR=''
  fi
  if [ -n "$PROBE_DIR" ]; then
    rm -rf "$PROBE_DIR"
    PROBE_DIR=''
  fi
  return 0
}
trap cleanup EXIT

ensure_probe_dir() {
  if [ -z "$PROBE_DIR" ] || [ ! -d "$PROBE_DIR" ]; then
    PROBE_DIR=$(mktemp -d "${TMPDIR:-/tmp}/gateway-probe.XXXXXX")
  fi
}

atomic_write() { # $1 = destination, stdin = content (same-directory rename, D6)
  # mktemp stages under an exclusive (O_EXCL), unpredictable name INSIDE the
  # audited target directory — the old fixed "$1.tmp.$$" + `cat >` let a
  # writer in a writable directory race a symlink under the shell
  # redirection before the final rename (the same pattern flagged for the
  # helper preamble in R2; the audited directory must grant nobody but root
  # create/unlink rights anyway).
  local dest=$1 tmp
  tmp=$(mktemp -- "$1.tmp.XXXXXX") || die "cannot stage atomic write to $1"
  cat >"$tmp" || { rm -f -- "$tmp"; die "cannot write staging file $tmp"; }
  mv -f "$tmp" "$dest"
}

# Root-owned install directories on the SERVICE USER's exec/read path
# (release root, per-release directory, the certdir base and any ancestor
# created for it) get an EXPLICIT 0755 — never whatever the caller's umask
# happens to produce. The SSM envelope runs under `umask 077`, so a bare
# `mkdir -p` yields root:root 0700 directories the non-root service cannot
# traverse: systemd then fails ExecStart with 203/EXEC "Permission denied"
# (incident: deploy 0ca7ec8, SSM 4bcf35ae). 0755 grants the service r-x
# only; it is never group- or world-WRITABLE, so the D13 path-trust audit
# (audit_chain / tree_has_violation / verify_runtime_ownership) is unchanged.
# Service-owned runtime leaves (certs/, registry/) are NOT handled here —
# they stay 0700 owned by the service (migrate_leaf_dir/migrate_registry_dir).
mkdir_tail_0755() { # $1 = absolute directory — create ONLY its missing tail, each new component 0755
  local d=$1 c i
  local -a missing=()
  c=$d
  while [ ! -e "$c" ] && [ ! -L "$c" ]; do
    missing+=("$c")
    c=$(dirname "$c")
  done
  [ -d "$c" ] && [ ! -L "$c" ] || die "cannot create $d: existing component $c is not a real directory (D13)"
  for ((i = ${#missing[@]} - 1; i >= 0; i--)); do
    mkdir -- "${missing[$i]}" || die "cannot create directory ${missing[$i]}"
    chmod 0755 -- "${missing[$i]}" || die "cannot set mode 0755 on ${missing[$i]}"
  done
}

ensure_root_dir_0755() { # $1 = root-owned install directory the service must traverse, $2 = label
  local d=$1 label=$2 owner mode
  mkdir_tail_0755 "$d"
  [ -d "$d" ] && [ ! -L "$d" ] || die "$label is not a real directory: $d (D13)"
  read -r owner mode <<<"$("$STAT_BIN" -c '%U %a' "$d" 2>/dev/null)" || die "cannot stat $label: $d"
  [ "$owner" = "$TRUST_OWNER" ] || die "$label owned by '$owner', must be $TRUST_OWNER — refusing (D13)"
  # Also repairs a directory an earlier deploy left at the umask-derived
  # 0700 (the release root and per-release dir of the failed rollout).
  if [ "$mode" != "755" ]; then
    chmod 0755 -- "$d" || die "cannot set mode 0755 on $label: $d"
  fi
}

# Gid of the service user's OWN designated group (the only group a runtime
# leaf may carry). Resolved lazily and cached; on a first migration the
# account may not exist yet, in which case no leaf can be service-owned
# anyway and the failure only matters when the exception is about to apply.
SERVICE_GID=''
service_gid() {
  if [ -z "$SERVICE_GID" ]; then
    SERVICE_GID=$("$ID_BIN" -g "$SERVICE_USER" 2>/dev/null) || return 1
  fi
  return 0
}

# D13 path-trust, ONE chain: every existing component of $1 from $1 down to
# AND INCLUDING $2 (the trust base; as given — stat follows symlinks, so a
# symlink component is judged by its target) must be owned by the
# administrative owner, and must carry NEITHER group- NOR world-writable
# bits. The sticky bit is NOT accepted as a mitigation (R2): it only blocks
# unlinking other users' files, not creating/racing new entries at a
# predictable staging name. $3=1 allows the LEAF to be owned by the runtime
# service user with its OWN designated group — ONLY the designed
# runtime-writable leaves (certs cache directory, registry directory/file)
# pass 1, and ONLY the leaf: every ANCESTOR stays strictly root-owned with
# group 0 (never widen to reach a leaf). The exception needs owner AND group
# to match the service account exactly; a service-owned leaf under any other
# group is refused.
audit_chain() {
  local p comp i mode owner gid base=$2 runtime_leaf=$3
  local -a parts=()
  comp="$1"
  # Reachability of $1 from the trust base. With the default "/" EVERY
  # absolute path is at or below the base — pattern-matching "$base"/*
  # would expand to //* and match nothing ordinary (the vacuous default the
  # independent review found in the provisioning preamble), so the root
  # base is special-cased instead.
  if [ "$base" != "/" ]; then
    case "$comp" in
      "$base"|"$base"/*) ;;
      *) return 0;; # above the trust base: distro-controlled
    esac
  fi
  while [ "$comp" != "$base" ]; do
    parts+=("$comp")
    comp=$(dirname "$comp")
  done
  parts+=("$base") # the base itself is audited too (for "/": the root directory)
  for ((i = ${#parts[@]} - 1; i >= 0; i--)); do
    p=${parts[$i]}
    [ -e "$p" ] || continue
    read -r owner gid mode <<<"$($STAT_BIN -c '%U %g %a' "$p" 2>/dev/null)" ||
      die "cannot stat path component: $p"
    case "$mode" in
      ''|*[!0-7]*) die "unusable mode reported for $p ('$mode') — refusing (D13)";;
    esac
    if [ "$i" = "0" ] && [ "$runtime_leaf" = "1" ] && [ "$owner" = "$SERVICE_USER" ]; then
      service_gid || die "cannot resolve service group for runtime-leaf audit (D13)"
      [ "$gid" = "$SERVICE_GID" ] ||
        die "runtime leaf $p owned by $SERVICE_USER but group is '$gid', want the designated '$SERVICE_GID' — refusing (D13)"
    else
      [ "$owner" = "$TRUST_OWNER" ] || die "untrusted owner on $p ($owner) — refusing (D13)"
      [ "$gid" = "$TRUST_GROUP_ID" ] || die "untrusted group on $p (gid $gid) — refusing (D13)"
    fi
    if [ $((8#$mode & 8#2)) -ne 0 ]; then
      die "world-writable path (sticky is no mitigation): $p ($mode) — refusing (D13)"
    fi
    if [ $((8#$mode & 8#20)) -ne 0 ]; then
      die "group-writable install path: $p ($mode) — refusing (D13)"
    fi
  done
}

# D13 path-trust: audit the RESOLVED path and ALSO the path AS GIVEN.
# realpath -m alone launders a symlinked prefix into its target: the audit
# must cover the original components too (the plant site) and, for every
# symlinked component, that redirect's own chain — a planted symlink cannot
# launder ownership either way.
verify_trusted_dir() { # $1 = directory (need not exist yet; absolute), $2 = allow-runtime-leaf(0|1)
  local p=$1 runtime_leaf=${2:-0} real c i
  real=$(realpath -m -- "$p") || die "cannot resolve path: $p"
  audit_chain "$real" "$TRUST_BASE" "$runtime_leaf"
  local -a parts=()
  c="$p"
  while [ "$c" != "/" ]; do
    parts+=("$c")
    c=$(dirname "$c")
  done
  for ((i = 0; i < ${#parts[@]}; i++)); do
    [ -e "${parts[$i]}" ] || continue
    if [ "$i" = "0" ]; then
      audit_chain "${parts[$i]}" "$TRUST_BASE" "$runtime_leaf"
    else
      audit_chain "${parts[$i]}" "$TRUST_BASE" 0
    fi
  done
}

endpoint_ok() { # $1 = DNS name — TRUSTED TLS against the system CA (D8)
  local code
  code=$("$CURL_BIN" -sS -o /dev/null -w '%{http_code}' --resolve "$1:443:127.0.0.1" --max-time 5 "https://$1/" 2>/dev/null || true)
  local ok
  for ok in $ACCEPTED_HEALTH_CODES; do [ "$code" = "$ok" ] && return 0; done
  log "endpoint check: name=$1 http_code=${code:-none} (trusted TLS verification)"
  return 1
}

json_field() { # $1 = file, $2 = key → value (flat JSON, no jq on instance)
  grep -o "\"$2\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$1" | head -1 | sed "s/.*:[[:space:]]*\"//; s/\"$//"
}

# D8: verify the running APPLICATION reports itself over trusted TLS.
# Sets HEALTHZ_RESULT to ok|legacy|mismatch. Returns 0 iff acceptable FOR
# THE MODE:
#   require=1 (new deploy): /healthz must be 200 JSON with version == the
#     deployed VERSION, commit matching the source revision (full or
#     non-empty prefix), AND registry+tunnel postures BOTH "enabled" — the
#     activation gate. A correct version/commit with disabled/failed postures
#     means the new API never mounted; that is a FAILED deploy.
#   require=0 (rollback): a real JSON healthz is verified against the
#     recorded previous version/revision; when the rollback target was an
#     ACTIVATED release (want_activation=1) the enabled postures are
#     required again (never accept a silently deactivated previous release).
#     A legacy binary without /healthz is accepted as healthz=legacy (frozen
#     426) — but only when no activation was expected of it.
HEALTHZ_RESULT=legacy
healthz_check() { # $1 = name, $2 = expect-version, $3 = expect-revision, $4 = require(0|1), $5 = want-activation(0|1)
  local name=$1 want_version=$2 want_rev=$3 require=$4 want_activation=$5
  ensure_probe_dir
  local body="$PROBE_DIR/healthz.body" code hv hc hr ht
  code=$("$CURL_BIN" -sS -o "$body" -w '%{http_code}' --resolve "$name:443:127.0.0.1" --max-time 5 "https://$name/healthz" 2>/dev/null || true)
  hv=$(json_field "$body" version 2>/dev/null || true)
  hc=$(json_field "$body" commit 2>/dev/null || true)
  hr=$(json_field "$body" registry 2>/dev/null || true)
  ht=$(json_field "$body" tunnel 2>/dev/null || true)
  if [ "$code" = "200" ] && [ -n "$hv" ] && [ -n "$hc" ]; then
    if [ "$hv" != "$want_version" ]; then
      log "healthz: version mismatch on $name: got '$hv' want '$want_version'"
      HEALTHZ_RESULT=mismatch
      return 1
    fi
    if ! printf '%s' "$hc" | grep -Eq '^[0-9a-f]{7,40}$'; then
      log "healthz: malformed commit on $name: '$hc'"
      HEALTHZ_RESULT=mismatch
      return 1
    fi
    case "$want_rev" in
      "$hc"*) : ;; # reported commit is a (possibly full) prefix of ours
      *) log "healthz: commit mismatch on $name: got '$hc' want '$want_rev'"; HEALTHZ_RESULT=mismatch; return 1;;
    esac
    if [ "$require" = "1" ] || [ "$want_activation" = "1" ]; then
      [ "$hr" = "enabled" ] || { log "healthz: registry posture on $name is '${hr:-<missing>}' (want enabled) — activation gate failed"; HEALTHZ_RESULT=mismatch; return 1; }
      [ "$ht" = "enabled" ] || { log "healthz: tunnel posture on $name is '${ht:-<missing>}' (want enabled) — activation gate failed"; HEALTHZ_RESULT=mismatch; return 1; }
    else
      log "healthz: $name posture registry='${hr:-<missing>}' tunnel='${ht:-<missing>}' (legacy-era target, activation not required)"
    fi
    HEALTHZ_RESULT=ok
    return 0
  fi
  # No usable /healthz — legacy binary behaviour (frozen 426 contract).
  HEALTHZ_RESULT=legacy
  if [ "$require" = "1" ]; then
    log "healthz: new binary did not serve JSON /healthz on $name (http_code=${code:-none}) — refusing (D8)"
    return 1
  fi
  if [ "$want_activation" = "1" ]; then
    log "healthz: rollback target was an ACTIVATED release but $name serves no JSON /healthz (http_code=${code:-none}) — refusing"
    return 1
  fi
  log "healthz: $name has no JSON /healthz — accepted as LEGACY rollback (version check NOT claimed)"
  return 0
}

# --- D13 runtime credential audit -------------------------------------------
# mask_has_only_bind <hex> → 0 iff the mask is a subset of CAP_NET_BIND_SERVICE
mask_has_only_bind() {
  local m
  m=$((16#$1)) || return 1
  [ $((m & ~CAP_BIND_BIT)) -eq 0 ]
}
# mask_is_bind <hex> → 0 iff the mask is exactly CAP_NET_BIND_SERVICE
mask_is_bind() {
  local m
  m=$((16#$1)) || return 1
  [ "$m" -eq "$CAP_BIND_BIT" ]
}
# --- systemd property serialization (real `systemctl show --value`) ----------
# The unit SOURCE says `CapabilityBoundingSet=CAP_NET_BIND_SERVICE`, but systemd
# stores capabilities as a 64-bit mask and `systemctl show` renders that mask
# with capability_set_to_string(): LOWERCASE names (cap_net_bind_service),
# space-separated, in capability-number order, never duplicated; an unset
# bounding set renders as the FULL list, an empty ambient set as "". Verified on
# systemd 252.23 (Amazon Linux 2023, deploy incident 37947576965) and 255.4.
#
# prop_caps_exactly_bind <value> → 0 iff the rendered set is EXACTLY
# {CAP_NET_BIND_SERVICE}: one token, compared case-insensitively against the
# full capability name. Empty, numeric, extra or partial names all refuse.
prop_caps_exactly_bind() {
  local -a toks=()
  read -r -a toks <<<"$1"
  [ "${#toks[@]}" = 1 ] || return 1
  [ "${toks[0],,}" = "cap_net_bind_service" ]
}

# IPAddressDeny= is stored as address prefixes and rendered by systemctl as
# CIDR ("169.254.169.254/32 fd00:ec2::254/128"), in set order (NOT unit order).
# prop_ipdeny_has <value> <address> <host-prefix-len> → 0 iff the rendered list
# denies exactly that host: the bare address or address/<host-prefix-len>. A
# broader or different prefix does not count (the audit stays exact).
prop_ipdeny_has() {
  local tok
  local -a toks=()
  read -r -a toks <<<"$1"
  for tok in ${toks[@]+"${toks[@]}"}; do
    tok=${tok,,}
    if [ "$tok" = "${2,,}" ] || [ "$tok" = "${2,,}/$3" ]; then return 0; fi
  done
  return 1
}

# read a Cap* hex field from the captured status text
cap_field() { # $1 = status text, $2 = field name
  printf '%s\n' "$1" | awk -v f="$2" '$1 == f":" {print $2; found=1} END {if (!found) exit 1}'
}

# --- structured systemd Exec* property parsing (regression, review R1) --------
# `systemctl show` does NOT return the raw command line: it returns one
# `{ ... }` group per command, with ` ; `-separated `key=value` fields that
# BEGIN with `path=` and `argv[]=`. systemd CONSUMES the privilege/behavior
# modifier run (+ - ! !! @ :) from the first word at load time
# (v255 load-fragment.c config_parse_exec), so the plain properties report
# PREFIX-FREE path/argv and only ignore_errors=yes for '-'; the flags-aware
# ExecStartEx/ExecStartPreEx properties carry the consumed flags instead
# (dbus-execute.c append_exec_ex_command; names per shared/exec-util.c:
# ignore-failure privileged no-setuid ambient no-env-expand; '@' has no
# flag — it replaces argv[0], visible as argv[] head != path). Verified
# empirically on the installed systemd 255.4. The audit therefore consults
# the Ex properties and treats a prefix INSIDE a property value as invented
# output. Systemd versions without ExecStartEx fail closed (empty property).
# ANY other shape is refused: the previous parser read the first whitespace
# token of the whole value, got `{` from every real systemd, and rejected
# every real deployment. Parsing here is exact — no substring search, no
# shell evaluation of the property.
#
# Flags witness (review D21): real systemd ALWAYS serializes exactly one
# flags= field into every Ex command group (empty for unmodified commands).
# A group WITHOUT flags= is a plain property (or invented output) wearing an
# Ex label — accepting it would let a plain ignore_errors= stand in for
# authoritative flag evidence. Duplicates overwrite nothing here: each key
# must appear at most once, and every flags= word must be a name real
# systemd emits (exec_command_flags_to_strv; shared/exec-util.c).
EXEC_KNOWN_TRAILER_KEYS='ignore_errors flags start_time stop_time stop_timeout pid code status'
EXEC_KNOWN_FLAG_NAMES='ignore-failure privileged no-setuid ambient no-env-expand'

flags_words_ok() { # $1 = raw flags= value, $2 = label → 0 iff every word is a flag real systemd emits
  local fw
  for fw in $1; do
    case " $EXEC_KNOWN_FLAG_NAMES " in
      *" $fw "*) ;;
      *) log "runtime audit: $2 carries unknown command flag '$fw' — not systemd serialization (D13)"; return 1;;
    esac
  done
  return 0
}

exec_parse_commands() { # $1 = raw property value, $2 = label → EXEC_PATH, EXEC_ARGV, EXEC_FLAGS
  local raw=$1 label=$2 rest group field key val idx sk
  EXEC_PATH=''; EXEC_ARGV=''; EXEC_FLAGS=''
  local ngroups=0 nflags=0
  local -a seen_keys=()
  rest="$raw"
  while :; do
    rest="${rest# }"
    case "$rest" in
      '{'*) ngroups=$((ngroups + 1));;
      '') break;;
      *) log "runtime audit: $label is not structured systemd output (got '$raw') (D13)"; return 1;;
    esac
    rest="${rest:1}" # drop the confirmed leading '{'
    case "$rest" in
      *'}'*) group="${rest%%\}*}"; rest="${rest#*\}}";;
      *) log "runtime audit: $label group is not closed (got '$raw') (D13)"; return 1;;
    esac
    case "$group" in
      *'{'*) log "runtime audit: $label contains a nested group (got '$raw') (D13)"; return 1;;
    esac
    if [ "$ngroups" -gt 1 ]; then
      log "runtime audit: $label carries $ngroups commands — exactly one is allowed (D13)"
      return 1
    fi
    idx=0
    nflags=0
    seen_keys=()
    while [ -n "$group" ]; do
      field="${group%%;*}"
      if [ "$field" = "$group" ]; then group=''; else group="${group#*;}"; fi
      field="${field# }"; field="${field% }"
      [ -n "$field" ] || { log "runtime audit: $label has an empty field (got '$raw') (D13)"; return 1; }
      key="${field%%=*}"
      val="${field#*=}"
      [ "$key" != "$field" ] || { log "runtime audit: $label field '$field' has no '=' (D13)"; return 1; }
      case "$idx" in
        0) [ "$key" = "path" ] || { log "runtime audit: $label first field is '$key', want 'path' (D13)"; return 1; }
           [ -n "$val" ] || { log "runtime audit: $label has an empty path (D13)"; return 1; }
           EXEC_PATH=$val;;
        1) [ "$key" = "argv[]" ] || { log "runtime audit: $label second field is '$key', want 'argv[]' (D13)"; return 1; }
           [ -n "$val" ] || { log "runtime audit: $label has empty argv (D13)"; return 1; }
           EXEC_ARGV=$val;;
        *) case " $EXEC_KNOWN_TRAILER_KEYS " in
             *" $key "*)
               for sk in ${seen_keys[@]+"${seen_keys[@]}"}; do
                 [ "$sk" = "$key" ] && { log "runtime audit: $label repeats field '$key' — real systemd serializes each key once (D13)"; return 1; }
               done
               seen_keys+=("$key")
               if [ "$key" = "flags" ]; then
                 nflags=$((nflags + 1))
                 flags_words_ok "$val" "$label" || return 1
                 EXEC_FLAGS=$val
               fi;;
             *) log "runtime audit: $label has unknown field '$key' (D13)"; return 1;;
           esac;;
      esac
      idx=$((idx + 1))
    done
    # Exactly ONE authoritative flags witness per command: missing (plain
    # property form) and duplicated flags= fields both refuse (D21).
    [ "$nflags" = "1" ] ||
      { log "runtime audit: $label command carries $nflags flags= fields — exactly one authoritative flags witness is required (D13)"; return 1; }
    [ -n "$EXEC_PATH" ] && [ -n "$EXEC_ARGV" ] ||
      { log "runtime audit: $label group missing path=/argv[]= (D13)"; return 1; }
  done
  [ "$ngroups" -ge 1 ] ||
    { log "runtime audit: $label is empty (D13)"; return 1; }
}

# Raw unit-SOURCE privilege audit (R1 fidelity). `systemctl show` structurally
# cannot report privilege prefixes — they are consumed at load time — so the
# prefix evidence comes from the unit SOURCES systemd itself reports as
# loaded: FragmentPath (must be exactly the unit we wrote) and DropInPaths
# (each must live in the unit's own .service.d/ directory). Rules:
#   * drop-ins may not set Exec* directives at all (a drop-in ExecStartPre=+
#     is the classic root-escape; the merged property would otherwise show a
#     prefix-free command that looks exactly like ours);
#   * when the guard is active: exactly ONE ExecStartPre line across all
#     sources and it is EXACTLY 'ExecStartPre=+$HELPERS_DIR/imds-guard.sh
#     $SERVICE_USER' — the '+' in the SOURCE is what systemd turns into the
#     FULLY_PRIVILEGED flag, so this pins the privilege semantics the
#     property cannot express;
#   * when the guard is inactive: zero ExecStartPre lines anywhere;
#   * ExecStart: hardened mode requires exactly one line, value-equal to
#     'ExecStart='<the property argv> (sound because the Ex flags are
#     verified empty, i.e. no prefix was consumed and argv is verbatim);
#     legacy (rollback) mode requires every non-empty ExecStart value to head
#     with exactly $BIN_LINK — refusing '+', '-', '!', '!!', '@' and ':'
#     modifiers by construction.
#
# systemd assignment syntax (D21): whitespace around '=' is ignored and
# leading indentation is tolerated (systemd.syntax v252), so the ban and the
# byte checks parse KEY and VALUE after trimming — a drop-in
# 'ExecStopPost = ...' or a tab-indented assignment must not escape the
# literal 'ExecStopPost=*' spelling match the previous check used.
# Comments and continuations follow conf-parser.c v252 EXACTLY (the audit
# must model the parser that would run the unit, or its verdicts are wrong):
#   * a PHYSICAL line whose first non-whitespace character is '#' or ';' is
#     a comment and is skipped BEFORE any continuation processing — a
#     comment ending in a backslash absorbs NOTHING and does not affect a
#     pending continuation;
#   * continuation is decided by trailing-backslash PARITY of the
#     accumulated logical line (the v252 scan toggles `escaped` over the
#     whole text, so it is true iff the text ends in an ODD number of
#     backslashes); trailing whitespace after the backslashes therefore
#     ends a continuation. Odd parity continues: the LAST backslash becomes
#     one space and the next NON-COMMENT physical line is appended verbatim
#     (a comment seen mid-continuation is skipped without ending it);
#   * an unterminated trailing continuation REFUSES (deliberately stronger
#     than v252, which would parse the fragment — this audit fails closed on
#     syntax it cannot attribute; pinned by the contract tests).
unit_trim() { # $1 = string → surrounding whitespace trimmed on stdout
  local s=${1#"${1%%[![:space:]]*}"}
  printf '%s' "${s%"${s##*[![:space:]]}"}"
}

unit_raw_exec_ok() { # $1 = require-hardened(0|1), $2 = guard-active(0|1), $3 = ExecStart argv (prefix-free)
  local require=$1 guard=$2 exec_argv=$3 frag drops f l key val is_dropin
  local nstart=0 npre=0 li ln logical rt raw pending lhead ntails head
  local -a rawlines=()
  frag=$(systemd_prop FragmentPath)
  [ "$frag" = "$UNIT_FILE" ] ||
    { log "runtime audit: unit loaded from '$frag', want $UNIT_FILE (D13)"; return 1; }
  drops=$(systemd_prop DropInPaths)
  for f in $drops; do
    case "$f" in
      "$UNIT_DIR/$SERVICE.service.d/"*) ;;
      *) log "runtime audit: drop-in outside $UNIT_DIR/$SERVICE.service.d/: $f (D13)"; return 1;;
    esac
  done
  for f in "$frag" $drops; do
    is_dropin=0
    case "$f" in "$UNIT_DIR/$SERVICE.service.d/"*) is_dropin=1;; esac
    rawlines=()
    while IFS= read -r l || [ -n "$l" ]; do rawlines+=("$l"); done <"$f"
    li=0
    ln=${#rawlines[@]}
    pending=''
    while [ "$li" -lt "$ln" ]; do
      raw=${rawlines[$li]}
      li=$((li + 1))
      # Physical comments FIRST (conf-parser.c v252 skips them before any
      # continuation processing): a comment's trailing backslash absorbs
      # nothing, and a comment mid-continuation neither ends nor joins it.
      lhead=${raw#"${raw%%[![:space:]]*}"}
      case "$lhead" in
        '#'*|';'*) continue;;
      esac
      if [ -n "$pending" ]; then logical="$pending$raw"; else logical=$raw; fi
      # trailing-backslash parity over the ACCUMULATED raw text (no right
      # trim — trailing whitespace ends a continuation, as in v252).
      ntails=0
      rt=$logical
      while :; do
        case "$rt" in
          *\\) ntails=$((ntails + 1)); rt=${rt%\\};;
          *) break;;
        esac
      done
      if [ $((ntails % 2)) = 1 ]; then
        # Odd parity: continue — the last backslash becomes ONE space and
        # the next non-comment physical line is appended verbatim.
        [ "$li" -lt "$ln" ] ||
          { log "runtime audit: $f ends in an unterminated continuation — refusing (D13)"; return 1; }
        pending="${logical%\\} "
        continue
      fi
      pending=''
      logical=${logical#"${logical%%[![:space:]]*}"} # systemd tolerates indentation
      case "$logical" in
        '') continue;; # blank line
      esac
      case "$logical" in
        *=*) key=$(unit_trim "${logical%%=*}"); val=${logical#*=};;
        *) continue;; # section headers carry no '='
      esac
      case "$key" in
        ExecStart|ExecStartPre|ExecStartPost|ExecStop|ExecStopPost|ExecCondition)
          if [ "$is_dropin" = 1 ]; then
            log "runtime audit: drop-in $f sets Exec* directives ($key) — refusing (D13)"
            return 1
          fi;;
        *) continue;;
      esac
      val=${val#"${val%%[![:space:]]*}"} # systemd ignores whitespace after '='
      case "$key" in
        'ExecStartPre')
          npre=$((npre + 1))
          [ "$val" = "+$HELPERS_DIR/imds-guard.sh $SERVICE_USER" ] ||
            { log "runtime audit: ExecStartPre value is '$val', want 'ExecStartPre=+$HELPERS_DIR/imds-guard.sh $SERVICE_USER' (D13)"; return 1; }
          ;;
        'ExecStart')
          nstart=$((nstart + 1))
          if [ "$require" = 1 ]; then
            [ "$val" = "$exec_argv" ] ||
              { log "runtime audit: ExecStart value is '$val', want 'ExecStart=$exec_argv' (D13)"; return 1; }
          else
            head=${val%% *}
            [ "$head" = "$BIN_LINK" ] ||
              { log "runtime audit: ExecStart head is '$head', want '$BIN_LINK' with no systemd privilege modifier (D13)"; return 1; }
          fi
          ;;
      esac
    done
  done
  if [ "$guard" = 1 ]; then
    [ "$npre" = 1 ] || { log "runtime audit: want exactly one ExecStartPre guard line, found $npre (D13)"; return 1; }
  else
    [ "$npre" = 0 ] || { log "runtime audit: ExecStartPre lines present but the guard is not active (D13)"; return 1; }
  fi
  if [ "$require" = 1 ]; then
    [ "$nstart" = 1 ] || { log "runtime audit: want exactly one ExecStart line, found $nstart (D13)"; return 1; }
  fi
  return 0
}

# Root is permitted only for the positively captured, byte-identically restored
# original legacy configuration inside do_rollback. require=0 alone grants none.
legacy_root_rollback_bound() { # $1 = restored MainPID
  local rb_user rb_group
  [ "${restored_legacy_root:-0}" = 1 ] && [ "${rollback_done:-0}" = 1 ] &&
    [ "${unit_installed:-0}" = 1 ] || return 1
  [ -z "${current_release:-}" ] && [ -z "${current_sha:-}" ] &&
    [ "${current_activation:-0}" = 0 ] || return 1
  [ -n "${legacy_original_unit_sha:-}" ] && [ -n "${legacy_original_binary_sha:-}" ] &&
    [ -n "${legacy_original_target:-}" ] || return 1
  [ "$(sha_of "$UNIT_FILE")" = "$legacy_original_unit_sha" ] &&
    [ "$(sha_of "$unit_backup")" = "$legacy_original_unit_sha" ] || return 1
  [ "$(readlink -f "$BIN_LINK")" = "$legacy_original_target" ] &&
    [ "$(sha_of "$legacy_original_target")" = "$legacy_original_binary_sha" ] || return 1
  [ "$(readlink -f "$(running_exe "$1")")" = "$legacy_original_target" ] || return 1
  rb_user=$(systemd_prop User) || return 1
  rb_group=$(systemd_prop Group) || return 1
  [ -z "$rb_user" ] && [ -z "$rb_group" ] || return 1
}

runtime_credentials_ok() { # $1 = MainPID, $2 = require-hardened(0|1)
  local pid=$1 require=$2 st f v ipd pre tok hardened=0
  local u1 u2 u3 u4 g1 g2 g3 g4 first_tok
  local svc_uid svc_gid expected_uid expected_gid
  svc_uid=$("$ID_BIN" -u "$SERVICE_USER" 2>/dev/null) || { log "runtime audit: cannot resolve uid"; return 1; }
  svc_gid=$("$ID_BIN" -g "$SERVICE_USER" 2>/dev/null) || { log "runtime audit: cannot resolve gid"; return 1; }
  [ "$svc_uid" != "0" ] || { log "runtime audit: service uid is 0 (D13)"; return 1; }
  expected_uid=$svc_uid; expected_gid=$svc_gid
  if [ "$require" = 0 ] && legacy_root_rollback_bound "$pid"; then
    expected_uid=0; expected_gid=0
  fi

  st=$(proc_status "$pid") || { log "runtime audit: no /proc/$pid/status"; return 1; }
  # effective UID/GID of the live process — the drop-in/property audit below
  # is worthless if the kernel says the process is something else.
  read -r u1 u2 u3 u4 extra <<<"$(printf '%s\n' "$st" | awk '$1 == "Uid:" {print $2, $3, $4, $5}')"
  if [ -z "$u4" ] || [ -n "$extra" ]; then
    log "runtime audit: bad Uid record"
    return 1
  fi
  for f in "$u1" "$u2" "$u3" "$u4"; do
    [ "$f" = "$expected_uid" ] || { log "runtime audit: process uid '$f' != expected uid '$expected_uid' (D13)"; return 1; }
  done
  read -r g1 g2 g3 g4 extra <<<"$(printf '%s\n' "$st" | awk '$1 == "Gid:" {print $2, $3, $4, $5}')"
  if [ -z "$g4" ] || [ -n "$extra" ]; then
    log "runtime audit: bad Gid record"
    return 1
  fi
  for f in "$g1" "$g2" "$g3" "$g4"; do
    [ "$f" = "$expected_gid" ] || { log "runtime audit: process gid '$f' != expected gid '$expected_gid' (D13)"; return 1; }
  done

  # Effective unit identity: "" (legacy, rollback-only) / SERVICE_USER / refuse.
  v=$(systemd_prop User)
  if [ -z "$v" ]; then
    if [ "$require" = "1" ]; then
      log "runtime audit: unit has no User= but this is a new deploy (D13)"
      return 1
    fi
  elif [ "$v" != "$SERVICE_USER" ]; then
    log "runtime audit: effective User='$v' (want '$SERVICE_USER' or empty) (D13)"
    return 1
  else
    hardened=1
  fi

  if [ "$hardened" = "1" ]; then
    # Hardened unit: verify every D13 directive as systemd will apply it.
    [ "$(systemd_prop Group)" = "$SERVICE_USER" ] || { log "runtime audit: Group not $SERVICE_USER (D13)"; return 1; }
    [ "$(systemd_prop NoNewPrivileges)" = "yes" ] || { log "runtime audit: NoNewPrivileges not yes (D13)"; return 1; }
    [ "$(systemd_prop ProtectSystem)" = "strict" ] || { log "runtime audit: ProtectSystem not strict (D13)"; return 1; }
    [ "$(systemd_prop PrivateTmp)" = "yes" ] || { log "runtime audit: PrivateTmp not yes (D13)"; return 1; }
    # Capability sets are rendered lowercase by real systemd (see
    # prop_caps_exactly_bind): compare as a set, exactly one capability.
    for f in CapabilityBoundingSet AmbientCapabilities; do
      v=$(systemd_prop "$f")
      prop_caps_exactly_bind "$v" ||
        { log "runtime audit: $f is '$v', not exactly CAP_NET_BIND_SERVICE (D13)"; return 1; }
    done
    [ -z "$(systemd_prop SupplementaryGroups)" ] || { log "runtime audit: SupplementaryGroups not empty (D13)"; return 1; }
    # Kernel truth for the caps we configured: bounding + ambient must be
    # EXACTLY CAP_NET_BIND_SERVICE; inheritable/permitted/effective may only
    # be a subset (the app may drop the capability after listen — dropping
    # is fine, gaining others is not).
    for f in CapBnd CapAmb; do
      tok=$(cap_field "$st" "$f") || { log "runtime audit: missing $f"; return 1; }
      mask_is_bind "$tok" || { log "runtime audit: $f=$tok is not exactly CAP_NET_BIND_SERVICE (D13)"; return 1; }
    done
    for f in CapInh CapPrm CapEff; do
      tok=$(cap_field "$st" "$f") || { log "runtime audit: missing $f"; return 1; }
      mask_has_only_bind "$tok" || { log "runtime audit: $f=$tok grants capabilities beyond CAP_NET_BIND_SERVICE (D13)"; return 1; }
    done
  fi

  # Writable paths: every listed entry must be on the whitelist (drop-ins
  # included). A hardened unit must list the whitelist; a legacy (restored)
  # unit may legitimately list nothing — but must never list anything else.
  # The whitelist is EXACTLY the two canonical leaves — the certs cache
  # directory and the registry directory — never their root-owned parent.
  v=$(systemd_prop ReadWritePaths)
  if [ "$hardened" = "1" ]; then
    [ -n "$v" ] || { log "runtime audit: ReadWritePaths empty (D13)"; return 1; }
  fi
  for tok in $v; do
    case "$tok" in
      "$CERT_DATA_DIR"|"$REGISTRY_DIR") ;;
      "$CERT_CACHE"|"$CERT_CACHE"/)
        log "runtime audit: ReadWritePaths contains the root-only ancestor '$tok' — canonical layout violated"; return 1;;
      *) log "runtime audit: ReadWritePaths contains non-whitelisted '$tok' (D13)"; return 1;;
    esac
  done

  # IMDS posture: any ExecStartPre other than the uid-guard is refused in
  # BOTH modes (it runs as root when '+'-prefixed). A hardened unit must
  # additionally show exactly one working strategy: IPAddressDeny covering
  # both endpoints (and no guard), or the uid-guard (and a reset
  # IPAddressDeny). A legacy (restored) unit may have neither.
  #
  # R1 fidelity: the effective property comes from ExecStartPreEx — REAL
  # systemd consumes the '+' into FULLY_PRIVILEGED before building the
  # command, so plain ExecStartPre/ExecStartPreEx report a PREFIX-FREE
  # path/argv and the '+', if present, appears ONLY as flags=privileged.
  # Expecting '+...' inside the property (the pre-fix behavior) can never
  # match a real system. The prefix evidence itself is pinned by the raw
  # unit-source audit (unit_raw_exec_ok) below — property and source must
  # agree or the audit refuses.
  local want_guard_argv="$HELPERS_DIR/imds-guard.sh $SERVICE_USER"
  local guard_active=0
  ipd=$(systemd_prop IPAddressDeny)
  pre=$(systemd_prop ExecStartPreEx)
  if [ -n "$pre" ]; then
    exec_parse_commands "$pre" ExecStartPreEx || return 1
    [ "$EXEC_PATH" = "$HELPERS_DIR/imds-guard.sh" ] ||
      { log "runtime audit: unexpected ExecStartPre path '$EXEC_PATH' (D13)"; return 1; }
    [ "$EXEC_ARGV" = "$want_guard_argv" ] ||
      { log "runtime audit: unexpected ExecStartPre argv '$EXEC_ARGV' (D13)"; return 1; }
    # The guard MUST be fully privileged: exactly the '+' flag, nothing else
    # (a combined 'ignore-failure privileged' or a bare command refuses).
    [ "$EXEC_FLAGS" = "privileged" ] ||
      { log "runtime audit: ExecStartPre guard carries no '+' full-privilege flag (flags='${EXEC_FLAGS:-none}') (D13)"; return 1; }
    guard_active=1
  fi
  if [ "$hardened" = "1" ]; then
    if [ "$guard_active" = "0" ]; then
      # Real systemd renders CIDR host prefixes (…/32, …/128): see prop_ipdeny_has.
      prop_ipdeny_has "$ipd" "$IMDS_V4" 32 ||
        { log "runtime audit: IPAddressDeny '$ipd' missing $IMDS_V4 (D13)"; return 1; }
      prop_ipdeny_has "$ipd" "$IMDS_V6" 128 ||
        { log "runtime audit: IPAddressDeny '$ipd' missing $IMDS_V6 (D13)"; return 1; }
    else
      [ -z "$ipd" ] || { log "runtime audit: uid-guard AND IPAddressDeny both set (D13)"; return 1; }
    fi
  fi

  # Effective ExecStart (flags-aware, R1): exactly one command whose path
  # AND argv[] head are the bin link and whose flags are EMPTY — i.e. no
  # systemd modifier (+ - ! !! @ :) was consumed from the command ('@' also
  # shows up as an argv[] head different from the path, refused by the exact
  # head equality). The raw source audit below pins the unit text itself.
  v=$(systemd_prop ExecStartEx)
  [ -n "$v" ] || { log "runtime audit: empty ExecStartEx (D13)"; return 1; }
  exec_parse_commands "$v" ExecStartEx || return 1
  [ "$EXEC_PATH" = "$BIN_LINK" ] ||
    { log "runtime audit: ExecStart path is '$EXEC_PATH', want '$BIN_LINK' (D13)"; return 1; }
  first_tok=${EXEC_ARGV%% *} # first whitespace-separated token (whole argv if none)
  [ -n "$first_tok" ] || { log "runtime audit: empty ExecStart argv (D13)"; return 1; }
  case "$first_tok" in
    "$BIN_LINK") ;;
    *) log "runtime audit: ExecStart binary is '$first_tok', want '$BIN_LINK' (D13)"; return 1;;
  esac
  [ -z "$EXEC_FLAGS" ] ||
    { log "runtime audit: ExecStart carries systemd privilege/behavior flags '$EXEC_FLAGS' — refusing (D13)"; return 1; }

  # Raw-source privilege audit: the unit text systemd says it loaded must
  # carry the exact commands the property claims — with the '+' physically
  # present on the guard line and absent everywhere else.
  unit_raw_exec_ok "$require" "$guard_active" "$EXEC_ARGV" || return 1

  # Activation contract on the RUNNING unit's argv: exactly one -certdir
  # (the canonical base — the binary stores its cache under <certdir>/certs)
  # and exactly one -registry pointing at the registry FILE, plus the
  # preserved nonempty -allow allowlist. Without this check a deploy whose
  # binary reports the right version/commit could still have never mounted
  # the identity/tunnel API (the activation blocker this contract closes).
  if [ "$require" = "1" ]; then
    local atok ncertdir=0 nregistry=0 nallow=0 acertdir='' aregistry='' aallow='' aprev=''
    for atok in $EXEC_ARGV; do
      case "$aprev" in
        -certdir) acertdir=$atok;;
        -registry) aregistry=$atok;;
        -allow) aallow=$atok;;
      esac
      case "$atok" in
        -certdir) ncertdir=$((ncertdir + 1));;
        -registry) nregistry=$((nregistry + 1));;
        -allow) nallow=$((nallow + 1));;
      esac
      aprev=$atok
    done
    { [ "$ncertdir" = "1" ] && [ "$acertdir" = "$CERT_CACHE" ]; } ||
      { log "runtime audit: ExecStart must carry exactly one -certdir $CERT_CACHE (activation; got '$acertdir' x$ncertdir)"; return 1; }
    { [ "$nregistry" = "1" ] && [ "$aregistry" = "$REGISTRY_FILE" ]; } ||
      { log "runtime audit: ExecStart must carry exactly one -registry $REGISTRY_FILE (activation; got '$aregistry' x$nregistry)"; return 1; }
    { [ "$nallow" = "1" ] && [ -n "$aallow" ]; } ||
      { log "runtime audit: ExecStart must preserve a nonempty -allow allowlist (activation)"; return 1; }
  fi

  # Drop-in files: an overriding drop-in is the classic root-escalation path
  # (ExecStartPre=+… runs as root). Their effective CONTENT is audited via
  # the properties above; here we refuse drop-ins the service user could
  # have written or owns. In legacy-rollback mode lax write bits are only
  # logged (fail-closed on content still applies).
  local dd="$UNIT_DIR/$SERVICE.service.d" dmode downer
  if [ -d "$dd" ]; then
    for f in "$dd"/*; do
      [ -e "$f" ] || continue
      read -r downer dmode <<<"$($STAT_BIN -c '%U %a' "$f" 2>/dev/null)" || { log "runtime audit: cannot stat drop-in $f"; return 1; }
      if [ "$downer" != "$TRUST_OWNER" ]; then
        log "runtime audit: drop-in $f owned by '$downer' — refusing (D13)"
        return 1
      fi
      if [ $((8#$dmode & 8#22)) -ne 0 ]; then
        if [ "$require" = "1" ] || [ "$hardened" = "1" ]; then
          log "runtime audit: drop-in $f group/world-writable ($dmode) — refusing (D13)"
          return 1
        fi
        log "runtime audit: WARNING drop-in $f group/world-writable ($dmode) — content still enforced"
      fi
    done
  fi
  return 0
}

health_ok() { # $1 = binary sha, $2 = release bin, $3 = require-healthz(0|1),
  # $4 = expect-version, $5 = expect-revision, $6 = want-activation(0|1),
  # then DNS names...
  local binary_sha=$1 release_bin=$2 require_hz=$3 want_version=$4 want_rev=$5 want_act=$6
  shift 6
  "$SYSTEMCTL" is-active --quiet "$SERVICE" || return 1
  local pid exe
  pid=$("$SYSTEMCTL" show -p MainPID --value "$SERVICE")
  [ -n "$pid" ] && [ "$pid" != "0" ] || return 1
  exe=$(running_exe "$pid") || return 1
  [ -n "$exe" ] || return 1
  [ "$exe" = "$(readlink -f "$release_bin")" ] || { log "running exe is '$exe', want '$release_bin'"; return 1; }
  [ "$(sha_of "$exe")" = "$binary_sha" ] || { log "running exe hash mismatch (want binary sha $binary_sha)"; return 1; }
  runtime_credentials_ok "$pid" "$require_hz" || return 1
  local name
  for name in "$@"; do
    endpoint_ok "$name" || return 1
    HEALTHZ_RESULT=legacy
    healthz_check "$name" "$want_version" "$want_rev" "$require_hz" "$want_act" || return 1
  done
  return 0
}

# Activation proof beyond the posture fields: the new API's routes must not
# merely exist in the binary but be MOUNTED on the serving mux, and they
# must fail CLOSED for anonymous requests. 401 on the identity route and
# 426 (websocket-only) on the client-ssh route prove exactly that; 404
# means the API object was never wired (the activation blocker), 2xx/000
# means the endpoint is wrong or absent. Runs only on NEW deploys.
ACTIVATION_PROBE_DEVICE=psh-activation-probe-0001
activation_routes_ok() { # $1 = DNS name (canonical)
  local name=$1 code
  code=$("$CURL_BIN" -sS -o /dev/null -w '%{http_code}' --resolve "$name:443:127.0.0.1" --max-time 5 "https://$1/identity/v1/devices" 2>/dev/null || true)
  [ "$code" = "401" ] || { log "activation: anonymous /identity/v1/devices answered '${code:-none}' (want 401 auth rejection; 404 = routes never mounted) — refusing"; return 1; }
  code=$("$CURL_BIN" -sS -o /dev/null -w '%{http_code}' --resolve "$name:443:127.0.0.1" --max-time 5 "https://$1/api/v1/hosts/$ACTIVATION_PROBE_DEVICE/ssh" 2>/dev/null || true)
  [ "$code" = "426" ] || { log "activation: anonymous client-ssh route answered '${code:-none}' (want 426 websocket-only; 404 = tunnel never mounted) — refusing"; return 1; }
  log "activation routes verified: identity 401 (auth rejection), tunnel 426 (upgrade required)"
  return 0
}

# --- overridable hooks (harness overrides these; production = real checks) --
# Walks a directory tree through STAT_BIN (single DAC seam) and returns 1 if
# any entry is owned by someone else or is group/world-writable. Remaining
# arguments are optional prune paths (subtrees skipped entirely) — used for
# the designed service-owned leaves inside a root-owned parent.
tree_has_violation() { # $1 = dir, $2 = expected owner, $3... = prune paths
  local dir=$1 want_owner=$2 item iowner imode pr skip
  shift 2
  for item in "$dir"/* "$dir"/.[!.]* "$dir"/..?*; do
    [ -e "$item" ] || continue
    skip=0
    for pr in "$@"; do
      [ -n "$pr" ] && [ "$item" = "$pr" ] && { skip=1; break; }
    done
    [ "$skip" = "0" ] || continue
    read -r iowner imode <<<"$($STAT_BIN -c '%U %a' "$item" 2>/dev/null)" || { log "DAC audit: cannot stat $item"; return 1; }
    [ "$iowner" = "$want_owner" ] || { log "DAC audit: $item owned by '$iowner', want '$want_owner' (D13)"; return 1; }
    [ $((8#$imode & 8#22)) -eq 0 ] || { log "DAC audit: $item mode $imode group/world-writable (D13)"; return 1; }
    if [ -d "$item" ] && [ ! -L "$item" ]; then
      tree_has_violation "$item" "$want_owner" "$@" || return 1
    fi
  done
  return 0
}

ensure_service_user() { # idempotent no-login system user, D13
  local uid primary g bad
  if ! "$GETENT_BIN" passwd "$SERVICE_USER" >/dev/null 2>&1; then
    "$GROUPADD_BIN" --system "$SERVICE_USER" 2>/dev/null || true
    "$USERADD_BIN" --system --no-create-home --shell /usr/sbin/nologin \
      --gid "$SERVICE_USER" "$SERVICE_USER" || die "cannot allocate service user $SERVICE_USER"
    log "allocated service user: $SERVICE_USER (no-login system account)"
  fi
  # Harden/verify regardless of whether it just got created.
  uid=$("$ID_BIN" -u "$SERVICE_USER") || die "cannot resolve uid of $SERVICE_USER"
  [ "$uid" != "0" ] || die "service user $SERVICE_USER has UID 0 — refusing (D13)"
  local shell
  shell=$("$GETENT_BIN" passwd "$SERVICE_USER" | cut -d: -f7)
  case "$shell" in
    /usr/sbin/nologin|/sbin/nologin|/bin/false) :;;
    *) "$USERMOD_BIN" --shell /usr/sbin/nologin "$SERVICE_USER" ||
      die "cannot force no-login shell for $SERVICE_USER";;
  esac
  # Exact minimal group set: primary group is its own group and there are NO
  # supplementary groups at all — privilege comes solely from the unit's
  # CAP_NET_BIND_SERVICE, never from group membership.
  primary=$("$ID_BIN" -gn "$SERVICE_USER") || die "cannot resolve primary group of $SERVICE_USER"
  [ "$primary" = "$SERVICE_USER" ] || die "service user primary group is '$primary', want '$SERVICE_USER' (D13)"
  bad=''
  for g in $("$ID_BIN" -nG "$SERVICE_USER"); do
    [ "$g" = "$SERVICE_USER" ] && continue
    bad="$bad $g"
  done
  [ -z "$bad" ] || die "service user must have NO supplementary groups; has:$bad (D13)"
  for g in $DANGEROUS_GROUPS; do
    if "$ID_BIN" -nG "$SERVICE_USER" 2>/dev/null | tr ' ' '\n' | grep -qx "$g"; then
      die "service user must not be in privileged group: $g (D13)"
    fi
  done
}

# --- D23 runtime-writable leaf authority boundary -----------------------------
# The runtime leaves (certs cache directory, registry directory, registry
# file) are OWNED and WRITABLE by the service account by design. A root
# pathname operation (chown/chmod/open-for-read) on anything inside a
# service-writable directory races the service: between any check and any
# use, a service-side writer can replace the pathname (symlink, hardlink,
# rename), and the privileged operation would then land on the object the
# service chose. The migration therefore never path-mutates leaf content
# blindly:
#   * read-only lstat decisions are the ONLY pathname preflight;
#   * the certdir BASE is reclaimed to root BEFORE any child is examined or
#     created — the base entry lives in an audited root-owned parent, so the
#     service cannot replace the base pathname itself, and once it is
#     root-owned the service can no longer swap the certs/registry entries
#     either (a running service keeps already-open fds; nothing here relies
#     on quiescence, KillMode or MainPID exit);
#   * root ownership is NOT treated as write authority: before root walks,
#     opens for use, or adopts anything inside a root-owned legacy directory
#     (the certs leaf, a nested legacy directory, the registry directory),
#     that directory is proven NOT service-writable — mode-bit math PLUS an
#     effective write probe executed as the service user (access(3)
#     semantics, so a POSIX access ACL that mode bits cannot express still
#     refuses). A writable root-owned legacy directory refuses BEFORE any
#     child is touched — it is never normalized after its children have
#     been mutated, and the parent/base probes are what freeze entry names
#     for the privileged opens below (the stable-parent invariant);
#   * alignment inside the service's own authority (runuser chown/chmod as
#     the service user) can only ever succeed on objects the service already
#     owns — a raced replacement is acted on, at most, within the service's
#     own power;
#   * the unavoidable privileged changes (base reclaim, legacy-cache
#     adoption) are bound to an OPENED, VERIFIED inode: open the path,
#     fstat through /proc/$BASHPID/fd and compare the full record — type,
#     DEVICE, inode, nlink, mode, owner, group — against the preflight
#     lstat, then chown/chmod the /proc fd path so the change lands on that
#     exact inode no matter what the pathname does later;
#   * legacy content adoption follows an explicit policy: regular files and
#     directories only, owner admin-or-service, group admin-or-service,
#     nlink==1 for files (aliasing is REFUSED, never normalized), depth-
#     bounded, byte-preserving — anything else fails closed. The REGISTRY
#     subtree is deliberately OUTSIDE this policy: its directory is moved
#     without walking its contents, and the registry FILE's original
#     type/link/owner/size evidence is validated before anything could
#     normalize it (migrate_registry_dir);
#   * already-correct state is left untouched (no recursive chown on
#     redeploy, no root read of runtime content — the preserved-registry log
#     size comes from inode metadata, never from opening the file).
# $BASHPID (not $$): the fd belongs to the current shell process; inside a
# sourced/subshelled invocation $$ can point at a different process.

lstat_record() { # $1 = path, $2 = label → LSTAT_TYPE|DEV|INODE|NLINK|MODE|OWNER|GID
  local out
  out=$("$STAT_BIN" -c '%F|%d|%i|%h|%a|%U|%g' "$1" 2>/dev/null) ||
    die "cannot stat $2: $1 (D13/D23)"
  LSTAT_TYPE=${out%%|*}; out=${out#*|}
  [ "$LSTAT_TYPE" = "regular empty file" ] && LSTAT_TYPE="regular file" # GNU %F spelling for size 0
  LSTAT_DEV=${out%%|*}; out=${out#*|}
  LSTAT_INODE=${out%%|*}; out=${out#*|}
  LSTAT_NLINK=${out%%|*}; out=${out#*|}
  LSTAT_MODE=${out%%|*}; out=${out#*|}
  LSTAT_OWNER=${out%%|*}
  LSTAT_GID=${out#*|}
}

fd_record() { # $1 = fd number, $2 = label → fstat of the OPENED inode (same record)
  local out
  out=$("$STAT_BIN" -Lc '%F|%d|%i|%h|%a|%U|%g' "/proc/$BASHPID/fd/$1" 2>/dev/null) ||
    die "cannot fstat the opened descriptor for $2 (D23 — is /proc mounted?)"
  FD_TYPE=${out%%|*}; out=${out#*|}
  [ "$FD_TYPE" = "regular empty file" ] && FD_TYPE="regular file" # GNU %F spelling for size 0
  FD_DEV=${out%%|*}; out=${out#*|}
  FD_INODE=${out%%|*}; out=${out#*|}
  FD_NLINK=${out%%|*}; out=${out#*|}
  FD_MODE=${out%%|*}; out=${out#*|}
  FD_OWNER=${out%%|*}
  FD_GID=${out#*|}
}

open_checked() { # $1 = path lstat_record'ed by the caller, $2 = label → OPFD
  local p=$1 label=$2
  # Stable-parent invariant (D23): this open is only issued while the ENTRY's
  # immediate parent directory is root-owned and proven NOT writable by the
  # service (mode bits AND an effective access probe as the service user —
  # dir_not_service_writable at every call site's parent). The service can
  # therefore neither replace this name nor plant a FIFO for the open to
  # block on between the caller's lstat and this open; nofollow/nonblocking
  # open flags are not available to a plain shell read-open, so the invariant
  # is the replacement-safety proof for this open. The full identity
  # comparison below (type/DEV/inode/nlink/mode/owner/group) is the second
  # net, and every descriptor-bound mutation afterwards is issued through
  # /proc/$BASHPID/fd so it lands on THIS opened inode regardless of what any
  # pathname does later.
  # NOTE: a redirection on `exec` PERSISTS for the whole shell, so the error
  # suppression must live on a transient group — `exec {fd}<p 2>/dev/null`
  # would silently black-hole stderr (every later die included) for the rest
  # of the deploy.
  { exec {opfd_n}<"$p"; } 2>/dev/null || die "cannot open checked descriptor for $label: $p (D23)"
  fd_record "$opfd_n" "$label"
  if [ "$LSTAT_TYPE" != "$FD_TYPE" ] || [ "$LSTAT_DEV" != "$FD_DEV" ] ||
    [ "$LSTAT_INODE" != "$FD_INODE" ] || [ "$LSTAT_NLINK" != "$FD_NLINK" ] ||
    [ "$LSTAT_MODE" != "$FD_MODE" ] || [ "$LSTAT_OWNER" != "$FD_OWNER" ] ||
    [ "$LSTAT_GID" != "$FD_GID" ]; then
    { exec {opfd_n}<&-; } 2>/dev/null || true
    die "path replaced between check and open: $label ($p) — refusing (D23)"
  fi
  OPFD=$opfd_n
}

close_fd() { { exec {opfd_n}<&-; } 2>/dev/null || true; }

fd_chown() { # $1 = fd, $2 = owner:group spec, $3 = label — through the opened inode
  "$CHOWN_BIN" "$2" "/proc/$BASHPID/fd/$1" 2>/dev/null ||
    die "descriptor-bound chown failed for $3 (D23)"
}

fd_chmod() { # $1 = fd, $2 = mode, $3 = label — through the opened inode
  "$CHMOD_BIN" "$2" "/proc/$BASHPID/fd/$1" 2>/dev/null ||
    die "descriptor-bound chmod failed for $3 (D23)"
}

stat_size() { # $1 = path — inode metadata only; NEVER a content read
  "$STAT_BIN" -c '%s' "$1" 2>/dev/null || die "cannot stat size of $1 (D23)"
}

# D23 authority proof for legacy descent: ROOT OWNERSHIP ALONE does not make
# a directory unwritable to the service. Group/world write bits, or a POSIX
# access ACL that grants the service account (or one of its classes) write
# access invisible to the mode bits, let a same-UID writer create/unlink/
# rename entries INSIDE the directory — which is exactly the replacement
# primitive the descriptor binding cannot cover (it pins the DIRECTORY's
# inode, not its entry names). Before root walks, opens for use, or adopts
# anything inside a root-owned legacy directory, that directory must be
# proven NOT service-writable: first by mode-bit math, then by an EFFECTIVE
# write probe executed AS the service user (kernel access(3) semantics —
# this sees ACLs that owner/mode math cannot). A writable root-owned legacy
# directory is REFUSED (conservative fail-closed) — never normalized after
# its children have been touched. The probe also models every OTHER process
# running with the service UID: if any of them could write here, root
# refuses to descend.
service_write_witness() { # $1 = path; exact protected|writable output, error otherwise
  local d=$1 witness probe_uid
  probe_uid=$("$ID_BIN" -u "$SERVICE_USER" 2>/dev/null) ||
    return 1
  # A nonzero runuser result can mean launch failure, not protected access.
  # Require an exact witness from a successfully executed service-uid shell.
  witness=$("$RUNUSER_BIN" -u "$SERVICE_USER" -- /bin/sh -c '
    uid=$(/usr/bin/id -u) || exit 3
    [ "$uid" = "$2" ] || exit 3
    if [ -w "$1" ]; then printf "%s\n" writable; else printf "%s\n" protected; fi
  ' gateway-authority-probe "$d" "$probe_uid" 2>/dev/null) ||
    return 1
  case "$witness" in
    protected|writable) printf '%s\n' "$witness";;
    *) return 1;;
  esac
}

dir_not_service_writable() { # $1 = directory, $2 = label
  local d=$1 label=$2 mode witness
  mode=$("$STAT_BIN" -c '%a' "$d" 2>/dev/null) ||
    die "cannot stat mode of $label: $d (D23)"
  if [ $((8#$mode & (8#20 | 8#2))) -ne 0 ]; then
    die "$label is root-owned but group/world-writable (mode $mode): $d — legacy write authority refused before descent (D23)"
  fi
  witness=$(service_write_witness "$d") ||
    die "invalid service uid authority probe witness for $label: $d (D23)"
  case "$witness" in
    protected) ;;
    writable) die "$label is effectively writable by $SERVICE_USER (access ACL or mode): $d — legacy write authority refused before descent (D23)";;
    *) die "invalid service uid authority probe witness for $label: $d (D23)";;
  esac
}

adopt_tree() { # $1 = root-owned dir whose entries are adopted to the service, $2 = label, $3 = depth
  local d=$1 label=$2 depth=$3 item
  service_gid || die "cannot resolve the service group for $label adoption (D23)"
  [ "$depth" -le 4 ] || die "$label: unexpected directory depth — refusing (D23)"
  for item in "$d"/* "$d"/.[!.]* "$d"/..?*; do
    [ -e "$item" ] || continue
    lstat_record "$item" "$label entry"
    case "$LSTAT_TYPE" in
      "regular file"|"directory") : ;;
      *) die "$label: unexpected object type '$LSTAT_TYPE': $item — refusing (D23)";;
    esac
    case " $LSTAT_OWNER " in
      " $TRUST_OWNER "|" $SERVICE_USER ") : ;;
      *) die "$label: entry owned by '$LSTAT_OWNER': $item — refusing (D23)";;
    esac
    case " $LSTAT_GID " in
      " $TRUST_GROUP_ID "|" $SERVICE_GID ") : ;;
      *) die "$label: entry group '$LSTAT_GID' is neither the admin nor the service group: $item — refusing (D23)";;
    esac
    if [ "$LSTAT_TYPE" = "regular file" ]; then
      # Explicit legacy-content policy: a hardlinked file aliases another
      # name for the same inode — adopting it would change metadata through
      # every alias, so it refuses instead of normalizing (D23).
      [ "$LSTAT_NLINK" = "1" ] ||
        die "$label: hardlinked entry (nlink=$LSTAT_NLINK) refused by the legacy-content policy: $item (D23)"
    fi
    if [ "$LSTAT_TYPE" = "directory" ]; then
      # A service-owned subdirectory is the service's own domain: its
      # contents are NOT walked or normalized by root (final DAC audit still
      # refuses anomalies). Root-owned subdirs are descended FIRST (children
      # before the dir itself is adopted, so every walk happens while the
      # parent is still root-owned and unwritable by the service) — and the
      # subdir's own NOT-SERVICE-WRITABLE authority (mode bits + effective
      # ACL probe) is proven BEFORE any of its entries are examined (D23):
      # root ownership alone would not freeze its entry names.
      if [ "$LSTAT_OWNER" = "$TRUST_OWNER" ]; then
        dir_not_service_writable "$item" "$label"
        adopt_tree "$item" "$label" $((depth + 1))
        lstat_record "$item" "$label entry" # the recursion clobbers the record globals
      else
        continue
      fi
    fi
    if [ "$LSTAT_OWNER" != "$SERVICE_USER" ] || [ "$LSTAT_GID" != "$SERVICE_GID" ] ||
      { [ "$LSTAT_TYPE" = "regular file" ] && [ "$LSTAT_MODE" != "600" ]; } ||
      { [ "$LSTAT_TYPE" = "directory" ] && [ "$LSTAT_MODE" != "700" ]; }; then
      open_checked "$item" "$label entry"
      fd_chown "$OPFD" "$SERVICE_USER:$SERVICE_USER" "$item"
      if [ "$LSTAT_TYPE" = "directory" ]; then
        fd_chmod "$OPFD" 0700 "$item"
      else
        fd_chmod "$OPFD" 0600 "$item"
      fi
      close_fd
    fi
  done
}

migrate_leaf_dir() { # $1 = leaf dir (certs cache / registry), $2 = label
  local d=$1 label=$2
  lstat_record "$d" "$label"
  [ "$LSTAT_TYPE" = "directory" ] || die "$label is not a directory: $d (D13)"
  if [ "$LSTAT_OWNER" = "$SERVICE_USER" ]; then
    service_gid || die "cannot resolve service group for $label (D23)"
    if [ "$LSTAT_GID" != "$SERVICE_GID" ] || [ "$LSTAT_MODE" != "700" ]; then
      # Alignment within the service's OWN authority: runuser chown/chmod
      # succeeds only on objects the service already owns (EPERM otherwise),
      # so even a raced pathname replacement stays inside the service's own
      # power — root authority never touches the leaf here (D23).
      "$RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHOWN_BIN" "$SERVICE_USER:$SERVICE_USER" "$d" 2>/dev/null ||
        die "$label is service-owned with group '$LSTAT_GID' (want $SERVICE_GID) and the service cannot realign it — refusing (D23)"
      "$RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHMOD_BIN" 0700 "$d" 2>/dev/null ||
        die "cannot realign the $label mode as the service user — refusing (D23)"
    fi
    # Correct (or now-correct) service leaf: contents are the service's own
    # domain — NO root walk, NO root chown, NO content read on redeploys.
    return 0
  fi
  if [ "$LSTAT_OWNER" != "$TRUST_OWNER" ]; then
    die "$label owned by '$LSTAT_OWNER' — refusing (D13/D23)"
  fi
  # Root-owned leaf = legacy state (pre-first-migration cache or an
  # interrupted prior migration). Before ANY privileged use of the leaf (its
  # own open, or the walk/adoption of its entries) its NOT-SERVICE-WRITABLE
  # authority is proven: root ownership is checked above, but group/world
  # write bits or an access ACL could still hand the service the replacement
  # primitive inside it — that state REFUSES here, before any child is
  # examined or mutated (D23). The entries are then frozen for the whole
  # walk (the probe result is stable: only the owner — root — can chmod/
  # setfacl a root-owned directory). The dir inode is verified through an
  # opened descriptor before the walk AND again before its own adoption (the
  # walk uses the same fd slot — never nested).
  dir_not_service_writable "$d" "$label"
  open_checked "$d" "$label"
  close_fd
  adopt_tree "$d" "$label" 0
  lstat_record "$d" "$label" # re-record: adopt_tree clobbers the LSTAT globals
  open_checked "$d" "$label"
  fd_chown "$OPFD" "$SERVICE_USER:$SERVICE_USER" "$label"
  fd_chmod "$OPFD" 0700 "$label"
  close_fd
}

# The registry DIRECTORY is NOT certificate-style adoptable content: the
# certificate policy normalizes owners (that is its job for the legacy cache)
# which would ERASE the registry file's ownership evidence before
# migrate_registry_file could apply the registry's own refuse-don't-normalize
# policy. This handler validates the registry FILE's ORIGINAL type/link/
# owner/size policy FIRST — read-only, before anything in the registry
# subtree is mutated — and then moves only the DIRECTORY ITSELF to the
# service account (never its contents, never via the generic adoption walk).
migrate_registry_dir() { # $1 = registry directory
  local d=$1 label="registry dir"
  # --- 1. the FILE's original evidence, before any normalization ----------
  if [ -e "$REGISTRY_FILE" ]; then
    lstat_record "$REGISTRY_FILE" "identity registry"
    [ "$LSTAT_TYPE" = "regular file" ] ||
      die "registry path exists and is not a regular file: $REGISTRY_FILE (D13)"
    [ "$LSTAT_NLINK" = "1" ] ||
      die "registry file is hardlinked (nlink=$LSTAT_NLINK) — aliasing refused by policy (D23)"
    [ "$(stat_size "$REGISTRY_FILE")" != "0" ] ||
      die "registry file exists but is EMPTY (corrupt state — Go would fail closed); refusing to deploy over it"
    case " $LSTAT_OWNER " in
      " $SERVICE_USER ") : ;;
      *) die "registry file owned by '$LSTAT_OWNER' — identity state must be service-owned (Go initializes it as the service account); refusing (D13/D23)";;
    esac
  fi
  # --- 2. the DIRECTORY itself (contents never walked by root) ------------
  lstat_record "$d" "$label"
  [ "$LSTAT_TYPE" = "directory" ] || die "$label is not a directory: $d (D13)"
  if [ "$LSTAT_OWNER" = "$SERVICE_USER" ]; then
    service_gid || die "cannot resolve service group for $label (D23)"
    if [ "$LSTAT_GID" != "$SERVICE_GID" ] || [ "$LSTAT_MODE" != "700" ]; then
      # Alignment within the service's OWN authority (EPERM-confined to
      # objects the service already owns — see D23 notes).
      "$RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHOWN_BIN" "$SERVICE_USER:$SERVICE_USER" "$d" 2>/dev/null ||
        die "$label is service-owned with group '$LSTAT_GID' (want $SERVICE_GID) and the service cannot realign it — refusing (D23)"
      "$RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHMOD_BIN" 0700 "$d" 2>/dev/null ||
        die "cannot realign the $label mode as the service user — refusing (D23)"
    fi
    return 0
  fi
  if [ "$LSTAT_OWNER" != "$TRUST_OWNER" ]; then
    die "$label owned by '$LSTAT_OWNER' — refusing (D13/D23)"
  fi
  dir_not_service_writable "$d" "$label"
  open_checked "$d" "$label"
  fd_chown "$OPFD" "$SERVICE_USER:$SERVICE_USER" "$label"
  fd_chmod "$OPFD" 0700 "$label"
  close_fd
}

migrate_registry_file() { # the Go-owned identity state FILE — never reset
  if [ ! -e "$REGISTRY_FILE" ]; then
    log "registry file absent — Go will initialize it on first start (never pre-created)"
    return 0
  fi
  lstat_record "$REGISTRY_FILE" "identity registry"
  [ "$LSTAT_TYPE" = "regular file" ] ||
    die "registry path exists and is not a regular file: $REGISTRY_FILE (D13)"
  [ "$LSTAT_NLINK" = "1" ] ||
    die "registry file is hardlinked (nlink=$LSTAT_NLINK) — aliasing refused by policy (D23)"
  [ "$(stat_size "$REGISTRY_FILE")" != "0" ] ||
    die "registry file exists but is EMPTY (corrupt state — Go would fail closed); refusing to deploy over it"
  if [ "$LSTAT_OWNER" = "$SERVICE_USER" ]; then
    service_gid || die "cannot resolve service group for the identity registry (D23)"
    if [ "$LSTAT_GID" != "$SERVICE_GID" ] || [ "$LSTAT_MODE" != "600" ]; then
      # Drifted group/mode on service-owned state: aligned as the SERVICE
      # USER (confined to the service's own authority — see D23 notes).
      "$RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHOWN_BIN" "$SERVICE_USER:$SERVICE_USER" "$REGISTRY_FILE" 2>/dev/null ||
        die "registry file group is '$LSTAT_GID' (want $SERVICE_GID) and the service cannot realign it — refusing (D23)"
      "$RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHMOD_BIN" 0600 "$REGISTRY_FILE" 2>/dev/null ||
        die "cannot realign the registry file mode as the service user — refusing (D23)"
    fi
  else
    die "registry file owned by '$LSTAT_OWNER' — identity state must be service-owned (Go initializes it as the service account); refusing (D13/D23)"
  fi
  log "existing identity registry preserved: $REGISTRY_FILE ($(stat_size "$REGISTRY_FILE") bytes)"
}

setup_runtime_dirs() { # ONLY the two canonical leaves become writable (D13 + activation layout)
  local trusted_parent
  # Layout derived from the carried activation configuration: CERT_CACHE is
  # the -certdir base, CERT_DATA_DIR its certs/ child (where BOTH binaries
  # keep the autocert cache: DirCache joins "/certs"), REGISTRY_DIR the
  # registry/ child holding the Go-owned REGISTRY_FILE.
  CERT_DATA_DIR="$CERT_CACHE/certs"
  REGISTRY_DIR=${REGISTRY_FILE%/*}
  [ "$REGISTRY_DIR" = "$CERT_CACHE/registry" ] ||
    die "registry file must live at $CERT_CACHE/registry/devices.json (got $REGISTRY_FILE)"
  [ "$REGISTRY_FILE" != "$REGISTRY_DIR" ] || die "registry path is a directory, want the state FILE"
  case "$CERT_CACHE" in
    /|/var|/var/lib|/var/lib/|/etc|/usr|/bin|/sbin) die "certdir base $CERT_CACHE is not a dedicated state root";;
  esac
  # Read-only preflight BEFORE any mutation: the chain audit allows a
  # service-owned BASE (the pre-canonical state the reclaim below repairs);
  # symlinked or writable-unsafe chains are refused outright (D13).
  verify_trusted_dir "$CERT_CACHE" 1
  # Establish ancestor authority BEFORE the base's first checked open. A
  # post-reclaim probe cannot authorize an earlier privileged pathname open.
  trusted_parent=$(dirname "$CERT_CACHE")
  while :; do
    if [ -e "$trusted_parent" ]; then
      dir_not_service_writable "$trusted_parent" "cert cache ancestor"
    fi
    [ "$trusted_parent" = "$TRUST_BASE" ] || [ "$trusted_parent" = "/" ] || {
      trusted_parent=$(dirname "$trusted_parent")
      continue
    }
    break
  done
  [ ! -L "$CERT_CACHE" ] || die "cert cache base is a symlink — refusing (D13)"
  [ ! -L "$CERT_DATA_DIR" ] || die "cert cache dir is a symlink — refusing (D13)"
  [ ! -L "$REGISTRY_DIR" ] || die "registry dir is a symlink — refusing (D13)"
  [ ! -L "$REGISTRY_FILE" ] || die "registry file is a symlink — refusing (activation)"
  # --- 1. the base: root-only ancestor, reclaimed FIRST (D23 ordering) ------
  # While the base is service-owned, the service could replace certs/ or
  # registry/ themselves after their symlink checks — so NO child is examined
  # or created until the base is root-owned. The base pathname itself cannot
  # be replaced by the service (its parent is audited root-owned); the chown
  # is still bound to the opened, verified inode.
  # Creates only the audited missing tail, every new component an explicit
  # 0755 (never umask-derived: the service must traverse to its leaves).
  [ -e "$CERT_CACHE" ] || mkdir_tail_0755 "$CERT_CACHE"
  lstat_record "$CERT_CACHE" "cert cache base"
  [ "$LSTAT_TYPE" = "directory" ] || die "cert cache base is not a directory: $CERT_CACHE (D13)"
  if [ "$LSTAT_OWNER" = "$TRUST_OWNER" ]; then
    if [ "$LSTAT_MODE" != "755" ]; then
      open_checked "$CERT_CACHE" "cert cache base"
      fd_chmod "$OPFD" 0755 "cert cache base"
      close_fd
    fi
  elif [ "$LSTAT_OWNER" = "$SERVICE_USER" ]; then
    service_gid || die "cannot resolve service group for the base reclaim (D23)"
    [ "$LSTAT_GID" = "$SERVICE_GID" ] ||
      die "service-owned cert cache base has foreign group '$LSTAT_GID' — refusing (D23)"
    open_checked "$CERT_CACHE" "cert cache base"
    fd_chown "$OPFD" "$TRUST_OWNER:$TRUST_GROUP_ID" "cert cache base"
    fd_chmod "$OPFD" 0755 "cert cache base"
    close_fd
    log "reclaimed pre-canonical service-owned base: $CERT_CACHE (root-only ancestor)"
  else
    die "cert cache base owned by '$LSTAT_OWNER' — refusing (D13/D23)"
  fi
  # The base is root-owned 0755 here. Before any child name is created or
  # examined, prove the base is GENUINELY not service-writable (mode bits +
  # effective ACL probe as the service user — the reclaim above fixed
  # ownership, but an access ACL could still hand the service the right to
  # create/rename the certs//registry/ entries). Probing the base's own
  # parent as well is what freezes the BASE's name for the open_checked
  # calls in this function (rename/unlink of the base needs write on its
  # parent; the parent chain's mode bits were audited by the preflight).
  dir_not_service_writable "$CERT_CACHE" "cert cache base"
  dir_not_service_writable "$(dirname "$CERT_CACHE")" "cert cache parent"
  # --- 2. the children: create if absent (the base is root-owned now, so
  # the service can no longer race these entries), then classify + migrate.
  [ -e "$CERT_DATA_DIR" ] || mkdir "$CERT_DATA_DIR"
  [ -e "$REGISTRY_DIR" ] || mkdir "$REGISTRY_DIR"
  migrate_leaf_dir "$CERT_DATA_DIR" "cert cache dir"
  migrate_registry_dir "$REGISTRY_DIR" # NOT the generic certificate adoption (D23)
  # --- 3. the identity-registry FILE (Go-owned; policy in migrate_registry_file)
  migrate_registry_file
  # Post-migration re-audit of the FINAL layout: full chains, leaves allowed
  # service:service (with the designated group), every ancestor root:root.
  verify_trusted_dir "$CERT_DATA_DIR" 1
  verify_trusted_dir "$REGISTRY_DIR" 1
  verify_trusted_dir "$CERT_CACHE" 1
}

# DAC audit: root-owned install surfaces must not be writable by the runtime
# user; writable surfaces must belong to it. Checks ownership, write-bit
# math AND an EFFECTIVE write probe executed as the service user (respects
# ACLs, which owner/mode alone cannot see). RETURNS 1 on violation (the
# caller rolls back) rather than exiting, so the rollback path runs even
# when health already passed. Harness overrides this hook.
verify_runtime_ownership() { # $1 = installed release binary
  local p owner gid mode witness
  local release_bin=$1
  local -a protected=(
    "$RELEASE_ROOT" "$STATE_DIR" "$BACKUP_DIR" "$LEGACY_DIR" "$HELPERS_DIR"
    "$UNIT_DIR" "$UNIT_FILE" "$STATE_FILE" "$LOCK_FILE"
    "$HELPERS_DIR/imds-probe.sh" "$HELPERS_DIR/imds-guard.sh"
    "$CERT_CACHE" "$release_bin"
  )
  for p in "${protected[@]}"; do
    # The state ledger is written only AFTER this audit — on a first
    # migration it legitimately does not exist yet.
    if [ "$p" = "$STATE_FILE" ] && [ ! -e "$p" ]; then continue; fi
    [ -e "$p" ] || { log "DAC audit: missing $p"; return 1; }
    read -r owner gid mode <<<"$($STAT_BIN -c '%U %g %a' "$p" 2>/dev/null)" || { log "DAC audit: cannot stat $p"; return 1; }
    if [ "$owner" != "$TRUST_OWNER" ]; then
      log "DAC audit: $p owned by '$owner', must be $TRUST_OWNER (D13)"
      return 1
    fi
    if [ "$gid" != "$TRUST_GROUP_ID" ]; then
      log "DAC audit: $p group gid $gid, must be $TRUST_GROUP_ID (D13)"
      return 1
    fi
    if [ $((8#$mode & 8#22)) -ne 0 ]; then
      log "DAC audit: $p mode $mode is group/world-writable (D13)"
      return 1
    fi
  done
  [ -L "$BIN_LINK" ] || { log "DAC audit: $BIN_LINK is not a symlink (D13)"; return 1; }
  # Recursive sweep of the trees the runtime must not touch. The designed
  # service-owned leaves are pruned from the root-owned walks; a historical
  # pre-canonical registry directory under STATE_DIR (never used — the old
  # default was outside the Go registryBaseDir) is likewise pruned, never
  # deleted. The walk goes through STAT_BIN so the whole DAC model has one
  # seam.
  tree_has_violation "$RELEASE_ROOT" "$TRUST_OWNER" || return 1
  tree_has_violation "$STATE_DIR" "$TRUST_OWNER" "$STATE_DIR/registry" || return 1
  tree_has_violation "$HELPERS_DIR" "$TRUST_OWNER" || return 1
  tree_has_violation "$CERT_CACHE" "$TRUST_OWNER" "$CERT_DATA_DIR" "$REGISTRY_DIR" || return 1
  # The writable surfaces must belong to the runtime user — every file.
  for p in "$CERT_DATA_DIR" "$REGISTRY_DIR"; do
    [ -d "$p" ] || { log "DAC audit: missing writable surface $p"; return 1; }
    [ "$($STAT_BIN -c '%U' "$p")" = "$SERVICE_USER" ] || { log "DAC audit: $p owned by '$($STAT_BIN -c '%U' "$p")', must be $SERVICE_USER (D13)"; return 1; }
    tree_has_violation "$p" "$SERVICE_USER" || return 1
  done
  # EFFECTIVE write access as the service user (ACL-aware, unlike the
  # bit math above). Root-protected paths must NOT be writable — including
  # the root-only layout ancestor; the two canonical leaves must be.
  for p in "${protected[@]}"; do
    witness=$(service_write_witness "$p") ||
      { log "DAC audit: service authority probe execution unproven for $p (D13)"; return 1; }
    if [ "$witness" = writable ]; then
      log "DAC audit: runtime user CAN write $p (D13)"
      return 1
    fi
  done
  for p in "$CERT_DATA_DIR" "$REGISTRY_DIR"; do
    witness=$(service_write_witness "$p") ||
      { log "DAC audit: service authority probe execution unproven for $p (D13)"; return 1; }
    [ "$witness" = writable ] ||
      { log "DAC audit: runtime user cannot write $p (D13)"; return 1; }
  done
  return 0
}

main() {
  # --- arguments (validated again here; the SSM document is the first gate) ---
  local BUCKET='' ARTIFACT_PATH='' ARCHIVE_SHA='' BINARY_SHA='' VERSION='' REVISION='' DOMAIN='' ALIASES='' SERVICE='' SERVICE_USER='' HEALTH_TIMEOUT=''
  local CERTDIR_ARG='' REGISTRY_ARG=''
  while [ $# -gt 0 ]; do
    case "$1" in
      --bucket) BUCKET=$2; shift 2;;
      --artifact-path) ARTIFACT_PATH=$2; shift 2;;
      --archive-sha256) ARCHIVE_SHA=$2; shift 2;;
      --binary-sha256) BINARY_SHA=$2; shift 2;;
      --version) VERSION=$2; shift 2;;
      --revision) REVISION=$2; shift 2;;
      --domain) DOMAIN=$2; shift 2;;
      --aliases) ALIASES=$2; shift 2;;
      --service) SERVICE=$2; shift 2;;
      --service-user) SERVICE_USER=$2; shift 2;;
      --health-timeout) HEALTH_TIMEOUT=$2; shift 2;;
      --certdir) CERTDIR_ARG=$2; shift 2;;
      --registry) REGISTRY_ARG=$2; shift 2;;
      *) die "unknown argument: $1";;
    esac
  done

  # Anchored, backslash-free patterns — the same literals the SSM document
  # enforces as its allowedPattern (D3/D9); any drift is a contract-test fail.
  assert_arg "$BUCKET" '^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$' 'bucket'
  assert_arg "$ARTIFACT_PATH" '^artifacts/[0-9a-f]{64}/gateway-linux-arm64[.]gz$' 'artifact path'
  assert_arg "$ARCHIVE_SHA" '^[0-9a-f]{64}$' 'archive sha256'
  assert_arg "$BINARY_SHA" '^[0-9a-f]{64}$' 'binary sha256'
  assert_arg "$VERSION" '^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$' 'version'
  assert_arg "$REVISION" '^[0-9a-f]{7,40}$' 'revision'
  assert_arg "$DOMAIN" '^[a-z0-9]([a-z0-9-]*[a-z0-9])?([.][a-z0-9]([a-z0-9-]*[a-z0-9])?)+$' 'domain'
  assert_arg "$ALIASES" '^([a-z0-9]([a-z0-9-]*[a-z0-9])?([.][a-z0-9]([a-z0-9-]*[a-z0-9])?)+)?(,([a-z0-9]([a-z0-9-]*[a-z0-9])?([.][a-z0-9]([a-z0-9-]*[a-z0-9])?)+)?)*$' 'aliases'
  assert_arg "$SERVICE" '^[a-zA-Z0-9:@._-]{1,128}$' 'service name'
  assert_arg "$SERVICE_USER" '^[a-z_][a-z0-9_-]{0,31}$' 'service user'
  assert_arg "$HEALTH_TIMEOUT" '^([5-9]|[1-9][0-9]|[1-5][0-9]{2}|600)$' 'health timeout'
  assert_arg "$CERTDIR_ARG" '^/[A-Za-z0-9][A-Za-z0-9/._-]*$' 'certdir'
  assert_arg "$REGISTRY_ARG" '^/[A-Za-z0-9][A-Za-z0-9/._-]*$' 'registry'
  [ "$HEALTH_TIMEOUT" -ge 5 ] && [ "$HEALTH_TIMEOUT" -le 600 ] || die "health timeout out of range"

  # Activation configuration is EXPLICITLY carried: empty means the deploy
  # was sent by a pre-activation document — refuse rather than silently
  # deploy an API-less gateway that still reports healthy version/commit.
  [ -n "$CERTDIR_ARG" ] || die "missing required --certdir (activation configuration must be carried explicitly)"
  [ -n "$REGISTRY_ARG" ] || die "missing required --registry (activation configuration must be carried explicitly)"
  CERT_CACHE=$CERTDIR_ARG
  REGISTRY_FILE=$REGISTRY_ARG
  CERT_DATA_DIR="$CERT_CACHE/certs" # where BOTH binaries keep the autocert cache
  REGISTRY_DIR=${REGISTRY_FILE%/*}
  [ "$REGISTRY_DIR" = "$CERT_CACHE/registry" ] || die "registry file must live at <certdir>/registry/devices.json (got $REGISTRY_FILE)"
  [ "$REGISTRY_FILE" = "$REGISTRY_DIR/devices.json" ] || die "registry state file must be named devices.json (got $REGISTRY_FILE)"
  case "$CERT_CACHE" in
    /|/var|/var/lib|/var/lib/|/etc|/usr|/bin|/sbin) die "certdir base $CERT_CACHE is not a dedicated state root";;
  esac

  # Digest-bound path (D9): the key's embedded digest must BE the expected
  # archive digest, so a caller cannot pair path A with verification of B.
  [ "${ARTIFACT_PATH#artifacts/}" = "$ARCHIVE_SHA/$ARCHIVE_NAME" ] || die "artifact path digest does not match expected archive sha256"

  local UNIT_FILE=$UNIT_DIR/${SERVICE}.service
  local STATE_FILE=$STATE_DIR/deploy-state
  local LOCK_FILE=$STATE_DIR/deploy.lock
  local tmp_link="$BIN_LINK.tmp.$$"

  # D13: refuse to operate in an untrusted path environment BEFORE any
  # download or mutation — a planted symlink/writable parent cannot launder
  # the swap targets, the state/backup/legacy locations, or the paths that
  # are about to become runtime-writable. The certdir base is audited in
  # leaf mode (a pre-canonical deploy may have left it service-owned — that
  # exact state is what the migration below repairs); the registry leaf and
  # file must not be symlinks already.
  verify_trusted_dir "$UNIT_DIR"
  verify_trusted_dir "$(dirname "$BIN_LINK")"
  verify_trusted_dir "$STATE_DIR"
  verify_trusted_dir "$BACKUP_DIR"
  verify_trusted_dir "$LEGACY_DIR"
  verify_trusted_dir "$RELEASE_ROOT"
  verify_trusted_dir "$HELPERS_DIR"
  verify_trusted_dir "$CERT_CACHE" 1
  [ ! -L "$CERT_DATA_DIR" ] || die "cert cache dir is a symlink — refusing (D13)"
  [ ! -L "$REGISTRY_DIR" ] || die "registry dir is a symlink — refusing (D13)"
  [ ! -L "$REGISTRY_FILE" ] || die "registry file is a symlink — refusing (activation)"

  local need
  for need in "$AWS_BIN" "$SYSTEMCTL" "$SYSTEMD_RUN" "$RUNUSER_BIN" "$CURL_BIN" "$SHA_BIN" \
    "$GETENT_BIN" "$USERADD_BIN" "$GROUPADD_BIN" "$USERMOD_BIN" "$CHOWN_BIN" "$CHMOD_BIN" \
    "$ID_BIN" "$STAT_BIN" flock gzip readlink od dd realpath mktemp; do
    command -v "$need" >/dev/null 2>&1 || die "missing required tool: $need"
  done

  mkdir -p "$STATE_DIR" "$BACKUP_DIR"
  # One deploy at a time on this host (D6): concurrent invocations serialize;
  # an interrupted (killed) deploy releases the lock with the kernel.
  exec 9>"$LOCK_FILE"
  flock -w "$LOCK_WAIT" 9 || die "another deployment holds the lock (waited ${LOCK_WAIT}s)"

  TMP_DIR=$(mktemp -d "${TMPDIR:-/tmp}/gateway-deploy.XXXXXX")

  log "deploy requested: version=$VERSION revision=$REVISION archive=$ARCHIVE_SHA binary=$BINARY_SHA bucket=$BUCKET path=$ARTIFACT_PATH domain=$DOMAIN aliases=$ALIASES service=$SERVICE user=$SERVICE_USER"

  # --- 1. previous state (parsed, never sourced; atomic on update) -----------
  # Sentinel values written by this script itself ('none' = absent,
  # 'legacy'/'unknown' = pre-migration state) normalize to empty; anything
  # else must match the expected format or the deploy aborts.
  # CURRENT_ACTIVATION/PREVIOUS_ACTIVATION record whether the ledger entry
  # was deployed with the new API ACTIVATED (registry+tunnel enabled): a
  # rollback to an activated release must require the enabled postures again
  # instead of silently accepting a deactivated previous release.
  local current_sha='' current_binary='' current_release='' current_version='' current_revision='' current_activation=''
  local previous_sha='' previous_binary='' previous_release='' previous_version='' previous_revision='' previous_activation=''
  if [ -f "$STATE_FILE" ]; then
    current_sha=$(sed -n 's/^CURRENT_SHA=//p' "$STATE_FILE" | head -1)
    current_binary=$(sed -n 's/^CURRENT_BINARY_SHA=//p' "$STATE_FILE" | head -1)
    current_release=$(sed -n 's/^CURRENT_RELEASE=//p' "$STATE_FILE" | head -1)
    current_version=$(sed -n 's/^CURRENT_VERSION=//p' "$STATE_FILE" | head -1)
    current_revision=$(sed -n 's/^CURRENT_REVISION=//p' "$STATE_FILE" | head -1)
    current_activation=$(sed -n 's/^CURRENT_ACTIVATION=//p' "$STATE_FILE" | head -1)
    previous_sha=$(sed -n 's/^PREVIOUS_SHA=//p' "$STATE_FILE" | head -1)
    previous_binary=$(sed -n 's/^PREVIOUS_BINARY_SHA=//p' "$STATE_FILE" | head -1)
    previous_release=$(sed -n 's/^PREVIOUS_RELEASE=//p' "$STATE_FILE" | head -1)
    previous_version=$(sed -n 's/^PREVIOUS_VERSION=//p' "$STATE_FILE" | head -1)
    previous_revision=$(sed -n 's/^PREVIOUS_REVISION=//p' "$STATE_FILE" | head -1)
    previous_activation=$(sed -n 's/^PREVIOUS_ACTIVATION=//p' "$STATE_FILE" | head -1)
    [ -z "$current_sha" ] || [ "$current_sha" = legacy ] || printf '%s' "$current_sha" | grep -Eq '^[0-9a-f]{64}$' || die "state corrupted (CURRENT_SHA)"
    [ -z "$current_binary" ] || [ "$current_binary" = unknown ] || printf '%s' "$current_binary" | grep -Eq '^[0-9a-f]{64}$' || die "state corrupted (CURRENT_BINARY_SHA)"
    [ -z "$previous_sha" ] || [ "$previous_sha" = none ] || printf '%s' "$previous_sha" | grep -Eq '^[0-9a-f]{64}$' || die "state corrupted (PREVIOUS_SHA)"
    [ -z "$previous_binary" ] || [ "$previous_binary" = none ] || printf '%s' "$previous_binary" | grep -Eq '^[0-9a-f]{64}$' || die "state corrupted (PREVIOUS_BINARY_SHA)"
    # The legacy rollback ledger names the DIRECTORY, not a release child.
    # Normalize only the exact sentinel this installer writes; preserve all
    # activated/nonlegacy release validation and never follow PREVIOUS as target.
    if [ "$current_sha" = legacy ]; then
      [ "$current_release" = "$LEGACY_DIR" ] && [ "$current_activation" = 0 ] ||
        die "state corrupted (legacy CURRENT_RELEASE/ACTIVATION)"
      if [ "$current_binary" != unknown ]; then
        [[ "$current_binary" =~ ^[0-9a-f]{64}$ ]] && [ -x "$LEGACY_DIR/pocketshell-relay" ] &&
          [ "$current_binary" = "$(sha_of "$LEGACY_DIR/pocketshell-relay")" ] ||
          die "state corrupted (legacy CURRENT_BINARY_SHA)"
      fi
      current_release=''
    fi
    [ -z "$current_release" ] || case "$current_release" in "$RELEASE_ROOT"/*|"$LEGACY_DIR"/*) ;; *) die "state corrupted (CURRENT_RELEASE)";; esac
    [ -z "$previous_release" ] || [ "$previous_release" = none ] || case "$previous_release" in "$RELEASE_ROOT"/*|"$LEGACY_DIR"/*) ;; *) die "state corrupted (PREVIOUS_RELEASE)";; esac
    case "$current_activation" in ''|0|1) ;; *) die "state corrupted (CURRENT_ACTIVATION)";; esac
    case "$previous_activation" in ''|0|1|none) ;; *) die "state corrupted (PREVIOUS_ACTIVATION)";; esac
    if [ "$current_sha" = legacy ]; then current_sha=''; fi
    if [ "$current_binary" = unknown ]; then current_binary=''; fi
    if [ "$previous_sha" = none ]; then previous_sha=''; fi
    if [ "$previous_binary" = none ]; then previous_binary=''; fi
    if [ "$previous_release" = none ]; then previous_release=''; fi
    if [ "$previous_version" = none ]; then previous_version=''; fi
    if [ "$previous_revision" = none ]; then previous_revision=''; fi
    if [ "$previous_activation" = none ]; then previous_activation=''; fi
  fi
  [ -n "$current_activation" ] || current_activation=0
  # --- 2. download + verify (archive and binary digests separate, D4) --------
  log "downloading artifact"
  "$AWS_BIN" s3 cp "s3://$BUCKET/$ARTIFACT_PATH" "$TMP_DIR/artifact.gz" >/dev/null
  "$AWS_BIN" s3 cp "s3://$BUCKET/${ARTIFACT_PATH%/*}/VERSION" "$TMP_DIR/VERSION" >/dev/null || die "VERSION sidecar missing"
  "$AWS_BIN" s3 cp "s3://$BUCKET/${ARTIFACT_PATH%/*}/manifest.json" "$TMP_DIR/manifest.json" >/dev/null || die "manifest missing"

  local actual_archive_sha actual_binary_sha remote_version
  actual_archive_sha=$(sha_of "$TMP_DIR/artifact.gz")
  [ "$actual_archive_sha" = "$ARCHIVE_SHA" ] || die "archive sha mismatch: got $actual_archive_sha want $ARCHIVE_SHA"
  gzip -t "$TMP_DIR/artifact.gz" || die "artifact is not valid gzip"

  # Digest-bound manifest (D10): the manifest shipped with this exact archive
  # must agree with every parameter the deployer sent.
  manifest_field() { json_field "$TMP_DIR/manifest.json" "$1"; }
  [ "$(manifest_field archive_sha256)" = "$ARCHIVE_SHA" ] || die "manifest archive_sha256 mismatch"
  [ "$(manifest_field binary_sha256)" = "$BINARY_SHA" ] || die "manifest binary_sha256 mismatch"
  [ "$(manifest_field version)" = "$VERSION" ] || die "manifest version mismatch"
  [ "$(manifest_field source_revision)" = "$REVISION" ] || die "manifest source_revision mismatch"
  [ "$(manifest_field domain)" = "$DOMAIN" ] || die "manifest domain mismatch"
  [ "$(manifest_field service)" = "$SERVICE" ] || die "manifest service mismatch"
  [ "$(manifest_field aliases)" = "$ALIASES" ] || die "manifest aliases mismatch"
  [ "$(manifest_field certdir)" = "$CERT_CACHE" ] || die "manifest certdir mismatch (activation configuration drift)"
  [ "$(manifest_field registry)" = "$REGISTRY_FILE" ] || die "manifest registry mismatch (activation configuration drift)"

  remote_version=$(tr -d ' \t\n\r' <"$TMP_DIR/VERSION")
  [ "$remote_version" = "$VERSION" ] || die "VERSION sidecar mismatch: got $remote_version want $VERSION"

  gzip -dc "$TMP_DIR/artifact.gz" >"$TMP_DIR/binary"
  actual_binary_sha=$(sha_of "$TMP_DIR/binary")
  [ "$actual_binary_sha" = "$BINARY_SHA" ] || die "binary sha mismatch: got $actual_binary_sha want $BINARY_SHA (archive and executable digests are independent)"
  elf_is_arm64 "$TMP_DIR/binary" || die "artifact is not a valid ARM64 ELF executable"
  log "artifact verified: archive=$ARCHIVE_SHA binary=$BINARY_SHA version=$remote_version revision=$REVISION"

  # --- 3. install immutable release ------------------------------------------
  [ -f "$UNIT_FILE" ] || die "unit file not found: $UNIT_FILE (is the legacy relay stack deployed?)"
  # Explicit 0755 on BOTH directories of the release path, regardless of the
  # envelope's umask 077: the unit runs the binary as $SERVICE_USER (D13).
  ensure_root_dir_0755 "$RELEASE_ROOT" "release root"

  local release_dir="$RELEASE_ROOT/$ARCHIVE_SHA"
  local release_bin="$release_dir/$RELEASE_BIN_NAME"
  local release_stage
  ensure_root_dir_0755 "$release_dir" "release dir" # also repairs a 0700 leftover on reuse
  if [ -e "$release_bin" ]; then
    [ "$(sha_of "$release_bin")" = "$BINARY_SHA" ] || die "existing release dir is corrupt: $release_dir"
    log "release already present, reusing (immutable per-SHA layout)"
  else
    # Exclusive unpredictable staging inside the audited release dir (same
    # reasoning as atomic_write), then rename(2) into place.
    release_stage=$(mktemp -- "$release_dir/.pocketshell-gateway.tmp.XXXXXX") ||
      die "cannot stage release binary in $release_dir"
    install -m 0755 "$TMP_DIR/binary" "$release_stage"
    mv -f "$release_stage" "$release_bin"
    [ "$(sha_of "$release_bin")" = "$BINARY_SHA" ] || { rm -rf "${release_dir:?}"; die "post-install hash mismatch"; }
  fi

  local unit_backup
  unit_backup="$BACKUP_DIR/unit.$(date +%s).bak"
  cp -a "$UNIT_FILE" "$unit_backup"
  restore_unit() { cp -a "$unit_backup" "$UNIT_FILE"; }

  # --- 4. preserve legacy executable BEFORE first swap (D5) -------------------
  local legacy_bin="$LEGACY_DIR/pocketshell-relay"
  if [ -f "$BIN_LINK" ] && [ ! -L "$BIN_LINK" ]; then
    mkdir -p "$LEGACY_DIR"
    cp -a "$BIN_LINK" "$legacy_bin.new.$$"
    [ "$(sha_of "$legacy_bin.new.$$")" = "$(sha_of "$BIN_LINK")" ] || { rm -f "$legacy_bin.new.$$"; die "legacy preservation hash mismatch — aborting before any swap"; }
    mv -f "$legacy_bin.new.$$" "$legacy_bin"
    chmod 0755 "$legacy_bin"
    log "legacy executable preserved: $legacy_bin (sha $(sha_of "$legacy_bin"))"
  fi

  # Capture authority BEFORE changing the unit: only the original nonactivated
  # legacy process with empty effective identity and all real kernel IDs root.
  # Failed/missing evidence grants no root rollback exception.
  local legacy_original_unit_sha='' legacy_original_binary_sha='' legacy_original_target=''
  local original_pid original_exe original_status original_ids original_user original_group
  if [ -z "$current_release" ] && [ -z "$current_sha" ] && [ "$current_activation" = 0 ] &&
      [ -x "$legacy_bin" ] && original_user=$(systemd_prop User) &&
      original_group=$(systemd_prop Group) && [ -z "$original_user" ] && [ -z "$original_group" ]; then
    original_pid=$("$SYSTEMCTL" show -p MainPID --value "$SERVICE")
    if [[ "$original_pid" =~ ^[1-9][0-9]*$ ]]; then
      original_exe=$(running_exe "$original_pid")
      original_status=$(proc_status "$original_pid")
      original_ids=$(printf '%s\n' "$original_status" | awk '$1 == "Uid:" || $1 == "Gid:" {print $2, $3, $4, $5}')
      if [ "$original_ids" = $'0 0 0 0\n0 0 0 0' ] && [ -n "$original_exe" ] &&
          [ "$(readlink -f "$original_exe")" = "$(readlink -f "$BIN_LINK")" ] &&
          [ "$(sha_of "$UNIT_FILE")" = "$(sha_of "$unit_backup")" ] &&
          [ "$(sha_of "$original_exe")" = "$(sha_of "$legacy_bin")" ]; then
        legacy_original_unit_sha=$(sha_of "$unit_backup")
        legacy_original_binary_sha=$(sha_of "$legacy_bin")
        legacy_original_target=$(readlink -f "$legacy_bin")
      fi
    fi
  fi

  # --- 5. D13 migration prep (idempotent; before any restart) -----------------
  [ -f "$HELPERS_DIR/imds-probe.sh" ] && [ -f "$HELPERS_DIR/imds-guard.sh" ] ||
    die "IMDS helpers missing in $HELPERS_DIR (SSM document must install them first)"
  ensure_service_user

  # --- 5a. D13 IMDS strategy PREFLIGHT (header item 4): before the unit, the
  # bin link or the runtime layout is touched; no proven strategy = refuse
  # with the old config still serving (incident 2026-10-09).
  local imds_strategy='' imds_control_rc=0 probe_rc=0 guard_err
  if imds_control_probe; then imds_control_rc=0; else imds_control_rc=$?; fi
  if imds_filtered_probe; then probe_rc=0; else probe_rc=$?; fi
  if imds_protected "$probe_rc" "$imds_control_rc"; then
    imds_strategy=systemd
    log "IMDS preflight: protected by IPAddressDeny as $SERVICE_USER (filtered rc=$probe_rc, unfiltered control rc=$imds_control_rc) — systemd strategy"
  else
    case "$probe_rc" in
      1) log "IMDS preflight: TOKEN OBTAINABLE under IPAddressDeny — kernel filter ineffective (D13)";;
      10) log "IMDS preflight: dropped under IPAddressDeny but the unfiltered control did not reach IMDS (rc=$imds_control_rc) — not attributable to the filter, fail closed";;
      *) log "IMDS preflight: IPAddressDeny protection not proven (systemd-run rc=$probe_rc, control rc=$imds_control_rc) — fail closed";;
    esac
    # Strategy B only with present+functional tooling (--check), the rule
    # applied (idempotent; REJECTs only this uid's IMDS traffic) and proven.
    if ! guard_err=$("$HELPERS_DIR/imds-guard.sh" --check "$SERVICE_USER" 2>&1); then
      die "IMDS protection unavailable: IPAddressDeny not proven and uid-firewall preflight failed (${guard_err:-no detail}) — refusing before any unit or binary change (D13)"
    fi
    if ! guard_err=$("$HELPERS_DIR/imds-guard.sh" "$SERVICE_USER" 2>&1); then
      die "IMDS protection unavailable: uid-firewall guard failed to apply (${guard_err:-no detail}) — refusing before any unit or binary change (D13)"
    fi
    if "$RUNUSER_BIN" -u "$SERVICE_USER" -- "$HELPERS_DIR/imds-probe.sh"; then
      probe_rc=0
    else
      probe_rc=$?
    fi
    imds_protected "$probe_rc" "$imds_control_rc" ||
      die "IMDS protection unavailable: probe as $SERVICE_USER under the uid firewall rc=$probe_rc (control rc=$imds_control_rc) — refusing before any unit or binary change (D13)"
    imds_strategy=firewall
    log "IMDS preflight: uid-firewall guard verified as $SERVICE_USER (rc=$probe_rc) — firewall strategy"
  fi

  setup_runtime_dirs

  local current_exec new_exec
  current_exec=$(sed -n 's/^ExecStart=//p' "$UNIT_FILE" | tail -1)
  [ -n "$current_exec" ] || die "no ExecStart in $UNIT_FILE"
  new_exec=$(rewrite_exec_start "$current_exec" "$BIN_LINK" "$DOMAIN" "$ALIASES" "$CERT_CACHE" "$REGISTRY_FILE") ||
    die "ExecStart rewrite failed — the unit must carry a nonempty -allow allowlist to activate the new API"
  [ -n "$new_exec" ] || die "ExecStart rewrite produced an empty line"

  # Build the unit content: ExecStart rewrite + D13 hardening directives.
  local unit_content
  unit_content=$(cat "$UNIT_FILE")
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive ExecStart "$new_exec")
  # The Go server stays in the foreground, without fork or READY notification.
  # Bind its startup contract; restore_unit keeps the saved legacy unit intact.
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive Type exec)
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive PIDFile '')
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive GuessMainPID no)
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive User "$SERVICE_USER")
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive Group "$SERVICE_USER")
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive AmbientCapabilities CAP_NET_BIND_SERVICE)
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive CapabilityBoundingSet CAP_NET_BIND_SERVICE)
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive NoNewPrivileges yes)
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive ProtectSystem strict)
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive ProtectHome yes)
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive PrivateTmp yes)
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive RestrictAddressFamilies 'AF_UNIX AF_INET AF_INET6')
  # Activation ReadWritePaths is a WHITELIST of the two canonical LEAVES:
  # the autocert cache directory (<certdir>/certs, where both binaries keep
  # the cache) and the registry directory (Go's temp+rename+fsync workspace).
  # The root-only parent is NEVER writable and legacy/foreign entries are
  # deliberately not carried forward.
  unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive ReadWritePaths "$CERT_DATA_DIR $REGISTRY_DIR")
  # D13 IMDS: the strategy chosen (and proven) in the preflight above.
  local guard_line="ExecStartPre=+$HELPERS_DIR/imds-guard.sh $SERVICE_USER"
  if [ "$imds_strategy" = systemd ]; then
    # Strategy A: IPAddressDeny for both endpoints; a uid-guard line left by
    # an earlier strategy-B deploy is dropped (the audit refuses both).
    unit_content=$(printf '%s\n' "$unit_content" | unit_drop_line "$guard_line")
    unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive IPAddressDeny "$IMDS_V4 $IMDS_V6")
  else
    # Strategy B: uid-scoped firewall + root ExecStartPre guard (reboot-safe).
    unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive IPAddressDeny '')
    unit_content=$(printf '%s\n' "$unit_content" | unit_set_directive ExecStartPre "+$HELPERS_DIR/imds-guard.sh $SERVICE_USER")
  fi

  # From here on, any failure must trigger the rollback path. Rollback is
  # decided in an ERR trap: errexit in a TOP-LEVEL script (the SSM envelope)
  # unwinds main's locals BEFORE the EXIT trap runs (incident 2026-10-09:
  # "unit_installed: unbound variable", nothing restored). ERR runs at the
  # failing command with the locals visible (set -E), main shell only.
  local unit_installed=0 health_passed=0 rollback_done=0
  rollback_if_pending() {
    if [ "${unit_installed:-0}" = 1 ] && [ "${health_passed:-0}" = 0 ] && [ "${rollback_done:-0}" = 0 ]; then
      do_rollback # exits on every path
    fi
  }
  on_err() {
    local rc=$?
    [ "$BASHPID" = "$$" ] || return "$rc"
    log "command failed (rc=$rc) at ${BASH_SOURCE[1]:-main}:${BASH_LINENO[0]:-?} after the unit was installed"
    # NOTE: no cleanup() before the rollback — the rollback re-check needs
    # its probe directory alive (it is recreated if already gone).
    rollback_if_pending
    return "$rc"
  }
  on_error() {
    local rc=$?
    rollback_if_pending
    cleanup
    exit "$rc"
  }

  do_rollback() {
    rollback_done=1
    log "DEPLOY FAILED — rolling back to previous configuration"
    # Restore target: the release that was CURRENT in the state at attempt
    # time (what was actually serving before this deploy), else the preserved
    # legacy executable. NOT the state's PREVIOUS_* (that is two releases
    # back, and a poisoned PREVIOUS must never become the rollback target).
    local target_release=${current_release:-}
    if [ -n "$target_release" ] && [ ! -x "$target_release/$RELEASE_BIN_NAME" ]; then
      target_release=''
    fi
    if [ -n "$target_release" ]; then
      ln -sfn "$target_release/$RELEASE_BIN_NAME" "$tmp_link"
      mv -Tf "$tmp_link" "$BIN_LINK"
    elif [ -x "$legacy_bin" ]; then
      ln -sfn "$legacy_bin" "$tmp_link"
      mv -Tf "$tmp_link" "$BIN_LINK"
    else
      log "no previous release and no preserved legacy executable; restoring unit only"
    fi
    local restored_legacy_root=0
    if [ -z "$target_release" ] && [ -n "$legacy_original_unit_sha" ]; then
      restored_legacy_root=1
    fi
    restore_unit # legacy/root unit — also undoes User= and IMDS directives
    "$SYSTEMCTL" daemon-reload || true
    if ! "$SYSTEMCTL" restart "$SERVICE"; then
      printf 'sha256=%s\nbinary-sha256=%s\nversion=%s\ncommit=%s\nhealthz=legacy\nimds=unchanged\nhealth=failed\nrollback=failed\nprevious=%s\n' \
        "$ARCHIVE_SHA" "$BINARY_SHA" "$VERSION" "$REVISION" "${current_sha:-none}"
      log "rollback=failed: restart refused — MANUAL INTERVENTION REQUIRED"
      exit 2
    fi
    # Re-verify the RESTORED configuration against its OWN unit and identity:
    # restored executable identity + trusted TLS on the restored names (D8),
    # and the runtime-credential audit in tolerant mode (a legacy unit has
    # no User=; any hardened unit that IS restored is fully re-audited).
    # /healthz is OPTIONAL here: the previous binary may predate it — a
    # missing healthz is reported as healthz=legacy, never as a version pass.
    local rb_domain rb_aliases rb_binary rb_deadline ok=0 a
    rb_domain=$(sed -n 's/^ExecStart=.*[ -]domain \([^ ]*\).*/\1/p' "$UNIT_FILE" | tail -1)
    rb_aliases=$(sed -n 's/^ExecStart=.*[ -]aliases \([^ ]*\).*/\1/p' "$UNIT_FILE" | tail -1)
    local -a rb_names=("${rb_domain:-$DOMAIN}")
    for a in ${rb_aliases//,/ }; do [ -n "$a" ] && rb_names+=("$a"); done
    rb_binary=${current_binary:-}
    if [ -z "$rb_binary" ] && [ -n "$target_release" ]; then
      rb_binary=$(sha_of "$target_release/$RELEASE_BIN_NAME")
    elif [ -z "$rb_binary" ] && [ -x "$legacy_bin" ]; then
      rb_binary=$(sha_of "$legacy_bin")
    fi
    rb_deadline=$(( $(date +%s) + 30 ))
    if [ -n "$rb_binary" ]; then
      until "$SYSTEMCTL" is-active --quiet "$SERVICE" && health_ok "$rb_binary" "$BIN_LINK" 0 "${current_version:-$VERSION}" "${current_revision:-$REVISION}" "${current_activation:-0}" ${rb_names[@]+"${rb_names[@]}"}; do
        [ "$(date +%s)" -lt "$rb_deadline" ] || break
        sleep 2
      done
      if "$SYSTEMCTL" is-active --quiet "$SERVICE" && health_ok "$rb_binary" "$BIN_LINK" 0 "${current_version:-$VERSION}" "${current_revision:-$REVISION}" "${current_activation:-0}" ${rb_names[@]+"${rb_names[@]}"}; then
        ok=1
      fi
    else
      # Unit-only restore with no known target digest: verify liveness and
      # trusted-TLS endpoints; say plainly that exe identity is unverifiable.
      log "rollback: no target binary digest available — verifying liveness and TLS endpoints only"
      until "$SYSTEMCTL" is-active --quiet "$SERVICE" && endpoint_ok "${rb_names[0]}"; do
        [ "$(date +%s)" -lt "$rb_deadline" ] || break
        sleep 2
      done
      if "$SYSTEMCTL" is-active --quiet "$SERVICE" && endpoint_ok "${rb_names[0]}"; then
        ok=1
      fi
    fi
    if [ "$ok" = "1" ]; then
      log "rollback=ok (previous configuration healthy again; healthz=$HEALTHZ_RESULT)"
      printf 'sha256=%s\nbinary-sha256=%s\nversion=%s\ncommit=%s\nhealthz=%s\nimds=unchanged\nhealth=failed\nrollback=ok\nprevious=%s\n' \
        "$ARCHIVE_SHA" "$BINARY_SHA" "$VERSION" "$REVISION" "$HEALTHZ_RESULT" "${current_sha:-legacy}"
      # Rewrite the state so the ledger matches reality: the restored release
      # is CURRENT again, the failed attempt becomes PREVIOUS (D5). A failed
      # retry therefore cannot poison the last-good entry: the next attempt
      # rolls back to CURRENT (= the restored release), never to its own
      # earlier failure.
      atomic_write "$STATE_FILE" <<EOF
CURRENT_SHA=${current_sha:-legacy}
CURRENT_BINARY_SHA=${current_binary:-unknown}
CURRENT_RELEASE=${current_release:-$LEGACY_DIR}
CURRENT_VERSION=${current_version:-legacy}
CURRENT_REVISION=${current_revision:-none}
CURRENT_ACTIVATION=${current_activation:-0}
PREVIOUS_SHA=$ARCHIVE_SHA
PREVIOUS_BINARY_SHA=$BINARY_SHA
PREVIOUS_RELEASE=$release_dir
PREVIOUS_VERSION=$VERSION
PREVIOUS_REVISION=$REVISION
PREVIOUS_ACTIVATION=1
UPDATED_AT=$(date +%s)
EOF
      exit 0
    fi
    printf 'sha256=%s\nbinary-sha256=%s\nversion=%s\ncommit=%s\nhealthz=%s\nimds=unchanged\nhealth=failed\nrollback=failed\nprevious=%s\n' \
      "$ARCHIVE_SHA" "$BINARY_SHA" "$VERSION" "$REVISION" "$HEALTHZ_RESULT" "${current_sha:-legacy}"
    log "rollback=failed: previous configuration not healthy — MANUAL INTERVENTION REQUIRED"
    exit 2
  }

  trap on_error EXIT
  trap on_err ERR
  atomic_write "$UNIT_FILE" <<<"$unit_content"
  [ "$(grep -c '^ExecStart=' "$UNIT_FILE")" = "1" ] || { restore_unit; die "unit rewrite produced wrong ExecStart count"; }
  [ "$(grep -c '^User=' "$UNIT_FILE")" = "1" ] || { restore_unit; die "unit rewrite produced wrong User count"; }
  unit_installed=1

  ln -sfn "$release_bin" "$tmp_link" # temp link beside the target: rename(2) stays on one filesystem
  mv -Tf "$tmp_link" "$BIN_LINK"
  log "installed: $BIN_LINK -> $release_bin"

  # --- 6. restart + health (identity, TLS, runtime audit, /healthz version) ---
  "$SYSTEMCTL" daemon-reload
  log "restarting $SERVICE"
  "$SYSTEMCTL" restart "$SERVICE"

  local names=("$DOMAIN") a
  for a in ${ALIASES//,/ }; do [ -n "$a" ] && names+=("$a"); done

  # New deploys ALWAYS carry the activation contract: posture fields must
  # both be enabled AND the routes must actually be mounted (auth rejection,
  # never 404) before the deploy may report success.
  local deadline=$(( $(date +%s) + HEALTH_TIMEOUT ))
  until health_ok "$BINARY_SHA" "$release_bin" 1 "$VERSION" "$REVISION" 1 ${names[@]+"${names[@]}"}; do
    [ "$(date +%s)" -lt "$deadline" ] || do_rollback
    sleep 2
  done
  activation_routes_ok "$DOMAIN" || do_rollback

  # --- 7. D13 IMDS: A is enforced by the audited IPAddressDeny; B re-probed --
  if [ "$imds_strategy" = firewall ]; then
    if "$RUNUSER_BIN" -u "$SERVICE_USER" -- "$HELPERS_DIR/imds-probe.sh"; then
      probe_rc=0
    else
      probe_rc=$?
    fi
    if imds_protected "$probe_rc" "$imds_control_rc"; then
      log "IMDS probe under service uid: protected (firewall strategy)"
    else
      log "IMDS probe under service uid rc=$probe_rc: protection NOT proven — refusing rollout (D13)"
      do_rollback
    fi
  fi
  health_passed=1
  trap - ERR
  trap cleanup EXIT

  # --- 8. DAC audit, record state atomically, prune, report --------------------
  verify_runtime_ownership "$release_bin" || do_rollback

  atomic_write "$STATE_FILE" <<EOF
CURRENT_SHA=$ARCHIVE_SHA
CURRENT_BINARY_SHA=$BINARY_SHA
CURRENT_RELEASE=$release_dir
CURRENT_VERSION=$VERSION
CURRENT_REVISION=$REVISION
CURRENT_ACTIVATION=1
PREVIOUS_SHA=${current_sha:-none}
PREVIOUS_BINARY_SHA=${current_binary:-none}
PREVIOUS_RELEASE=${current_release:-none}
PREVIOUS_VERSION=${current_version:-none}
PREVIOUS_REVISION=${current_revision:-none}
PREVIOUS_ACTIVATION=$current_activation
UPDATED_AT=$(date +%s)
EOF
  chmod 0644 "$STATE_FILE"

  # Prune old releases; never touch current, previous or the legacy copy.
  if [ -d "$RELEASE_ROOT" ]; then
    local dir
    for dir in $(ls -1t "$RELEASE_ROOT" 2>/dev/null | tail -n +$((KEEP_RELEASES + 1))); do
      case "$dir" in
        "$ARCHIVE_SHA"|"${current_sha:-__}") continue;;
        [0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f][0-9a-f]*) rm -rf "${RELEASE_ROOT:?}/$dir";;
      esac
    done
  fi

  log "deploy OK: version=$VERSION revision=$REVISION archive=$ARCHIVE_SHA binary=$BINARY_SHA imds=$imds_strategy ExecStart: $new_exec"
  printf 'sha256=%s\nbinary-sha256=%s\nversion=%s\ncommit=%s\nhealthz=ok\nregistry=enabled\ntunnel=enabled\nimds=%s\nhealth=ok\nrollback=none\nprevious=%s\n' \
    "$ARCHIVE_SHA" "$BINARY_SHA" "$VERSION" "$REVISION" "$imds_strategy" "${current_sha:-none}"
}

main "$@"
