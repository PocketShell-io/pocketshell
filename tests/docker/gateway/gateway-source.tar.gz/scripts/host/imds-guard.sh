#!/bin/sh
# UID-scoped IMDS guard (strategy B), run by the unit as root:
#   ExecStartPre=+/usr/local/lib/pocketshell-gateway/imds-guard.sh <user>
# REJECTs only this uid's OUTPUT to the IMDS endpoints (IPv6 only when the
# host has IPv6); rules are re-installed at every start (reboot-safe).
#   imds-guard.sh --check <user>: read-only PREFLIGHT — tools present AND
# functional. The installer never activates B unless it passes (incident
# 2026-10-09: AL2023 has no iptables/nft; the guard crash-looped with 127).
# Tools resolve ONLY on IMDS_GUARD_PATH (fixed system path; harness seam).
# Exit: 0 ok; 1 usage/apply/functional failure; 127 tool missing.
set -eu

GUARD_PATH=${IMDS_GUARD_PATH:-/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin}

mode=apply
if [ "${1:-}" = --check ]; then
  mode=check
  shift
fi
[ $# -ge 1 ] || { echo "usage: imds-guard.sh [--check] <service-user>" >&2; exit 1; }
SERVICE_USER=$1
UID_N=$(id -u "$SERVICE_USER")

resolve() { # $1 = tool name -> absolute path on GUARD_PATH (first match)
  _rest=$GUARD_PATH
  while [ -n "$_rest" ]; do
    _dir=${_rest%%:*}
    case "$_rest" in *:*) _rest=${_rest#*:} ;; *) _rest='' ;; esac
    case "$_dir" in /*) ;; *) continue ;; esac # relative entries never count
    if [ -f "$_dir/$1" ] && [ -x "$_dir/$1" ]; then
      printf '%s\n' "$_dir/$1"
      return 0
    fi
  done
  return 1
}

need() { # $1 = tool name -> path, or exit 127 naming what is missing
  resolve "$1" || {
    echo "imds-guard: $1 not found on $GUARD_PATH — uid-firewall IMDS strategy unavailable" >&2
    exit 127
  }
}

IPT=$(need iptables)
IP6T=''
if [ -e /proc/net/if_inet6 ]; then
  IP6T=$(need ip6tables)
fi

if [ "$mode" = check ]; then
  # Functional, read-only: the binary must actually reach the kernel's
  # filter table (a present-but-broken iptables is as useless as none).
  "$IPT" -w -S OUTPUT >/dev/null ||
    { echo "imds-guard: $IPT cannot read the OUTPUT chain" >&2; exit 1; }
  if [ -n "$IP6T" ]; then
    "$IP6T" -w -S OUTPUT >/dev/null ||
      { echo "imds-guard: $IP6T cannot read the OUTPUT chain" >&2; exit 1; }
  fi
  exit 0
fi

ipt() { # $1 = binary, $2 = destination CIDR
  if "$1" -w -C OUTPUT -m owner --uid-owner "$UID_N" -d "$2" -j REJECT >/dev/null 2>&1; then
    return 0
  fi
  "$1" -w -I OUTPUT 1 -m owner --uid-owner "$UID_N" -d "$2" -j REJECT
}

ipt "$IPT" 169.254.169.254/32

if [ -n "$IP6T" ]; then
  ipt "$IP6T" fd00:ec2::254/128
fi
