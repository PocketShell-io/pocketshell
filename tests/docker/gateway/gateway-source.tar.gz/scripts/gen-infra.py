#!/usr/bin/env python3
"""Regenerate the host script embedded in infra/github-actions.yaml.

`make infra` runs this. scripts/host/install-deploy.sh is the single source
of truth for on-instance deploy logic; the block between the generated
markers inside the `pocketshell-gateway-deploy` SSM document must never be
edited by hand — a contract test fails if it drifts from the .sh file.

The transform retains the installer body, trusted helper provisioning and
verbatim helper payloads in their original execution order, then main "$@".
A deterministic gzip/base64 envelope carries this exact UTF-8 body below the
SSM 64KiB document limit. The outer wrapper stages only in a private root-owned
/run directory, bounds decompression, verifies exact length and SHA256, then
runs /bin/bash on the decoded body. SSM parameter substitutions remain visible
in the wrapper; they are never hidden in the compressed payload. Child traps
and exit status remain separate from staging cleanup in the wrapper.

"""

from __future__ import annotations

import base64
import gzip
import hashlib
import io
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
SRC = ROOT / "scripts" / "host" / "install-deploy.sh"
PROVISION = ROOT / "scripts" / "host" / "provision-helpers.sh"
DST = ROOT / "infra" / "github-actions.yaml"
INDENT = " " * 18
BEGIN = "# ==== BEGIN generated from scripts/host/install-deploy.sh - regenerate with `make infra`; do not edit this block ===="
END = "# ==== END generated ===="

INVOCATION = [
    "",
    "# ---- deployment invocation (every value constrained by allowedPattern above) ----",
    "main \\",
    '  --bucket "{{Bucket}}" \\',
    '  --artifact-path "{{ArtifactPath}}" \\',
    '  --archive-sha256 "{{ExpectedSHA256}}" \\',
    '  --binary-sha256 "{{BinarySHA256}}" \\',
    '  --version "{{Version}}" \\',
    '  --revision "{{Revision}}" \\',
    '  --domain "{{Domain}}" \\',
    '  --aliases "{{Aliases}}" \\',
    '  --service "{{ServiceName}}" \\',
    '  --service-user "{{ServiceUser}}" \\',
    '  --health-timeout "{{HealthTimeoutSeconds}}" \\',
    '  --certdir "{{CertDir}}" \\',
    '  --registry "{{RegistryFile}}"',
]

# The installer refuses to run without the two IMDS helpers in place
# ("IMDS helpers missing"), so the document provisions them — verbatim from
# the sources — in the same runCommand, BEFORE `main` executes. The preamble
# (embedded first) validates the target chain and stages + renames
# atomically; nothing here writes through a symlink or mutates an ancestor.
HELPERS_DIR = "/usr/local/lib/pocketshell-gateway"
HELPER_EOF = "POCKETSHHELL_GATEWAY_HELPER_EOF"

VERBATIM_SOURCES = (SRC, PROVISION)


def read_verbatim(src: pathlib.Path) -> list[str]:
    text = src.read_text()
    if "\t" in text:
        sys.exit(f"{src}: tab characters are not allowed (YAML block-scalar hygiene)")
    if HELPER_EOF in text:
        sys.exit(f"{src}: heredoc delimiter collision")
    lines = text.rstrip("\n").splitlines()
    while lines and not lines[-1].strip():
        lines.pop()
    return lines


def helper_block(path: str, install_as: str) -> list[str]:
    src = ROOT / "scripts" / "host" / path
    lines = read_verbatim(src)
    return [
        "",
        f"# ---- {install_as} payload (generated from scripts/host/{path}; installed by helper_install below; do not edit) ----",
        # The destination is the preamble's HELPERS_DIR shell variable (fixed
        # default /usr/local/lib/pocketshell-gateway; env seams exist only for
        # the behavioral harness) — never a literal baked in at generation
        # time, so the whole provisioning path has exactly one source of truth.
        f'helper_install "$HELPERS_DIR/{install_as}" <<\'{HELPER_EOF}\'',
        *lines,
        HELPER_EOF,
    ]


def helpers_install_block() -> list[str]:
    return (
        [""]
        + ["# ---- IMDS helpers: trusted provisioning BEFORE the deploy body's main() runs (the installer refuses without them) ----"]
        + ["# preamble generated verbatim from scripts/host/provision-helpers.sh: validate first, mutate last, never follow a symlink"]
        + read_verbatim(PROVISION)
        + helper_block("imds-probe.sh", "imds-probe.sh")
        + helper_block("imds-guard.sh", "imds-guard.sh")
    )


PAYLOAD_EOF = "POCKETSHELL_DEPLOY_GZIP_BASE64"


def trusted_payload() -> bytes:
    lines = read_verbatim(SRC)
    if lines[-1] != 'main "$@"':
        sys.exit(f'{SRC}: last line must be exactly main "$@"')
    # Keep every trusted source line and provisioning order; parameters are
    # deliberately outside this blob so SSM can constrain and substitute them.
    return ("\n".join(lines[:-1] + helpers_install_block() + INVOCATION[:2] + ['main "$@"']) + "\n").encode("utf-8")


def envelope(payload: bytes) -> list[str]:
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode="wb", filename="", mtime=0, compresslevel=9) as gz:
        gz.write(payload)
    encoded = base64.b64encode(compressed.getvalue()).decode("ascii")
    digest = hashlib.sha256(payload).hexdigest()
    # SSM runs shell commands with /bin/sh. Enter bash explicitly; the outer
    # shell owns no temporary files, while this wrapper owns its private staging
    # directory and the decoded child retains all its original traps unchanged.
    invocation = INVOCATION[3:].copy()
    invocation[-1] += " &"
    return [
        "/bin/bash -s <<'POCKETSHELL_DEPLOY_WRAPPER'",
        "set -euo pipefail",
        "umask 077",
        "[ \"$(id -u)\" = 0 ] || { echo 'deployment envelope requires root' >&2; exit 1; }",
        "for ancestor in / /run; do",
        "  [ -d \"$ancestor\" ] && [ ! -L \"$ancestor\" ] || exit 1",
        "  owner_mode=$(stat -c '%u:%a' -- \"$ancestor\")",
        "  [[ $owner_mode =~ ^0:([0-7]{3,4})$ ]] || exit 1",
        "  (( (8#${BASH_REMATCH[1]} & 0022) == 0 )) || exit 1",
        "done",
        "stage=$(mktemp -d /run/pocketshell-deploy.XXXXXXXXXXXX)",
        "cleanup() { rm -rf -- \"$stage\"; }",
        "trap cleanup EXIT",
        "child=''",
        "forward_signal() {",
        "  trap '' INT TERM",
        "  if [ -n \"$child\" ]; then",
        "    # Background bash ignores INT; cancellation uses TERM for either signal.",
        "    kill -TERM \"$child\" 2>/dev/null || true",
        "    for ((attempt=0; attempt<50; attempt++)); do",
        "      kill -0 \"$child\" 2>/dev/null || break",
        "      sleep 0.1",
        "    done",
        "    kill -KILL \"$child\" 2>/dev/null || true",
        "    wait \"$child\" || true",
        "  fi",
        "  exit \"$2\"",
        "}",
        "trap 'forward_signal TERM 130' INT",
        "trap 'forward_signal TERM 143' TERM",
        "payload=\"$stage/deploy.sh\"",
        f"if ! base64 --decode <<'{PAYLOAD_EOF}' | gzip --decompress | head -c {len(payload) + 1} >\"$payload\"; then",
        encoded,
        PAYLOAD_EOF,
        "  echo 'deployment envelope decode failed' >&2; exit 1",
        "fi",
        f"[ \"$(wc -c <\"$payload\")\" -eq {len(payload)} ] || {{ echo 'deployment envelope size mismatch' >&2; exit 1; }}",
        f"[ \"$(sha256sum -- \"$payload\" | cut -d ' ' -f 1)\" = {digest} ] || {{ echo 'deployment envelope hash mismatch' >&2; exit 1; }}",
        "# Original deployment parameters remain visible to SSM substitution.",
        '/bin/bash "$payload" \\',
        *invocation,
        "child=$!",
        "status=0",
        "wait \"$child\" || status=$?",
        "exit \"$status\"",
        "POCKETSHELL_DEPLOY_WRAPPER",
    ]


def decode_embedded(command: str) -> bytes:
    # Test/inspection path verifies the actual committed wrapper's payload,
    # rather than silently regenerating a second equivalent copy.
    lines = command.splitlines()
    start = next(i for i, line in enumerate(lines) if line.startswith("if ! base64 --decode <<'" + PAYLOAD_EOF + "'"))
    end = lines.index(PAYLOAD_EOF, start + 1)
    return gzip.decompress(base64.b64decode("".join(lines[start + 1:end]), validate=True))


def embedded_block() -> list[str]:
    out = [BEGIN] + envelope(trusted_payload()) + [END]
    return [INDENT + line if line else "" for line in out]


def main() -> None:
    block = embedded_block()
    dst_lines = DST.read_text().splitlines()
    begin_idx = end_idx = None
    for i, line in enumerate(dst_lines):
        stripped = line.strip()
        if stripped == BEGIN and begin_idx is None:
            begin_idx = i
        elif stripped == END:
            end_idx = i
            break
    if begin_idx is None or end_idx is None:
        sys.exit(f"{DST}: generated markers not found (expected BEGIN/END inside runCommand block)")
    # The block carries its own BEGIN/END marker lines; replace the whole
    # inclusive range so repeated runs stay idempotent.
    out = dst_lines[:begin_idx] + block + dst_lines[end_idx + 1 :]
    DST.write_text("\n".join(out) + "\n")
    print(f"embedded {len(block) - 2} script lines into {DST.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
