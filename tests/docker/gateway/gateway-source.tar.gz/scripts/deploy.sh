#!/usr/bin/env bash
# PocketShell gateway — CI/deployer-side deploy driver.
#
# Called by .github/workflows/deploy.yml (GitHub OIDC credentials) and
# runnable by an operator with equivalent credentials. Complements
# scripts/host/install-deploy.sh, which runs ON the instance via the
# pocketshell-gateway-deploy SSM document:
#
#   1. Cross-check the build/dist artifact set (archive, VERSION,
#      sha256sums.txt and the digest-bound manifest.json) against freshly
#      computed digests — build/driver drift fails before anything is sent.
#   2. Upload to digest-addressed keys under artifacts/ with IfNoneMatch:*
#      (D10): an existing object must byte-match this upload (identical
#      retry) or the deploy fails — overwrites and substitutions are
#      impossible through this path.
#   3. Invoke the bounded SSM document with string-ARRAY parameters (D7),
#      wait to a terminal status, distinguishing eventual-consistency
#      (InvocationDoesNotExist — bounded retry) from permanent API errors
#      (fail fast with a clear message).
#   4. Verify the instance's StandardOutputContent echoes both digests, the
#      version and health=ok/rollback=none (D7/D8). rollback=ok is a FAILED
#      deploy (old binary serving) so the workflow goes red; rollback=failed
#      is a page-a-human exit code 2.
set -Eeuo pipefail

log() { printf '[deploy] %s\n' "$*"; }
die() { printf '[deploy] FATAL: %s\n' "$*" >&2; exit "${2:-1}"; }

REGION=eu-west-1
BUCKET='' INSTANCE_ID=''
DOCUMENT=arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-deploy
DOCUMENT_OWNER=
DOCUMENT_VERSION=
DOCUMENT_SHA256=
DOMAIN=gateway.pocketshell.io
ALIASES=relay.pocketshell.io
SERVICE=pocketshell-relay
SERVICE_USER=pocketshell-gateway
# Activation configuration, carried explicitly with every deploy: the
# -certdir base (both binaries keep the autocert cache under <certdir>/certs)
# and the -registry STATE FILE (Go initializes it; the on-instance installer
# never pre-creates or resets it). Pinned to the bootstrap values, mirrored
# in the digest-bound manifest and re-validated by the installer.
CERT_DIR=/var/lib/pocketshell-relay
REGISTRY_FILE=/var/lib/pocketshell-relay/registry/devices.json
HEALTH_TIMEOUT=180
ARTIFACT_DIR=build/dist
VERSION=
REVISION=
DRY_RUN=0

while [ $# -gt 0 ]; do
  case "$1" in
    --region) REGION=$2; shift 2;;
    --bucket) BUCKET=$2; shift 2;;
    --instance-id) INSTANCE_ID=$2; shift 2;;
    --document) DOCUMENT=$2; shift 2;;
    --document-owner) DOCUMENT_OWNER=$2; shift 2;;
    --document-version) DOCUMENT_VERSION=$2; shift 2;;
    --document-sha256) DOCUMENT_SHA256=$2; shift 2;;
    --domain) DOMAIN=$2; shift 2;;
    --aliases) ALIASES=$2; shift 2;;
    --service) SERVICE=$2; shift 2;;
    --service-user) SERVICE_USER=$2; shift 2;;
    --certdir) CERT_DIR=$2; shift 2;;
    --registry) REGISTRY_FILE=$2; shift 2;;
    --health-timeout) HEALTH_TIMEOUT=$2; shift 2;;
    --artifact-dir) ARTIFACT_DIR=$2; shift 2;;
    --version) VERSION=$2; shift 2;;
    --revision) REVISION=$2; shift 2;;
    --dry-run) DRY_RUN=1; shift;;
    *) die "unknown argument: $1";;
  esac
done

for tool in aws jq sha256sum; do command -v "$tool" >/dev/null || die "missing tool: $tool"; done
[ -n "$BUCKET" ] || die "--bucket required"
[ -n "$INSTANCE_ID" ] || die "--instance-id required"
printf '%s' "$DOCUMENT_OWNER" | grep -Eq '^[0-9]{12}$' || die "--document-owner must be the reviewed 12-digit account"
printf '%s' "$DOCUMENT_VERSION" | grep -Eq '^[1-9][0-9]{0,9}$' || die "--document-version must be a reviewed numeric version (no aliases)"
printf '%s' "$DOCUMENT_SHA256" | grep -Eq '^[0-9a-f]{64}$' || die "--document-sha256 must be the reviewed SHA256 hash"
DOCUMENT_NAME=${DOCUMENT##*:document/}
printf '%s' "$DOCUMENT_NAME" | grep -Eq '^[A-Za-z0-9_.-]{3,128}$' || die "bad document name"
[ "$DOCUMENT" = "arn:aws:ssm:$REGION:$DOCUMENT_OWNER:document/$DOCUMENT_NAME" ] || die "--document must be the full custom document ARN in the expected region/account"
printf '%s' "$INSTANCE_ID" | grep -Eq '^i-[0-9a-f]{8,17}$' || die "instance id must look like i-0123456789abcdef"
printf '%s' "$HEALTH_TIMEOUT" | grep -Eq '^[0-9]{1,3}$' || die "bad health timeout"
printf '%s' "$SERVICE_USER" | grep -Eq '^[a-z_][a-z0-9_-]{0,31}$' || die "bad service user: $SERVICE_USER"
printf '%s' "$CERT_DIR" | grep -Eq '^/[A-Za-z0-9][A-Za-z0-9/._-]*$' || die "bad certdir: $CERT_DIR"
printf '%s' "$REGISTRY_FILE" | grep -Eq '^/[A-Za-z0-9][A-Za-z0-9/._-]*$' || die "bad registry: $REGISTRY_FILE"
[ "$REGISTRY_FILE" = "$CERT_DIR/registry/devices.json" ] || die "registry file must live at <certdir>/registry/devices.json (got $REGISTRY_FILE)"

ARCHIVE="$ARTIFACT_DIR/gateway-linux-arm64.gz"
[ -f "$ARCHIVE" ] || die "archive not found: $ARCHIVE (run: make artifacts)"
ARCHIVE_SHA=$(sha256sum "$ARCHIVE" | awk '{print $1}')
[ ${#ARCHIVE_SHA} = 64 ] || die "could not hash archive"

if [ -z "$VERSION" ]; then
  VERSION="git-$(git rev-parse --short=12 HEAD 2>/dev/null || echo unknown)"
  [ "$VERSION" != "git-unknown" ] || die "--version required outside a git checkout"
fi
printf '%s' "$VERSION" | grep -Eq '^[A-Za-z0-9][A-Za-z0-9._+-]{0,63}$' || die "bad version: $VERSION"

# Source revision: verified on the instance against the manifest AND against
# the running application's /healthz commit (D8).
if [ -z "$REVISION" ]; then
  REVISION=$(git rev-parse HEAD 2>/dev/null || echo unknown)
  [ "$REVISION" != "unknown" ] || die "--revision required outside a git checkout"
fi
printf '%s' "$REVISION" | grep -Eq '^[0-9a-f]{7,40}$' || die "bad revision: $REVISION"

tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

log "deployer identity: $(aws --region "$REGION" sts get-caller-identity --output json | jq -r '.Arn')"
log "artifact: $ARCHIVE archive-sha256=$ARCHIVE_SHA version=$VERSION"

# Verify the independently reviewed document pin, not a hash learned from
# this response. No S3 Put or command may happen before this read-only guard.
if ! aws --region "$REGION" ssm describe-document --name "$DOCUMENT" \
    --document-version "$DOCUMENT_VERSION" --output json >"$tmp/document.json" 2>"$tmp/document.err"; then
  die "DescribeDocument preflight failed; no artifact uploaded or command sent"
fi
if ! jq -e --arg name "$DOCUMENT_NAME" --arg arn "$DOCUMENT" --arg owner "$DOCUMENT_OWNER" \
    --arg version "$DOCUMENT_VERSION" --arg hash "$DOCUMENT_SHA256" '
    .Document | type == "object" and (.Name == $name or .Name == $arn) and .Owner == $owner
    and .Status == "Active" and .DocumentType == "Command"
    and .DocumentVersion == $version and .HashType == "Sha256" and .Hash == $hash
    ' "$tmp/document.json" >/dev/null 2>&1; then
  die "SSM document metadata does not match reviewed Active Command owner/version/SHA256 pin"
fi
log "document preflight: owner=$DOCUMENT_OWNER version=$DOCUMENT_VERSION sha256=$DOCUMENT_SHA256"

# --- 1. sidecars: recompute and cross-check (build/driver drift fails here) --
BINARY_SHA=$(gzip -dc "$ARCHIVE" | sha256sum | awk '{print $1}')
[ ${#BINARY_SHA} = 64 ] || die "could not hash unpacked binary"
if [ -f "$ARTIFACT_DIR/VERSION" ]; then
  sidecar_version=$(tr -d ' \t\n\r' <"$ARTIFACT_DIR/VERSION")
  [ "$sidecar_version" = "$VERSION" ] || die "VERSION sidecar ($sidecar_version) != requested version ($VERSION) — pass --version consistently or rebuild"
fi

if [ -f "$ARTIFACT_DIR/manifest.json" ]; then
  manifest_field() { grep -o "\"$1\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" "$ARTIFACT_DIR/manifest.json" | head -1 | sed "s/.*:[[:space:]]*\"//; s/\"$//"; }
  [ "$(manifest_field archive_sha256)" = "$ARCHIVE_SHA" ] || die "manifest archive_sha256 drift"
  [ "$(manifest_field binary_sha256)" = "$BINARY_SHA" ] || die "manifest binary_sha256 drift"
  [ "$(manifest_field version)" = "$VERSION" ] || die "manifest version drift"
  [ "$(manifest_field certdir)" = "$CERT_DIR" ] || die "manifest certdir drift (activation configuration)"
  [ "$(manifest_field registry)" = "$REGISTRY_FILE" ] || die "manifest registry drift (activation configuration)"
else
  log "building digest-bound manifest"
  jq -n --arg a "$ARCHIVE_SHA" --arg b "$BINARY_SHA" --arg v "$VERSION" \
    --arg rev "$(git rev-parse HEAD 2>/dev/null || echo unknown)" \
    --arg dom "$DOMAIN" --arg al "$ALIASES" --arg svc "$SERVICE" \
    --arg certdir "$CERT_DIR" --arg registry "$REGISTRY_FILE" \
    --arg at "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    '{archive_sha256:$a, binary_sha256:$b, version:$v, source_revision:$rev, domain:$dom, aliases:$al, service:$svc, certdir:$certdir, registry:$registry, built_at:$at}' \
    >"$ARTIFACT_DIR/manifest.json"
fi
printf '%s  gateway-linux-arm64.gz\n' "$ARCHIVE_SHA" >"$ARTIFACT_DIR/sha256sums.txt"

# --- 2. immutable digest-addressed uploads (D10) ------------------------------
put_if_absent() { # $1 = local file, $2 = key; identical retry allowed, overwrite refused
  local local_file=$1 key=$2 remote
  if aws --region "$REGION" s3api put-object \
    --bucket "$BUCKET" --key "$key" --body "$local_file" \
    --if-none-match '*' >/dev/null 2>"$tmp/put.err"; then
    log "uploaded s3://$BUCKET/$key"
    return 0
  fi
  if ! grep -q "PreconditionFailed" "$tmp/put.err"; then
    cat "$tmp/put.err" >&2
    die "upload of $key failed (not a precondition conflict)"
  fi
  log "s3://$BUCKET/$key already exists — verifying byte-identical retry"
  remote="$tmp/remote.$(basename "$key")"
  aws --region "$REGION" s3api get-object --bucket "$BUCKET" --key "$key" "$remote" >/dev/null ||
    die "existing object $key could not be fetched for retry verification"
  if cmp -s "$local_file" "$remote"; then
    log "identical retry accepted for $key"
  else
    die "CONFLICT: s3://$BUCKET/$key exists with different content — digest-addressed artifacts are immutable; refusing to overwrite"
  fi
}

put_if_absent "$ARCHIVE" "artifacts/$ARCHIVE_SHA/gateway-linux-arm64.gz"
put_if_absent "$ARTIFACT_DIR/VERSION" "artifacts/$ARCHIVE_SHA/VERSION"
put_if_absent "$ARTIFACT_DIR/manifest.json" "artifacts/$ARCHIVE_SHA/manifest.json"
put_if_absent "$ARTIFACT_DIR/sha256sums.txt" "artifacts/$ARCHIVE_SHA/sha256sums.txt"

# --- 3. invoke the bounded document (string-array parameters, D7) -------------
PARAMS=$(jq -n \
  --arg bucket "$BUCKET" \
  --arg path "artifacts/$ARCHIVE_SHA/gateway-linux-arm64.gz" \
  --arg sha "$ARCHIVE_SHA" \
  --arg bsha "$BINARY_SHA" \
  --arg version "$VERSION" \
  --arg revision "$REVISION" \
  --arg domain "$DOMAIN" \
  --arg aliases "$ALIASES" \
  --arg service "$SERVICE" \
  --arg service_user "$SERVICE_USER" \
  --arg timeout "$HEALTH_TIMEOUT" \
  --arg certdir "$CERT_DIR" \
  --arg registry "$REGISTRY_FILE" \
  '{Bucket:[$bucket], ArtifactPath:[$path], ExpectedSHA256:[$sha], BinarySHA256:[$bsha], Version:[$version], Revision:[$revision], Domain:[$domain], Aliases:[$aliases], ServiceName:[$service], ServiceUser:[$service_user], HealthTimeoutSeconds:[$timeout], CertDir:[$certdir], RegistryFile:[$registry]}')

if [ "$DRY_RUN" = "1" ]; then
  log "dry-run: would invoke $DOCUMENT on $INSTANCE_ID with:"
  printf '%s\n' "$PARAMS" | jq .
  exit 0
fi

log "invoking SSM document $DOCUMENT on $INSTANCE_ID"
aws --region "$REGION" ssm send-command \
  --instance-ids "$INSTANCE_ID" \
  --document-name "$DOCUMENT" \
  --document-version "$DOCUMENT_VERSION" \
  --document-hash "$DOCUMENT_SHA256" \
  --document-hash-type Sha256 \
  --comment "pocketshell-gateway $VERSION" \
  --parameters "$PARAMS" \
  --output json >"$tmp/send.json"
COMMAND_ID=$(jq -r '.Command.CommandId' "$tmp/send.json")
[ -n "$COMMAND_ID" ] && [ "$COMMAND_ID" != "null" ] || { cat "$tmp/send.json"; die "send-command returned no CommandId"; }
log "command id: $COMMAND_ID (waiting; install+health may take a few minutes)"

# Poll to a terminal status, bounded (~30 min; the document itself times out
# at 30). InvocationDoesNotExist right after send-command is eventual
# consistency — retry briefly. Permanent API errors fail immediately (D7).
STATUS=Pending
invocation_json() {
  aws --region "$REGION" ssm get-command-invocation \
    --command-id "$COMMAND_ID" --instance-id "$INSTANCE_ID" \
    --output json 2>"$tmp/inv.err"
}
not_exist=0
# Poll bounds are env-overridable for the API harness; production defaults
# give ~30 minutes of eventual-consistency tolerance.
POLL_ATTEMPTS=${DEPLOY_POLL_ATTEMPTS:-180}
POLL_SLEEP=${DEPLOY_POLL_SLEEP:-10}
for _ in $(seq 1 "$POLL_ATTEMPTS"); do
  if OUT=$(invocation_json); then
    STATUS=$(printf '%s' "$OUT" | jq -r '.Status')
    printf '%s' "$OUT" >"$tmp/inv.json"
  else
    if grep -q "InvocationDoesNotExist" "$tmp/inv.err"; then
      not_exist=$((not_exist + 1))
      [ "$not_exist" -le 30 ] || die "command $COMMAND_ID still unknown after 5 minutes of retries — aborting"
      STATUS=Pending
    elif grep -Eq "AccessDenied|AuthorizationError|OptInRequired|InvalidDocument|InvalidInstanceId|Throttling" "$tmp/inv.err"; then
      printf '[deploy] FATAL: permanent SSM API error:\n%s\n' "$(cat "$tmp/inv.err")" >&2
      exit 1
    else
      log "transient SSM API error (retrying): $(head -c 300 "$tmp/inv.err")"
      STATUS=Pending
    fi
  fi
  case "$STATUS" in
    Pending|InProgress|Delayed) sleep "$POLL_SLEEP";;
    *) break;;
  esac
done

echo "---- instance output -------------------------------------------"
aws --region "$REGION" ssm get-command-invocation \
  --command-id "$COMMAND_ID" --instance-id "$INSTANCE_ID" \
  --query '[Status,StandardOutputContent,StandardErrorContent]' --output text || true
echo "----------------------------------------------------------------"

case "$STATUS" in
  Success)
    OUTPUT=$(aws --region "$REGION" ssm get-command-invocation \
      --command-id "$COMMAND_ID" --instance-id "$INSTANCE_ID" \
      --query StandardOutputContent --output text)
    printf '%s\n' "$OUTPUT" >"$tmp/out.txt"
    grep -q "^sha256=$ARCHIVE_SHA$" "$tmp/out.txt" || die "instance did not confirm archive sha256=$ARCHIVE_SHA"
    grep -q "^binary-sha256=$BINARY_SHA$" "$tmp/out.txt" || die "instance did not confirm binary sha256=$BINARY_SHA"
    grep -q "^version=$VERSION$" "$tmp/out.txt" || die "instance did not confirm version=$VERSION"
    grep -q "^commit=$REVISION$" "$tmp/out.txt" || die "instance did not confirm commit=$REVISION"
    if grep -q '^health=ok$' "$tmp/out.txt" && grep -q '^rollback=none$' "$tmp/out.txt" &&
      grep -q '^healthz=ok$' "$tmp/out.txt" && grep -q '^registry=enabled$' "$tmp/out.txt" &&
      grep -q '^tunnel=enabled$' "$tmp/out.txt" && grep -Eq '^imds=(systemd|firewall)$' "$tmp/out.txt"; then
      log "DEPLOY OK: $VERSION ($REVISION, archive $ARCHIVE_SHA) live on $DOMAIN (alias: $ALIASES); identity/tunnel ACTIVATED (registry+tunnel enabled, routes mounted); IMDS protection: $(grep -oE '^imds=.*' "$tmp/out.txt")"
      exit 0
    elif grep -q '^health=failed$' "$tmp/out.txt" && grep -q '^rollback=ok$' "$tmp/out.txt"; then
      die "deploy FAILED and was rolled back — previous binary is serving; see instance output above" 1
    else
      die "instance output did not report a clean result; see instance output above" 1
    fi
    ;;
  Failed|Cancelled|TimedOut)
    die "SSM command terminal status: $STATUS (rollback ran on-instance if the unit was already touched)" 1
    ;;
  *)
    die "SSM command did not reach a terminal state in time (last: $STATUS)" 1
    ;;
esac
