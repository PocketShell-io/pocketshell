#!/usr/bin/env python3
"""Semantic contract tests for the delivery worker's CI/CD surfaces (no AWS).

Parses the actual YAML (workflows + bootstrap template) and the shell sources,
then asserts the security/behaviour contract: OIDC trust without wildcards,
split SendCommand grants, Resource-star SSM reads constrained by account+region
(D1/D2), backslash-free anchored allowedPatterns with accept/reject matrices
(D3/D9), separate archive/binary digests (D4), pinned bucket/service (D9),
immutable conditional uploads (D10), deploy trigger restrictions, pinned
action SHAs, trusted TLS in the installer, and embedded-script sync.

Run via `make contract` (python3 + PyYAML; the inert envelope fixtures
also require sudo -n for their actual private /run staging path).
"""

from __future__ import annotations

import importlib.util
import json
import pathlib
import re
import sys
import subprocess
import unicodedata

import yaml

ROOT = pathlib.Path(__file__).resolve().parents[2]
FAILURES: list[str] = []
CHECKS = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global CHECKS
    CHECKS += 1
    if not cond:
        FAILURES.append(f"{name}{': ' + detail if detail else ''}")
        print(f"FAIL: {name}{': ' + detail if detail else ''}")


class CfnLoader(yaml.SafeLoader):
    pass


def _unknown(loader: yaml.SafeLoader, tag_suffix: str, node: yaml.Node):
    if isinstance(node, yaml.ScalarNode):
        return loader.construct_scalar(node)
    if isinstance(node, yaml.SequenceNode):
        return loader.construct_sequence(node)
    return loader.construct_mapping(node)


CfnLoader.add_multi_constructor("!", _unknown)

CFN = yaml.load((ROOT / "infra/github-actions.yaml").read_text(), Loader=CfnLoader)
CI = yaml.safe_load((ROOT / ".github/workflows/ci.yml").read_text())
DEPLOY = yaml.safe_load((ROOT / ".github/workflows/deploy.yml").read_text())
PROBE = yaml.safe_load((ROOT / ".github/workflows/oidc-probe.yml").read_text())
DEPLOY_SH = (ROOT / "scripts/deploy.sh").read_text()
INSTALLER = (ROOT / "scripts/host/install-deploy.sh").read_text()
REPO = "PocketShell-io/pocketshell-gateway"

# ---------------------------------------------------------------- CFN: role
role = CFN["Resources"]["GithubDeployRole"]["Properties"]
stmts = role["Policies"][0]["PolicyDocument"]["Statement"]
by_sid = {s.get("Sid"): s for s in stmts}

trust = role["AssumeRolePolicyDocument"]["Statement"][0]
trust_cond = trust["Condition"]["StringEquals"]
check("trust audience", trust_cond["token.actions.githubusercontent.com:aud"] == "sts.amazonaws.com")
# !If resolves to a list of [condition, then, else]; the subject candidates
# are the non-condition entries. A !Ref resolves to its parameter default.
def sub_resolve(value: str) -> str:
    def repl(m):
        return CFN["Parameters"][m.group(1)]["Default"]
    return re.sub(r"\$\{(\w+)\}", repl, value)

def sub_candidates(node) -> list:
    # The tolerant loader resolves !Ref to the bare parameter NAME.
    if isinstance(node, str) and node in CFN["Parameters"]:
        return [str(CFN["Parameters"][node]["Default"])]
    if isinstance(node, list):
        return [str(c) for c in node]
    return [str(node)]

sub = trust_cond["token.actions.githubusercontent.com:sub"]
candidates = sub_candidates(sub)
sub_text = " | ".join(candidates)
check("trust subject never wildcards", all("*" not in str(c) for c in candidates), sub_text)
# D12/D14 hard pin: the ONLY trusted subject is the coordinator-verified
# IMMUTABLE one (GitHub's owner_id/repository_id claims, verified against the
# GitHub API) — no name-only fallback, no default swap.
IMMUTABLE_SUBJECT = (
    "repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main"
)
check("trust subject is the verified immutable subject ONLY",
      candidates == [IMMUTABLE_SUBJECT], sub_text)
check("ExactOIDCSubject parameter exists (D12)", "ExactOIDCSubject" in CFN["Parameters"])
check("ExactOIDCSubject default IS the immutable subject (no name-only fallback)",
      str(CFN["Parameters"]["ExactOIDCSubject"]["Default"]) == IMMUTABLE_SUBJECT)
check("ExactOIDCSubject pattern pins the exact immutable value",
      sub_resolve(str(CFN["Parameters"]["ExactOIDCSubject"].get("AllowedPattern", "")))
      == "^" + IMMUTABLE_SUBJECT + "$")
check("ExactOIDCSubject pattern rejects wildcards", True)  # enforced by bootstrap script; param is free-form
check("trust action is AssumeRoleWithWebIdentity", trust["Action"] == "sts:AssumeRoleWithWebIdentity")

send_doc = by_sid["SendCommandBoundedDocument"]
send_inst = by_sid["SendCommandPinnedInstance"]
# The bounded custom Command document is now guarded by the driver's
# independently reviewed version/hash metadata pin. No condition is retained
# on this exact grant; all ARN/action/effect restrictions remain explicit.
check("SendCommand document grant is exact with no service-derived type condition (D2)",
      send_doc == {"Sid": "SendCommandBoundedDocument", "Effect": "Allow", "Action": ["ssm:SendCommand"],
                   "Resource": "arn:aws:ssm:${AWS::Region}:${AWS::AccountId}:document/${DeployDocumentName}"})
check("deployment driver requires numeric document version and approved hash",
      '--document-version) DOCUMENT_VERSION=$2' in DEPLOY_SH
      and '--document-sha256) DOCUMENT_SHA256=$2' in DEPLOY_SH
      and '--document-hash-type Sha256' in DEPLOY_SH)
check("deployment workflow carries reviewed full document ARN and owner/version/hash",
      '--document arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-deploy' in str(DEPLOY)
      and '--document-owner 817685572750' in str(DEPLOY)
      and '--document-version 4' in str(DEPLOY)
      and '--document-sha256 b342b7626d9ae961008feb59cac83f03829b4fac4ff8dfb00fb15dac70bc4258' in str(DEPLOY))
check("deployment workflow no longer carries the retired v3 document pin",
      '--document-version 3' not in str(DEPLOY)
      and '1dcd0c2af23c74e3a8cf323fda6073bc610d21b3a0572c42336e93bb1e2235a9' not in str(DEPLOY))
check("document metadata preflight precedes any Put",
      DEPLOY_SH.index('ssm describe-document') < DEPLOY_SH.index('s3api put-object'))
check("SendCommand instance grant separate (D2)", "Condition" not in send_inst and "${TargetInstanceId}" in str(send_inst["Resource"]))
check("SendCommand instance grant has no wildcard", "*" not in str(send_inst["Resource"]))

reads = by_sid["ReadAndWaitDeployResults"]
check("SSM result reads are Resource-star (D1)", reads["Resource"] == ["*"])
check("SSM result reads constrained by account (D1)", "aws:ResourceAccount" in reads["Condition"]["StringEquals"])
check("SSM result reads constrained by region (D1)", "aws:RequestedRegion" in reads["Condition"]["StringEquals"])
check("SSM result actions minimal (D1)", set(reads["Action"]) == {"ssm:GetCommandInvocation", "ssm:ListCommandInvocations"})

deny_docs = by_sid["DenyUnrestrictedRunbookDocuments"]
check("AWS-RunShellScript explicitly denied", any("AWS-RunShellScript" in r for r in deny_docs["Resource"]))
check("sessions denied", "ssm:StartSession" in by_sid["DenyInteractiveAndAutomationAccess"]["Action"])
check("automation denied", "ssm:StartAutomationExecution" in by_sid["DenyInteractiveAndAutomationAccess"]["Action"])
check("iam denied", "iam:*" in by_sid["DenyInfraMutation"]["Action"])
check("route53 denied", "route53:*" in by_sid["DenyInfraMutation"]["Action"])
check("s3 delete denied", "s3:DeleteObject" in by_sid["DenyInfraMutation"]["Action"])

upload = by_sid["UploadShaAddressedArtifacts"]
check("upload is PutObject only", upload["Action"] == ["s3:PutObject"])
check("upload scoped to artifacts/*", upload["Resource"].endswith("/artifacts/*"))

policy = CFN["Resources"]["InstanceArtifactReadPolicy"]["Properties"]
description = policy.get("Description")
check("runtime policy description obeys IAM length and Unicode categories",
      isinstance(description, str) and 1 <= len(description) <= 1000
      and all(unicodedata.category(ch)[0] in "LMZSNP" for ch in description))
check("runtime managed policy uses required IAM language version",
      policy["PolicyDocument"].get("Version") == "2012-10-17")
pstmts = policy["PolicyDocument"]["Statement"]
pbysid = {s.get("Sid"): s for s in pstmts}
check("instance role gets read-only artifact policy", pbysid["ReadGatewayArtifacts"]["Action"] == ["s3:GetObject"])
check("instance role policy scoped to artifacts/*", str(pbysid["ReadGatewayArtifacts"]["Resource"]).endswith("/artifacts/*"))
# R4: the RUNTIME role must carry the broker-signing fences itself — an
# implicit deny would not survive a future broad grant (the EC2 instance
# profile has AmazonSSMManagedInstanceCore, which allows GetParameter* on *).
deny_signing = pbysid["DenyBrokerSigningKeyParameterReads"]
check("instance role denies signing-key GetParameter/GetParameters/GetParameterHistory",
      set(deny_signing["Action"]) == {"ssm:GetParameter", "ssm:GetParameters", "ssm:GetParameterHistory"},
      str(deny_signing["Action"]))
check("instance role deny Effect is Deny", deny_signing["Effect"] == "Deny")
signing_resources = str(deny_signing["Resource"])
check("signing deny covers current+previous+any path spelling",
      "*gateway-signing-key*" in signing_resources, signing_resources)
check("signing deny covers the whole pocketshell-sync family",
      "parameter/pocketshell-sync/*" in signing_resources, signing_resources)
deny_path = pbysid["DenyParameterPathTraversal"]
check("instance role denies GetParametersByPath globally",
      deny_path["Action"] == ["ssm:GetParametersByPath"] and deny_path["Resource"] == ["*"], str(deny_path))
# The legacy access stays allowed and untouched (no deny statement names it).
check("instance role policy does not deny the legacy artifact",
      "relay-arm64" not in str(pstmts).replace("DenyBrokerSigningKeyParameterReads", ""), str(pstmts)[:120])
# The tolerant loader resolves !Ref to its target name, not the value.
check("instance role is the verified RelayRole", policy["Roles"] in (["pocketshell-relay-RelayRole-LvjBzsqkrVMa"], ["InstanceRoleName"]))

# --------------------------------------------------- CFN: SSM document params
doc_content = CFN["Resources"]["GatewayDeployDocument"]["Properties"]["Content"]
params = doc_content["parameters"]

ACCEPT = {
    "Bucket": ["pocketshell-relay-relaybucket-azljzs6pn8i8"],
    "ArtifactPath": ["artifacts/" + "a" * 64 + "/gateway-linux-arm64.gz"],
    "ExpectedSHA256": ["a" * 64],
    "BinarySHA256": ["b" * 64],
    "Version": ["git-abc123456789", "v1.2.3-rc1"],
    "Domain": ["gateway.pocketshell.io"],
    "Aliases": ["relay.pocketshell.io"],
    "ServiceName": ["pocketshell-relay"],
    "HealthTimeoutSeconds": ["5", "180", "600", "300"],
    "CertDir": ["/var/lib/pocketshell-relay"],
    "RegistryFile": ["/var/lib/pocketshell-relay/registry/devices.json"],
}
REJECT = {
    "Bucket": ["other-bucket", "pocketshell-relay-relaybucket-azljzs6pn8i8/x", "*", ""],
    "ArtifactPath": ["relay-arm64.gz", "artifacts/zz/gateway-linux-arm64.gz", "artifacts/" + "a" * 64 + "/../../relay-arm64.gz", "artifacts/" + "a" * 64 + "/other.gz"],
    "ExpectedSHA256": ["", "x" * 64, "a" * 63, "a" * 65],
    "BinarySHA256": ["", "a" * 64 + ";rm"],
    "Version": ["", "v1;rm -rf", "a" * 100],
    "Domain": ["relay.pocketshell.io", "evil.example.com", "gateway.pocketshell.io;reboot", ""],
    "Aliases": ["gateway.pocketshell.io", "", "relay.pocketshell.io,evil.com"],
    "ServiceName": ["pocketshell-gateway", "*", "pocketshell-relay;reboot", ""],
    "HealthTimeoutSeconds": ["0", "1", "601", "-1", "abc", "180;reboot", "999"],
    "CertDir": ["/var/lib/pocketshell-gateway", "/var/lib/pocketshell-relay/certs", "relative/path", "/var/lib/pocketshell-relay/", "", "/var/lib", "pocketshell-relay", "/var/lib/pocketshell-relay;reboot"],
    "RegistryFile": ["/var/lib/pocketshell-relay/registry", "/var/lib/pocketshell-relay/devices.json", "/var/lib/pocketshell-gateway/registry/devices.json", "registry/devices.json", "", "/var/lib/pocketshell-relay/registry/devices.json;rm", "/var/lib/pocketshell-relay/registry/other.json"],
}
for pname, pdef in params.items():
    ap = pdef["allowedPattern"]
    check(f"allowedPattern anchored (D3): {pname}", ap.startswith("^") and ap.endswith("$"), ap)
    check(f"allowedPattern backslash-free (D3): {pname}", "\\" not in ap, ap)
    for good in ACCEPT.get(pname, []):
        check(f"pattern accepts {pname}={good!r}", re.fullmatch(sub_resolve(ap), good) is not None, ap)
    for bad in REJECT.get(pname, []):
        check(f"pattern rejects {pname}={bad!r}", re.fullmatch(sub_resolve(ap), bad) is None, ap)
check("bucket pinned to bootstrap value (D9)", sub_resolve(params["Bucket"]["allowedPattern"]) == "^" + CFN["Parameters"]["ArtifactBucket"]["Default"] + "$")
check("service pinned to bootstrap value (D9)", sub_resolve(params["ServiceName"]["allowedPattern"]) == "^" + CFN["Parameters"]["ServiceName"]["Default"] + "$")

# Activation contract (integration blocker): the identity/tunnel activation
# configuration is EXPLICITLY carried by the deploy — an SSM parameter per
# path, pinned to the canonical values, the binary's own rules mirrored:
#   - -certdir is the BASE (both binaries DirCache("<certdir>/certs")), the
#     root-only ancestor; its certs/ child is the service-owned cache leaf.
#   - -registry is the registry STATE FILE under <base>/registry/, inside the
#     Go registryBaseDir (main() refuses anything else) — never a directory,
#     never pre-created or reset by the installer.
check("activation parameter CertDir carried (pinned canonical base)",
      params["CertDir"]["allowedPattern"] == "^/var/lib/pocketshell-relay$")
check("activation parameter RegistryFile carried (pinned canonical FILE)",
      params["RegistryFile"]["allowedPattern"] == "^/var/lib/pocketshell-relay/registry/devices[.]json$")
check("RegistryFile is under the Go registryBaseDir (validateRegistryPath)",
      sub_resolve(params["RegistryFile"]["allowedPattern"]).startswith("^/var/lib/pocketshell-relay/"))
check("installer refuses to run without the carried activation configuration",
      "missing required --certdir" in INSTALLER and "missing required --registry" in INSTALLER)
check("installer re-validates certdir/registry arguments",
      "assert_arg \"$CERTDIR_ARG\"" in INSTALLER and "assert_arg \"$REGISTRY_ARG\"" in INSTALLER)
check("installer derives certs/ leaf from the base (DirCache contract)",
      'CERT_DATA_DIR="$CERT_CACHE/certs"' in INSTALLER)
check("installer pins the registry file into <certdir>/registry/",
      '"$REGISTRY_DIR" = "$CERT_CACHE/registry"' in INSTALLER)
check("installer refuses a service-writable layout base",
      "is not a dedicated state root" in INSTALLER)
check("installer whitelist ReadWritePaths is exactly the two leaves",
      'unit_set_directive ReadWritePaths "$CERT_DATA_DIR $REGISTRY_DIR"' in INSTALLER)
check("installer never chowns the layout base to the service account",
      "chown -R \"$SERVICE_USER:$SERVICE_USER\" \"$CERT_CACHE\"" not in INSTALLER)
check("installer never pre-creates or truncates the registry file",
      "touch \"$REGISTRY_FILE\"" not in INSTALLER
      and ">\"$REGISTRY_FILE\"" not in INSTALLER
      and ">>\"$REGISTRY_FILE\"" not in INSTALLER)
check("installer refuses an empty (corrupt) registry file before any swap",
      "registry file exists but is EMPTY" in INSTALLER)
check("installer preserves an existing registry file (no destructive reset)",
      "existing identity registry preserved" in INSTALLER)
check("rewrite drops and re-adds exactly one -certdir/-registry pair",
      '"-certdir"' in INSTALLER and '"-registry"' in INSTALLER
      and '-certdir %s -registry %s' in INSTALLER)
check("rewrite refuses a legacy unit without a nonempty -allow",
      "nonempty -allow allowlist" in INSTALLER)
check("runtime audit requires the carried -certdir/-registry on the running unit",
      'exactly one -certdir' in INSTALLER and 'exactly one -registry' in INSTALLER)
check("health gate requires registry+tunnel enabled on new deploys",
      "registry posture on" in INSTALLER and "tunnel posture on" in INSTALLER)
check("health gate requires enabled postures for an activated rollback target",
      "want_activation" in INSTALLER and 'no JSON /healthz (http_code=${code:-none}) — refusing' in INSTALLER)
check("anonymous identity route must be auth-rejected (never 404)",
      "/identity/v1/devices" in INSTALLER and 'want 401 auth rejection' in INSTALLER)
check("anonymous tunnel route must be upgrade-rejected (never 404)",
      "/api/v1/hosts/" in INSTALLER and 'want 426 websocket-only' in INSTALLER)

# ------------------------------------------------------ embedded script sync
step = doc_content["mainSteps"][0]
cmd = step["inputs"]["runCommand"][0]
lines = cmd.splitlines()
# The YAML loader already removes block-scalar indentation. Preserve source
# indentation, including lines whose own indentation is 18 spaces or more.
spec = importlib.util.spec_from_file_location("gateway_infra_generator", ROOT / "scripts/gen-infra.py")
generator = importlib.util.module_from_spec(spec)
sys.dont_write_bytecode = True
spec.loader.exec_module(generator)
decoded = generator.decode_embedded(cmd)
check("decoded deployment payload equals trusted source composition", decoded == generator.trusted_payload())
emb = [generator.BEGIN] + decoded.decode("utf-8").splitlines() + [generator.END]
check("SSM input parameters all have explicit positive byte bounds", all(isinstance(p.get("maxChars"), int) and p["maxChars"] > 0 for p in params.values()))
# Exact current Domain/Aliases patterns retain two unescaped wildcard dots.
# Reserve 1024 additional bytes for Unicode/JSON escaping in those slots;
# this proof does not qualify arbitrary future CloudFormation overrides.
check("SSM size proof has exact reviewed domain/alias pattern census",
      CFN["Parameters"]["CanonicalDomain"]["Default"] == "gateway.pocketshell.io"
      and CFN["Parameters"]["LegacyAlias"]["Default"] == "relay.pocketshell.io"
      and params["Domain"]["allowedPattern"] == "^${CanonicalDomain}$"
      and params["Aliases"]["allowedPattern"] == "^${LegacyAlias}$")
parameter_budget = 1024 + sum(p["maxChars"] * (1 + cmd.count("{{" + name + "}}")) + len(name) + 16 for name, p in params.items())
content_bytes = len(json.dumps(doc_content, ensure_ascii=True).encode("utf-8"))
check("SSM document plus worst runtime parameter budget fits 64KiB", content_bytes + parameter_budget <= 65536, f"{content_bytes} + {parameter_budget} <= 65536")
src_lines = INSTALLER.splitlines()
while src_lines and not src_lines[-1].strip():
    src_lines.pop()
check("embedded body matches installer source", emb[1 : 1 + len(src_lines) - 1] == src_lines[:-1])
emb_joined = "\n".join(emb)
check(
    "embedded invocation uses document params",
    '/bin/bash "$payload" \\' in cmd
    and '--archive-sha256 "{{ExpectedSHA256}}"' in cmd
    and '--binary-sha256 "{{BinarySHA256}}"' in cmd
    and '--certdir "{{CertDir}}"' in cmd
    and '--registry "{{RegistryFile}}"' in cmd,
)
invocation_params = set(re.findall(r"\{\{(\w+)\}\}", cmd))
check("invocation params all exist in document", invocation_params <= set(params), str(invocation_params - set(params)))
check("document timeout bounded", step["inputs"]["timeoutSeconds"] <= 3600)

# --------------------------- embedded provisioning sync (review R2) ----------
# The generated block must provision the helpers with the verbatim preamble
# and payloads, in that order, BEFORE the `main` invocation — and contain no
# privileged write that bypasses helper_install.
PROVISION_SRC = (ROOT / "scripts/host/provision-helpers.sh").read_text()
PROBE_SRC = (ROOT / "scripts/host/imds-probe.sh").read_text()
GUARD_SRC = (ROOT / "scripts/host/imds-guard.sh").read_text()
emb_body = emb[1:]  # drop the BEGIN marker
prov_start = next(
    i for i, l in enumerate(emb_body)
    if l.startswith("# preamble generated verbatim from scripts/host/provision-helpers.sh")
) + 1
inv_line = next(i for i, l in enumerate(emb_body) if l == 'main "$@"')
check("provisioning preamble embedded verbatim",
      emb_body[prov_start : prov_start + len(PROVISION_SRC.rstrip("\n").splitlines())]
      == PROVISION_SRC.rstrip("\n").splitlines())
HEREDOC_EOF = "POCKETSHHELL_GATEWAY_HELPER_EOF"
probe_at = next(i for i, l in enumerate(emb_body) if l.startswith('helper_install "$HELPERS_DIR/imds-probe.sh"'))
probe_eof = emb_body.index(HEREDOC_EOF, probe_at)
guard_at = next(i for i, l in enumerate(emb_body) if l.startswith('helper_install "$HELPERS_DIR/imds-guard.sh"'))
guard_eof = emb_body.index(HEREDOC_EOF, guard_at)
check("probe payload embedded verbatim",
      emb_body[probe_at + 1 : probe_eof] == PROBE_SRC.rstrip("\n").splitlines())
check("guard payload embedded verbatim",
      emb_body[guard_at + 1 : guard_eof] == GUARD_SRC.rstrip("\n").splitlines())
check("provisioning runs before the deployment invocation", prov_start < probe_at < guard_at < inv_line,
      f"{prov_start} < {probe_at} < {guard_at} < {inv_line}")
prov_region = "\n".join(emb_body[prov_start:inv_line])
prov_code = "\n".join(l for l in prov_region.splitlines() if not l.lstrip().startswith("#"))
check("no install -d / bare cat-to-final-path / append / post-hoc chown in provisioning code",
      not re.search(r"install -d|cat > ['\"]|>>|chown root:root ['\"]", prov_code))
check("provisioning refuses symlink leaves before any write",
      '[ -L "$dest" ]' in prov_code and 'mv -f' in prov_code)

# ------------------------------------------------------------- installer text
_K_RE = re.compile(r"""(^|[\s"'=])-k([\s"']|$)|-sk\b|--insecure""")
tls_violations = [
    l for l in INSTALLER.splitlines()
    if not l.lstrip().startswith("#") and _K_RE.search(l)
]
check("installer never disables TLS verification (D8)", not tls_violations, str(tls_violations[:2]))
check("installer probes canonical and alias (D8)", "--resolve" in INSTALLER)
check("installer takes a lock (D6)", "flock" in INSTALLER)
check("installer uses atomic rename for unit/state (D6)", "atomic_write" in INSTALLER and "mv -Tf" in INSTALLER)
check("installer preserves legacy binary (D5)", "legacy" in INSTALLER and "LEGACY_DIR" in INSTALLER)
check("installer separates archive and binary digests (D4)", '--archive-sha256' in INSTALLER and '--binary-sha256' in INSTALLER)
check("installer validates ARM64 machine bytes (D4)", "b700" in INSTALLER)
check("installer cross-checks path digest (D9)", "artifact path digest does not match" in INSTALLER)
check("installer last line is main (embed contract)", INSTALLER.splitlines()[-1] == 'main "$@"')
check("installer has no eval", "eval " not in INSTALLER)
# R1: the runtime audit parses the REAL structured `systemctl show` output —
# never raw strings, never substrings of arbitrary shapes.
check("installer parses structured systemd Exec* properties (R1)",
      "exec_parse_commands" in INSTALLER and "argv[]" in INSTALLER and "path=" in INSTALLER)
check("installer refuses multi-command properties (R1)", "exactly one is allowed" in INSTALLER)
check("installer audits guard argv exactly (R1)", 'EXEC_ARGV" = "$want_guard_argv"' in INSTALLER)
# R1 fidelity (independent committed review): real systemd consumes the
# privilege prefixes at load time — plain properties report prefix-free
# path/argv, only ExecStartEx/ExecStartPreEx carry the consumed flags, and
# the '+' itself survives ONLY in the raw unit text (FragmentPath/
# DropInPaths), which the audit must therefore pin exactly.
check("installer consults the flags-aware ExecStartEx/ExecStartPreEx properties (R1 fidelity)",
      "ExecStartEx" in INSTALLER and "ExecStartPreEx" in INSTALLER and '"privileged"' in INSTALLER)
check("installer never expects the privilege prefix inside a property value (R1 fidelity)",
      '"+$HELPERS_DIR/imds-guard.sh"' not in INSTALLER)
check("installer pins the '+' privilege prefix in the raw unit sources (R1 fidelity)",
      "unit_raw_exec_ok" in INSTALLER
      and "FragmentPath" in INSTALLER and "DropInPaths" in INSTALLER
      and "ExecStartPre=+$HELPERS_DIR/imds-guard.sh $SERVICE_USER" in INSTALLER)
check("installer refuses non-empty ExecStart flags (R1 fidelity)",
      "privilege/behavior flags" in INSTALLER)
# D21 residuals (provisional source review): authoritative Ex serialization.
check("installer requires exactly one authoritative flags witness per Ex command (D21)",
      "exactly one authoritative flags witness is required" in INSTALLER)
check("installer refuses duplicate Ex fields instead of overwriting (D21)",
      "real systemd serializes each key once" in INSTALLER)
check("installer validates flags words against real systemd flag names (D21)",
      "EXEC_KNOWN_FLAG_NAMES" in INSTALLER
      and "ignore-failure privileged no-setuid ambient no-env-expand" in INSTALLER)
check("installer drop-in Exec ban parses systemd assignment syntax (D21)",
      "unit_trim" in INSTALLER
      and "ExecStartPost|ExecStop|ExecStopPost|ExecCondition" in INSTALLER)
check("installer joins systemd continuation lines and refuses unterminated ones (D21)",
      "unterminated continuation" in INSTALLER)
# D23 (runtime-writable leaf authority boundary): root must not path-mutate
# or path-read service-writable runtime content.
check("installer has no recursive chown at all (D23 — no unrestricted normalization of untrusted trees)",
      "chown -R" not in INSTALLER)
check("installer never opens the runtime content for a privileged byte count (D23)",
      "wc -c" not in INSTALLER and "stat_size" in INSTALLER)
check("installer binds privileged leaf metadata changes to opened verified inodes (D23)",
      "open_checked" in INSTALLER and "/proc/$BASHPID/fd/" in INSTALLER
      and "path replaced between check and open" in INSTALLER)
check("installer reclaims the pre-canonical service-owned base BEFORE child work (D23 ordering)",
      "reclaimed pre-canonical service-owned base" in INSTALLER)
check("installer aligns drifted service-owned leaves as the service user (D23 service authority)",
      'RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHOWN_BIN"' in INSTALLER
      and 'RUNUSER_BIN" -u "$SERVICE_USER" -- "$CHMOD_BIN"' in INSTALLER)
check("installer refuses hardlinked registry state (explicit link-count policy, D23)",
      "aliasing refused by policy" in INSTALLER)
check("installer refuses foreign-owned registry state (explicit ownership policy, D23)",
      "must be service-owned" in INSTALLER)
check("installer adopts legacy cert content under an explicit per-inode policy (D23)",
      "refused by the legacy-content policy" in INSTALLER)
# D23 authority residuals (delivery-authority-final): root ownership is not
# write authority; the registry is not certificate-adoptable content; open
# identity is dev+inode complete.
check("installer proves a root-owned legacy dir NOT service-writable BEFORE descent (D23 authority)",
      "dir_not_service_writable" in INSTALLER
      and "legacy write authority refused before descent" in INSTALLER)
check("installer probes EFFECTIVE service-user access for legacy descent authority (D23 ACL semantics)",
      'gateway-authority-probe "$d" "$probe_uid"' in INSTALLER
      and 'uid=$(/usr/bin/id -u)' in INSTALLER
      and '[ "$uid" = "$2" ] || exit 3' in INSTALLER
      and 'invalid service uid authority probe witness' in INSTALLER)
check("installer keeps the registry OUT of generic certificate adoption (D23)",
      "migrate_registry_dir" in INSTALLER
      and "NOT certificate-style adoptable" in INSTALLER
      and 'migrate_registry_dir "$REGISTRY_DIR"' in INSTALLER)
check("installer validates the registry FILE's original policy before any registry-dir mutation (D23)",
      "before any normalization" in INSTALLER
      and "must be service-owned (Go initializes it as the service account)" in INSTALLER)
check("installer identity records carry device+inode (D23 full identity)",
      "LSTAT_DEV" in INSTALLER and "FD_DEV" in INSTALLER
      and "'%F|%d|%i|%h|%a|%U|%g'" in INSTALLER)
check("installer documents the stable-parent invariant for privileged opens (D23)",
      "Stable-parent invariant" in INSTALLER)
# D21 comment/continuation residuals (delivery-authority-final): physical
# comments are skipped BEFORE continuation; continuation follows trailing-
# backslash parity (conf-parser.c v252).
check("installer skips physical comments BEFORE continuation processing (D21)",
      "Physical comments FIRST" in INSTALLER)
check("installer decides continuation by trailing-backslash parity (D21)",
      "trailing-backslash parity" in INSTALLER
      and "ntails % 2" in INSTALLER)
check("installer audits the trust base itself (sticky is no mitigation, R2 fidelity)",
      'sticky is no mitigation' in INSTALLER and '"$base" != "/"' in INSTALLER)
check("preamble audits the trust base itself and rejects world-writable dirs (R2 fidelity)",
      'sticky is no mitigation' in PROVISION_SRC
      and '[ "$TRUST_BASE" != "/" ]' in PROVISION_SRC
      and 'MKTEMP_BIN' in PROVISION_SRC
      and '.${base}.tmp.XXXXXX' in PROVISION_SRC)

# ------------------------------------------------------------- deploy.sh text
check("deploy uploads conditionally (D10)", "--if-none-match" in DEPLOY_SH)
check("deploy reads StandardOutputContent (D7)", "StandardOutputContent" in DEPLOY_SH)
check("deploy distinguishes eventual consistency (D7)", "InvocationDoesNotExist" in DEPLOY_SH)
check("deploy fails fast on permanent errors (D7)", "AccessDenied" in DEPLOY_SH)
check("deploy sends string-array params (D7)", "{Bucket:[$bucket]" in DEPLOY_SH)
check("deploy carries the activation parameters (CertDir/RegistryFile)",
      "CertDir:[$certdir]" in DEPLOY_SH and "RegistryFile:[$registry]" in DEPLOY_SH)
check("deploy pins the canonical activation constants",
      "CERT_DIR=/var/lib/pocketshell-relay" in DEPLOY_SH
      and "REGISTRY_FILE=/var/lib/pocketshell-relay/registry/devices.json" in DEPLOY_SH)
check("deploy verifies the manifest binds the activation configuration",
      'manifest_field certdir' in DEPLOY_SH and 'manifest_field registry' in DEPLOY_SH)
check("deploy requires the enabled postures in the instance result",
      '^registry=enabled$' in DEPLOY_SH and '^tunnel=enabled$' in DEPLOY_SH)
check("deploy builds a digest-bound manifest (D10)", "binary_sha256" in DEPLOY_SH and "manifest.json" in DEPLOY_SH)
check("deploy never fetches credentials into URLs", "https://" not in DEPLOY_SH.replace("https://$1/", ""))

# --------------------------------------------------------- bootstrap text (R3)
BOOTSTRAP = (ROOT / "scripts/bootstrap-aws.sh").read_text()
IMMUTABLE_SUBJECT = (
    "repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main"
)
check("bootstrap pins the verified immutable subject constant", IMMUTABLE_SUBJECT in BOOTSTRAP)
check("bootstrap has no classic fallback path", "CLASSIC fallback" not in BOOTSTRAP)
check("bootstrap validates the subject BEFORE any AWS call",
      BOOTSTRAP.index("strictly BEFORE any AWS call") < BOOTSTRAP.index("sts get-caller-identity"))
check("bootstrap refuses empty subject overrides", "refusing EMPTY OIDC subject" in BOOTSTRAP)
check("bootstrap refuses wildcard subjects", "refusing wildcard OIDC subject" in BOOTSTRAP)
check("bootstrap accepts only the immutable subject (no self-matching case)",
      'IMMUTABLE_SUBJECT") ;;' in BOOTSTRAP and '$EXACT_SUBJECT") ;;' not in BOOTSTRAP)
check("bootstrap asserts the template pins subject+audience",
      "template_assert" in BOOTSTRAP and "sts.amazonaws.com" in BOOTSTRAP)
check("bootstrap simulation distinguishes explicit denies (R4)",
      "ExplicitDeny" in BOOTSTRAP and "explicitdeny" in BOOTSTRAP)
check("bootstrap simulates the runtime signing-key fences (R4)",
      "GetParameterHistory" in BOOTSTRAP and "GetParametersByPath" in BOOTSTRAP
      and "gateway-signing-key-previous" in BOOTSTRAP)

# ------------------------------------------------------------------ workflows
def uses_pins(workflow: dict, name: str) -> None:
    for job_name, job in workflow["jobs"].items():
        for stepx in job.get("steps", []):
            use = stepx.get("uses", "")
            if not use:
                continue
            m = re.fullmatch(r"([\w.-]+/[\w.-]+)@([0-9a-f]{40})", use)
            check(f"{name}/{job_name} action pinned to SHA: {use}", m is not None)


uses_pins(CI, "ci")
uses_pins(DEPLOY, "deploy")

makefile = (ROOT / "Makefile").read_text() if (ROOT / "Makefile").exists() else ""
gateway_build = makefile.split("build-arm64:", 1)[1].split("artifacts:", 1)[0]
check("gateway artifact injects health version and commit", "-ldflags '$(HELPER_LDFLAGS)' -o $(DIST)/gateway-linux-arm64 ." in gateway_build)
ci_test_runs = [s.get("run", "") for s in CI["jobs"]["test"].get("steps", [])]
check("ci test job drives the Makefile", any("make test" in r for r in ci_test_runs))
check("make test runs the race detector", re.search(r"^test:", makefile, re.M) is not None and "-race" in makefile)
check("ci has vet", "vet" in CI["jobs"])
check("ci has format", "format" in CI["jobs"])
check("ci has vulnerability", "vulnerability" in CI["jobs"])
check("ci builds ARM64", "build-arm64" in CI["jobs"])
check("ci has e2e", "e2e-docker" in CI["jobs"])
check("ci permissions read-only", CI["permissions"] == {"contents": "read"})

# D14: deploy is a REUSABLE workflow — the same-commit CI gate is the only
# entry. An independent push trigger would deploy without fmt/vet/race/vuln/
# ARM/Docker having passed.
on_map = DEPLOY.get(True) or DEPLOY.get("on") or {}
check("deploy has NO independent trigger (workflow_call only)", set(on_map.keys()) == {"workflow_call"}, str(on_map))
check("deploy has no pull_request trigger", "pull_request" not in (ROOT / ".github/workflows/deploy.yml").read_text())
check("deploy has no workflow_dispatch trigger", "workflow_dispatch" not in on_map)
ci_on = CI.get(True) or CI.get("on") or {}
check("ci push trigger is main-only", ci_on.get("push", {}).get("branches") == ["main"])
check("ci concurrency never cancels main", CI["concurrency"]["cancel-in-progress"] == "${{ github.event_name == 'pull_request' }}")
dep_job = DEPLOY["jobs"]["deploy"]
dep_if = str(dep_job["if"])
check("deploy if guards push event", "github.event_name == 'push'" in dep_if, dep_if)
check("deploy if guards main ref", "github.ref == 'refs/heads/main'" in dep_if)
check("deploy if guards exact repo", f"github.repository == '{REPO}'" in dep_if)
check("deploy permissions minimal", DEPLOY["permissions"] == {"contents": "read"})
dep_perms = dep_job.get("permissions", {})
check("deploy job permissions are contents:read + id-token:write ONLY",
      dep_perms == {"contents": "read", "id-token": "write"}, str(dep_perms))
ci_deploy_job = CI["jobs"]["deploy"]
check("ci deploy job calls the reusable workflow", str(ci_deploy_job.get("uses", "")).startswith("./.github/workflows/deploy.yml"))
ci_needs = ci_deploy_job.get("needs", [])
check("ci deploy needs every gate",
      sorted(ci_needs if isinstance(ci_needs, list) else [ci_needs]) ==
      sorted(["test", "vet", "format", "vulnerability", "build-arm64", "e2e-docker"]), str(ci_needs))
ci_dep_if = str(ci_deploy_job.get("if", ""))
check("ci deploy refuses on failed need", "!contains(needs.*.result, 'failure')" in ci_dep_if, ci_dep_if)
check("ci deploy refuses on cancelled need", "!contains(needs.*.result, 'cancelled')" in ci_dep_if)
check("ci deploy refuses on skipped need", "!contains(needs.*.result, 'skipped')" in ci_dep_if)
check("ci deploy job carries id-token: write", ci_deploy_job.get("permissions", {}).get("id-token") == "write")
# Artifact binding: what build-arm64 uploaded is what deploy downloads.
up_all = [s for j in CI["jobs"].values() for s in j.get("steps", []) if "upload-artifact" in str(s.get("uses", ""))]
up = [s for s in up_all if s.get("with", {}).get("name") == "gateway-linux-arm64"]
down = [s for s in dep_job.get("steps", []) if "download-artifact" in str(s.get("uses", ""))]
check("exactly one upload of the release set", len(up) == 1 and up[0].get("with", {}).get("name") == "gateway-linux-arm64", str(up_all))
check("helper matrix + wheels are the only other uploads (no release-set name reuse)",
      len(up_all) == 3, str([s.get("with", {}).get("name") for s in up_all]))
check("deploy downloads the SAME artifact name", len(down) == 1 and down[0].get("with", {}).get("name") == "gateway-linux-arm64", str(down))
check("deploy assumes the bootstrap role", "arn:aws:iam::817685572750:role/pocketshell-github-deploy" in (ROOT / ".github/workflows/deploy.yml").read_text())
check("deploy concurrency serializes", DEPLOY["concurrency"]["group"] == "deploy-main" and DEPLOY["concurrency"]["cancel-in-progress"] is False)
check("deploy has no approval environment", "environment" not in dep_job)

probe_text = (ROOT / ".github/workflows/oidc-probe.yml").read_text()
probe_on = PROBE.get(True) or PROBE.get("on") or {}
check("probe is workflow_dispatch only", set(probe_on.keys()) == {"workflow_dispatch"}, str(probe_on))
check("probe writes id-token", PROBE["permissions"]["id-token"] == "write")
check("probe never echoes the token", re.search(r"echo[^|]*\$?token|cat\s+<<.*token", probe_text, re.I) is None)
check("probe prints only allow-listed claims", "for k in keep" in probe_text)

# -------------------------------------------------------- e2e fixture images
# CI e2e must not depend on Docker Hub's unauthenticated pull limit or on a
# mutable tag: every fixture base image is the ONE digest-pinned public ECR
# mirror of the official alpine:3.20 index (9226 B, same digest on Docker Hub).
E2E_IMAGE = "public.ecr.aws/docker/library/alpine@sha256:d9e853e87e55526f6b2917df91a2115c36dd7c696a35be12163d44e6e2a4b6bc"
E2E_DIR = ROOT / "scripts/e2e"


def e2e_ref_ok(ref: str) -> bool:
    return ref == E2E_IMAGE


for bad in ["alpine:3.20", "alpine", "library/alpine:3.20", "docker.io/library/alpine:3.20",
            "docker.io/library/alpine@" + E2E_IMAGE.split("@", 1)[1],
            "public.ecr.aws/docker/library/alpine:3.20",
            "public.ecr.aws/docker/library/alpine:3.20@" + E2E_IMAGE.split("@", 1)[1],
            "public.ecr.aws/docker/library/alpine@sha256:" + "0" * 64]:
    check(f"e2e fixture ref rejected: {bad}", not e2e_ref_ok(bad))
check("e2e fixture ref accepted: pinned ECR digest", e2e_ref_ok(E2E_IMAGE))

e2e_text_refs = []
for f in sorted(E2E_DIR.rglob("*")):
    if f.name == "Dockerfile" or f.name.startswith("Dockerfile."):
        froms = re.findall(r"^\s*FROM\s+(\S+)", f.read_text(), re.M | re.I)
        check(f"e2e {f.relative_to(ROOT)} has a FROM", len(froms) >= 1)
        e2e_text_refs += [(str(f.relative_to(ROOT)), r) for r in froms]
    elif f.suffix in (".yml", ".yaml"):
        e2e_text_refs += [(str(f.relative_to(ROOT)), r.strip("'\""))
                          for r in re.findall(r"^\s*image:\s*(\S+)", f.read_text(), re.M)]
for where, ref in e2e_text_refs:
    check(f"e2e fixture image pinned to ECR digest: {where}: {ref}", e2e_ref_ok(ref))
check("e2e fixture refs are exactly the 4 known sites (legacy x2, sshd FROM, newapi anchor)",
      sorted(w for w, _ in e2e_text_refs) == sorted([
          "scripts/e2e/docker-compose.yml", "scripts/e2e/docker-compose.yml",
          "scripts/e2e/sshd/Dockerfile", "scripts/e2e/newapi/docker-compose.yml"]),
      str(e2e_text_refs))

# Resolved (anchors merged): every service either uses the pinned image or
# builds from a directory whose Dockerfile is itself checked above.
for compose in sorted(E2E_DIR.rglob("docker-compose.y*ml")):
    services = (yaml.safe_load(compose.read_text()) or {}).get("services", {})
    check(f"e2e {compose.relative_to(ROOT)} has services", bool(services))
    for sname, svc in services.items():
        label = f"{compose.relative_to(ROOT)}/{sname}"
        if "build" in svc:
            ctx = svc["build"] if isinstance(svc["build"], str) else svc["build"].get("context", ".")
            check(f"e2e service builds a checked fixture Dockerfile: {label}",
                  "image" not in svc and (compose.parent / ctx / "Dockerfile").resolve().parent == E2E_DIR / "sshd",
                  str(svc["build"]))
        else:
            check(f"e2e service image pinned to ECR digest: {label}", e2e_ref_ok(str(svc.get("image", ""))), str(svc.get("image")))

# The 3.22 fixtures (security labs + the hostagent real-sshd test that the
# race job builds) get the same treatment: ONE digest-pinned public ECR ref
# of the official alpine:3.22 index (9218 B, same digest on Docker Hub).
LAB_IMAGE = "public.ecr.aws/docker/library/alpine@sha256:5291449c3df73caf6ed85e649dec1b9e818b39a5d8c871e97afc13e9cd5e8fa8"


def lab_ref_ok(ref: str) -> bool:
    return ref == LAB_IMAGE


for bad in ["alpine:3.22", "alpine", "docker.io/library/alpine:3.22",
            "docker.io/library/alpine@" + LAB_IMAGE.split("@", 1)[1],
            "public.ecr.aws/docker/library/alpine:3.22",
            "public.ecr.aws/docker/library/alpine:3.22@" + LAB_IMAGE.split("@", 1)[1],
            E2E_IMAGE, "public.ecr.aws/docker/library/alpine@sha256:" + "0" * 64]:
    check(f"lab fixture ref rejected: {bad}", not lab_ref_ok(bad))
check("lab fixture ref accepted: pinned ECR digest", lab_ref_ok(LAB_IMAGE))

# Repo-wide: every Alpine base image in a tracked Dockerfile, Go-embedded
# Dockerfile or compose file is one of the two pins, at its known sites.
tracked = subprocess.run(["git", "-C", str(ROOT), "ls-files", "-z"], capture_output=True, check=True).stdout.decode().split("\0")
base_refs = []  # (path, ref, is_FROM)
for rel in filter(None, tracked):
    p = pathlib.Path(rel)
    if p.name == "Dockerfile" or p.name.startswith("Dockerfile."):
        pat = r"^\s*FROM\s+(\S+)"
    elif p.suffix == ".go":
        pat = r"^\s*(?:\w+\s*:?=\s*`)?FROM\s+(\S+)"
    elif p.suffix in (".yml", ".yaml") and "compose" in p.name:
        pat = r"^\s*image:\s*['\"]?([^\s'\"]+)"
    else:
        continue
    base_refs += [(rel, r, p.suffix not in (".yml", ".yaml")) for r in re.findall(pat, (ROOT / rel).read_text(), re.M)]
all_refs = [(w, r) for w, r, _ in base_refs if "alpine" in r]
lab_sites = sorted(w for w, r in all_refs if not w.startswith("scripts/e2e/"))
check("lab fixture refs are exactly the 3 known sites (opus lab, dockerlab, hostagent test)",
      lab_sites == sorted(["internal/hostagent/localssh_docker_test.go",
                           "security/dockerlab/Dockerfile", "security/opus/lab/Dockerfile"]), str(all_refs))
for where, ref in all_refs:
    ok = e2e_ref_ok(ref) if where.startswith("scripts/e2e/") else lab_ref_ok(ref)
    check(f"fixture image pinned to its ECR digest: {where}: {ref}", ok)
check("no tracked Alpine fixture pulls a mutable Docker Hub ref",
      not any("@sha256:" not in r or not r.startswith("public.ecr.aws/") for _, r in all_refs), str(all_refs))

# The imds-native proof host (CI: make imds-native-proof) is the Docker
# Official amazonlinux:2023 index via its docker/library ECR mirror (2377 B,
# same digest on Docker Hub). NOT public.ecr.aws/amazonlinux/amazonlinux:
# that is a different index with different per-platform children.
AL_IMAGE = "public.ecr.aws/docker/library/amazonlinux@sha256:8ed3c0a996841537f75607e7d1de2114d8150391f75792e8da9268738547e73f"


def al_ref_ok(ref: str) -> bool:
    return ref == AL_IMAGE


for bad in ["amazonlinux:2023", "amazonlinux", "docker.io/library/amazonlinux:2023",
            "docker.io/library/amazonlinux@" + AL_IMAGE.split("@", 1)[1],
            "public.ecr.aws/docker/library/amazonlinux:2023",
            "public.ecr.aws/docker/library/amazonlinux:2023@" + AL_IMAGE.split("@", 1)[1],
            "public.ecr.aws/amazonlinux/amazonlinux:2023",
            "public.ecr.aws/amazonlinux/amazonlinux@sha256:12052e9b5d3fd85769abbdd863dd038e1890c9ace31d5fdbe1afa78eda97d061",
            "public.ecr.aws/amazonlinux/amazonlinux@" + AL_IMAGE.split("@", 1)[1],
            "public.ecr.aws/docker/library/amazonlinux@sha256:" + "0" * 64]:
    check(f"imds-native ref rejected: {bad}", not al_ref_ok(bad))
check("imds-native ref accepted: pinned docker/library ECR digest", al_ref_ok(AL_IMAGE))
al_refs = [(w, r) for w, r, _ in base_refs if "amazonlinux" in r]
check("amazonlinux refs are exactly the imds-native proof Dockerfile, pinned",
      al_refs == [("scripts/tests/imds-native/Dockerfile", AL_IMAGE)], str(al_refs))

# Closing net: every tracked FROM (Dockerfiles + Go-embedded) is a Docker
# Official image pulled by digest from public ECR — never a Docker Hub base.
# (Compose image: refs may be local build tags; Alpine ones are checked above.)
froms = [(w, r) for w, r, is_from in base_refs if is_from]
bad_froms = [(w, r) for w, r in froms
             if not re.fullmatch(r"public\.ecr\.aws/docker/library/[a-z0-9._-]+@sha256:[0-9a-f]{64}", r)]
check("every tracked FROM is a docker/library ECR digest (no Docker Hub base)",
      bool(froms) and not bad_froms, str(bad_froms))

# Serialized acquisition: anonymous public ECR allows 1 pull/second, and
# compose's parallel per-service pulls were throttled. Both e2e entry points
# must pull the exact pin once (helper), then build, then run compose with
# no pulls and no builds of its own; the helper only retries a throttle.
HELPER = (ROOT / "scripts/e2e/pull-pinned.sh")
helper_text = HELPER.read_text()
check("pull helper is executable", HELPER.stat().st_mode & 0o111 != 0)
check("pull helper accepts only docker/library ECR digest refs",
      "PIN_RE='^public\\.ecr\\.aws/docker/library/[a-z0-9._-]+@sha256:[0-9a-f]{64}$'" in helper_text)
check("pull helper retries only an explicit registry throttle",
      "THROTTLE_RE='toomanyrequests|Rate exceeded|429 Too Many Requests'" in helper_text
      and 'die "$what failed (not a registry throttle; no retry)"' in helper_text)
# Build output also carries RUN steps: only the exact pin's FROM metadata
# resolution answered 429 by public ECR is a retryable build failure.
check("pull uses the registry-answer classifier",
      'throttled_retry "pull of $ref" "$THROTTLE_RE" "$DOCKER" pull --quiet "$ref"' in helper_text)
check("build uses the exact-pin metadata classifier, never the broad one",
      'throttled_retry "compose build of $1" "$(metadata_throttle_re "$3")" "$DOCKER" compose -f "$1" -p "$2" build' in helper_text
      and len(re.findall(r'throttled_retry "[^"]*" "\$THROTTLE_RE"', helper_text)) == 1)
check("build classifier ignores RUN-step output lines",
      "grep -vE '^#[0-9]+ [0-9]+\\.[0-9]+ ' <<<\"$out\" | grep -qE \"$re\"" in helper_text)
check("build classifier is anchored to pin, ECR manifest/token URL and 429",
      'failed to resolve source metadata for ${pin}: (failed to authorize: failed to fetch (anonymous|oauth) token: )?unexpected status from (GET|HEAD) request to https://public\\\\.ecr\\\\.aws/(v2/${repo}/manifests/${digest}|token/\\\\?[^ ]*): 429 Too Many Requests' in helper_text)
check("pull helper never tags/removes/pushes/logs in",
      re.search(r'"\$DOCKER"\s+(tag|rmi|push|login|image\s+(rm|tag|prune))\b', helper_text) is None)
check("e2e base is taken from the pinned sshd FROM",
      "E2E_BASE := $(shell sed -n 's/^FROM //p' scripts/e2e/sshd/Dockerfile)" in makefile)
e2e_recipe = makefile.split("\ne2e-docker:", 1)[1].split("\nNEWAPI_COMPOSE", 1)[0]
newapi_text = (ROOT / "scripts/e2e/run-newapi.sh").read_text()
for label, text, seq in [
    ("make e2e-docker", e2e_recipe,
     ["scripts/e2e/pull-pinned.sh pull $(E2E_BASE)",
      "scripts/e2e/pull-pinned.sh build scripts/e2e/docker-compose.yml pocketshell-e2e $(E2E_BASE)",
      "$(COMPOSE) up --pull never --no-build --abort-on-container-exit --exit-code-from e2e"]),
    ("run-newapi.sh", newapi_text,
     ["E2E_BASE=$(sed -n 's/^FROM //p' scripts/e2e/sshd/Dockerfile)",
      'scripts/e2e/pull-pinned.sh pull "$E2E_BASE"',
      'scripts/e2e/pull-pinned.sh build "$FIXTURE" pocketshell-newapi-e2e "$E2E_BASE"',
      "$COMPOSE up --pull never --no-build --abort-on-container-exit --exit-code-from e2e"])]:
    pos = [text.find(s) for s in seq]
    check(f"{label}: pull pin -> build -> compose up --pull never --no-build, in order",
          all(p >= 0 for p in pos) and pos == sorted(pos), str(list(zip(seq, pos))))
    check(f"{label}: compose up never pulls or builds by itself",
          re.search(r"\bup\b(?![^\n]*--pull never --no-build)", text.replace("pull-pinned.sh", "")) is None
          and "up --build" not in text)
check("pull helper controls: throttle->ok, permanent fail, exhaustion, exact pin, cache, binding, no overwrite; build retries only pin metadata 429 (not RUN/package/server/other 429)",
      subprocess.run(["bash", str(ROOT / "scripts/tests/pull-pinned-test.sh")]).returncode == 0)

# ------------------------------------------------------------------- secrets
secret_re = re.compile(r"AKIA[0-9A-Z]{16}|BEGIN [A-Z ]*PRIVATE KEY")
for f in [ROOT / "scripts/deploy.sh", ROOT / "scripts/bootstrap-aws.sh", ROOT / "scripts/host/install-deploy.sh",
          ROOT / "infra/github-actions.yaml", ROOT / ".github/workflows/deploy.yml", ROOT / ".github/workflows/ci.yml"]:
    check(f"no secrets in {f.name}", secret_re.search(f.read_text()) is None)

if not FAILURES:
    check("compressed SSM envelope real-shell corruption/cleanup regressions", subprocess.run([sys.executable, str(ROOT / "scripts/tests/ssm-envelope-test.py")]).returncode == 0)

print(f"\ncontract: {CHECKS - len(FAILURES)}/{CHECKS} checks passed")
if FAILURES:
    print(f"contract FAILURES: {len(FAILURES)}")
    sys.exit(1)
print("contract OK")
