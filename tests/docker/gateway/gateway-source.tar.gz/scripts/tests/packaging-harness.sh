#!/usr/bin/env bash
# Packaging harness (wheel provenance semantics repair): exercises the REAL
# artifact pipeline, not text presence.
#
#   1. Producer-gated packaging + complete release set. The build-matrix
#      fixture is REAL: a tiny module cross-compiled with the local Go
#      toolchain inside a scratch git worktree (clearly labelled fixtures —
#      NOT cmd/pocketshell-link, NOT release artifacts). Real binaries carry
#      the real Go buildinfo stamp, so the producer's identity gate is
#      exercised for real: the strict PROVENANCE.txt record (duplicate fields
#      refused, exact schema/types), the flags GRAMMAR (exactly one effective
#      -X main.commit assignment — substring presence is not verification),
#      and the read-only embedded-buildinfo inspection (toolchain, GOOS/GOARCH,
#      CGO_ENABLED=0, -trimpath, vcs.revision == release revision,
#      vcs.modified=false; binaries are never executed). The packager must
#      verify every producer input against actual bytes and emit the complete
#      release set (4 wheels + outer .sha256 sidecars + SHA256SUMS +
#      wheels-manifest.json + checked PROVENANCE copy), deterministically and
#      with stale artifacts cleared.
#   2. Independent release verification (scripts/packaging/
#      verify_wheel_release.py): recomputes outer digests, every manifest
#      member, wheel structure/RECORD, the embedded helper digest, the
#      helper_matrix map relationships, the embedded binary's architecture
#      AND its embedded build stamp — in BOTH modes. Tamper calibration on
#      COPIES of the release, including the review's control set: a copied
#      provenance naming another commit with every checksum refreshed (C1), a
#      zeroed helper_matrix (C2 release-only / C2b with the raw matrix), a
#      stripped manifest provenance record (C3), a non-canonical producer_file
#      (C4), a wrong-architecture payload whose RECORD/outer set is fully
#      refreshed (exercises the architecture channel, not the checksum
#      channel), and a stale-helper build stamp that is fully checksum-
#      consistent (exercises the buildinfo channel).
#   3. Build matrix: on a full-source tree (cmd/pocketshell-link present)
#      `make build-matrix` + `make wheels` produce the REAL receipt when the
#      worktree is clean; a DIRTY worktree must fail closed at the
#      vcs.modified gate. On a standalone delivery tree the targets must FAIL
#      CLOSED with the dependency named, and the final 4-platform wheel
#      receipt stays explicitly PENDING root integration — fixtures never
#      substitute for it.
set -uo pipefail

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
WORK=$(mktemp -d "${TMPDIR:-/tmp}/gateway-packaging-harness.XXXXXX")
PASS=0
FAIL=0

note() { printf '[pk-harness] %s\n' "$*"; }
ok() { PASS=$((PASS + 1)); printf '[pk-harness] PASS: %s\n' "$1"; }
ko() { FAIL=$((FAIL + 1)); printf '[pk-harness] FAIL: %s\n' "$1"; }
finish() {
  rm -rf "$WORK"
  note "-----"
  note "passed=$PASS failed=$FAIL"
  [ "$FAIL" = 0 ] || exit 1
  exit 0
}

BW="python3 $ROOT/scripts/packaging/build_wheel.py"
VW="python3 $ROOT/scripts/packaging/verify_wheel_release.py"

# --- real locally-compiled fixture toolchain ----------------------------------
GO_BIN=$(command -v /usr/local/go/bin/go || command -v go || true)
if [ -z "$GO_BIN" ]; then
  ko "no Go toolchain on this machine (/usr/local/go/bin/go or PATH) — the fixture matrix cannot be compiled and the packaging contract cannot be exercised"
  finish
fi

FIXTURE_SRC="$WORK/fixture-src"
OTHER=1111222233334444555566667777888899990000
SHORT=abc123def456

# Scratch git worktree holding the fixture module. Builds emit binaries
# OUTSIDE the worktree so it stays clean (vcs.modified=false is part of the
# gate this harness exercises).
init_fixture_repo() {
  mkdir -p "$FIXTURE_SRC"
  (
    cd "$FIXTURE_SRC" || exit 1
    git init -q -b main
    git config user.email fixture@invalid.local
    git config user.name fixture
    cat > main.go <<'EOF'
package main

// gateway packaging-harness fixture — NOT the real helper; format controls only.
var version, commit string

func main() { println(version, commit) }
EOF
    printf 'module gatewayfixture\n\ngo 1.22\n' > go.mod
    git add main.go go.mod
    git commit -qm "fixture revision 1"
  ) || { ko "scratch fixture git repo init failed"; finish; }
}

# build_fixture_bins SRC OUTDIR LDFLAGS — cross-compile the 4 platform slots
# (never executed; pure bytes for the static identity checks).
build_fixture_bins() {
  local src=$1 out=$2 ldflags=$3 t os arch
  mkdir -p "$out"
  for t in linux/amd64 linux/arm64 darwin/amd64 darwin/arm64; do
    os=${t%/*}; arch=${t#*/}
    ( cd "$src" && GOOS=$os GOARCH=$arch CGO_ENABLED=0 "$GO_BIN" build -trimpath \
        -ldflags "$ldflags" -o "$out/pocketshell-link-$os-$arch" . ) || return 1
  done
}

# write_matrix_records DIR COMMIT — write the per-binary sidecars, SHA256SUMS
# and PROVENANCE.txt in the exact shape `make build-matrix` writes.
write_matrix_records() {
  local dir=$1 commit=$2
  local ver="git-${commit:0:12}"
  (
    cd "$dir" || exit 1
    local f
    : > SHA256SUMS
    for f in pocketshell-link-*; do
      case "$f" in *.sha256) continue ;; esac
      sha256sum "$f" > "$f.sha256" || exit 1
      sha256sum "$f" >> SHA256SUMS || exit 1
    done
  ) || { ko "fixture checksum writing failed for $dir"; finish; }
  cat > "$dir/PROVENANCE.txt" <<EOF
artifact: pocketshell-link (raw helper binary)
version: $ver
commit: $commit
built_at: 2026-10-07T00:00:00Z
toolchain: $("$GO_BIN" version)
flags: CGO_ENABLED=0 -trimpath -ldflags "-s -w -X main.version=$ver -X main.commit=$commit"
platforms: linux/amd64 linux/arm64 darwin/amd64 darwin/arm64
checksums: sha256 sidecar NEXT TO every artifact + SHA256SUMS
published_by: locally-compiled packaging-harness fixture, not a real release build
EOF
}

gen_matrix() { # DIR COMMIT — pristine fixture matrix built at the scratch repo HEAD
  local dir=$1 commit=$2
  local ver="git-${commit:0:12}"
  build_fixture_bins "$FIXTURE_SRC" "$dir" \
    "-s -w -X main.version=$ver -X main.commit=$commit" \
    || { ko "fixture cross-compile failed"; finish; }
  write_matrix_records "$dir" "$commit"
}

# refresh_checksums DIR — recompute sidecars + SHA256SUMS the way
# `make build-matrix` does (used to build *valid* mutated fixtures).
refresh_checksums() {
  (
    cd "$1" || exit 1
    for f in pocketshell-link-*; do
      case "$f" in *.sha256) continue ;; esac
      sha256sum "$f" > "$f.sha256" || exit 1
    done
    : > SHA256SUMS
    for f in pocketshell-link-*; do
      case "$f" in *.sha256) continue ;; esac
      sha256sum "$f" >> SHA256SUMS || exit 1
    done
  )
}

# expect_refusal LABEL MATRIXDIR COMMIT TOKEN — the packager must fail and
# name the reason.
expect_refusal() {
  local label=$1 dir=$2 commit=$3 token=$4
  if $BW --matrix-dir "$dir" --out-dir "$WORK/refused-out" --version "0.0.0+${commit:0:12}" \
      --commit "$commit" >"$WORK/ref.out" 2>&1; then
    ko "$label: packager must refuse"
  elif grep -q -- "$token" "$WORK/ref.out"; then
    ok "$label"
  else
    ko "$label: refused but without naming the reason (wanted '$token'): $(head -1 "$WORK/ref.out")"
  fi
}

note "fixture toolchain: $("$GO_BIN" version) @ git $(git --version)"

# --- 0. real fixture matrices ---------------------------------------------------
init_fixture_repo
COMMIT=$(git -C "$FIXTURE_SRC" rev-parse HEAD)
V1="0.0.0+${COMMIT:0:12}"

rm -rf "$WORK/matrix"; gen_matrix "$WORK/matrix" "$COMMIT"
ok "pristine fixture matrix cross-compiled at scratch revision ${COMMIT:0:12} (real Go buildinfo stamps)"

# stale matrix: a SECOND revision really built from the scratch repo (review
# WP3: a real stale helper from a different known revision).
printf '// fixture revision 2\n' >> "$FIXTURE_SRC/main.go"
( cd "$FIXTURE_SRC" && git add main.go && git commit -qm "fixture revision 2" ) || { ko "second fixture commit failed"; finish; }
STALE_COMMIT=$(git -C "$FIXTURE_SRC" rev-parse HEAD)
rm -rf "$WORK/stale-matrix"
build_fixture_bins "$FIXTURE_SRC" "$WORK/stale-matrix" \
  "-s -w -X main.version=git-${STALE_COMMIT:0:12} -X main.commit=$STALE_COMMIT" \
  || { ko "stale fixture cross-compile failed"; finish; }
write_matrix_records "$WORK/stale-matrix" "$STALE_COMMIT"
ok "stale fixture matrix really built from the second scratch revision ${STALE_COMMIT:0:12}"

# back to revision 1 for the mislabeled-flags and dirty-tree fixtures
( cd "$FIXTURE_SRC" && git reset -q --hard "$COMMIT" ) || { ko "fixture repo reset failed"; finish; }
V2="0.0.0+${STALE_COMMIT:0:12}"

# --- 1a. complete release set from a valid real-fixture producer set ------------
rm -rf "$WORK/wheels-a"
if $BW --matrix-dir "$WORK/matrix" --out-dir "$WORK/wheels-a" \
    --version "$V1" --commit "$COMMIT" >"$WORK/build.out" 2>&1; then
  ok "producer-gated packager builds the full release set from the real fixture matrix"
else
  ko "producer-gate packager refused a valid producer set: $(cat "$WORK/build.out")"
fi

count=$(ls -1 "$WORK/wheels-a" 2>/dev/null | wc -l)
if [ "$count" = 11 ]; then
  ok "release set is exactly 11 files (4 wheels + 4 outer sidecars + SHA256SUMS + manifest + provenance copy)"
else
  ko "release set has $count files, want 11: $(ls -1 "$WORK/wheels-a" 2>/dev/null | tr '\n' ' ')"
fi
for f in "pocketshell_gateway_link-$V1-py3-none-manylinux_2_28_x86_64.whl" \
         "pocketshell_gateway_link-$V1-py3-none-manylinux_2_28_x86_64.whl.sha256" \
         "pocketshell_gateway_link-$V1-py3-none-macosx_11_0_arm64.whl.sha256" \
         SHA256SUMS wheels-manifest.json helper-matrix-PROVENANCE.txt; do
  [ -f "$WORK/wheels-a/$f" ] || ko "release set missing $f"
done
ok "release set: wheels, per-wheel outer sidecars, SHA256SUMS, manifest, provenance copy all present"

( cd "$WORK/wheels-a" && sha256sum -c SHA256SUMS >/dev/null 2>&1 ) &&
  ok "release SHA256SUMS recomputes clean against actual files (sha256sum -c)" ||
  ko "release SHA256SUMS does not verify"

cmp -s "$WORK/wheels-a/helper-matrix-PROVENANCE.txt" "$WORK/matrix/PROVENANCE.txt" &&
  ok "checked producer provenance copied byte-identically into the release set" ||
  ko "provenance copy differs from the checked producer provenance"

# manifest bindings + independent recomputation of outer, embedded, helper-map digests
if python3 - "$WORK/wheels-a" "$WORK/matrix" "$COMMIT" "$V1" <<'PY'
import hashlib, json, pathlib, sys, zipfile
rel, matrix = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
commit, version = sys.argv[3], sys.argv[4]
m = json.loads((rel / "wheels-manifest.json").read_bytes())
assert m["schema"] == "pocketshell-gateway-wheels-manifest/v1", m["schema"]
assert m["source_revision"] == commit and len(commit) == 40, m["source_revision"]
assert m["wheel_version"] == version
assert m["producer"]["provenance"]["commit"] == commit
assert sorted(m["producer"]["helper_matrix"]) == sorted(
    f"pocketshell-link-{p}" for p in ("linux-amd64", "linux-arm64", "darwin-amd64", "darwin-arm64"))
assert len(m["wheels"]) == 4, len(m["wheels"])
for e in m["wheels"]:
    data = (rel / e["file"]).read_bytes()
    assert hashlib.sha256(data).hexdigest() == e["sha256"], e["file"]
    assert len(data) == e["size_bytes"], e["file"]
    with zipfile.ZipFile(rel / e["file"]) as zf:
        helper = zf.read("pocketshell_gateway_link/bin/pocketshell-link")
    raw = matrix / e["embedded_helper"]["producer_file"]
    assert e["embedded_helper"]["producer_file"] == raw.name, e["file"]
    assert raw.read_bytes() == helper, e["file"]
    embedded = hashlib.sha256(helper).hexdigest()
    assert embedded == e["embedded_helper"]["sha256"], e["file"]
    assert embedded == m["producer"]["helper_matrix"][raw.name]["sha256"], e["file"]
print("manifest receipt:", ", ".join(f'{e["platform"]}={e["sha256"][:12]}' for e in m["wheels"]))
PY
then
  ok "manifest binds full revision/version; outer + embedded + helper_matrix digests recompute against actual bytes and the raw producer binaries"
else
  ko "manifest binding / independent recomputation failed"
fi

# determinism: same inputs -> every release-set file byte-identical
$BW --matrix-dir "$WORK/matrix" --out-dir "$WORK/wheels-b" \
    --version "$V1" --commit "$COMMIT" >/dev/null 2>&1
det=ok
for f in "$WORK/wheels-a"/*; do
  base=$(basename "$f")
  cmp -s "$f" "$WORK/wheels-b/$base" || det="DIFF: $base"
done
[ "$det" = "ok" ] && ok "whole release set is deterministic (byte-identical rebuild)" \
                  || ko "release set not deterministic ($det)"

# stale-artifact guard: rebuilding a new version into the SAME output dir
# must remove the old wheels and cover exactly the new set
$BW --matrix-dir "$WORK/matrix" --out-dir "$WORK/wheels-c" --version "$V1" --commit "$COMMIT" >/dev/null 2>&1
$BW --matrix-dir "$WORK/matrix" --out-dir "$WORK/wheels-c" --version "$V2" --commit "$COMMIT" >/dev/null 2>&1
if compgen -G "$WORK/wheels-c/pocketshell_gateway_link-$V1-*.whl" >/dev/null; then
  ko "stale V1 wheel survived a V2 rebuild into the same output dir"
else
  ok "stale-artifact guard: earlier build's wheels are removed, not carried along"
fi
rows=$(wc -l < "$WORK/wheels-c/SHA256SUMS")
[ "$rows" = 6 ] && ok "rebuilt SHA256SUMS covers exactly 4 wheels + manifest + provenance" \
                || ko "rebuilt SHA256SUMS has $rows rows, want 6"
if grep -F "$V1" "$WORK/wheels-c/wheels-manifest.json" "$WORK/wheels-c/SHA256SUMS" >/dev/null 2>&1; then
  ko "rebuilt manifest/checksums still reference the stale version"
else
  ok "rebuilt manifest + SHA256SUMS contain no stale-version reference"
fi

# --- 1b. wheel structure (unchanged contract, re-checked) ---------------------
WHEEL="$WORK/wheels-a/pocketshell_gateway_link-$V1-py3-none-manylinux_2_28_x86_64.whl"
python3 - "$WHEEL" "$WORK/matrix/pocketshell-link-linux-amd64" <<'PY' && ok "wheel structure: RECORD hashes verified, binary round-trip, executable" || ko "wheel structure broken"
import base64, csv, hashlib, sys, zipfile
wheel, payload_path = sys.argv[1], sys.argv[2]
zf = zipfile.ZipFile(wheel)
names = zf.namelist()
assert "pocketshell_gateway_link/bin/pocketshell-link" in names, names
assert zf.read("pocketshell_gateway_link/bin/pocketshell-link") == open(payload_path, "rb").read()
info = zf.getinfo("pocketshell_gateway_link/bin/pocketshell-link")
assert (info.external_attr >> 16) & 0o755, hex(info.external_attr)
rec_name = [n for n in names if n.endswith(".dist-info/RECORD")][0]
rows = {r[0]: r for r in csv.reader(zf.read(rec_name).decode().splitlines())}
for n in names:
    assert n in rows, f"RECORD missing {n}"
    if n == rec_name:
        assert rows[n][1] == "", "RECORD row must be self-listing without hash"
    else:
        d = zf.read(n)
        want = "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(d).digest()).rstrip(b"=").decode()
        assert rows[n][1] == want, f"hash mismatch {n}"
wheel_meta = [n for n in names if n.endswith(".dist-info/WHEEL")][0]
assert b"Root-Is-Purelib: false" in zf.read(wheel_meta)
assert b"Tag: py3-none-manylinux_2_28_x86_64" in zf.read(wheel_meta)
PY

# --- 1c. producer-input refusals (each on a fresh, otherwise-valid set) -------
rm -rf "$WORK/n1"; cp -r "$WORK/matrix" "$WORK/n1"; rm "$WORK/n1/pocketshell-link-linux-arm64.sha256"
expect_refusal "refuses a missing per-binary producer sidecar" "$WORK/n1" "$COMMIT" "sidecar"

rm -rf "$WORK/n2"; cp -r "$WORK/matrix" "$WORK/n2"; rm "$WORK/n2/SHA256SUMS"
expect_refusal "refuses a missing producer SHA256SUMS" "$WORK/n2" "$COMMIT" "SHA256SUMS"

rm -rf "$WORK/n3"; cp -r "$WORK/matrix" "$WORK/n3"; rm "$WORK/n3/PROVENANCE.txt"
expect_refusal "refuses a missing producer provenance" "$WORK/n3" "$COMMIT" "provenance"

rm -rf "$WORK/n4"; cp -r "$WORK/matrix" "$WORK/n4"; printf 'x' >> "$WORK/n4/pocketshell-link-linux-amd64"
expect_refusal "refuses raw bytes that no longer match their sidecar" "$WORK/n4" "$COMMIT" "sidecar mismatch"

rm -rf "$WORK/n5"; cp -r "$WORK/matrix" "$WORK/n5"
python3 - "$WORK/n5" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "SHA256SUMS"
lines = p.read_text().splitlines()
lines[3] = ("1" if lines[3][0] == "0" else "0") + lines[3][1:]
p.write_text("\n".join(lines) + "\n")
PY
expect_refusal "refuses SHA256SUMS conflicting with actual bytes" "$WORK/n5" "$COMMIT" "SHA256SUMS mismatch"

rm -rf "$WORK/n6"; gen_matrix "$WORK/n6" "$OTHER"
expect_refusal "refuses stale provenance (commit from another revision)" "$WORK/n6" "$COMMIT" "stale/conflicting"

rm -rf "$WORK/n7"; gen_matrix "$WORK/n7" "$SHORT"
expect_refusal "refuses short-form provenance commit (full revision mandatory)" "$WORK/n7" "$COMMIT" "FULL 40-hex"

rm -rf "$WORK/n8"; cp -r "$WORK/matrix" "$WORK/n8"
python3 - "$WORK/n8" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "SHA256SUMS"
lines = p.read_text().splitlines()
p.write_text("\n".join(lines) + "\n" + lines[0].replace(lines[0].split()[0], "f" * 64) + "\n")
PY
expect_refusal "refuses ambiguous duplicate SHA256SUMS rows" "$WORK/n8" "$COMMIT" "duplicate"

expect_refusal "refuses a short --commit on the CLI (manifest binds the FULL revision)" \
  "$WORK/matrix" "$SHORT" "FULL 40-hex source revision"

rm -rf "$WORK/n9"; cp -r "$WORK/matrix" "$WORK/n9"
cp "$WORK/n9/pocketshell-link-linux-arm64" "$WORK/n9/pocketshell-link-linux-amd64"
refresh_checksums "$WORK/n9"
expect_refusal "refuses a wrong-architecture binary in a platform slot" "$WORK/n9" "$COMMIT" "e_machine"

rm -rf "$WORK/n10"; cp -r "$WORK/matrix" "$WORK/n10"
printf 'AKIAIOSFODNN7EXAMPLE fake key material\n' >> "$WORK/n10/pocketshell-link-linux-arm64"
refresh_checksums "$WORK/n10"
expect_refusal "refuses credential-shaped payloads" "$WORK/n10" "$COMMIT" "credential-shaped"

# --- 1d. WP1 refusals: ambiguous provenance fields + flags grammar (C5/C6) ----
rm -rf "$WORK/n11"; cp -r "$WORK/matrix" "$WORK/n11"
printf 'commit: %s\n' "$OTHER" >> "$WORK/n11/PROVENANCE.txt"
expect_refusal "C5: refuses a duplicate provenance commit field (no later-override)" \
  "$WORK/n11" "$COMMIT" "duplicate provenance field"

rm -rf "$WORK/n12"; cp -r "$WORK/matrix" "$WORK/n12"
python3 - "$WORK/n12" "$OTHER" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "PROVENANCE.txt"
other = sys.argv[2]
lines = p.read_text().splitlines()
out = []
for l in lines:
    if l.startswith("flags:"):
        l = l[:-1] + f' -X main.commit={other}"'  # second assignment inside the same ldflags string
    out.append(l)
p.write_text("\n".join(out) + "\n")
PY
expect_refusal "C6: refuses two -X main.commit assignments in the same flags string" \
  "$WORK/n12" "$COMMIT" "-X main.commit assignments"

rm -rf "$WORK/n13"; cp -r "$WORK/matrix" "$WORK/n13"
python3 - "$WORK/n13" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "PROVENANCE.txt"
lines = p.read_text().splitlines()
out = []
for l in lines:
    if l.startswith("flags:") and "-X main.commit=" in l:
        i = l.rindex("-X main.commit=")
        l = l[:i] + l[i:].replace('"', 'e"', 1)  # commit value with a suffix glued on
    out.append(l)
p.write_text("\n".join(out) + "\n")
PY
expect_refusal "refuses a commit-prefix-suffix assignment (substring is not the revision)" \
  "$WORK/n13" "$COMMIT" "not exactly the expected FULL revision"

rm -rf "$WORK/n14"; cp -r "$WORK/matrix" "$WORK/n14"
python3 - "$WORK/n14" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "PROVENANCE.txt"
lines = [l for l in p.read_text().splitlines() if not l.startswith("version:")]
p.write_text("\n".join(lines) + "\n")
PY
expect_refusal "refuses provenance missing the version field" "$WORK/n14" "$COMMIT" "missing a version:"

rm -rf "$WORK/n15"; cp -r "$WORK/matrix" "$WORK/n15"
python3 - "$WORK/n15" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "PROVENANCE.txt"
lines = [l for l in p.read_text().splitlines() if not l.startswith("built_at:")]
p.write_text("\n".join(lines) + "\n")
PY
expect_refusal "refuses provenance missing the built_at field" "$WORK/n15" "$COMMIT" "missing a built_at:"

rm -rf "$WORK/n16"; cp -r "$WORK/matrix" "$WORK/n16"
python3 - "$WORK/n16" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "PROVENANCE.txt"
lines = [l for l in p.read_text().splitlines() if not l.startswith("toolchain:")]
p.write_text("\n".join(lines) + "\n")
PY
expect_refusal "refuses provenance missing the toolchain field" "$WORK/n16" "$COMMIT" "missing a toolchain:"

rm -rf "$WORK/n17"; cp -r "$WORK/matrix" "$WORK/n17"
python3 - "$WORK/n17" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "PROVENANCE.txt"
lines = p.read_text().splitlines()
out = [l.replace("CGO_ENABLED=0", "CGO_ENABLED=1") if l.startswith("flags:") else l for l in lines]
p.write_text("\n".join(out) + "\n")
PY
expect_refusal "refuses flags contradicting CGO_ENABLED=0" "$WORK/n17" "$COMMIT" "CGO_ENABLED"

rm -rf "$WORK/n18"; cp -r "$WORK/matrix" "$WORK/n18"
python3 - "$WORK/n18" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "PROVENANCE.txt"
lines = p.read_text().splitlines()
out = []
for l in lines:
    if l.startswith("flags:"):
        l = l.replace(" -trimpath", "", 1)  # drop the contracted -trimpath token only
    out.append(l)
p.write_text("\n".join(out) + "\n")
PY
expect_refusal "refuses flags missing the contracted -trimpath setting" "$WORK/n18" "$COMMIT" "-trimpath"

# --- 1e. WP3 refusals: real stale/dirty binaries under a current label ---------
rm -rf "$WORK/n19"; cp -r "$WORK/stale-matrix" "$WORK/n19"
write_matrix_records "$WORK/n19" "$COMMIT"   # forged CURRENT label on STALE bytes
expect_refusal "WP3: refuses a real helper built from another revision under a current receipt" \
  "$WORK/n19" "$COMMIT" "vcs.revision"

rm -rf "$WORK/dirty-matrix"
# the untracked file must exist DURING the build so the toolchain stamps
# vcs.modified=true (that is the state the gate must refuse)
printf 'untracked scratch\n' > "$FIXTURE_SRC/notes.txt"
build_fixture_bins "$FIXTURE_SRC" "$WORK/dirty-matrix" \
  "-s -w -X main.version=git-${COMMIT:0:12} -X main.commit=$COMMIT" \
  || { rm -f "$FIXTURE_SRC/notes.txt"; ko "dirty-tree fixture cross-compile failed"; finish; }
write_matrix_records "$WORK/dirty-matrix" "$COMMIT"
rm -f "$FIXTURE_SRC/notes.txt"
expect_refusal "WP3: refuses binaries built from a dirty (uncommitted-changes) worktree" \
  "$WORK/dirty-matrix" "$COMMIT" "vcs.modified"

# WP3 residual, stated honestly: a binary built from the SAME revision but a
# DIFFERENT -X main.commit injection carries vcs.revision == the release
# revision and (because -trimpath redacts -ldflags from the Go buildinfo,
# go.dev/issue/52372) its effective ldflags are NOT statically re-derivable.
# The producer must ACCEPT it on the strength of the receipt grammar alone —
# the ldflags claim is closed at the trusted CI build receipt / final gate,
# not here.
rm -rf "$WORK/mislabeled-matrix"
build_fixture_bins "$FIXTURE_SRC" "$WORK/mislabeled-matrix" \
  "-s -w -X main.version=git-${COMMIT:0:12} -X main.commit=$OTHER" \
  || { ko "mislabeled fixture cross-compile failed"; finish; }
write_matrix_records "$WORK/mislabeled-matrix" "$COMMIT"
if $BW --matrix-dir "$WORK/mislabeled-matrix" --out-dir "$WORK/mislabeled-out" \
    --version "$V1" --commit "$COMMIT" >"$WORK/mis.out" 2>&1; then
  note "LIMITATION (accepted by design): same-revision binary with a different -X main.commit injection passes the producer gate — the source binding (vcs.revision) holds, the ldflags label is receipt-only because -trimpath redacts -ldflags from Go buildinfo (go.dev/issue/52372); final ldflags acceptance is the trusted CI build receipt / release gate"
else
  note "UPDATE (producer refuses the mislabeled-flags fixture): $(head -1 "$WORK/mis.out")"
fi

# --- 2. independent release verification + tamper calibration ------------------
if $VW --release-dir "$WORK/wheels-a" --matrix-dir "$WORK/matrix" \
    --expect-commit "$COMMIT" --expect-version "$V1" >"$WORK/ver.out" 2>&1; then
  ok "independent verifier accepts the pristine release set against the raw matrix"
  note "$(head -1 "$WORK/ver.out")"
else
  ko "independent verifier rejected a pristine release set: $(cat "$WORK/ver.out")"
fi
if $VW --release-dir "$WORK/wheels-a" --expect-commit "$COMMIT" --expect-version "$V1" \
    >"$WORK/ver2.out" 2>&1; then
  ok "independent verifier accepts the pristine release set in release-only mode"
else
  ko "independent verifier rejected a pristine release set (release-only): $(cat "$WORK/ver2.out")"
fi

tamper() { # tamper LABEL EXPECTED_TOKEN -- CMD... : verifier must FAIL naming the reason
  local label=$1 token=$2; shift 2
  local dir="$WORK/tampered"
  rm -rf "$dir"; cp -r "$WORK/wheels-a" "$dir"
  ( cd "$dir" && "$@" )
  if $VW --release-dir "$dir" --expect-commit "$COMMIT" --expect-version "$V1" \
      >"$WORK/tam.out" 2>&1; then
    ko "$label: verifier must reject the tampered release set"
  elif grep -q "FAIL \[$token\]" "$WORK/tam.out"; then
    ok "$label"
  else
    ko "$label: rejected but via [$token] was expected: $(head -1 "$WORK/tam.out")"
  fi
}

tamper_m() { # matrix-mode variant: verifier runs with --matrix-dir $WORK/matrix
  local label=$1 token=$2; shift 2
  local dir="$WORK/tampered-m"
  rm -rf "$dir"; cp -r "$WORK/wheels-a" "$dir"
  ( cd "$dir" && "$@" )
  if $VW --release-dir "$dir" --matrix-dir "$WORK/matrix" --expect-commit "$COMMIT" \
      --expect-version "$V1" >"$WORK/tamm.out" 2>&1; then
    ko "$label: verifier must reject the tampered release set (matrix mode)"
  elif grep -q "FAIL \[$token\]" "$WORK/tamm.out"; then
    ok "$label"
  else
    ko "$label: rejected but via [$token] was expected: $(head -1 "$WORK/tamm.out")"
  fi
}

tamper "verifier catches a flipped byte inside a wheel member" outer python3 - "$V1" <<'PY'
import pathlib, sys, zipfile
version = sys.argv[1]
wheel = next(pathlib.Path(".").glob("*manylinux_2_28_x86_64.whl"))
meta_name = f"pocketshell_gateway_link-{version}.dist-info/METADATA"
with zipfile.ZipFile(wheel) as zf:
    infos = zf.infolist()
    payload = {i.filename: zf.read(i.filename) for i in infos}
meta = payload[meta_name]
payload[meta_name] = meta[:-1] + bytes([meta[-1] ^ 0x01])
with zipfile.ZipFile(wheel, "w") as zf:
    for i in infos:
        zf.writestr(i, payload[i.filename])
PY

tamper "verifier catches an edited manifest digest (checksums now disagree with the manifest)" sums \
  python3 - <<'PY'
import json, pathlib
p = pathlib.Path("wheels-manifest.json")
m = json.loads(p.read_bytes())
old = m["wheels"][0]["sha256"]
m["wheels"][0]["sha256"] = ("0" if old[0] != "0" else "1") + old[1:]  # guaranteed change
p.write_text(json.dumps(m, sort_keys=True, indent=2) + "\n")
PY

tamper "verifier catches an edited manifest digest even with refreshed outer checksums" outer \
  python3 - <<'PY'
import hashlib, json, pathlib
p = pathlib.Path("wheels-manifest.json")
m = json.loads(p.read_bytes())
old = m["wheels"][0]["sha256"]
m["wheels"][0]["sha256"] = ("0" if old[0] != "0" else "1") + old[1:]  # guaranteed change
raw = (json.dumps(m, sort_keys=True, indent=2) + "\n").encode()
p.write_bytes(raw)
sums = pathlib.Path("SHA256SUMS")
rows = [l for l in sums.read_text().splitlines() if not l.endswith("wheels-manifest.json")]
rows.append(f"{hashlib.sha256(raw).hexdigest()}  wheels-manifest.json")
sums.write_text("\n".join(sorted(rows)) + "\n")
PY

tamper "verifier catches a stale manifest revision against the expected commit" manifest \
  python3 - <<'PY'
import json, pathlib
p = pathlib.Path("wheels-manifest.json")
m = json.loads(p.read_bytes())
m["source_revision"] = "1" * 40
p.write_text(json.dumps(m, sort_keys=True, indent=2) + "\n")
PY

tamper "verifier catches a removed outer wheel sidecar" outer \
  rm -f "pocketshell_gateway_link-$V1-py3-none-manylinux_2_28_x86_64.whl.sha256"

tamper "verifier catches a removed release SHA256SUMS" sums rm -f SHA256SUMS

tamper "verifier catches a removed producer provenance copy" provenance rm -f helper-matrix-PROVENANCE.txt

tamper "C1: verifier parses the carried provenance and refuses another commit even with refreshed checksums" provenance \
  python3 - "$OTHER" <<'PY'
import hashlib, json, pathlib, sys
other = sys.argv[1]
p = pathlib.Path("helper-matrix-PROVENANCE.txt")
lines = [f"commit: {other}" if l.startswith("commit:") else l for l in p.read_text().splitlines()]
raw = ("\n".join(lines) + "\n").encode()
p.write_bytes(raw)
m = pathlib.Path("wheels-manifest.json")
mani = json.loads(m.read_bytes())
mani["producer"]["provenance"]["sha256"] = hashlib.sha256(raw).hexdigest()
mb = (json.dumps(mani, sort_keys=True, indent=2) + "\n").encode()
m.write_bytes(mb)
sums = pathlib.Path("SHA256SUMS")
rows = []
for l in sums.read_text().splitlines():
    if l.endswith("helper-matrix-PROVENANCE.txt"):
        l = f"{hashlib.sha256(raw).hexdigest()}  helper-matrix-PROVENANCE.txt"
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(mb).hexdigest()}  wheels-manifest.json"
    rows.append(l)
sums.write_text("\n".join(rows) + "\n")
PY

tamper "C5: verifier refuses a duplicate commit field in the carried provenance" provenance \
  python3 - "$OTHER" <<'PY'
import hashlib, json, pathlib, sys
other = sys.argv[1]
p = pathlib.Path("helper-matrix-PROVENANCE.txt")
raw = (p.read_text() + f"commit: {other}\n").encode()
p.write_bytes(raw)
m = pathlib.Path("wheels-manifest.json")
mani = json.loads(m.read_bytes())
mani["producer"]["provenance"]["sha256"] = hashlib.sha256(raw).hexdigest()
mb = (json.dumps(mani, sort_keys=True, indent=2) + "\n").encode()
m.write_bytes(mb)
sums = pathlib.Path("SHA256SUMS")
rows = []
for l in sums.read_text().splitlines():
    if l.endswith("helper-matrix-PROVENANCE.txt"):
        l = f"{hashlib.sha256(raw).hexdigest()}  helper-matrix-PROVENANCE.txt"
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(mb).hexdigest()}  wheels-manifest.json"
    rows.append(l)
sums.write_text("\n".join(rows) + "\n")
PY

tamper "C2: verifier refuses a zeroed helper_matrix map even with the manifest checksum refreshed" helper-matrix \
  python3 - <<'PY'
import hashlib, json, pathlib
p = pathlib.Path("wheels-manifest.json")
m = json.loads(p.read_bytes())
m["producer"]["helper_matrix"] = {k: {"sha256": "0" * 64} for k in m["producer"]["helper_matrix"]}
mb = (json.dumps(m, sort_keys=True, indent=2) + "\n").encode()
p.write_bytes(mb)
sums = pathlib.Path("SHA256SUMS")
rows = []
for l in sums.read_text().splitlines():
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(mb).hexdigest()}  wheels-manifest.json"
    rows.append(l)
sums.write_text("\n".join(sorted(rows)) + "\n")
PY

tamper_m "C2b: the same contradictory helper map is refused with the raw matrix supplied" helper-matrix \
  python3 - <<'PY'
import hashlib, json, pathlib
p = pathlib.Path("wheels-manifest.json")
m = json.loads(p.read_bytes())
m["producer"]["helper_matrix"] = {k: {"sha256": "0" * 64} for k in m["producer"]["helper_matrix"]}
mb = (json.dumps(m, sort_keys=True, indent=2) + "\n").encode()
p.write_bytes(mb)
sums = pathlib.Path("SHA256SUMS")
rows = []
for l in sums.read_text().splitlines():
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(mb).hexdigest()}  wheels-manifest.json"
    rows.append(l)
sums.write_text("\n".join(sorted(rows)) + "\n")
PY

tamper "C3: verifier refuses a manifest provenance record with required fields stripped" manifest \
  python3 - <<'PY'
import hashlib, json, pathlib
p = pathlib.Path("wheels-manifest.json")
m = json.loads(p.read_bytes())
for field in ("version", "built_at", "toolchain", "flags", "platforms", "file"):
    del m["producer"]["provenance"][field]
mb = (json.dumps(m, sort_keys=True, indent=2) + "\n").encode()
p.write_bytes(mb)
sums = pathlib.Path("SHA256SUMS")
rows = []
for l in sums.read_text().splitlines():
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(mb).hexdigest()}  wheels-manifest.json"
    rows.append(l)
sums.write_text("\n".join(sorted(rows)) + "\n")
PY

tamper "verifier refuses a stale provenance field that contradicts the carried receipt" provenance \
  python3 - <<'PY'
import hashlib, json, pathlib
p = pathlib.Path("wheels-manifest.json")
m = json.loads(p.read_bytes())
m["producer"]["provenance"]["built_at"] = "1999-01-01T00:00:00Z"
mb = (json.dumps(m, sort_keys=True, indent=2) + "\n").encode()
p.write_bytes(mb)
sums = pathlib.Path("SHA256SUMS")
rows = []
for l in sums.read_text().splitlines():
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(mb).hexdigest()}  wheels-manifest.json"
    rows.append(l)
sums.write_text("\n".join(sorted(rows)) + "\n")
PY

tamper "C4: verifier refuses a producer_file that is not canonical for the wheel's platform" manifest \
  python3 - <<'PY'
import hashlib, json, pathlib
p = pathlib.Path("wheels-manifest.json")
m = json.loads(p.read_bytes())
entry = next(e for e in m["wheels"] if e["platform"] == "linux-amd64")
entry["embedded_helper"]["producer_file"] = "pocketshell-link-darwin-arm64"
mb = (json.dumps(m, sort_keys=True, indent=2) + "\n").encode()
p.write_bytes(mb)
sums = pathlib.Path("SHA256SUMS")
rows = []
for l in sums.read_text().splitlines():
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(mb).hexdigest()}  wheels-manifest.json"
    rows.append(l)
sums.write_text("\n".join(sorted(rows)) + "\n")
PY

tamper "verifier refuses a duplicate JSON key in the manifest (ambiguous record)" manifest \
  python3 - <<'PY'
import hashlib, pathlib
p = pathlib.Path("wheels-manifest.json")
text = p.read_text()
marker = '"schema": "pocketshell-gateway-wheels-manifest/v1",'
i = text.index(marker)
raw = (text[:i] + marker + "\n" + text[i:]).encode()
p.write_bytes(raw)
sums = pathlib.Path("SHA256SUMS")
rows = []
for l in sums.read_text().splitlines():
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(raw).hexdigest()}  wheels-manifest.json"
    rows.append(l)
sums.write_text("\n".join(sorted(rows)) + "\n")
PY

# The decisive WP2/WP3 forges: fully checksum-consistent release sets whose
# ONLY contradiction is the embedded binary's architecture / build stamp.
forge_release() { # forge_release RELDIR WHEEL-SUFFIX REPLACEMENT-BIN
  python3 - "$1" "$2" "$3" <<'PY'
import base64, csv, hashlib, io, json, pathlib, sys, zipfile
rel = pathlib.Path(sys.argv[1])
suffix = sys.argv[2]
replacement = pathlib.Path(sys.argv[3]).read_bytes()
wheel = next(p for p in rel.glob("*.whl") if p.name.endswith(suffix))
rec = next(n for n in zipfile.ZipFile(wheel).namelist() if n.endswith(".dist-info/RECORD"))
def rh(data):
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()
with zipfile.ZipFile(wheel) as zin:
    infos = zin.infolist()
    members = []
    rows = []
    for i in infos:
        data = zin.read(i.filename)
        if i.filename.endswith("/bin/pocketshell-link"):
            data = replacement
        if i.filename != rec:
            rows.append(f"{i.filename},{rh(data)},{len(data)}")
        members.append((i, data))
    rows.append(f"{rec},,")
buf = io.BytesIO()
with zipfile.ZipFile(buf, "w") as zf:
    for info, data in members:
        zf.writestr(info, ("\r\n".join(rows) + "\r\n").encode() if info.filename == rec else data)
raw = buf.getvalue()
wheel.write_bytes(raw)
digest = hashlib.sha256(raw).hexdigest()
(wheel.parent / (wheel.name + ".sha256")).write_text(f"{digest}  {wheel.name}\n")
m = rel / "wheels-manifest.json"
mani = json.loads(m.read_bytes())
entry = next(e for e in mani["wheels"] if e["file"] == wheel.name)
entry["sha256"] = digest
entry["size_bytes"] = len(raw)
entry["embedded_helper"]["sha256"] = hashlib.sha256(replacement).hexdigest()
mani["producer"]["helper_matrix"][entry["embedded_helper"]["producer_file"]]["sha256"] = \
    hashlib.sha256(replacement).hexdigest()
mb = (json.dumps(mani, sort_keys=True, indent=2) + "\n").encode()
m.write_bytes(mb)
sums = rel / "SHA256SUMS"
rows2 = []
for l in sums.read_text().splitlines():
    if l.endswith(wheel.name):
        l = f"{digest}  {wheel.name}"
    if l.endswith("wheels-manifest.json"):
        l = f"{hashlib.sha256(mb).hexdigest()}  wheels-manifest.json"
    rows2.append(l)
sums.write_text("\n".join(sorted(rows2)) + "\n")
print("forged:", wheel.name)
PY
}

dir="$WORK/forged-arch"; rm -rf "$dir"; cp -r "$WORK/wheels-a" "$dir"
forge_release "$dir" "manylinux_2_28_x86_64.whl" "$WORK/matrix/pocketshell-link-linux-arm64" >/dev/null
if $VW --release-dir "$dir" --expect-commit "$COMMIT" --expect-version "$V1" \
    >"$WORK/fa.out" 2>&1; then
  ko "wrong-architecture payload with fully refreshed checksums: verifier must reject"
elif grep -q "FAIL \[architecture\]" "$WORK/fa.out"; then
  ok "WP2: wrong-architecture payload is caught by the ARCHITECTURE channel, not the checksum channel"
else
  ko "wrong-arch forged release rejected via unexpected channel: $(head -1 "$WORK/fa.out")"
fi

dir="$WORK/forged-stale"; rm -rf "$dir"; cp -r "$WORK/wheels-a" "$dir"
forge_release "$dir" "manylinux_2_28_x86_64.whl" "$WORK/stale-matrix/pocketshell-link-linux-amd64" >/dev/null
if $VW --release-dir "$dir" --expect-commit "$COMMIT" --expect-version "$V1" \
    >"$WORK/fs.out" 2>&1; then
  ko "stale-build-stamp payload with fully refreshed checksums: verifier must reject"
elif grep -q "FAIL \[buildinfo\]" "$WORK/fs.out"; then
  ok "WP3: a real stale helper (other revision) under a fully consistent forged release is caught by the embedded build stamp"
else
  ko "stale forged release rejected via unexpected channel: $(head -1 "$WORK/fs.out")"
fi

# The RECORD-only calibration: RECORD is consistency data, the outer set is
# the swap control (unchanged from the previous delivery).
rm -rf "$WORK/swapped"; cp -r "$WORK/wheels-a" "$WORK/swapped"
if python3 - "$WORK/swapped" "$V1" <<'PY'
import base64, hashlib, pathlib, sys, zipfile
d = pathlib.Path(sys.argv[1])
version = sys.argv[2]
rec = f"pocketshell_gateway_link-{version}.dist-info/RECORD"
src = d / f"pocketshell_gateway_link-{version}-py3-none-macosx_11_0_arm64.whl"
dst = d / f"pocketshell_gateway_link-{version}-py3-none-manylinux_2_28_x86_64.whl"
swap = zipfile.ZipFile(src).read("pocketshell_gateway_link/bin/pocketshell-link")
with zipfile.ZipFile(dst) as zin:
    members = [(i, zin.read(i.filename)) for i in zin.infolist()]
def rh(data):
    return "sha256=" + base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b"=").decode()
rows = []
rewritten = []
for info, data in members:
    if info.filename.endswith("/bin/pocketshell-link"):
        data = swap  # the OTHER platform's helper bytes
    if info.filename != rec:
        rows.append(f"{info.filename},{rh(data)},{len(data)}")
    rewritten.append((info, data))
rows.append(f"{rec},,")
with zipfile.ZipFile(dst, "w") as zf:
    for info, data in rewritten:
        zf.writestr(info, ("\r\n".join(rows) + "\r\n").encode() if info.filename == rec else data)
PY
then
  ok "fixture built: same-format helper swap with internally consistent RECORD"
else
  ko "same-format swap fixture construction failed"
fi

if $VW --release-dir "$WORK/swapped" --expect-commit "$COMMIT" --expect-version "$V1" \
    >"$WORK/swap.out" 2>&1; then
  ko "verifier must reject the RECORD-consistent helper swap"
elif grep -q "FAIL \[outer\]" "$WORK/swap.out"; then
  ok "verifier catches the swapped embedded helper via the OUTER digest set (RECORD passed in vain)"
else
  ko "helper swap rejected via unexpected channel: $(head -1 "$WORK/swap.out")"
fi

# matrix-mode raw negatives: the verifier re-applies the full producer
# contract to the RAW record set, not just the packaged bytes.
rm -rf "$WORK/mx-flags"; cp -r "$WORK/matrix" "$WORK/mx-flags"
python3 - "$WORK/mx-flags" "$OTHER" <<'PY'
import pathlib, sys
p = pathlib.Path(sys.argv[1]) / "PROVENANCE.txt"
other = sys.argv[2]
lines = p.read_text().splitlines()
out = []
for l in lines:
    if l.startswith("flags:"):
        l = l[:-1] + f' -X main.commit={other}"'
    out.append(l)
p.write_text("\n".join(out) + "\n")
PY
refresh_checksums "$WORK/mx-flags"
if $VW --release-dir "$WORK/wheels-a" --matrix-dir "$WORK/mx-flags" \
    --expect-commit "$COMMIT" --expect-version "$V1" >"$WORK/mxf.out" 2>&1; then
  ko "matrix-mode conflicting raw flags: verifier must refuse"
elif grep -q "FAIL \[provenance\]" "$WORK/mxf.out"; then
  ok "matrix mode: the verifier re-parses the RAW provenance and refuses conflicting -X main.commit assignments"
else
  ko "matrix-mode raw flags conflict rejected via unexpected channel: $(head -1 "$WORK/mxf.out")"
fi

# stale raw matrix under a forged current label: the verifier's commit check
# passes (label == expectation), so the RAW BINARIES' build stamps must be
# what refuses (matrix-mode buildinfo inspection).
rm -rf "$WORK/mx-stale"; cp -r "$WORK/stale-matrix" "$WORK/mx-stale"
write_matrix_records "$WORK/mx-stale" "$COMMIT"
if $VW --release-dir "$WORK/wheels-a" --matrix-dir "$WORK/mx-stale" \
    --expect-commit "$COMMIT" --expect-version "$V1" >"$WORK/mxs.out" 2>&1; then
  ko "matrix-mode stale raw matrix: verifier must refuse"
elif grep -q "FAIL \[buildinfo\]" "$WORK/mxs.out"; then
  ok "matrix mode: the verifier inspects the RAW binaries' build stamps and refuses another revision"
else
  ko "matrix-mode stale matrix rejected via unexpected channel: $(head -1 "$WORK/mxs.out")"
fi

# --- 3. build matrix + REAL built-helper packaging receipt ----------------------
if [ -d "$ROOT/cmd/pocketshell-link" ]; then
  RV=$(git -C "$ROOT" rev-parse HEAD)
  RWV="0.0.0+$(git -C "$ROOT" rev-parse --short=12 HEAD)"
  if [ -n "$(git -C "$ROOT" status --porcelain)" ]; then
    # A dirty worktree cannot produce a clean-source receipt: the buildinfo
    # gate must refuse. Assert that refusal instead of pretending.
    if (cd "$ROOT" && make wheels >"$WORK/real.out" 2>&1); then
      ko "dirty full-source tree: make wheels must refuse a vcs.modified=true matrix"
    elif grep -q "vcs.modified" "$WORK/real.out"; then
      ok "dirty worktree fail-closed: make wheels refuses an uncommitted-source matrix (vcs.modified gate)"
    else
      ko "dirty worktree refusal without naming the gate: $(head -2 "$WORK/real.out")"
    fi
    note "PENDING (honest): the real 4-platform wheel receipt needs a CLEAN full-source checkout (git status --porcelain empty) — run this harness there; this dirty tree only proves the fail-closed gate"
  elif make build-matrix >/dev/null 2>&1; then
    ok "make build-matrix built the full matrix"
    python3 - "$ROOT/build/dist/helper-matrix" <<'PY' && ok "every matrix binary matches its platform magic + sidecar digest" || ko "matrix binary/platform verification failed"
import hashlib, pathlib, struct, sys
mdir = pathlib.Path(sys.argv[1])
EXPECT = {
    "pocketshell-link-linux-amd64": ("elf", 0x3E),
    "pocketshell-link-linux-arm64": ("elf", 0xB7),
    "pocketshell-link-darwin-amd64": ("macho", 0x01000007),
    "pocketshell-link-darwin-arm64": ("macho", 0x0100000C),
}
for name, (kind, machine) in EXPECT.items():
    p = mdir / name
    data = p.read_bytes()
    if kind == "elf":
        assert data[:4] == b"\x7fELF" and data[4] == 2, f"{name}: not ELF64"
        assert struct.unpack_from("<H", data, 18)[0] == machine, f"{name}: wrong e_machine"
    else:
        assert data[:4] == b"\xcf\xfa\xed\xfe", f"{name}: not little-endian Mach-O"
        assert struct.unpack_from("<I", data, 4)[0] == machine, f"{name}: wrong cputype"
    side = (mdir / (name + ".sha256")).read_text().split()
    assert side[1] == name and side[0] == hashlib.sha256(data).hexdigest(), f"{name}: sidecar digest mismatch"
sums = {}
for line in (mdir / "SHA256SUMS").read_text().splitlines():
    digest, fn = line.split(None, 1)
    sums[fn.strip()] = digest
for name in EXPECT:
    assert sums.get(name) == hashlib.sha256((mdir / name).read_bytes()).hexdigest(), f"{name}: SHA256SUMS mismatch"
prov = (mdir / "PROVENANCE.txt").read_text()
assert "version:" in prov and "commit:" in prov and "linux/amd64" in prov
print("platforms verified:", ", ".join(EXPECT))
PY
    # REAL packaging receipt: the actual built helpers, packaged and verified
    # end to end (outer digests, manifest members, embedded == raw producer).
    if (cd "$ROOT" && make wheels >/dev/null 2>&1); then
      if $VW --release-dir "$ROOT/build/dist/wheels" --matrix-dir "$ROOT/build/dist/helper-matrix" \
          --expect-commit "$RV" --expect-version "$RWV" >"$WORK/real.out" 2>&1; then
        ok "REAL wheel release verified against the actual built helper matrix @ $RV"
        note "receipt: $(head -1 "$WORK/real.out")"
        note "manifest digest: $(sha256sum "$ROOT/build/dist/wheels/wheels-manifest.json" | awk '{print $1}')"
        for w in "$ROOT"/build/dist/wheels/*.whl; do
          note "receipt: $(basename "$w") $(sha256sum "$w" | awk '{print $1}')"
        done
      else
        ko "REAL wheel release failed independent verification: $(cat "$WORK/real.out")"
      fi
      if grep -q "\"source_revision\": \"$RV\"" "$ROOT/build/dist/wheels/wheels-manifest.json"; then
        ok "real manifest binds the release to the exact git HEAD revision"
      else
        ko "real manifest source_revision != git HEAD"
      fi
    else
      ko "make wheels failed on a clean full-source tree"
    fi
  else
    ko "make build-matrix failed on a full-source tree"
  fi
else
  if (cd "$ROOT" && make build-matrix >"$WORK/mx.out" 2>&1); then
    ko "build-matrix succeeded WITHOUT cmd/pocketshell-link — fail-closed broken"
  elif grep -q "cmd/pocketshell-link not on this tree" "$WORK/mx.out"; then
    ok "standalone tree: build-matrix fails closed naming the runtime dependency"
  else
    ko "build-matrix failed without naming the dependency: $(head -2 "$WORK/mx.out")"
  fi
  note "PENDING (honest): the final 4-platform wheel receipt needs the full-source tree (cmd/pocketshell-link) — root integration; the real locally-compiled fixtures above do NOT substitute for it and no earlier-revision helper may be passed off as the final release"
fi

finish
