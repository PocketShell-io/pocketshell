#!/usr/bin/env python3
"""Source and real-shell regressions for the bounded SSM envelope (no AWS).

Real execution uses only a tiny inert fixture, never the deployment body.
Root is needed for the actual private /run staging path; sudo -n is explicit.
"""
import base64
import gzip
import hashlib
import importlib.util
import json
import pathlib
import re
import select
import subprocess
import sys
import unittest

import yaml

ROOT = pathlib.Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("gateway_generator", ROOT / "scripts/gen-infra.py")
gen = importlib.util.module_from_spec(spec)
sys.dont_write_bytecode = True
spec.loader.exec_module(gen)


class Loader(yaml.SafeLoader):
    pass


Loader.add_multi_constructor("!", lambda ld, tag, node: ld.construct_scalar(node) if isinstance(node, yaml.ScalarNode) else ld.construct_sequence(node) if isinstance(node, yaml.SequenceNode) else ld.construct_mapping(node))


class EnvelopeTests(unittest.TestCase):
    def setUp(self):
        self.template = yaml.load((ROOT / "infra/github-actions.yaml").read_text(), Loader=Loader)
        self.content = self.template["Resources"]["GatewayDeployDocument"]["Properties"]["Content"]
        self.command = self.content["mainSteps"][0]["inputs"]["runCommand"][0]

    def fixture(self):
        payload = b'''#!/bin/bash
trap 'echo CHILD_CLEANUP' EXIT
printf 'EXECUTED:%s\\n' "$0"
printf 'ARGV:<%s>\\n' "$@"
stat -c 'STAGE:%u:%a' -- "${0%/*}"
exit 23
'''
        return payload, "\n".join(gen.envelope(payload)) + "\n"

    def run_root(self, command):
        before = set(pathlib.Path("/run").glob("pocketshell-deploy.*"))
        result = subprocess.run(["sudo", "-n", "/bin/sh", "-s"], input=command, text=True, capture_output=True, timeout=15)
        after = set(pathlib.Path("/run").glob("pocketshell-deploy.*"))
        self.assertEqual(after - before, set(), "wrapper leaked its private stage")
        return result

    def test_actual_payload_reconstruction_and_syntax(self):
        payload = gen.decode_embedded(self.command)
        self.assertEqual(payload, gen.trusted_payload())
        self.assertTrue(payload.endswith(b'main "$@"\n'))
        self.assertNotIn(b"{{", payload)
        self.assertEqual(subprocess.run(["/bin/bash", "-n"], input=payload, capture_output=True).returncode, 0)
        self.assertEqual(subprocess.run(["/bin/sh", "-n"], input=self.command.encode(), capture_output=True).returncode, 0)
        sources = [gen.SRC, gen.PROVISION, ROOT / "scripts/host/imds-probe.sh", ROOT / "scripts/host/imds-guard.sh"]
        for source in sources:
            raw = source.read_bytes().rstrip(b"\n")
            if source == gen.SRC:
                raw = raw.removesuffix(b'main "$@"')
            self.assertIn(raw, payload)
        self.assertLess(payload.index(gen.PROVISION.read_bytes().rstrip(b"\n")), payload.index(b'helper_install "$HELPERS_DIR/imds-probe.sh"'))
        self.assertLess(payload.index(b'helper_install "$HELPERS_DIR/imds-probe.sh"'), payload.index(b'helper_install "$HELPERS_DIR/imds-guard.sh"'))
        self.assertEqual(set(re.findall(r"\{\{(\w+)\}\}", self.command)), set(self.content["parameters"]))

    def test_determinism_and_regeneration_idempotence(self):
        payload = gen.trusted_payload()
        self.assertEqual(gen.envelope(payload), gen.envelope(payload))
        encoded = gen.envelope(payload)[gen.envelope(payload).index(gen.PAYLOAD_EOF)-1]
        compressed = base64.b64decode(encoded)
        self.assertEqual(compressed[4:8], b"\0" * 4)  # mtime = 0
        self.assertEqual(compressed[9], 255)  # platform-independent gzip header
        self.assertEqual(gzip.decompress(compressed), payload)
        before = (ROOT / "infra/github-actions.yaml").read_bytes()
        subprocess.run(["python3", str(ROOT / "scripts/gen-infra.py")], check=True, capture_output=True)
        self.assertEqual((ROOT / "infra/github-actions.yaml").read_bytes(), before)

    def test_document_and_worst_parameter_budget(self):
        params = self.content["parameters"]
        for name, p in params.items():
            self.assertGreater(p["maxChars"], 0)
            default = p.get("default")
            if isinstance(default, str):
                default = self.template["Parameters"].get(default, {}).get("Default", default)
                self.assertLessEqual(len(default), p["maxChars"], name)
        budget = 1024 + sum(p["maxChars"] * (1 + self.command.count("{{" + name + "}}")) + len(name) + 16 for name, p in params.items())
        size = len(json.dumps(self.content, ensure_ascii=True).encode())
        self.assertLessEqual(size + budget, 65536)
        print(f"SSM_BYTES={size} PARAMETER_BUDGET={budget} TOTAL={size + budget}")
        # The historical raw body is demonstrably too big, even without params.
        raw = dict(self.content)
        raw["mainSteps"] = [{"inputs": {"runCommand": [gen.trusted_payload().decode()]}}]
        self.assertGreater(len(json.dumps(raw).encode()), 65536)

    def test_unicode_and_json_escaping_surcharge_for_pinned_wildcard_slots(self):
        expected = {"Domain": ("CanonicalDomain", "gateway.pocketshell.io"), "Aliases": ("LegacyAlias", "relay.pocketshell.io")}
        for name, (bootstrap, default) in expected.items():
            self.assertEqual(self.template["Parameters"][bootstrap]["Default"], default)
            self.assertEqual(self.content["parameters"][name]["allowedPattern"], "^${" + bootstrap + "}$")
            for wildcard in ("é", "😀", '\"', "\\"):
                value = default.replace(".", wildcard)
                self.assertRegex(value, "^" + default + "$")
                self.assertLessEqual(len(value), self.content["parameters"][name]["maxChars"])
                encoded_extra = len(json.dumps(value, ensure_ascii=True).encode()) - len(value)
                self.assertLessEqual(encoded_extra * (1 + self.command.count("{{" + name + "}}")), 1024 // 2)

    def test_actual_execution_arguments_child_status_and_cleanup(self):
        _, command = self.fixture()
        result = self.run_root(command)
        self.assertEqual(result.returncode, 23, result.stderr)
        self.assertIn("EXECUTED:/run/pocketshell-deploy.", result.stdout)
        self.assertIn("STAGE:0:700", result.stdout)
        self.assertIn("CHILD_CLEANUP", result.stdout)
        self.assertIn("ARGV:<{{Bucket}}>", result.stdout)
        self.assertIn("ARGV:<--registry>", result.stdout)
        self.assertIn("ARGV:<{{RegistryFile}}>", result.stdout)

    def check_cancellation(self, signal, ignore_term=False):
        payload = b'''#!/bin/bash
trap 'echo CHILD_TERM; exit 42' TERM
trap 'echo CHILD_CLEANUP' EXIT
echo WRAPPER_PID=$PPID
while true; do sleep 0.05; done
'''
        if ignore_term:
            payload = payload.replace(b"trap 'echo CHILD_TERM; exit 42' TERM", b"trap '' TERM")
        command = "\n".join(gen.envelope(payload)) + "\n"
        before = set(pathlib.Path("/run").glob("pocketshell-deploy.*"))
        child = subprocess.Popen(["sudo", "-n", "/bin/sh", "-s"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        try:
            child.stdin.write(command)
            child.stdin.close()
            child.stdin = None
            self.assertTrue(select.select([child.stdout], [], [], 5)[0], "child never announced wrapper PID")
            line = child.stdout.readline()
            self.assertRegex(line, r"^WRAPPER_PID=[0-9]+\n$")
            pid = line.strip().split("=", 1)[1]
            subprocess.run(["sudo", "-n", "kill", "-" + signal, pid], check=True)
            stdout, stderr = child.communicate(timeout=10)
            self.assertEqual(child.returncode, 130 if signal == "INT" else 143, stderr)
            if ignore_term:
                self.assertNotIn("CHILD_CLEANUP", stdout)  # KILL cannot promise rollback
            else:
                self.assertIn("CHILD_TERM", stdout)
                self.assertIn("CHILD_CLEANUP", stdout)
            self.assertEqual(set(pathlib.Path("/run").glob("pocketshell-deploy.*")) - before, set())
        finally:
            if child.poll() is None:
                # The exact announced wrapper is our fixture; signal its direct
                # child for test teardown before killing the waiting sudo client.
                if 'pid' in locals():
                    subprocess.run(["sudo", "-n", "pkill", "-TERM", "-P", pid], capture_output=True)
                child.kill()
                child.wait()

    def test_wrapper_term_reaches_child_and_both_cleanups_run(self):
        self.check_cancellation("TERM")

    def test_wrapper_int_maps_to_child_term_without_hanging(self):
        self.check_cancellation("INT")

    def test_term_ignoring_child_is_killed_with_bounded_wrapper_cleanup(self):
        self.check_cancellation("TERM", ignore_term=True)

    def test_nonroot_refused_before_decode(self):
        _, command = self.fixture()
        before = set(pathlib.Path("/run").glob("pocketshell-deploy.*"))
        result = subprocess.run(["sudo", "-n", "-u", "nobody", "/bin/sh", "-s"], input=command, text=True, capture_output=True, timeout=10)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("requires root", result.stderr)
        self.assertNotIn("EXECUTED", result.stdout)
        self.assertEqual(set(pathlib.Path("/run").glob("pocketshell-deploy.*")) - before, set())

    def test_wrong_digest_never_executes(self):
        payload, command = self.fixture()
        command = command.replace(hashlib.sha256(payload).hexdigest(), "0" * 64)
        result = self.run_root(command)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("hash mismatch", result.stderr)
        self.assertNotIn("EXECUTED", result.stdout)

    def test_valid_gzip_tampered_body_never_executes(self):
        payload, command = self.fixture()
        lines = command.splitlines()
        end = lines.index(gen.PAYLOAD_EOF)
        changed = payload.replace(b"exit 23", b"exit 24")
        self.assertEqual(len(changed), len(payload))
        lines[end - 1] = base64.b64encode(gzip.compress(changed, mtime=0)).decode()
        result = self.run_root("\n".join(lines) + "\n")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("hash mismatch", result.stderr)
        self.assertNotIn("EXECUTED", result.stdout)

    def test_truncated_and_malformed_payloads_never_execute(self):
        for corrupt in (lambda text: text[:-4], lambda text: "!" + text[1:]):
            with self.subTest(corrupt=corrupt):
                _, command = self.fixture()
                lines = command.splitlines()
                end = lines.index(gen.PAYLOAD_EOF)
                lines[end - 1] = corrupt(lines[end - 1])
                result = self.run_root("\n".join(lines) + "\n")
                self.assertNotEqual(result.returncode, 0)
                self.assertIn("decode failed", result.stderr)
                self.assertNotIn("EXECUTED", result.stdout)

    def test_oversized_decoded_payload_is_bounded_and_never_executes(self):
        _, command = self.fixture()
        lines = command.splitlines()
        end = lines.index(gen.PAYLOAD_EOF)
        lines[end - 1] = base64.b64encode(gzip.compress(b"A" * 2_000_000, mtime=0)).decode()
        result = self.run_root("\n".join(lines) + "\n")
        self.assertNotEqual(result.returncode, 0)
        self.assertNotIn("EXECUTED", result.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
