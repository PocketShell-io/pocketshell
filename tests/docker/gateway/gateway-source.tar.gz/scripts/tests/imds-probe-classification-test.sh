#!/bin/sh
# Standalone offline regression suite for the IMDS probe timeout
# classification (scripts/host/imds-probe.sh).
#
# The suite executes the ACTUAL helper through its IMDS_PROBE_CURL seam with
# an injected fake curl. It never re-implements the classification logic and
# never opens a socket: the fake curl is a plain shell script that records
# its argv and emits a canned "http_code num_connects" write-out plus exit
# status per address family.
#
# Frozen counterexamples (RED under the pre-fix helper that accepted
# rc 7|28 before looking at the HTTP code) pin the corrected contract:
#   * an HTTP answer followed by any transfer error (200/403 + rc 28 or 7)
#     must NEVER be classified "blocked" — packets traversed the filter;
#   * rc 28 with http_code 000 AFTER a TCP connection was established
#     (num_connects > 0) is ambiguous and must fail closed as unproven;
#   * refused/unreachable (rc 7) with an exact "000 0" (no HTTP answer, no
#     connection) proves connection-level blocking (exit 0);
#   * a CONNECT-phase timeout (rc 28, "000 0": the TCP handshake never
#     completed) is what systemd's IPAddressDeny BPF egress drop produces on
#     a real kernel; it is reported as its own verdict, "dropped" (exit 10),
#     which the installer accepts ONLY together with an unfiltered positive
#     control (incident 2026-10-09, deploy 37970949069 — the pre-fix helper
#     called it inconclusive, so strategy A could never pass);
#   * empty or malformed status output is always unproven.
#
# Usage: scripts/tests/imds-probe-classification-test.sh
# Exit 0 = all checks passed; exit 1 = at least one failure.
set -u

TESTS_DIR=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
PROBE="$TESTS_DIR/../host/imds-probe.sh"

[ -f "$PROBE" ] || { printf '%s\n' "FAIL probe helper not found at $PROBE"; exit 1; }

WORK=$(mktemp -d "${TMPDIR:-/tmp}/imds-probe-classification.XXXXXX") || exit 1
trap 'rm -rf "$WORK"' EXIT

pass=0
fail=0
ok()  { pass=$((pass + 1)); printf 'ok   %s\n' "$1"; }
bad() { fail=$((fail + 1)); printf 'FAIL %s\n' "$1"; }

# Fake curl: behavior per family is FIXTURE_V4 / FIXTURE_V6 as "rc:code"
# (code may be empty or deliberately malformed; a bare "code" means rc 0).
cat >"$WORK/fake-curl" <<'EOF'
#!/bin/sh
argv_file=${FIXTURE_ARGV_FILE:-/dev/null}
for a in "$@"; do
  printf '%s\n' "$a" >>"$argv_file"
done
case "$*" in
  *169.254.169.254*) spec=${FIXTURE_V4-} ;;
  *)                 spec=${FIXTURE_V6-} ;;
esac
rc=${spec%%:*}
code=${spec#*:}
[ "$rc" = "$spec" ] && rc=0
printf '%s' "$code"
exit "$rc"
EOF
chmod +x "$WORK/fake-curl"

# run_probe V4SPEC V6SPEC: run the actual helper; stdout/stderr land in
# $WORK/out so silence can be asserted (no token, no diagnostics escape).
run_probe() {
  : >"$WORK/argv"
  : >"$WORK/out"
  FIXTURE_V4="$1" FIXTURE_V6="$2" FIXTURE_ARGV_FILE="$WORK/argv" \
    IMDS_PROBE_CURL="$WORK/fake-curl" "$PROBE" >"$WORK/out" 2>&1
}

# expect LABEL EXPECTED V4SPEC V6SPEC — asserts exit code, silence, and that
# the first family's verdict can never be masked by the second's.
expect() {
  label=$1
  run_probe "$3" "$4"
  rc=$?
  if [ "$rc" -ne "$2" ]; then
    bad "$label: expected exit $2, got $rc"
    return
  fi
  if [ -s "$WORK/out" ]; then
    bad "$label: helper wrote unexpected output"
    return
  fi
  ok "$label (exit $rc)"
}

# Fixture specs are "rc:write-out" where write-out is what curl prints for
# -w '%{http_code} %{num_connects}' (a bare "write-out" means rc 0).

# --- frozen RED counterexamples: HTTP answer + nonzero rc is never blocked ---
expect 'RED 200+rc28 both families is not classified blocked (unproven)' 2 '28:200 1' '28:200 1'
expect 'RED 403+rc28 both families is not classified blocked (unproven)' 2 '28:403 1' '28:403 1'
expect 'RED 000+rc28 AFTER a TCP connect (num_connects=1) is not blocked' 2 '28:000 1' '28:000 1'
expect 'RED 200+rc7 (answer then connection error) is unproven'          2 '7:200 1' '7:200 1'
expect 'RED 403+rc7 (answer then connection error) is unproven'          2 '7:403 1' '7:403 1'

# --- incident 2026-10-09 (deploy 37970949069, AL2023 / systemd 252): ----------
# systemd IPAddressDeny is a cgroup BPF egress filter that DROPS the SYN; the
# kernel ignores the -EPERM from the dropped transmit inside tcp_connect, so
# curl sees a CONNECT-phase timeout (rc 28, http 000, num_connects 0) — never
# a refusal. The live host's manual check under the same IPAddressDeny saw
# exactly rc 28 / 000. The pre-fix helper classified that as "inconclusive"
# (exit 2), so strategy A could NEVER pass on a real kernel and the installer
# fell back to the uid firewall on a host without iptables (outage).
expect 'RED BPF drop: connect-phase timeout, 0 connects both families -> dropped (10)' 10 '28:000 0' '28:000 0'
expect 'RED BPF drop on IPv4 + IPv6 unreachable (rc7) -> dropped (10)'               10 '28:000 0' '7:000 0'
expect 'RED IPv4 refused + IPv6 BPF drop -> dropped (10)'                            10 '7:000 0' '28:000 0'

# --- first-family failure must not be hidden by the second family ---
expect 'IPv4 unproven (200+28) not hidden by IPv6 blocked (000+7)'       2 '28:200 1' '7:000 0'
expect 'IPv6 unproven (connected+28) not hidden by IPv4 blocked (000+7)' 2 '7:000 0' '28:000 1'
expect 'IPv6 token obtainable not hidden by IPv4 dropped'                1 '28:000 0' '0:200 1'

# --- healthy / unexpected complete answers ---
expect 'healthy complete 200 both families: protection ineffective (1)'  1 '0:200 1' '0:200 1'
expect 'complete unexpected 403 both families: refused (2)'              2 '0:403 1' '0:403 1'
expect 'inconsistent rc0+000: unproven'                                  2 '0:000 0' '0:000 0'
expect 'complete non-200 405 both families: refused (2)'                 2 '0:405 1' '0:405 1'

# --- ambiguous timeouts and infrastructure failures fail closed ---
expect 'rc28 after connect on IPv4, rc7 on IPv6: overall unproven'       2 '28:000 1' '7:000 0'
expect 'rc5 infrastructure failure: unproven'                            2 '5:000 0' '5:000 0'
expect 'rc6 infrastructure failure: unproven'                            2 '6:000 0' '6:000 0'
expect 'refused but curl claims a connection (7, 000, 1): unproven'      2 '7:000 1' '7:000 1'

# --- malformed / empty status output is always unproven, even with rc7 ---
expect 'empty output + rc28: unproven'                                   2 28: 28:
expect 'empty output + rc7 is NOT protected'                             2 7: 7:
expect 'legacy bare "000" (no num_connects) + rc7: unproven'             2 7:000 7:000
expect 'legacy bare "000" (no num_connects) + rc28: unproven'            2 28:000 28:000
expect 'malformed "20x" + rc28: unproven'                                2 '28:20x 0' '28:20x 0'
expect 'malformed 4-digit "2000" + rc7: unproven'                        2 '7:2000 0' '7:2000 0'
expect 'short "00" + rc7: unproven'                                      2 '7:00 0' '7:00 0'
expect 'non-numeric num_connects + rc28: unproven'                       2 '28:000 x' '28:000 x'
expect 'trailing junk after num_connects + rc28: unproven'               2 '28:000 0 1' '28:000 0 1'

# --- honest connection-level denial: refused/unreachable, no HTTP answer ---
expect 'honest 000+rc7, 0 connects, both families: protected (0)'       0 '7:000 0' '7:000 0'

# --- positive control mode (--control): ONLY a complete 200 is exit 20 ------
# (systemd-run returns 1 for its own start failures, so the control's
# positive verdict must be a code systemd-run never produces by itself)
expect_control() {
  : >"$WORK/argv"; : >"$WORK/out"
  FIXTURE_V4="$2" FIXTURE_V6='0:200 1' FIXTURE_ARGV_FILE="$WORK/argv" \
    IMDS_PROBE_CURL="$WORK/fake-curl" "$PROBE" --control >"$WORK/out" 2>&1
  rc=$?
  if [ "$rc" -ne 20 ] && [ "$3" = 20 ]; then bad "$1: expected exit 20, got $rc"; return; fi
  if [ "$3" != 20 ] && [ "$rc" -ne "$3" ]; then bad "$1: expected exit $3, got $rc"; return; fi
  if grep -q -F 'fd00:ec2::254' "$WORK/argv"; then bad "$1: control probed IPv6"; return; fi
  ok "$1 (exit $rc)"
}
expect_control 'control: complete 200 = IMDS reachable (20)'      '0:200 1' 20
expect_control 'control: refused = not a positive control (2)'   '7:000 0' 2
expect_control 'control: dropped = not a positive control (2)'   '28:000 0' 2
expect_control 'control: 403 answer = not a positive control (2)' '0:403 1' 2
expect_control 'control: 200 then timeout = not positive (2)'    '28:200 1' 2

# --- missing curl binary is infrastructure failure, not denial ---
: >"$WORK/out"
IMDS_PROBE_CURL="$WORK/definitely-missing-curl" "$PROBE" >"$WORK/out" 2>&1
rc=$?
if [ "$rc" -eq 2 ] && [ ! -s "$WORK/out" ]; then
  ok 'missing curl binary: unproven (2), silent'
else
  bad "missing curl binary: expected exit 2, got $rc"
fi

# --- hostile proxy environment must not flip the verdict ---
: >"$WORK/out"
: >"$WORK/argv"
FIXTURE_V4='7:000 0' FIXTURE_V6='7:000 0' FIXTURE_ARGV_FILE="$WORK/argv" \
  http_proxy=http://127.0.0.1:9 https_proxy=http://127.0.0.1:9 \
  all_proxy=http://127.0.0.1:9 \
  IMDS_PROBE_CURL="$WORK/fake-curl" "$PROBE" >"$WORK/out" 2>&1
rc=$?
if [ "$rc" -eq 0 ] && [ ! -s "$WORK/out" ]; then
  ok 'blocked verdict holds under hostile proxy env (0), silent'
else
  bad "hostile proxy env: expected exit 0, got $rc"
fi

# --- argument assertions: bounds, noproxy, body discard, PUT, token URL ---
# Collected from the last fake-curl run above (one call per family).
argv_contains() {
  if grep -F -x -q -- "$2" "$WORK/argv"; then
    ok "argv has $1"
  else
    bad "argv missing $1 ('$2')"
  fi
}
argv_contains 'silent flag'            '-sS'
argv_contains 'noproxy flag'           '--noproxy'
argv_contains 'noproxy wildcard'       '*'
argv_contains 'body-discard flag'      '-o'
argv_contains 'body-discard target'    '/dev/null'
argv_contains 'max-time bound flag'    '--max-time'
argv_contains 'max-time bound value'   '3'
argv_contains 'connect-timeout flag'   '--connect-timeout'
argv_contains 'connect-timeout value'  '2'
argv_contains 'write-out flag'         '-w'
argv_contains 'write-out status fields' '%{http_code} %{num_connects}'
argv_contains 'PUT method flag'        '-X'
argv_contains 'PUT method value'       'PUT'
argv_contains 'token header flag'      '-H'
argv_contains 'token header value'     'X-aws-ec2-metadata-token-ttl-seconds: 60'
argv_contains 'IPv4 token URL'         'http://169.254.169.254/latest/api/token'
argv_contains 'IPv6 token URL'         'http://[fd00:ec2::254]/latest/api/token'
# Exactly 16 arguments per call, exactly one call per family: no smuggled
# extra output files, URLs, or options beyond the bounded set above.
lines=$(wc -l <"$WORK/argv" | tr -d ' ')
if [ "$lines" -eq 32 ]; then
  ok 'argv count: exactly 16 args x 2 calls (no extras)'
else
  bad "argv count: expected 32 lines (16 args x 2 calls), got $lines"
fi
v4calls=$(grep -c -F -x 'http://169.254.169.254/latest/api/token' "$WORK/argv")
v6calls=$(grep -c -F -x 'http://[fd00:ec2::254]/latest/api/token' "$WORK/argv")
if [ "$v4calls" -eq 1 ] && [ "$v6calls" -eq 1 ]; then
  ok 'exactly one probe call per address family'
else
  bad "call counts: IPv4=$v4calls IPv6=$v6calls (expected 1 and 1)"
fi

printf '%s\n' "---------------------------------------------------------"
printf 'imds-probe-classification: %d passed, %d failed\n' "$pass" "$fail"
[ "$fail" -eq 0 ] || exit 1
exit 0
