#!/usr/bin/env python3
"""Workflow contract checker for the delivery CI/CD surfaces (D14).

Usage: workflow_check.py [ROOT]   (default: the repo this file lives in)

Asserts the same-commit deploy gate on ROOT/.github/workflows: ci.yml runs
every quality gate and its `deploy` job calls the reusable deploy.yml only
after ALL needs succeeded (no failure/cancel/skip), actions pinned to SHAs,
artifact upload/download name binding, job-only id-token, no deploy
cancellation, no independent deploy trigger. Exits 0 clean, 1 with a list
of violations.

This file is the CHECK; scripts/tests/workflow-harness.sh proves the check
has teeth by mutating copies and requiring detection.
"""
from __future__ import annotations

import pathlib
import re
import sys

import yaml

FAILURES: list[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    if not cond:
        FAILURES.append(f"{name}{': ' + detail if detail else ''}")
        print(f"VIOLATION: {name}{': ' + detail if detail else ''}")


def load(path: pathlib.Path) -> dict:
    class L(yaml.SafeLoader):
        pass

    L.add_multi_constructor("!", lambda ld, tag, node: None)
    return yaml.load(path.read_text(), Loader=L)


def main() -> None:
    root = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parents[2]
    wf = root / ".github" / "workflows"
    try:
        ci = load(wf / "ci.yml")
        deploy = load(wf / "deploy.yml")
        probe = load(wf / "oidc-probe.yml")
    except (OSError, yaml.YAMLError) as e:
        print(f"cannot load workflows: {e}")
        sys.exit(1)

    repo = "PocketShell-io/pocketshell-gateway"
    gates = ["test", "vet", "format", "vulnerability", "build-arm64", "e2e-docker"]
    harnesses = ["contract", "installer-harness", "api-harness", "workflow-harness",
                 "bootstrap-harness", "provision-harness", "packaging-harness", "imds-probe-harness"]

    # --- ci.yml: the gates and the same-commit deploy job -------------------
    check("ci defines every gate job", all(g in ci.get("jobs", {}) for g in gates),
          str(sorted(ci.get("jobs", {}))))
    for g in gates:
        steps = ci["jobs"].get(g, {}).get("steps", [])
        runs = [str(s.get("run", "")) for s in steps]
        check(f"gate {g} actually runs something", any(r.strip() for r in runs))
        # R5: a gate whose failure is neutralized is not a gate. No `|| true`
        # style failure swallowing inside gate steps, no continue-on-error.
        for r in runs:
            check(f"gate {g} step does not swallow failures", "|| true" not in r and "|| :" not in r and "; true" not in r, r)
        for s in steps:
            check(f"gate {g} step has no continue-on-error", s.get("continue-on-error") in (None, False), str(s.get("continue-on-error")))

    # R5: every regression harness is a real CI step on the test job (not
    # only a `make check` convenience nobody in CI executes).
    test_runs = " ".join(str(s.get("run", "")) for s in ci["jobs"]["test"].get("steps", []))
    for h in harnesses:
        check(f"ci test job runs make {h}", f"make {h}" in test_runs, test_runs)
    wheel_steps = ci["jobs"].get("wheels", {}).get("steps", [])
    producer = [i for i, s in enumerate(wheel_steps) if str(s.get("run", "")).startswith("make wheels ")]
    verifier = [i for i, s in enumerate(wheel_steps) if str(s.get("run", "")).startswith("make verify-wheels ")]
    uploads = [i for i, s in enumerate(wheel_steps) if str(s.get("uses", "")).startswith("actions/upload-artifact@")]
    check("wheels producer and verifier precede upload", len(producer) == len(verifier) == len(uploads) == 1
          and producer[0] < verifier[0] < uploads[0])
    for i in producer + verifier:
        run = wheel_steps[i]["run"]
        check("wheel gate binds exact source and version", 'COMMIT="${{ github.sha }}"' in run and 'WHEEL_VERSION="0.0.0+$(git rev-parse --short=12 HEAD)"' in run)
        check("wheel gate propagates failure", wheel_steps[i].get("continue-on-error") in (None, False)
              and "||" not in run and ";" not in run and not wheel_steps[i].get("if"))
    makefile = (root / "Makefile").read_text() if (root / "Makefile").exists() else ""
    mlines = makefile.splitlines()
    wheel_target = next((l for l in mlines if l.startswith("wheels:")), "")
    check("wheels consumes downloaded matrix without rebuild", bool(wheel_target) and "build-matrix" not in wheel_target.split("##")[0])
    check_line = ""
    for i, l in enumerate(mlines):
        if l.startswith("check:"):
            check_line = l
            j = i + 1
            while j < len(mlines) and mlines[i].endswith("\\"):
                check_line += " " + mlines[j].rstrip("\\")
                if not mlines[j].endswith("\\"):
                    break
                i = j
                j += 1
            break
    for h in harnesses:
        check(f"make check includes {h}", h in check_line, check_line)

    # R5: the production-shaped new-API e2e is a mandatory part of the docker
    # gate and the runner script can never succeed by skipping.
    e2e_runs = " ".join(str(s.get("run", "")) for s in ci["jobs"]["e2e-docker"].get("steps", []))
    check("ci e2e job runs the docker e2e", "make e2e-docker" in e2e_runs, e2e_runs)
    check("ci e2e job runs the production new-API e2e", "make e2e-newapi" in e2e_runs, e2e_runs)
    runner = root / "scripts" / "e2e" / "run-newapi.sh"
    if runner.exists():
        rtext = runner.read_text()
        check("new-api runner never exits 0 on a skip",
              re.search(r"\bexit 0\b", rtext) is None,
              "literal 'exit 0' found (a skip would surface as success)")
        check("new-api runner names its fail-closed contract",
              "no successful skip" in rtext and "fail_missing" in rtext)
        check("new-api runner refuses without the runtime sources",
              "cmd/pocketshell-link" in rtext)
        check("new-api runner requires docker and compose",
              "docker" in rtext and "docker compose version" in rtext)
    else:
        check("new-api runner exists", False, str(runner))

    djob = ci.get("jobs", {}).get("deploy", {})
    needs = djob.get("needs", [])
    needs = [needs] if isinstance(needs, str) else list(needs)
    check("ci deploy needs ALL gates at the same commit", sorted(needs) == sorted(gates), str(needs))
    dif = str(djob.get("if", ""))
    check("ci deploy guards push event", "github.event_name == 'push'" in dif, dif)
    check("ci deploy guards main ref", "github.ref == 'refs/heads/main'" in dif)
    check("ci deploy guards exact repo", f"github.repository == '{repo}'" in dif)
    for bad in ("failure", "cancelled", "skipped"):
        check(f"ci deploy refuses {bad} needs", f"!contains(needs.*.result, '{bad}')" in dif)
    check("ci deploy calls the local reusable workflow",
          str(djob.get("uses", "")) == "./.github/workflows/deploy.yml", str(djob.get("uses")))
    check("ci deploy job carries id-token: write",
          djob.get("permissions", {}).get("id-token") == "write")
    check("ci deploy job does not write anything else",
          set(djob.get("permissions", {})) <= {"contents", "id-token"})
    conc = ci.get("concurrency", {})
    check("ci concurrency group is per-ref", str(conc.get("group", "")) == "ci-${{ github.ref }}", str(conc.get("group")))
    check("ci never cancels a main run (parent must not cancel the deploy child)",
          str(conc.get("cancel-in-progress", "false")) == "${{ github.event_name == 'pull_request' }}",
          str(conc.get("cancel-in-progress")))
    check("ci workflow permissions are read-only", ci.get("permissions") == {"contents": "read"})

    # --- deploy.yml: reusable, unreachable except through the gate ----------
    on = deploy.get(True) or deploy.get("on") or {}
    check("deploy has no independent trigger", list(on.keys()) == ["workflow_call"], str(list(on.keys())))
    dtext = (wf / "deploy.yml").read_text()
    check("deploy.yml never triggers on push events", "  push:" not in dtext)
    djob2 = deploy.get("jobs", {}).get("deploy", {})
    dif2 = str(djob2.get("if", ""))
    for guard in ("github.event_name == 'push'", "github.ref == 'refs/heads/main'", f"github.repository == '{repo}'"):
        check(f"deploy job belt-and-braces guard: {guard}", guard in dif2, dif2)
    check("deploy workflow permissions minimal", deploy.get("permissions") == {"contents": "read"})
    check("deploy job id-token is write and job-scoped only",
          djob2.get("permissions", {}) == {"contents": "read", "id-token": "write"}, str(djob2.get("permissions")))
    dconc = deploy.get("concurrency", {})
    check("deploys serialize and are never cancelled",
          dconc.get("group") == "deploy-main" and dconc.get("cancel-in-progress") is False, str(dconc))
    check("deploy has no approval environment", "environment" not in djob2)
    dsteps = djob2.get("steps", [])
    downs = [s for s in dsteps if "download-artifact" in str(s.get("uses", ""))]
    ups_all = [s for j in ci.get("jobs", {}).values() for s in j.get("steps", []) if "upload-artifact" in str(s.get("uses", ""))]
    # The release set is the upload of build/dist itself (helper matrix and
    # wheels upload distinct subdirectories and are NOT deploy inputs).
    release_ups = [s for s in ups_all if str(s.get("with", {}).get("path", "")).rstrip("/") == "build/dist"]
    ups_names = [s.get("with", {}).get("name") for s in ups_all]
    down_name = downs[0].get("with", {}).get("name") if downs else None
    check("exactly one upload of the release set", len(release_ups) == 1, str(ups_names))
    check("artifact name binding upload==download",
          len(release_ups) == 1 and len(downs) == 1 and
          release_ups[0].get("with", {}).get("name") == down_name,
          f"release_upload={release_ups[0].get('with', {}).get('name') if release_ups else None} download={down_name}")
    check("helper matrix + wheels are the only other uploads (release-set name used once)",
          len(ups_all) == 3 and ups_names.count("gateway-linux-arm64") == 1, str(ups_names))
    check("upload refuses missing files",
          all(s.get("with", {}).get("if-no-files-found") == "error" for s in ups_all), str(ups_names))
    check("exactly one download in deploy", len(downs) == 1, str(len(downs)))
    drun = " ".join(str(s.get("run", "")) for s in dsteps)
    check("deploy pins the source revision", "--revision" in drun)
    check("deploy pins the service user", "--service-user" in drun)
    check("deploy targets the bootstrap role",
          "arn:aws:iam::817685572750:role/pocketshell-github-deploy" in dtext)
    check("deploy version binds the checked-out commit",
          "git rev-parse" in drun)

    # --- pinned actions everywhere (no floating tags) ------------------------
    pin = re.compile(r"uses:\s*([\w.-]+/[\w.-]+)@(\S+)")
    for fname in ("ci.yml", "deploy.yml", "oidc-probe.yml"):
        for m in pin.finditer((wf / fname).read_text()):
            check(f"{fname}: {m.group(1)} pinned to 40-hex SHA",
                  re.fullmatch(r"[0-9a-f]{40}", m.group(2)) is not None, m.group(2))

    # --- oidc probe stays dispatch-only --------------------------------------
    probe_on = probe.get(True) or probe.get("on") or {}
    check("oidc probe is workflow_dispatch only", list(probe_on.keys()) == ["workflow_dispatch"], str(list(probe_on.keys())))
    check("oidc probe writes id-token", probe.get("permissions", {}).get("id-token") == "write")

    if FAILURES:
        print(f"workflow_check: {len(FAILURES)} violation(s)")
        sys.exit(1)
    print("workflow_check OK")


if __name__ == "__main__":
    main()
