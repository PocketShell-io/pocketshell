#!/usr/bin/env bash
# NATIVE proof of the D13 IMDS enforcement verdicts — no stubs, no fake curl.
#
# Boots Amazon Linux 2023 with systemd 252 as PID 1 in a privileged container
# (scripts/tests/imds-native/Dockerfile: same OS + systemd build as the
# gateway instance, and like it WITHOUT iptables/nft), puts a stand-in IMDS
# endpoint on 169.254.169.254:80 and [fd00:ec2::254]:80 (answers the IMDSv2
# token PUT with 200), and then runs the INSTALLER'S OWN probe functions
# (imds_control_probe / imds_filtered_probe, sourced from
# scripts/host/install-deploy.sh) plus the real helper scripts against REAL
# cgroup BPF IPAddressDeny enforcement:
#
#   P1 unfiltered root control (--control) obtains a token        -> rc 20
#   P2 service user + the unit's IPAddressDeny (installer probe)   -> protected
#      (kernel: SYN dropped, curl 28 / 000 / 0 connects -> probe 10, accepted
#      with P1 — exactly the live-host observation of 2026-10-09)
#   P3 service user under the FULL hardened property set of the live
#      effective unit (outage-a1a26-post-recovery-effective-unit)  -> protected
#   N1 equivalent filter on the WRONG hosts (.253) as service user -> rc 1, NOT protected
#   N2 service user, no filter                                     -> rc 1, NOT protected
#   N4 a control unit systemd-run cannot even start (noexec)       -> rc 1, never
#      mistaken for the positive control (why the control code is 20)
#   N3 strategy B on this OS: imds-guard.sh --check                -> 127 (iptables absent),
#      i.e. the installer refuses B in the preflight
#   R1 (evidence) the pre-fix probe from a1a26a2, when the git object is
#      available, under the SAME working filter                   -> 2 "inconclusive"
#
# Usage: scripts/tests/imds-native-proof.sh        (needs docker, privileged)
# Exit 0 = every check passed. Never touches AWS or any real IMDS.
set -euo pipefail

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
IMAGE=${IMDS_PROOF_IMAGE:-pocketshell-imds-native-proof:al2023}
PREFIX_REV=${IMDS_PROOF_PREFIX_REV:-a1a26a2ee27a59fd260823d08f82b9b87b0e1a9c}

if [ "${1:-}" != --inner ]; then
  command -v docker >/dev/null || { echo "imds-native-proof: docker required" >&2; exit 1; }
  docker build -q -t "$IMAGE" "$ROOT/scripts/tests/imds-native" >/dev/null
  mkdir -p "$ROOT/.tmp"
  extra=$(mktemp -d "$ROOT/.tmp/imds-native.XXXXXX")
  if git -C "$ROOT" cat-file -e "$PREFIX_REV:scripts/host/imds-probe.sh" 2>/dev/null; then
    git -C "$ROOT" show "$PREFIX_REV:scripts/host/imds-probe.sh" >"$extra/prefix-imds-probe.sh"
  fi
  name=psh-imds-proof-$$
  trap 'docker rm -f "$name" >/dev/null 2>&1 || true; rm -rf "$extra"' EXIT
  docker run -d --name "$name" --privileged --cgroupns=private --tmpfs /run --tmpfs /tmp \
    -v "$ROOT:/src:ro" -v "$extra:/extra:ro" "$IMAGE" >/dev/null
  for _ in $(seq 1 60); do
    state=$(docker exec "$name" systemctl is-system-running 2>/dev/null || true)
    case "$state" in running|degraded) break;; esac
    sleep 1
  done
  echo "imds-native-proof: $(docker exec "$name" sh -c '. /etc/os-release; echo "$PRETTY_NAME"'), $(docker exec "$name" systemctl --version | head -1), kernel $(uname -r), system state: ${state:-unknown}"
  docker exec "$name" bash /src/scripts/tests/imds-native-proof.sh --inner
  exit $?
fi

# ------------------------------------------------------------------ inner ----
pass=0 fail=0
ok() { pass=$((pass + 1)); echo "PASS $*"; }
ko() { fail=$((fail + 1)); echo "FAIL $*"; }

SERVICE_USER=pocketshell-gateway
id -u "$SERVICE_USER" >/dev/null 2>&1 ||
  useradd --system --no-create-home --shell /sbin/nologin "$SERVICE_USER"
for t in iptables ip6tables nft; do
  command -v "$t" >/dev/null && echo "note: $t present (production has none)"
done

# Stand-in IMDS on both production addresses (local, never the real IMDS).
ip addr add 169.254.169.254/32 dev lo 2>/dev/null || true
ip -6 addr add fd00:ec2::254/128 dev lo nodad 2>/dev/null || true
cat >/run/fake-imds.py <<'PY'
import http.server, socket, threading
class H(http.server.BaseHTTPRequestHandler):
    def do_PUT(self):
        if self.path == "/latest/api/token":
            self.send_response(200); self.end_headers(); self.wfile.write(b"STAND-IN-TOKEN")
        else:
            self.send_response(404); self.end_headers()
    def log_message(self, *a): pass
class S6(http.server.HTTPServer):
    address_family = socket.AF_INET6
s4 = http.server.HTTPServer(("169.254.169.254", 80), H)
threading.Thread(target=s4.serve_forever, daemon=True).start()
try:
    S6(("fd00:ec2::254", 80), H).serve_forever()
except OSError:
    threading.Event().wait()
PY
systemd-run --quiet --unit=fake-imds python3 /run/fake-imds.py
for _ in $(seq 1 50); do
  curl -s -o /dev/null -X PUT http://169.254.169.254/latest/api/token && break
  sleep 0.1
done

# Helpers installed root-owned 0755, as the SSM document does.
HELPERS_DIR=/usr/local/lib/pocketshell-gateway # production path (not the noexec /run tmpfs)
install -d -m 0755 "$HELPERS_DIR"
install -m 0755 /src/scripts/host/imds-probe.sh /src/scripts/host/imds-guard.sh "$HELPERS_DIR/"

# The installer body exactly as embedded (main line stripped), so the probes
# below are the installer's own functions.
sed '$d' /src/scripts/host/install-deploy.sh >/run/installer-body.sh
# shellcheck disable=SC1091
source /run/installer-body.sh
set +e +E +u
trap - EXIT ERR
SYSTEMD_RUN=systemd-run
export HELPERS_DIR SERVICE_USER SYSTEMD_RUN

run_unit() { # extra systemd-run args... -> probe exit code
  systemd-run --collect --quiet --wait --pipe -p Type=oneshot "$@" "$HELPERS_DIR/imds-probe.sh" >/dev/null 2>&1
}

imds_control_probe; c=$?
[ "$c" = 20 ] && ok "P1 unfiltered root control obtains a token (rc 20)" || ko "P1 control rc=$c, want 20"

imds_filtered_probe; f=$?
echo "     installer filtered probe (User=$SERVICE_USER, IPAddressDeny=$IMDS_V4 $IMDS_V6) rc=$f"
[ "$f" = 10 ] || [ "$f" = 0 ] && ok "P2 IPAddressDeny blocks IMDS for the service user (rc $f)" || ko "P2 filtered rc=$f, want 10 or 0"
imds_protected "$f" "$c" && ok "P2 installer verdict: protected -> strategy A (systemd)" || ko "P2 installer verdict NOT protected (rc=$f control=$c)"

# Raw curl as the service user under the same filter: the live-host signature.
raw=$(systemd-run --collect --quiet --wait --pipe -p "User=$SERVICE_USER" \
  -p "IPAddressDeny=169.254.169.254/32" -p "IPAddressDeny=fd00:ec2::254/128" \
  curl -sS --noproxy '*' -o /dev/null --connect-timeout 2 --max-time 3 \
  -w '%{http_code} %{num_connects}' -X PUT http://169.254.169.254/latest/api/token 2>/dev/null); rr=$?
echo "     raw curl as $SERVICE_USER under IPAddressDeny: rc=$rr write-out='$raw'"
[ "$rr" = 28 ] && [ "$raw" = "000 0" ] && ok "P2 kernel signature is a connect-phase drop (curl 28, '000 0'), as on the live host" ||
  ko "P2 raw signature rc=$rr '$raw'"

# Full hardened property set of the live effective unit (post-recovery).
run_unit -p "User=$SERVICE_USER" -p "Group=$SERVICE_USER" \
  -p "IPAddressDeny=169.254.169.254/32 fd00:ec2::254/128" \
  -p AmbientCapabilities=CAP_NET_BIND_SERVICE -p CapabilityBoundingSet=CAP_NET_BIND_SERVICE \
  -p NoNewPrivileges=yes -p ProtectSystem=strict -p ProtectHome=yes -p PrivateTmp=yes \
  -p "RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6"; full=$?
imds_protected "$full" "$c" && ok "P3 live unit's full property set: protected (rc $full)" || ko "P3 full property set rc=$full"

run_unit -p "User=$SERVICE_USER" -p "IPAddressDeny=169.254.169.253/32" -p "IPAddressDeny=fd00:ec2::253/128"; n1=$?
[ "$n1" = 1 ] && ! imds_protected "$n1" "$c" && ok "N1 equivalent filter on the wrong hosts: token obtainable, NOT protected (rc 1)" ||
  ko "N1 wrong-host filter rc=$n1, want 1"

run_unit -p "User=$SERVICE_USER"; n2=$?
[ "$n2" = 1 ] && ! imds_protected "$n2" "$c" && ok "N2 service user without filter: NOT protected (rc 1)" || ko "N2 unfiltered service user rc=$n2, want 1"

install -m 0755 "$HELPERS_DIR/imds-probe.sh" /run/noexec-imds-probe.sh # /run is a noexec tmpfs here
systemd-run --collect --quiet --wait --pipe -p Type=oneshot /run/noexec-imds-probe.sh --control >/dev/null 2>&1; n4=$?
[ "$n4" = 1 ] && ! imds_protected 10 "$n4" && ok "N4 control unit that cannot start: systemd-run rc 1, not a positive control" ||
  ko "N4 unstartable control rc=$n4, want 1 and not accepted"

gout=$("$HELPERS_DIR/imds-guard.sh" --check "$SERVICE_USER" 2>&1); g=$?
if command -v iptables >/dev/null; then
  echo "note: iptables present; N3 not applicable"
else
  [ "$g" = 127 ] && ok "N3 strategy B preflight on AL2023 refuses: $gout" || ko "N3 guard --check rc=$g ($gout), want 127"
fi

if [ -f /extra/prefix-imds-probe.sh ]; then
  install -m 0755 /extra/prefix-imds-probe.sh "$HELPERS_DIR/prefix-imds-probe.sh"
  systemd-run --collect --quiet --wait --pipe -p Type=oneshot -p "User=$SERVICE_USER" \
    -p "IPAddressDeny=$IMDS_V4" -p "IPAddressDeny=$IMDS_V6" "$HELPERS_DIR/prefix-imds-probe.sh" >/dev/null 2>&1; old=$?
  [ "$old" = 2 ] && ok "R1 pre-fix probe (a1a26a2) under the SAME working filter: rc 2 'inconclusive' (the 2026-10-09 RED)" ||
    ko "R1 pre-fix probe rc=$old, expected 2"
else
  echo "note: pre-fix probe object unavailable (shallow clone); R1 skipped"
fi

echo "imds-native-proof: $pass passed, $fail failed"
[ "$fail" = 0 ]
