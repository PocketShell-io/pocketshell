#!/usr/bin/env bash
# Real configured-toolchain regression; no production installer/infra mutations.
# Usage: scripts/tests/installer-go-toolchain-test.sh /absolute/trusted/bin/go
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
TRUSTED_GO=${1:?supply an absolute trusted Go executable}
case "$TRUSTED_GO" in /*) ;; *) exit 1 ;; esac
[ -f "$TRUSTED_GO" ] && [ -x "$TRUSTED_GO" ]
TRUSTED_ROOT=$(GOTOOLCHAIN=local "$TRUSTED_GO" env GOROOT)
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT
# Exercise the actual function body; importing the full harness would deploy
# sandbox fixtures. Keep the extraction delimited and require exactly one body.
sed -n '/^# BEGIN configured Go resolver/,/^# END configured Go resolver/p' \
  "$ROOT/scripts/tests/installer-harness.sh" > "$WORK/resolver.sh"
[ "$(grep -c '^resolve_configured_go()' "$WORK/resolver.sh")" = 1 ]
mkdir -p "$WORK/relocated toolchain/bin" "$WORK/poison" "$WORK/fixture"
for entry in "$TRUSTED_ROOT"/*; do
  [ "${entry##*/}" = bin ] || ln -s "$entry" "$WORK/relocated toolchain/${entry##*/}"
done
cp "$TRUSTED_GO" "$WORK/relocated toolchain/bin/go"
cat > "$WORK/poison/go" <<'POISON'
#!/bin/sh
printf 'poison executed\n' > "$POISON_MARKER"
exit 97
POISON
chmod +x "$WORK/poison/go"
export POISON_MARKER="$WORK/path-tool-used"
export PATH="$WORK/poison:/usr/bin:/bin"
# Prove the poison is executable before relying on its absence later.
if go; then echo 'poison negative control unexpectedly succeeded' >&2; exit 1; fi
[ -f "$POISON_MARKER" ]; rm "$POISON_MARKER"
# shellcheck disable=SC1090
source "$WORK/resolver.sh"
export GOROOT="$WORK/relocated toolchain"
unset GO
SELECTED=$(resolve_configured_go)
[ "$SELECTED" = "$GOROOT/bin/go" ]
# The old actual selector disregards relocated GOROOT. This RED control checks
# path selection even on developer machines where the old path still exists.
OLD_SELECTED=$(unset GO; GO=${GO:-/usr/local/go/bin/go}; printf '%s' "$GO")
[ "$OLD_SELECTED" != "$SELECTED" ]
echo 'PASS: baseline selector RED for relocated configured GOROOT'
export GO="$SELECTED" GOROOT="$WORK/missing-root"
[ "$(resolve_configured_go)" = "$SELECTED" ]
for bad in go relative/bin/go "$WORK/missing-go" "$WORK/fixture"; do
  if (export GO="$bad"; resolve_configured_go); then
    echo 'invalid explicit GO unexpectedly accepted' >&2; exit 1
  fi
done
for bad in relative-root "$WORK/missing-root"; do
  if (unset GO; export GOROOT="$bad"; resolve_configured_go); then
    echo 'invalid GOROOT unexpectedly accepted' >&2; exit 1
  fi
done
if (unset GO GOROOT; resolve_configured_go); then
  echo 'unconfigured ambient PATH unexpectedly accepted' >&2; exit 1
fi
export GOROOT="$WORK/relocated toolchain" GOTOOLCHAIN=local GOPROXY=off CGO_ENABLED=0
cat > "$WORK/fixture/go.mod" <<'MOD'
module installer_toolchain_fixture

go 1.27
MOD
cat > "$WORK/fixture/main.go" <<'SRC'
package main
import "fmt"
func main() { fmt.Print("configured relocated Go ran") }
SRC
(cd "$WORK/fixture" && "$SELECTED" build -trimpath -o "$WORK/fixture/native" .)
[ "$("$WORK/fixture/native")" = 'configured relocated Go ran' ]
for arch in amd64 arm64; do
  (cd "$WORK/fixture" && GOOS=linux GOARCH=$arch "$SELECTED" build -trimpath -o "$WORK/fixture/$arch" .)
done
readelf -h "$WORK/fixture/amd64" | grep -q 'Advanced Micro Devices X86-64'
readelf -h "$WORK/fixture/arm64" | grep -q 'AArch64'
[ ! -e "$POISON_MARKER" ]
echo 'PASS: actual relocated Go builds/runs and cross-builds ELF fixtures; poisoned PATH unused'
