#!/usr/bin/env bash
# Controls for scripts/e2e/pull-pinned.sh against a scripted docker stub (no
# daemon, no network): throttle->success, permanent error fails at once,
# retry exhaustion fails, only exact pins accepted, bound cache reused with
# no registry request, unbound pull refused, nothing tagged/removed/pushed.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
HELPER=$ROOT/scripts/e2e/pull-pinned.sh
WORK=$(mktemp -d)
trap 'rm -rf "$WORK"' EXIT

REF=public.ecr.aws/docker/library/alpine@sha256:d9e853e87e55526f6b2917df91a2115c36dd7c696a35be12163d44e6e2a4b6bc
OTHER=public.ecr.aws/docker/library/alpine@sha256:5291449c3df73caf6ed85e649dec1b9e818b39a5d8c871e97afc13e9cd5e8fa8

# Stub: logs argv; `pull`/`compose build` pop scripted outcomes
# (ok|throttle|perm, and for builds the meta*/run*/... shapes below, which
# mirror real BuildKit/containerd error text); `image inspect` prints RepoDigests from
# $ST/bound (one per line) or fails when absent.
cat >"$WORK/docker" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "$*" >>"$ST/calls"
pop() { local f=$ST/$1 l; l=$(head -n1 "$f"); sed -i 1d "$f"; printf '%s' "$l"; }
case "$1 ${2:-}" in
"image inspect")
  [ -f "$ST/bound" ] || { echo "Error: No such image: ${*: -1}" >&2; exit 1; }
  cat "$ST/bound" ;;
"pull --quiet")
  case $(pop pulls) in
  ok) printf '%s\n' "${BIND_AS:-$3}" >>"$ST/bound"; echo "$3" ;;
  throttle) echo "Error response from daemon: toomanyrequests: Rate exceeded" >&2; exit 1 ;;
  perm) echo "Error response from daemon: manifest unknown" >&2; exit 1 ;;
  *) echo "stub: unscripted pull" >&2; exit 99 ;;
  esac ;;
"compose -f")
  case $(pop builds) in
  ok) echo "built" ;;
  # Genuine: FROM metadata resolution of the exact pin, throttled by ECR.
  meta429) printf '#2 [internal] load metadata for %s\n#2 ERROR: failed to resolve source metadata for %s: unexpected status from HEAD request to https://public.ecr.aws/v2/docker/library/alpine/manifests/%s: 429 Too Many Requests\nfailed to solve: %s: failed to resolve source metadata for %s: unexpected status from HEAD request to https://public.ecr.aws/v2/docker/library/alpine/manifests/%s: 429 Too Many Requests\n' "$PIN" "$PIN" "${PIN#*@}" "$PIN" "$PIN" "${PIN#*@}" >&2; exit 1 ;;
  meta429token) printf 'target sshd: failed to solve: %s: failed to resolve source metadata for %s: failed to authorize: failed to fetch anonymous token: unexpected status from GET request to https://public.ecr.aws/token/?scope=repository%%3Adocker%%2Flibrary%%2Falpine%%3Apull&service=public.ecr.aws: 429 Too Many Requests: {"errors":[{"code":"TOOMANYREQUESTS","message":"Rate exceeded"}]}\n' "$PIN" "$PIN" >&2; exit 1 ;;
  # Not retried: a RUN step (package mirror / any server) answering 429.
  run429) printf '#6 [sshd 2/4] RUN apk add --no-cache openssh-server\n#6 0.912 ERROR: https://dl-cdn.alpinelinux.org/alpine/v3.20/main: 429 Too Many Requests\n#6 0.913 toomanyrequests: Rate exceeded\n#6 ERROR: process "/bin/sh -c apk add --no-cache openssh-server" did not complete successfully: exit code: 1\nfailed to solve: process "/bin/sh -c apk add --no-cache openssh-server" did not complete successfully: exit code: 1\n' >&2; exit 1 ;;
  # Not retried: RUN output that merely ECHOES the genuine metadata line.
  runecho) printf '#6 0.500 failed to resolve source metadata for %s: unexpected status from HEAD request to https://public.ecr.aws/v2/docker/library/alpine/manifests/%s: 429 Too Many Requests\nfailed to solve: process "/bin/sh -c x" did not complete successfully: exit code: 1\n' "$PIN" "${PIN#*@}" >&2; exit 1 ;;
  # Not retried: throttle wording with no exact pin metadata context.
  generic429) printf 'failed to solve: toomanyrequests: Rate exceeded\nERROR: 429 Too Many Requests\n' >&2; exit 1 ;;
  blob429) printf 'failed to solve: failed to copy: httpReadSeeker: failed open: unexpected status code https://public.ecr.aws/v2/docker/library/alpine/blobs/sha256:%064d: 429 Too Many Requests\n' 0 >&2; exit 1 ;;
  otherpin429) printf 'failed to solve: %s: failed to resolve source metadata for %s: unexpected status from HEAD request to https://public.ecr.aws/v2/docker/library/alpine/manifests/%s: 429 Too Many Requests\n' "$OTHER" "$OTHER" "${OTHER#*@}" >&2; exit 1 ;;
  otherhost429) printf 'failed to solve: %s: failed to resolve source metadata for %s: unexpected status from HEAD request to https://registry-1.docker.io/v2/library/alpine/manifests/%s: 429 Too Many Requests\n' "$PIN" "$PIN" "${PIN#*@}" >&2; exit 1 ;;
  # One anchor wrong at a time: pin, registry host, manifest path.
  pinmismatch429) printf 'failed to solve: %s: failed to resolve source metadata for %s: unexpected status from HEAD request to https://public.ecr.aws/v2/docker/library/alpine/manifests/%s: 429 Too Many Requests\n' "$OTHER" "$OTHER" "${PIN#*@}" >&2; exit 1 ;;
  hostmismatch429) printf 'failed to solve: %s: failed to resolve source metadata for %s: unexpected status from HEAD request to https://mirror.example/v2/docker/library/alpine/manifests/%s: 429 Too Many Requests\n' "$PIN" "$PIN" "${PIN#*@}" >&2; exit 1 ;;
  pathmismatch429) printf 'failed to solve: %s: failed to resolve source metadata for %s: unexpected status from HEAD request to https://public.ecr.aws/v2/docker/library/alpine/manifests/%s: 429 Too Many Requests\n' "$PIN" "$PIN" "${OTHER#*@}" >&2; exit 1 ;;
  meta503) printf 'failed to solve: %s: failed to resolve source metadata for %s: unexpected status from HEAD request to https://public.ecr.aws/v2/docker/library/alpine/manifests/%s: 503 Service Unavailable\n' "$PIN" "$PIN" "${PIN#*@}" >&2; exit 1 ;;
  perm) echo "ERROR: failed to solve: process \"/bin/sh -c apk add\" did not complete successfully" >&2; exit 1 ;;
  *) echo "stub: unscripted build" >&2; exit 99 ;;
  esac ;;
*) echo "stub: unexpected docker call: $*" >&2; exit 98 ;;
esac
STUB
chmod +x "$WORK/docker"
printf 'services: {}\n' >"$WORK/compose.yml"

PASS=0 FAIL=0 i=0
# run NAME WANT_RC PULLS BUILDS [BOUND_LINES] -- ARGS...
run() {
  local name=$1 want=$2 pulls=$3 builds=$4 bound=$5
  shift 6
  export ST=$WORK/$name
  mkdir -p "$ST"
  : >"$ST/calls"
  tr ' ' '\n' <<<"$pulls" | sed '/^$/d' >"$ST/pulls"
  tr ' ' '\n' <<<"$builds" | sed '/^$/d' >"$ST/builds"
  [ -z "$bound" ] || tr ' ' '\n' <<<"$bound" >"$ST/bound"
  local rc=0
  PIN=$REF OTHER=$OTHER DOCKER=$WORK/docker PULL_PINNED_BACKOFF=${BO:-0} PULL_PINNED_ATTEMPTS=${ATT:-5} \
    "$HELPER" "$@" >"$ST/out" 2>&1 || rc=$?
  if [ "$rc" -eq "$want" ]; then :; else
    echo "FAIL $name: rc=$rc want=$want"; sed 's/^/    /' "$ST/out"; FAIL=$((FAIL + 1)); return 0
  fi
  PASS=$((PASS + 1))
}
expect() { # NAME DESCRIPTION CONDITION...
  local name=$1 desc=$2
  shift 2
  if "$@"; then PASS=$((PASS + 1)); else echo "FAIL $name: $desc"; FAIL=$((FAIL + 1)); fi
}
count() { grep -c -- "$2" "$WORK/$1/calls" || true; }

run throttle-then-ok 0 "throttle throttle ok" "" "" -- pull "$REF"
expect throttle-then-ok "3 pulls" test "$(count throttle-then-ok '^pull ')" -eq 3
expect throttle-then-ok "reports bound on attempt 3" grep -q "pulled $REF (attempt 3, bound)" "$WORK/throttle-then-ok/out"

run permanent 1 "perm ok" "" "" -- pull "$REF"
expect permanent "exactly 1 pull (no retry)" test "$(count permanent '^pull ')" -eq 1
expect permanent "says not a throttle" grep -q "not a registry throttle; no retry" "$WORK/permanent/out"

ATT=3 run exhausted 1 "throttle throttle throttle ok" "" "" -- pull "$REF"
expect exhausted "exactly 3 pulls (bounded)" test "$(count exhausted '^pull ')" -eq 3
expect exhausted "says still throttled" grep -q "still throttled after 3 attempts" "$WORK/exhausted/out"

for bad in alpine:3.20 docker.io/library/alpine@sha256:d9e853e87e55526f6b2917df91a2115c36dd7c696a35be12163d44e6e2a4b6bc \
  public.ecr.aws/docker/library/alpine:3.20 \
  public.ecr.aws/amazonlinux/amazonlinux@sha256:12052e9b5d3fd85769abbdd863dd038e1890c9ace31d5fdbe1afa78eda97d061 \
  "public.ecr.aws/docker/library/alpine:3.20@sha256:d9e853e87e55526f6b2917df91a2115c36dd7c696a35be12163d44e6e2a4b6bc" \
  public.ecr.aws/docker/library/alpine@sha256:D9E853E87E55526F6B2917DF91A2115C36DD7C696A35BE12163D44E6E2A4B6BC; do
  n=refuse-$((++i))
  run "$n" 1 "ok" "" "" -- pull "$REF" "$bad"
  expect "$n" "no docker call at all for a bad ref ($bad)" test ! -s "$WORK/$n/calls"
done

run cached-bound 0 "" "" "$REF" -- pull "$REF" "$REF"
expect cached-bound "no pull when bound" test "$(count cached-bound '^pull ')" -eq 0
expect cached-bound "reports cached" grep -q "cached $REF (bound, no registry request)" "$WORK/cached-bound/out"

run cached-unbound 0 "ok" "" "$OTHER" -- pull "$REF"
expect cached-unbound "pulls when the local image is not bound to the ref" test "$(count cached-unbound '^pull ')" -eq 1

BIND_AS=$OTHER run pulled-unbound 1 "ok" "" "" -- pull "$REF"
expect pulled-unbound "refuses an image not bound to the exact ref" grep -q "not bound to that exact ref" "$WORK/pulled-unbound/out"

run dedup 0 "ok" "" "" -- pull "$REF" "$REF" "$REF"
expect dedup "one pull per digest" test "$(count dedup '^pull ')" -eq 1

B=(build "$WORK/compose.yml" proj "$REF")
run build-meta-ok 0 "" "meta429 ok" "" -- "${B[@]}"
expect build-meta-ok "pin metadata 429 retried: 2 builds" test "$(count build-meta-ok '^compose ')" -eq 2
run build-token-ok 0 "" "meta429token meta429 ok" "" -- "${B[@]}"
expect build-token-ok "pin metadata token 429 retried: 3 builds" test "$(count build-token-ok '^compose ')" -eq 3
ATT=2 run build-meta-exhausted 1 "" "meta429 meta429 ok" "" -- "${B[@]}"
expect build-meta-exhausted "2 builds (bounded)" test "$(count build-meta-exhausted '^compose ')" -eq 2
expect build-meta-exhausted "says still throttled" grep -q "still throttled after 2 attempts" "$WORK/build-meta-exhausted/out"
for shape in perm run429 runecho generic429 blob429 otherpin429 otherhost429 meta503 \
  pinmismatch429 hostmismatch429 pathmismatch429; do
  run "build-$shape" 1 "" "$shape ok" "" -- "${B[@]}"
  expect "build-$shape" "exactly 1 build, no retry" test "$(count "build-$shape" '^compose ')" -eq 1
  expect "build-$shape" "says not a throttle" grep -q "not a registry throttle; no retry" "$WORK/build-$shape/out"
done
run build-argv 0 "" "ok" "" -- "${B[@]}"
expect build-argv "exact compose build argv (no --pull)" test "$(cat "$WORK/build-argv/calls")" = "compose -f $WORK/compose.yml -p proj build"
run build-bad-pin 1 "" "ok" "" -- build "$WORK/compose.yml" proj alpine:3.20
expect build-bad-pin "refuses a non-pinned build FROM with no docker call" test ! -s "$WORK/build-bad-pin/calls"
run build-no-pin 1 "" "ok" "" -- build "$WORK/compose.yml" proj
expect build-no-pin "requires the pin argument" grep -q "usage: build COMPOSE_FILE PROJECT PIN" "$WORK/build-no-pin/out"

ATT=9 run bad-attempts 1 "" "" "" -- pull "$REF"
expect bad-attempts "rejects attempts > 8" grep -q "PULL_PINNED_ATTEMPTS must be 1..8" "$WORK/bad-attempts/out"
BO=11 run bad-backoff 1 "" "" "" -- pull "$REF"
expect bad-backoff "rejects backoff > 10" grep -q "PULL_PINNED_BACKOFF must be 0..10" "$WORK/bad-backoff/out"
run no-args 1 "" "" "" -- pull
expect no-args "rejects an empty ref list" grep -q "no image refs given" "$WORK/no-args/out"
run bad-cmd 1 "" "" "" -- push "$REF"
expect bad-cmd "rejects unknown subcommands with no docker call" test ! -s "$WORK/bad-cmd/calls"

# No overwrite: across every case the stub saw only pull/inspect/compose build.
expect no-overwrite "no tag/rmi/rm/push/login/load/import call anywhere" \
  bash -c "! cat '$WORK'/*/calls | grep -qE '^(tag|rmi|image (rm|tag|prune)|push|login|load|import|compose .* (up|down|push|pull))'"

echo "pull-pinned-test: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
