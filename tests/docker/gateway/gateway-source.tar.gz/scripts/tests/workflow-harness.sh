#!/usr/bin/env bash
# D14 workflow regression harness: the checker must PASS the real workflows
# and FAIL every known-bad mutation of them. A check that a mutation survives
# is a vacuous check — each mutation below encodes one requirement:
#   m1  dropping a gate from `needs`            -> same-commit gate broken
#   m2  dropping the skipped-needs guard        -> silent-skip deploys
#   m3  dropping the push-event guard           -> non-push deploys
#   m4  renaming the uploaded artifact          -> upload/download binding broken
#   m5  adding a push trigger to deploy.yml     -> independent (ungated) deploys
#   m6  floating an action tag                  -> unpinned supply chain
#   m7  moving id-token to workflow level       -> blast radius beyond the job
#   m8  cancel-in-progress on main              -> parent cancels the deploy child
#   m9  dropping --revision from the deploy run -> D8 healthz-commit check neutered
#   m10 un-guarded ci concurrency               -> per-ref group removed
# R5 (mandatory production gate, no successful skip):
#   m11 dropping the make e2e-newapi step       -> production gate unwired
#   m12 `|| true` on a gate step                -> failure swallowed
#   m13 continue-on-error on a gate step        -> failure tolerated
#   m14 dropping a harness step from ci         -> regression unwired from CI
#   m15 exit-0 skip branch in the runner        -> successful skip bypass
#   m16 runtime dependency check removed        -> missing-runtime run accepted
#   m17 docker/compose requirement removed      -> missing-tool run accepted
set -uo pipefail

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
WORK=$(mktemp -d "${TMPDIR:-/tmp}/gateway-workflow-harness.XXXXXX")
PASS=0
FAIL=0
CHECK="python3 $ROOT/scripts/tests/workflow_check.py"

note() { printf '[wf-harness] %s\n' "$*"; }
ok() { PASS=$((PASS + 1)); printf '[wf-harness] PASS: %s\n' "$1"; }
ko() { FAIL=$((FAIL + 1)); printf '[wf-harness] FAIL: %s\n' "$1"; }
finish() {
  rm -rf "$WORK"
  note "-----"
  note "passed=$PASS failed=$FAIL"
  [ "$FAIL" = 0 ] || exit 1
  exit 0
}

# mutate <name> <expected-violation> <workflow-file> <sed args...> — copy the
# workflows (+ the other checker inputs: Makefile, new-API runner), apply the
# mutation to ONE file, require the checker to REJECT the copy and name the
# broken invariant.
mutate() {
  local name=$1 expect=$2 target=$3; shift 3
  local dir="$WORK/$name"
  mkdir -p "$dir/.github/workflows" "$dir/scripts/e2e"
  cp "$ROOT"/.github/workflows/*.yml "$dir/.github/workflows/"
  cp "$ROOT/Makefile" "$dir/Makefile"
  cp "$ROOT/scripts/e2e/run-newapi.sh" "$dir/scripts/e2e/run-newapi.sh"
  sed -i "$@" "$dir/.github/workflows/$target"
  local out rc
  out=$($CHECK "$dir" 2>&1); rc=$?
  if [ "$rc" -eq 0 ]; then
    ko "$name: mutation NOT detected (checker exited 0)"
    return
  fi
  if ! printf '%s' "$out" | grep -qF -- "$expect"; then
    ko "$name: detected, but wrong violation (wanted '$expect'): $(printf '%s' "$out" | head -1)"
    return
  fi
  ok "$name: mutation detected ('$expect')"
}

# mutate_runner <name> <expected-violation> <sed args...> — same, but the
# mutation targets the new-API runner script (R5: gate-skip bypasses in the
# runner itself must be detected, not just workflow-level ones).
mutate_runner() {
  local name=$1 expect=$2; shift 2
  local dir="$WORK/$name"
  mkdir -p "$dir/.github/workflows" "$dir/scripts/e2e"
  cp "$ROOT"/.github/workflows/*.yml "$dir/.github/workflows/"
  cp "$ROOT/Makefile" "$dir/Makefile"
  cp "$ROOT/scripts/e2e/run-newapi.sh" "$dir/scripts/e2e/run-newapi.sh"
  sed -i "$@" "$dir/scripts/e2e/run-newapi.sh"
  local out rc
  out=$($CHECK "$dir" 2>&1); rc=$?
  if [ "$rc" -eq 0 ]; then
    ko "$name: mutation NOT detected (checker exited 0)"
    return
  fi
  if ! printf '%s' "$out" | grep -qF -- "$expect"; then
    ko "$name: detected, but wrong violation (wanted '$expect'): $(printf '%s' "$out" | head -1)"
    return
  fi
  ok "$name: mutation detected ('$expect')"
}

note "positive: real workflows must pass the checker"
if out=$($CHECK "$ROOT" 2>&1); then
  ok "real workflows pass ($(printf '%s' "$out" | tail -1))"
else
  ko "real workflows FAIL the checker — fix before anything else:"
  printf '%s\n' "$out"
  finish
fi

mutate m1_needs_gate_dropped "ci deploy needs ALL gates" ci.yml \
  -e 's/needs: \[test, vet, format, vulnerability, build-arm64, e2e-docker\]/needs: [test, vet, format, build-arm64, e2e-docker]/'
mutate m2_skip_guard_dropped "ci deploy refuses skipped needs" ci.yml \
  -e "/!contains(needs\.\*.result, 'skipped')/d"
mutate m3_push_guard_dropped "ci deploy guards push event" ci.yml \
  -e "s/github.event_name == 'push' \&\&//"
mutate m4_artifact_name_mismatch "artifact name binding upload==download" ci.yml \
  -e 's/name: gateway-linux-arm64$/name: gateway-linux-arm64-other/'
mutate m5_independent_push_trigger "deploy has no independent trigger" deploy.yml \
  -e 's/^on:$/on:\n  push:\n    branches: [main]/'
mutate m6_floating_action_tag "pinned to 40-hex SHA" ci.yml \
  -e 's/uses: actions\/checkout@[0-9a-f]\{40\}.*/uses: actions\/checkout@v7/'
mutate m7_workflow_level_idtoken "deploy workflow permissions minimal" deploy.yml \
  -e 's/^permissions:/permissions:\n  id-token: write/'
mutate m8_cancel_main_runs "ci never cancels a main run" ci.yml \
  -e "s/cancel-in-progress: \${{ github.event_name == 'pull_request' }}/cancel-in-progress: true/"
mutate m9_revision_binding_dropped "deploy pins the source revision" deploy.yml \
  -e '/--revision/d'
mutate m10_concurrency_group_removed "ci concurrency group is per-ref" ci.yml \
  -e '/^  group: ci-/d'

# --- R5: missing-gate / skip-bypass mutations must also be detected ----------
mutate m11_newapi_gate_step_removed "ci e2e job runs the production new-API e2e" ci.yml \
  -e '/- run: make e2e-newapi$/d'
mutate m12_gate_failure_swallowed "step does not swallow failures" ci.yml \
  -e 's/- run: make e2e-newapi$/- run: make e2e-newapi || true/'
mutate m13_continue_on_error_added "no continue-on-error" ci.yml \
  -e 's/- run: make e2e-newapi$/- continue-on-error: true\n        run: make e2e-newapi/'
mutate m14_harness_unwired_from_ci "ci test job runs make bootstrap-harness" ci.yml \
  -e '/- run: make bootstrap-harness$/d'
mutate m18_imds_unwired "ci test job runs make imds-probe-harness" ci.yml \
  -e '/- run: make imds-probe-harness$/d'
mutate m19_wheel_verifier_unwired "wheels producer and verifier precede upload" ci.yml \
  -e '/- run: make verify-wheels /d'
mutate_runner m15_runner_skip_path_added "never exits 0 on a skip" \
  -e 's|^set -euo pipefail$|set -euo pipefail\nexit 0 # silent skip bypass (must be detected)|'
mutate_runner m16_runtime_dependency_check_removed "refuses without the runtime sources" \
  -e '/cmd\/pocketshell-link/d'
mutate_runner m17_docker_requirement_removed "requires docker and compose" \
  -e '/docker compose version/d'

finish
