#!/usr/bin/env bash
# Behavioral harness for scripts/bootstrap-aws.sh.
#
# Invariant family 1 (review R3, unchanged): ONLY the coordinator-verified
# immutable OIDC subject is accepted — blank, wildcard, classic name-only and
# any other subject are refused BEFORE ANY AWS CALL, and the template itself
# must pin the exact subject + sts.amazonaws.com audience or the bootstrap
# refuses. "No AWS call" is proven by an EMPTY aws/jq invocation log.
#
# Invariant family 2 (ExistingOidcProviderArn deployment fix): when the
# bootstrap selects CreateOidcProvider=false it MUST pass the EXACT OIDC
# provider ARN of THIS account as ExistingOidcProviderArn — the template's
# false branch uses that parameter as the deploy role's Federated principal
# and its default is empty (the pre-fix script left it empty: a role no
# GitHub token could ever assume). Provider discovery must therefore:
#   * match the provider by its exact canonical ARN, never by substring;
#   * validate Url = token.actions.githubusercontent.com and a ClientIDList
#     that contains the exact sts.amazonaws.com audience;
#   * create ONLY on a genuinely absent provider (a SUCCEEDED listing with
#     no match) — a failed or malformed lookup is a fatal refusal, never a
#     silent create;
#   * refuse foreign-account, wrong-provider, wrong-audience and ambiguous
#     discoveries before any deployment call;
#   * refuse a successful-but-malformed listing: empty output, a missing or
#     non-array OpenIDConnectProviderList key, entries that are not objects,
#     missing/null/numeric Arn fields, and multiple concatenated JSON
#     documents. Only a valid, genuinely empty array proves absence.
#
# Invariant family 3 (simulator verification, B-R2): after the STUBBED
# CloudFormation deploy succeeds the harness serves the full
# iam simulate-principal-policy block and proves the bootstrap
#   * invokes it with the official CLI flags (--action-names /
#     --resource-arns / --context-entries; never the dead "--actions");
#   * supplies the conditioned request context (ssm:DocumentType,
#     aws:ResourceAccount, aws:RequestedRegion) on the SendCommand and
#     result-read cases;
#   * simulates ssm:GetCommandInvocation WITHOUT a document resource
#     (its API resource type is '*'), and
#   * checks the COMPLETE per-(action, resource) result census of the
#     official response shape (one EvaluationResult per action, per-resource
#     decisions only in ResourceSpecificResults.EvalResourceDecision) —
#     missing, duplicated, conflicting, unexpected, unknown or null results
#     and non-empty MissingContextValues must fail, while good mixed
#     decisions (allowed document + denied alternate instance and vice
#     versa; explicit and implicit denies) must pass.
#
# The harness never touches AWS: `aws` is a PATH stub that records every
# invocation to $AWS_CALL_LOG and serves per-case fixtures (a matched
# subcommand with no fixture answers successfully and empty; only explicitly
# failing fixtures fail), and `jq` is a recording stub forwarding to the REAL
# jq so the script's parsing is exercised for real. cloudformation deploy is
# recorded-then-refused in the discovery worlds: "reaches deployment" means
# the recorded deploy line carries the exact parameters; refusal cases must
# show no deploy line. The simulator worlds override the stub so the deploy
# SUCCEEDS (still recorded, no real stack) and the response comes from a
# signature-keyed responder emitting the official API shape.
#
# Template-drift negatives run against mutated copies in a sandbox root (the
# script derives REPO_ROOT from its own location). BOOTSTRAP_SCRIPT overrides
# which bootstrap copy is exercised (used to demonstrate RED on the pre-fix
# script).
set -uo pipefail

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
BOOTSTRAP=${BOOTSTRAP_SCRIPT:-$ROOT/scripts/bootstrap-aws.sh}
WORK=$(mktemp -d "${TMPDIR:-/tmp}/gateway-bootstrap-harness.XXXXXX")
PASS=0
FAIL=0

note() { printf '[bs-harness] %s\n' "$*"; }
ok() { PASS=$((PASS + 1)); printf '[bs-harness] PASS: %s\n' "$1"; }
ko() { FAIL=$((FAIL + 1)); printf '[bs-harness] FAIL: %s\n' "$1"; }
finish() {
  rm -rf "$WORK"
  note "-----"
  note "passed=$PASS failed=$FAIL"
  [ "$FAIL" = 0 ] || exit 1
  exit 0
}

[ -f "$BOOTSTRAP" ] || { printf '[bs-harness] missing bootstrap script: %s\n' "$BOOTSTRAP" >&2; exit 1; }
REAL_JQ=$(command -v jq 2>/dev/null || true)
[ -n "$REAL_JQ" ] || { printf '[bs-harness] the discovery controls need the real jq\n' >&2; exit 1; }

IMMUTABLE='repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main'
ACCOUNT=817685572750
GH_HOST=token.actions.githubusercontent.com
CANONICAL_ARN="arn:aws:iam::${ACCOUNT}:oidc-provider/${GH_HOST}"
REGION=eu-west-1
BUCKET=pocketshell-relay-relaybucket-azljzs6pn8i8
INSTANCE_ID=i-0f9c18ce63cf6c26e
INSTANCE_ROLE=pocketshell-relay-RelayRole-LvjBzsqkrVMa
DEPLOY_ROLE=pocketshell-github-deploy
DEPLOY_DOC=pocketshell-gateway-deploy
DOC_ARN="arn:aws:ssm:${REGION}:${ACCOUNT}:document/${DEPLOY_DOC}"
INST_ARN="arn:aws:ec2:${REGION}:${ACCOUNT}:instance/${INSTANCE_ID}"

# --- sandbox: recording aws/jq stubs ------------------------------------------
make_sandbox() { # $1 = sandbox dir
  local sb=$1
  mkdir -p "$sb/bin" "$sb/fixtures"
  cat >"$sb/bin/aws" <<'STUB'
#!/usr/bin/env bash
# Record-and-serve aws stub: every invocation is logged; answers come from
# fixture files "<AWS_STUB_DIR>/<subcommand>.{out,err,rc}" chosen by the
# subcommand name. A matched call with no fixture exits 0 with no output;
# unrecognized calls fail loudly (exit 254).
printf 'aws %s\n' "$*" >>"${AWS_CALL_LOG:?}"
d=${AWS_STUB_DIR:?}
case " $* " in
  *" sts get-caller-identity "*) n=identity;;
  *" iam list-open-id-connect-providers "*) n=oidc-list;;
  *" iam get-open-id-connect-provider "*) n=oidc-get;;
  *" cloudformation deploy "*) n=cfn-deploy;;
  *" cloudformation create-change-set "*) n=cfn-create;;
  *" s3api head-bucket "*) n=s3-head;;
  *" s3api get-bucket-location "*) n=s3-location;;
  *" s3api put-object "*)
    n=s3-put
    body=''; previous=''
    for argument in "$@"; do
      [ "$previous" != --body ] || body=$argument
      previous=$argument
    done
    if [ ! -f "$d/$n.rc" ] || [ "$(cat "$d/$n.rc")" = 0 ]; then
      cp "$body" "$d/stored-template.yaml"
    fi;;
  *" s3api get-object "*)
    if [ -f "$d/s3-get.rc" ] && [ "$(cat "$d/s3-get.rc")" != 0 ]; then exit "$(cat "$d/s3-get.rc")"; fi
    dest=${!#}
    cp "$d/stored-template.yaml" "$dest" || exit 1
    [ ! -f "$d/corrupt-download" ] || printf 'CORRUPTED\n' >>"$dest"
    if [ -f "$d/s3-get.out" ]; then cat "$d/s3-get.out"; exit 0; fi
    sha=$(sha256sum "$d/stored-template.yaml" | awk '{print $1}')
    sum=$(printf '%s' "$sha" | xxd -r -p | base64 | tr -d '\n')
    size=$(wc -c <"$d/stored-template.yaml")
    printf '{"Metadata":{"sha256":"%s"},"ChecksumSHA256":"%s","ContentLength":%s}\n' "$sha" "$sum" "$size"
    exit 0;;
  *" cloudformation wait "*) n=cfn-wait;;
  *" cloudformation describe-stacks "*) n=cfn-describe;;
  *" iam simulate-principal-policy "*)
    # Simulator worlds: a signature-keyed responder answers INSTEAD of the
    # static fixture, so every call gets its own official-shape response.
    if [ -x "$d/simulate.responder" ]; then
      exec "$d/simulate.responder" "$@"
    fi
    n=simulate;;
  *) n=unknown;;
esac
if [ "$n" = unknown ]; then
  echo "stub-aws: unexpected aws invocation: $*" >&2
  exit 254
fi
[ -f "$d/$n.out" ] && cat "$d/$n.out"
[ -f "$d/$n.err" ] && cat "$d/$n.err" >&2
rc=0
[ -f "$d/$n.rc" ] && rc=$(cat "$d/$n.rc")
exit "$rc"
STUB
  cat >"$sb/bin/jq" <<STUB
#!/usr/bin/env bash
# Recording jq: forwards to the REAL jq so the bootstrap's parsing is
# exercised for real; the shared log still proves refusals precede any call.
printf 'jq %s\n' "$*" >>"\${AWS_CALL_LOG:?}"
exec "$REAL_JQ" "\$@"
STUB
  chmod +x "$sb/bin/aws" "$sb/bin/jq"
}

run_bootstrap() { # $1 = sandbox dir, $2 = outfile, rest = bootstrap args
  local sb=$1 out=$2
  shift 2
  : >"$sb/aws-calls.log"
  AWS_CALL_LOG="$sb/aws-calls.log" AWS_STUB_DIR="$sb/fixtures" PATH="$sb/bin:$PATH" \
    "$sb/scripts/bootstrap-aws.sh" "$@" >"$out" 2>&1
}

# fresh sandbox per case: bootstrap copy + current template + stubs
new_case() { # $1 = case name → echoes sandbox dir
  local sb="$WORK/$1"
  rm -rf "$sb"
  mkdir -p "$sb/infra" "$sb/scripts"
  cp "$BOOTSTRAP" "$sb/scripts/bootstrap-aws.sh"
  chmod +x "$sb/scripts/bootstrap-aws.sh"
  cp "$ROOT/infra/github-actions.yaml" "$sb/infra/github-actions.yaml"
  make_sandbox "$sb"
  printf '%s' "$sb"
}

# --- fixtures for the discovery controls --------------------------------------
stub_out() { cat >"$1/fixtures/$2.out"; }                # $1=sb $2=name, stdin
call_fails() { # $1=sb $2=name $3=rc, stdin = stderr text
  local sb=$1 name=$2 rc=$3
  cat >"$sb/fixtures/$name.err"
  printf '%s' "$rc" >"$sb/fixtures/$name.rc"
}

# Minimal working world: identity answers the verified account, the provider
# listing starts empty, and cloudformation deploy is RECORDED then refused
# (no stack mutation in a harness) — "reaches deployment" = the recorded line.
base_fixtures() { # $1 = sb
  local sb=$1
  stub_out "$sb" identity <<J
{"Account":"${ACCOUNT}","UserId":"harness","Arn":"arn:aws:iam::${ACCOUNT}:root"}
J
  stub_out "$sb" oidc-list <<J
{"OpenIDConnectProviderList":[]}
J
  stub_out "$sb" s3-location <<J
{"LocationConstraint":"$REGION"}
J
  call_fails "$sb" cfn-deploy 254 <<'E'
stub-aws: no stack mutation in harness (the deploy call was recorded only)
E
}

provider_list() { # $1 = sb, rest = ARNs to list
  local sb=$1 arn first=1
  {
    printf '{"OpenIDConnectProviderList":['
    shift
    for arn in "$@"; do
      [ "$first" -eq 1 ] || printf ','
      first=0
      printf '{"Arn":"%s"}' "$arn"
    done
    printf ']}'
  } >"$sb/fixtures/oidc-list.out"
}

get_fixture() { # $1 = sb, $2 = Url, rest = client IDs
  local sb=$1 url=$2 cid first=1
  {
    printf '{"Url":"%s","ClientIDList":[' "$url"
    shift 2
    for cid in "$@"; do
      [ "$first" -eq 1 ] || printf ','
      first=0
      printf '"%s"' "$cid"
    done
    printf ']}'
  } >"$sb/fixtures/oidc-get.out"
}

valid_provider_fixtures() { # $1 = sb: canonical provider, exact Url + audience
  provider_list "$1" "$CANONICAL_ARN"
  get_fixture "$1" "$GH_HOST" sts.amazonaws.com
}

# --- simulator world (B-R2): official-shape signature-keyed responder ---------
# The responder parses the bootstrap's ACTUAL simulate arguments (captured
# verbatim) and answers each signature with the official response shape:
# ONE EvaluationResult per action; per-resource decisions ONLY in
# ResourceSpecificResults[].EvalResourceDecision. Decisions mirror what the
# reviewed template policy would really produce, including good mixed cases
# (allowed deploy document + denied alternate instance and vice versa) and
# both deny flavours (explicitDeny for the fenced documents/actions,
# implicitDeny for plain absence of an Allow). Unknown signatures exit 254.
# MUTATION (optional) bends exactly one response so the harness can prove
# the bootstrap refuses incomplete or falsified censuses.
make_responder() { # $1 = sb, $2 = mutation name ("" = good world)
  local sb=$1 mut=$2
  cat >"$sb/fixtures/simulate.env" <<ENV
ACCOUNT=$ACCOUNT
REGION=$REGION
BUCKET=$BUCKET
INSTANCE_ID=$INSTANCE_ID
INSTANCE_ROLE=$INSTANCE_ROLE
DEPLOY_ROLE=$DEPLOY_ROLE
DEPLOY_DOC=$DEPLOY_DOC
REAL_JQ=$REAL_JQ
MUTATION=$mut
ENV
  cat >"$sb/fixtures/simulate.responder" <<'RESPONDER'
#!/usr/bin/env bash
# Official-shape iam simulate-principal-policy responder (harness-internal).
set -u
here=$(cd "$(dirname "$0")" && pwd)
. "$here/simulate.env"
src='' acts='' ress=''
while [ $# -gt 0 ]; do
  case "$1" in
    --policy-source-arn) src="$2"; shift 2;;
    --action-names) shift
      while [ $# -gt 0 ]; do case "$1" in -*) break;; esac; acts="$acts $1"; shift; done;;
    --resource-arns) shift
      while [ $# -gt 0 ]; do case "$1" in -*) break;; esac; ress="$ress $1"; shift; done;;
    *) shift;;
  esac
done
deploy_role_arn="arn:aws:iam::$ACCOUNT:role/$DEPLOY_ROLE"
inst_role_arn="arn:aws:iam::$ACCOUNT:role/$INSTANCE_ROLE"
doc_arn="arn:aws:ssm:$REGION:$ACCOUNT:document/$DEPLOY_DOC"
inst_arn="arn:aws:ec2:$REGION:$ACCOUNT:instance/$INSTANCE_ID"
other_arn="arn:aws:ec2:$REGION:$ACCOUNT:instance/i-00000000000000000"
runshell_arn="arn:aws:ssm:$REGION:$ACCOUNT:document/AWS-RunShellScript"
art_arn="arn:aws:s3:::$BUCKET/artifacts/0000000000000000000000000000000000000000000000000000000000000000/gateway-linux-arm64.gz"
legacy_arn="arn:aws:s3:::$BUCKET/relay-arm64.gz"
bucket_arn="arn:aws:s3:::$BUCKET"
key1="arn:aws:ssm:$REGION:$ACCOUNT:parameter/pocketshell-sync/gateway-signing-key"
key2="arn:aws:ssm:$REGION:$ACCOUNT:parameter/pocketshell-sync/gateway-signing-key-previous"
key3="arn:aws:ssm:$REGION:$ACCOUNT:parameter/pocketshell-sync/anything"
key4="arn:aws:ssm:$REGION:$ACCOUNT:parameter/gateway-signing-key"
sync_root="arn:aws:ssm:$REGION:$ACCOUNT:parameter/pocketshell-sync"
param_root="arn:aws:ssm:$REGION:$ACCOUNT:parameter/"

rsr() { printf '{"EvalResourceName":"%s","EvalResourceDecision":"%s","MatchedStatements":[],"MissingContextValues":[]}' "$1" "$2"; }
act() { # $1 = action, $2 = aggregate decision, rest = optional resource-specific results
  local a=$1 d=$2 IFS=,
  shift 2
  if [ $# -gt 0 ]; then
    printf '{"EvalActionName":"%s","EvalDecision":"%s","MatchedStatements":[],"MissingContextValues":[],"ResourceSpecificResults":[%s]}' "$a" "$d" "$*"
  else
    printf '{"EvalActionName":"%s","EvalDecision":"%s","MatchedStatements":[],"MissingContextValues":[]}' "$a" "$d"
  fi
}
wrap() { local IFS=,; printf '{"EvaluationResults":[%s]}' "$*"; }

key="$src|$acts|$ress"
case "$key" in
  "$deploy_role_arn| s3:PutObject| $art_arn")
    resp=$(wrap "$(act 's3:PutObject' allowed "$(rsr "$art_arn" allowed)")");;
  "$deploy_role_arn| s3:PutObject| $legacy_arn")
    resp=$(wrap "$(act 's3:PutObject' implicitDeny "$(rsr "$legacy_arn" implicitDeny)")");;
  "$deploy_role_arn| s3:DeleteObject| $art_arn")
    resp=$(wrap "$(act 's3:DeleteObject' explicitDeny "$(rsr "$art_arn" explicitDeny)")");;
  "$deploy_role_arn| s3:GetObject| $art_arn")
    resp=$(wrap "$(act 's3:GetObject' implicitDeny "$(rsr "$art_arn" implicitDeny)")");;
  "$deploy_role_arn| ssm:SendCommand| $doc_arn $inst_arn")
    resp=$(wrap "$(act 'ssm:SendCommand' allowed "$(rsr "$doc_arn" allowed)" "$(rsr "$inst_arn" allowed)")");;
  "$deploy_role_arn| ssm:SendCommand| $runshell_arn $inst_arn")
    resp=$(wrap "$(act 'ssm:SendCommand' explicitDeny "$(rsr "$runshell_arn" explicitDeny)" "$(rsr "$inst_arn" allowed)")");;
  "$deploy_role_arn| ssm:SendCommand| $doc_arn $other_arn")
    resp=$(wrap "$(act 'ssm:SendCommand' implicitDeny "$(rsr "$doc_arn" allowed)" "$(rsr "$other_arn" implicitDeny)")");;
  "$deploy_role_arn| ssm:GetCommandInvocation|")
    resp=$(wrap "$(act 'ssm:GetCommandInvocation' allowed)");;
  "$deploy_role_arn| ssm:StartSession| $inst_arn")
    resp=$(wrap "$(act 'ssm:StartSession' explicitDeny "$(rsr "$inst_arn" explicitDeny)")");;
  "$deploy_role_arn| ssm:StartAutomationExecution| *")
    resp=$(wrap "$(act 'ssm:StartAutomationExecution' explicitDeny "$(rsr '*' explicitDeny)")");;
  "$deploy_role_arn| iam:CreateRole| *")
    resp=$(wrap "$(act 'iam:CreateRole' explicitDeny "$(rsr '*' explicitDeny)")");;
  "$deploy_role_arn| ec2:AuthorizeSecurityGroupEgress| *")
    resp=$(wrap "$(act 'ec2:AuthorizeSecurityGroupEgress' explicitDeny "$(rsr '*' explicitDeny)")");;
  "$deploy_role_arn| route53:ChangeResourceRecordSets| *")
    resp=$(wrap "$(act 'route53:ChangeResourceRecordSets' explicitDeny "$(rsr '*' explicitDeny)")");;
  "$inst_role_arn| s3:GetObject| $art_arn")
    resp=$(wrap "$(act 's3:GetObject' allowed "$(rsr "$art_arn" allowed)")");;
  "$inst_role_arn| s3:GetObject| $legacy_arn")
    resp=$(wrap "$(act 's3:GetObject' allowed "$(rsr "$legacy_arn" allowed)")");;
  "$inst_role_arn| s3:ListBucket| $bucket_arn")
    resp=$(wrap "$(act 's3:ListBucket' implicitDeny "$(rsr "$bucket_arn" implicitDeny)")");;
  "$inst_role_arn| ssm:GetParameter ssm:GetParameters ssm:GetParameterHistory| $key1" | \
  "$inst_role_arn| ssm:GetParameter ssm:GetParameters ssm:GetParameterHistory| $key2" | \
  "$inst_role_arn| ssm:GetParameter ssm:GetParameters ssm:GetParameterHistory| $key3")
    resp=$(wrap \
      "$(act 'ssm:GetParameter' explicitDeny "$(rsr "${ress# }" explicitDeny)")" \
      "$(act 'ssm:GetParameters' explicitDeny "$(rsr "${ress# }" explicitDeny)")" \
      "$(act 'ssm:GetParameterHistory' explicitDeny "$(rsr "${ress# }" explicitDeny)")");;
  "$inst_role_arn| ssm:GetParameter| $key4")
    resp=$(wrap "$(act 'ssm:GetParameter' explicitDeny "$(rsr "$key4" explicitDeny)")");;
  "$inst_role_arn| ssm:GetParametersByPath| $sync_root")
    resp=$(wrap "$(act 'ssm:GetParametersByPath' explicitDeny "$(rsr "$sync_root" explicitDeny)")");;
  "$inst_role_arn| ssm:GetParametersByPath| $param_root")
    resp=$(wrap "$(act 'ssm:GetParametersByPath' explicitDeny "$(rsr "$param_root" explicitDeny)")");;
  *)
    echo "responder: unexpected simulate signature: $key" >&2
    exit 254;;
esac

# Mutation negatives: bend exactly ONE response of the intended signature so
# the bootstrap must refuse (a mutated census must never be accepted).
if [ -n "$MUTATION" ]; then
  case "$MUTATION" in
    wrong_first)
      [ "$key" = "$deploy_role_arn| s3:PutObject| $art_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].ResourceSpecificResults[0].EvalResourceDecision = "implicitDeny"') ;;
    wrong_pair2)
      [ "$key" = "$deploy_role_arn| ssm:SendCommand| $doc_arn $inst_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].ResourceSpecificResults[1].EvalResourceDecision = "implicitDeny"') ;;
    wrong_later)
      [ "$key" = "$inst_role_arn| ssm:GetParameter ssm:GetParameters ssm:GetParameterHistory| $key1" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[2].ResourceSpecificResults[0].EvalResourceDecision = "allowed"') ;;
    missing_pair)
      [ "$key" = "$deploy_role_arn| ssm:SendCommand| $runshell_arn $inst_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].ResourceSpecificResults |= .[0:1]') ;;
    missing_result)
      [ "$key" = "$inst_role_arn| ssm:GetParameter ssm:GetParameters ssm:GetParameterHistory| $key1" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults |= .[0:1] + .[2:]') ;;
    empty_results)
      [ "$key" = "$deploy_role_arn| s3:PutObject| $art_arn" ] && resp='{"EvaluationResults":[]}' ;;
    null_decision)
      [ "$key" = "$deploy_role_arn| s3:PutObject| $art_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].ResourceSpecificResults[0].EvalResourceDecision = null') ;;
    unknown_decision)
      [ "$key" = "$deploy_role_arn| s3:PutObject| $art_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].ResourceSpecificResults[0].EvalResourceDecision = "notapplicable"') ;;
    unknown_action)
      [ "$key" = "$deploy_role_arn| s3:PutObject| $art_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].EvalActionName = "s3:ListObject"') ;;
    duplicate_pair)
      [ "$key" = "$deploy_role_arn| ssm:SendCommand| $doc_arn $inst_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].ResourceSpecificResults += [.EvaluationResults[0].ResourceSpecificResults[0]]') ;;
    conflict_pair)
      [ "$key" = "$deploy_role_arn| ssm:SendCommand| $doc_arn $inst_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].ResourceSpecificResults += [.EvaluationResults[0].ResourceSpecificResults[0] | .EvalResourceDecision = "implicitDeny"]') ;;
    extra_pair)
      [ "$key" = "$deploy_role_arn| s3:PutObject| $art_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c --arg b "$BUCKET" \
          '.EvaluationResults[0].ResourceSpecificResults += [{"EvalResourceName":("arn:aws:s3:::" + $b + "/someone-elses-prefix/x"),"EvalResourceDecision":"allowed","MatchedStatements":[],"MissingContextValues":[]}]') ;;
    missing_context)
      [ "$key" = "$deploy_role_arn| ssm:SendCommand| $doc_arn $inst_arn" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].ResourceSpecificResults[0].MissingContextValues = ["ssm:DocumentType"]') ;;
    missing_context_top)
      [ "$key" = "$deploy_role_arn| ssm:GetCommandInvocation|" ] &&
        resp=$(printf '%s' "$resp" | "$REAL_JQ" -c '.EvaluationResults[0].MissingContextValues = ["aws:RequestedRegion"]') ;;
    malformed)
      [ "$key" = "$deploy_role_arn| s3:PutObject| $art_arn" ] && { printf '{"EvaluationResults":[{"EvalAc'; exit 0; } ;;
    two_documents)
      [ "$key" = "$deploy_role_arn| s3:PutObject| $art_arn" ] && { printf '{"EvaluationResults":[]}{"EvaluationResults":[]}'; exit 0; } ;;
    *) echo "responder: unknown mutation: $MUTATION" >&2; exit 254;;
  esac
fi
printf '%s' "$resp"
exit 0
RESPONDER
  chmod +x "$sb/fixtures/simulate.responder"
}

sim_world() { # $1 = sb, $2 = mutation (""): the stubbed stack deploy SUCCEEDS
  # (still recorded — nothing real is mutated) so the FULL simulator block
  # runs; a responder answers every simulate signature.
  local sb=$1 mut=$2
  rm -f "$sb/fixtures/cfn-deploy.err" "$sb/fixtures/cfn-deploy.rc"
  printf '%s' '{"Stacks":[]}' >"$sb/fixtures/cfn-describe.out"
  make_responder "$sb" "$mut"
}

# --- controls: pre-AWS refusals (R3, unchanged) --------------------------------
refuse_case() { # $1 = label, $2 = expected-refusal-text, rest = bootstrap args
  local label=$1 want=$2
  shift 2
  local sb out rc
  sb=$(new_case "$label")
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" "$@"
  rc=$?
  if [ "$rc" -eq 0 ]; then
    ko "$label: accepted (exit 0) — must refuse"
    return
  fi
  if [ -s "$sb/aws-calls.log" ]; then
    ko "$label: refused, but AFTER AWS calls: $(head -1 "$sb/aws-calls.log")"
    return
  fi
  if ! grep -qF -- "$want" "$out"; then
    ko "$label: refused without the expected reason ('$want'): $(head -2 "$out" | tr '\n' ' ')"
    return
  fi
  ok "$label: refused before any AWS call ('$want')"
}

refuse_case classic_name_subject_refused "refusing OIDC subject" \
  --oidc-subject 'repo:PocketShell-io/pocketshell-gateway:ref:refs/heads/main' --no-exec
refuse_case wildcard_subject_refused "refusing wildcard" \
  --oidc-subject 'repo:PocketShell-io/pocketshell-gateway:*' --no-exec
refuse_case empty_subject_refused "refusing EMPTY OIDC subject" \
  --oidc-subject '' --no-exec
refuse_case other_subject_refused "ONLY the verified immutable subject" \
  --oidc-subject 'repo:Evil-Org/evil:ref:refs/heads/main' --no-exec
refuse_case repository_override_refused "refusing repository override" \
  --repository 'Evil-Org/evil' --no-exec
refuse_case invalid_create_oidc_flag_refused "invalid --create-oidc" \
  --create-oidc maybe --no-exec

# --- controls: template drift (R3, unchanged) ----------------------------------
drift_case() { # $1 = label, $2 = expected text, $3 = sed script on the template
  local label=$1 want=$2 sedexpr=$3
  local sb out rc
  sb=$(new_case "$label")
  sed -i "$sedexpr" "$sb/infra/github-actions.yaml"
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" --no-exec
  rc=$?
  if [ "$rc" -eq 0 ]; then
    ko "$label: drifted template accepted (exit 0) — must refuse"
    return
  fi
  if [ -s "$sb/aws-calls.log" ]; then
    ko "$label: refused, but AFTER AWS calls"
    return
  fi
  if ! grep -qF -- "$want" "$out"; then
    ko "$label: refused without expected reason ('$want')"
    return
  fi
  ok "$label: template drift refused before any AWS call ('$want')"
}

drift_case template_subject_default_swapped "template assertion failed" \
  's|repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main|repo:PocketShell-io/pocketshell-gateway:ref:refs/heads/main|'
drift_case template_audience_changed "template assertion failed" \
  's|token.actions.githubusercontent.com:aud: sts.amazonaws.com|token.actions.githubusercontent.com:aud: something-else|'
drift_case template_pattern_loosened "template assertion failed" \
  's|AllowedPattern: "\^repo:PocketShell-io@327658728/pocketshell-gateway@1408222370:ref:refs/heads/main\$"|AllowedPattern: "^repo:.*"|'

# --- controls: subject validation passes, bootstrap reaches (stubbed) AWS ------
positive_case() { # $1 = label, rest = bootstrap args
  local label=$1
  shift
  local sb out rc
  sb=$(new_case "$label")
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" "$@"
  rc=$?
  if [ "$rc" -eq 0 ]; then
    ko "$label: reached no AWS call — validation never exercised (stub aws must be reached)"
    return
  fi
  if ! grep -q "sts get-caller-identity" "$sb/aws-calls.log"; then
    ko "$label: did not reach the identity call after passing validation: $(head -2 "$out" | tr '\n' ' ')"
    return
  fi
  if ! grep -qF -- "$IMMUTABLE" "$out"; then
    ko "$label: immutable subject not echoed in the plan"
    return
  fi
  ok "$label: validation passed, proceeded to (stubbed) AWS"
}

positive_case default_subject_passes_validation --no-exec
positive_case explicit_immutable_subject_passes_validation --oidc-subject "$IMMUTABLE" --no-exec

# --- controls: OIDC provider resolution (ExistingOidcProviderArn fix) ----------
deploy_line() { # $1 = sb → the recorded (stubbed) cloudformation deploy line
  grep ' cloudformation deploy ' "$1/aws-calls.log" | head -1
}

# Reuse path: a VALID provider (exact canonical ARN, exact issuer Url, the
# exact sts.amazonaws.com audience) must reach deployment as
# CreateOidcProvider=false + ExistingOidcProviderArn=<exact ARN>.
existing_valid_provider_reaches_deploy() {
  local label=existing_valid_provider_reaches_deploy sb out rc line
  sb=$(new_case "$label")
  base_fixtures "$sb"
  valid_provider_fixtures "$sb"
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" # deploy attempted against the (refusing) stub, so the line is recorded
  rc=$?
  if [ "$rc" -eq 0 ]; then
    ko "$label: exit 0 — the stubbed deploy must have been attempted (and refused)"
    return
  fi
  line=$(deploy_line "$sb")
  if [ -z "$line" ]; then
    ko "$label: never reached the deployment call: $(head -3 "$out" | tr '\n' ' ')"
    return
  fi
  grep -q ' iam list-open-id-connect-providers ' "$sb/aws-calls.log" ||
    { ko "$label: deployment without a provider listing: $line"; return; }
  grep -q ' iam get-open-id-connect-provider ' "$sb/aws-calls.log" ||
    { ko "$label: deployment without provider validation: $line"; return; }
  case "$line" in
    *CreateOidcProvider=false*) ;;
    *) ko "$label: deploy line lacks CreateOidcProvider=false: $line"; return;;
  esac
  case "$line" in
    *"ExistingOidcProviderArn=$CANONICAL_ARN"*) ;;
    *) ko "$label: deploy line lacks the EXACT provider ARN (pre-fix bug): $line"; return;;
  esac
  ok "$label: exact ARN + CreateOidcProvider=false reached the (stubbed) deployment"
}

# Create path: a genuinely absent provider (listing SUCCEEDED, no match) must
# select CreateOidcProvider=true with no ExistingOidcProviderArn override.
genuinely_absent_provider_creates() {
  local label=genuinely_absent_provider_creates sb out rc line
  sb=$(new_case "$label")
  base_fixtures "$sb"
  # A failing get-open-id-connect-provider must NOT be how absence is proven:
  # the old script concluded "absent" from exactly such a failed lookup.
  call_fails "$sb" oidc-get 254 <<'E'
An error occurred (NoSuchEntity) when calling the GetOpenIDConnectProvider operation: not found (harness)
E
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" # deploy attempted against the (refusing) stub, so the line is recorded
  rc=$?
  if [ "$rc" -eq 0 ]; then
    ko "$label: exit 0 — the stubbed deploy must have been attempted (and refused)"
    return
  fi
  line=$(deploy_line "$sb")
  if [ -z "$line" ]; then
    ko "$label: never reached the deployment call: $(head -3 "$out" | tr '\n' ' ')"
    return
  fi
  grep -q ' iam list-open-id-connect-providers ' "$sb/aws-calls.log" ||
    { ko "$label: created without a SUCCESSFUL listing (absence not proven): $line"; return; }
  if grep -q ' iam get-open-id-connect-provider ' "$sb/aws-calls.log"; then
    ko "$label: absence concluded from a get-open-id-connect-provider call"
    return
  fi
  case "$line" in
    *CreateOidcProvider=true*) ;;
    *) ko "$label: deploy line lacks CreateOidcProvider=true: $line"; return;;
  esac
  case "$line" in
    *ExistingOidcProviderArn=*) ko "$label: create pass must not carry ExistingOidcProviderArn: $line"; return;;
  esac
  ok "$label: genuine absence (successful empty listing) selected create"
}

# An UNRELATED provider (different issuer path, same account) is not a match:
# matching must be exact-path, so this is still a genuine absence → create.
unrelated_provider_still_creates() {
  local label=unrelated_provider_still_creates sb out rc line
  sb=$(new_case "$label")
  base_fixtures "$sb"
  provider_list "$sb" "arn:aws:iam::${ACCOUNT}:oidc-provider/oidc.eks.eu-west-1.amazonaws.com/id/EXAMPLEDUMMY"
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" # deploy attempted against the (refusing) stub, so the line is recorded
  rc=$?
  [ "$rc" -ne 0 ] && [ -n "$(deploy_line "$sb")" ] || { ko "$label: did not reach deployment: $(head -3 "$out" | tr '\n' ' ')"; return; }
  line=$(deploy_line "$sb")
  case "$line" in
    *CreateOidcProvider=true*) ;;
    *) ko "$label: unrelated provider must not block a genuine create: $line"; return;;
  esac
  case "$line" in
    *ExistingOidcProviderArn=*) ko "$label: create pass must not carry an unrelated ARN: $line"; return;;
  esac
  ok "$label: unrelated provider ignored, exact matching preserved, create selected"
}

# Refusals AFTER the (read-only) identity+listing calls but BEFORE deployment.
discovery_refusal_case() { # $1 = label, $2 = fixture-setup fn, $3 = expected text, rest = args
  local label=$1 setup=$2 want=$3
  shift 3
  local sb out rc
  sb=$(new_case "$label")
  base_fixtures "$sb"
  "$setup" "$sb"
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" "$@"
  rc=$?
  if [ "$rc" -eq 0 ]; then
    ko "$label: accepted (exit 0) — must refuse"
    return
  fi
  if grep -q ' cloudformation deploy ' "$sb/aws-calls.log"; then
    ko "$label: refused only AFTER attempting deployment: $(deploy_line "$sb")"
    return
  fi
  if ! grep -qF -- "$want" "$out"; then
    ko "$label: refused without expected reason ('$want'): $(tail -3 "$out" | tr '\n' ' ')"
    return
  fi
  ok "$label: refused before deployment ('$want')"
}

fx_foreign_account()    { provider_list "$1" "arn:aws:iam::999999999999:oidc-provider/${GH_HOST}"; }
fx_wrong_provider_url() { provider_list "$1" "$CANONICAL_ARN"; get_fixture "$1" "evil.example.invalid" sts.amazonaws.com; }
fx_wrong_audience()     { provider_list "$1" "$CANONICAL_ARN"; get_fixture "$1" "$GH_HOST" "events.amazonaws.com" "openid.amazonaws.com"; }
fx_duplicate_arn()      { provider_list "$1" "$CANONICAL_ARN" "$CANONICAL_ARN"; }
fx_malformed_list()     { printf '{"OpenIDConnectProviderList":"not-a-list"}' >"$1/fixtures/oidc-list.out"; }
fx_list_transport()     { call_fails "$1" oidc-list 254 <<'E'
Could not connect to the endpoint URL: https://iam.eu-west-1.amazonaws.com/ (harness-simulated transport failure)
E
}
fx_list_access_denied() { call_fails "$1" oidc-list 254 <<'E'
An error occurred (AccessDenied) when calling the ListOpenIDConnectProviders operation: not authorized (harness)
E
}
fx_get_access_denied() {
  provider_list "$1" "$CANONICAL_ARN"
  call_fails "$1" oidc-get 254 <<'E'
An error occurred (AccessDenied) when calling the GetOpenIDConnectProvider operation: not authorized (harness)
E
}
fx_get_no_such_entity() {
  provider_list "$1" "$CANONICAL_ARN"
  call_fails "$1" oidc-get 254 <<'E'
An error occurred (NoSuchEntity) when calling the GetOpenIDConnectProvider operation: listed but unreadable (harness)
E
}
no_fixtures() { :; } # explicit-false-absent case uses the empty base world

discovery_refusal_case foreign_account_provider_refused fx_foreign_account \
  "foreign account or mangled provider" --no-exec
discovery_refusal_case wrong_provider_url_refused fx_wrong_provider_url \
  "is not the GitHub issuer" --no-exec
discovery_refusal_case wrong_provider_audience_refused fx_wrong_audience \
  "does not trust audience" --no-exec
discovery_refusal_case duplicate_provider_arn_refused fx_duplicate_arn \
  "ambiguous OIDC discovery" --no-exec
discovery_refusal_case malformed_provider_list_refused fx_malformed_list \
  "cannot parse the OIDC provider list" --no-exec
discovery_refusal_case list_transport_failure_refuses fx_list_transport \
  "cannot list IAM OIDC providers" --no-exec
discovery_refusal_case list_access_denied_refuses fx_list_access_denied \
  "cannot list IAM OIDC providers" --no-exec
discovery_refusal_case get_access_denied_refuses fx_get_access_denied \
  "registered but cannot be read" --no-exec
discovery_refusal_case get_no_such_entity_refuses fx_get_no_such_entity \
  "registered but cannot be read" --no-exec

# Explicit --create-oidc false: reuse WITHOUT a validated provider is the bug
# this fix closes — absent provider must refuse, valid provider must pass the
# exact ARN.
discovery_refusal_case explicit_false_absent_refuses no_fixtures \
  "nothing to reuse" --create-oidc false --no-exec

# --- controls: successful-but-malformed listings must NOT prove absence -------
# Independent-review counterexamples: a SUCCEEDED list-open-id-connect-providers
# call whose body is empty, not one JSON document, carries a missing/non-array
# list key, or has {}, null or numeric-Arn rows used to select CREATE as if
# absence were proven (jq iterates all of those with exit 0). Each case below
# runs the FULL bootstrap and captures its arguments: the refusal must happen
# after the listing and before any get-open-id-connect-provider/deploy call.
malformed_list_case() { # $1 = label, $2 = fixture fn, $3 = expected reason token
  local label=$1 setup=$2 want=$3 sb out rc
  sb=$(new_case "$label")
  base_fixtures "$sb"
  "$setup" "$sb"
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" --no-exec
  rc=$?
  [ "$rc" -ne 0 ] || { ko "$label: accepted a malformed listing (exit 0) — must refuse"; return; }
  if grep -q ' cloudformation deploy ' "$sb/aws-calls.log"; then
    ko "$label: refused only AFTER attempting deployment: $(deploy_line "$sb")"
    return
  fi
  if ! grep -q ' iam list-open-id-connect-providers ' "$sb/aws-calls.log"; then
    ko "$label: refused without issuing the listing call: $(head -2 "$out" | tr '\n' ' ')"
    return
  fi
  if grep -q ' iam get-open-id-connect-provider ' "$sb/aws-calls.log"; then
    ko "$label: consulted a provider after a malformed listing"
    return
  fi
  if ! grep -qF -- "$want" "$out"; then
    ko "$label: refused without expected reason ('$want'): $(tail -3 "$out" | tr '\n' ' ')"
    return
  fi
  ok "$label: malformed listing refused before any get/deploy ('$want')"
}

fx_list_empty_output() { : >"$1/fixtures/oidc-list.out"; }
fx_list_row_no_arn()    { printf '{"OpenIDConnectProviderList":[{}]}' >"$1/fixtures/oidc-list.out"; }
fx_list_null_row()      { printf '{"OpenIDConnectProviderList":[null]}' >"$1/fixtures/oidc-list.out"; }
fx_list_numeric_arn()   { printf '{"OpenIDConnectProviderList":[{"Arn":42}]}' >"$1/fixtures/oidc-list.out"; }
fx_multiple_documents() { printf '{"OpenIDConnectProviderList":[]}{"OpenIDConnectProviderList":[]}' >"$1/fixtures/oidc-list.out"; }

malformed_list_case malformed_list_empty_output_refuses fx_list_empty_output \
  "expected exactly one JSON object"
malformed_list_case malformed_list_row_without_arn_refuses fx_list_row_no_arn \
  "non-empty string Arn"
malformed_list_case malformed_list_null_row_refuses fx_list_null_row \
  "non-empty string Arn"
malformed_list_case malformed_list_numeric_arn_refuses fx_list_numeric_arn \
  "non-empty string Arn"
malformed_list_case malformed_list_multiple_documents_refuses fx_multiple_documents \
  "expected exactly one JSON object"

explicit_false_valid_provider_passes_exact_arn() {
  local label=explicit_false_valid_provider_passes_exact_arn sb out rc line
  sb=$(new_case "$label")
  base_fixtures "$sb"
  valid_provider_fixtures "$sb"
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" --create-oidc false # deploy attempted (and stub-refused)
  rc=$?
  [ "$rc" -ne 0 ] || { ko "$label: exit 0 — stubbed deploy must have been attempted"; return; }
  line=$(deploy_line "$sb")
  [ -n "$line" ] || { ko "$label: never reached deployment: $(head -3 "$out" | tr '\n' ' ')"; return; }
  case "$line" in
    *CreateOidcProvider=false*ExistingOidcProviderArn="${CANONICAL_ARN}"*) ;;
    *) ko "$label: deploy line lacks false + exact ARN: $line"; return;;
  esac
  ok "$label: explicit --create-oidc false passes the exact provider ARN"
}

# Explicit --create-oidc true: a forced create is the caller's explicit
# assertion; it must reach deployment as CreateOidcProvider=true with no
# ExistingOidcProviderArn override and without consulting the registry.
explicit_true_forces_create() {
  local label=explicit_true_forces_create sb out rc line
  sb=$(new_case "$label")
  base_fixtures "$sb"
  valid_provider_fixtures "$sb" # present, but irrelevant to an explicit create
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out" --create-oidc true # deploy attempted (and stub-refused)
  rc=$?
  [ "$rc" -ne 0 ] || { ko "$label: exit 0 — stubbed deploy must have been attempted"; return; }
  line=$(deploy_line "$sb")
  [ -n "$line" ] || { ko "$label: never reached deployment: $(head -3 "$out" | tr '\n' ' ')"; return; }
  case "$line" in
    *CreateOidcProvider=true*) ;;
    *) ko "$label: deploy line lacks CreateOidcProvider=true: $line"; return;;
  esac
  case "$line" in
    *ExistingOidcProviderArn=*) ko "$label: create pass must not carry ExistingOidcProviderArn: $line"; return;;
  esac
  if grep -q ' iam list-open-id-connect-providers ' "$sb/aws-calls.log"; then
    ko "$label: explicit create unexpectedly consulted the registry"
    return
  fi
  ok "$label: explicit --create-oidc true forces create without registry lookup"
}

# --- controls: the FULL simulator block (B-R2) --------------------------------
# These worlds let the stubbed cloudformation deploy SUCCEED so verification
# actually runs: the bootstrap must reach all 22 simulate calls (13 deploy-role
# cases / 16 pair verdicts + 9 runtime cases / 15 pair verdicts) and survive
# only a complete, honest result census.

full_simulator_block_runs_and_passes() {
  local label=full_simulator_block_runs_and_passes sb out rc line nsim npass send gci
  sb=$(new_case "$label")
  base_fixtures "$sb"
  valid_provider_fixtures "$sb"
  sim_world "$sb" ""
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out"
  rc=$?
  [ "$rc" -eq 0 ] || { ko "$label: bootstrap failed: $(tail -5 "$out" | tr '\n' ' ')"; return; }
  line=$(deploy_line "$sb")
  [ -n "$line" ] || { ko "$label: never reached the stubbed deployment"; return; }
  case "$line" in
    *CreateOidcProvider=false*ExistingOidcProviderArn="$CANONICAL_ARN"*) ;;
    *) ko "$label: deploy line lacks the provider-reuse parameters: $line"; return;;
  esac
  # The default execute path also preserves the large template bytes and
  # gives the AWS CLI its documented S3 staging bucket/prefix.
  local template_sha
  template_sha=$(sha256sum "$sb/infra/github-actions.yaml" | awk '{print $1}')
  if ! grep -Fq -- "--s3-bucket $BUCKET --s3-prefix bootstrap/templates/$template_sha" "$sb/aws-calls.log" ||
     ! cmp -s "$sb/infra/github-actions.yaml" "$sb/fixtures/stored-template.yaml"; then
    ko "$label: default deploy missing digest-addressed S3 staging or changed template bytes"
    return
  fi
  nsim=$(grep -c ' iam simulate-principal-policy ' "$sb/aws-calls.log")
  [ "$nsim" = 22 ] || { ko "$label: expected 22 simulate calls, got $nsim"; return; }
  npass=$(grep -c 'PASS \[' "$out")
  [ "$npass" = 31 ] || { ko "$label: expected 31 pair verdicts (16 deploy-role + 15 runtime), got $npass"; return; }
  if grep -q 'FAIL' "$out"; then
    ko "$label: FAIL lines present: $(grep 'FAIL' "$out" | head -2 | tr '\n' ' ')"
    return
  fi
  grep -qF 'bootstrap OK: all 31 permission checks passed' "$out" ||
    { ko "$label: missing the OK summary: $(tail -3 "$out" | tr '\n' ' ')"; return; }
  # argument capture: official CLI flags only, exact conditioned context
  if grep -q ' --actions ' "$sb/aws-calls.log"; then
    ko "$label: the dead '--actions' flag was used"
    return
  fi
  send=$(grep ' iam simulate-principal-policy ' "$sb/aws-calls.log" | grep "ssm:SendCommand" | grep -- "--resource-arns $DOC_ARN $INST_ARN " | head -1)
  [ -n "$send" ] || { ko "$label: no recorded SendCommand(document, pinned instance) call"; return; }
  case "$send" in
    *"--action-names ssm:SendCommand "*) ;;
    *) ko "$label: SendCommand call lacks --action-names: $send"; return;;
  esac
  case "$send" in
    *"--context-entries ContextKeyName=ssm:DocumentType,ContextKeyValues=Command,ContextKeyType=string"*) ;;
    *) ko "$label: SendCommand call lacks the ssm:DocumentType context: $send"; return;;
  esac
  case "$send" in
    *"ContextKeyName=aws:RequestedRegion,ContextKeyValues=$REGION,ContextKeyType=string"*) ;;
    *) ko "$label: SendCommand call lacks the aws:RequestedRegion context: $send"; return;;
  esac
  case "$send" in
    *"ContextKeyName=aws:ResourceAccount,ContextKeyValues=$ACCOUNT,ContextKeyType=string"*) ;;
    *) ko "$label: SendCommand call lacks the aws:ResourceAccount context: $send"; return;;
  esac
  gci=$(grep ' iam simulate-principal-policy ' "$sb/aws-calls.log" | grep -- '--action-names ssm:GetCommandInvocation' | head -1)
  [ -n "$gci" ] || { ko "$label: no recorded GetCommandInvocation call"; return; }
  if printf '%s' "$gci" | grep -q -- '--resource-arns'; then
    ko "$label: GetCommandInvocation must be simulated WITHOUT a document resource (API resource type *): $gci"
    return
  fi
  grep -q 'remaining live gate' "$out" ||
    { ko "$label: the live context-population gate is missing from the output"; return; }
  ok "$label: full simulator block ran (22 calls, 31 verdicts) with official args + context, all passed"
}

# Mutation negatives: every falsified/incomplete census must fail AFTER the
# stubbed deploy and inside the simulator (never before, never as a pass).
sim_mutation_case() { # $1 = label, $2 = mutation, $3 = expected failure token
  local label=$1 mut=$2 want=$3 sb out rc nsim
  sb=$(new_case "$label")
  base_fixtures "$sb"
  valid_provider_fixtures "$sb"
  sim_world "$sb" "$mut"
  out="$sb/out.txt"
  run_bootstrap "$sb" "$out"
  rc=$?
  [ "$rc" -ne 0 ] || { ko "$label: accepted (exit 0) — mutated simulator results must fail"; return; }
  grep -q ' cloudformation deploy ' "$sb/aws-calls.log" ||
    { ko "$label: control broken — never reached the stubbed deployment"; return; }
  nsim=$(grep -c ' iam simulate-principal-policy ' "$sb/aws-calls.log")
  [ "$nsim" -ge 1 ] || { ko "$label: never reached the simulator: $(tail -2 "$out" | tr '\n' ' ')"; return; }
  if grep -q 'bootstrap OK' "$out"; then
    ko "$label: reported OK despite mutated results"
    return
  fi
  if ! grep -qF -- "$want" "$out"; then
    ko "$label: failed without expected reason ('$want'): $(grep 'FAIL' "$out" | head -2 | tr '\n' ' ')"
    return
  fi
  ok "$label: mutated simulator result refused ('$want')"
}

sim_mutation_case sim_wrong_first_decision_refused wrong_first \
  "Allowed wanted, got implicitdeny"
sim_mutation_case sim_wrong_pair2_decision_refused wrong_pair2 \
  "Allowed wanted, got implicitdeny"
sim_mutation_case sim_wrong_later_decision_refused wrong_later \
  "ExplicitDeny wanted, got allowed"
sim_mutation_case sim_missing_pair_refused missing_pair \
  "result census mismatch"
sim_mutation_case sim_missing_result_refused missing_result \
  "result census mismatch"
sim_mutation_case sim_empty_results_refused empty_results \
  "EvaluationResults must not be empty"
sim_mutation_case sim_null_decision_refused null_decision \
  "invalid simulator response"
sim_mutation_case sim_unknown_decision_refused unknown_decision \
  "invalid simulator response"
sim_mutation_case sim_unknown_action_refused unknown_action \
  "result census mismatch"
sim_mutation_case sim_duplicate_pair_refused duplicate_pair \
  "result census mismatch"
sim_mutation_case sim_conflicting_duplicate_refused conflict_pair \
  "result census mismatch"
sim_mutation_case sim_extra_unexpected_pair_refused extra_pair \
  "result census mismatch"
sim_mutation_case sim_missing_context_values_refused missing_context \
  "MissingContextValues"
sim_mutation_case sim_missing_context_top_level_refused missing_context_top \
  "MissingContextValues"
sim_mutation_case sim_malformed_response_refused malformed \
  "not valid JSON"
sim_mutation_case sim_two_documents_refused two_documents \
  "not exactly one JSON object"

explicit_false_valid_provider_passes_exact_arn
explicit_true_forces_create
existing_valid_provider_reaches_deploy
genuinely_absent_provider_creates
unrelated_provider_still_creates
full_simulator_block_runs_and_passes

template_prepare_positive() {
  local sb sha url out
  sb=$(new_case template_prepare_positive); base_fixtures "$sb"; valid_provider_fixtures "$sb"
  sha=$(sha256sum "$sb/infra/github-actions.yaml" | awk '{print $1}')
  url="https://$BUCKET.s3.$REGION.amazonaws.com/bootstrap/templates/$sha/github-actions.yaml"
  out=$sb/result.txt
  if run_bootstrap "$sb" "$out" --create-oidc false --prepare-update-change-set reviewed-update; then
    [ "$(wc -c <"$sb/infra/github-actions.yaml")" -gt 51200 ] &&
      cmp -s "$sb/infra/github-actions.yaml" "$sb/fixtures/stored-template.yaml" &&
      grep -Fq -- "--template-url $url" "$sb/aws-calls.log" &&
      grep -Fq -- '--change-set-type UPDATE' "$sb/aws-calls.log" &&
      grep -Fq -- "--metadata sha256=$sha" "$sb/aws-calls.log" &&
      grep -Fq -- "--expected-bucket-owner $ACCOUNT" "$sb/aws-calls.log" &&
      grep -Fq -- "--if-none-match * --checksum-algorithm SHA256" "$sb/aws-calls.log" &&
      grep -Fq -- "ParameterKey=ExistingOidcProviderArn,ParameterValue=$CANONICAL_ARN" "$sb/aws-calls.log" &&
      ! grep -Eq 'cloudformation (deploy|execute-change-set)|iam simulate-principal-policy|--template-body|s3api create-bucket' "$sb/aws-calls.log" &&
      ok "TemplateURL preparation carries exact large template, owner/region/SHA/conditional upload and UPDATE-only trust parameters" ||
      ko "TemplateURL preparation custody or CREATE-only argument capture"
  else ko "TemplateURL preparation failed: $(tail -1 "$out")"; fi
}
template_prepare_negative() {
  local kind=$1 sb out reason required_call
  sb=$(new_case "template_prepare_$kind"); base_fixtures "$sb"; valid_provider_fixtures "$sb"
  case "$kind" in
    bucket_missing) reason='existing same-account template bucket is unavailable'; required_call='s3api head-bucket'; call_fails "$sb" s3-head 254 <<< 'NoSuchBucket';;
    wrong_region) reason='template bucket region us-west-2 differs from eu-west-1'; required_call='s3api get-bucket-location'; stub_out "$sb" s3-location <<< '{"LocationConstraint":"us-west-2"}';;
    upload_denied) reason='template conditional upload failed'; required_call='s3api put-object'; call_fails "$sb" s3-put 254 <<< '(AccessDenied)';;
    download_failed) reason='cannot verify uploaded template bytes'; required_call='s3api get-object'; call_fails "$sb" s3-get 254 <<< '(AccessDenied)';;
    wrong_bytes) reason='uploaded template byte digest mismatch'; required_call='s3api get-object'; : >"$sb/fixtures/corrupt-download";;
    wrong_metadata) reason='uploaded template metadata/checksum/length mismatch'; required_call='s3api get-object'; stub_out "$sb" s3-get <<< '{}';;
    conflict_bad_bytes)
      reason='uploaded template byte digest mismatch'; required_call='s3api get-object'
      printf 'NOT THE REVIEWED TEMPLATE\n' >"$sb/fixtures/stored-template.yaml"
      call_fails "$sb" s3-put 254 <<< '(PreconditionFailed)';;
  esac
  out=$sb/result.txt
  if run_bootstrap "$sb" "$out" --create-oidc false --prepare-update-change-set reviewed-update; then
    ko "$kind must refuse before change-set creation"
  elif grep -q 'cloudformation create-change-set' "$sb/aws-calls.log"; then
    ko "$kind reached change-set creation"
  elif ! grep -Fq "$required_call" "$sb/aws-calls.log" || ! grep -Fq "$reason" "$out"; then
    ko "$kind refused without executing intended probe and reporting its reason"
  else ok "$kind refuses after intended probe before any change-set creation"; fi
}
template_existing_exact_reused() {
  local sb
  sb=$(new_case template_existing_exact_reused); base_fixtures "$sb"; valid_provider_fixtures "$sb"
  cp "$sb/infra/github-actions.yaml" "$sb/fixtures/stored-template.yaml"
  call_fails "$sb" s3-put 254 <<< '(PreconditionFailed)'
  if run_bootstrap "$sb" "$sb/result.txt" --create-oidc false --prepare-update-change-set reviewed-update &&
     cmp -s "$sb/infra/github-actions.yaml" "$sb/fixtures/stored-template.yaml"; then
    ok "conditional conflict reuses only exact readback-verified template without overwrite"
  else ko "exact existing template reuse"; fi
}
template_prepare_noexec() {
  local sb
  sb=$(new_case template_prepare_noexec); base_fixtures "$sb"; valid_provider_fixtures "$sb"
  if run_bootstrap "$sb" "$sb/result.txt" --create-oidc false --prepare-update-change-set reviewed-update --no-exec &&
     ! grep -Eq 's3api put-object|cloudformation (create-change-set|execute-change-set|deploy)' "$sb/aws-calls.log"; then
    ok "no-exec preparation never uploads or creates/executes change set"
  else ko "no-exec preparation performed mutation or failed"; fi
  if run_bootstrap "$sb" "$sb/empty.txt" --prepare-update-change-set '' || [ -s "$sb/aws-calls.log" ]; then
    ko "empty prepare name must refuse before AWS"
  else ok "empty prepare name cannot fall through to execution"; fi
}
template_prepare_positive
for failure in bucket_missing wrong_region upload_denied download_failed wrong_bytes wrong_metadata conflict_bad_bytes; do
  template_prepare_negative "$failure"
done
template_existing_exact_reused
template_prepare_noexec

finish
