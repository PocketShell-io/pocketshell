#!/usr/bin/env bash
# Installer regression harness for scripts/host/install-deploy.sh (no AWS).
#
# Fidelity notes:
#   * Payloads are REAL Go cross-builds: linux/arm64 (accepted) and
#     linux/amd64 (must be rejected by the ELF gate) with distinct versions
#     per release (A/B/C) so archive and binary digests genuinely differ.
#   * The installer is loaded EXACTLY the way the SSM document embeds it:
#     strip the final `main "$@"` line, source the body, invoke main with
#     the document's arguments. The simulated primitives are exactly the
#     kernel/systemd primitives that cannot exist off-production:
#       - running_exe()/proc_status(): /proc of a process that isn't there;
#         the audit then runs FOR REAL against those values.
#       - systemd properties: stubctl reads the ACTUAL unit file + any
#         service.d drop-ins and applies systemd's merge semantics
#         (single-value keys last-win, list keys append, `Key=` resets),
#         then renders Exec* values EXACTLY as the installed systemd 255.4
#         does: PREFIX-FREE path=/argv[]= for plain ExecStart/ExecStartPre
#         (every privilege modifier is consumed at load time) and flags=
#         -carrying ExecStartEx/ExecStartPreEx — captured empirically and
#         pinned upstream (v255 load-fragment.c config_parse_exec,
#         dbus-execute.c append_exec_ex_command, shared/exec-util.c names).
#         Capability sets render as LOWERCASE mask names in capability order
#         (unset bounding set = full list) and IPAddressDeny as CIDR host
#         prefixes in set order — as systemd 252.23 (AL2023 production) and
#         255.4 print them (t71; deploy incident 37947576965).
#       - ownership: this harness runs unprivileged, so chown is a recorded
#         no-op whose EFFECTS are keyed by the REAL object identity (dev:ino
#         via the kernel, /proc fd magic links stat'ed directly — never
#         resolved to a pathname, so effects follow the operated inode across
#         rename/unlink); stubstat consults the identity map first, fixture
#         path rows second; write-bit math, effective-write probing (runuser
#         stub models the kernel's faccessat bits) and every REFUSAL decision
#         run for real. A separate REAL-descriptor calibration block proves
#         the kernel half (fd identity survives rename/unlink) — the stubbed
#         suite and the kernel proof are reported as what they are.
#   * aws/systemctl/curl are recorded stubs. curl serves /healthz JSON
#     derived from WHICH binary the "running process" is (version map), so
#     health verification is behavioural, not a static grep; curl never
#     accepts -k, and both the canonical name and the alias are probed.
#
# Scenarios: happy first migration (legacy preserved, D13 unit hardened),
# A->B->failed-C rollback to B, failed FIRST migration restores legacy,
# repeated-deploy idempotence (incl. idempotent user allocation), concurrent
# deploy lock, interrupted deploy recovery, wrong archive digest, amd64
# payload, corrupt gzip, VERSION sidecar mismatch, manifest mismatch, corrupt
# existing release, parameter injection, alias endpoint failure, restart
# refusal, IMDS strategy A/B + refusal, healthz version/commit mismatch,
# runtime-credential and DAC-audit negatives, drop-in escalation negatives,
# ReadWritePaths whitelist, symlinked-path trust refusal, uid-0 / dangerous
# group allocation refusals, shell forcing, and the R1 structured-systemd
# regression block (raw/malformed/multi-command/prefix property shapes
# refused; drop-in ExecStart/ExecStartPre overrides refused; ALL systemd
# property fixtures use the REAL structured `systemctl show` format).
set -uo pipefail
# (SC2046/SC1090 suppressed via scripts/tests/.shellcheckrc)

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
INSTALLER=$ROOT/scripts/host/install-deploy.sh
# Make passes its configured executable explicitly (including setup-go's
# selected toolchain). Direct invocations must supply an absolute GO or GOROOT;
# this harness never chooses an ambient PATH executable or a machine-local default.
# BEGIN configured Go resolver (exercised by installer-go-toolchain-test.sh)
resolve_configured_go() {
  local selected
  if [ -n "${GO:-}" ]; then
    selected=$GO
  elif [ -n "${GOROOT:-}" ]; then
    selected=${GOROOT%/}/bin/go
  else
    printf '%s\n' 'installer harness requires an absolute configured GO or GOROOT' >&2
    return 1
  fi
  case "$selected" in
    /*) ;;
    *) printf '%s\n' 'installer harness configured Go executable must be absolute' >&2; return 1 ;;
  esac
  if [ ! -f "$selected" ] || [ ! -x "$selected" ]; then
    printf '%s\n' 'installer harness configured Go executable is unavailable' >&2
    return 1
  fi
  printf '%s\n' "$selected"
}
# END configured Go resolver
GO=$(resolve_configured_go) || exit 1
# The sandbox tree must be TRUSTED all the way down (like the real install
# paths are root-owned to /), so the workdir lives under the repo's gitignored
# .tmp/ rather than /tmp (root-owned, refused by the audit here).
mkdir -p "$ROOT/.tmp"
WORK=$(mktemp -d "$ROOT/.tmp/harness.XXXXXX")
umask 077 # sandbox dirs are private, like root's install dirs
PASS=0
FAIL=0

note() { printf '[harness] %s\n' "$*"; }
ok() { PASS=$((PASS + 1)); printf '[harness] PASS: %s\n' "$1"; }
ko() { FAIL=$((FAIL + 1)); printf '[harness] FAIL: %s\n' "$1"; }
finish() {
  note "-----"
  note "passed=$PASS failed=$FAIL workdir=$WORK"
  [ "$FAIL" = 0 ] || exit 1
  exit 0
}
assert_eq() { # desc expected actual
  if [ "$2" = "$3" ]; then ok "$1"; else ko "$1 (expected '$2' got '$3')"; fi
}
assert_contains() { # desc needle haystack-file
  if grep -qF -- "$2" "$3"; then ok "$1"; else ko "$1 (missing '$2' in $3)"; fi
}
execstart_of() { sed -n 's/^ExecStart=//p' "$1" | tail -1; }
unit_value() { sed -n "s/^$1=//p" "$2" | tail -1; }

# --- fixtures: real cross-builds ---------------------------------------------
FIXDIR=$WORK/fixture
mkdir -p "$FIXDIR"
cat >"$FIXDIR/main.go" <<'EOF'
package main

var version string

func main() { println("fixture", version) }
EOF
printf 'module fixture\n\ngo 1.27\n' >"$FIXDIR/go.mod"

build_fixture() { # $1=out $2=GOARCH $3=version
  (cd "$FIXDIR" && GOOS=linux GOARCH=$2 CGO_ENABLED=0 "$GO" build -trimpath -ldflags "-X main.version=$3" -o "$1" .) ||
    { ko "go build $2 $3"; finish; }
}

archive_of() { gzip -n -9 -c "$1" >"$2"; }
sha_file() { sha256sum "$1" | awk '{print $1}'; }

REVISION_FIXTURE=0000000000000000000000000000000000000000

write_manifest() { # $1=dir $2=archive_sha $3=binary_sha $4=version
  printf '{"archive_sha256":"%s","binary_sha256":"%s","version":"%s","source_revision":"%s","domain":"gateway.pocketshell.io","aliases":"relay.pocketshell.io","service":"pocketshell-relay","certdir":"%s","registry":"%s","built_at":"harness"}\n' \
    "$2" "$3" "$4" "$REVISION_FIXTURE" "$CERT_CACHE" "$REGISTRY_FILE" >"$1/manifest.json"
}

# --- stubs --------------------------------------------------------------------
# Quoted heredocs (<<'STUB') pass text verbatim: no escaping needed or wanted.
make_stubs() { # $1 = sandbox dir
  local sb=$1
  mkdir -p "$sb/bin"

  # shared chown-map lookup (chown is a recorded no-op on this unprivileged host)
  cat >"$sb/bin/maplib.sh" <<'STUB'
mapped_owner() { # $1 = path → nearest recorded owner name (or '')
  local p=$1 line
  while :; do
    line=$(awk -v p="$p" -F'\t' '$1 == p { print $2; exit }' "${OWNERSHIP_MAP:?}" 2>/dev/null)
    [ -n "$line" ] && { printf '%s' "$line"; return 0; }
    [ "$p" = "/" ] && return 0
    p=$(dirname "$p")
  done
}
mapped_gid() { # $1 = path → nearest recorded NUMERIC group id (or '') — the
  # harness models `chown user:group` faithfully: the group is part of the
  # audit surface (runtime leaves carry the service group; ancestors carry
  # group 0), so %g must consult the recorded map like %U does.
  local p=$1 line
  while :; do
    line=$(awk -v p="$p" -F'\t' '$1 == p { print $3; exit }' "${OWNERSHIP_MAP:?}" 2>/dev/null)
    [ -n "$line" ] && { printf '%s' "$line"; return 0; }
    [ "$p" = "/" ] && return 0
    p=$(dirname "$p")
  done
}
# D23 identity-keyed metadata model. The installer's descriptor-bound
# operations act on /proc/<pid>/fd/<n>; the kernel resolves that magic link
# to the OPENED inode — the ORIGINAL one, even after the pathname has been
# renamed or unlinked. The stubs therefore NEVER reconstruct a pathname from
# an fd (the previous model consulted whatever occupied the reconstructed
# name after a rename/unlink — a semantic mismatch the D23 review refused).
# Instead: obj_id() asks the REAL kernel for the object identity (dev:ino)
# of a path or of an open descriptor, and recorded chown/chmod EFFECTS are
# keyed by that identity in OWNERSHIP_IDMAP. Fixture-seeded ownership rows
# stay in the path-keyed OWNERSHIP_MAP (they model the era state of a PATH
# before any deploy chown); identity rows take precedence.
obj_id() { # $1 = path or /proc fd path → 'dev:ino' of the ACTUAL object
  case "$1" in
    /proc/[0-9]*/fd/[0-9]*) /usr/bin/stat -Lc '%d:%i' "$1" 2>/dev/null;;
    *) /usr/bin/stat -c '%d:%i' "$1" 2>/dev/null;;
  esac
}
idmap_owner() { # $1 = identity → owner recorded by a real chown effect (or '')
  awk -F'\t' -v k="$1" '$1 == k { print $2; exit }' "${OWNERSHIP_IDMAP:?}" 2>/dev/null
}
idmap_gid() { # $1 = identity → numeric group recorded by a real chown effect (or '')
  awk -F'\t' -v k="$1" '$1 == k { print $3; exit }' "${OWNERSHIP_IDMAP:?}" 2>/dev/null
}
STUB

  cat >"$sb/bin/stubctl" <<'STUB'
#!/usr/bin/env bash
set -u
state_file="${FAKE_STATE_FILE:?}"; mainpid=${FAKE_MAIN_PID:-4242}
svc="${FAKE_SERVICE:?}"; unit_file="${UNIT_DIR:?}/$svc.service"
dropdir="${UNIT_DIR:?}/$svc.service.d"

# Render ONE Exec command group exactly as the installed systemd reports it.
# Empirically captured on systemd 255.4-1ubuntu8.17 (transient + on-disk user
# units with every prefix) and pinned upstream for v255:
#   * load-fragment.c config_parse_exec consumes the modifier run
#     (+ - ! !! @ :) from the first word BEFORE building the executable
#     path, so plain ExecStart/ExecStartPre report PREFIX-FREE path=/argv[]
#     and only lose ignore_errors=yes for '-';
#   * the Ex properties (dbus-execute.c append_exec_ex_command +
#     exec_command_flags_to_strv) carry the consumed flags instead, named
#     per shared/exec-util.c: ignore-failure privileged no-setuid ambient
#     no-env-expand (space-joined in that order, empty when no prefix);
#   * '@' has NO flag: it replaces argv[0] with the next word
#     ('+@/bin/echo PLUS-AT SECRET-ARGV0' -> 'argv[]=PLUS-AT SECRET-ARGV0').
# The pre-255 harness fixture preserved '+' inside path/argv — systemd never
# emits that, and accepting it would let the audit pass on invented output.
render_exec() { # $1 = raw Exec value, $2 = 1 → Ex form (flags=), 0 → plain (ignore_errors=)
  local val=$1 ex=$2 path argv flags='' ign=no at=0 f g
  local -a toks names=()
  read -r -a toks <<<"$val"
  path=${toks[0]:-}
  while :; do
    case "$path" in
      '!!'*) names+=("ambient"); path=${path#'!!'};;
      '!'*) names+=("no-setuid"); path=${path#'!'};;
      '-'*) names+=("ignore-failure"); ign=yes; path=${path#-};;
      '@'*) at=1; path=${path#@};;
      ':'*) names+=("no-env-expand"); path=${path#:};;
      '+'*) names+=("privileged"); path=${path#+};;
      *) break;;
    esac
  done
  if [ "$at" = 1 ]; then
    argv="${toks[*]:1}"
  else
    argv=$path
    [ "${#toks[@]}" -gt 1 ] && argv="$argv ${toks[*]:1}"
  fi
  for f in ignore-failure privileged no-setuid ambient no-env-expand; do
    for g in ${names[@]+"${names[@]}"}; do
      [ "$g" = "$f" ] && { flags="${flags:+$flags }$f"; break; }
    done
  done
  if [ "$ex" = 1 ]; then
    printf '{ path=%s ; argv[]=%s ; flags=%s ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }' "$path" "$argv" "$flags"
  else
    printf '{ path=%s ; argv[]=%s ; ignore_errors=%s ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }' "$path" "$argv" "$ign"
  fi
}

# Capability-set and IP-prefix rendering, as REAL `systemctl show --value`
# prints them (captured on systemd 255.4 with a transient unit carrying the
# hardened directives; the same capability_set_to_string() /
# in_addr_prefix_to_string() rendering produced the systemd 252.23 output of
# deploy incident 37947576965 on Amazon Linux 2023):
#   * capabilities are a 64-bit MASK: LOWERCASE names, capability-number
#     order, no duplicates; repeated assignments OR together, `Key=` resets to
#     the empty set; an UNSET bounding set renders as the full list below,
#     an unset ambient set as "";
#   * IPAddressDeny entries are prefixes rendered as CIDR (bare host address
#     -> /32 or /128, `any` -> 0.0.0.0/0 ::/0), in SET order — not unit order
#     (rendered reverse-sorted here so nothing can depend on unit order).
# The pre-fix stub echoed the unit text (uppercase CAP_NET_BIND_SERVICE, bare
# addresses): exactly the fiction that let the case-sensitive audit pass CI
# and fail every real deploy.
CAPS_V252='cap_chown cap_dac_override cap_dac_read_search cap_fowner cap_fsetid cap_kill cap_setgid cap_setuid cap_setpcap cap_linux_immutable cap_net_bind_service cap_net_broadcast cap_net_admin cap_net_raw cap_ipc_lock cap_ipc_owner cap_sys_module cap_sys_rawio cap_sys_chroot cap_sys_ptrace cap_sys_pacct cap_sys_admin cap_sys_boot cap_sys_nice cap_sys_resource cap_sys_time cap_sys_tty_config cap_mknod cap_lease cap_audit_write cap_audit_control cap_setfcap cap_mac_override cap_mac_admin cap_syslog cap_wake_alarm cap_block_suspend cap_audit_read cap_perfmon cap_bpf cap_checkpoint_restore'
render_caps() { # $1 = accumulated unit tokens -> systemd's mask rendering
  local want=" ${1,,} " c o='' t
  for t in $1; do
    case "$t" in '~'*) echo "stubctl: inverted capability lists are not modelled" >&2; exit 64;; esac
  done
  for c in $CAPS_V252; do
    case "$want" in *" $c "*) o="${o:+$o }$c";; esac
  done
  printf '%s' "$o"
}
render_ipprefixes() { # $1 = accumulated unit tokens -> CIDR set rendering
  local t
  for t in $1; do
    case "$t" in
      any) printf '%s\n' 0.0.0.0/0 ::/0;;
      */*) printf '%s\n' "$t";;
      *:*) printf '%s/128\n' "$t";;
      *) printf '%s/32\n' "$t";;
    esac
  done | LC_ALL=C sort -ru | tr '\n' ' ' | sed 's/ $//'
}

case "$1" in
  is-active) [ "$(cat "$state_file" 2>/dev/null)" = active ];;
  show)
    if [ "$2" = "-p" ] && [ "$3" = "MainPID" ]; then printf '%s\n' "$mainpid"; exit 0; fi
    key=""; prev=""
    for a in "$@"; do [ "$prev" = "-p" ] && key=$a; prev=$a; done
    # Manager-derived properties (not unit-file lines): systemd reports the
    # fragment it loaded the unit from and the drop-ins it merged.
    case "$key" in
      FragmentPath) [ -f "$unit_file" ] && printf '%s\n' "$unit_file"; exit 0;;
      DropInPaths)
        out=$(ls -1 "$dropdir"/*.conf 2>/dev/null | sort | tr '\n' ' ')
        printf '%s\n' "${out% }"; exit 0;;
    esac
    # Effective property with systemd merge semantics over unit + drop-ins:
    # single-value keys last-win, list keys append, `Key=` resets a list.
    # The *Ex properties mirror the SAME ExecStart=/ExecStartPre= unit lines
    # as their plain forms — they differ only in how systemd renders the
    # consumed modifiers (flags= vs ignore_errors=).
    match=$key
    case "$match" in ExecStartEx) match=ExecStart;; ExecStartPreEx) match=ExecStartPre;; esac
    files=()
    [ -f "$unit_file" ] && files+=("$unit_file")
    if [ -d "$dropdir" ]; then
      while IFS= read -r f; do files+=("$f"); done < <(ls -1 "$dropdir"/*.conf 2>/dev/null | sort)
    fi
    out=""; assigned=0
    for f in ${files[@]+"${files[@]}"}; do
      while IFS= read -r line; do
        case "$line" in
          "$match="*)
            assigned=1
            val=${line#*=}
            if [ -z "$val" ]; then
              out=""
            else
              case "$key" in
                User|Group|NoNewPrivileges|ProtectSystem|PrivateTmp|ProtectHome) out=$val;;
                ExecStart|ExecStartEx)
                  # Single-assignment key: a drop-in REPLACES the unit's
                  # ExecStart (systemd merge semantics), rendered exactly as
                  # real systemd reports it (prefix-free; see render_exec).
                  out=$(render_exec "$val" "$([ "$key" = "ExecStartEx" ] && printf 1 || printf 0)");;
                ExecStartPre|ExecStartPreEx)
                  # List key: one `{ ... }` group per command, space-joined —
                  # the REAL `systemctl show` shape (verified on the
                  # installed systemd 255.4). Prefixes NEVER survive into
                  # path=/argv[]=; the Ex form carries flags= instead.
                  grp=$(render_exec "$val" "$([ "$key" = "ExecStartPreEx" ] && printf 1 || printf 0)")
                  if [ -z "$out" ]; then out=$grp; else out="$out $grp"; fi;;
                *) out="$out $val";;
              esac
            fi;;
        esac
      done <"$f"
    done
    case "$key" in
      CapabilityBoundingSet)
        if [ "$assigned" = 0 ]; then out=$CAPS_V252; else out=$(render_caps "$out"); fi;;
      AmbientCapabilities) out=$(render_caps "$out");;
      IPAddressDeny|IPAddressAllow) out=$(render_ipprefixes "$out");;
    esac
    printf '%s\n' "${out# }";;
  daemon-reload)
    # Fault injection: FAKE_DAEMON_RELOAD_FAIL_FIRST=<n> fails the n-th
    # daemon-reload — a plain errexit failure right AFTER the new unit is
    # installed (the rollback's own reload is `|| true`).
    rl_file="${FAKE_SVC_LOG:?}.reload-count"
    rl=$(cat "$rl_file" 2>/dev/null || echo 0); rl=$((rl + 1)); echo "$rl" >"$rl_file"
    if [ "${FAKE_DAEMON_RELOAD_FAIL_FIRST:-0}" = "$rl" ]; then
      echo "Failed to reload daemon: injected fault" >&2; exit 1
    fi;;
  restart)
    printf 'restart %s\n' "$2" >>"${FAKE_SVC_LOG:?}"
    # Model restarts that fail exactly once (deploy restart fails, the
    # rollback restart succeeds) via FAKE_RESTART_FAIL_FIRST=<n>.
    cnt_file="${FAKE_SVC_LOG}.restart-count"
    cnt=$(cat "$cnt_file" 2>/dev/null || echo 0); cnt=$((cnt + 1)); echo "$cnt" >"$cnt_file"
    if [ "${FAKE_RESTART_FAIL_FIRST:-0}" = "$cnt" ]; then exit 1; fi
    # Incident 2026-10-09 model: a unit carrying a (non-empty) ExecStartPre
    # whose helper cannot run (imds-guard.sh -> `iptables: command not
    # found`, status=127) never reaches the main process: systemd reports
    # "Control process exited ... status=127", the restart job FAILS and the
    # unit sits in auto-restart. FAKE_EXECSTARTPRE_FAILS=1 applies that to
    # every restart of a unit (fragment or drop-in) that has an ExecStartPre.
    if [ "${FAKE_EXECSTARTPRE_FAILS:-0}" = 1 ] &&
      cat "$unit_file" "$dropdir"/*.conf 2>/dev/null | grep -q '^ExecStartPre=..*'; then
      printf 'restart-failed %s ExecStartPre status=127\n' "$2" >>"${FAKE_SVC_LOG:?}"
      echo activating >"$state_file"
      exit 1
    fi
    [ -n "${FAKE_RESTART_SLEEP:-}" ] && sleep "$FAKE_RESTART_SLEEP"
    # After a ROLLBACK restart the runtime process is correct again even when
    # the deploy's process was mis-modelled (FAKE_PROC_STATUS_BAD_UNTIL).
    if [ -n "${FAKE_PROC_STATUS_BAD_UNTIL:-}" ] && [ -n "${FAKE_PROC_STATUS_GOOD:-}" ] &&
      [ "$cnt" -gt "${FAKE_PROC_STATUS_BAD_UNTIL}" ]; then
      cp "$FAKE_PROC_STATUS_GOOD" "${FAKE_PROC_STATUS_FILE:?}"
    fi
    # A successful restart means the process is now the binary the symlink
    # points at. FAKE_STALE_EXE_ONCE=<n> models restart number n and later
    # NOT taking effect (the stale process keeps running the old release):
    # used to force deploy-health failure while the ROLLBACK restart (a later
    # call) updates the running identity. Default 0: every restart takes effect.
    if [ "${FAKE_STALE_EXE_ONCE:-0}" != "${cnt}" ]; then
      readlink -f "${BIN_LINK:?}" >"${FAKE_RUNNING_FILE:?}"
    fi
    echo active >"$state_file";;
  *) echo "stubctl: unknown args: $*" >&2; exit 64;;
esac
STUB

  cat >"$sb/bin/stubcurl" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "$*" >>"${FAKE_CURL_LOG:?}"
name=""; out="/dev/null"; url=""; prev=""
for a in "$@"; do
  [ "$prev" = "--resolve" ] && name="${a%%:*}"
  [ "$prev" = "-o" ] && out=$a
  case "$a" in https://*) url=$a;; esac
  prev=$a
done
# Transient-outage model: the first FAKE_FAIL_FIRST calls to any name listed
# in FAKE_FAIL_NAMES return 000 (connection failure), then recover.
if [ "${FAKE_FAIL_FIRST:-0}" -gt 0 ] 2>/dev/null &&
  case " ${FAKE_FAIL_NAMES:-} " in *" $name "*) true;; *) false;; esac; then
  cnt_file="${FAKE_CURL_LOG}.count-$name"
  failcnt=$(cat "$cnt_file" 2>/dev/null || echo 0); failcnt=$((failcnt + 1)); echo "$failcnt" >"$cnt_file"
  [ "$failcnt" -le "${FAKE_FAIL_FIRST}" ] && { printf '%s' "000"; exit 0; }
fi
code=$(grep -m1 "^$name " "${FAKE_HTTP_CODES:?}" 2>/dev/null | awk '{print $2}')
[ -n "$code" ] || code=$(grep -m1 '^\* ' "${FAKE_HTTP_CODES:?}" | awk '{print $2}')
# Activation model: a RELEASE binary (running path inside a version-mapped
# release dir) serves the real /healthz JSON with registry/tunnel postures
# and mounts the new API routes (anonymous identity -> 401, client-ssh ->
# 426). A LEGACY binary answers the frozen 426 everywhere and mounts
# nothing. FAKE_POSTURE / FAKE_TUNNEL_POSTURE model deactivated/failed
# postures; FAKE_ROUTE_404 models a binary that LIES in /healthz while the
# routes are actually unmounted (the wiring bug the route probes exist for).
running=$(cat "${FAKE_RUNNING_FILE:?}" 2>/dev/null)
ver=$(awk -v s="$(basename "$(dirname "$running")")" '$1 == s { print $2 }' "${FAKE_VERSION_MAP:?}" 2>/dev/null)
posture="${FAKE_POSTURE:-enabled}"
tposture="${FAKE_TUNNEL_POSTURE:-$posture}"
case "$url" in
  */healthz)
    if [ "$out" != "/dev/null" ]; then
      odir=$(dirname "$out")
      if [ ! -d "$odir" ]; then printf '%s' "000"; exit 0; fi # model curl: unwritable -o target fails
      if [ "${FAKE_NO_HEALTHZ:-0}" = "1" ]; then
        printf 'Upgrade Required\n' >"$out"; code=426
      elif [ -n "$ver" ]; then
        printf '{"service":"pocketshell-gateway","version":"%s","commit":"%s","status":"ok","registry":"%s","tunnel":"%s"}\n' \
          "${FAKE_HEALTHZ_VERSION:-$ver}" "${FAKE_HEALTHZ_COMMIT:-0000000000000000000000000000000000000000}" "$posture" "$tposture" >"$out"
        code=200
      else
        printf 'Upgrade Required\n' >"$out"; code=426
      fi
    fi;;
  */identity/v1/devices)
    if [ -n "$ver" ]; then
      [ "$posture" = "enabled" ] && code=401 || code=404
      [ "${FAKE_ROUTE_404:-0}" = "1" ] && code=404
    fi;; # legacy binary: keep the codes-file default (frozen 426)
  */api/v1/hosts/*)
    if [ -n "$ver" ]; then
      [ "$tposture" = "enabled" ] && code=426 || code=404
      [ "${FAKE_ROUTE_404:-0}" = "1" ] && code=404
    fi;;
esac
printf '%s' "${code:-000}"
STUB

  cat >"$sb/bin/stubaws" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
bucket_dir="${FAKE_BUCKET_DIR:?}"
key_of() { local u=$1; u="${u#s3://*/}"; printf '%s' "$u"; }
opt_of() { local want=$1 v=$2 prev=""; shift 2; for a in "$@"; do [ "$prev" = "$want" ] && v=$a; prev=$a; done; printf '%s' "$v"; }
case "$1 $2" in
  "s3 cp")
    src=$3 dst=$4
    case "$dst" in
      s3://*) mkdir -p "$bucket_dir/$(dirname "$(key_of "$dst")")"; cp "$src" "$bucket_dir/$(key_of "$dst")";;
      *) cp "$bucket_dir/$(key_of "$src")" "$dst";;
    esac;;
  "s3api put-object")
    key=$(opt_of --key "" "$@"); body=$(opt_of --body "" "$@")
    if [ -e "$bucket_dir/$key" ]; then
      echo "An error occurred (PreconditionFailed) when calling the PutObject operation: At least one of the pre-conditions did not pass" >&2
      exit 254
    fi
    mkdir -p "$bucket_dir/$(dirname "$key")"; cp "$body" "$bucket_dir/$key";;
  "s3api get-object")
    key=$(opt_of --key "" "$@"); out="${*: -1}"
    cp "$bucket_dir/$key" "$out";;
  "sts get-caller-identity") echo '{"Arn":"arn:aws:iam::000000000000:assumed-role/harness/session"}';;
  *) echo "stubaws: unknown args: $*" >&2; exit 64;;
esac
STUB

  cat >"$sb/bin/stubchown" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
. "${SB_MAPLIB:?}"
spec=""; paths=()
for a in "$@"; do
  case "$a" in
    -*) ;;
    *) if [ -z "$spec" ]; then spec=$a; else paths+=("$a"); fi;;
  esac
done
owner=${spec%%:*}
grp=''
case "$spec" in *:*) grp=${spec#*:};; esac
gid=''
if [ -n "$grp" ]; then
  # Model chown's user:group resolution: numeric ids pass through, group (or
  # user) names resolve to their numeric gid — user nobody's primary group
  # resolves the same way production's service:service pair would.
  gid=$(id -g -- "$grp" 2>/dev/null) || gid=$grp
  [ -n "$gid" ] || gid=$grp
fi
for p in ${paths[@]+"${paths[@]}"}; do
  # D23: descriptor-bound chowns arrive as /proc/<pid>/fd/<n>. The KERNEL
  # decides which inode they land on; the model records the effect keyed by
  # that object's REAL identity (dev:ino), so an fd-chown of a renamed or
  # unlinked inode can never be confused with whatever occupies the old
  # pathname now. An fd-path argument NEVER writes a path-keyed row (the
  # pathname of a magic link says nothing about the operated object); plain
  # pathname arguments also update the fixture-era path map.
  oid=$(obj_id "$p") || oid=''
  if [ -n "$oid" ]; then
    if [ -f "${OWNERSHIP_IDMAP:?}" ] && awk -F'\t' -v k="$oid" '$1 == k { found=1; exit } END { exit !found }' "$OWNERSHIP_IDMAP"; then
      map_tmp="${OWNERSHIP_IDMAP}.rewrite.$$"
      awk -F'\t' -v k="$oid" -v o="$owner" -v g="$gid" 'BEGIN { OFS = "\t" } $1 == k { print k, o, g; next } { print }' \
        "$OWNERSHIP_IDMAP" >"$map_tmp" && mv -f "$map_tmp" "$OWNERSHIP_IDMAP"
    else
      printf '%s\t%s\t%s\n' "$oid" "$owner" "$gid" >>"${OWNERSHIP_IDMAP:?}"
    fi
  fi
  case "$p" in /proc/[0-9]*/fd/[0-9]*) continue;; esac
  if [ -f "${OWNERSHIP_MAP:?}" ] && awk -F'\t' -v p="$p" '$1 == p { found=1; exit } END { exit !found }' "$OWNERSHIP_MAP"; then
    map_tmp="${OWNERSHIP_MAP}.rewrite.$$"
    awk -F'\t' -v p="$p" -v o="$owner" -v g="$gid" 'BEGIN { OFS = "\t" } $1 == p { print p, o, g; next } { print }' \
      "$OWNERSHIP_MAP" >"$map_tmp" && mv -f "$map_tmp" "$OWNERSHIP_MAP"
  else
    printf '%s\t%s\t%s\n' "$p" "$owner" "$gid" >>"${OWNERSHIP_MAP:?}"
  fi
done
# record for the audit trail ("runuser"-prefixed when invoked through the
# runuser stub, so root pathname ops stay distinguishable from the service's
# own-authority alignments) — WITH the object identity of every target, so
# assertions can pin the ACTUAL operated inode, not merely the argument
# pathname (an fd-based effect is visible by identity even when its path
# argument says something else).
oids=''
for p in ${paths[@]+"${paths[@]}"}; do
  oid=$(obj_id "$p") || oid=unknown
  oids="$oids[$oid]"
done
printf '%schown %s %s %s\n' "${FAKE_RUNAS_MARKER:+runuser }" "${oids:-unknown}" "$spec" "$*" >>"${FAKE_TOOL_LOG:?}"
STUB

  cat >"$sb/bin/stubchmod" <<'STUB'
#!/usr/bin/env bash
# REAL chmod (modes must be really applied for the byte/mode-preservation
# assertions; through a /proc/<pid>/fd/<n> magic link the kernel itself
# applies it to the OPENED inode) PLUS a recorded audit trail carrying the
# object identity of every target, so the harness can assert which INODES
# root chmod'ed (D23 confinement checks) — not merely which pathnames appear
# in the arguments. "runuser"-prefixed when invoked through the runuser stub
# (service authority, not root).
set -euo pipefail
. "${SB_MAPLIB:?}"
mode=''; paths=()
for a in "$@"; do
  case "$a" in
    -*) ;;
    *) if [ -z "$mode" ]; then mode=$a; else paths+=("$a"); fi;;
  esac
done
oids=''
for p in ${paths[@]+"${paths[@]}"}; do
  oid=$(obj_id "$p") || oid=unknown
  oids="$oids[$oid]"
done
printf '%schmod %s %s\n' "${FAKE_RUNAS_MARKER:+runuser }" "${oids:-unknown}" "$*" >>"${FAKE_TOOL_LOG:?}"
exec /bin/chmod "$@"
STUB

  cat >"$sb/bin/stubstat" <<'STUB'
#!/usr/bin/env bash
# stat(1) for the formats the installer uses. %U and %g consult the recorded
# chown effects — by OBJECT IDENTITY first (dev:ino from OWNERSHIP_IDMAP,
# written by stubchown), then the fixture-era path map — so recorded chowns
# behave like real ones for every downstream check. /proc/<pid>/fd/<n> is
# NEVER resolved to a pathname: the kernel's magic link is stat'ed DIRECTLY
# (-L), which reports the OPENED inode — the original one — even after the
# pathname was renamed or unlinked (D23 descriptor identity, kernel truth).
set -u
. "${SB_MAPLIB:?}"
fmt=$2 path=$3
case "$path" in
  /proc/[0-9]*/fd/[0-9]*)
    real=$(/usr/bin/stat -Lc "$fmt" "$path" 2>/dev/null) || exit 1
    oid=$(obj_id "$path") || oid=''
    mo=''; mg=''
    [ -z "$oid" ] || { mo=$(idmap_owner "$oid"); mg=$(idmap_gid "$oid"); }
    if [ -z "$mo" ] && [ -z "$mg" ]; then
      # Fixture-era ownership fallback: the KERNEL's readlink of the magic
      # link names the path the fd was opened on; a seeded row for that name
      # is an ownership statement about the OBJECT (kept verbatim — a
      # " (deleted)" name deliberately matches no seeded row, so an unlinked
      # object never inherits whatever occupies its old name). Type/dev/
      # inode/nlink/mode NEVER consult the name; neither do chown/chmod
      # effects (identity-keyed).
      tname=$(readlink "$path" 2>/dev/null) || tname=''
      if [ -n "$tname" ]; then mo=$(mapped_owner "$tname"); mg=$(mapped_gid "$tname"); fi
    fi
    if [ -n "$mo" ] || [ -n "$mg" ]; then
      case "$fmt" in
        '%F|%d|%i|%h|%a|%U|%g')
            IFS='|' read -r f1 f2 f3 f4 f5 fu fg <<<"$real"
            [ -n "$mo" ] || mo=$fu
            [ -n "$mg" ] || mg=$fg
            printf '%s|%s|%s|%s|%s|%s|%s\n' "$f1" "$f2" "$f3" "$f4" "$f5" "$mo" "$mg";;
        '%F|%i|%h|%a|%U|%g') # pre-dev record spelling (older audited source)
            IFS='|' read -r f1 f2 f3 f4 fu fg <<<"$real"
            [ -n "$mo" ] || mo=$fu
            [ -n "$mg" ] || mg=$fg
            printf '%s|%s|%s|%s|%s|%s\n' "$f1" "$f2" "$f3" "$f4" "$mo" "$mg";;
        '%U') printf '%s' "${mo:-$real}";;
        '%g') printf '%s' "${mg:-$real}";;
        '%U %g %a') rowner=$mo; [ -n "$rowner" ] || rowner=$(/usr/bin/stat -Lc '%U' "$path")
                    rgid=$mg; [ -n "$rgid" ] || rgid=$(/usr/bin/stat -Lc '%g' "$path")
                    printf '%s %s %s' "$rowner" "$rgid" "${real##* }";;
        *) printf '%s' "$real";;
      esac
    else
      printf '%s' "$real"
    fi
    exit 0;;
esac
real=$(/usr/bin/stat -c "$fmt" "$path" 2>/dev/null) || exit 1
oid=$(obj_id "$path") || oid=''
mo=''; mg=''
[ -z "$oid" ] || { mo=$(idmap_owner "$oid"); mg=$(idmap_gid "$oid"); }
mapped=$(mapped_owner "$path")
mgid=$(mapped_gid "$path")
[ -n "$mo" ] || mo=$mapped
[ -n "$mg" ] || mg=$mgid
if [ -n "$mo" ] || [ -n "$mg" ]; then
  rowner=$mo
  [ -n "$rowner" ] || rowner=$(/usr/bin/stat -c '%U' "$path")
  rgid=$mg
  [ -n "$rgid" ] || rgid=$(/usr/bin/stat -c '%g' "$path")
  case "$fmt" in
    '%U') printf '%s' "$rowner";;
    '%g') printf '%s' "$rgid";;
    '%U %a') printf '%s %s' "$rowner" "${real#* }";;
    '%U %g %a') printf '%s %s %s' "$rowner" "$rgid" "${real##* }";;
    '%F|%d|%i|%h|%a|%U|%g')
      IFS='|' read -r f1 f2 f3 f4 f5 fu fg <<<"$real"
      [ -n "$mo" ] || mo=$fu
      [ -n "$mg" ] || mg=$fg
      printf '%s|%s|%s|%s|%s|%s|%s\n' "$f1" "$f2" "$f3" "$f4" "$f5" "$mo" "$mg";;
    '%F|%i|%h|%a|%U|%g') # pre-dev record spelling (older audited source)
      IFS='|' read -r f1 f2 f3 f4 fu fg <<<"$real"
      [ -n "$mo" ] || mo=$fu
      [ -n "$mg" ] || mg=$fg
      printf '%s|%s|%s|%s|%s|%s\n' "$f1" "$f2" "$f3" "$f4" "$mo" "$mg";;
    *) printf '%s' "$real";;
  esac
else
  printf '%s' "$real"
fi
STUB

  cat >"$sb/bin/stubrunuser" <<'STUB'
#!/usr/bin/env bash
# models `runuser -u USER -- CMD...`: the runtime user's EFFECTIVE access.
set -u
. "${SB_MAPLIB:?}"
[ "$1" = "-u" ] || { echo "stubrunuser: usage" >&2; exit 64; }
user=$2; shift 2; [ "${1:-}" = "--" ] && shift
cmd=${1:-}; shift || true
if [ "$cmd" = /bin/sh ] && [ "${1:-}" = -c ] && [ "${3:-}" = gateway-authority-probe ]; then
  p=${4:-}
  if [ -z "${FAKE_AUTHORITY_PROBE_FAILURE_PATH:-}" ] || [ "$p" = "$FAKE_AUTHORITY_PROBE_FAILURE_PATH" ]; then
    case "${FAKE_AUTHORITY_PROBE_FAILURE:-}" in
      launch) exit 1;;
      empty) exit 0;;
      malformed) printf 'protected\nnoise\n'; exit 0;;
      wrong_uid) exit 3;;
    esac
  fi
  if "$0" -u "$user" -- test -w "$p"; then
    printf 'writable\n'
  else
    printf 'protected\n'
  fi
  exit 0
fi
if [ "$cmd" = "test" ] && [ "${1:-}" = "-w" ]; then
  p=${2:-}
  case " ${FAKE_RUNTIME_CAN_WRITE:-} " in *" $p "*) exit 0;; esac
  case " ${FAKE_RUNTIME_CANNOT_WRITE:-} " in *" $p "*) exit 1;; esac
  # kernel faccessat bit-model with the recorded ownership (identity first:
  # a chown effect recorded on the OBJECT governs, fixture path rows are the
  # fallback), then the mode bits as the only remaining grant
  mode=$(/usr/bin/stat -c '%a' "$p" 2>/dev/null) || exit 1
  owned=$(idmap_owner "$(obj_id "$p" 2>/dev/null)" 2>/dev/null) || owned=''
  [ -n "$owned" ] || owned=$(mapped_owner "$p")
  if [ "$owned" = "$user" ] && [ $((8#$mode & 8#200)) -ne 0 ]; then exit 0; fi
  [ $((8#$mode & 8#2)) -ne 0 ] && exit 0
  exit 1
fi
case "$cmd" in
  *imds-probe.sh) exit "${FAKE_RUNUSER_PROBE_RC:-0}";;
esac
# D23: the installer aligns runtime-leaf owner/mode AS THE SERVICE USER.
# Kernel model: a non-root chown/chmod succeeds ONLY on objects the user
# already owns — otherwise EPERM (exit 1). When allowed, the real recorder
# (stubchown for chown; real chmod for chmod) executes exactly as it would.
case "$cmd" in
  *chown)
    spec=${1:-}; shift || true
    [ -n "$spec" ] || { echo "stubrunuser: chown needs a spec" >&2; exit 64; }
    for p in "$@"; do
      # Kernel EPERM model, identity-keyed (D23): a non-root chown succeeds
      # ONLY on an object the user already owns. The object is identified by
      # its REAL dev:ino (so a replaced pathname is judged as the new object
      # it is); a fixture-seeded path row is the fallback for state the
      # fixture declared without a recorded chown.
      owned=$(idmap_owner "$(obj_id "$p" 2>/dev/null)" 2>/dev/null) || owned=''
      [ -n "$owned" ] || owned=$(mapped_owner "$p")
      [ "$owned" = "$user" ] ||
        { echo "runuser: chown: $p: EPERM (not owned by $user)" >&2; exit 1; }
    done
    FAKE_RUNAS_MARKER=1 exec "$cmd" "$spec" "$@";;
  *chmod)
    mode=${1:-}; shift || true
    [ -n "$mode" ] || { echo "stubrunuser: chmod needs a mode" >&2; exit 64; }
    for p in "$@"; do
      owned=$(idmap_owner "$(obj_id "$p" 2>/dev/null)" 2>/dev/null) || owned=''
      [ -n "$owned" ] || owned=$(mapped_owner "$p")
      [ "$owned" = "$user" ] ||
        { echo "runuser: chmod: $p: EPERM (not owned by $user)" >&2; exit 1; }
    done
    FAKE_RUNAS_MARKER=1 exec "$cmd" "$mode" "$@";;
esac
echo "stubrunuser: unknown args: $*" >&2
exit 64
STUB

  cat >"$sb/bin/stubsystemdrun" <<'STUB'
#!/usr/bin/env bash
# Transient-unit IMDS probes: a run carrying IPAddressDeny is the FILTERED
# strategy-A probe (FAKE_PROBE_RC, default 0 = refused); a run WITHOUT it is
# the unfiltered positive control (FAKE_CONTROL_RC, default 20 = IMDS answers
# and a token is obtainable without the filter — a healthy EC2 host).
printf '%s\n' "$*" >>"${FAKE_TOOL_LOG:?}"
case " $* " in
  *IPAddressDeny=*) exit "${FAKE_PROBE_RC:-0}";;
  *) exit "${FAKE_CONTROL_RC:-20}";;
esac
STUB

  # Strategy-B firewall tooling as imds-guard.sh resolves it (IMDS_GUARD_PATH
  # = $sb/guardbin). Records every call; -C reports "rule absent" until an -I
  # inserted it; -S lists the chain. FAKE_IPTABLES_BROKEN=1 models a present
  # but non-functional binary (no kernel tables).
  mkdir -p "$sb/guardbin"
  for t in iptables ip6tables; do
    cat >"$sb/guardbin/$t" <<'STUB'
#!/usr/bin/env bash
tool=${0##*/}
printf '%s %s\n' "$tool" "$*" >>"${FAKE_TOOL_LOG:?}"
[ "${FAKE_IPTABLES_BROKEN:-0}" = 1 ] && { echo "$tool: can't initialize table: Permission denied" >&2; exit 4; }
rules="${FAKE_TOOL_LOG}.$tool-rules"
args=" $* "
case "$args" in
  *" -S "*) printf -- '-P OUTPUT ACCEPT\n'; cat "$rules" 2>/dev/null; exit 0;;
  *" -C "*) grep -qxF -- "${args/ -C / -A }" "$rules" 2>/dev/null; exit $?;;
  *" -I "*) printf '%s\n' "${args/ -I OUTPUT 1 / -A OUTPUT }" >>"$rules"; exit 0;;
esac
echo "$tool: unsupported in harness: $*" >&2
exit 2
STUB
    chmod +x "$sb/guardbin/$t"
  done

  cat >"$sb/bin/stubgetent" <<'STUB'
#!/usr/bin/env bash
# models `getent passwd USER`: honours the "user does not exist yet" fixture
# (until stubuseradd has run) and a custom passwd line (shell-forcing test).
set -u
if [ "$1" = passwd ]; then
  if [ "${FAKE_GETENT_MISSING:-0}" = "1" ] && [ ! -e "${FAKE_USER_ADDED:?}" ]; then exit 2; fi
  if [ -e "${FAKE_USER_ADDED:?}" ]; then
    printf '%s\n' "$(cat "${FAKE_USER_ADDED:?}")"
    exit 0
  fi
  if [ -n "${FAKE_PASSWD_LINE:-}" ]; then printf '%s\n' "$FAKE_PASSWD_LINE"; exit 0; fi
fi
exec /usr/bin/getent "$@"
STUB

  cat >"$sb/bin/stubuseradd" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "useradd $*" >>"${FAKE_TOOL_LOG:?}"
n=$(cat "${FAKE_USERADDED_COUNT:?}" 2>/dev/null || echo 0); echo $((n + 1)) >"${FAKE_USERADDED_COUNT:?}"
printf '%s\n' "${FAKE_CREATED_LINE:-nothing:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin}" >"${FAKE_USER_ADDED:?}"
STUB

  cat >"$sb/bin/stubgroupadd" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "groupadd $*" >>"${FAKE_TOOL_LOG:?}"
STUB

  cat >"$sb/bin/stubusermod" <<'STUB'
#!/usr/bin/env bash
printf '%s\n' "usermod $*" >>"${FAKE_TOOL_LOG:?}"
# model the shell rewrite on the recorded passwd line
line=$(cat "${FAKE_USER_ADDED:?}" 2>/dev/null || printf '%s' "${FAKE_PASSWD_LINE:-}")
printf '%s\n' "$(printf '%s' "$line" | sed 's|[^:]*$|/usr/sbin/nologin|')" >"${FAKE_USER_ADDED:?}"
STUB

  cat >"$sb/bin/stubid" <<'STUB'
#!/usr/bin/env bash
# id(1) for the harness service user (nobody): models the correctly allocated
# account the installer creates in production (primary group = own name, no
# supplementary groups). Fixture modes override for refusal tests.
set -u
case "${FAKE_ID_MODE:-}" in
  uid0) case "$1" in -u) echo 0; exit 0;; esac;;
  dangerous)
    case "$1" in
      -nG) echo "${FAKE_USER_GROUPS:-nobody docker}"; exit 0;;
      -gn) echo nobody; exit 0;;
      -u) echo 65534; exit 0;;
      -g) echo 65534; exit 0;;
    esac;;
esac
case "$1" in
  -gn) shift; [ "${1:-}" = "nobody" ] && { echo nobody; exit 0; } ;;
  -nG) shift; [ "${1:-}" = "nobody" ] && { echo "${FAKE_USER_GROUPS:-nobody}"; exit 0; } ;;
esac
exec /usr/bin/id "$@"
STUB

  chmod +x "$sb/bin"/stubctl "$sb/bin/stubcurl" "$sb/bin/stubaws" "$sb/bin/stubchown" \
    "$sb/bin/stubstat" "$sb/bin/stubrunuser" "$sb/bin/stubsystemdrun" "$sb/bin/stubgetent" \
    "$sb/bin/stubuseradd" "$sb/bin/stubgroupadd" "$sb/bin/stubusermod" "$sb/bin/stubid" \
    "$sb/bin/stubchmod"
}

# --- sandbox -------------------------------------------------------------------
DEPLOY_BODY=$WORK/installer-body.sh
tail -1 "$INSTALLER" | grep -qx 'main "$@"' || { ko "installer must end with main \"\$@\""; finish; }
sed '$d' "$INSTALLER" >"$DEPLOY_BODY"

NEW_SB() {
  SB=$WORK/$1
  rm -rf "$SB"
  mkdir -p "$SB/bin" "$SB/tmp" "$SB/root/releases" "$SB/root/legacy" "$SB/unit" "$SB/state" "$SB/bucket" "$SB/dist" "$SB/helpers" "$SB/cert-base/certs"
  make_stubs "$SB"
  # The SSM document installs the IMDS helpers before the installer runs.
  cp "$ROOT/scripts/host/imds-probe.sh" "$ROOT/scripts/host/imds-guard.sh" "$SB/helpers/"
  export RELEASE_ROOT=$SB/root/releases
  export BIN_LINK=$SB/root/bin/pocketshell-relay
  export UNIT_DIR=$SB/unit
  export STATE_DIR=$SB/state
  export HELPERS_DIR=$SB/helpers
  # Canonical activation layout: CERT_CACHE is the -certdir BASE (root-only
  # ancestor); the autocert cache is its certs/ child — where the LEGACY
  # binary already keeps its cache (DirCache joins "/certs"), modeled here
  # with a pre-existing legacy cache file; REGISTRY_FILE is the Go-owned
  # state FILE (never pre-created by the installer).
  export CERT_CACHE=$SB/cert-base
  export CERT_DATA_DIR=$CERT_CACHE/certs
  export REGISTRY_DIR=$CERT_CACHE/registry
  export REGISTRY_FILE=$REGISTRY_DIR/devices.json
  export AWS_BIN=$SB/bin/stubaws
  export SYSTEMCTL=$SB/bin/stubctl
  export SYSTEMD_RUN=$SB/bin/stubsystemdrun
  # imds-guard.sh resolves iptables/ip6tables ONLY on this path (production
  # default: the fixed system sbin/bin path); the harness points it at the
  # recorded stubs, or at an EMPTY dir to model AL2023 (no iptables, no nft).
  export IMDS_GUARD_PATH=$SB/guardbin
  export RUNUSER_BIN=$SB/bin/stubrunuser
  export CURL_BIN=$SB/bin/stubcurl
  export SHA_BIN=sha256sum
  export GETENT_BIN=$SB/bin/stubgetent
  export USERADD_BIN=$SB/bin/stubuseradd
  export GROUPADD_BIN=$SB/bin/stubgroupadd
  export USERMOD_BIN=$SB/bin/stubusermod
  export CHOWN_BIN=$SB/bin/stubchown
  export CHMOD_BIN=$SB/bin/stubchmod
  export STAT_BIN=$SB/bin/stubstat
  export ID_BIN=$SB/bin/stubid
  export TMPDIR=$SB/tmp
  export LOCK_WAIT=8
  export SB_MAPLIB=$SB/bin/maplib.sh
  export OWNERSHIP_MAP=$SB/ownership.map
  # D23: chown/chmod EFFECTS are recorded per OBJECT identity (dev:ino), so
  # descriptor-bound operations stay bound to the operated inode across
  # rename/unlink instead of being re-attributed to whatever occupies the
  # reconstructed pathname.
  export OWNERSHIP_IDMAP=$SB/ownership-id.map
  : >"$OWNERSHIP_IDMAP"
  export FAKE_STATE_FILE=$SB/svc-state
  export FAKE_SVC_LOG=$SB/svc-calls
  export FAKE_CURL_LOG=$SB/curl-calls
  export FAKE_HTTP_CODES=$SB/http-codes
  export FAKE_VERSION_MAP=$SB/version-map
  export FAKE_BUCKET_DIR=$SB/bucket
  export FAKE_MAIN_PID=555
  export FAKE_SERVICE=pocketshell-relay
  export FAKE_TOOL_LOG=$SB/tool-calls
  export FAKE_USER_ADDED=$SB/user-added
  export FAKE_USERADDED_COUNT=$SB/useradded-count
  export TRUST_OWNER TRUST_GROUP_ID TRUST_BASE
  TRUST_OWNER=$(id -un)
  TRUST_GROUP_ID=$(id -g)
  TRUST_BASE=$SB
  # What the "running process" is, per the restart model in stubctl.
  export FAKE_RUNNING_FILE=$SB/running-exe
  printf '%s' "$BIN_LINK" >"$FAKE_RUNNING_FILE" # pre-deploy: legacy regular file
  # Runtime process credential model: nobody (uid/gid 65534) with exactly the
  # CAP_NET_BIND_SERVICE bit the unit configures.
  NOBODY_UID=$(id -u nobody)
  export NOBODY_UID
  export FAKE_PROC_STATUS_FILE=$SB/proc-status
  export FAKE_PROC_STATUS_GOOD=$SB/proc-status-good
  write_proc_status "$FAKE_PROC_STATUS_FILE" "$NOBODY_UID"
  cp "$FAKE_PROC_STATUS_FILE" "$FAKE_PROC_STATUS_GOOD"
  # Legacy autocert state: pre-existing files in the certs/ cache directory
  # (the legacy binary's DirCache location) must be chowned to the runtime
  # user by the migration, byte-preserved.
  printf 'legacy cert state\n' >"$CERT_DATA_DIR/legacy-cert.json"
  : >"$FAKE_VERSION_MAP"
  unset FAKE_RESTART_FAIL_FIRST FAKE_RESTART_SLEEP FAKE_STALE_EXE_ONCE FAKE_FAIL_FIRST FAKE_FAIL_NAMES
  unset FAKE_CONTROL_RC FAKE_EXECSTARTPRE_FAILS FAKE_IPTABLES_BROKEN FAKE_DAEMON_RELOAD_FAIL_FIRST
  unset FAKE_PROBE_RC FAKE_RUNUSER_PROBE_RC FAKE_RUNTIME_CAN_WRITE FAKE_RUNTIME_CANNOT_WRITE FAKE_AUTHORITY_PROBE_FAILURE FAKE_AUTHORITY_PROBE_FAILURE_PATH
  unset FAKE_GETENT_MISSING FAKE_PASSWD_LINE FAKE_CREATED_LINE FAKE_ID_MODE FAKE_USER_GROUPS
  unset FAKE_LEGACY_ROOT FAKE_NO_HEALTHZ FAKE_HEALTHZ_VERSION FAKE_HEALTHZ_COMMIT FAKE_PROC_STATUS_BAD_UNTIL
  unset FAKE_EXECSTARTEX_RAW FAKE_EXECSTARTPREEX_RAW
  unset FAKE_POSTURE FAKE_TUNNEL_POSTURE FAKE_ROUTE_404
  unset FAKE_RUNAS_MARKER
  echo active >"$FAKE_STATE_FILE"
  printf '* 426\ngateway.pocketshell.io 426\nrelay.pocketshell.io 426\n' >"$FAKE_HTTP_CODES"
  : >"$FAKE_SVC_LOG"
  : >"$FAKE_CURL_LOG"
  : >"$FAKE_TOOL_LOG"
}

write_proc_status() { # $1 = file, $2 = uid
  { printf 'Name:\tpocketshell-gateway\n'
    printf 'Uid:\t%s\t%s\t%s\t%s\n' "$2" "$2" "$2" "$2"
    printf 'Gid:\t%s\t%s\t%s\t%s\n' "$2" "$2" "$2" "$2"
    printf 'CapInh:\t0000000000000000\n'
    printf 'CapPrm:\t0000000000000400\n'
    printf 'CapEff:\t0000000000000400\n'
    printf 'CapBnd:\t0000000000000400\n'
    printf 'CapAmb:\t0000000000000400\n'; } >"$1"
}

# Seed the legacy world exactly as the current stack has it: a REGULAR legacy
# binary at the bin link and a unit with -domain plus unrelated arguments.
LEGACY_UNIT_TEMPLATE='[Unit]
Description=PocketShell dumb relay (WebSocket to TCP)

[Service]
ExecStart=__BIN_LINK__ -domain relay.pocketshell.io -client-id cid-123 -allow a@b.c -staging
Restart=always

[Install]
WantedBy=multi-user.target
'

seed_legacy() {
  mkdir -p "$(dirname "$BIN_LINK")" "$UNIT_DIR" "$STATE_DIR"
  cp "$WORK/legacy-bin" "$BIN_LINK"
  chmod 0755 "$BIN_LINK"
  printf '%s' "${LEGACY_UNIT_TEMPLATE//__BIN_LINK__/$BIN_LINK}" >"$UNIT_DIR/pocketshell-relay.service"
}

# Load the installer body the way SSM does and invoke main with the
# document's parameter set ($@ = main's arguments).
RUN_NO=0
# Shared by the R1/D21 parser regression blocks: runs assertions in a
# subshell against the body's functions (defined once, before first use).
source_tests() {
  (source "$DEPLOY_BODY"
   set +e # refusal RETURN codes must be observable, not fatal (the body sets -e)
   # shellcheck disable=SC2034  # consumed by the sourced body's systemd_prop
   SERVICE=pocketshell-relay
   UNIT_FILE=$UNIT_DIR/pocketshell-relay.service
   SERVICE_USER=nobody
   systemctl_stub() { case "$1" in FragmentPath) printf '%s\n' "$UNIT_FILE";; DropInPaths) printf '%s\n' "${R1_DROPINS:-}";; esac; }
   eval "$1")
}
# The SSM envelope runs the decoded body as a TOP-LEVEL script
# (`/bin/bash "$payload" ...`), with `main "$@"` as its last line. That
# matters: when errexit fires inside a function at top level, bash unwinds the
# function frames — main's locals included — BEFORE the EXIT trap runs,
# whereas in a ( subshell ) the trap still sees them. The pre-fix harness ran
# main inside a subshell and so masked the 2026-10-09 rollback failure
# ("deploy.sh: line 1931: unit_installed: unbound variable"). The runner
# below is a real top-level bash process: source the body, apply the
# kernel/systemd seams, call main at top level.
RUN_MAIN=$WORK/run-main.sh
cat >"$RUN_MAIN" <<'RUNNER'
# shellcheck disable=SC1090,SC2154  # body path + harness env are fixed by the harness
source "${DEPLOY_BODY:?}"
running_exe() { cat "${FAKE_RUNNING_FILE:?}"; }
proc_status() {
  if [ "${FAKE_LEGACY_ROOT:-0}" = 1 ] && [ -z "$(systemd_prop User)" ]; then
    # Legacy no-User unit runs as root; never seed it with the new service UID.
    sed -e 's/^Uid:.*/Uid: 0 0 0 0/' -e 's/^Gid:.*/Gid: 0 0 0 0/' "$FAKE_PROC_STATUS_FILE"
    printf 'legacy-root\n' >>"${SB:?}/legacy-root-witness"
  else
    cat "${FAKE_PROC_STATUS_FILE:?}"
  fi
}
# Regression seam (R1 fidelity): FAKE_EXECSTARTEX_RAW /
# FAKE_EXECSTARTPREEX_RAW force RAW property shapes and invented
# serializations (prefix-preserving groups, unknown fields, trailing
# junk) for the flags-aware properties the audit consults — what a lying
# stub or non-systemd tooling returns. The audit must refuse them: real
# systemd never emits these, and accepting them would mean the audit was
# never actually looking at systemd's answer.
systemd_prop() {
  case "$1" in
    ExecStartEx)
      [ -n "${FAKE_EXECSTARTEX_RAW:-}" ] && { printf '%s\n' "$FAKE_EXECSTARTEX_RAW"; return; };;
    ExecStartPreEx)
      [ -n "${FAKE_EXECSTARTPREEX_RAW:-}" ] && { printf '%s\n' "$FAKE_EXECSTARTPREEX_RAW"; return; };;
  esac
  "$SYSTEMCTL" show -p "$1" --value "$SERVICE"
}
main "$@"
RUNNER
run_deploy() { RUN_NO=$((RUN_NO + 1))
  printf '\n===== run %d =====\n' "$RUN_NO" >>"$SB/deploy-out.txt"
  DEPLOY_BODY=$DEPLOY_BODY SB=$SB /bin/bash "$RUN_MAIN" "$@" >>"$SB/deploy-out.txt" 2>>"$SB/deploy-err.txt"
}

deploy_args() { # $1=archive-sha $2=binary-sha $3=version
  printf '%s' "--bucket fake-bucket --artifact-path artifacts/$1/gateway-linux-arm64.gz --archive-sha256 $1 --binary-sha256 $2 --version $3 --revision $REVISION_FIXTURE --domain gateway.pocketshell.io --aliases relay.pocketshell.io --service pocketshell-relay --service-user nobody --health-timeout 5 --certdir $CERT_CACHE --registry $REGISTRY_FILE"
}

publish_fixture() { # $1=gz $2=binary-digest $3=version
  local gz=$1 bsha=$2 ver=$3 sha
  sha=$(sha_file "$gz")
  local d="$FAKE_BUCKET_DIR/artifacts/$sha"
  mkdir -p "$d"
  cp "$gz" "$d/gateway-linux-arm64.gz"
  printf '%s\n' "$ver" >"$d/VERSION"
  write_manifest "$d" "$sha" "$bsha" "$ver"
  printf '%s %s\n' "$sha" "$ver" >>"$FAKE_VERSION_MAP"
}

# --- build fixtures -------------------------------------------------------------
note "building real cross-compile fixtures"
build_fixture "$WORK/hello-arm64-a" arm64 releaseA
build_fixture "$WORK/hello-arm64-b" arm64 releaseB
build_fixture "$WORK/hello-arm64-c" arm64 releaseC
build_fixture "$WORK/hello-amd64" amd64 amd64Impostor
cp "$WORK/hello-amd64" "$WORK/legacy-bin"
A_SHA=$(archive_of "$WORK/hello-arm64-a" "$WORK/a.gz" && sha_file "$WORK/a.gz")
A_BSHA=$(sha_file "$WORK/hello-arm64-a")
B_SHA=$(archive_of "$WORK/hello-arm64-b" "$WORK/b.gz" && sha_file "$WORK/b.gz")
B_BSHA=$(sha_file "$WORK/hello-arm64-b")
C_SHA=$(archive_of "$WORK/hello-arm64-c" "$WORK/c.gz" && sha_file "$WORK/c.gz")
C_BSHA=$(sha_file "$WORK/hello-arm64-c")
LEGACY_SHA=$(sha_file "$WORK/legacy-bin")

# =====================================================================================
NEW_SB t1_happy_first_migration
seed_legacy
sed -i '/^\[Service\]$/a Type=forking\nPIDFile=/run/pocketshell-relay.pid\nGuessMainPID=yes' "$UNIT_DIR/pocketshell-relay.service"
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t1 exit 0" 0 $?
assert_eq "t1 foreground startup Type" exec "$(sed -n 's/^Type=//p' "$UNIT_DIR/pocketshell-relay.service")"
assert_eq "t1 stale PIDFile cleared" '' "$(sed -n 's/^PIDFile=//p' "$UNIT_DIR/pocketshell-relay.service")"
assert_eq "t1 main PID guessing disabled" no "$(sed -n 's/^GuessMainPID=//p' "$UNIT_DIR/pocketshell-relay.service")"
assert_contains "t1 health=ok" "health=ok" "$SB/deploy-out.txt"
assert_contains "t1 rollback=none" "rollback=none" "$SB/deploy-out.txt"
assert_contains "t1 healthz=ok (application version verified)" "healthz=ok" "$SB/deploy-out.txt"
assert_contains "t1 imds=systemd" "imds=systemd" "$SB/deploy-out.txt"
assert_eq "t1 bin link is symlink to release" "$RELEASE_ROOT/$A_SHA/pocketshell-gateway" "$(readlink "$BIN_LINK")"
assert_eq "t1 legacy preserved (hash)" "$LEGACY_SHA" "$(sha_file "$STATE_DIR/legacy/pocketshell-relay")"
assert_eq "t1 legacy preserved (layout)" "regular" "$([ -L "$STATE_DIR/legacy/pocketshell-relay" ] && echo symlink || echo regular)"
assert_eq "t1 execstart rewritten+preserved" \
  "$BIN_LINK -client-id cid-123 -allow a@b.c -staging -domain gateway.pocketshell.io -aliases relay.pocketshell.io -certdir $CERT_CACHE -registry $REGISTRY_FILE" \
  "$(execstart_of "$UNIT_DIR/pocketshell-relay.service")"
U=$UNIT_DIR/pocketshell-relay.service
assert_eq "t1 unit User=" "nobody" "$(unit_value User "$U")"
assert_eq "t1 unit Group=" "nobody" "$(unit_value Group "$U")"
assert_eq "t1 unit NoNewPrivileges" "yes" "$(unit_value NoNewPrivileges "$U")"
assert_eq "t1 unit ProtectSystem" "strict" "$(unit_value ProtectSystem "$U")"
assert_eq "t1 unit PrivateTmp" "yes" "$(unit_value PrivateTmp "$U")"
assert_eq "t1 unit CapabilityBoundingSet" "CAP_NET_BIND_SERVICE" "$(unit_value CapabilityBoundingSet "$U")"
assert_eq "t1 unit AmbientCapabilities" "CAP_NET_BIND_SERVICE" "$(unit_value AmbientCapabilities "$U")"
assert_eq "t1 unit IPAddressDeny both endpoints" "169.254.169.254 fd00:ec2::254" "$(unit_value IPAddressDeny "$U")"
assert_eq "t1 unit ReadWritePaths is exactly the two canonical leaves" "$CERT_DATA_DIR $REGISTRY_DIR" "$(unit_value ReadWritePaths "$U")"
grep -qF -- "$CERT_CACHE " <<<"$(unit_value ReadWritePaths "$U")" &&
  ko "t1 ReadWritePaths must NOT contain the root-only base" ||
  ok "t1 ReadWritePaths must NOT contain the root-only base"
[ -z "$(unit_value ExecStartPre "$U")" ] && ok "t1 no ExecStartPre in systemd strategy" || ko "t1 no ExecStartPre in systemd strategy"
grep -q "^CURRENT_SHA=$A_SHA$" "$STATE_DIR/deploy-state" && ok "t1 state CURRENT_SHA=A" || ko "t1 state CURRENT_SHA=A"
grep -q "^CURRENT_BINARY_SHA=$A_BSHA$" "$STATE_DIR/deploy-state" && ok "t1 state CURRENT_BINARY_SHA" || ko "t1 state CURRENT_BINARY_SHA"
grep -qF -- "-k " "$FAKE_CURL_LOG" && ko "t1 curl never uses -k" || ok "t1 curl never uses -k"
grep -q -- "--resolve gateway.pocketshell.io:443:127.0.0.1" "$FAKE_CURL_LOG" && ok "t1 canonical probed" || ko "t1 canonical probed"
grep -q -- "--resolve relay.pocketshell.io:443:127.0.0.1" "$FAKE_CURL_LOG" && ok "t1 alias probed" || ko "t1 alias probed"
grep -q -- "/healthz" "$FAKE_CURL_LOG" && ok "t1 healthz endpoint queried" || ko "t1 healthz endpoint queried"
grep -qE '\-o /healthz[.]body' "$FAKE_CURL_LOG" && ko "t1 no stray healthz body at filesystem root" || ok "t1 no stray healthz body at filesystem root"
grep -q '^chown' "$FAKE_TOOL_LOG" && ok "t1 cert cache chowned to runtime user" || ko "t1 cert cache chowned to runtime user"
# Activation contract on the FIRST migration (old deployed unit -> activated):
# route probes ran and were auth-rejected (never 404), the result lines name
# both enabled postures, and the ledger records the activated release.
grep -q -- "/identity/v1/devices" "$FAKE_CURL_LOG" && ok "t1 identity route probed" || ko "t1 identity route probed"
grep -q -- "/api/v1/hosts/" "$FAKE_CURL_LOG" && ok "t1 tunnel route probed" || ko "t1 tunnel route probed"
assert_contains "t1 registry=enabled result line" "registry=enabled" "$SB/deploy-out.txt"
assert_contains "t1 tunnel=enabled result line" "tunnel=enabled" "$SB/deploy-out.txt"
assert_contains "t1 route rejection verified" "activation routes verified" "$SB/deploy-out.txt"
grep -q "^CURRENT_ACTIVATION=1$" "$STATE_DIR/deploy-state" && ok "t1 state records activation" || ko "t1 state records activation"

# =====================================================================================
NEW_SB t2_ab_failc_rolls_back_to_b
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
publish_fixture "$WORK/b.gz" "$B_BSHA" git-B
publish_fixture "$WORK/c.gz" "$C_BSHA" git-C
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t2 deploy A exit 0" 0 $?
run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B)
assert_eq "t2 deploy B exit 0" 0 $?
grep -q "^CURRENT_SHA=$B_SHA$" "$STATE_DIR/deploy-state" && ok "t2 state CURRENT=B" || ko "t2 state CURRENT=B"
# D5 ledger shift: after a successful B, PREVIOUS is the pre-deploy CURRENT (A)
grep -q "^PREVIOUS_SHA=$A_SHA$" "$STATE_DIR/deploy-state" && ok "t2 success shifts PREVIOUS to A" || ko "t2 success shifts PREVIOUS to A"
# Deploy C: service comes up but the running exe identity is wrong (simulated
# stale/foreign process) -> health fails -> rollback to B and its unit.
export FAKE_STALE_EXE_ONCE=3 # restart #3 is deploy C: stale process keeps running B
run_deploy $(deploy_args "$C_SHA" "$C_BSHA" git-C)
assert_eq "t2 deploy C exit 0 (rollback=ok)" 0 $?
assert_contains "t2 rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
assert_contains "t2 health=failed" "health=failed" "$SB/deploy-out.txt"
assert_eq "t2 bin link restored to B" "$RELEASE_ROOT/$B_SHA/pocketshell-gateway" "$(readlink "$BIN_LINK")"
assert_eq "t2 execstart is B-era" \
  "$BIN_LINK -client-id cid-123 -allow a@b.c -staging -domain gateway.pocketshell.io -aliases relay.pocketshell.io -certdir $CERT_CACHE -registry $REGISTRY_FILE" \
  "$(execstart_of "$UNIT_DIR/pocketshell-relay.service")"
grep -q "^CURRENT_SHA=$B_SHA$" "$STATE_DIR/deploy-state" && ok "t2 rolled-back state CURRENT=B" || ko "t2 rolled-back state CURRENT=B"
grep -q "^PREVIOUS_SHA=$C_SHA$" "$STATE_DIR/deploy-state" && ok "t2 rolled-back state PREVIOUS=C" || ko "t2 rolled-back state PREVIOUS=C"
# A retry of C (the restart takes effect this time) must ledger-shift from
# the pre-retry CURRENT (B) — never from the earlier failed attempt's entry.
run_deploy $(deploy_args "$C_SHA" "$C_BSHA" git-C)
assert_eq "t2 C retry exit 0 (succeeds now)" 0 $?
grep -q "^CURRENT_SHA=$C_SHA$" "$STATE_DIR/deploy-state" && ok "t2 retry records CURRENT=C" || ko "t2 retry records CURRENT=C"
grep -q "^PREVIOUS_SHA=$B_SHA$" "$STATE_DIR/deploy-state" && ok "t2 retry shifts PREVIOUS to pre-retry CURRENT (B), not the stale failed entry" || ko "t2 retry shifts PREVIOUS to B (no poisoning)"

# =====================================================================================
NEW_SB t3_failed_first_migration_restores_legacy
seed_legacy
sed -i '/^\[Service\]$/a Type=notify\nPIDFile=/run/pocketshell-relay.pid\nGuessMainPID=yes' "$UNIT_DIR/pocketshell-relay.service"
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/legacy-unit.orig"
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_STALE_EXE_ONCE=1 # deploy restart does not take effect
export FAKE_NO_HEALTHZ=1     # rollback health is legacy-only
export FAKE_LEGACY_ROOT=1    # root BEFORE migration and AFTER restoring the saved legacy unit
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t3 exit 0 (rollback=ok)" 0 $?
assert_contains "t3 rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
[ "$(wc -l <"$SB/legacy-root-witness")" -ge 2 ] && ok "t3 original and restored legacy root credentials audited" || ko "t3 missing original/restored root witness"
assert_contains "t3 rollback reported as legacy (no version claim)" "healthz=legacy" "$SB/deploy-out.txt"
assert_eq "t3 legacy copy hash" "$LEGACY_SHA" "$(sha_file "$STATE_DIR/legacy/pocketshell-relay")"
assert_eq "t3 bin link serves legacy copy" "$STATE_DIR/legacy/pocketshell-relay" "$(readlink "$BIN_LINK")"
assert_eq "t3 unit restored byte-identical" "$(cat "$SB/legacy-unit.orig")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"
grep -q "^CURRENT_SHA=legacy$" "$STATE_DIR/deploy-state" && ok "t3 state CURRENT=legacy" || ko "t3 state CURRENT=legacy"
grep -q "^PREVIOUS_SHA=$A_SHA$" "$STATE_DIR/deploy-state" && ok "t3 state PREVIOUS=A" || ko "t3 state PREVIOUS=A"

# A second failed deployment must consume the ledger actually emitted above,
# not a hand-seeded approximation or the failed PREVIOUS release.
legacy_test_ledger="$STATE_DIR/deploy-state"
legacy_test_unit="$UNIT_DIR/pocketshell-relay.service"
cp "$legacy_test_ledger" "$SB/first-legacy-ledger"
export FAKE_STALE_EXE_ONCE=3 # retry deploy restart; rollback restart4 restores legacy
publish_fixture "$WORK/b.gz" "$B_BSHA" git-B
legacy_test_start=$(wc -l <"$SB/deploy-out.txt")
run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B)
legacy_test_retry_rc=$?
tail -n "+$((legacy_test_start + 1))" "$SB/deploy-out.txt" >"$SB/legacy-retry-out.txt"
assert_eq "t3 retry exit0 restores same legacy" 0 "$legacy_test_retry_rc"
assert_contains "t3 retry fresh rollback=ok" "rollback=ok" "$SB/legacy-retry-out.txt"
assert_contains "t3 retry fresh healthz=legacy" "healthz=legacy" "$SB/legacy-retry-out.txt"
assert_eq "t3 retry exact original unit" "$(cat "$SB/legacy-unit.orig")" "$(cat "$legacy_test_unit")"
assert_eq "t3 retry exact original executable" "$LEGACY_SHA" "$(sha_file "$BIN_LINK")"
grep -q '^CURRENT_SHA=legacy$' "$legacy_test_ledger" && ok "t3 retry CURRENT remains legacy" || ko "t3 retry CURRENT remains legacy"
grep -q "^PREVIOUS_SHA=$B_SHA$" "$legacy_test_ledger" && ok "t3 retry PREVIOUS is latest failed B" || ko "t3 retry PREVIOUS is latest failed B"

# Canonical legacy sentinel cannot bless an arbitrary/activated/new target.
cp "$legacy_test_ledger" "$SB/second-legacy-ledger"
for legacy_test_bad in release activation binary sentinel; do
  cp "$SB/second-legacy-ledger" "$legacy_test_ledger"
  case "$legacy_test_bad" in
    release) sed -i "s|^CURRENT_RELEASE=.*|CURRENT_RELEASE=$STATE_DIR/legacy/arbitrary|" "$legacy_test_ledger";;
    activation) sed -i 's/^CURRENT_ACTIVATION=.*/CURRENT_ACTIVATION=1/' "$legacy_test_ledger";;
    binary) sed -i "s/^CURRENT_BINARY_SHA=.*/CURRENT_BINARY_SHA=$B_BSHA/" "$legacy_test_ledger";;
    sentinel) sed -i "s/^CURRENT_SHA=.*/CURRENT_SHA=$B_SHA/" "$legacy_test_ledger";;
  esac
  legacy_test_restarts=$(wc -l <"$FAKE_SVC_LOG")
  run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B)
  [ $? -ne 0 ] && ok "t3 forged legacy ledger $legacy_test_bad refused" || ko "t3 forged legacy ledger $legacy_test_bad refused"
  assert_eq "t3 forged legacy ledger $legacy_test_bad no restart" "$legacy_test_restarts" "$(wc -l <"$FAKE_SVC_LOG")"
done
cp "$SB/second-legacy-ledger" "$legacy_test_ledger"

# =====================================================================================
NEW_SB t4_repeated_deploy_idempotent
seed_legacy
sed -i '/^\[Service\]$/a Type=notify\nPIDFile=/run/pocketshell-relay.pid\nGuessMainPID=yes' "$UNIT_DIR/pocketshell-relay.service"
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t4 first exit 0" 0 $?
E1=$(execstart_of "$UNIT_DIR/pocketshell-relay.service")
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t4 second exit 0" 0 $?
assert_eq "t4 foreground startup Type" exec "$(sed -n 's/^Type=//p' "$UNIT_DIR/pocketshell-relay.service")"
assert_eq "t4 stale PIDFile cleared" '' "$(sed -n 's/^PIDFile=//p' "$UNIT_DIR/pocketshell-relay.service")"
assert_eq "t4 main PID guessing disabled" no "$(sed -n 's/^GuessMainPID=//p' "$UNIT_DIR/pocketshell-relay.service")"
E2=$(execstart_of "$UNIT_DIR/pocketshell-relay.service")
assert_eq "t4 execstart stable" "$E1" "$E2"
[ "$(grep -o -- '-aliases' <<<"$E2" | wc -l)" = "1" ] && ok "t4 exactly one -aliases" || ko "t4 exactly one -aliases (got: $E2)"
[ "$(grep -o -- '-domain' <<<"$E2" | wc -l)" = "1" ] && ok "t4 exactly one -domain" || ko "t4 exactly one -domain"
[ "$(cat "$FAKE_USERADDED_COUNT" 2>/dev/null || echo 0)" = "0" ] &&
  ok "t4 existing user found via getent (no useradd)" ||
  ko "t4 existing user found via getent (no useradd)"

# =====================================================================================
NEW_SB t5_concurrent_deploys_serialize
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
publish_fixture "$WORK/b.gz" "$B_BSHA" git-B
export FAKE_RESTART_SLEEP=2
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A) &
pidA=$!
# Wait until A HOLDS the lock (it logs "deploy requested" only after flock),
# so the second deploy's refusal is deterministic even on a loaded machine.
for _ in $(seq 1 200); do
  grep -q "deploy requested" "$SB/deploy-out.txt" 2>/dev/null && break
  sleep 0.1
done
LOCK_WAIT=1 run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B) &
pidB=$!
wait $pidA
rcA=$?
wait $pidB
rcB=$?
assert_eq "t5 first deploy (lock holder) exit 0" 0 "$rcA"
[ "$rcB" != "0" ] && ok "t5 second deploy refused while locked" || ko "t5 second deploy refused while locked"
assert_contains "t5 lock refusal message" "holds the lock" "$SB/deploy-err.txt"

# =====================================================================================
NEW_SB t6_interrupted_deploy_recovers
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_RESTART_SLEEP=2
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A) &
pidK=$!
sleep 0.8
# Kill the deploy SUBSHELL (run_deploy's child), not just the function
# wrapper — kill -9 on the wrapper alone would leave the inner deploy
# running as an orphan, holding the lock (a harness artifact, not a
# property of the installer; SSM kills the whole script).
pkill -9 -P "$pidK" 2>/dev/null || true
kill -9 "$pidK" 2>/dev/null || true
wait "$pidK" 2>/dev/null
[ "$(grep -c '^ExecStart=' "$UNIT_DIR/pocketshell-relay.service")" = "1" ] &&
  ok "t6 unit has exactly one ExecStart after interruption" ||
  ko "t6 unit has exactly one ExecStart after interruption"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t6 rerun after interruption exit 0" 0 $?
assert_eq "t6 bin link correct after recovery" "$RELEASE_ROOT/$A_SHA/pocketshell-gateway" "$(readlink "$BIN_LINK")"
grep -q "^CURRENT_SHA=$A_SHA$" "$STATE_DIR/deploy-state" && ok "t6 state CURRENT=A after recovery" || ko "t6 state CURRENT=A after recovery"

# =====================================================================================
NEW_SB t7_wrong_archive_digest_rejected
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A) >/dev/null 2>&1
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
# Publish B's payload under B's key but claim A's digest in the path/params.
run_deploy --bucket fake-bucket --artifact-path "artifacts/$A_SHA/gateway-linux-arm64.gz" \
  --archive-sha256 "$A_SHA" --binary-sha256 "$B_BSHA" --version git-A --revision "$REVISION_FIXTURE" \
  --domain gateway.pocketshell.io --aliases relay.pocketshell.io \
  --service pocketshell-relay --service-user nobody --health-timeout 5 --certdir "$CERT_CACHE" --registry "$REGISTRY_FILE"
assert_eq "t7 digest/path confusion rejected" 1 $?
assert_eq "t7 unit untouched" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"
assert_eq "t7 bin link untouched" "$RELEASE_ROOT/$A_SHA/pocketshell-gateway" "$(readlink "$BIN_LINK")"

# =====================================================================================
NEW_SB t8_amd64_impostor_rejected
seed_legacy
mkdir -p "$FAKE_BUCKET_DIR/artifacts/$A_SHA"
archive_of "$WORK/hello-amd64" "$WORK/amd64.gz"
cp "$WORK/amd64.gz" "$FAKE_BUCKET_DIR/artifacts/$A_SHA/gateway-linux-arm64.gz"
printf 'git-A\n' >"$FAKE_BUCKET_DIR/artifacts/$A_SHA/VERSION"
write_manifest "$FAKE_BUCKET_DIR/artifacts/$A_SHA" "$A_SHA" "$(sha_file "$WORK/hello-amd64")" git-A
run_deploy $(deploy_args "$A_SHA" "$(sha_file "$WORK/hello-amd64")" git-A)
assert_eq "t8 amd64 payload rejected" 1 $?
[ ! -L "$BIN_LINK" ] && ok "t8 no symlink swap happened" || ko "t8 no symlink swap happened"

# =====================================================================================
NEW_SB t9_corrupt_gzip_rejected
seed_legacy
mkdir -p "$FAKE_BUCKET_DIR/artifacts/$A_SHA"
head -c 200 "$WORK/a.gz" >"$FAKE_BUCKET_DIR/artifacts/$A_SHA/gateway-linux-arm64.gz"
printf 'git-A\n' >"$FAKE_BUCKET_DIR/artifacts/$A_SHA/VERSION"
write_manifest "$FAKE_BUCKET_DIR/artifacts/$A_SHA" "$A_SHA" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t9 corrupt gzip rejected" 1 $?

# =====================================================================================
NEW_SB t10_injection_attempts_rejected
seed_legacy
mkdir -p "$SB/canary"
touch "$SB/canary/keepme"
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy --bucket fake-bucket --artifact-path "artifacts/$A_SHA/gateway-linux-arm64.gz" \
  --archive-sha256 "$A_SHA" --binary-sha256 "$A_BSHA" --version git-A --revision "$REVISION_FIXTURE" \
  --domain 'gateway.pocketshell.io;rm -rf /tmp' --aliases relay.pocketshell.io \
  --service pocketshell-relay --service-user nobody --health-timeout 5 --certdir "$CERT_CACHE" --registry "$REGISTRY_FILE"
assert_eq "t10 domain injection rejected" 1 $?
[ -f "$SB/canary/keepme" ] && ok "t10 canary intact" || ko "t10 canary intact"
run_deploy --bucket fake-bucket \
  --artifact-path "artifacts/0000000000000000000000000000000000000000000000000000000000000000/gateway-linux-arm64.gz" \
  --archive-sha256 "$A_SHA" --binary-sha256 "$A_BSHA" --version git-A --revision "$REVISION_FIXTURE" \
  --domain gateway.pocketshell.io --aliases relay.pocketshell.io \
  --service pocketshell-relay --service-user nobody --health-timeout 5 --certdir "$CERT_CACHE" --registry "$REGISTRY_FILE"
assert_eq "t10 path/digest mismatch rejected (D9)" 1 $?
run_deploy --bucket fake-bucket --artifact-path "artifacts/$A_SHA/gateway-linux-arm64.gz" \
  --archive-sha256 "$A_SHA" --binary-sha256 "$A_BSHA" --version git-A --revision "$REVISION_FIXTURE" \
  --domain gateway.pocketshell.io --aliases relay.pocketshell.io \
  --service 'pocketshell-relay;reboot' --service-user nobody --health-timeout 5 --certdir "$CERT_CACHE" --registry "$REGISTRY_FILE"
assert_eq "t10 service injection rejected" 1 $?
run_deploy --bucket fake-bucket --artifact-path "artifacts/$A_SHA/gateway-linux-arm64.gz" \
  --archive-sha256 "$A_SHA" --binary-sha256 "$A_BSHA" --version git-A --revision "$REVISION_FIXTURE" \
  --domain gateway.pocketshell.io --aliases relay.pocketshell.io \
  --service pocketshell-relay --service-user 'root;reboot' --health-timeout 5
assert_eq "t10 service-user injection rejected" 1 $?

# =====================================================================================
NEW_SB t11_version_sidecar_mismatch_rejected
seed_legacy
mkdir -p "$FAKE_BUCKET_DIR/artifacts/$A_SHA"
cp "$WORK/a.gz" "$FAKE_BUCKET_DIR/artifacts/$A_SHA/gateway-linux-arm64.gz"
printf 'git-OTHER\n' >"$FAKE_BUCKET_DIR/artifacts/$A_SHA/VERSION"
write_manifest "$FAKE_BUCKET_DIR/artifacts/$A_SHA" "$A_SHA" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t11 version sidecar mismatch rejected" 1 $?

# =====================================================================================
NEW_SB t12_manifest_mismatch_rejected
seed_legacy
mkdir -p "$FAKE_BUCKET_DIR/artifacts/$A_SHA"
cp "$WORK/a.gz" "$FAKE_BUCKET_DIR/artifacts/$A_SHA/gateway-linux-arm64.gz"
printf 'git-A\n' >"$FAKE_BUCKET_DIR/artifacts/$A_SHA/VERSION"
write_manifest "$FAKE_BUCKET_DIR/artifacts/$A_SHA" "$A_SHA" "$B_BSHA" git-A # wrong binary digest
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t12 manifest binary digest mismatch rejected" 1 $?

# =====================================================================================
NEW_SB t13_alias_endpoint_failure_rolls_back
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_STALE_EXE_ONCE=1
# Alias outage for the first 5 checks (covers the deploy's ~5s health window),
# then recovery — so the ROLLBACK health on the restored unit passes.
export FAKE_FAIL_FIRST=5
export FAKE_FAIL_NAMES='relay.pocketshell.io'
export FAKE_NO_HEALTHZ=1 # restored legacy binary has no /healthz
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t13 exit 0 (rollback=ok)" 0 $?
assert_contains "t13 rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
assert_eq "t13 legacy copy served after alias failure" "$LEGACY_SHA" "$(sha_file "$STATE_DIR/legacy/pocketshell-relay")"

# =====================================================================================
NEW_SB t14_restart_refusal_rolls_back
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_RESTART_FAIL_FIRST=1
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t14 exit 0 (rollback=ok)" 0 $?
assert_contains "t14 rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
if cmp -s <(printf "%s" "${LEGACY_UNIT_TEMPLATE//__BIN_LINK__/$BIN_LINK}") <(cat "$UNIT_DIR/pocketshell-relay.service"); then ok "t14 unit restored"; else ko "t14 unit restored"; fi

# =====================================================================================
NEW_SB t15_corrupt_existing_release_detected
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$RELEASE_ROOT/$A_SHA"
echo corrupt >"$RELEASE_ROOT/$A_SHA/pocketshell-gateway"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t15 corrupt existing release rejected" 1 $?
[ "$(execstart_of "$UNIT_DIR/pocketshell-relay.service")" = "$BIN_LINK -domain relay.pocketshell.io -client-id cid-123 -allow a@b.c -staging" ] &&
  ok "t15 legacy unit untouched" || ko "t15 legacy unit untouched"

# =====================================================================================
NEW_SB t16_imds_probe_ineffective_falls_back_to_firewall
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_PROBE_RC=1      # token obtainable under IPAddressDeny: filter ineffective
export FAKE_RUNUSER_PROBE_RC=0 # after the uid guard: protected
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t16 exit 0" 0 $?
assert_contains "t16 imds=firewall" "imds=firewall" "$SB/deploy-out.txt"
assert_contains "t16 fallback reason logged" "TOKEN OBTAINABLE" "$SB/deploy-out.txt"
U=$UNIT_DIR/pocketshell-relay.service
assert_eq "t16 IPAddressDeny reset" "" "$(unit_value IPAddressDeny "$U")"
assert_eq "t16 guard ExecStartPre installed" "+$HELPERS_DIR/imds-guard.sh nobody" "$(unit_value ExecStartPre "$U")"
# The strategy is decided in the PREFLIGHT: one restart, straight into the
# guarded unit (never an unguarded IPAddressDeny start first).
grep -c '^restart pocketshell-relay' "$FAKE_SVC_LOG" | grep -q '^1$' &&
  ok "t16 exactly one restart (strategy chosen before the unit is touched)" ||
  ko "t16 exactly one restart (got $(grep -c '^restart pocketshell-relay' "$FAKE_SVC_LOG"))"
grep -q '^iptables -w -S OUTPUT' "$FAKE_TOOL_LOG" && ok "t16 guard tooling checked in preflight" || ko "t16 guard tooling checked in preflight"
grep -q '^iptables -w -I OUTPUT 1 -m owner --uid-owner [0-9]* -d 169.254.169.254/32 -j REJECT' "$FAKE_TOOL_LOG" &&
  ok "t16 uid REJECT rule applied and verified in preflight" || ko "t16 uid REJECT rule applied and verified in preflight"

# =====================================================================================
NEW_SB t17_imds_probe_inconclusive_still_falls_back
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_PROBE_RC=2 # infrastructure failure must NOT count as protected
export FAKE_RUNUSER_PROBE_RC=0
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t17 exit 0" 0 $?
assert_contains "t17 imds=firewall" "imds=firewall" "$SB/deploy-out.txt"
assert_contains "t17 inconclusive treated fail-closed" "fail closed" "$SB/deploy-out.txt"

# =====================================================================================
NEW_SB t18_imds_unprotectable_refuses_rollout
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_PROBE_RC=1
export FAKE_RUNUSER_PROBE_RC=1 # token obtainable even under the uid guard
snapshot_unit=$(cat "$UNIT_DIR/pocketshell-relay.service")
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t18 refused in preflight (exit 1)" 1 $?
assert_contains "t18 refusal message" "probe as nobody under the uid firewall rc=1" "$SB/deploy-err.txt"
assert_contains "t18 refused before any unit or binary change" "refusing before any unit or binary change" "$SB/deploy-err.txt"
assert_eq "t18 legacy unit untouched" "$snapshot_unit" "$(cat "$UNIT_DIR/pocketshell-relay.service")"
[ -f "$BIN_LINK" ] && [ ! -L "$BIN_LINK" ] && ok "t18 legacy executable still at the bin link" || ko "t18 legacy executable still at the bin link"
grep -q '^restart ' "$FAKE_SVC_LOG" && ko "t18 no restart" || ok "t18 no restart"

# =====================================================================================
NEW_SB t19_healthz_version_mismatch_rolls_back
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_HEALTHZ_VERSION='git-OTHER' # running binary reports the wrong version
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t19 exit 0 (rollback=ok)" 0 $?
assert_contains "t19 mismatch detected" "version mismatch" "$SB/deploy-out.txt"

# =====================================================================================
NEW_SB t20_healthz_commit_mismatch_rolls_back
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_HEALTHZ_COMMIT='deadbeefdeadbeefdeadbeefdeadbeefdeadbeef'
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t20 exit 0 (rollback=ok)" 0 $?
assert_contains "t20 commit mismatch detected" "commit mismatch" "$SB/deploy-out.txt"

# =====================================================================================
NEW_SB t21_healthz_requires_json_on_new_deploy
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_NO_HEALTHZ=1 # new deploy without JSON /healthz must be refused
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t21 exit 0 (rollback=ok)" 0 $?
assert_contains "t21 no-JSON refusal logged" "did not serve JSON /healthz" "$SB/deploy-out.txt"
assert_contains "t21 rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
grep -q '^healthz=ok$' "$SB/deploy-out.txt" && ko "t21 never claims healthz=ok" || ok "t21 never claims healthz=ok"

# =====================================================================================
NEW_SB t22_runtime_as_root_rejected
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_LEGACY_ROOT=1 # ORIGINAL/restored no-User legacy root, independent of NEW process model
export FAKE_PROC_STATUS_BAD_UNTIL=1
write_proc_status "$FAKE_PROC_STATUS_FILE" 0 # NEW dedicated-User process wrongly runs as root
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t22 exit 0 (rollback=ok)" 0 $?
assert_contains "t22 process uid rejected" "process uid" "$SB/deploy-out.txt"
assert_contains "t22 NEW root process violates dedicated UID" "process uid '0' != expected uid '$NOBODY_UID'" "$SB/deploy-out.txt"
assert_contains "t22 health=failed" "health=failed" "$SB/deploy-out.txt"

# =====================================================================================
NEW_SB t23_excess_capabilities_rejected
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_PROC_STATUS_BAD_UNTIL=1
{ cat "$FAKE_PROC_STATUS_GOOD"; } >/dev/null
write_proc_status "$FAKE_PROC_STATUS_FILE" "$(id -u nobody)"
# give the process a second capability (CAP_DAC_OVERRIDE=1 → mask 402)
sed -i 's/^CapEff:.*/CapEff:\t0000000000000402/; s/^CapPrm:.*/CapPrm:\t0000000000000402/' "$FAKE_PROC_STATUS_FILE"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t23 exit 0 (rollback=ok)" 0 $?
assert_contains "t23 excess capability rejected" "beyond CAP_NET_BIND_SERVICE" "$SB/deploy-out.txt"

# =====================================================================================
NEW_SB t24_runtime_writable_unit_file_rejected
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_RUNTIME_CAN_WRITE="$UNIT_DIR/pocketshell-relay.service"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t24 exit 0 (rollback=ok)" 0 $?
assert_contains "t24 effective write detected" "CAN write" "$SB/deploy-out.txt"

# =====================================================================================
NEW_SB t25_dropin_execstartpre_root_escape_fails_closed
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
printf '[Service]\nExecStartPre=+/bin/evil\n' >"$UNIT_DIR/pocketshell-relay.service.d/99-evil.conf"
chmod 0644 "$UNIT_DIR/pocketshell-relay.service.d/99-evil.conf"
export FAKE_STALE_EXE_ONCE=1
export FAKE_NO_HEALTHZ=1
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t25 exit 2 (rollback=failed, fail closed)" 2 $?
assert_contains "t25 root ExecStartPre refused" "unexpected ExecStartPre" "$SB/deploy-out.txt"
assert_contains "t25 manual intervention" "MANUAL INTERVENTION" "$SB/deploy-out.txt"

# =====================================================================================
NEW_SB t26_dropin_writable_downgraded_content_enforced
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
printf '[Service]\n# harmless override\n' >"$UNIT_DIR/pocketshell-relay.service.d/50-harmless.conf"
chmod 0662 "$UNIT_DIR/pocketshell-relay.service.d/50-harmless.conf" # group+world writable
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t26 exit 0 (deploy refused once, then rollback ok? no: strict refuses)" 0 $?
assert_contains "t26 writable drop-in refused on new deploy" "group/world-writable" "$SB/deploy-out.txt"

# =====================================================================================
NEW_SB t27_readwritepaths_legacy_entries_not_carried
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# legacy unit with an arbitrary writable path — must NOT survive migration
sed -i 's/^Restart=always/Restart=always\nReadWritePaths=\/var\/lib\/arbitrary/' "$UNIT_DIR/pocketshell-relay.service"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t27 exit 0" 0 $?
assert_eq "t27 ReadWritePaths is exactly the two canonical leaves" "$CERT_DATA_DIR $REGISTRY_DIR" \
  "$(unit_value ReadWritePaths "$UNIT_DIR/pocketshell-relay.service")"

# =====================================================================================
NEW_SB t28_symlinked_state_path_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$SB/evil-place"
chmod 0777 "$SB/evil-place" # world-writable, no sticky
mv "$STATE_DIR/backups" "$SB/backups-real" 2>/dev/null || true
rm -rf "$STATE_DIR/backups"
ln -s "$SB/evil-place" "$STATE_DIR/backups"
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t28 untrusted symlink path refused" 1 $?
assert_contains "t28 refusal names the writable component" "world-writable" "$SB/deploy-err.txt"
assert_eq "t28 unit untouched" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"

# =====================================================================================
NEW_SB t29_uid0_allocation_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
export FAKE_ID_MODE=uid0
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t29 exit 1" 1 $?
assert_contains "t29 uid-0 refusal" "UID 0" "$SB/deploy-err.txt"
assert_eq "t29 unit untouched" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"
[ ! -L "$BIN_LINK" ] && ok "t29 no swap" || ko "t29 no swap"

# =====================================================================================
NEW_SB t30_dangerous_supplementary_group_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
export FAKE_ID_MODE=dangerous
export FAKE_USER_GROUPS='nobody docker'
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t30 exit 1" 1 $?
assert_contains "t30 supplementary groups refused" "NO supplementary groups" "$SB/deploy-err.txt"
assert_eq "t30 unit untouched" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"

# =====================================================================================
NEW_SB t31_user_allocation_idempotent_and_shell_forced
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_GETENT_MISSING=1 # first deploy: user "missing" -> allocate
export FAKE_CREATED_LINE="nobody:x:65534:65534:nobody:/nonexistent:/bin/bash"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t31 first deploy exit 0" 0 $?
grep -q '^useradd' "$FAKE_TOOL_LOG" && ok "t31 useradd called when missing" || ko "t31 useradd called when missing"
grep -q '^usermod --shell /usr/sbin/nologin' "$FAKE_TOOL_LOG" && ok "t31 login shell forced to nologin" || ko "t31 login shell forced to nologin"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t31 second deploy exit 0" 0 $?
[ "$(cat "$FAKE_USERADDED_COUNT")" = "1" ] && ok "t31 user allocation is idempotent" || ko "t31 user allocation is idempotent (count $(cat "$FAKE_USERADDED_COUNT"))"

# =====================================================================================
NEW_SB t32_cert_cache_contents_chowned_to_runtime
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t32 exit 0" 0 $?
assert_eq "t32 pre-existing cert cache file chowned in place" "nobody" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR/legacy-cert.json")"
assert_eq "t32 legacy cert file byte-preserved" "legacy cert state" "$(cat "$CERT_DATA_DIR/legacy-cert.json")"
assert_eq "t32 cert cache leaf chowned" "nobody" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR")"
assert_eq "t32 registry leaf chowned" "nobody" "$("$STAT_BIN" -c '%U' "$REGISTRY_DIR")"
assert_eq "t32 layout base stays root-owned (root-only ancestor)" "$TRUST_OWNER" "$("$STAT_BIN" -c '%U' "$CERT_CACHE")"
assert_eq "t32 layout base group stays root" "$TRUST_GROUP_ID" "$("$STAT_BIN" -c '%g' "$CERT_CACHE")"
assert_eq "t32 layout base mode 0755" "755" "$("$STAT_BIN" -c '%a' "$CERT_CACHE")"
[ ! -e "$REGISTRY_FILE" ] && ok "t32 registry file NOT pre-created (Go owns it)" || ko "t32 registry file NOT pre-created (Go owns it)"

# =====================================================================================
# R1 regression block: the runtime-credential audit parses the REAL structured
# `systemctl show` property format (fixtures above now emit it) and refuses
# every other shape. All refusals fail closed: no healthz=ok is ever claimed,
# and because the poisoned property cannot be un-poisoned by the rollback the
# audit refuses the rollback's re-check too (exit 2, manual intervention) —
# the honest outcome when the audit source itself is not trustworthy.
NEW_SB t33_raw_execstart_property_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_EXECSTARTEX_RAW="$BIN_LINK -domain relay.pocketshell.io" # raw string: what systemd NEVER returns
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t33 exit 2 (audit source untrustworthy -> manual intervention)" 2 $?
assert_contains "t33 raw property refused" "not structured systemd output" "$SB/deploy-out.txt"
assert_contains "t33 health=failed" "health=failed" "$SB/deploy-out.txt"
assert_contains "t33 rollback=failed" "rollback=failed" "$SB/deploy-out.txt"
grep -q '^healthz=ok$' "$SB/deploy-out.txt" && ko "t33 never claims healthz=ok" || ok "t33 never claims healthz=ok"
unset FAKE_EXECSTARTEX_RAW

NEW_SB t34_dropin_execstart_override_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
printf '[Service]\nExecStart=/bin/evil --pwn\n' >"$UNIT_DIR/pocketshell-relay.service.d/98-exec.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t34 exit 2 (drop-in ExecStart override persists through rollback)" 2 $?
assert_contains "t34 wrong ExecStart path refused" "ExecStart path is '/bin/evil'" "$SB/deploy-out.txt"
grep -q '^healthz=ok$' "$SB/deploy-out.txt" && ko "t34 never claims healthz=ok" || ok "t34 never claims healthz=ok"

NEW_SB t35_dropin_execstartpre_wrong_args_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
printf '[Service]\nExecStartPre=+%s/imds-guard.sh OTHERUSER\n' "$HELPERS_DIR" >"$UNIT_DIR/pocketshell-relay.service.d/97-pre.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t35 exit 2" 2 $?
assert_contains "t35 guard argv mismatch refused" "unexpected ExecStartPre argv" "$SB/deploy-out.txt"

NEW_SB t36_privilege_prefix_execstart_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
printf '[Service]\nExecStart=+%s --smuggle\n' "$BIN_LINK" >"$UNIT_DIR/pocketshell-relay.service.d/96-prefix.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t36 exit 2" 2 $?
# Real systemd CONSUMES the '+' into FULLY_PRIVILEGED and reports it in the
# flags= field of ExecStartEx (the plain property shows a prefix-free
# path=$BIN_LINK that would pass the old audit) — the flags-aware check
# refuses the privilege escape; the raw unit-source audit is the second net.
assert_contains "t36 '+'-prefixed drop-in ExecStart refused via flags" "privilege/behavior flags 'privileged'" "$SB/deploy-out.txt"
grep -q '^healthz=ok$' "$SB/deploy-out.txt" && ko "t36 never claims healthz=ok" || ok "t36 never claims healthz=ok"

NEW_SB t37_malformed_property_shapes_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
for shape in \
  'garbage' \
  '{ path=/bin/x ; argv[]=/bin/x ; evil=1 }' \
  '{ path= ; argv[]=/bin/x ; ignore_errors=no }' \
  '{ path=/bin/x ; argv[]=/bin/x ; ignore_errors=no } extra-junk' \
  "{ path=+$BIN_LINK ; argv[]=+$BIN_LINK --smuggle ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"; do
  export FAKE_EXECSTARTEX_RAW="$shape"
  run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
  assert_eq "t37 shape '$shape' refused (exit 2)" 2 $?
  assert_eq "t37 unit untouched after '$shape'" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"
done
grep -q '^healthz=ok$' "$SB/deploy-out.txt" && ko "t37 never claims healthz=ok" || ok "t37 never claims healthz=ok"
unset FAKE_EXECSTARTEX_RAW

# =====================================================================================
# Activation-block regression scenarios (the integration blocker this round
# closes: version/commit-healthy deploys that never mount identity/tunnel).
NEW_SB t38_canonical_layout_exact_file_flag
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t38 exit 0" 0 $?
E=$(execstart_of "$UNIT_DIR/pocketshell-relay.service")
[ "$(grep -o -- '-registry' <<<"$E" | wc -l)" = "1" ] && ok "t38 exactly one -registry flag" || ko "t38 exactly one -registry flag (got: $E)"
grep -qF -- "-registry $REGISTRY_FILE" <<<"$E" && ok "t38 -registry carries the state FILE path" || ko "t38 -registry carries the state FILE path (got: $E)"
[ "$(grep -o -- '-certdir' <<<"$E" | wc -l)" = "1" ] && ok "t38 exactly one -certdir flag" || ko "t38 exactly one -certdir flag (got: $E)"
assert_eq "t38 certs leaf owned by runtime user" "nobody" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR")"
assert_eq "t38 certs leaf group = designated service group" "$(id -g nobody)" "$("$STAT_BIN" -c '%g' "$CERT_DATA_DIR")"
assert_eq "t38 certs leaf mode 0700" "700" "$("$STAT_BIN" -c '%a' "$CERT_DATA_DIR")"
assert_eq "t38 registry leaf owned by runtime user" "nobody" "$("$STAT_BIN" -c '%U' "$REGISTRY_DIR")"
assert_eq "t38 registry leaf mode 0700" "700" "$("$STAT_BIN" -c '%a' "$REGISTRY_DIR")"
assert_eq "t38 base is the -certdir value passed to the binary" "$CERT_CACHE" "$(sed -n 's/.*-certdir \([^ ]*\).*/\1/p' <<<"$E")"
[ ! -e "$REGISTRY_FILE" ] && ok "t38 registry file absent (Go initializes it, never the installer)" || ko "t38 registry file absent (Go initializes it, never the installer)"

NEW_SB t39_rerun_with_service_owned_leaves
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t39 first deploy exit 0" 0 $?
# The leaves are now service:service with the DESIGNATED group — the exact
# state that made the pre-fix audit refuse every rerun (the leaf owner
# exception still required group 0). The rerun must pass every audit.
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t39 rerun with service:service leaves exit 0" 0 $?
assert_contains "t39 rerun healthy" "health=ok" "$SB/deploy-out.txt"
# Direct audit_chain checks against the leaf-group rule (harness-level unit
# tests of the exception: leaf service-owned with the designated group is
# the ONLY non-root ownership allowed, and ONLY at the leaf).
audit_leaf_rc() {
  (
    export SERVICE_USER=nobody
    source "$DEPLOY_BODY"
    audit_chain "$1" "$TRUST_BASE" 1 >/dev/null 2>&1
  )
}
printf '%s\t%s\t%s\n' "$SB" "nobody" 65534 >>"$OWNERSHIP_MAP" # poison AFTER the deploys
audit_leaf_rc "$CERT_DATA_DIR"
[ $? -ne 0 ] && ok "t39 service-owned ANCESTOR refused (never broaden to reach a leaf)" || ko "t39 service-owned ANCESTOR refused (never broaden to reach a leaf)"

NEW_SB t39b_leaf_group_rule_unit
mkdir -p "$SB/leaf-ok" "$SB/leaf-badgroup" "$SB/under-poisoned"
printf '%s\t%s\t%s\n' "$SB/leaf-ok" "nobody" "$(id -g nobody)" >>"$OWNERSHIP_MAP"
printf '%s\t%s\t%s\n' "$SB/leaf-badgroup" "nobody" 1234 >>"$OWNERSHIP_MAP"
# NOTE: the sandbox root is deliberately NOT poisoned here — a service-owned
# ANCESTOR must be refused (that is t39's check, where the deploys have
# already completed); in THIS sandbox the leaf rule is isolated.
audit_leaf_rc "$SB/leaf-ok"
[ $? -eq 0 ] && ok "t39b service-owned leaf WITH designated group accepted" || ko "t39b service-owned leaf WITH designated group accepted"
audit_leaf_rc "$SB/leaf-badgroup"
[ $? -ne 0 ] && ok "t39b service-owned leaf with FOREIGN group refused" || ko "t39b service-owned leaf with FOREIGN group refused"
printf '%s\t%s\t%s\n' "$SB" "nobody" "$(id -g nobody)" >>"$OWNERSHIP_MAP"
audit_leaf_rc "$SB/under-poisoned"
[ $? -ne 0 ] && ok "t39b service-owned ANCESTOR refused even for an absent leaf" || ko "t39b service-owned ANCESTOR refused even for an absent leaf"

NEW_SB t40_existing_certs_and_registry_preserved
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# A valid, non-empty registry (enrolled devices) from an earlier ACTIVATION
# era: Go wrote it AS THE SERVICE ACCOUNT, so it is service-owned; the mode
# drifted from Go's 0600. The installer must realign group/mode WITHIN THE
# SERVICE'S OWN AUTHORITY (never a root pathname chown of leaf content) and
# NEVER rewrite or reset the bytes.
mkdir -p "$REGISTRY_DIR" # first deploy creates the parent; the fixture predates it
printf '{"version":2,"devices":[{"id":"dev-1","account":"google:x","public_key":"","ssh_host_key":"ssh-ed25519 AAAA","revoked":false,"enrolled_at":"2026-01-01T00:00:00Z"}],"revoked_keys":[]}\n' >"$REGISTRY_FILE"
cp "$REGISTRY_FILE" "$SB/registry.before"
chmod 0644 "$REGISTRY_FILE" # drifted mode
printf '%s\t%s\t%s\n' "$REGISTRY_FILE" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP" # service-owned era
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t40 exit 0" 0 $?
cmp -s "$SB/registry.before" "$REGISTRY_FILE" &&
  ok "t40 existing registry byte-preserved (no destructive reset)" ||
  ko "t40 existing registry byte-preserved (no destructive reset)"
assert_eq "t40 existing registry owner service-owned" "nobody" "$("$STAT_BIN" -c '%U' "$REGISTRY_FILE")"
assert_eq "t40 existing registry mode realigned to 0600" "600" "$("$STAT_BIN" -c '%a' "$REGISTRY_FILE")"
assert_contains "t40 preserved-registry logged" "existing identity registry preserved" "$SB/deploy-out.txt"
assert_eq "t40 legacy cert file byte-preserved" "legacy cert state" "$(cat "$CERT_DATA_DIR/legacy-cert.json")"
assert_eq "t40 legacy cert file chowned in place" "nobody" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR/legacy-cert.json")"
# D23 confinement: the registry FILE was aligned as the service user, never
# by a root pathname chown/chmod (root must not act on service-writable
# content through racy pathnames).
grep -E "^chown .*$REGISTRY_FILE|^chmod .*$REGISTRY_FILE" "$FAKE_TOOL_LOG" &&
  ko "t40 registry file aligned WITHOUT root pathname ops (D23)" ||
  ok "t40 registry file aligned WITHOUT root pathname ops (D23)"

NEW_SB t41_symlink_and_writable_ancestor_fail_before_writes
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$SB/evil" && chmod 0777 "$SB/evil"
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
# (1) symlinked certs leaf. The artifact for this key does not exist in the
# bucket: if the deploy got past the audits it would fail at DOWNLOAD — so
# the symlink refusal message plus the ABSENCE of the download step proves
# the audit failed BEFORE the download, not instead of it.
mv "$CERT_DATA_DIR" "$SB/certs-real"
ln -s "$SB/evil" "$CERT_DATA_DIR"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t41 symlinked certs leaf refused" 1 $?
assert_contains "t41 refusal names the symlink" "cert cache dir is a symlink" "$SB/deploy-err.txt"
grep -q "downloading artifact" "$SB/deploy-out.txt" &&
  ko "t41 refusal happened AFTER the download started (too late)" ||
  ok "t41 refusal happened BEFORE the download (first run in this sandbox)"
rm -f "$CERT_DATA_DIR"; mv "$SB/certs-real" "$CERT_DATA_DIR"
# (2) symlinked registry dir
mv "$REGISTRY_DIR" "$SB/registry-real" 2>/dev/null; ln -s "$SB/evil" "$REGISTRY_DIR"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t41 symlinked registry dir refused" 1 $?
assert_contains "t41 registry symlink refusal" "registry dir is a symlink" "$SB/deploy-err.txt"
rm -f "$REGISTRY_DIR"; mv "$SB/registry-real" "$REGISTRY_DIR" 2>/dev/null || mkdir -p "$REGISTRY_DIR"
# (3) symlinked registry file
ln -s "$SB/evil/registry-victim" "$REGISTRY_FILE"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t41 symlinked registry file refused" 1 $?
assert_contains "t41 registry file symlink refusal" "registry file is a symlink" "$SB/deploy-err.txt"
rm -f "$REGISTRY_FILE"
# (4) group-writable base (unrepairable ancestor: mode check refuses)
chmod 0770 "$CERT_CACHE"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t41 group-writable layout base refused" 1 $?
assert_contains "t41 group-writable refusal" "group-writable install path" "$SB/deploy-err.txt"
chmod 0755 "$CERT_CACHE"
# (5) world-writable base (sticky is no mitigation either)
	chmod 0777 "$CERT_CACHE"
	run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
	assert_eq "t41 world-writable layout base refused" 1 $?
	assert_contains "t41 world-writable refusal" "world-writable path (sticky is no mitigation)" "$SB/deploy-err.txt"
	chmod 0755 "$CERT_CACHE"
assert_eq "t41 final: unit still untouched" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"

NEW_SB t42_disabled_posture_fails_and_rolls_back
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_POSTURE=disabled
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t42 disabled registry posture -> rollback=ok" 0 $?
assert_contains "t42 activation gate failure named" "registry posture" "$SB/deploy-out.txt"
assert_contains "t42 health=failed" "health=failed" "$SB/deploy-out.txt"
assert_contains "t42 rollback=ok (legacy serving)" "rollback=ok" "$SB/deploy-out.txt"
grep -q '^healthz=ok$' "$SB/deploy-out.txt" && ko "t42 never claims healthz=ok for disabled posture" || ok "t42 never claims healthz=ok for disabled posture"
unset FAKE_POSTURE
NEW_SB t42b_tunnel_posture_failed
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_TUNNEL_POSTURE=failed
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t42b failed tunnel posture -> rollback=ok" 0 $?
assert_contains "t42b tunnel posture failure named" "tunnel posture" "$SB/deploy-out.txt"
assert_contains "t42b health=failed" "health=failed" "$SB/deploy-out.txt"
unset FAKE_TUNNEL_POSTURE
NEW_SB t42c_route_404_never_accepted
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_ROUTE_404=1 # /healthz claims enabled but the routes are NOT mounted
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t42c unmounted routes -> rollback=ok" 0 $?
assert_contains "t42c identity route 404 refused" "want 401 auth rejection; 404 = routes never mounted" "$SB/deploy-out.txt"
assert_contains "t42c health=failed" "health=failed" "$SB/deploy-out.txt"
grep -q '^health=ok$' "$SB/deploy-out.txt" && ko "t42c never reports healthy deploy" || ok "t42c never reports healthy deploy"
unset FAKE_ROUTE_404

NEW_SB t43_activated_rollback_preserves_previous_posture
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
publish_fixture "$WORK/b.gz" "$B_BSHA" git-B
publish_fixture "$WORK/c.gz" "$C_BSHA" git-C
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t43 A deploy exit 0 (activated)" 0 $?
grep -q "^CURRENT_ACTIVATION=1$" "$STATE_DIR/deploy-state" && ok "t43 A recorded activated" || ko "t43 A recorded activated"
# B fails (stale exe); the rollback restart makes A run again — an ACTIVATED
# release — so the rollback health requires the enabled postures again.
export FAKE_STALE_EXE_ONCE=2
run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B)
assert_eq "t43 B rollback=ok exit 0" 0 $?
assert_contains "t43 rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
grep -q "^PREVIOUS_ACTIVATION=1$" "$STATE_DIR/deploy-state" && ok "t43 ledger keeps the failed attempt as activated previous" || ko "t43 ledger keeps the failed attempt as activated previous"
# Now the rollback target itself is DEACTIVATED: the rollback must REFUSE
# (never claim a successful rollback after the previous posture was lost).
# Restart numbering: A#1, B#2 (stale) + B-rollback#3, C#4 (stale) +
# C-rollback#5 (takes effect, running A with the disabled posture).
unset FAKE_STALE_EXE_ONCE
export FAKE_STALE_EXE_ONCE=4 FAKE_POSTURE=disabled
run_deploy $(deploy_args "$C_SHA" "$C_BSHA" git-C)
assert_eq "t43 deactivated rollback target refused (exit 2)" 2 $?
# The rollback target (A) still SERVES /healthz JSON — with the disabled
# posture, so the refusal is the activation-gate (posture) message; the
# "rollback target was an ACTIVATED release" wording is the no-JSON branch.
assert_contains "t43 refusal names the activated expectation" "activation gate failed" "$SB/deploy-out.txt"
assert_contains "t43 rollback=failed" "rollback=failed" "$SB/deploy-out.txt"
unset FAKE_STALE_EXE_ONCE FAKE_POSTURE

NEW_SB t44_rollback_restores_legacy_posture_and_access
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_STALE_EXE_ONCE=1
export FAKE_NO_HEALTHZ=1
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t44 exit 0 (rollback=ok)" 0 $?
assert_contains "t44 rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
assert_contains "t44 legacy posture reported (no version claim)" "healthz=legacy" "$SB/deploy-out.txt"
assert_eq "t44 legacy binary serving" "$STATE_DIR/legacy/pocketshell-relay" "$(readlink "$BIN_LINK")"
if cmp -s <(printf "%s" "${LEGACY_UNIT_TEMPLATE//__BIN_LINK__/$BIN_LINK}") <(cat "$UNIT_DIR/pocketshell-relay.service"); then
  ok "t44 legacy unit restored (old flags and old posture, byte-identical)"
else
  ko "t44 legacy unit restored (old flags and old posture, byte-identical)"
fi
assert_eq "t44 legacy cert cache still in place" "legacy cert state" "$(cat "$CERT_DATA_DIR/legacy-cert.json")"
assert_eq "t44 legacy cert cache retained for the legacy binary" "nobody" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR")"
assert_eq "t44 layout base root-owned after rollback" "$TRUST_OWNER" "$("$STAT_BIN" -c '%U' "$CERT_CACHE")"
[ ! -e "$REGISTRY_FILE" ] && ok "t44 no registry file fabricated by the failed attempt" || ko "t44 no registry file fabricated by the failed attempt"

NEW_SB t45_missing_allowlist_refused_before_any_write
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
sed -i 's/ -allow a@b\.c//' "$UNIT_DIR/pocketshell-relay.service"
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t45 empty allowlist refused" 1 $?
assert_contains "t45 refusal names the allowlist" "nonempty -allow allowlist" "$SB/deploy-err.txt"
assert_eq "t45 unit untouched" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"
[ ! -L "$BIN_LINK" ] && ok "t45 no bin swap" || ko "t45 no bin swap"

# =====================================================================================
# R1 fidelity block (independent committed review): REAL systemd 255.4 reports
# ExecStart/ExecStartPre PREFIX-FREE (modifiers are consumed at load time)
# and only the *Ex properties carry the consumed flags. The old audit expected
# '+$HELPERS_DIR/imds-guard.sh' inside the property — that never matches a
# real system (production false negative) while the old fixture manufactured
# the prefix to hide it. These cases pin the flags-aware + raw-source design.
NEW_SB t46_r1_flags_parser_and_raw_audit
seed_legacy
GUARD_LINE="ExecStartPre=+$HELPERS_DIR/imds-guard.sh nobody"
EX_GUARD="{ path=$HELPERS_DIR/imds-guard.sh ; argv[]=$HELPERS_DIR/imds-guard.sh nobody ; flags=privileged ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
source_tests "
  exec_parse_commands '$EX_GUARD' ExecStartPreEx
  [ \"\$?\" = 0 ] && [ \"\$EXEC_PATH\" = '$HELPERS_DIR/imds-guard.sh' ] && [ \"\$EXEC_ARGV\" = '$HELPERS_DIR/imds-guard.sh nobody' ] && [ \"\$EXEC_FLAGS\" = privileged ]"
[ $? -eq 0 ] && ok "t46 parser extracts prefix-free path/argv + flags=privileged (real v255 shape)" || ko "t46 parser extracts prefix-free path/argv + flags=privileged (real v255 shape)"
source_tests "
  exec_parse_commands '{ path=$HELPERS_DIR/imds-guard.sh ; argv[]=$HELPERS_DIR/imds-guard.sh nobody ; ignore_errors=no ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }' ExecStartPreEx
  [ \"\$?\" != 0 ]"
[ $? -eq 0 ] && ok "t46 plain-property form (no flags=) REFUSED — not authoritative Ex evidence (D21)" || ko "t46 plain-property form (no flags=) REFUSED (D21)"
source_tests "
  exec_parse_commands '{ path=$HELPERS_DIR/imds-guard.sh ; argv[]=$HELPERS_DIR/imds-guard.sh nobody ; flags=ignore-failure privileged ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }' ExecStartPreEx
  [ \"\$?\" = 0 ] && [ \"\$EXEC_FLAGS\" = 'ignore-failure privileged' ]"
[ $? -eq 0 ] && ok "t46 parser captures combined flags verbatim (audit refuses non-'privileged')" || ko "t46 parser captures combined flags verbatim"
source_tests "
  exec_parse_commands '{ path=+$HELPERS_DIR/imds-guard.sh ; argv[]=+$HELPERS_DIR/imds-guard.sh nobody ; flags=privileged ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }' ExecStartPreEx
  [ \"\$?\" = 0 ] && [ \"\$EXEC_PATH\" = '+$HELPERS_DIR/imds-guard.sh' ]"
[ $? -eq 0 ] && ok "t46 prefix-preserving 'path=+...' parses but can never equal the audit expectation" || ko "t46 prefix-preserving parse"
# Raw-source audit: exact guard line with '+', exactly-once, drop-in Exec* refusal
printf '%s\n' '[Unit]' '[Service]' "ExecStart=$BIN_LINK -domain x" "$GUARD_LINE" >"$UNIT_DIR/pocketshell-relay.service"
source_tests "
  systemd_prop() { systemctl_stub \"\$@\"; }
  unit_raw_exec_ok 1 1 '$BIN_LINK -domain x'
  [ \"\$?\" = 0 ]"
[ $? -eq 0 ] && ok "t46 raw audit accepts the exact '+guard' source line" || ko "t46 raw audit accepts the exact '+guard' source line"
sed -i 's/^ExecStartPre=+/ExecStartPre=/' "$UNIT_DIR/pocketshell-relay.service"
source_tests "
  systemd_prop() { systemctl_stub \"\$@\"; }
  unit_raw_exec_ok 1 1 '$BIN_LINK -domain x'
  [ \"\$?\" != 0 ]"
[ $? -eq 0 ] && ok "t46 raw audit refuses the guard line once '+' is stripped from the source" || ko "t46 raw audit refuses the '+'-stripped guard source"
printf '%s\n' '[Unit]' '[Service]' "ExecStart=$BIN_LINK -domain x" "$GUARD_LINE" >"$UNIT_DIR/pocketshell-relay.service"
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
printf '%s\n' '[Service]' 'ExecStartPre=+/bin/evil' >"$UNIT_DIR/pocketshell-relay.service.d/90-evil.conf"
source_tests "
  R1_DROPINS='$UNIT_DIR/pocketshell-relay.service.d/90-evil.conf'
  systemd_prop() { systemctl_stub \"\$@\"; }
  unit_raw_exec_ok 1 1 '$BIN_LINK -domain x'
  [ \"\$?\" != 0 ]"
[ $? -eq 0 ] && ok "t46 raw audit refuses drop-in Exec* directives" || ko "t46 raw audit refuses drop-in Exec* directives"
rm -rf "$UNIT_DIR/pocketshell-relay.service.d"

NEW_SB t47_guard_flag_fidelity_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_EXECSTARTPREEX_RAW="{ path=$HELPERS_DIR/imds-guard.sh ; argv[]=$HELPERS_DIR/imds-guard.sh nobody ; flags= ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t47 guard without the privileged flag refused (exit 2)" 2 $?
assert_contains "t47 nonprivileged guard refusal" "no '+' full-privilege flag" "$SB/deploy-out.txt"
grep -q '^healthz=ok$' "$SB/deploy-out.txt" && ko "t47a never claims healthz=ok" || ok "t47a never claims healthz=ok"
NEW_SB t47b_guard_extra_flags_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_EXECSTARTPREEX_RAW="{ path=$HELPERS_DIR/imds-guard.sh ; argv[]=$HELPERS_DIR/imds-guard.sh nobody ; flags=ignore-failure privileged ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t47b guard with extra flags (not exactly 'privileged') refused (exit 2)" 2 $?
assert_contains "t47b bad-flags refusal" "no '+' full-privilege flag" "$SB/deploy-out.txt"
NEW_SB t47c_privileged_main_execstart_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_EXECSTARTEX_RAW="{ path=$BIN_LINK ; argv[]=$BIN_LINK -domain relay.pocketshell.io ; flags=privileged ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t47c fully-privileged ExecStart refused (exit 2)" 2 $?
assert_contains "t47c privilege-flags refusal" "privilege/behavior flags 'privileged'" "$SB/deploy-out.txt"
unset FAKE_EXECSTARTPREEX_RAW FAKE_EXECSTARTEX_RAW

NEW_SB t48_guard_without_plus_in_unit_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# The guard baked into the unit WITHOUT its '+' prefix: real systemd reports
# exactly the same prefix-free property as WITH it — only the flags= field
# (and the raw source) can tell them apart. Both must refuse.
sed -i "s|^Restart=always|Restart=always\nExecStartPre=$HELPERS_DIR/imds-guard.sh nobody|" "$UNIT_DIR/pocketshell-relay.service"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t48 '+'-less guard source refused (exit 2)" 2 $?
assert_contains "t48 refusal names the missing privilege flag" "no '+' full-privilege flag" "$SB/deploy-out.txt"
grep -q '^healthz=ok$' "$SB/deploy-out.txt" && ko "t48 never claims healthz=ok" || ok "t48 never claims healthz=ok"

NEW_SB t49_lying_property_vs_raw_source_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# A tampering stub claims flags=privileged for a unit whose raw ExecStartPre
# line has NO '+': the property checks all pass; the raw-source audit is the
# authority that catches the disagreement (defense in depth against a lying
# property source — the property is never the prefix evidence).
sed -i "s|^Restart=always|Restart=always\nExecStartPre=$HELPERS_DIR/imds-guard.sh nobody|" "$UNIT_DIR/pocketshell-relay.service"
export FAKE_EXECSTARTPREEX_RAW="{ path=$HELPERS_DIR/imds-guard.sh ; argv[]=$HELPERS_DIR/imds-guard.sh nobody ; flags=privileged ; start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0 }"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t49 property claims privileged but the raw source lacks '+' -> refused (exit 2)" 2 $?
assert_contains "t49 raw-source refusal" "want 'ExecStartPre=+$HELPERS_DIR/imds-guard.sh nobody'" "$SB/deploy-out.txt"
unset FAKE_EXECSTARTPREEX_RAW

# =====================================================================================
# D23 regression block: the runtime-writable leaf authority boundary. The
# leaves are service-owned and service-writable BY DESIGN — root pathname
# operations on entries inside them race the service (symlink/hardlink/
# rename between check and use). These fixtures pin: aliasing refused,
# foreign-owned state refused, ordinary redeploys emit NO root leaf ops at
# all, interrupted migrations recover without byte damage, the pre-canonical
# base is reclaimed BEFORE children, and a live writer cannot steer root
# authority outside the service's own power. Outside sentinels pin the
# blast radius (content/owner/mode unchanged).
NEW_SB t50_registry_hardlink_refused_sentinel_untouched
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$SB/outside" "$REGISTRY_DIR"
printf 'SENTINEL-SECRET-CONTENT\n' >"$SB/outside/sentinel"
chmod 0640 "$SB/outside/sentinel"
ln "$SB/outside/sentinel" "$REGISTRY_FILE" # hardlink planted at the registry pathname
printf '%s\t%s\t%s\n' "$REGISTRY_FILE" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP"
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
regdir_id=$(/usr/bin/stat -c '%d:%i' "$REGISTRY_DIR")
regdir_owner=$("$STAT_BIN" -c '%U' "$REGISTRY_DIR")
regdir_mode=$("$STAT_BIN" -c '%a' "$REGISTRY_DIR")
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t50 hardlinked registry refused (exit 1)" 1 $?
assert_contains "t50 refusal names the hardlink policy" "hardlinked" "$SB/deploy-err.txt"
# D23 registry separation: the ORIGINAL evidence (dir owner/mode) is
# validated before any adoption could normalize it — the refusal leaves the
# registry directory itself untouched too.
assert_eq "t50 registry dir owner unchanged at refusal" "$regdir_owner" "$("$STAT_BIN" -c '%U' "$REGISTRY_DIR")"
assert_eq "t50 registry dir mode unchanged at refusal" "$regdir_mode" "$("$STAT_BIN" -c '%a' "$REGISTRY_DIR")"
assert_eq "t50 sentinel content unchanged" "SENTINEL-SECRET-CONTENT" "$(cat "$SB/outside/sentinel")"
assert_eq "t50 sentinel real mode unchanged (chmod never follows the alias)" "640" "$(/usr/bin/stat -c '%a' "$SB/outside/sentinel")"
assert_eq "t50 sentinel real owner unchanged" "$(id -un)" "$(/usr/bin/stat -c '%U' "$SB/outside/sentinel")"
assert_eq "t50 unit untouched" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"

NEW_SB t51_registry_foreign_owner_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$REGISTRY_DIR"
printf '{"version":2,"devices":[]}\n' >"$REGISTRY_FILE"
chmod 0600 "$REGISTRY_FILE"
# Root-owned identity state is not a state the service account can have
# produced (Go writes it as the service user) — refused, never re-owned by a
# root pathname chown of untrusted content.
printf '%s\t%s\t%s\n' "$REGISTRY_FILE" "$TRUST_OWNER" "$TRUST_GROUP_ID" >>"$OWNERSHIP_MAP"
cp "$REGISTRY_FILE" "$SB/registry.before"
chmod 0750 "$REGISTRY_DIR" # distinctive dir mode: must survive the refusal unchanged
regdir_owner=$("$STAT_BIN" -c '%U' "$REGISTRY_DIR")
regdir_mode=$("$STAT_BIN" -c '%a' "$REGISTRY_DIR")
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t51 root-owned registry refused (exit 1)" 1 $?
assert_contains "t51 refusal names the ownership policy" "must be service-owned" "$SB/deploy-err.txt"
cmp -s "$SB/registry.before" "$REGISTRY_FILE" &&
  ok "t51 refused registry byte-untouched" ||
  ko "t51 refused registry byte-untouched"
assert_eq "t51 refused registry mode untouched" "600" "$("$STAT_BIN" -c '%a' "$REGISTRY_FILE")"
assert_eq "t51 registry dir owner unchanged at refusal" "$regdir_owner" "$("$STAT_BIN" -c '%U' "$REGISTRY_DIR")"
assert_eq "t51 registry dir mode unchanged at refusal (never normalized)" "$regdir_mode" "$("$STAT_BIN" -c '%a' "$REGISTRY_DIR")"
grep -E "^chown .*$REGISTRY_FILE" "$FAKE_TOOL_LOG" &&
  ko "t51 root never chowns the untrusted registry" ||
  ok "t51 root never chowns the untrusted registry"

NEW_SB t52_ordinary_redeploy_emits_no_root_leaf_ops
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t52 first deploy exit 0" 0 $?
OFFSET=$(wc -l <"$FAKE_TOOL_LOG")
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t52 redeploy exit 0" 0 $?
tail -n +"$((OFFSET + 1))" "$FAKE_TOOL_LOG" >"$SB/tool-slice.txt"
grep -E '^(chown|chmod) ' "$SB/tool-slice.txt" | grep -F -e "$CERT_CACHE" -e "$CERT_DATA_DIR" -e "$REGISTRY_DIR" -e "$REGISTRY_FILE" >"$SB/leaf-ops.txt"
[ ! -s "$SB/leaf-ops.txt" ] &&
  ok "t52 redeploy performs NO root chown/chmod on the runtime leaves (already-correct state untouched)" ||
  ko "t52 redeploy performs NO root chown/chmod on the runtime leaves (got: $(cat "$SB/leaf-ops.txt"))"
assert_eq "t52 legacy cert bytes still intact" "legacy cert state" "$(cat "$CERT_DATA_DIR/legacy-cert.json")"

NEW_SB t53_interrupted_migration_recovers_bytes_intact
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# Interrupted-migration state: the legacy certs cache is still root-era
# (unadopted) AND a corrupt EMPTY registry file exists (a previous attempt
# died after adopting certs, before the registry check). The rerun must
# adopt the cache byte-exactly, then still refuse the corrupt registry.
mkdir -p "$REGISTRY_DIR"
: >"$REGISTRY_FILE"
chmod 0600 "$REGISTRY_FILE"
printf '%s\t%s\t%s\n' "$REGISTRY_FILE" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP"
cp "$CERT_DATA_DIR/legacy-cert.json" "$SB/legacy-cert.before"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t53 corrupt empty registry refused (exit 1)" 1 $?
assert_contains "t53 empty-registry refusal" "registry file exists but is EMPTY" "$SB/deploy-err.txt"
assert_eq "t53 interrupted migration adopted the legacy cache before refusing" "nobody" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR/legacy-cert.json")"
cmp -s "$SB/legacy-cert.before" "$CERT_DATA_DIR/legacy-cert.json" &&
  ok "t53 legacy cert bytes intact through the interruption" ||
  ko "t53 legacy cert bytes intact through the interruption"
rm -f "$REGISTRY_FILE" # admin removes the corrupt artifact; Go will re-init
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t53 recovery rerun exit 0" 0 $?
cmp -s "$SB/legacy-cert.before" "$CERT_DATA_DIR/legacy-cert.json" &&
  ok "t53 legacy cert bytes STILL intact after recovery" ||
  ko "t53 legacy cert bytes STILL intact after recovery"
grep -q "^CURRENT_SHA=$A_SHA$" "$STATE_DIR/deploy-state" && ok "t53 recovery completed the deploy" || ko "t53 recovery completed the deploy"

NEW_SB t54_precanonical_base_reclaimed_before_children
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# Pre-canonical era: the WHOLE certdir base (and everything under it) was
# service-owned. The reclaim must happen BEFORE any child is examined or
# created — while the base is service-owned the service could swap the
# certs/registry entries themselves.
printf '%s\t%s\t%s\n' "$CERT_CACHE" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP"
printf '%s\t%s\t%s\n' "$CERT_DATA_DIR" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP"
printf '%s\t%s\t%s\n' "$CERT_DATA_DIR/legacy-cert.json" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP"
chmod 0700 "$CERT_CACHE" "$CERT_DATA_DIR"
chmod 0600 "$CERT_DATA_DIR/legacy-cert.json"
cp "$CERT_DATA_DIR/legacy-cert.json" "$SB/legacy-cert.before"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t54 exit 0" 0 $?
assert_contains "t54 reclaim logged" "reclaimed pre-canonical service-owned base" "$SB/deploy-out.txt"
assert_eq "t54 base reclaimed to the admin owner" "$TRUST_OWNER" "$("$STAT_BIN" -c '%U' "$CERT_CACHE")"
assert_eq "t54 base mode 0755" "755" "$("$STAT_BIN" -c '%a' "$CERT_CACHE")"
assert_eq "t54 legacy cert owner preserved (already service-owned)" "nobody" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR/legacy-cert.json")"
cmp -s "$SB/legacy-cert.before" "$CERT_DATA_DIR/legacy-cert.json" &&
  ok "t54 legacy cert bytes preserved through the reclaim" ||
  ko "t54 legacy cert bytes preserved through the reclaim"

NEW_SB t55_surviving_writer_race_stays_confined
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t55 first deploy exit 0" 0 $?
# Post-activation state: Go owns a valid registry file; a SERVICE-side
# writer keeps replacing it (temp+rename — the Go store's own pattern). The
# running writer is never stopped by the installer (no quiescence is relied
# on); whatever the race outcome, root authority must stay out of the leaf:
# no root chown/chmod may name the registry pathname, and the outside
# sentinel must be untouched.
mkdir -p "$SB/outside"
printf 'WRITER-RACE-SENTINEL\n' >"$SB/outside/sentinel"
chmod 0640 "$SB/outside/sentinel"
sentinel_id=$(/usr/bin/stat -c '%d:%i' "$SB/outside/sentinel")
printf '{"version":2,"devices":[]}\n' >"$REGISTRY_FILE"
chmod 0600 "$REGISTRY_FILE"
printf '%s\t%s\t%s\n' "$REGISTRY_FILE" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP"
OFFSET=$(wc -l <"$FAKE_TOOL_LOG")
( while :; do printf '{"version":2,"devices":[]}\n' >"$REGISTRY_FILE.tmpw"; mv -f "$REGISTRY_FILE.tmpw" "$REGISTRY_FILE"; sleep 0.01; done ) &
WRITER=$!
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
RACE_RC=$?
kill "$WRITER" 2>/dev/null || true
wait "$WRITER" 2>/dev/null || true
rm -f "$REGISTRY_FILE.tmpw"
{ [ "$RACE_RC" = "0" ] || [ "$RACE_RC" = "1" ]; } &&
  ok "t55 racing deploy either succeeds confined or fails closed (rc=$RACE_RC)" ||
  ko "t55 racing deploy either succeeds confined or fails closed (rc=$RACE_RC)"
tail -n +"$((OFFSET + 1))" "$FAKE_TOOL_LOG" >"$SB/tool-slice.txt"
grep -E '^chown ' "$SB/tool-slice.txt" | grep -F -e "$REGISTRY_FILE" >"$SB/reg-ops.txt"
[ ! -s "$SB/reg-ops.txt" ] &&
  ok "t55 NO root pathname chown ever named the registry file during the race" ||
  ko "t55 NO root pathname chown ever named the registry file during the race (got: $(cat "$SB/reg-ops.txt"))"
# Identity-keyed blast radius: no operation AT ALL (root or runuser,
# pathname- or fd-addressed) may have recorded an effect on the outside
# sentinel's INODE — the tool log carries each operated object's dev:ino, so
# an fd-based effect is visible by identity even when its path argument
# would not name the sentinel.
grep -F "[$sentinel_id]" "$SB/tool-slice.txt" >/dev/null &&
  ko "t55 no op touched the sentinel's inode (identity-checked)" ||
  ok "t55 no op touched the sentinel's inode (identity-checked)"
assert_eq "t55 outside sentinel content unchanged" "WRITER-RACE-SENTINEL" "$(cat "$SB/outside/sentinel")"
assert_eq "t55 outside sentinel real mode unchanged" "640" "$(/usr/bin/stat -c '%a' "$SB/outside/sentinel")"
# After the writer is gone, a clean deploy must succeed again (availability).
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t55 post-race clean redeploy exit 0" 0 $?

NEW_SB t56_flags_witness_refusals
seed_legacy
BAD_TRL='start_time=[n/a] ; stop_time=[n/a] ; pid=0 ; code=(null) ; status=0/0'
source_tests "
  exec_parse_commands '{ path=/bin/x ; argv[]=/bin/x ; flags=privileged ; flags=ignore-failure ; $BAD_TRL }' ExecStartEx
  [ \"\$?\" != 0 ]"
[ $? -eq 0 ] && ok "t56 duplicate flags= fields refused (no overwrite-to-last)" || ko "t56 duplicate flags= fields refused (no overwrite-to-last)"
source_tests "
  exec_parse_commands '{ path=/bin/x ; argv[]=/bin/x ; flags=frobnicate ; $BAD_TRL }' ExecStartEx
  [ \"\$?\" != 0 ]"
[ $? -eq 0 ] && ok "t56 unknown flag word refused (not systemd serialization)" || ko "t56 unknown flag word refused (not systemd serialization)"
source_tests "
  exec_parse_commands '{ path=/bin/x ; argv[]=/bin/x ; ignore_errors=no ; ignore_errors=yes ; flags= ; $BAD_TRL }' ExecStartEx
  [ \"\$?\" != 0 ]"
[ $? -eq 0 ] && ok "t56 duplicate trailer key refused (authoritative serialization is unique-keyed)" || ko "t56 duplicate trailer key refused"
source_tests "
  exec_parse_commands '{ path=/bin/x ; argv[]=/bin/x ; flags=privileged ambient ; $BAD_TRL }' ExecStartEx
  [ \"\$?\" = 0 ] && [ \"\$EXEC_FLAGS\" = 'privileged ambient' ]"
[ $? -eq 0 ] && ok "t56 valid multi-flag serialization parses verbatim (audit policy decides)" || ko "t56 valid multi-flag serialization parses verbatim"
source_tests "
  exec_parse_commands '{ path=/bin/x ; argv[]=/bin/x ; flags= ; $BAD_TRL }' ExecStartEx
  [ \"\$?\" = 0 ] && [ -z \"\$EXEC_FLAGS\" ]"
[ $? -eq 0 ] && ok "t56 explicit empty flags= parses (unmodified command; the real main-command shape)" || ko "t56 explicit empty flags= parses"

NEW_SB t57_dropin_whitespace_and_continuation_forms
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# The drop-in Exec* ban must key on the systemd assignment SYNTAX (whitespace
# around '=' ignored, continuation lines joined), not on literal 'Key=*'
# spellings — otherwise 'ExecStopPost = ...' escapes the ban exactly as the
# D21 review constructed.
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
printf '%s\n' '[Service]' 'ExecStopPost = /bin/evil' >"$UNIT_DIR/pocketshell-relay.service.d/95-spaced.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t57 space-around-equals drop-in ExecStopPost refused (exit 2)" 2 $?
assert_contains "t57 refusal names the spaced drop-in" "sets Exec* directives (ExecStopPost)" "$SB/deploy-out.txt"
rm -f "$UNIT_DIR/pocketshell-relay.service.d/95-spaced.conf"
printf '%s\n' '[Service]' "$(printf '\tExecStopPost\t= /bin/evil')" >"$UNIT_DIR/pocketshell-relay.service.d/95-tabbed.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t57 tab-indented drop-in ExecStopPost refused (exit 2)" 2 $?
assert_contains "t57 refusal names the tabbed drop-in" "sets Exec* directives (ExecStopPost)" "$SB/deploy-out.txt"
rm -f "$UNIT_DIR/pocketshell-relay.service.d/95-tabbed.conf"
printf '%s\n' '[Service]' 'ExecStopPost = \' "$(printf '\t/bin/evil')" >"$UNIT_DIR/pocketshell-relay.service.d/95-cont.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t57 continuation-hidden drop-in ExecStopPost refused (exit 2)" 2 $?
assert_contains "t57 refusal names the continuation drop-in" "sets Exec* directives (ExecStopPost)" "$SB/deploy-out.txt"
rm -f "$UNIT_DIR/pocketshell-relay.service.d/95-cont.conf"
# systemd-equivalent MAIN-unit spellings must still be ACCEPTED (the ban is
# calibrated to real systemd, not stricter than it): spaces around '=' in
# the guard line of the unit we loaded.
printf '%s\n' '[Unit]' '[Service]' "ExecStart=$BIN_LINK -domain x" "ExecStartPre = +$HELPERS_DIR/imds-guard.sh nobody" >"$UNIT_DIR/pocketshell-relay.service"
source_tests "
  systemd_prop() { systemctl_stub \"\$@\"; }
  unit_raw_exec_ok 1 1 '$BIN_LINK -domain x'
  [ \"\$?\" = 0 ]"
[ $? -eq 0 ] && ok "t57 systemd-equivalent spaced guard line in the MAIN unit accepted" || ko "t57 systemd-equivalent spaced guard line in the MAIN unit accepted"

# =====================================================================================
# D23/D21 authority + fidelity block (delivery-authority-final). Two kinds of
# proof live here and are reported HONESTLY as what they are:
#   * KERNEL proof (t58): REAL descriptors + REAL /usr/bin/stat — an open fd
#     keeps its dev+ino across rename/unlink, and a replacement at the old
#     pathname is a different object. No stub participates in those
#     assertions; this is the kernel property the identity-keyed stub model
#     relies on.
#   * STUBBED behavior proof (t59, t60–t66): the recorded-effect model and
#     the end-to-end authority refusals (writable root-owned legacy
#     leaf/nested directories refuse BEFORE child mutation — mode bits AND
#     effective ACL-probe semantics; the registry's ORIGINAL evidence
#     survives a refusal unchanged; the remaining check/use boundary
#     deterministically refuses a replaced pathname with full dev+ino
#     identity; the D21 comment/parity parser controls). The stubbed suite
#     never claims kernel authority on its own.
NEW_SB t58_kernel_descriptor_identity_calibration
mkdir -p "$SB/cal"
printf 'original-bytes\n' >"$SB/cal/obj"
# REAL descriptor, REAL stat only — the kernel half of the fd identity proof.
exec {cfd}<"$SB/cal/obj"
kid_pre=$(/usr/bin/stat -Lc '%d:%i' "/proc/$$/fd/$cfd")
kid_path=$(/usr/bin/stat -c '%d:%i' "$SB/cal/obj")
assert_eq "t58 kernel: fd identity equals pathname identity before replacement" "$kid_path" "$kid_pre"
mv -f "$SB/cal/obj" "$SB/cal/obj.moved"
printf 'replacement-bytes\n' >"$SB/cal/obj" # replacement occupies the OLD name
kid_post=$(/usr/bin/stat -Lc '%d:%i' "/proc/$$/fd/$cfd")
kid_new=$(/usr/bin/stat -c '%d:%i' "$SB/cal/obj")
kid_moved=$(/usr/bin/stat -c '%d:%i' "$SB/cal/obj.moved")
assert_eq "t58 kernel: open fd KEEPS dev+ino across rename+replacement" "$kid_pre" "$kid_post"
assert_eq "t58 kernel: fd still references the MOVED original object" "$kid_moved" "$kid_post"
[ "$kid_new" != "$kid_pre" ] &&
  ok "t58 kernel: the object now at the old pathname is a DIFFERENT inode" ||
  ko "t58 kernel: the object now at the old pathname is a DIFFERENT inode"
exec {cfd}<&-
rm -f "$SB/cal/obj" "$SB/cal/obj.moved"

NEW_SB t59_fd_identity_model_across_rename
mkdir -p "$SB/model"
printf 'model-victim\n' >"$SB/model/state.json"
exec {mfd}<"$SB/model/state.json"
"$SB/bin/stubchown" "nobody:$(id -g nobody)" "/proc/$$/fd/$mfd"
grep -q '^chown \[' "$FAKE_TOOL_LOG" &&
  ok "t59 stub model: fd op recorded WITH its object identity" ||
  ko "t59 stub model: fd op recorded WITH its object identity"
[ -z "$(awk -F'\t' -v p="/proc/$$/fd/$mfd" '$1 == p { print $1 }' "$OWNERSHIP_MAP")" ] &&
  ok "t59 stub model: fd chown writes NO pathname row (no path reconstruction)" ||
  ko "t59 stub model: fd chown writes NO pathname row (no path reconstruction)"
moid=$(/usr/bin/stat -Lc '%d:%i' "/proc/$$/fd/$mfd")
assert_eq "t59 stub model: effect keyed by the OPENED dev:ino" "nobody" \
  "$(awk -F'\t' -v k="$moid" '$1 == k { print $2 }' "$OWNERSHIP_IDMAP")"
mv -f "$SB/model/state.json" "$SB/model/state.json.moved"
printf 'model-replacement\n' >"$SB/model/state.json"
assert_eq "t59 stub model: fd path still reports the ORIGINAL inode" "$moid" \
  "$("$SB/bin/stubstat" -c '%d:%i' "/proc/$$/fd/$mfd")"
assert_eq "t59 stub model: fd path carries the recorded owner of THAT inode" "nobody" \
  "$("$SB/bin/stubstat" -c '%U' "/proc/$$/fd/$mfd")"
assert_eq "t59 stub model: replacement at the old path is NOT colored by the fd chown" \
  "$(id -un)" "$("$SB/bin/stubstat" -c '%U' "$SB/model/state.json")"
[ "$("$SB/bin/stubstat" -c '%i' "$SB/model/state.json")" != "${moid#*:}" ] &&
  ok "t59 stub model: replacement has its own inode, its own (real) ownership" ||
  ko "t59 stub model: replacement has its own inode, its own (real) ownership"
# Kernel agreement: the stub's fd view must equal the REAL kernel's view.
assert_eq "t59 stub model agrees with the kernel on the fd's identity" \
  "$(/usr/bin/stat -Lc '%d:%i' "/proc/$$/fd/$mfd")" \
  "$("$SB/bin/stubstat" -c '%d:%i' "/proc/$$/fd/$mfd")"
exec {mfd}<&-
rm -f "$SB/model/state.json" "$SB/model/state.json.moved"

NEW_SB t60_writable_root_leaf_refused_before_children
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# Root-owned legacy cache that is group/world-writable: root ownership alone
# does NOT make it unwritable to the service — the write authority must be
# refused BEFORE any child is examined or adopted (D23).
chmod 0777 "$CERT_DATA_DIR"
cp "$UNIT_DIR/pocketshell-relay.service" "$SB/unit.before"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t60 writable root-owned legacy leaf refused (exit 1)" 1 $?
assert_contains "t60 refusal names the legacy write authority" "legacy write authority refused before descent" "$SB/deploy-err.txt"
assert_contains "t60 refusal names the certs leaf" "cert cache dir is root-owned but group/world-writable" "$SB/deploy-err.txt"
assert_eq "t60 legacy cert file NOT adopted (owner unchanged)" "$TRUST_OWNER" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR/legacy-cert.json")"
assert_eq "t60 legacy cert bytes unchanged" "legacy cert state" "$(cat "$CERT_DATA_DIR/legacy-cert.json")"
assert_eq "t60 certs leaf mode unchanged at refusal" "777" "$("$STAT_BIN" -c '%a' "$CERT_DATA_DIR")"
[ ! -e "$REGISTRY_FILE" ] && ok "t60 no registry fabricated" || ko "t60 no registry fabricated"
assert_eq "t60 unit untouched" "$(cat "$SB/unit.before")" "$(cat "$UNIT_DIR/pocketshell-relay.service")"

NEW_SB t61_writable_root_nested_dir_refused_before_descent
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# A root-owned NESTED legacy directory that is writable: the descent into it
# must be refused before ITS children are adopted (the certs leaf itself is
# a clean 0700, so the walk reaches the nested entry first).
printf 'sibling-legacy\n' >"$CERT_DATA_DIR/aaa-sibling.json"
mkdir -p "$CERT_DATA_DIR/nested-deep"
printf 'deep-legacy\n' >"$CERT_DATA_DIR/nested-deep/deep.json"
chmod 0700 "$CERT_DATA_DIR"
chmod 0777 "$CERT_DATA_DIR/nested-deep" # the refusing entry (group+world writable)
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t61 writable nested legacy dir refused (exit 1)" 1 $?
assert_contains "t61 refusal names the nested dir" "nested-deep" "$SB/deploy-err.txt"
assert_contains "t61 refusal names the legacy write authority" "legacy write authority refused before descent" "$SB/deploy-err.txt"
assert_eq "t61 nested child NOT adopted (owner unchanged)" "$TRUST_OWNER" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR/nested-deep/deep.json")"
assert_eq "t61 nested child bytes unchanged" "deep-legacy" "$(cat "$CERT_DATA_DIR/nested-deep/deep.json")"
assert_eq "t61 earlier sibling WAS adopted (walk reached it before the refusal)" "nobody" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR/aaa-sibling.json")"
assert_eq "t61 sibling bytes preserved" "sibling-legacy" "$(cat "$CERT_DATA_DIR/aaa-sibling.json")"

NEW_SB t62_acl_writable_root_leaf_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# Mode bits are CLEAN (0755, no group/world write): a POSIX access ACL
# granting the service write is invisible to the mode math — the EFFECTIVE
# write probe executed as the service user is what catches it (kernel
# access(3) semantics). FAKE_RUNTIME_CAN_WRITE models exactly that grant.
chmod 0755 "$CERT_DATA_DIR"
export FAKE_RUNTIME_CAN_WRITE="$CERT_DATA_DIR"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t62 ACL-writable root-owned legacy leaf refused (exit 1)" 1 $?
assert_contains "t62 refusal names the effective write grant" "effectively writable by nobody (access ACL or mode)" "$SB/deploy-err.txt"
assert_eq "t62 legacy cert file NOT adopted" "$TRUST_OWNER" "$("$STAT_BIN" -c '%U' "$CERT_DATA_DIR/legacy-cert.json")"
unset FAKE_RUNTIME_CAN_WRITE

NEW_SB t63_registry_evidence_unchanged_on_refusal
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$REGISTRY_DIR"
printf 'ROOT-ERA-REGISTRY-STATE\n' >"$REGISTRY_FILE"
chmod 0644 "$REGISTRY_FILE"
printf '%s\t%s\t%s\n' "$REGISTRY_FILE" "$TRUST_OWNER" "$TRUST_GROUP_ID" >>"$OWNERSHIP_MAP"
cp "$REGISTRY_FILE" "$SB/registry.before"
chmod 0750 "$REGISTRY_DIR" # distinctive drifted dir mode: must survive unchanged
regdir_id=$(/usr/bin/stat -c '%d:%i' "$REGISTRY_DIR")
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t63 root-owned registry state refused (exit 1)" 1 $?
assert_contains "t63 refusal names the ownership policy" "must be service-owned" "$SB/deploy-err.txt"
cmp -s "$SB/registry.before" "$REGISTRY_FILE" &&
  ok "t63 registry bytes unchanged" ||
  ko "t63 registry bytes unchanged"
assert_eq "t63 registry file owner unchanged" "$TRUST_OWNER" "$("$STAT_BIN" -c '%U' "$REGISTRY_FILE")"
assert_eq "t63 registry file mode unchanged" "644" "$("$STAT_BIN" -c '%a' "$REGISTRY_FILE")"
assert_eq "t63 registry dir owner unchanged (never adopted at refusal)" "$TRUST_OWNER" "$("$STAT_BIN" -c '%U' "$REGISTRY_DIR")"
assert_eq "t63 registry dir mode unchanged (never normalized at refusal)" "750" "$("$STAT_BIN" -c '%a' "$REGISTRY_DIR")"
grep -E '^chown ' "$FAKE_TOOL_LOG" | grep -F -e "$REGISTRY_FILE" -e "$REGISTRY_DIR" >/dev/null &&
  ko "t63 no root chown names the registry subtree" ||
  ok "t63 no root chown names the registry subtree"
grep -E "^chown \[$regdir_id\]" "$FAKE_TOOL_LOG" >/dev/null &&
  ko "t63 no root op touched the registry dir inode (identity-checked)" ||
  ok "t63 no root op touched the registry dir inode (identity-checked)"

NEW_SB t64_registry_service_dir_root_file_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# The registry DIRECTORY is service-owned era, but the FILE inside is
# root-owned. The file's ORIGINAL policy must be validated BEFORE the
# service-owned directory is realigned — the ordering is the evidence: a
# handler that normalized the dir first would show 0700 here.
mkdir -p "$REGISTRY_DIR"
chmod 0755 "$REGISTRY_DIR" # drifted (want 700) — realignment must NOT happen before the file refusal
printf '{"version":2,"devices":[]}\n' >"$REGISTRY_FILE"
chmod 0600 "$REGISTRY_FILE"
printf '%s\t%s\t%s\n' "$REGISTRY_DIR" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP"
printf '%s\t%s\t%s\n' "$REGISTRY_FILE" "$TRUST_OWNER" "$TRUST_GROUP_ID" >>"$OWNERSHIP_MAP"
cp "$REGISTRY_FILE" "$SB/registry.before"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t64 root-owned file under service-owned registry dir refused (exit 1)" 1 $?
assert_contains "t64 refusal names the ownership policy" "must be service-owned" "$SB/deploy-err.txt"
assert_eq "t64 registry dir NOT realigned before the file refusal" "755" "$("$STAT_BIN" -c '%a' "$REGISTRY_DIR")"
grep -E '^runuser (chown|chmod) ' "$FAKE_TOOL_LOG" | grep -F "$REGISTRY_DIR" >/dev/null &&
  ko "t64 no service-authority op touched the dir before the file refusal" ||
  ok "t64 no service-authority op touched the dir before the file refusal"
cmp -s "$SB/registry.before" "$REGISTRY_FILE" &&
  ok "t64 registry file bytes unchanged" ||
  ko "t64 registry file bytes unchanged"

NEW_SB t65_replacement_boundary_dev_ino_refuses
# Deterministic check/use-boundary proof (no timing): lstat an entry, THEN
# replace the pathname, then open — the opened inode's full record
# (type/DEV/inode/nlink/mode/owner/group) can no longer match, and the
# installer must refuse. Also proves the DEVICE dimension participates.
mkdir -p "$SB/swap"
printf 'swap-original\n' >"$SB/swap/entry"
printf 'swap-incoming\n' >"$SB/swap/incoming"
source_tests "
  lstat_record '$SB/swap/entry' 'swap probe'
  mv -f '$SB/swap/incoming' '$SB/swap/entry'
  open_checked '$SB/swap/entry' 'swap probe'
" 2>"$SB/swap-err.txt"
[ $? -ne 0 ] && ok "t65 replaced pathname refuses at the check/use boundary" || ko "t65 replaced pathname refuses at the check/use boundary"
assert_contains "t65 refusal names the check/use boundary" "path replaced between check and open" "$SB/swap-err.txt"
source_tests "
  lstat_record '$SB/swap/entry' 'dev probe'
  LSTAT_DEV=999999 # corrupt ONLY the device: identity is dev+inode, not inode alone
  open_checked '$SB/swap/entry' 'dev probe'
" 2>"$SB/dev-err.txt"
[ $? -ne 0 ] && ok "t65 a DEVICE mismatch refuses even with an identical inode" || ko "t65 a DEVICE mismatch refuses even with an identical inode"
assert_contains "t65 dev refusal uses the full-identity check" "path replaced between check and open" "$SB/dev-err.txt"
# A same-UID sibling replacing a service-owned leaf stays within SERVICE
# authority: the alignment acts as the service user on whatever object is
# there, and the operated inode is asserted BY IDENTITY from the audit trail.
seed_legacy
mkdir -p "$SB/raced-leaf"
printf 'raced-inner\n' >"$SB/raced-leaf/inner.json"
printf '%s\t%s\t%s\n' "$SB/raced-leaf" nobody "$(id -g nobody)" >>"$OWNERSHIP_MAP"
chmod 0755 "$SB/raced-leaf" # drifted mode (want 700): triggers the alignment path
: >"$FAKE_TOOL_LOG"
# Simulate a service-side replacement BEFORE the deploy: a NEW directory
# object now occupies the name (the path-keyed fixture row models the
# service-era statement about the PATH; the replacement is service-made).
mv -f "$SB/raced-leaf" "$SB/raced-leaf.old"
mkdir -p "$SB/raced-leaf"
printf 'raced-inner-new\n' >"$SB/raced-leaf/inner.json"
chmod 0755 "$SB/raced-leaf"
newleaf_id=$(/usr/bin/stat -c '%d:%i' "$SB/raced-leaf")
source_tests "
  migrate_leaf_dir '$SB/raced-leaf' 'raced leaf probe'
" 2>"$SB/raced-err.txt"
[ $? -eq 0 ] && ok "t65 raced service-owned leaf realigned within service authority" || ko "t65 raced service-owned leaf realigned within service authority ($(cat "$SB/raced-err.txt"))"
assert_eq "t65 raced leaf mode realigned to 0700" "700" "$("$STAT_BIN" -c '%a' "$SB/raced-leaf")"
grep -E "^runuser chown \[$newleaf_id\]" "$FAKE_TOOL_LOG" >/dev/null &&
  ok "t65 the operated inode is the REPLACED object (identity in the audit trail)" ||
  ko "t65 the operated inode is the REPLACED object (identity in the audit trail)"
grep -E '^chown \[' "$FAKE_TOOL_LOG" >/dev/null &&
  ko "t65 NO root-authority op touched the raced leaf" ||
  ok "t65 NO root-authority op touched the raced leaf"

NEW_SB t66_d21_comment_and_parity_controls
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
GUARD_LINE="ExecStartPre=+$HELPERS_DIR/imds-guard.sh nobody"
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
# (1) A physical comment ending in a backslash absorbs NOTHING (conf-parser
# v252 skips comments before continuation): the following forbidden hook is
# a REAL assignment and must be caught — the pre-fix parser swallowed it.
printf '%s\n' '[Service]' '# rotation note ending in a backslash \' 'ExecStopPost=/bin/evil' >"$UNIT_DIR/pocketshell-relay.service.d/94-comment-cont.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t66 comment-backslash does NOT hide the drop-in hook (exit 2)" 2 $?
assert_contains "t66 comment-hidden hook caught" "sets Exec* directives (ExecStopPost)" "$SB/deploy-out.txt"
rm -f "$UNIT_DIR/pocketshell-relay.service.d/94-comment-cont.conf"
# (2) An EVEN backslash run does NOT continue: the hook is its own assignment.
printf '%s\n' '[Service]' 'Environment=ROTATE_FLAG=aa \\' 'ExecStopPost=/bin/evil' >"$UNIT_DIR/pocketshell-relay.service.d/94-even.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t66 even-backslash run does NOT swallow the drop-in hook (exit 2)" 2 $?
assert_contains "t66 even-backslash hook caught" "sets Exec* directives (ExecStopPost)" "$SB/deploy-out.txt"
rm -f "$UNIT_DIR/pocketshell-relay.service.d/94-even.conf"
# (3) MAIN unit: comment+backslash followed by the EXACT guard — the guard
# must still be seen (npre=1 with the exact value), not absorbed.
printf '%s\n' '[Unit]' '[Service]' "ExecStart=$BIN_LINK -domain x" '# note ending in backslash \' "$GUARD_LINE" >"$UNIT_DIR/pocketshell-relay.service"
source_tests "
  systemd_prop() { systemctl_stub \"\$@\"; }
  unit_raw_exec_ok 1 1 '$BIN_LINK -domain x'
  [ \"\$?\" = 0 ]"
[ $? -eq 0 ] && ok "t66 main unit: comment+backslash then exact guard ACCEPTED (guard seen)" || ko "t66 main unit: comment+backslash then exact guard ACCEPTED (guard seen)"
# (4) MAIN unit: even-backslash Environment then the exact guard — both
# assignments parsed independently.
printf '%s\n' '[Unit]' '[Service]' "ExecStart=$BIN_LINK -domain x" 'Environment=EXTRA=zz \\' "$GUARD_LINE" >"$UNIT_DIR/pocketshell-relay.service"
source_tests "
  systemd_prop() { systemctl_stub \"\$@\"; }
  unit_raw_exec_ok 1 1 '$BIN_LINK -domain x'
  [ \"\$?\" = 0 ]"
[ $? -eq 0 ] && ok "t66 main unit: even-backslash Environment then exact guard ACCEPTED" || ko "t66 main unit: even-backslash Environment then exact guard ACCEPTED"
# (5) MAIN unit: ODD-backslash continuation joins the next line per systemd —
# the hook-looking tail is part of the joined VALUE (key Environment), no
# hook exists, and the unit is accepted exactly as systemd would run it.
printf '%s\n' '[Unit]' '[Service]' "ExecStart=$BIN_LINK -domain x" 'Environment=EXTRA=zz \' 'ExecStopPost=/bin/evil' "$GUARD_LINE" >"$UNIT_DIR/pocketshell-relay.service"
source_tests "
  systemd_prop() { systemctl_stub \"\$@\"; }
  unit_raw_exec_ok 1 1 '$BIN_LINK -domain x'
  [ \"\$?\" = 0 ]"
[ $? -eq 0 ] && ok "t66 main unit: odd-backslash continuation joins as systemd (no hook invented)" || ko "t66 main unit: odd-backslash continuation joins as systemd (no hook invented)"
# (6) ...but the SAME odd-backslash continuation carrying a hook KEY in a
# DROP-IN is still refused (the joined logical line's key is ExecStopPost).
# Controls (3)-(5) use parser-only main units without an allowlist. Restore
# the production-shaped unit before invoking the FULL installer, otherwise
# its earlier activation validation refuses before the raw-unit audit.
printf '%s' "${LEGACY_UNIT_TEMPLATE//__BIN_LINK__/$BIN_LINK}" >"$UNIT_DIR/pocketshell-relay.service"
printf '%s\n' '[Service]' 'ExecStopPost = \' "$(printf '\t/bin/evil')" >"$UNIT_DIR/pocketshell-relay.service.d/95-cont.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
continuation_rc=$?
# Bind the reason to this invocation; preceding controls already logged the
# same hook reason and must not supply a false positive for this control.
sed -n "/^===== run $RUN_NO =====$/,\$p" "$SB/deploy-out.txt" >"$SB/continuation-run-out.txt"
assert_eq "t66 continuation-hidden drop-in ExecStopPost still refused (exit 2)" 2 "$continuation_rc"
assert_contains "t66 continuation hook caught in its own invocation" "sets Exec* directives (ExecStopPost)" "$SB/continuation-run-out.txt"
rm -f "$UNIT_DIR/pocketshell-relay.service.d/95-cont.conf"
# (7) Ordinary comments and plain assignments remain harmless positives.
printf '%s\n' '[Unit]' '# plain comment' '[Service]' "ExecStart=$BIN_LINK -domain x" "$GUARD_LINE" >"$UNIT_DIR/pocketshell-relay.service"
source_tests "
  systemd_prop() { systemctl_stub \"\$@\"; }
  unit_raw_exec_ok 1 1 '$BIN_LINK -domain x'
  [ \"\$?\" = 0 ]"
[ $? -eq 0 ] && ok "t66 ordinary comments/assignments accepted (exact policy intact)" || ko "t66 ordinary comments/assignments accepted (exact policy intact)"

NEW_SB t67_parent_authority_precedes_base_open
seed_legacy
base_identity=$(/usr/bin/stat -c '%d:%i' "$CERT_CACHE")
base_mode=$(/usr/bin/stat -c '%a' "$CERT_CACHE")
export FAKE_RUNTIME_CAN_WRITE="$SB"
source_tests "SERVICE_USER=nobody; setup_runtime_dirs" >"$SB/parent-refusal.txt" 2>&1
assert_eq "t67 writable ancestor refuses before base open (exit 1)" 1 $?
assert_contains "t67 refusal identifies ancestor authority" "cert cache ancestor is effectively writable" "$SB/parent-refusal.txt"
assert_eq "t67 base mode unchanged" "$base_mode" "$(/usr/bin/stat -c '%a' "$CERT_CACHE")"
if grep -Fq "[$base_identity]" "$FAKE_TOOL_LOG"; then
  ko "t67 no descriptor mutation of base before parent authority"
else
  ok "t67 no descriptor mutation of base before parent authority"
fi
unset FAKE_RUNTIME_CAN_WRITE

NEW_SB t68_authority_probe_requires_execution_witness
seed_legacy
for failure in launch empty malformed wrong_uid; do
  export FAKE_AUTHORITY_PROBE_FAILURE=$failure
  source_tests "dir_not_service_writable '$SB' 'probe control'" >"$SB/witness-$failure.txt" 2>&1
  assert_eq "t68 $failure cannot count as protected authority (exit 1)" 1 $?
done
unset FAKE_AUTHORITY_PROBE_FAILURE
source_tests "dir_not_service_writable '$SB' 'probe control'" >"$SB/witness-protected.txt" 2>&1
assert_eq "t68 successful protected witness accepted" 0 $?
export FAKE_RUNTIME_CAN_WRITE="$SB"
source_tests "dir_not_service_writable '$SB' 'probe control'" >"$SB/witness-writable.txt" 2>&1
assert_eq "t68 successful writable witness refuses" 1 $?
unset FAKE_RUNTIME_CAN_WRITE

NEW_SB t69_final_dac_probe_launch_failure
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t69 prepared deployed layout succeeds" 0 $?
export FAKE_AUTHORITY_PROBE_FAILURE=launch FAKE_AUTHORITY_PROBE_FAILURE_PATH="$UNIT_DIR/pocketshell-relay.service"
source_tests "STATE_FILE='$STATE_DIR/deploy-state'; LOCK_FILE='$STATE_DIR/deploy.lock'; CERT_DATA_DIR='$CERT_CACHE/certs'; REGISTRY_DIR='$CERT_CACHE/registry'; verify_runtime_ownership '$RELEASE_ROOT/$A_SHA/pocketshell-gateway'" >"$SB/dac-probe-failure.txt" 2>&1
assert_eq "t69 final DAC audit refuses launch failure (return 1)" 1 $?
assert_contains "t69 final audit names unproven probe" "service authority probe execution unproven" "$SB/dac-probe-failure.txt"
unset FAKE_AUTHORITY_PROBE_FAILURE FAKE_AUTHORITY_PROBE_FAILURE_PATH

# =====================================================================================
# t70 — release path traversable by the NON-ROOT service user under umask 077.
# Incident (deploy 0ca7ec8, SSM 4bcf35ae): the SSM envelope runs the installer
# under `umask 077`; a bare `mkdir -p` left releases/ and releases/<sha>/
# root:root 0700, so the unit's User=$SERVICE_USER could not traverse them —
# systemd 203/EXEC "Permission denied", crash loop, rollback. The simulated
# service user (nobody) is neither the owner nor in the owning group of the
# root-owned release path, so EVERY component must grant OTHER execute
# (directories: o+x; binary: o+rx) and stay non-group/world-writable (D13).
release_path_blocker() { # $1 = release binary → first component the service cannot use, '' if none
  local bin=$1 p mode
  mode=$(/usr/bin/stat -c '%a' "$bin" 2>/dev/null) || { printf '%s(missing)' "$bin"; return; }
  if [ $((8#$mode & 8#5)) -ne 5 ]; then printf '%s(%s)' "$bin" "$mode"; return; fi
  p=$(dirname "$bin")
  while :; do
    mode=$(/usr/bin/stat -c '%a' "$p" 2>/dev/null) || { printf '%s(missing)' "$p"; return; }
    if [ $((8#$mode & 8#1)) -eq 0 ] || [ $((8#$mode & 8#22)) -ne 0 ]; then printf '%s(%s)' "$p" "$mode"; return; fi
    [ "$p" = "$RELEASE_ROOT" ] && break
    p=$(dirname "$p")
  done
}

NEW_SB t70a_fresh_release_root_under_umask_077
seed_legacy
rm -rf "$RELEASE_ROOT" # production: the release root does not exist before the first deploy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
(umask 077; run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A))
assert_eq "t70a deploy under umask 077 exit 0" 0 $?
assert_eq "t70a service user can traverse+exec the release path" '' "$(release_path_blocker "$RELEASE_ROOT/$A_SHA/pocketshell-gateway")"
assert_eq "t70a release root mode is explicit 0755" 755 "$(/usr/bin/stat -c '%a' "$RELEASE_ROOT")"
assert_eq "t70a per-release dir mode is explicit 0755" 755 "$(/usr/bin/stat -c '%a' "$RELEASE_ROOT/$A_SHA")"
assert_eq "t70a release binary mode 0755" 755 "$(/usr/bin/stat -c '%a' "$RELEASE_ROOT/$A_SHA/pocketshell-gateway")"
assert_eq "t70a bin link targets the release" "$RELEASE_ROOT/$A_SHA/pocketshell-gateway" "$(readlink "$BIN_LINK")"

NEW_SB t70b_leftover_0700_release_repaired_on_reuse
seed_legacy
# Exactly the live state the failed rollout left behind: releases/ and
# releases/<sha>/ root-owned 0700 holding the verified 0755 binary.
mkdir -p "$RELEASE_ROOT/$A_SHA"
cp "$WORK/hello-arm64-a" "$RELEASE_ROOT/$A_SHA/pocketshell-gateway"
chmod 0755 "$RELEASE_ROOT/$A_SHA/pocketshell-gateway"
chmod 0700 "$RELEASE_ROOT" "$RELEASE_ROOT/$A_SHA"
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
(umask 077; run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A))
assert_eq "t70b redeploy over 0700 leftovers exit 0" 0 $?
assert_contains "t70b existing release reused" "release already present, reusing" "$SB/deploy-out.txt"
assert_eq "t70b service user can traverse+exec the reused release path" '' "$(release_path_blocker "$RELEASE_ROOT/$A_SHA/pocketshell-gateway")"
assert_eq "t70b release root repaired to 0755" 755 "$(/usr/bin/stat -c '%a' "$RELEASE_ROOT")"
assert_eq "t70b per-release dir repaired to 0755" 755 "$(/usr/bin/stat -c '%a' "$RELEASE_ROOT/$A_SHA")"

NEW_SB t70c_missing_certdir_ancestors_traversable_under_umask_077
seed_legacy
# A certdir whose PARENT does not exist yet: every component the installer
# creates on the way to the service-owned leaves must be root 0755, the
# leaves themselves service-owned 0700.
export CERT_CACHE=$SB/var-new/cert-base
export CERT_DATA_DIR=$CERT_CACHE/certs REGISTRY_DIR=$CERT_CACHE/registry
export REGISTRY_FILE=$REGISTRY_DIR/devices.json
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
(umask 077; run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A))
assert_eq "t70c deploy with a missing certdir ancestor exit 0" 0 $?
assert_eq "t70c created certdir ancestor mode 0755" 755 "$(/usr/bin/stat -c '%a' "$SB/var-new")"
assert_eq "t70c certdir base mode 0755" 755 "$(/usr/bin/stat -c '%a' "$CERT_CACHE")"
assert_eq "t70c cert leaf stays service-only 0700" 700 "$(/usr/bin/stat -c '%a' "$CERT_DATA_DIR")"
assert_eq "t70c registry leaf stays service-only 0700" 700 "$(/usr/bin/stat -c '%a' "$REGISTRY_DIR")"

# Path-trust audit still REFUSES group/world-writable release components
# (0755 is accepted; widening to g+w/o+w is not).
NEW_SB t70d_release_root_write_bits_still_refused
seed_legacy
for bad in 0775 0757; do
  chmod "$bad" "$RELEASE_ROOT"
  source_tests "verify_trusted_dir '$RELEASE_ROOT'" >"$SB/audit-$bad.txt" 2>&1
  assert_eq "t70d release root $bad refused by path-trust audit (exit 1)" 1 $?
done
chmod 0755 "$RELEASE_ROOT"
source_tests "verify_trusted_dir '$RELEASE_ROOT'" >"$SB/audit-0755.txt" 2>&1
assert_eq "t70d release root 0755 accepted by path-trust audit" 0 $?

# =====================================================================================
# t71 — REAL systemd capability/IP-prefix serialization (deploy incident
# 37947576965, Amazon Linux 2023, systemd 252.23). `systemctl show --value`
# renders CapabilityBoundingSet/AmbientCapabilities as LOWERCASE mask names
# (cap_net_bind_service) and IPAddressDeny as CIDR (169.254.169.254/32); the
# pre-fix audit compared the literal unit text (CAP_NET_BIND_SERVICE, bare
# addresses), so every real hardened deploy failed the D13 runtime audit and
# rolled back while this harness — whose stub echoed the unit text — passed.
NEW_SB t71_real_systemd_cap_and_ipdeny_serialization
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t71 hardened deploy passes the runtime audit against real systemd rendering (exit 0)" 0 $?
assert_contains "t71 health=ok" "health=ok" "$SB/deploy-out.txt"
assert_contains "t71 rollback=none" "rollback=none" "$SB/deploy-out.txt"
grep -q "CapabilityBoundingSet .*not exactly\|AmbientCapabilities .*not exactly\|CapabilityBoundingSet not CAP_NET_BIND_SERVICE" "$SB/deploy-out.txt" &&
  ko "t71 no capability-serialization refusal" || ok "t71 no capability-serialization refusal"
# Stub fidelity: the fixture renders exactly what systemd 252/255 prints.
assert_eq "t71 stub renders CapabilityBoundingSet lowercase (real systemd)" "cap_net_bind_service" \
  "$("$SYSTEMCTL" show -p CapabilityBoundingSet --value pocketshell-relay)"
assert_eq "t71 stub renders AmbientCapabilities lowercase (real systemd)" "cap_net_bind_service" \
  "$("$SYSTEMCTL" show -p AmbientCapabilities --value pocketshell-relay)"
assert_eq "t71 stub renders IPAddressDeny as CIDR in set order (real systemd)" "fd00:ec2::254/128 169.254.169.254/32" \
  "$("$SYSTEMCTL" show -p IPAddressDeny --value pocketshell-relay)"
# Exactness is kept: these are SET comparisons, never substring/prefix.
CAPS_FULL='cap_chown cap_dac_override cap_dac_read_search cap_fowner cap_fsetid cap_kill cap_setgid cap_setuid cap_setpcap cap_linux_immutable cap_net_bind_service cap_net_broadcast cap_net_admin cap_net_raw cap_ipc_lock cap_ipc_owner cap_sys_module cap_sys_rawio cap_sys_chroot cap_sys_ptrace cap_sys_pacct cap_sys_admin cap_sys_boot cap_sys_nice cap_sys_resource cap_sys_time cap_sys_tty_config cap_mknod cap_lease cap_audit_write cap_audit_control cap_setfcap cap_mac_override cap_mac_admin cap_syslog cap_wake_alarm cap_block_suspend cap_audit_read cap_perfmon cap_bpf cap_checkpoint_restore'
for good in 'cap_net_bind_service' 'CAP_NET_BIND_SERVICE' ' cap_net_bind_service '; do
  source_tests "prop_caps_exactly_bind '$good'"
  assert_eq "t71 caps '$good' accepted as exactly CAP_NET_BIND_SERVICE" 0 $?
done
for bad in '' "$CAPS_FULL" 'cap_net_bind_service cap_sys_admin' 'cap_net_raw' 'cap_net_bind' 'cap_net_bind_service_x' '10' 'net_bind_service' 'cap_*'; do
  source_tests "prop_caps_exactly_bind '$bad'"
  assert_eq "t71 caps '${bad:0:40}' refused" 1 $?
done
for good in '169.254.169.254/32 fd00:ec2::254/128' 'fd00:ec2::254/128 169.254.169.254/32' '169.254.169.254 fd00:ec2::254' '10.0.0.0/8 169.254.169.254/32 fd00:ec2::254/128'; do
  source_tests "prop_ipdeny_has '$good' 169.254.169.254 32 && prop_ipdeny_has '$good' fd00:ec2::254 128"
  assert_eq "t71 IPAddressDeny '$good' covers both IMDS hosts" 0 $?
done
for bad in '' '169.254.0.0/16 fd00:ec2::/64' '169.254.169.254/31' '169.254.169.2540/32' '169.254.169.25/32' 'fd00:ec2::254/127' '0.0.0.0/0 ::/0'; do
  source_tests "prop_ipdeny_has '$bad' 169.254.169.254 32 && prop_ipdeny_has '$bad' fd00:ec2::254 128"
  assert_eq "t71 IPAddressDeny '$bad' refused (exact host entries only)" 1 $?
done

# A drop-in that WIDENS the bounding set renders as a multi-name lowercase set
# under real systemd; the audit must still refuse it (exactly one capability).
NEW_SB t71b_dropin_widened_capability_set_refused
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
mkdir -p "$UNIT_DIR/pocketshell-relay.service.d"
printf '[Service]\nCapabilityBoundingSet=CAP_SYS_ADMIN\nAmbientCapabilities=CAP_SYS_ADMIN\n' >"$UNIT_DIR/pocketshell-relay.service.d/60-caps.conf"
chmod 0644 "$UNIT_DIR/pocketshell-relay.service.d/60-caps.conf"
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_contains "t71b widened bounding set refused" "CapabilityBoundingSet is 'cap_net_bind_service cap_sys_admin', not exactly CAP_NET_BIND_SERVICE" "$SB/deploy-out.txt"
assert_contains "t71b deploy health=failed" "health=failed" "$SB/deploy-out.txt"
grep -q "rollback=none" "$SB/deploy-out.txt" && ko "t71b widened caps never accepted" || ok "t71b widened caps never accepted"

# =====================================================================================
# t72-t75 — production deploy incident 2026-10-09 (run 37970949069, SSM
# 449a8271, AL2023 aarch64, systemd 252): the strategy-A probe was read as
# inconclusive, the installer activated strategy B on a host WITHOUT iptables
# (nft absent too), the guard ExecStartPre exited 127, and the rollback trap
# died on `unit_installed: unbound variable` — nothing was restored.
snapshot_deploy_world() { # $1 = prefix: unit bytes, bin link, state, restart count
  cp "$UNIT_DIR/pocketshell-relay.service" "$SB/$1.unit"
  readlink "$BIN_LINK" >"$SB/$1.link" 2>/dev/null || printf 'regular-file\n' >"$SB/$1.link"
  cp "$STATE_DIR/deploy-state" "$SB/$1.state" 2>/dev/null || : >"$SB/$1.state"
  grep -c '^restart ' "$FAKE_SVC_LOG" >"$SB/$1.restarts" || true
}
assert_world_unchanged() { # $1 = label, $2 = snapshot prefix
  snapshot_deploy_world "$2.after"
  local f
  for f in unit link state restarts; do
    if cmp -s "$SB/$2.$f" "$SB/$2.after.$f"; then ok "$1 $f unchanged"; else ko "$1 $f unchanged"; fi
  done
}

NEW_SB t72_execstartpre_failure_after_restart_rolls_back_to_previous_unit
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t72 release A deployed (strategy A)" 0 $?
snapshot_deploy_world t72-A
publish_fixture "$WORK/b.gz" "$B_BSHA" git-B
export FAKE_PROBE_RC=2            # strategy A not proven for this deploy -> strategy B
export FAKE_RUNUSER_PROBE_RC=0
export FAKE_EXECSTARTPRE_FAILS=1  # the guard ExecStartPre exits 127 on restart (incident)
run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B)
assert_eq "t72 failed B deploy exits 0 with rollback=ok" 0 $?
grep -q 'unbound variable' "$SB/deploy-err.txt" && ko "t72 rollback trap has no unbound variable" || ok "t72 rollback trap has no unbound variable"
assert_contains "t72 rollback ran" "DEPLOY FAILED — rolling back" "$SB/deploy-out.txt"
assert_contains "t72 rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
assert_contains "t72 the ExecStartPre restart failure was hit" "restart-failed pocketshell-relay ExecStartPre" "$FAKE_SVC_LOG"
cmp -s "$SB/t72-A.unit" "$UNIT_DIR/pocketshell-relay.service" && ok "t72 previous healthy unit restored byte-for-byte" || ko "t72 previous healthy unit restored byte-for-byte"
assert_eq "t72 restored unit has no ExecStartPre" "" "$(unit_value ExecStartPre "$UNIT_DIR/pocketshell-relay.service")"
assert_eq "t72 bin link restored to release A" "$(cat "$SB/t72-A.link")" "$(readlink "$BIN_LINK")"
assert_eq "t72 restored release A is running" "$RELEASE_ROOT/$A_SHA/pocketshell-gateway" "$(cat "$FAKE_RUNNING_FILE")"
assert_eq "t72 service active after rollback" active "$(cat "$FAKE_STATE_FILE")"
assert_eq "t72 ledger CURRENT is A again" "CURRENT_SHA=$A_SHA" "$(grep '^CURRENT_SHA=' "$STATE_DIR/deploy-state")"
unset FAKE_PROBE_RC FAKE_RUNUSER_PROBE_RC FAKE_EXECSTARTPRE_FAILS

NEW_SB t72b_injected_fatal_error_after_unit_install_rolls_back
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t72b release A deployed" 0 $?
snapshot_deploy_world t72b-A
publish_fixture "$WORK/b.gz" "$B_BSHA" git-B
# Deploy A used reload #1; B's first reload (#2) runs right after B's unit
# and bin link are installed: an arbitrary fatal (errexit) error there.
export FAKE_DAEMON_RELOAD_FAIL_FIRST=2
run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B)
assert_eq "t72b injected failure exits 0 with rollback=ok" 0 $?
grep -q 'unbound variable' "$SB/deploy-err.txt" && ko "t72b no unbound variable in the trap" || ok "t72b no unbound variable in the trap"
assert_contains "t72b fault was injected after the unit install" "Failed to reload daemon: injected fault" "$SB/deploy-err.txt"
assert_contains "t72b rollback=ok" "rollback=ok" "$SB/deploy-out.txt"
cmp -s "$SB/t72b-A.unit" "$UNIT_DIR/pocketshell-relay.service" && ok "t72b previous unit restored byte-for-byte" || ko "t72b previous unit restored byte-for-byte"
assert_eq "t72b bin link restored to release A" "$(cat "$SB/t72b-A.link")" "$(readlink "$BIN_LINK")"
assert_eq "t72b release A running and healthy" "$RELEASE_ROOT/$A_SHA/pocketshell-gateway" "$(cat "$FAKE_RUNNING_FILE")"
assert_eq "t72b service active" active "$(cat "$FAKE_STATE_FILE")"
assert_contains "t72b restored release verified (healthz=ok)" "rollback=ok (previous configuration healthy again; healthz=ok)" "$SB/deploy-out.txt"
unset FAKE_DAEMON_RELOAD_FAIL_FIRST

NEW_SB t73_no_imds_strategy_refuses_before_any_mutation
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t73 release A deployed" 0 $?
snapshot_deploy_world t73-A
publish_fixture "$WORK/b.gz" "$B_BSHA" git-B
export FAKE_PROBE_RC=2                  # strategy A not proven
mkdir -p "$SB/no-firewall-tools"        # AL2023: neither iptables nor nft
export IMDS_GUARD_PATH=$SB/no-firewall-tools
run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B)
assert_eq "t73 deploy refused (exit 1)" 1 $?
assert_contains "t73 refusal names the missing strategy-B dependency" "iptables not found" "$SB/deploy-err.txt"
assert_contains "t73 refused before any unit/binary change" "refusing before any unit or binary change" "$SB/deploy-err.txt"
assert_world_unchanged "t73" t73-A
grep -q 'imds=firewall' "$SB/deploy-out.txt" && ko "t73 strategy B never activated" || ok "t73 strategy B never activated"
unset FAKE_PROBE_RC

NEW_SB t73b_no_imds_strategy_first_migration_keeps_legacy
seed_legacy
snapshot_deploy_world t73b-legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_PROBE_RC=1                  # token obtainable under IPAddressDeny
mkdir -p "$SB/no-firewall-tools"
export IMDS_GUARD_PATH=$SB/no-firewall-tools
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t73b first migration refused (exit 1)" 1 $?
assert_world_unchanged "t73b" t73b-legacy
[ -f "$BIN_LINK" ] && [ ! -L "$BIN_LINK" ] && ok "t73b legacy executable still in place" || ko "t73b legacy executable still in place"
unset FAKE_PROBE_RC

NEW_SB t74_bpf_drop_with_positive_control_is_strategy_a
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_PROBE_RC=10   # connect-phase timeout under IPAddressDeny: the real-kernel BPF drop
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t74 exit 0" 0 $?
assert_contains "t74 imds=systemd" "imds=systemd" "$SB/deploy-out.txt"
U=$UNIT_DIR/pocketshell-relay.service
assert_eq "t74 IPAddressDeny kept" "169.254.169.254 fd00:ec2::254" "$(unit_value IPAddressDeny "$U")"
assert_eq "t74 no ExecStartPre" "" "$(unit_value ExecStartPre "$U")"
grep -q '^iptables \|^ip6tables ' "$FAKE_TOOL_LOG" && ko "t74 firewall never touched" || ok "t74 firewall never touched"
unset FAKE_PROBE_RC

NEW_SB t74b_bpf_drop_without_positive_control_is_not_proof
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
export FAKE_PROBE_RC=10 FAKE_CONTROL_RC=2   # IMDS unreachable even WITHOUT the filter
export FAKE_RUNUSER_PROBE_RC=0
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t74b exit 0" 0 $?
assert_contains "t74b strategy A not accepted without control: imds=firewall" "imds=firewall" "$SB/deploy-out.txt"
unset FAKE_PROBE_RC FAKE_CONTROL_RC FAKE_RUNUSER_PROBE_RC

NEW_SB t74c_control_unit_start_failure_is_not_a_positive_control
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
# systemd-run exits 1 when it cannot start the unit at all ("Failed to find
# executable", observed natively on systemd 252): that must never read as
# "IMDS answered", so a dropped filtered probe stays unattributable.
export FAKE_PROBE_RC=10 FAKE_CONTROL_RC=1
export FAKE_RUNUSER_PROBE_RC=0
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t74c exit 0" 0 $?
assert_contains "t74c rc-1 control is not proof: imds=firewall" "imds=firewall" "$SB/deploy-out.txt"
grep -q -- '--control' "$FAKE_TOOL_LOG" && ok "t74c control runs the probe in --control mode" || ko "t74c control runs the probe in --control mode"
unset FAKE_PROBE_RC FAKE_CONTROL_RC FAKE_RUNUSER_PROBE_RC

NEW_SB t75_broken_firewall_tooling_refuses_before_any_mutation
seed_legacy
publish_fixture "$WORK/a.gz" "$A_BSHA" git-A
run_deploy $(deploy_args "$A_SHA" "$A_BSHA" git-A)
assert_eq "t75 release A deployed" 0 $?
snapshot_deploy_world t75-A
publish_fixture "$WORK/b.gz" "$B_BSHA" git-B
export FAKE_PROBE_RC=2 FAKE_IPTABLES_BROKEN=1 # binaries present, kernel tables unusable
run_deploy $(deploy_args "$B_SHA" "$B_BSHA" git-B)
assert_eq "t75 deploy refused (exit 1)" 1 $?
assert_world_unchanged "t75" t75-A
unset FAKE_PROBE_RC FAKE_IPTABLES_BROKEN

finish
