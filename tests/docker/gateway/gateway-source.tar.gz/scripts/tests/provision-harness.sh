#!/usr/bin/env bash
# Behavioral harness for the GENERATED SSM document's helper-provisioning
# sequence (review R2).
#
# The audit target is the GENERATED block inside infra/github-actions.yaml —
# NOT the installer source — because the vulnerability class is the
# document's execution ORDER (privileged writes before validation, symlink-
# following writes, ancestor mutation). The harness:
#   1. extracts the generated runCommand block and its provisioning region;
#   2. structurally asserts the sequence: helpers installed via helper_install
#      BEFORE `main` runs, no `install -d`, no bare `cat > <final path>`, no
#      post-hoc chown of the final destination;
#   3. executes the EXACT generated provisioning region for real in a
#      sandbox (unprivileged; chown recorded; stat overridable) under
#      adversarial filesystem fixtures. Every refusal must PRESERVE the
#      pre-existing bytes, ownership and modes:
#        P1  pristine install (payload bytes land, 0755, root:root recorded)
#        P2  idempotent redeploy replaces root-owned helpers atomically
#        N1  dangling final symlink at a helper path -> refuse, symlink kept
#        N2  symlink to a victim file -> refuse, victim bytes/mode intact
#        N3  group-writable helpers dir -> refuse, dir + planted file intact
#        N4  foreign-owned existing helper -> refuse, bytes intact
#        N5  symlinked helpers dir -> refuse, target dir + mode untouched
#        N6  missing parent chain -> refuse, nothing created above the leaf
#
#      Default trust-base fidelity (independent committed review R2: with the
#      production default TRUST_BASE=/ the subtree pattern `//*` matched
#      nothing, so EVERY ordinary absolute ancestor — and the root itself —
#      was silently skipped and the whole chain audit was vacuous; the
#      sticky-bit allowance also admitted root-owned 1777 staging dirs, where
#      the predictable staging name let an untrusted writer race a symlink
#      under `rm -f` + `cat >`):
#        P7  default base (TRUST_BASE unset): pristine install succeeds AND
#            the stat query log records EVERY component examined, including
#            / itself (the audit is load-bearing, not skipped)
#        P8  default base: world-writable STICKY parent (real 1777, sandbox
#            local) -> refuse BEFORE any mkdir/chmod/chown/write
#        P9  default base: unusable stat -> refuse (old code audited nothing
#            and happily "succeeded" with STAT_BIN=/bin/false)
#        P10 explicit TRUST_BASE=/ behaves exactly like the default
#        P11 invalid bases refused: relative path, "."
#        P12 base normalization: trailing slash "//base/" and "//" behave as
#            the normalized base; the base component itself is audited
#        P13 root-owned world-writable STICKY helpers dir (custom base) ->
#            refuse: sticky is NOT a mitigation for the staging race
#      All P7-P13 fixtures live entirely inside the harness sandbox; no
#      system directory or permission is ever touched.
set -uo pipefail

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
TEMPLATE=$ROOT/infra/github-actions.yaml
# The workdir lives under the repo's gitignored .tmp/ (like the installer
# harness) so the default trust-base walks traverse the repo path, whose
# every component the stub map models deterministically — /tmp is 1777+ACL
# on a real host and would refuse for the right reason with the wrong
# (unmodelable) evidence.
mkdir -p "$ROOT/.tmp"
WORK=$(mktemp -d "$ROOT/.tmp/gateway-provision-harness.XXXXXX")
umask 077 # sandbox dirs must model a trusted (non-group-writable) install root
PASS=0
FAIL=0

note() { printf '[pv-harness] %s\n' "$*"; }
ok() { PASS=$((PASS + 1)); printf '[pv-harness] PASS: %s\n' "$1"; }
ko() { FAIL=$((FAIL + 1)); printf '[pv-harness] FAIL: %s\n' "$1"; }
finish() {
  rm -rf "$WORK"
  note "-----"
  note "passed=$PASS failed=$FAIL"
  [ "$FAIL" = 0 ] || exit 1
  exit 0
}
assert_eq() { # desc expected actual
  if [ "$2" = "$3" ]; then ok "$1"; else ko "$1 (expected '$2' got '$3')"; fi
}

# --- 1. extract the generated block + provisioning region ---------------------
BLOCK=$WORK/generated-block.sh
PROV=$WORK/provision-region.sh
python3 - "$TEMPLATE" "$BLOCK" "$PROV" <<'PY'
import importlib.util, pathlib, sys, yaml

class L(yaml.SafeLoader):
    pass

L.add_multi_constructor("!", lambda ld, tag, node: None)
cfn = yaml.load(open(sys.argv[1]), Loader=L)
content = cfn["Resources"]["GatewayDeployDocument"]["Properties"]["Content"]
cmd = content["mainSteps"][0]["inputs"]["runCommand"][0]
# yaml.load already removes the scalar's indentation; keep payload spaces.
root = pathlib.Path(sys.argv[1]).resolve().parents[1]
spec = importlib.util.spec_from_file_location("gateway_infra_generator", root / "scripts/gen-infra.py")
generator = importlib.util.module_from_spec(spec)
sys.dont_write_bytecode = True
spec.loader.exec_module(generator)
payload = generator.decode_embedded(cmd)
assert payload == generator.trusted_payload(), "committed envelope must reconstruct exact sources"
lines = payload.decode("utf-8").splitlines()
open(sys.argv[2], "w").write("\n".join(lines) + "\n")
start = next(i for i, ln in enumerate(lines) if ln.startswith("# ---- IMDS helpers"))
end = next(i for i, ln in enumerate(lines) if ln.startswith("# ---- deployment invocation"))
open(sys.argv[3], "w").write("\n".join(lines[start:end]) + "\n")
print(f"block={len(lines)} provisioning-lines={end - start}")
PY
[ -s "$BLOCK" ] && [ -s "$PROV" ] || { ko "extracting the generated block failed"; finish; }

# --- 2. structural sequence assertions ----------------------------------------
first_install=$(grep -n '^helper_install ' "$BLOCK" | head -1 | cut -d: -f1)
main_line=$(grep -n -x -F 'main "$@"' "$BLOCK" | head -1 | cut -d: -f1)
[ -n "$first_install" ] && [ -n "$main_line" ] || { ko "block must contain helper_install calls and the main invocation"; finish; }
[ "$first_install" -lt "$main_line" ] &&
  ok "helpers are provisioned BEFORE main() runs (line $first_install < $main_line)" ||
  ko "helpers are provisioned BEFORE main() runs (line $first_install >= $main_line)"

n_calls=$(grep -c '^helper_install ' "$BLOCK")
assert_eq "exactly two helper_install calls (probe + guard)" 2 "$n_calls"
# Raw writes/installs outside helper_install — comments (including the
# preamble's documentation) are excluded, code is not.
if grep -Ev '^[[:space:]]*#' "$PROV" | grep -Eq "install -d|cat > '|>>|chown root:root '/"; then
  ko "provisioning region contains a raw write/install outside helper_install"
else
  ok "no install -d / bare cat-to-final-path / append / post-hoc chown in the provisioning region"
fi
grep -q 'helper_dir_trusted' "$PROV" && grep -q 'mv -f' "$PROV" && grep -q '\[ -L "\$dest" \]' "$PROV" &&
  ok "provisioning validates the dir chain, refuses symlink leaves, installs via rename" ||
  ko "provisioning region misses validation/atomic-install primitives"

# --- sandbox plumbing -----------------------------------------------------------
make_sandbox() { # $1 = sandbox dir
  local sb=$1
  mkdir -p "$sb/bin"
  : >"$sb/stat.map"
  : >"$sb/stat-queries.log"
  cat >"$sb/bin/stubstat" <<'STUB'
#!/usr/bin/env bash
# stat(1) with a foreign-owner override map
# (path<TAB>owner<TAB>gid[<TAB>mode]; a mapped mode models ownership the
# invoking user cannot really create, e.g. a root-owned 0755 ancestor chain
# for the default trust-base tests) and a QUERY LOG so the harness can prove
# which components the audit actually examined — the independent review's
# core complaint was that the production-default audit examined NOTHING.
set -u
map_file="${SB_STAT_MAP:?}"
log_file="${SB_STAT_LOG:-/dev/null}"
args=("$@")
path="${args[$(( ${#args[@]} - 1 ))]}"
printf '%s\n' "$path" >>"$log_file"
fmt=""
i=0
while [ "$i" -lt "${#args[@]}" ]; do
  [ "${args[$i]}" = "-c" ] && fmt="${args[$((i + 1))]}"
  i=$((i + 1))
done
real=$(/usr/bin/stat -c "${fmt:-%N}" -- "$path" 2>/dev/null) || exit 1
line=$(awk -v p="$path" -F'\t' '$1 == p { print; exit }' "$map_file" 2>/dev/null)
if [ -n "$line" ]; then
  owner=$(printf '%s' "$line" | cut -f2)
  gid=$(printf '%s' "$line" | cut -f3)
  mapped_mode=$(printf '%s' "$line" | cut -f4)
  real_mode=$(/usr/bin/stat -c '%a' -- "$path")
  case "$fmt" in
    '%U %g %a') printf '%s %s %s\n' "$owner" "$gid" "${mapped_mode:-$real_mode}";;
    '%U') printf '%s\n' "$owner";;
    '%g') printf '%s\n' "$gid";;
    '%a') printf '%s\n' "${mapped_mode:-$real_mode}";;
    *) printf '%s\n' "$real";;
  esac
else
  printf '%s\n' "$real"
fi
STUB
  cat >"$sb/bin/stubchown" <<'STUB'
#!/usr/bin/env bash
# chown is a recorded no-op in this unprivileged sandbox.
printf 'chown %s\n' "$*" >>"${CHOWN_LOG:?}"
exit 0
STUB
  chmod +x "$sb/bin/stubstat" "$sb/bin/stubchown"
}

run_prov() { # $1 = sandbox dir; [$2 = "noacl"]; runs the GENERATED provisioning region; rc → PROV_RC
  local sb=$1 noacl=${2:-}
  (export HELPERS_DIR="$sb/helpers"
   export TRUST_OWNER TRUST_GROUP_ID TRUST_BASE
   export STAT_BIN="$sb/bin/stubstat" CHOWN_BIN="$sb/bin/stubchown" CHMOD_BIN=chmod
   if [ -n "$noacl" ]; then
     # Default-chain runs traverse REAL distro ancestors whose ACLs cannot be
     # modeled by the stub map; the mode-bit rules (the load-bearing refusal
     # surface) still run for real. Custom-base sandbox runs keep real ACL
     # checks when getfacl is available.
     export GETFACL_BIN=/nonexistent
   elif command -v getfacl >/dev/null 2>&1; then export GETFACL_BIN=getfacl; else export GETFACL_BIN=/nonexistent; fi
   export SB_STAT_MAP="$sb/stat.map" CHOWN_LOG="$sb/chown.log" SB_STAT_LOG="$sb/stat-queries.log"
   bash -e "$PROV") >"$sb/out.txt" 2>"$sb/err.txt"
  PROV_RC=$?
}

new_sb() { # $1 = name — custom trust base (the sandbox), the P1–N6 regression layout
  SB=$WORK/$1
  rm -rf "$SB"
  mkdir -p "$SB"
  make_sandbox "$SB"
  TRUST_OWNER=$(id -un)
  TRUST_GROUP_ID=$(id -g)
  TRUST_BASE=$SB
}

new_sb_root() { # $1 = name [$2 = explicit base; empty = UNSET → the production default (/)]
  new_sb "$1"
  TRUST_BASE=${2:-}
}

# Model the sandbox's REAL ancestor chain as a trusted root-owned 0755
# layout the way production's /usr/local/lib is: the stub map overrides
# owner AND mode, so the unprivileged harness can exercise the default
# trust-base walk against real filesystem paths. EVERY component of the
# workdir's real chain is mapped (walked with dirname, exactly what the
# audit will visit), so the fixture is independent of the host's layout.
map_default_chain_trusted() { # $1 = sandbox dir
  local sb=$1
  local p=$sb
  : >"$sb/stat.map" # rebuild deterministically from the leaf upward
  while :; do
    printf '%s\t%s\t%s\t755\n' "$p" "$(id -un)" "$(id -g)" >>"$sb/stat.map"
    [ "$p" = "/" ] && break
    p=$(dirname "$p")
  done
}
chain_of() { # $1 = path → print every component from $1 up to and including /
  local p=$1
  while :; do
    printf '%s\n' "$p"
    [ "$p" = "/" ] && break
    p=$(dirname "$p")
  done
}

# --- P1: pristine install -------------------------------------------------------
new_sb p1_pristine
run_prov "$SB"
assert_eq "P1 provisioning succeeds on a pristine sandbox" 0 "$PROV_RC"
assert_eq "P1 probe payload matches source" "$(cat "$ROOT/scripts/host/imds-probe.sh")" "$(cat "$SB/helpers/imds-probe.sh")"
assert_eq "P1 guard payload matches source" "$(cat "$ROOT/scripts/host/imds-guard.sh")" "$(cat "$SB/helpers/imds-guard.sh")"
assert_eq "P1 probe mode 0755" "755" "$(/usr/bin/stat -c '%a' "$SB/helpers/imds-probe.sh")"
assert_eq "P1 guard mode 0755" "755" "$(/usr/bin/stat -c '%a' "$SB/helpers/imds-guard.sh")"
assert_eq "P1 helpers dir mode 0755" "755" "$(/usr/bin/stat -c '%a' "$SB/helpers")"
[ "$(grep -c 'root:root' "$SB/chown.log")" = "2" ] &&
  ok "P1 both helpers chowned root:root (recorded)" ||
  ko "P1 both helpers chowned root:root (got: $(cat "$SB/chown.log"))"
[ -z "$(find "$SB/helpers" -name '.*.tmp.*' -print -quit)" ] &&
  ok "P1 no staging leftovers" || ko "P1 no staging leftovers"

# --- P2: idempotent redeploy ----------------------------------------------------
run_prov "$SB"
assert_eq "P2 redeploy succeeds over existing root-owned helpers" 0 "$PROV_RC"
assert_eq "P2 guard payload still correct" "$(cat "$ROOT/scripts/host/imds-guard.sh")" "$(cat "$SB/helpers/imds-guard.sh")"

# --- N1: dangling final symlink refused, target never created -------------------
rm -f "$SB/helpers/imds-probe.sh"
ln -s "$SB/helpers/never-exists" "$SB/helpers/imds-probe.sh"
cp "$SB/helpers/imds-guard.sh" "$SB/guard.before"
run_prov "$SB"
[ "$PROV_RC" -ne 0 ] && ok "N1 dangling symlink refused" || ko "N1 dangling symlink refused (exit 0)"
[ -L "$SB/helpers/imds-probe.sh" ] && [ ! -e "$SB/helpers/imds-probe.sh" ] &&
  ok "N1 dangling symlink preserved (nothing materialised through it)" ||
  ko "N1 dangling symlink preserved"
assert_eq "N1 sibling helper untouched" "$(cat "$SB/guard.before")" "$(cat "$SB/helpers/imds-guard.sh")"

# --- N2: symlink to a victim file refused; victim bytes/owner/mode intact -------
VICTIM=$WORK/victim-file
printf 'VICTIM CONTENT — must stay byte-identical\n' >"$VICTIM"
chmod 0640 "$VICTIM"
rm -f "$SB/helpers/imds-guard.sh"
ln -s "$VICTIM" "$SB/helpers/imds-guard.sh"
run_prov "$SB"
[ "$PROV_RC" -ne 0 ] && ok "N2 symlinked helper destination refused" || ko "N2 symlinked helper destination refused (exit 0)"
assert_eq "N2 victim bytes preserved" "VICTIM CONTENT — must stay byte-identical" "$(cat "$VICTIM")"
assert_eq "N2 victim mode preserved" "640" "$(/usr/bin/stat -c '%a' "$VICTIM")"
assert_eq "N2 victim owner preserved" "$(id -un)" "$(/usr/bin/stat -c '%U' "$VICTIM")"
[ -L "$SB/helpers/imds-guard.sh" ] && ok "N2 symlink not followed/replaced" || ko "N2 symlink not followed/replaced"

# --- N3: group-writable helpers dir refused; planted file intact ----------------
new_sb n3_writable_dir
mkdir -p "$SB/helpers"
chmod 0775 "$SB/helpers"
printf 'PLANTED\n' >"$SB/helpers/imds-guard.sh"
chmod 0755 "$SB/helpers/imds-guard.sh"
run_prov "$SB"
[ "$PROV_RC" -ne 0 ] && ok "N3 group-writable helpers dir refused" || ko "N3 group-writable helpers dir refused (exit 0)"
assert_eq "N3 helpers dir mode NOT mutated" "775" "$(/usr/bin/stat -c '%a' "$SB/helpers")"
assert_eq "N3 planted helper bytes preserved" "PLANTED" "$(cat "$SB/helpers/imds-guard.sh")"
assert_eq "N3 planted helper mode preserved" "755" "$(/usr/bin/stat -c '%a' "$SB/helpers/imds-guard.sh")"

# --- N4: foreign-owned existing helper refused (tamper evidence) -----------------
new_sb n4_foreign_helper
mkdir -p "$SB/helpers"
printf 'INTRUDER PAYLOAD\n' >"$SB/helpers/imds-probe.sh"
chmod 0755 "$SB/helpers/imds-probe.sh"
printf '%s\tintruder\t9999\n' "$SB/helpers/imds-probe.sh" >"$SB/stat.map"
run_prov "$SB"
[ "$PROV_RC" -ne 0 ] && ok "N4 foreign-owned helper refused" || ko "N4 foreign-owned helper refused (exit 0)"
assert_eq "N4 intruder bytes preserved (never blessed with chown)" "INTRUDER PAYLOAD" "$(cat "$SB/helpers/imds-probe.sh")"

# --- N5: symlinked helpers dir refused; target dir untouched ---------------------
new_sb n5_symlinked_dir
mkdir -p "$SB/evil-place"
chmod 0777 "$SB/evil-place"
printf 'EVIL\n' >"$SB/evil-place/imds-guard.sh"
ln -s "$SB/evil-place" "$SB/helpers"
run_prov "$SB"
[ "$PROV_RC" -ne 0 ] && ok "N5 symlinked helpers dir refused" || ko "N5 symlinked helpers dir refused (exit 0)"
assert_eq "N5 evil target dir mode untouched" "777" "$(/usr/bin/stat -c '%a' "$SB/evil-place")"
assert_eq "N5 planted file bytes untouched" "EVIL" "$(cat "$SB/evil-place/imds-guard.sh")"

# --- N6: missing parent chain refused; nothing created above the leaf ------------
new_sb n6_missing_parent
DEEP_HELPERS="$SB/deep/nested/helpers"
(export HELPERS_DIR="$DEEP_HELPERS"
 export TRUST_OWNER TRUST_GROUP_ID TRUST_BASE
 export STAT_BIN="$SB/bin/stubstat" CHOWN_BIN="$SB/bin/stubchown" CHMOD_BIN=chmod
 export GETFACL_BIN=/nonexistent
 export SB_STAT_MAP="$SB/stat.map" CHOWN_LOG="$SB/chown.log" SB_STAT_LOG="$SB/stat-queries.log"
 bash -e "$PROV") >"$SB/out2.txt" 2>"$SB/err2.txt"
[ "$?" -ne 0 ] && ok "N6 missing parent chain refused" || ko "N6 missing parent chain refused (exit 0)"
[ ! -e "$SB/deep" ] && ok "N6 no ancestor was created" || ko "N6 no ancestor was created"

# =====================================================================================
# Default trust-base fidelity (independent committed review R2): the harness
# cases above set TRUST_BASE to the sandbox, which MASKED the production
# default — with TRUST_BASE=/ the old subtree pattern `//*` matched nothing,
# so /usr, /usr/local ... AND / itself were silently skipped and the entire
# parent owner/mode/ACL audit was vacuous. These cases run the EXACT
# generated region with the production default (TRUST_BASE unset), record
# which components the audit actually examined, and prove refusals happen
# BEFORE any mutation. Everything stays inside the sandbox: hostile modes are
# created under $SB only; the real ancestors are never modified (their owner/
# mode is only ever READ — directly or through the stub map).
provisioned_ok() { # $1 = sandbox dir — payload bytes landed for both helpers
  cmp -s "$ROOT/scripts/host/imds-probe.sh" "$1/helpers/imds-probe.sh" &&
    cmp -s "$ROOT/scripts/host/imds-guard.sh" "$1/helpers/imds-guard.sh"
}
queried_component() { # $1 = sandbox dir, $2 = path recorded as EXAMINED by the audit
  grep -Fxq -- "$2" "$1/stat-queries.log"
}

# --- P7: default base, pristine install; every chain component EXAMINED ----------
new_sb_root p7_default_base
map_default_chain_trusted "$SB"
run_prov "$SB" noacl
assert_eq "P7 pristine install succeeds with the production-default trust base" 0 "$PROV_RC"
provisioned_ok "$SB" && ok "P7 payloads installed under default base" || ko "P7 payloads installed under default base"
for comp in $(chain_of "$SB"); do
  queried_component "$SB" "$comp" &&
    ok "P7 audit examined $comp (component check recorded)" ||
    ko "P7 audit examined $comp (component check recorded)"
done
queried_component "$SB" "/" &&
  ok "P7 audit includes the ROOT directory itself" ||
  ko "P7 audit includes the ROOT directory itself"

# --- P8: default base, world-writable STICKY parent refused BEFORE any mutation --
new_sb_root p8_default_sticky_parent
map_default_chain_trusted "$SB"
mkdir -p "$SB/hosts-evil"
chmod 1777 "$SB/hosts-evil" # real sticky world-writable dir, INSIDE the sandbox only
(export HELPERS_DIR="$SB/hosts-evil/helpers"
 export TRUST_OWNER TRUST_GROUP_ID TRUST_BASE
 export STAT_BIN="$SB/bin/stubstat" CHOWN_BIN="$SB/bin/stubchown" CHMOD_BIN=chmod
 export GETFACL_BIN=/nonexistent
 export SB_STAT_MAP="$SB/stat.map" CHOWN_LOG="$SB/chown.log" SB_STAT_LOG="$SB/stat-queries.log"
 bash -e "$PROV") >"$SB/out.txt" 2>"$SB/err.txt"
[ "$?" -ne 0 ] && ok "P8 default base refuses world-writable sticky parent" || ko "P8 default base refuses world-writable sticky parent (exit 0)"
grep -q "world-writable" "$SB/err.txt" &&
  ok "P8 refusal names the world-writable component" ||
  ko "P8 refusal names the world-writable component (err: $(cat "$SB/err.txt"))"
[ ! -e "$SB/hosts-evil/helpers" ] &&
  ok "P8 refused BEFORE mkdir (no helpers dir created)" ||
  ko "P8 refused BEFORE mkdir (no helpers dir created)"
[ ! -s "$SB/chown.log" ] &&
  ok "P8 refused BEFORE any chown" ||
  ko "P8 refused BEFORE any chown ($(cat "$SB/chown.log" 2>/dev/null))"
assert_eq "P8 hostile parent mode NOT mutated" "1777" "$(/usr/bin/stat -c '%a' "$SB/hosts-evil")"

# --- P9: default base, unusable stat must refuse (the review's calibration) ------
new_sb_root p9_default_badstat
map_default_chain_trusted "$SB"
cp "$SB/bin/stubstat" "$SB/bin/stat.once"
cat >"$SB/bin/falsestat" <<'STUB'
#!/usr/bin/env bash
# models a broken/unusable stat: every query fails (the production-default
# audit MUST notice — the old default-base walk never called stat at all).
exit 1
STUB
chmod +x "$SB/bin/falsestat"
(export HELPERS_DIR="$SB/helpers"
 export TRUST_OWNER TRUST_GROUP_ID TRUST_BASE
 export STAT_BIN="$SB/bin/falsestat" CHOWN_BIN="$SB/bin/stubchown" CHMOD_BIN=chmod
 export GETFACL_BIN=/nonexistent
 export SB_STAT_MAP="$SB/stat.map" CHOWN_LOG="$SB/chown.log" SB_STAT_LOG="$SB/stat-queries.log"
 bash -e "$PROV") >"$SB/out.txt" 2>"$SB/err.txt"
[ "$?" -ne 0 ] && ok "P9 default base refuses when stat is unusable" || ko "P9 default base refuses when stat is unusable (exit 0)"
grep -q "cannot stat" "$SB/err.txt" &&
  ok "P9 refusal names the stat failure" ||
  ko "P9 refusal names the stat failure (err: $(cat "$SB/err.txt"))"
[ ! -e "$SB/helpers" ] &&
  ok "P9 refused BEFORE mkdir (no helpers dir created)" ||
  ko "P9 refused BEFORE mkdir (no helpers dir created)"
[ ! -s "$SB/chown.log" ] &&
  ok "P9 refused BEFORE any chown" ||
  ko "P9 refused BEFORE any chown ($(cat "$SB/chown.log" 2>/dev/null))"

# --- P10: explicit TRUST_BASE=/ behaves exactly like the default -----------------
new_sb_root p10_explicit_root "/"
map_default_chain_trusted "$SB"
run_prov "$SB" noacl
assert_eq "P10 explicit TRUST_BASE=/ install succeeds" 0 "$PROV_RC"
queried_component "$SB" "/" && ok "P10 explicit base audits / itself" || ko "P10 explicit base audits / itself"

# --- P11: invalid (relative/ambiguous) trust bases are refused -------------------
p11_no=0
for bad in "relative/path" "." ".."; do
  p11_no=$((p11_no + 1))
  new_sb_root "p11_badbase_$p11_no" "$bad"
  map_default_chain_trusted "$SB"
  run_prov "$SB" noacl
  [ "$PROV_RC" -ne 0 ] && ok "P11 trust base '$bad' refused" || ko "P11 trust base '$bad' refused (exit 0)"
  grep -q "TRUST_BASE" "$SB/err.txt" &&
    ok "P11 refusal names the invalid trust base '$bad'" ||
    ko "P11 refusal names the invalid trust base '$bad' (err: $(cat "$SB/err.txt"))"
  [ ! -s "$SB/chown.log" ] && ok "P11 '$bad' refused before any chown" || ko "P11 '$bad' refused before any chown"
done

# --- P12: base normalization — trailing slash and double slash -------------------
# NOTE: the base must be assigned AFTER new_sb_root — "$SB/" as a call
# argument would expand to the PREVIOUS case's sandbox.
new_sb_root p12_trailing_slash
TRUST_BASE="$SB/"
map_default_chain_trusted "$SB"
run_prov "$SB"
assert_eq "P12 trailing-slash base install succeeds (normalized)" 0 "$PROV_RC"
queried_component "$SB" "$SB" &&
  ok "P12 normalized base component itself audited" ||
  ko "P12 normalized base component itself audited"
new_sb_root p12_double_slash "//"
map_default_chain_trusted "$SB"
run_prov "$SB" noacl
assert_eq "P12 '//' base install succeeds (normalized to /)" 0 "$PROV_RC"
queried_component "$SB" "/" && ok "P12 '//' base audits / itself" || ko "P12 '//' base audits / itself"

# --- P13: root-owned world-writable STICKY helpers dir refused (custom base) -----
# 1757 is the precise old-code hole: world-writable + sticky with the group
# bits CLEAR — the old audit's group-write and sticky rules both let it pass.
new_sb p13_sticky_helpers_dir
for hm in 1757 1777; do
  rm -rf "$SB/helpers"; mkdir -p "$SB/helpers"
  chmod "$hm" "$SB/helpers"
  printf '%s\t%s\t%s\n' "$SB/helpers" "$(id -un)" "$(id -g)" >>"$SB/stat.map"
  run_prov "$SB"
  [ "$PROV_RC" -ne 0 ] && ok "P13 sticky world-writable helpers dir refused (mode $hm)" || ko "P13 sticky world-writable helpers dir refused (mode $hm) (exit 0)"
  grep -q "world-writable" "$SB/err.txt" &&
    ok "P13 refusal names the world-writable dir (mode $hm, sticky is no mitigation)" ||
    ko "P13 refusal names the world-writable dir (mode $hm; err: $(cat "$SB/err.txt"))"
  assert_eq "P13 helpers dir mode NOT mutated ($hm)" "$hm" "$(/usr/bin/stat -c '%a' "$SB/helpers")"
  [ -z "$(ls -A "$SB/helpers")" ] &&
    ok "P13 nothing written into the hostile dir ($hm)" ||
    ko "P13 nothing written into the hostile dir ($hm)"
  [ ! -s "$SB/chown.log" ] &&
    ok "P13 refused BEFORE any chown ($hm)" ||
    ko "P13 refused BEFORE any chown ($hm ($(cat "$SB/chown.log")))"
done

finish
