#!/usr/bin/env bash
# API regression harness for scripts/deploy.sh (no AWS, no SSM).
#
# A recorded fake `aws` shim stands in for the real CLI and replays scripted
# SSM get-command-invocation sequences, so the driver's contract is checked
# end to end against realistic API shapes:
#   * SendCommand receives STRING-ARRAY parameters (D7) — asserted on the
#     recorded --parameters JSON
#   * result verification reads StandardOutputContent (D7) and requires both
#     digests + version + health=ok + rollback=none
#   * InvocationDoesNotExist right after send-command is retried with a bound
#     (eventual consistency); AccessDenied/AuthorizationError fail fast (D7)
#   * digest-addressed uploads use IfNoneMatch:* — identical retries accepted,
#     conflicting content refused (D10)
#   * build/dist drift (manifest digests) fails before anything is uploaded
set -uo pipefail

ROOT=$(cd "$(dirname "$0")/../.." && pwd)
WORK=$(mktemp -d /tmp/gateway-deploy-api-harness.XXXXXX)
PASS=0
FAIL=0

note() { printf '[api-harness] %s\n' "$*"; }
ok() { PASS=$((PASS + 1)); printf '[api-harness] PASS: %s\n' "$1"; }
ko() { FAIL=$((FAIL + 1)); printf '[api-harness] FAIL: %s\n' "$1"; }
finish() {
  note "-----"
  note "passed=$PASS failed=$FAIL workdir=$WORK"
  [ "$FAIL" = 0 ] || exit 1
  exit 0
}
assert_eq() { if [ "$2" = "$3" ]; then ok "$1"; else ko "$1 (expected '$2' got '$3')"; fi; }
assert_contains() { if grep -qF -- "$2" "$3"; then ok "$1"; else ko "$1 (missing '$2' in $3)"; fi; }
assert_not_contains() { if grep -qF -- "$2" "$3"; then ko "$1 (unexpected '$2' in $3)"; else ok "$1"; fi; }

FAKE=$WORK/bin
mkdir -p "$FAKE"
cat >"$FAKE/aws" <<'STUB'
#!/usr/bin/env bash
set -uo pipefail
FA="${FAKE_AWS_DIR:?}"
printf '%s\n' "$*" >>"$FA/calls.log"
# The real CLI accepts global options (--region) before the API call; find
# the first two NON-option tokens (skipping their values) to dispatch on.
args=(); prev_opt=0
for a in "$@"; do
  if [ "$prev_opt" = 1 ]; then prev_opt=0; continue; fi
  case "$a" in -*) prev_opt=1; continue;; esac
  args+=("$a")
done
dispatch="${args[0]:-} ${args[1]:-}"
opt_of() { local want=$1 prev="" v=""; shift; for a in "$@"; do [ "$prev" = "$want" ] && v=$a; prev=$a; done; printf '%s' "$v"; }
case "$dispatch" in
  "sts get-caller-identity") echo '{"Account":"000000000000","Arn":"arn:aws:iam::000000000000:assumed-role/harness/session"}';;
  "s3api put-object")
    key=$(opt_of --key "" "$@"); body=$(opt_of --body "" "$@")
    if [ -e "$FA/bucket/$key" ]; then
      echo "An error occurred (PreconditionFailed) when calling the PutObject operation: At least one of the pre-conditions did not pass" >&2
      exit 254
    fi
    mkdir -p "$FA/bucket/$(dirname "$key")"; cp "$body" "$FA/bucket/$key"
    echo '{"ETag":"\"new\""}';;
  "s3api get-object")
    key=$(opt_of --key "" "$@"); out="${*: -1}"
    if [ ! -f "$FA/bucket/$key" ]; then
      echo "An error occurred (NoSuchKey) when calling the GetObject operation" >&2; exit 254
    fi
    cp "$FA/bucket/$key" "$out"; echo '{}';;
  "ssm describe-document")
    if [ -f "$FA/describe-denied" ]; then echo 'AccessDeniedException' >&2; exit 254; fi
    if [ -f "$FA/document.json" ]; then cat "$FA/document.json"; else
      printf '{"Document":{"Name":"pocketshell-gateway-deploy","Owner":"817685572750","Status":"Active","DocumentType":"Command","DocumentVersion":"1","HashType":"Sha256","Hash":"%s"}}\n' "$(printf 'a%.0s' {1..64})"
    fi;;
  "ssm send-command")
    comment=$(opt_of --comment "" "$@")
    printf '%s' "$comment" >"$FA/send-comment.txt"
    if [ "${#comment}" -gt 100 ]; then
      echo 'ValidationException: Comment exceeds maximum length 100' >&2
      exit 254
    fi
    printf '%s\n' "$(opt_of --parameters "" "$@")" >"$FA/send-params.json"
    echo '{"Command":{"CommandId":"cid-1234-5678"}}';;
  "ssm get-command-invocation")
    # deploy.sh re-queries after the terminal status (display + verification),
    # so an exhausted sequence replays the LAST step instead of failing.
    if [ -s "$FA/inv-sequence" ]; then
      step=$(head -1 "$FA/inv-sequence"); tail -n +2 "$FA/inv-sequence" >"$FA/inv-sequence.next"; mv "$FA/inv-sequence.next" "$FA/inv-sequence"
      printf '%s\n' "$step" >"$FA/last-step"
    elif [ -f "$FA/last-step" ]; then
      step=$(cat "$FA/last-step")
    else
      echo "sequence exhausted" >&2; exit 254
    fi
    case "$step" in
      # PENDING must go through the same --query plumbing as SUCCESS/FAILED
      # (deploy.sh polls with the @tsv query): set resp, never echo.
      PENDING) resp='{"Status":"InProgress","StandardOutputContent":"","StandardErrorContent":""}';;
      DOESNOTEXIST) echo "An error occurred (InvocationDoesNotExist) when calling the GetCommandInvocation operation" >&2; exit 254;;
      DENIED) echo "An error occurred (AccessDeniedException) when calling the GetCommandInvocation operation: User is not authorized" >&2; exit 254;;
      SUCCESS*) f=${step#SUCCESS }; resp=$(jq -rn --arg o "$(cat "$f")" '{Status:"Success",StandardOutputContent:$o,StandardErrorContent:""}');;
      FAILED*) f=${step#FAILED }; resp=$(jq -rn --arg o "$(cat "$f")" '{Status:"Failed",StandardOutputContent:$o,StandardErrorContent:"boom"}');;
      *) echo "unknown sequence step: $step" >&2; exit 254;;
    esac
    # Honor the two --query shapes scripts/deploy.sh uses, like the real CLI.
    q=$(opt_of --query "" "$@")
    case "$q" in
      StandardOutputContent) printf '%s' "$resp" | jq -r '.StandardOutputContent';;
      *Status*) printf '%s' "$resp" | jq -r '[.Status,.StandardOutputContent,.StandardErrorContent] | @tsv';;
      *) printf '%s\n' "$resp";;
    esac;;
  *) echo "stub aws: unknown args: $*" >&2; exit 64;;
esac
STUB
chmod +x "$FAKE/aws"

SANDBOX() { # $1 = name
  SB=$WORK/$1
  rm -rf "$SB"
  mkdir -p "$SB/bin" "$SB/dist"
  export FAKE_AWS_DIR=$SB/fake
  mkdir -p "$FAKE_AWS_DIR/bucket"
  : >"$FAKE_AWS_DIR/calls.log"
  export PATH="$FAKE:$PATH"
  # fast, bounded polling for tests
  export DEPLOY_POLL_ATTEMPTS=6
  export DEPLOY_POLL_SLEEP=0.05
}

instance_output() { # $1=archive sha $2=binary sha $3=version -> healthy instance output
  printf '%s' "$INST_OK" | sed -e "s/__ARCHIVE__/$1/" -e "s/__BINARY__/$2/" -e "s/__VERSION__/$3/" -e "s/__REVISION__/$FIXREV/"
}
# The revision deploy.sh sends (--revision, passed EXPLICITLY so the harness
# is independent of the checkout being a git repository) and the instance
# must confirm as commit= (D8), next to healthz=ok, the ACTIVATION result
# lines (registry/tunnel enabled — the carried activation contract) and the
# imds= strategy line the installer now reports.
FIXREV=$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || printf '0000000000000000000000000000000000000000')
INST_OK='sha256=__ARCHIVE__
binary-sha256=__BINARY__
version=__VERSION__
commit=__REVISION__
healthz=ok
registry=enabled
tunnel=enabled
imds=systemd
health=ok
rollback=none
previous=none
'

# Fixture build/dist: a real gzip so unpack+digest checks run for real.
printf 'fake gateway payload %s\n' "$(date +%s)" >"$WORK/payload.bin"
DIST() { # refresh $SB/dist from the base payload
  gzip -n -9 -c "$WORK/payload.bin" >"$SB/dist/gateway-linux-arm64.gz"
}
archive_sha() { sha256sum "$1" | awk '{print $1}'; }
binary_sha() { gzip -dc "$1" | sha256sum | awk '{print $1}'; }

write_dist_meta() { # $1=version  — writes VERSION+manifest with CORRECT digests
  local ver=$1 asha bsha
  asha=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
  bsha=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
  printf '%s\n' "$ver" >"$SB/dist/VERSION"
  printf '{"archive_sha256":"%s","binary_sha256":"%s","version":"%s","source_revision":"0000000000000000000000000000000000000000","domain":"gateway.pocketshell.io","aliases":"relay.pocketshell.io","service":"pocketshell-relay","certdir":"/var/lib/pocketshell-relay","registry":"/var/lib/pocketshell-relay/registry/devices.json","built_at":"harness"}\n' \
    "$asha" "$bsha" "$ver" >"$SB/dist/manifest.json"
}

do_deploy() { # $1=version extra args after
  local ver=$1
  shift
  "$ROOT/scripts/deploy.sh" \
    --region eu-west-1 \
    --bucket test-bucket \
    --instance-id i-0f9c18ce63cf6c26e \
    --document arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-deploy \
    --document-owner 817685572750 \
    --document-version 1 \
    --document-sha256 "$(printf 'a%.0s' {1..64})" \
    --artifact-dir "$SB/dist" \
    --version "$ver" \
    --revision "$FIXREV" \
    "$@" >"$SB/out.txt" 2>"$SB/err.txt"
}

# =============================================================================
SANDBOX t1_happy_path
DIST
write_dist_meta git-abc123
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
instance_output "$ASHA" "$BSHA" git-abc123 >"$WORK/good.txt"
printf 'DOESNOTEXIST\nDOESNOTEXIST\nPENDING\nSUCCESS %s\n' "$WORK/good.txt" >"$FAKE_AWS_DIR/inv-sequence"
do_deploy git-abc123
assert_eq "t1 exit 0" 0 $?
assert_contains "t1 DEPLOY OK" "DEPLOY OK" "$SB/out.txt"
# SendCommand parameters must be string arrays (D7)
jq -e 'to_entries | all(.value | type == "array" and length == 1 and (.[0] | type == "string"))' \
  "$FAKE_AWS_DIR/send-params.json" >/dev/null 2>&1 &&
  ok "t1 SSM parameters are string arrays" || ko "t1 SSM parameters are string arrays"
jq -e '.ExpectedSHA256[0] == "'"$ASHA"'" and .BinarySHA256[0] == "'"$BSHA"'" and .ArtifactPath[0] == "artifacts/'"$ASHA"'/gateway-linux-arm64.gz"' \
  "$FAKE_AWS_DIR/send-params.json" >/dev/null 2>&1 &&
  ok "t1 parameters bind path to archive digest and carry binary digest" || ko "t1 parameters bind path/carried digests"
# The activation configuration is carried EXPLICITLY with every deploy and
# bound to the digest-checked manifest values.
jq -e '.CertDir[0] == "/var/lib/pocketshell-relay" and .RegistryFile[0] == "/var/lib/pocketshell-relay/registry/devices.json"' \
  "$FAKE_AWS_DIR/send-params.json" >/dev/null 2>&1 &&
  ok "t1 activation configuration carried (CertDir base + registry FILE)" || ko "t1 activation configuration carried (CertDir base + registry FILE)"
jq -e '.certdir == "/var/lib/pocketshell-relay" and .registry == "/var/lib/pocketshell-relay/registry/devices.json"' \
  "$SB/dist/manifest.json" >/dev/null 2>&1 &&
  ok "t1 manifest binds the activation configuration" || ko "t1 manifest binds the activation configuration"
# uploads used IfNoneMatch (D10)
grep -q -- '--if-none-match \*' "$FAKE_AWS_DIR/calls.log" && ok "t1 conditional uploads (IfNoneMatch)" || ko "t1 conditional uploads (IfNoneMatch)"
[ "$(grep -c 'put-object' "$FAKE_AWS_DIR/calls.log")" = 4 ] && ok "t1 archive+VERSION+manifest+sha256sums uploaded" || ko "t1 four objects uploaded (got $(grep -c 'put-object' "$FAKE_AWS_DIR/calls.log"))"
# document+instance pinned in the call
grep -q -- '--document-name arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-deploy' "$FAKE_AWS_DIR/calls.log" && ok "t1 pinned document" || ko "t1 pinned document"
grep -q -- '--instance-ids i-0f9c18ce63cf6c26e' "$FAKE_AWS_DIR/calls.log" && ok "t1 pinned instance" || ko "t1 pinned instance"
[ "$(grep -c 'InvocationDoesNotExist' "$FAKE_AWS_DIR/calls.log" )" = 0 ] && ok "t1 (no direct reliance on log)" || true

# =============================================================================
SANDBOX t2_conflicting_object_refused
DIST
write_dist_meta git-abc123
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
mkdir -p "$FAKE_AWS_DIR/bucket/artifacts/$ASHA"
printf 'TAMPERED-EXISTING-CONTENT\n' >"$FAKE_AWS_DIR/bucket/artifacts/$ASHA/gateway-linux-arm64.gz"
printf 'DOESNOTEXIST\nSUCCESS /dev/null\n' >"$FAKE_AWS_DIR/inv-sequence"
do_deploy git-abc123
assert_eq "t2 conflict exit 1" 1 $?
assert_contains "t2 conflict refused" "CONFLICT" "$SB/err.txt"
grep -q 'send-command' "$FAKE_AWS_DIR/calls.log" && ko "t2 no SSM command after conflict" || ok "t2 no SSM command after conflict"

# =============================================================================
SANDBOX t3_identical_retry_accepted
DIST
write_dist_meta git-abc123
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
mkdir -p "$FAKE_AWS_DIR/bucket/artifacts/$ASHA"
cp "$SB/dist/gateway-linux-arm64.gz" "$FAKE_AWS_DIR/bucket/artifacts/$ASHA/gateway-linux-arm64.gz"
instance_output "$ASHA" "$BSHA" git-abc123 >"$WORK/good.txt"
printf 'SUCCESS %s\n' "$WORK/good.txt" >"$FAKE_AWS_DIR/inv-sequence"
do_deploy git-abc123
assert_eq "t3 identical retry exit 0" 0 $?
assert_contains "t3 retry accepted" "identical retry accepted" "$SB/out.txt"

# =============================================================================
SANDBOX t4_permanent_api_error_fails_fast
DIST
write_dist_meta git-abc123
printf 'DENIED\nDENIED\nDENIED\n' >"$FAKE_AWS_DIR/inv-sequence"
start=$(date +%s%N)
do_deploy git-abc123
rc=$?
elapsed_ms=$(( ($(date +%s%N) - start) / 1000000 ))
assert_eq "t4 permanent error exit 1" 1 "$rc"
[ "$elapsed_ms" -lt 5000 ] && ok "t4 failed fast (${elapsed_ms}ms, no retry storm)" || ko "t4 failed fast (${elapsed_ms}ms)"
assert_contains "t4 clear permanent-error message" "permanent SSM API error" "$SB/err.txt"

# =============================================================================
SANDBOX t5_eventual_consistency_bounded
DIST
write_dist_meta git-abc123
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
instance_output "$ASHA" "$BSHA" git-abc123 >"$WORK/good.txt"
: >"$FAKE_AWS_DIR/inv-sequence"
for _ in $(seq 1 60); do echo DOESNOTEXIST >>"$FAKE_AWS_DIR/inv-sequence"; done
# generous attempt budget so the InvocationDoesNotExist BOUND (30) is what
# stops the poll, not the attempt cap
DEPLOY_POLL_ATTEMPTS=60 DEPLOY_POLL_SLEEP=0.02 do_deploy git-abc123
assert_eq "t5 bounded abort exit 1" 1 $?
assert_contains "t5 bounded abort message" "still unknown after" "$SB/err.txt"

# =============================================================================
SANDBOX t6_instance_refuses_version
DIST
write_dist_meta git-abc123
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
instance_output "$ASHA" "$BSHA" git-DIFFERENT >"$WORK/bad-ver.txt"
printf 'SUCCESS %s\n' "$WORK/bad-ver.txt" >"$FAKE_AWS_DIR/inv-sequence"
do_deploy git-abc123
assert_eq "t6 version echo mismatch exit 1" 1 $?
assert_contains "t6 version echo mismatch message" "did not confirm version" "$SB/err.txt"

# =============================================================================
SANDBOX t7_rolledback_deploy_is_red
DIST
write_dist_meta git-abc123
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
# Rolled-back instance output, in the EXACT shape the installer's do_rollback
# prints (commit echoes the attempted revision; healthz may only say legacy;
# imds=unchanged) — deploy.sh must still demand the commit confirmation
# before it accepts the rollback framing.
printf 'sha256=%s\nbinary-sha256=%s\nversion=git-abc123\ncommit=%s\nhealthz=legacy\nimds=unchanged\nhealth=failed\nrollback=ok\nprevious=deadbeef\n' "$ASHA" "$BSHA" "$FIXREV" >"$WORK/rb.txt"
printf 'SUCCESS %s\n' "$WORK/rb.txt" >"$FAKE_AWS_DIR/inv-sequence"
do_deploy git-abc123
assert_eq "t7 rolled-back deploy fails CI" 1 $?
assert_contains "t7 rollback message" "rolled back" "$SB/err.txt"

# =============================================================================
SANDBOX t8_terminal_failed_status
DIST
write_dist_meta git-abc123
printf 'sha-does-not-matter\n' >"$WORK/fail.txt"
printf 'FAILED %s\n' "$WORK/fail.txt" >"$FAKE_AWS_DIR/inv-sequence"
do_deploy git-abc123
assert_eq "t8 Failed status exit 1" 1 $?
assert_contains "t8 terminal status message" "terminal status: Failed" "$SB/err.txt"

# =============================================================================
SANDBOX t9_build_dist_drift_rejected
DIST
write_dist_meta git-abc123
printf 'x' >>"$SB/dist/gateway-linux-arm64.gz" # drift after manifest was written
printf 'SUCCESS /dev/null\n' >"$FAKE_AWS_DIR/inv-sequence"
do_deploy git-abc123
assert_eq "t9 drift exit 1" 1 $?
assert_contains "t9 drift message" "drift" "$SB/err.txt"
grep -q 'put-object' "$FAKE_AWS_DIR/calls.log" && ko "t9 nothing uploaded after drift" || ok "t9 nothing uploaded after drift"

# Metadata must match all reviewed inputs BEFORE any Put or Send.
for field in Name Owner Status DocumentType DocumentVersion HashType Hash; do
  SANDBOX "t10_bad_$field"
  DIST
  write_dist_meta git-abc123
  jq -n --arg field "$field" --arg hash "$(printf 'a%.0s' {1..64})" \
    '{Document:{Name:"pocketshell-gateway-deploy",Owner:"817685572750",Status:"Active",DocumentType:"Command",DocumentVersion:"1",HashType:"Sha256",Hash:$hash}} | .Document[$field]="wrong"' >"$FAKE_AWS_DIR/document.json"
  do_deploy git-abc123
  assert_eq "t10 $field mismatch refused" 1 $?
  assert_not_contains "t10 $field no Put" "put-object" "$FAKE_AWS_DIR/calls.log"
  assert_not_contains "t10 $field no Send" "send-command" "$FAKE_AWS_DIR/calls.log"
done
for mode in malformed denied; do
  SANDBOX "t11_$mode"
  DIST
  write_dist_meta git-abc123
  if [ "$mode" = denied ]; then touch "$FAKE_AWS_DIR/describe-denied"; else printf '{bad' >"$FAKE_AWS_DIR/document.json"; fi
  do_deploy git-abc123
  assert_eq "t11 $mode refused" 1 $?
  assert_not_contains "t11 $mode no Put" "put-object" "$FAKE_AWS_DIR/calls.log"
  assert_not_contains "t11 $mode no Send" "send-command" "$FAKE_AWS_DIR/calls.log"
done
SANDBOX t12_explicit_pin_success
DIST
write_dist_meta git-abc123
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
instance_output "$ASHA" "$BSHA" git-abc123 >"$SB/good.txt"
printf 'SUCCESS %s\n' "$SB/good.txt" >"$FAKE_AWS_DIR/inv-sequence"
do_deploy git-abc123
assert_eq "t12 pinned success" 0 $?
assert_contains "t12 Describe version pinned" "ssm describe-document --name arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-deploy --document-version 1" "$FAKE_AWS_DIR/calls.log"
assert_contains "t12 Send version/hash pins" "--document-version 1 --document-hash $(printf 'a%.0s' {1..64}) --document-hash-type Sha256" "$FAKE_AWS_DIR/calls.log"
first_write=$(grep -n 'put-object' "$FAKE_AWS_DIR/calls.log" | head -1 | cut -d: -f1)
first_describe=$(grep -n 'describe-document' "$FAKE_AWS_DIR/calls.log" | head -1 | cut -d: -f1)
[ "$first_describe" -lt "$first_write" ] && ok "t12 preflight precedes first Put" || ko "t12 preflight precedes first Put"
for flag in --document-version --document-sha256 --document-owner; do
  SANDBOX "t13_bad_${flag#--}"
  DIST
  write_dist_meta git-abc123
  do_deploy git-abc123 "$flag" ''
  assert_eq "t13 empty $flag refused" 1 $?
  [ ! -s "$FAKE_AWS_DIR/calls.log" ] && ok "t13 empty $flag no AWS effect" || ko "t13 empty $flag no AWS effect"
done

# Actual full-ARN DescribeDocument framing from parent receipt dbcc29b1.
# Existing t1/t12 basename framing remains unchanged and accepted.
SANDBOX t14_actual_full_arn_framing
DIST
write_dist_meta git-abc123
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
instance_output "$ASHA" "$BSHA" git-abc123 >"$SB/good.txt"
printf 'SUCCESS %s\n' "$SB/good.txt" >"$FAKE_AWS_DIR/inv-sequence"
printf '%s\n' '{"Document":{"DocumentType":"Command","DocumentVersion":"4","Hash":"b342b7626d9ae961008feb59cac83f03829b4fac4ff8dfb00fb15dac70bc4258","HashType":"Sha256","Name":"arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-deploy","Owner":"817685572750","Status":"Active"}}' >"$FAKE_AWS_DIR/document.json"
do_deploy git-abc123 --document-version 4 --document-sha256 b342b7626d9ae961008feb59cac83f03829b4fac4ff8dfb00fb15dac70bc4258
assert_eq "t14 actual full ARN framing accepted" 0 $?
assert_contains "t14 exact full ARN Send" "--document-name arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-deploy" "$FAKE_AWS_DIR/calls.log"
assert_contains "t14 reviewed actual version/hash Send" "--document-version 4 --document-hash b342b7626d9ae961008feb59cac83f03829b4fac4ff8dfb00fb15dac70bc4258 --document-hash-type Sha256" "$FAKE_AWS_DIR/calls.log"
# The retired v3/1dcd0c2a pin must fail closed against the actual v4 metadata.
SANDBOX t14b_retired_v3_pin_refused
DIST
write_dist_meta git-abc123
printf '%s\n' '{"Document":{"DocumentType":"Command","DocumentVersion":"4","Hash":"b342b7626d9ae961008feb59cac83f03829b4fac4ff8dfb00fb15dac70bc4258","HashType":"Sha256","Name":"arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-deploy","Owner":"817685572750","Status":"Active"}}' >"$FAKE_AWS_DIR/document.json"
do_deploy git-abc123 --document-version 3 --document-sha256 1dcd0c2af23c74e3a8cf323fda6073bc610d21b3a0572c42336e93bb1e2235a9
assert_eq "t14b retired v3 pin refused" 1 $?
assert_not_contains "t14b retired v3 pin no Put" "put-object" "$FAKE_AWS_DIR/calls.log"
assert_not_contains "t14b retired v3 pin no Send" "send-command" "$FAKE_AWS_DIR/calls.log"
# Refuse all other names: no suffix matching or response-learned identity.
for name in pocketshell-gateway-other arn:aws:ssm:eu-west-1:000000000000:document/pocketshell-gateway-deploy arn:aws:ssm:us-east-1:817685572750:document/pocketshell-gateway-deploy arn:aws:ssm:eu-west-1:817685572750:document/pocketshell-gateway-other; do
  SANDBOX t15_wrong_name
  DIST
  write_dist_meta git-abc123
  jq -n --arg name "$name" --arg hash "$(printf 'a%.0s' {1..64})" \
    '{Document:{Name:$name,Owner:"817685572750",Status:"Active",DocumentType:"Command",DocumentVersion:"1",HashType:"Sha256",Hash:$hash}}' >"$FAKE_AWS_DIR/document.json"
  do_deploy git-abc123
  assert_eq "t15 nonexact Name refused" 1 $?
  assert_not_contains "t15 nonexact Name no Put" "put-object" "$FAKE_AWS_DIR/calls.log"
  assert_not_contains "t15 nonexact Name no Send" "send-command" "$FAKE_AWS_DIR/calls.log"
done

# Provider enforces Comment <=100 even for the longest accepted version.
# Full SHA256 digests/revision stay in authoritative parameters, not the comment.
SANDBOX t16_comment_provider_limit
DIST
LONG_VERSION=$(printf 'v%.0s' {1..64})
write_dist_meta "$LONG_VERSION"
ASHA=$(archive_sha "$SB/dist/gateway-linux-arm64.gz")
BSHA=$(binary_sha "$SB/dist/gateway-linux-arm64.gz")
instance_output "$ASHA" "$BSHA" "$LONG_VERSION" >"$SB/good.txt"
printf 'SUCCESS %s\n' "$SB/good.txt" >"$FAKE_AWS_DIR/inv-sequence"
do_deploy "$LONG_VERSION"
assert_eq "t16 max-version provider accepts comment" 0 $?
comment=$(cat "$FAKE_AWS_DIR/send-comment.txt")
[ "${#comment}" -le 100 ] && ok "t16 comment provider bound" || ko "t16 comment provider bound"
jq -e --arg archive "$ASHA" --arg binary "$BSHA" --arg version "$LONG_VERSION" --arg revision "$FIXREV" \
  '.ExpectedSHA256[0] == $archive and .BinarySHA256[0] == $binary and .Version[0] == $version and .Revision[0] == $revision and .ArtifactPath[0] == "artifacts/" + $archive + "/gateway-linux-arm64.gz"' \
  "$FAKE_AWS_DIR/send-params.json" >/dev/null 2>&1 && ok "t16 full digest/version/revision parameters unchanged" || ko "t16 full digest/version/revision parameters unchanged"
assert_contains "t16 full document integrity pins unchanged" "--document-version 1 --document-hash $(printf 'a%.0s' {1..64}) --document-hash-type Sha256" "$FAKE_AWS_DIR/calls.log"
finish
