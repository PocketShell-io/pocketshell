"""Execute actual workflow shell blocks; these fixtures are not live AWS proof."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import yaml

WORKFLOW = Path(__file__).resolve().parents[2] / '.github/workflows/oidc-result-preflight.yml'
DOC = yaml.load(WORKFLOW.read_text(), Loader=yaml.BaseLoader)
STEPS = DOC['jobs']['result-context']['steps']
COMMAND = '104ba941-344f-4fd6-b9cb-707c54488f28'
INSTANCE = 'i-0dee79146aceb4014'


class WorkflowBehavior(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        fake = self.root / 'aws'
        fake.write_text('''#!/usr/bin/python3
import json, os, pathlib, sys
a=sys.argv[1:]
assert not any(k in os.environ for k in ('BASH_ENV','ENV','AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN','AWS_PROFILE'))
assert not any(k.startswith('BASH_FUNC_') for k in os.environ)
assert a[a.index('--region')+1]=='eu-west-1'
assert a[a.index('--command-id')+1]=='104ba941-344f-4fd6-b9cb-707c54488f28'
assert a[a.index('--instance-id')+1]=='i-0dee79146aceb4014'
assert '--query' in a and '--debug' not in a and '--details' not in a
assert a[a.index('--cli-connect-timeout')+1]=='5'
assert a[a.index('--cli-read-timeout')+1]=='15'
action=a[a.index('ssm')+1]
assert action in ('get-command-invocation','list-command-invocations')
with open(os.environ['CALLS'],'a') as f: f.write(action+'\\n')
mode=os.environ.get('MODE','valid')
if mode==action+'-denied':
 print('AccessDenied',file=sys.stderr); sys.exit(7)
row={'CommandId':'104ba941-344f-4fd6-b9cb-707c54488f28','InstanceId':'i-0dee79146aceb4014','Status':'Failed'}
if mode=='wrong-instance': row['InstanceId']='i-00000000000000000'
if mode=='wrong-command': row['CommandId']='00000000-0000-0000-0000-000000000000'
if mode=='wrong-status': row['Status']='Success'
if action=='get-command-invocation':
 row['ResponseCode']=True if mode=='bool-response' else 0 if mode=='wrong-code' else 2
 # Deliberately extra fixture content must NEVER appear in sanitized receipts.
 row['StandardOutputContent']='FORBIDDEN-FIXTURE-CONTENT'
 print('invalid-json' if mode=='invalid-json' else json.dumps(row))
else:
 assert '--no-paginate' in a
 print(json.dumps([] if mode=='empty-list' else [row,row] if mode=='duplicate-list' else [row]))
''')
        fake.chmod(0o700)
        # Operator shells can export functions/BASH_ENV and AWS credentials.
        # None may enter a fake-AWS fixture: build a fresh allowlisted environment.
        self.env = dict(PATH=str(self.root)+':/usr/bin:/bin', HOME=str(self.root), LC_ALL='C',
                        RUNNER_TEMP=str(self.root), CALLS=str(self.root/'calls'),
                        PREFLIGHT_COMMAND_ID=COMMAND, GITHUB_EVENT_NAME='workflow_dispatch',
                        GITHUB_REF='refs/heads/main', GITHUB_REPOSITORY='PocketShell-io/pocketshell-gateway',
                        GITHUB_SHA='a'*40, GITHUB_RUN_ID='123',
                        GITHUB_STEP_SUMMARY=str(self.root/'summary'))

    def run_block(self, number):
        return subprocess.run(['/bin/bash', '--noprofile', '--norc', '-c', STEPS[number]['run']], env=self.env,
                              capture_output=True, text=True, timeout=10)

    def test_only_manual_main_exact_role_and_readonly_session(self):
        self.assertEqual(set(DOC['on']), {'workflow_dispatch'})
        condition = DOC['jobs']['result-context']['if']
        for value in ("github.event_name == 'workflow_dispatch'", "github.ref == 'refs/heads/main'",
                      "github.repository == 'PocketShell-io/pocketshell-gateway'"):
            self.assertIn(value, condition)
        action = STEPS[1]
        self.assertEqual(action['uses'], 'aws-actions/configure-aws-credentials@e1253824e5c10ff9df46874f81ed3ec929e19cfd')
        inputs = action['with']
        self.assertEqual(inputs['role-to-assume'], 'arn:aws:iam::817685572750:role/pocketshell-github-deploy')
        self.assertEqual(inputs['allowed-account-ids'], '817685572750')
        for key, value in [('use-existing-credentials','false'), ('unset-current-credentials','true'),
                           ('translate-env-variables','false'), ('output-credentials','false')]:
            self.assertEqual(inputs[key], value)
        statement = json.loads(inputs['inline-session-policy'])['Statement']
        self.assertEqual(statement, [{'Effect':'Allow', 'Action':['ssm:GetCommandInvocation','ssm:ListCommandInvocations'],
                                     'Resource':'*', 'Condition':{'StringEquals':{'aws:ResourceAccount':'817685572750',
                                                                              'aws:RequestedRegion':'eu-west-1'}}}])

    def test_guard_rejects_unreviewed_context_before_aws(self):
        for key, value in [('PREFLIGHT_COMMAND_ID', COMMAND+'; echo unsafe'), ('PREFLIGHT_COMMAND_ID',''),
                           ('GITHUB_REF','refs/heads/feature'), ('GITHUB_EVENT_NAME','push'),
                           ('GITHUB_REPOSITORY','someone/pocketshell-gateway')]:
            with self.subTest(key=key, value=value):
                original = self.env[key]
                self.env[key] = value
                self.assertNotEqual(self.run_block(0).returncode, 0)
                self.assertFalse((self.root/'calls').exists())
                self.env[key] = original

    def test_both_actions_and_sanitized_receipt(self):
        self.assertEqual(self.run_block(0).returncode, 0)
        result = self.run_block(2)
        self.assertEqual(result.returncode, 0, result.stderr)
        receipt = json.loads(result.stdout)
        self.assertEqual(receipt['commandId'], COMMAND)
        self.assertEqual(receipt['instanceId'], INSTANCE)
        self.assertEqual(receipt['resultContext'], 'PROVEN')
        self.assertEqual(receipt['runtimeProtection'], 'NOT_PROVEN')
        self.assertEqual((self.root/'calls').read_text().splitlines(),
                         ['get-command-invocation','list-command-invocations'])
        self.assertNotIn('FORBIDDEN-FIXTURE-CONTENT', result.stdout+result.stderr+(self.root/'summary').read_text())
        self.assertFalse(list(self.root.glob('pocketshell-result-context.*')))

    def test_malformed_or_unbound_receipt_never_passes(self):
        for mode in ('wrong-instance','wrong-command','wrong-status','wrong-code','bool-response',
                     'invalid-json','empty-list','duplicate-list'):
            with self.subTest(mode=mode):
                self.env['MODE'] = mode
                result = self.run_block(2)
                self.assertNotEqual(result.returncode, 0)
                self.assertNotIn('PROVEN', result.stdout)
                self.assertFalse((self.root/'summary').exists())
                self.assertFalse(list(self.root.glob('pocketshell-result-context.*')))
                self.assertNotIn('FORBIDDEN-FIXTURE-CONTENT', result.stdout+result.stderr)

    def test_denial_of_either_action_is_failure(self):
        for action in ('get-command-invocation','list-command-invocations'):
            with self.subTest(action=action):
                self.env['MODE'] = action+'-denied'
                result = self.run_block(2)
                self.assertNotEqual(result.returncode, 0)
                self.assertFalse((self.root/'summary').exists())
                self.assertFalse(list(self.root.glob('pocketshell-result-context.*')))

    def test_invalid_source_receipt_is_failure(self):
        self.env['GITHUB_SHA'] = 'bad-revision'
        self.assertNotEqual(self.run_block(2).returncode, 0)
        self.assertFalse((self.root/'summary').exists())

    def test_exported_shell_hooks_and_credentials_never_reach_fixture(self):
        sentinel = self.root/'live-aws-or-shell-hook-ran'
        hook = self.root/'operator-startup.sh'
        hook.write_text('touch "' + str(sentinel) + '"\n')
        polluted = dict(os.environ, BASH_ENV=str(hook), ENV=str(hook),
                        AWS_ACCESS_KEY_ID='FAKE-OPERATOR-KEY', AWS_SECRET_ACCESS_KEY='FAKE-OPERATOR-SECRET',
                        AWS_SESSION_TOKEN='FAKE-OPERATOR-TOKEN', AWS_PROFILE='FAKE-OPERATOR-PROFILE')
        polluted['BASH_FUNC_aws%%'] = '() { /usr/bin/touch "' + str(sentinel) + '"; return 97; }'
        # Run the actual positive fixture under a poisoned parent environment.
        # It must still exercise BOTH recorded fake AWS calls and succeed.
        result = subprocess.run([sys.executable, str(Path(__file__).resolve()),
                                 'WorkflowBehavior.test_both_actions_and_sanitized_receipt'],
                                env=polluted, capture_output=True, text=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stdout+result.stderr)
        self.assertFalse(sentinel.exists(), 'An inherited function/startup hook executed')
        for key in polluted:
            if key.startswith(('AWS_', 'BASH_FUNC_')) or key in ('BASH_ENV', 'ENV'):
                self.assertNotIn(key, self.env)


if __name__ == '__main__':
    unittest.main(verbosity=2)
