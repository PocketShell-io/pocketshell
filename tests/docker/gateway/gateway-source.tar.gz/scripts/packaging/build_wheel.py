#!/usr/bin/env python3
"""Build platform-tagged wheels carrying the pocketshell-link helper binary.

Distribution contract (CLI gateway contract delivery handoff, 2026-10-07):
one PyPI-style distribution name `pocketshell-gateway-link`, non-purelib
platform wheels carrying ONLY the built binary at
`pocketshell_gateway_link/bin/pocketshell-link` (aplexer precedent:
`aplexer_cli/bin/...`). Wheels are built by the private repo's own CI; this
script NEVER uploads anything anywhere — publication channel and credentials
are explicitly out of scope, and the default version is a PEP 440 LOCAL
version (rejected by public PyPI uploads) so an accidental publish is
structurally impossible.

Producer-input gate (wheel provenance repair, 2026-10-07; semantics repair
2026-10-08): the matrix directory MUST carry the complete raw record set
`make build-matrix` writes — a sha256 sidecar next to every binary, a
combined SHA256SUMS covering exactly the four binaries, and PROVENANCE.txt
naming the FULL 40-hex source revision — and every producer input is
verified against the actual binary bytes BEFORE anything is packaged.
Missing, mismatched, stale (different revision), conflicting (sidecar vs
SHA256SUMS vs bytes) or ambiguous producer inputs are refused. Ambiguity is
refused at every level: duplicate provenance fields (no first-wins/later-
override), duplicate checksum rows, and a provenance flags line that is
parsed as a grammar — exactly one CGO_ENABLED assignment (=0), exactly one
-trimpath, exactly one -ldflags argument with unambiguous -X assignments —
not a substring hunt, so `-X main.commit=<revision>extra` or a second
`-X main.commit=` assignment can never pass as "bound". Each raw binary is
additionally identified by read-only inspection of its embedded Go build
information (the `\xff Go buildinf:` blob; the binary is NEVER executed, so
cross-compiled slots are safe): toolchain version, GOOS/GOARCH, CGO_ENABLED,
-trimpath, the effective -ldflags string (which must equal the provenance
flags line), vcs.revision (must equal the full release revision) and
vcs.modified=false (clean-tree build). A binary built from other source, a
dirty tree, different flags, or a non-Go blob in a platform slot is refused.
The packager also refuses a binary whose ELF machine / Mach-O cputype does
not match its platform slot, so a cross-platform swap cannot enter a wheel.

The wheels then ship with their own digest set in the SAME output directory:
a `<wheel>.whl.sha256` sidecar per wheel, a SHA256SUMS over the whole
release set, a deterministic machine-readable `wheels-manifest.json` binding
the full source revision, wheel version/platform tag/archive digest, the
embedded helper digest and the validated producer provenance, plus a
byte-identical copy of the checked PROVENANCE.txt. Existing CI uploads the
whole wheels directory, so the complete set travels together with no
publishing workflow. Pre-existing files in the output directory matching
this build's artifact namespace are removed first — a stale wheel from an
earlier build can never ride along in the uploaded set.

Honest limits: RECORD hashes and the binary's self-reported version are
INTERNAL CONSISTENCY data — RECORD travels inside the same archive it
describes and proves nothing about who built it. The Go buildinfo stamp is
stronger static corroboration (it ties the packaged bytes to a toolchain, a
VCS revision and effective ldflags without executing anything), but it is
still producer-authored data: it is not a signature and does not
authenticate who ran the build. The manifest binds bytes to the exact
source revision and the validated same-run producer inputs, but it is not
a signature either; independent verification is
scripts/packaging/verify_wheel_release.py plus out-of-band digest comparison
against a trusted copy of the manifest, and final source-origin acceptance
requires the trusted CI build receipt at the accepted revision.

Platform mapping (Windows is explicitly unsupported and stays out):
    linux-amd64  -> py3-none-manylinux_2_28_x86_64
    linux-arm64  -> py3-none-manylinux_2_28_aarch64
    darwin-amd64 -> py3-none-macosx_11_0_x86_64
    darwin-arm64 -> py3-none-macosx_11_0_arm64

Stdlib only (zipfile, hashlib, base64, csv, json): no runtime downloads, no
third-party packages, no network. Deterministic: fixed member timestamps and
order, sorted manifest keys and checksum rows — two builds of the same
inputs produce byte-identical output files.
"""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import io
import json
import pathlib
import re
import struct
import sys
import zipfile

PACKAGE = "pocketshell_gateway_link"
DIST_NAME = "pocketshell-gateway-link"
BIN_PATH_IN_WHEEL = f"{PACKAGE}/bin/pocketshell-link"
FIXED_TIME = (2020, 1, 1, 0, 0, 0)  # deterministic builds; no clock in the zip

PLATFORM_TAGS = {
    "linux-amd64": "py3-none-manylinux_2_28_x86_64",
    "linux-arm64": "py3-none-manylinux_2_28_aarch64",
    "darwin-amd64": "py3-none-macosx_11_0_x86_64",
    "darwin-arm64": "py3-none-macosx_11_0_arm64",
}

MANIFEST_NAME = "wheels-manifest.json"
MANIFEST_SCHEMA = "pocketshell-gateway-wheels-manifest/v1"
SUMS_NAME = "SHA256SUMS"
PROVENANCE_NAME = "PROVENANCE.txt"
PROVENANCE_COPY = "helper-matrix-PROVENANCE.txt"
RELEASE_FILES = (MANIFEST_NAME, SUMS_NAME, PROVENANCE_COPY)

# The manifest binds artifacts to the EXACT source revision: no short forms,
# no "unknown". `make build-matrix` records `git rev-parse HEAD` verbatim.
FULL_COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
REQUIRED_PLATFORMS = ["linux/amd64", "linux/arm64", "darwin/amd64", "darwin/arm64"]
REQUIRED_PROVENANCE_FIELDS = ("version", "commit", "built_at", "toolchain", "flags", "platforms")
BUILT_AT_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$")
MATRIX_VERSION_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._+:-]{0,99}$")

# Go buildinfo (debug/buildinfo blob): 32-byte header — 14-byte magic, pointer
# size, flags — then, in the pointer-free format (flags bit 0x2, Go >= 1.18),
# a Uvarint-prefixed toolchain version string and a Uvarint-prefixed modinfo
# blob. The modinfo text is framed by 16 non-text bytes on each side
# (runtime/debug strips `data[16 : len(data)-16]`); its `build\tkey=value`
# lines carry the effective build settings. Parsed read-only from raw bytes —
# binaries are never executed.
BUILDINFO_MAGIC = b"\xff Go buildinf:"
BUILDINFO_HEADER_SIZE = 32
BUILDINFO_INLINE_FLAG = 0x2
_MODINFO_LINE_PREFIXES = (b"path\t", b"mod\t", b"dep\t", b"=>\t", b"build\t")
_MODINFO_LINE_PREFIXES_TEXT = ("path\t", "mod\t", "dep\t", "=>\t", "build\t")

VERSION_RE = re.compile(r"^[0-9][0-9A-Za-z.]*([+][0-9A-Za-z.-]+)?$")
# Anything that smells like a credential must never enter a wheel.
SECRET_RE = re.compile(r"AKIA[0-9A-Z]{16}|BEGIN [A-Z ]*PRIVATE KEY|gh[pousr]_[A-Za-z0-9]{20,}")


def fail(msg: str) -> None:
    print(f"FAIL: {msg}")
    sys.exit(1)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def record_hash(data: bytes) -> str:
    digest = hashlib.sha256(data).digest()
    return "sha256=" + base64.urlsafe_b64encode(digest).rstrip(b"=").decode()


def add_member(zf: zipfile.ZipFile, name: str, data: bytes, executable: bool = False) -> None:
    info = zipfile.ZipInfo(name, date_time=FIXED_TIME)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = ((0o755 if executable else 0o644) << 16)
    zf.writestr(info, data)


def parse_sums(text: str, source: str) -> dict[str, str]:
    rows: dict[str, str] = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split(None, 1)
        if len(parts) != 2 or not re.fullmatch(r"[0-9a-f]{64}", parts[0]) or not parts[1].strip():
            fail(f"{source}: malformed checksum row {line!r}")
        name = parts[1].strip()
        if name in rows:
            fail(f"{source}: duplicate row for {name} — ambiguous producer checksum set")
        rows[name] = parts[0]
    return rows


def check_platform_magic(plat: str, payload: bytes, source: str) -> None:
    """The binary in a platform wheel must BE that platform's binary."""
    if plat.startswith("linux-"):
        if payload[:6] != b"\x7fELF\x02\x01":
            fail(f"{source}: not a little-endian ELF64 binary (magic {payload[:6].hex()})")
        machine = struct.unpack_from("<H", payload, 18)[0]
        want = 0x3E if plat.endswith("amd64") else 0xB7
        if machine != want:
            fail(f"{source}: ELF e_machine {machine:#x} does not match platform {plat} (want {want:#x})")
    else:
        if payload[:4] != b"\xcf\xfa\xed\xfe":
            fail(f"{source}: not a little-endian 64-bit Mach-O binary (magic {payload[:4].hex()})")
        cputype = struct.unpack_from("<I", payload, 4)[0]
        want = 0x01000007 if plat.endswith("amd64") else 0x0100000C
        if cputype != want:
            fail(f"{source}: Mach-O cputype {cputype:#x} does not match platform {plat} (want {want:#x})")


def tokenize_shellish(text: str, source: str) -> list[str]:
    """Split a flags line into whitespace-separated tokens, honoring double
    quotes (the shape `make build-matrix` writes). Unterminated quotes are
    refused rather than silently absorbed."""
    tokens: list[str] = []
    buf = ""
    in_quote = False
    for ch in text:
        if ch == '"':
            in_quote = not in_quote
            continue
        if ch.isspace() and not in_quote:
            if buf:
                tokens.append(buf)
                buf = ""
            continue
        buf += ch
    if in_quote:
        fail(f"{source}: unterminated double quote in flags line")
    if buf:
        tokens.append(buf)
    return tokens


def parse_flags_line(flags: str, commit: str, version: str, source: str) -> str:
    """Parse the contracted build-flags grammar and return the effective
    -ldflags string. Substring presence is NOT verification: the grammar
    requires exactly one CGO_ENABLED assignment (=0), exactly one -trimpath,
    exactly one -ldflags argument, and inside it unambiguous -X assignments —
    a later duplicate -X assignment would silently override the earlier one,
    and a value that merely CONTAINS the expected revision as a prefix is not
    the expected assignment."""
    tokens = tokenize_shellish(flags, source)

    cgo = [t for t in tokens if t.startswith("CGO_ENABLED=")]
    if len(cgo) != 1 or cgo[0] != "CGO_ENABLED=0":
        fail(f"{source}: flags must carry exactly one effective CGO_ENABLED=0 assignment, "
             f"got {cgo!r} — refusing an ambiguous or contradicting CGO record")
    if tokens.count("-trimpath") != 1:
        fail(f"{source}: flags must carry exactly one -trimpath token, "
             f"got {tokens.count('-trimpath')}")

    ld_idx = [i for i, t in enumerate(tokens) if t == "-ldflags" or t.startswith("-ldflags=")]
    if len(ld_idx) != 1:
        fail(f"{source}: flags must carry exactly one -ldflags assignment, got {len(ld_idx)}")
    i = ld_idx[0]
    if tokens[i].startswith("-ldflags="):
        ldflags = tokens[i][len("-ldflags="):]
        if tokens[i + 1:i + 2]:
            fail(f"{source}: -ldflags= form takes exactly one value")
    else:
        if i + 1 >= len(tokens):
            fail(f"{source}: -ldflags requires an argument")
        ldflags = tokens[i + 1]

    assigns: dict[str, list[str]] = {}
    rest = tokenize_shellish(ldflags, source)
    j = 0
    while j < len(rest):
        tok = rest[j]
        if tok == "-X" or tok == "-X=" or tok.startswith("-X="):
            if tok == "-X":
                j += 1
                if j >= len(rest):
                    fail(f"{source}: -X requires an importpath.name=value argument")
                arg = rest[j]
            else:
                arg = tok[len("-X="):]
            j += 1
            if "=" in arg:
                symbol, value = arg.split("=", 1)
            else:
                if j >= len(rest):
                    fail(f"{source}: -X {arg!r} is missing its value")
                symbol, value = arg, rest[j]
                j += 1
            assigns.setdefault(symbol, []).append(value)
        else:
            j += 1

    for symbol in ("main.commit", "main.version"):
        values = assigns.get(symbol, [])
        if len(values) != 1:
            fail(f"{source}: flags ldflags carry {len(values)} -X {symbol} assignments "
                 f"{values!r} — the Go linker lets a later assignment override an earlier "
                 "one, so this record is ambiguous and refused")
    if assigns["main.commit"][0] != commit:
        fail(f"{source}: flags assign -X main.commit={assigns['main.commit'][0]!r} which is "
             f"not exactly the expected FULL revision {commit} (a value containing the "
             "revision as a prefix is a different assignment)")
    if assigns["main.version"][0] != version:
        fail(f"{source}: flags assign -X main.version={assigns['main.version'][0]!r} which "
             f"contradicts the provenance version {version!r}")
    return ldflags


def parse_provenance(text: str, source: str) -> dict[str, str]:
    """Strict `key: value` parse. A repeated field is an ambiguous record —
    neither first-wins nor later-override is accepted."""
    prov: dict[str, str] = {}
    for lineno, line in enumerate(text.splitlines(), 1):
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        if key in prov:
            fail(f"{source}:{lineno}: duplicate provenance field {key!r} — ambiguous record "
                 "(earlier value would silently differ from the later one)")
        prov[key] = value.strip()
    return prov


def _read_uvarint(data: bytes, off: int, source: str) -> tuple[int, int]:
    result = 0
    shift = 0
    while True:
        if off >= len(data) or shift > 63:
            fail(f"{source}: truncated Go buildinfo varint (not a Go build stamp?)")
        byte = data[off]
        off += 1
        result |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return result, off
        shift += 7


def _go_unquote(value: str, source: str) -> str:
    """Minimal strconv.Unquote for the double-quoted build-setting values the
    Go toolchain writes (keys/values containing spaces are quoted)."""
    if len(value) < 2 or value[0] != '"' or value[-1] != '"':
        fail(f"{source}: malformed quoted Go build setting {value!r}")
    out: list[str] = []
    body = value[1:-1]
    i = 0
    simple = {'"': '"', "\\": "\\", "n": "\n", "t": "\t", "r": "\r",
              "a": "\a", "b": "\b", "f": "\f", "v": "\v"}
    while i < len(body):
        ch = body[i]
        if ch != "\\":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= len(body):
            fail(f"{source}: malformed escape in Go build setting {value!r}")
        esc = body[i + 1]
        if esc in simple:
            out.append(simple[esc])
            i += 2
        elif esc == "x" and i + 3 < len(body) + 1:
            try:
                out.append(chr(int(body[i + 2:i + 4], 16)))
            except ValueError:
                fail(f"{source}: malformed \\x escape in Go build setting {value!r}")
            i += 4
        else:
            fail(f"{source}: unsupported escape \\{esc} in Go build setting {value!r}")
    return "".join(out)


def go_buildinfo(payload: bytes, source: str) -> dict:
    """Read-only parse of the embedded Go build information — the binary is
    never executed, so cross-compiled slots are safe. Returns the toolchain
    version string and the effective build settings."""
    idx = payload.find(BUILDINFO_MAGIC)
    if idx < 0:
        fail(f"{source}: no Go buildinfo stamp found — refusing to package bytes that are "
             "not a stamped Go build of the contracted helper")
    header = payload[idx:idx + BUILDINFO_HEADER_SIZE]
    if len(header) < BUILDINFO_HEADER_SIZE:
        fail(f"{source}: truncated Go buildinfo header")
    if not header[15] & BUILDINFO_INLINE_FLAG:
        fail(f"{source}: Go buildinfo pre-1.18 pointer format is not supported — "
             "the contracted toolchain stamps the pointer-free format")
    try:
        off = idx + BUILDINFO_HEADER_SIZE
        n, off = _read_uvarint(payload, off, source)
        if not 0 < n < 4096 or off + n > len(payload):
            fail(f"{source}: implausible Go buildinfo version length {n}")
        go_version = payload[off:off + n].decode("utf-8")
        off += n
        n2, off2 = _read_uvarint(payload, off, source)
        if not 0 < n2 < (1 << 20) or off2 + n2 > len(payload):
            fail(f"{source}: implausible Go buildinfo modinfo length {n2}")
        mod = payload[off2:off2 + n2]
    except UnicodeDecodeError:
        fail(f"{source}: Go buildinfo version string is not valid UTF-8")
    if mod.startswith(_MODINFO_LINE_PREFIXES):
        text = mod
    elif len(mod) >= 32 and mod[16:].startswith(_MODINFO_LINE_PREFIXES):
        text = mod[16:-16]  # runtime.modinfo framing: 16 bytes each side
    else:
        fail(f"{source}: unrecognized Go buildinfo modinfo framing")
    settings: dict[str, str] = {}
    for line in text.decode("utf-8", "replace").split("\n"):
        if not line:
            continue
        if line.startswith("build\t"):
            key, sep, value = line[len("build\t"):].partition("=")
            if not sep:
                fail(f"{source}: malformed Go build setting line {line[:60]!r}")
            if value.startswith('"'):
                value = _go_unquote(value, source)
            if key in settings:
                fail(f"{source}: duplicate Go build setting {key!r} — ambiguous record")
            settings[key] = value
        elif line.startswith(_MODINFO_LINE_PREFIXES_TEXT):
            continue
        else:
            fail(f"{source}: unrecognized Go buildinfo line {line[:60]!r}")
    return {"go_version": go_version, "settings": settings}


def check_binary_identity(plat: str, name: str, payload: bytes, prov: dict[str, str],
                          commit: str) -> None:
    """The binary in a platform slot must BE that platform's clean Go build of
    the exact revision: format magic, then the embedded Go buildinfo stamp,
    cross-checked against the provenance.

    Bounded honesty: with the contracted -trimpath build the Go toolchain
    REDACTS the -ldflags value from the buildinfo (go.dev/issue/52372), so the
    effective -X injections cannot be re-derived from the packaged bytes by a
    static reader. They are enforced textually on the receipt's flags line
    (exactly one unambiguous assignment, see parse_flags_line); independent
    ldflags acceptance stays with the trusted CI build receipt / final
    release gate. Everything checked here IS derivable from the bytes.
    """
    check_platform_magic(plat, payload, name)
    info = go_buildinfo(payload, name)
    s = info["settings"]
    if info["go_version"] not in prov["toolchain"].split():
        fail(f"{name}: binary was built by Go {info['go_version']!r} but the provenance "
             f"toolchain line is {prov['toolchain']!r}")
    goos, goarch = plat.split("-")
    if s.get("GOOS") != goos or s.get("GOARCH") != goarch:
        fail(f"{name}: binary buildinfo GOOS/GOARCH {s.get('GOOS')!r}/{s.get('GOARCH')!r} "
             f"does not match platform slot {plat}")
    if s.get("CGO_ENABLED") != "0":
        fail(f"{name}: binary buildinfo CGO_ENABLED={s.get('CGO_ENABLED')!r} != 0 — the "
             "contracted build is static CGO_ENABLED=0")
    if s.get("-trimpath") != "true":
        fail(f"{name}: binary buildinfo -trimpath={s.get('-trimpath')!r} != true — the "
             "contracted build is -trimpath")
    if s.get("vcs") != "git":
        fail(f"{name}: binary buildinfo vcs={s.get('vcs')!r} != git — the contracted "
             "matrix is built from the git worktree")
    if "vcs.revision" not in s:
        fail(f"{name}: binary carries no vcs.revision build stamp — refusing (built outside "
             "a VCS worktree or with -buildvcs disabled; a release binary must be stamped "
             "with its source revision)")
    if s["vcs.revision"] != commit:
        fail(f"{name}: binary build stamp vcs.revision {s['vcs.revision']} != release "
             f"revision {commit} — these bytes were built from different source")
    if s.get("vcs.modified") != "false":
        fail(f"{name}: binary build stamp vcs.modified={s.get('vcs.modified')!r} != false — "
             f"built from a dirty/uncommitted tree, not the clean revision {commit}")
    vcs_time = s.get("vcs.time", "")
    if not BUILT_AT_RE.fullmatch(vcs_time):
        fail(f"{name}: binary build stamp vcs.time {vcs_time!r} is not an RFC3339 UTC "
             "timestamp — the source-binding stamp set is incomplete")


def verify_producer(matrix_dir: pathlib.Path, commit: str) -> tuple[dict[str, str], dict[str, str]]:
    """Verify the raw build-matrix record set against the actual binary bytes.

    Refuses missing, mismatched, stale, conflicting or ambiguous producer
    inputs. Returns the parsed provenance fields and the verified per-binary
    digests.
    """
    expected = [f"pocketshell-link-{plat}" for plat in PLATFORM_TAGS]
    sidecars: dict[str, str] = {}
    for name in expected:
        binary = matrix_dir / name
        if not binary.is_file():
            fail(f"missing matrix binary {binary} (run `make build-matrix` first)")
        side = matrix_dir / f"{name}.sha256"
        if not side.is_file():
            fail(f"missing producer checksum sidecar {side.name} — make build-matrix writes "
                 "one next to every raw binary; refusing to package an unverifiable input")
        rows = parse_sums(side.read_text(), side.name)
        if set(rows) != {name}:
            fail(f"{side.name} must contain exactly one row for {name}, got {sorted(rows)}")
        sidecars[name] = rows[name]

    sums_path = matrix_dir / SUMS_NAME
    if not sums_path.is_file():
        fail(f"missing producer {SUMS_NAME} in {matrix_dir} — refusing to package without a "
             "combined raw checksum set")
    sums = parse_sums(sums_path.read_text(), SUMS_NAME)
    if set(sums) != set(expected):
        fail(f"producer {SUMS_NAME} must cover exactly the four matrix binaries; "
             f"found {sorted(sums)}")

    digests: dict[str, str] = {}
    for name in expected:
        actual = sha256_hex((matrix_dir / name).read_bytes())
        if sidecars[name] != actual:
            fail(f"producer sidecar mismatch for {name}: sidecar says {sidecars[name]}, "
                 f"actual bytes hash to {actual}")
        if sums[name] != actual:
            fail(f"producer {SUMS_NAME} mismatch for {name}: SUMS says {sums[name]}, "
                 f"actual bytes hash to {actual} (stale or conflicting producer checksums)")
        digests[name] = actual

    prov_path = matrix_dir / PROVENANCE_NAME
    if not prov_path.is_file():
        fail(f"missing producer provenance {prov_path} — refusing to package without it")
    prov = parse_provenance(prov_path.read_text(), PROVENANCE_NAME)
    for key in REQUIRED_PROVENANCE_FIELDS:
        if not prov.get(key):
            fail(f"producer provenance is missing a {key}: line")

    if not FULL_COMMIT_RE.fullmatch(prov["commit"]):
        fail(f"producer provenance commit {prov['commit']!r} is not a FULL 40-hex revision — "
             "refusing (a short-form receipt is not a release receipt; make build-matrix "
             "records `git rev-parse HEAD` verbatim)")
    if prov["commit"] != commit:
        fail(f"stale/conflicting producer provenance: {PROVENANCE_NAME} commit "
             f"{prov['commit']} != requested source revision {commit}")
    if not MATRIX_VERSION_RE.fullmatch(prov["version"]):
        fail(f"producer provenance version {prov['version']!r} is not a bounded "
             "identifier-shaped version string")
    if not BUILT_AT_RE.fullmatch(prov["built_at"]):
        fail(f"producer provenance built_at {prov['built_at']!r} is not an RFC3339 UTC "
             "timestamp (YYYY-MM-DDTHH:MM:SSZ)")
    if not prov["toolchain"].startswith("go version "):
        fail(f"producer provenance toolchain {prov['toolchain']!r} is not a `go version` line")
    if sorted(prov["platforms"].split()) != sorted(REQUIRED_PLATFORMS):
        fail(f"producer provenance platforms {prov['platforms']!r} != contracted matrix "
             f"{' '.join(REQUIRED_PLATFORMS)}")
    # The flags line is validated as a grammar (not substrings); its effective
    # -ldflags string is intentionally not returned — a -trimpath build redacts
    # ldflags from the binary's buildinfo, so there is nothing to cross-check
    # it against (see check_binary_identity).
    parse_flags_line(prov["flags"], commit, prov["version"], PROVENANCE_NAME)

    for plat in PLATFORM_TAGS:
        name = f"pocketshell-link-{plat}"
        check_binary_identity(plat, name, (matrix_dir / name).read_bytes(),
                              prov, commit)
    return prov, digests


def build_one(matrix_dir: pathlib.Path, out_dir: pathlib.Path, plat: str,
              tag: str, version: str, commit: str, payload_digest: str) -> pathlib.Path:
    binary_name = f"pocketshell-link-{plat}"
    payload = (matrix_dir / binary_name).read_bytes()  # identity checked in verify_producer
    if SECRET_RE.search(payload.decode("latin-1")):
        fail(f"{binary_name} contains credential-shaped material — refusing to package")

    wheel_name = f"{PACKAGE}-{version}-{tag}.whl"
    out = out_dir / wheel_name

    records: list[tuple[str, str, str]] = []
    members: list[tuple[str, bytes, bool]] = [
        (BIN_PATH_IN_WHEEL, payload, True),
        (f"{PACKAGE}-{version}.dist-info/METADATA",
         (f"Metadata-Version: 2.1\nName: {DIST_NAME}\nVersion: {version}\n"
          f"Summary: PocketShell gateway link helper (raw binary wheel; internal distribution only)\n"
          f"Source-Commit: {commit}\nPlatform-Binary: {plat}\n"
          + "".join(f"Supported-Platform: {t}\n" for t in PLATFORM_TAGS.values())).encode(),
         False),
        (f"{PACKAGE}-{version}.dist-info/WHEEL",
         ("Wheel-Version: 1.0\nGenerator: pocketshell-delivery scripts/packaging/build_wheel.py\n"
          f"Root-Is-Purelib: false\nTag: {tag}\n").encode(),
         False),
    ]
    for name, data, _exec in members:
        records.append((name, record_hash(data), str(len(data))))

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, data, executable in members:
            add_member(zf, name, data, executable)
        # RECORD lists every member AND itself (empty hash/size) — wheel spec.
        record_data = ("\r\n".join(",".join(r) for r in records) +
                       f"\r\n{PACKAGE}-{version}.dist-info/RECORD,,\r\n")
        add_member(zf, f"{PACKAGE}-{version}.dist-info/RECORD", record_data.encode(), False)
    out.write_bytes(buf.getvalue())

    # verify what we just wrote: names, hashes, payload round-trip, no secrets
    with zipfile.ZipFile(out) as zf:
        names = zf.namelist()
        expected = [m[0] for m in members] + [f"{PACKAGE}-{version}.dist-info/RECORD"]
        if names != expected:
            fail(f"{out.name}: unexpected wheel members: {names}")
        if zf.read(BIN_PATH_IN_WHEEL) != payload:
            fail(f"{out.name}: binary payload does not round-trip")
        rec = zf.read(f"{PACKAGE}-{version}.dist-info/RECORD").decode().splitlines()
        rec_map = {row[0]: row for row in csv.reader(rec)}
        for name, data, _exec in members:
            if name not in rec_map:
                fail(f"{out.name}: RECORD missing {name}")
            if rec_map[name][1] != record_hash(data):
                fail(f"{out.name}: RECORD hash mismatch for {name}")
        bad = SECRET_RE.search("".join(zf.read(n).decode("latin-1") for n in names))
        if bad:
            fail(f"{out.name}: credential-shaped material in wheel")
    if sha256_hex(payload) != payload_digest:
        fail(f"{out.name}: embedded helper digest drifted from the verified producer input")
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--matrix-dir", required=True, type=pathlib.Path)
    ap.add_argument("--out-dir", required=True, type=pathlib.Path)
    ap.add_argument("--version", required=True)
    ap.add_argument("--commit", required=True)
    args = ap.parse_args()

    if not VERSION_RE.fullmatch(args.version):
        fail(f"wheel version {args.version!r} is not a sane PEP 440 form "
             "^[0-9][0-9A-Za-z.]*([+][0-9A-Za-z.-]+)?$")
    if not FULL_COMMIT_RE.fullmatch(args.commit):
        fail(f"commit {args.commit!r} must be the FULL 40-hex source revision "
             "(git rev-parse HEAD) — the release manifest binds artifacts to the exact revision")
    if not args.matrix_dir.is_dir():
        fail(f"matrix dir missing: {args.matrix_dir} (run `make build-matrix`)")
    if not args.out_dir.is_dir():
        args.out_dir.mkdir(parents=True, exist_ok=True)

    # Producer gate FIRST: refuse bad inputs before touching the output dir.
    prov, digests = verify_producer(args.matrix_dir, args.commit)

    # Stale-artifact guard: clear exactly this build's artifact namespace so a
    # wheel from an earlier run can never ride along in the uploaded set.
    removed = []
    for pattern in (f"{PACKAGE}-*.whl", f"{PACKAGE}-*.whl.sha256", *RELEASE_FILES):
        for old in sorted(args.out_dir.glob(pattern)):
            if old.is_file():
                old.unlink()
                removed.append(old.name)
    if removed:
        print(f"removed stale artifacts from {args.out_dir}: {', '.join(removed)}")

    built = []
    for plat, tag in PLATFORM_TAGS.items():
        built.append((plat, tag,
                      build_one(args.matrix_dir, args.out_dir, plat, tag, args.version,
                                args.commit, digests[f"pocketshell-link-{plat}"])))

    # Outer digest set: one sidecar per wheel, bytes just written.
    wheel_entries = []
    wheel_sums: dict[str, str] = {}
    for plat, tag, wheel in built:
        wheel_bytes = wheel.read_bytes()
        wheel_digest = sha256_hex(wheel_bytes)
        (args.out_dir / f"{wheel.name}.sha256").write_text(f"{wheel_digest}  {wheel.name}\n")
        wheel_sums[wheel.name] = wheel_digest
        wheel_entries.append({
            "file": wheel.name,
            "platform": plat,
            "platform_tag": tag,
            "sha256": wheel_digest,
            "size_bytes": len(wheel_bytes),
            "embedded_helper": {
                "member": BIN_PATH_IN_WHEEL,
                "producer_file": f"pocketshell-link-{plat}",
                "sha256": digests[f"pocketshell-link-{plat}"],
            },
        })

    # Checked producer provenance travels with the release, byte-identical.
    prov_bytes = (args.matrix_dir / PROVENANCE_NAME).read_bytes()
    (args.out_dir / PROVENANCE_COPY).write_bytes(prov_bytes)

    manifest = {
        "schema": MANIFEST_SCHEMA,
        "source_revision": args.commit,
        "wheel_version": args.version,
        "producer": {
            "provenance": {
                "file": PROVENANCE_COPY,
                "sha256": sha256_hex(prov_bytes),
                "commit": prov["commit"],
                "version": prov["version"],
                "built_at": prov["built_at"],
                "toolchain": prov["toolchain"],
                "flags": prov["flags"],
                "platforms": prov["platforms"].split(),
            },
            "helper_matrix": {name: {"sha256": digest} for name, digest in sorted(digests.items())},
        },
        "wheels": wheel_entries,
        "notes": [
            "Internal distribution only; this repository never publishes wheels or uploads "
            "to any index.",
            "This manifest binds artifact bytes to the exact source revision and the "
            "validated same-run producer inputs; it is NOT a cryptographic signature.",
            "Wheel-internal RECORD hashes are consistency data carried inside the archive "
            "they describe; they are not independent provenance.",
            "Verify out of band: recompute each wheel's SHA256 and compare against a trusted "
            "copy of this manifest and SHA256SUMS obtained through a separate channel.",
        ],
    }
    manifest_bytes = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
    (args.out_dir / MANIFEST_NAME).write_bytes(manifest_bytes)

    release_sums = dict(wheel_sums)
    release_sums[MANIFEST_NAME] = sha256_hex(manifest_bytes)
    release_sums[PROVENANCE_COPY] = sha256_hex(prov_bytes)
    (args.out_dir / SUMS_NAME).write_text(
        "".join(f"{digest}  {name}\n" for name, digest in sorted(release_sums.items())))

    for plat, _tag, wheel in built:
        print(f"built {wheel} (+{wheel.name}.sha256)")
    print(f"release set in {args.out_dir}: {len(built)} wheels + sidecars + {SUMS_NAME} "
          f"({len(release_sums)} rows) + {MANIFEST_NAME} + {PROVENANCE_COPY} "
          f"@ source revision {args.commit} "
          "(never published by this repo; internal channel only, no credentials)")


if __name__ == "__main__":
    main()
