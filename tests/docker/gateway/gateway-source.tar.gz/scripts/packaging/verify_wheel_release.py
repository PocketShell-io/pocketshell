#!/usr/bin/env python3
"""Independent verifier for a built pocketshell-gateway-link wheel release set.

Verifies the COMPLETE artifact set emitted by scripts/packaging/
build_wheel.py in a wheels output directory, recomputing every digest from
actual bytes — it trusts no hash it is handed and shares no code with the
builder:

  * every wheel's outer SHA256, recomputed, against its `<wheel>.whl.sha256`
    sidecar, the release SHA256SUMS and `wheels-manifest.json`;
  * the manifest: schema, FULL 40-hex source revision (pinned with
    --expect-commit when given), wheel version, exactly one entry per wheel
    file present in the directory (no unlisted/stale wheels), and the
    canonical platform order/tag/member identities; duplicate JSON keys
    anywhere in the manifest are an ambiguous record and are refused;
  * the manifest's `producer.provenance` record: every required field present
    (file/sha256/commit/version/built_at/toolchain/flags/platforms — a
    missing, extra or mistyped field is a failure, refreshable checksums
    cannot resurrect it);
  * the copied producer provenance: parsed as a strict `key: value` record in
    BOTH modes (duplicate fields refused, no first-wins), its flags line
    parsed as a grammar — exactly one CGO_ENABLED=0 assignment, exactly one
    -trimpath, exactly one -ldflags with unambiguous `-X main.commit` /
    `-X main.version` assignments (a value containing the revision as a
    prefix is a different assignment) — and every field must equal its
    manifest representation, so a provenance copy that names another commit
    cannot pass while the manifest claims the expected one;
  * the manifest's `producer.helper_matrix` map: exactly the four canonical
    producer filenames, each digest bound to the corresponding wheel's
    embedded helper bytes in BOTH modes (a stale/zeroed map cannot pass by
    refreshing checksums), and to the re-verified raw binary digest with
    --matrix-dir;
  * inside every wheel: exact member set/order/zip metadata, byte-exact
    METADATA and WHEEL fields re-derived from the manifest, RECORD rows
    recomputed against actual member bytes (internal consistency), the
    embedded helper hashed and bound to the manifest entry, its canonical
    `pocketshell-link-<platform>` producer filename, its ELF `e_machine` /
    Mach-O `cputype` against the wheel's platform, and a read-only parse of
    its embedded Go buildinfo stamp (the binary is NEVER executed, so
    cross-platform payloads are safe): toolchain version, GOOS/GOARCH,
    CGO_ENABLED=0, -trimpath, vcs=git, vcs.revision == the manifest's full
    source revision, vcs.modified=false and an RFC3339 vcs.time. A binary
    built from other source or a dirty tree cannot carry the release label;
  * with --matrix-dir: the embedded helper equals the named raw producer
    binary byte-for-byte, the raw record set (sidecars, SHA256SUMS,
    PROVENANCE.txt) is re-verified with the same strictness as above, and the
    provenance copy is byte-identical to the raw receipt.

Honest limits, enforced by what this tool does NOT claim: RECORD checks and
metadata fields are consistency data (RECORD rides inside the archive it
describes). The Go buildinfo stamp is producer-authored corroboration, not a
signature, and with the contracted -trimpath build the Go toolchain redacts
`-ldflags` from the buildinfo (go.dev/issue/52372), so the effective -X
injections are verified as an unambiguous grammar on the receipt's flags
line, not re-derived from the bytes. A self-authored unsigned manifest does
NOT authenticate the build producer: this verifier proves byte-level
consistency between the release set, its claimed revision, and the binaries'
embedded build stamps; binding the bytes to a trusted build requires a
trusted CI receipt plus out-of-band comparison of the manifest digest.

Failure lines are tokenized `FAIL [category]` with categories: release,
manifest, sums, provenance, producer, wheel, RECORD, outer, embedded-helper,
helper-matrix, architecture, buildinfo. Stdlib only; never uploads, never
fetches, never writes anything.
"""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import json
import pathlib
import re
import struct
import sys
import zipfile

PACKAGE = "pocketshell_gateway_link"
DIST_NAME = "pocketshell-gateway-link"
BIN_PATH_IN_WHEEL = f"{PACKAGE}/bin/pocketshell-link"
FIXED_TIME = (2020, 1, 1, 0, 0, 0)
MANIFEST_NAME = "wheels-manifest.json"
MANIFEST_SCHEMA = "pocketshell-gateway-wheels-manifest/v1"
SUMS_NAME = "SHA256SUMS"
PROVENANCE_COPY = "helper-matrix-PROVENANCE.txt"
PLATFORM_TAGS = {
    "linux-amd64": "py3-none-manylinux_2_28_x86_64",
    "linux-arm64": "py3-none-manylinux_2_28_aarch64",
    "darwin-amd64": "py3-none-macosx_11_0_x86_64",
    "darwin-arm64": "py3-none-macosx_11_0_arm64",
}
FULL_COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
HEX64_RE = re.compile(r"^[0-9a-f]{64}$")
REQUIRED_PLATFORMS = ["linux/amd64", "linux/arm64", "darwin/amd64", "darwin/arm64"]
REQUIRED_PROVENANCE_FIELDS = ("version", "commit", "built_at", "toolchain", "flags", "platforms")
BUILT_AT_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$")
MATRIX_VERSION_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._+:-]{0,99}$")
MANIFEST_TOP_KEYS = {"schema", "source_revision", "wheel_version", "producer", "wheels", "notes"}
MANIFEST_WHEEL_KEYS = {"file", "platform", "platform_tag", "sha256", "size_bytes", "embedded_helper"}
MANIFEST_EMBEDDED_KEYS = {"member", "producer_file", "sha256"}
MANIFEST_PROVENANCE_KEYS = {"file", "sha256", "commit", "version", "built_at",
                            "toolchain", "flags", "platforms"}
MANIFEST_PRODUCER_KEYS = {"provenance", "helper_matrix"}

BUILDINFO_MAGIC = b"\xff Go buildinf:"
BUILDINFO_HEADER_SIZE = 32
BUILDINFO_INLINE_FLAG = 0x2
_MODINFO_LINE_PREFIXES = (b"path\t", b"mod\t", b"dep\t", b"=>\t", b"build\t")
_MODINFO_LINE_PREFIXES_TEXT = ("path\t", "mod\t", "dep\t", "=>\t", "build\t")


def fail(category: str, msg: str) -> None:
    print(f"FAIL [{category}]: {msg}")
    sys.exit(1)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def record_hash(data: bytes) -> str:
    return "sha256=" + base64.urlsafe_b64encode(
        hashlib.sha256(data).digest()).rstrip(b"=").decode()


def parse_sums(text: str, category: str, source: str) -> dict[str, str]:
    rows: dict[str, str] = {}
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split(None, 1)
        if len(parts) != 2 or not re.fullmatch(r"[0-9a-f]{64}", parts[0]) or not parts[1].strip():
            fail(category, f"{source}: malformed checksum row {line!r}")
        name = parts[1].strip()
        if name in rows:
            fail(category, f"{source}: duplicate row for {name} — ambiguous checksum set")
        rows[name] = parts[0]
    return rows


def check_platform_magic(plat: str, payload: bytes, source: str) -> None:
    """The binary claimed for a platform must BE that platform's format."""
    if plat.startswith("linux-"):
        if payload[:6] != b"\x7fELF\x02\x01":
            fail("architecture", f"{source}: not a little-endian ELF64 binary "
                                 f"(magic {payload[:6].hex()})")
        machine = struct.unpack_from("<H", payload, 18)[0]
        want = 0x3E if plat.endswith("amd64") else 0xB7
        if machine != want:
            fail("architecture", f"{source}: ELF e_machine {machine:#x} does not match "
                                 f"platform {plat} (want {want:#x})")
    else:
        if payload[:4] != b"\xcf\xfa\xed\xfe":
            fail("architecture", f"{source}: not a little-endian 64-bit Mach-O binary "
                                 f"(magic {payload[:4].hex()})")
        cputype = struct.unpack_from("<I", payload, 4)[0]
        want = 0x01000007 if plat.endswith("amd64") else 0x0100000C
        if cputype != want:
            fail("architecture", f"{source}: Mach-O cputype {cputype:#x} does not match "
                                 f"platform {plat} (want {want:#x})")


def tokenize_shellish(text: str, source: str) -> list[str]:
    """Split a flags line into whitespace-separated tokens, honoring double
    quotes (the shape `make build-matrix` writes)."""
    tokens: list[str] = []
    buf = ""
    in_quote = False
    for ch in text:
        if ch == '"':
            in_quote = not in_quote
            continue
        if ch.isspace() and not in_quote:
            if buf:
                tokens.append(buf)
                buf = ""
            continue
        buf += ch
    if in_quote:
        fail("provenance", f"{source}: unterminated double quote in flags line")
    if buf:
        tokens.append(buf)
    return tokens


def parse_flags_line(flags: str, commit: str, version: str, source: str) -> None:
    """Independent re-implementation of the producer's flags grammar: exactly
    one CGO_ENABLED=0 assignment, exactly one -trimpath, exactly one -ldflags
    argument whose -X assignments are unambiguous and bind main.commit to the
    exact revision and main.version to the receipt's version."""
    tokens = tokenize_shellish(flags, source)

    cgo = [t for t in tokens if t.startswith("CGO_ENABLED=")]
    if len(cgo) != 1 or cgo[0] != "CGO_ENABLED=0":
        fail("provenance", f"{source}: flags must carry exactly one effective "
                           f"CGO_ENABLED=0 assignment, got {cgo!r}")
    if tokens.count("-trimpath") != 1:
        fail("provenance", f"{source}: flags must carry exactly one -trimpath token, "
                           f"got {tokens.count('-trimpath')}")

    ld_idx = [i for i, t in enumerate(tokens) if t == "-ldflags" or t.startswith("-ldflags=")]
    if len(ld_idx) != 1:
        fail("provenance", f"{source}: flags must carry exactly one -ldflags assignment, "
                           f"got {len(ld_idx)}")
    i = ld_idx[0]
    if tokens[i].startswith("-ldflags="):
        ldflags = tokens[i][len("-ldflags="):]
        if tokens[i + 1:i + 2]:
            fail("provenance", f"{source}: -ldflags= form takes exactly one value")
    else:
        if i + 1 >= len(tokens):
            fail("provenance", f"{source}: -ldflags requires an argument")
        ldflags = tokens[i + 1]

    assigns: dict[str, list[str]] = {}
    rest = tokenize_shellish(ldflags, source)
    j = 0
    while j < len(rest):
        tok = rest[j]
        if tok == "-X" or tok == "-X=" or tok.startswith("-X="):
            if tok == "-X":
                j += 1
                if j >= len(rest):
                    fail("provenance", f"{source}: -X requires an importpath.name=value argument")
                arg = rest[j]
            else:
                arg = tok[len("-X="):]
            j += 1
            if "=" in arg:
                symbol, value = arg.split("=", 1)
            else:
                if j >= len(rest):
                    fail("provenance", f"{source}: -X {arg!r} is missing its value")
                symbol, value = arg, rest[j]
                j += 1
            assigns.setdefault(symbol, []).append(value)
        else:
            j += 1

    for symbol in ("main.commit", "main.version"):
        values = assigns.get(symbol, [])
        if len(values) != 1:
            fail("provenance", f"{source}: flags ldflags carry {len(values)} -X {symbol} "
                               f"assignments {values!r} — a later assignment would override "
                               "an earlier one, so this record is ambiguous and refused")
    if assigns["main.commit"][0] != commit:
        fail("provenance", f"{source}: flags assign -X main.commit="
                           f"{assigns['main.commit'][0]!r} which is not exactly the expected "
                           f"FULL revision {commit}")
    if assigns["main.version"][0] != version:
        fail("provenance", f"{source}: flags assign -X main.version="
                           f"{assigns['main.version'][0]!r} which contradicts the receipt "
                           f"version {version!r}")


def parse_provenance(text: str, category: str, source: str) -> dict[str, str]:
    """Strict `key: value` parse of a PROVENANCE record; a repeated field is
    an ambiguous record (no first-wins, no later-override)."""
    prov: dict[str, str] = {}
    for lineno, line in enumerate(text.splitlines(), 1):
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        if key in prov:
            fail(category, f"{source}:{lineno}: duplicate provenance field {key!r} — "
                           "ambiguous record")
        prov[key] = value.strip()
    for key in REQUIRED_PROVENANCE_FIELDS:
        if not prov.get(key):
            fail(category, f"{source}: provenance is missing a {key}: line")
    if not FULL_COMMIT_RE.fullmatch(prov["commit"]):
        fail(category, f"{source}: provenance commit {prov['commit']!r} is not a FULL "
                       "40-hex revision")
    if not MATRIX_VERSION_RE.fullmatch(prov["version"]):
        fail(category, f"{source}: provenance version {prov['version']!r} is not a bounded "
                       "identifier-shaped version string")
    if not BUILT_AT_RE.fullmatch(prov["built_at"]):
        fail(category, f"{source}: provenance built_at {prov['built_at']!r} is not an "
                       "RFC3339 UTC timestamp (YYYY-MM-DDTHH:MM:SSZ)")
    if not prov["toolchain"].startswith("go version "):
        fail(category, f"{source}: provenance toolchain {prov['toolchain']!r} is not a "
                       "`go version` line")
    if sorted(prov["platforms"].split()) != sorted(REQUIRED_PLATFORMS):
        fail(category, f"{source}: provenance platforms {prov['platforms']!r} != contracted "
                       f"matrix {' '.join(REQUIRED_PLATFORMS)}")
    return prov


def _read_uvarint(data: bytes, off: int, source: str) -> tuple[int, int]:
    result = 0
    shift = 0
    while True:
        if off >= len(data) or shift > 63:
            fail("buildinfo", f"{source}: truncated Go buildinfo varint")
        byte = data[off]
        off += 1
        result |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return result, off
        shift += 7


def _go_unquote(value: str, source: str) -> str:
    if len(value) < 2 or value[0] != '"' or value[-1] != '"':
        fail("buildinfo", f"{source}: malformed quoted Go build setting {value!r}")
    out: list[str] = []
    body = value[1:-1]
    i = 0
    simple = {'"': '"', "\\": "\\", "n": "\n", "t": "\t", "r": "\r",
              "a": "\a", "b": "\b", "f": "\f", "v": "\v"}
    while i < len(body):
        ch = body[i]
        if ch != "\\":
            out.append(ch)
            i += 1
            continue
        if i + 1 >= len(body):
            fail("buildinfo", f"{source}: malformed escape in Go build setting {value!r}")
        esc = body[i + 1]
        if esc in simple:
            out.append(simple[esc])
            i += 2
        elif esc == "x" and i + 3 < len(body) + 1:
            try:
                out.append(chr(int(body[i + 2:i + 4], 16)))
            except ValueError:
                fail("buildinfo", f"{source}: malformed \\x escape in Go build setting")
            i += 4
        else:
            fail("buildinfo", f"{source}: unsupported escape \\{esc} in Go build setting")
    return "".join(out)


def go_buildinfo(payload: bytes, source: str) -> dict:
    """Read-only parse of the embedded Go build information — the binary is
    never executed, so cross-platform payloads are safe."""
    idx = payload.find(BUILDINFO_MAGIC)
    if idx < 0:
        fail("buildinfo", f"{source}: no Go buildinfo stamp found — the payload is not a "
                          "stamped Go build of the contracted helper")
    header = payload[idx:idx + BUILDINFO_HEADER_SIZE]
    if len(header) < BUILDINFO_HEADER_SIZE:
        fail("buildinfo", f"{source}: truncated Go buildinfo header")
    if not header[15] & BUILDINFO_INLINE_FLAG:
        fail("buildinfo", f"{source}: Go buildinfo pre-1.18 pointer format is not supported")
    try:
        off = idx + BUILDINFO_HEADER_SIZE
        n, off = _read_uvarint(payload, off, source)
        if not 0 < n < 4096 or off + n > len(payload):
            fail("buildinfo", f"{source}: implausible Go buildinfo version length {n}")
        go_version = payload[off:off + n].decode("utf-8")
        off += n
        n2, off2 = _read_uvarint(payload, off, source)
        if not 0 < n2 < (1 << 20) or off2 + n2 > len(payload):
            fail("buildinfo", f"{source}: implausible Go buildinfo modinfo length {n2}")
        mod = payload[off2:off2 + n2]
    except UnicodeDecodeError:
        fail("buildinfo", f"{source}: Go buildinfo version string is not valid UTF-8")
    if mod.startswith(_MODINFO_LINE_PREFIXES):
        text = mod
    elif len(mod) >= 32 and mod[16:].startswith(_MODINFO_LINE_PREFIXES):
        text = mod[16:-16]  # runtime.modinfo framing: 16 bytes each side
    else:
        fail("buildinfo", f"{source}: unrecognized Go buildinfo modinfo framing")
    settings: dict[str, str] = {}
    for line in text.decode("utf-8", "replace").split("\n"):
        if not line:
            continue
        if line.startswith("build\t"):
            key, sep, value = line[len("build\t"):].partition("=")
            if not sep:
                fail("buildinfo", f"{source}: malformed Go build setting line {line[:60]!r}")
            if value.startswith('"'):
                value = _go_unquote(value, source)
            if key in settings:
                fail("buildinfo", f"{source}: duplicate Go build setting {key!r} — "
                                  "ambiguous record")
            settings[key] = value
        elif line.startswith(_MODINFO_LINE_PREFIXES_TEXT):
            continue
        else:
            fail("buildinfo", f"{source}: unrecognized Go buildinfo line {line[:60]!r}")
    return {"go_version": go_version, "settings": settings}


def check_binary_identity(plat: str, source: str, payload: bytes,
                          toolchain: str, commit: str) -> None:
    """Statically identify the payload as the platform's clean Go build of the
    exact revision. Bounded honesty: with the contracted -trimpath build the
    Go toolchain redacts -ldflags from the buildinfo (go.dev/issue/52372), so
    the effective -X injections are verified on the receipt's flags line, not
    re-derived here."""
    check_platform_magic(plat, payload, source)
    info = go_buildinfo(payload, source)
    s = info["settings"]
    if info["go_version"] not in toolchain.split():
        fail("buildinfo", f"{source}: binary was built by Go {info['go_version']!r} but the "
                          f"receipt toolchain line is {toolchain!r}")
    goos, goarch = plat.split("-")
    if s.get("GOOS") != goos or s.get("GOARCH") != goarch:
        fail("buildinfo", f"{source}: binary buildinfo GOOS/GOARCH "
                          f"{s.get('GOOS')!r}/{s.get('GOARCH')!r} does not match platform "
                          f"slot {plat}")
    if s.get("CGO_ENABLED") != "0":
        fail("buildinfo", f"{source}: binary buildinfo CGO_ENABLED="
                          f"{s.get('CGO_ENABLED')!r} != 0 — the contracted build is static")
    if s.get("-trimpath") != "true":
        fail("buildinfo", f"{source}: binary buildinfo -trimpath="
                          f"{s.get('-trimpath')!r} != true — the contracted build is -trimpath")
    if s.get("vcs") != "git":
        fail("buildinfo", f"{source}: binary buildinfo vcs={s.get('vcs')!r} != git — the "
                          "contracted matrix is built from the git worktree")
    if "vcs.revision" not in s:
        fail("buildinfo", f"{source}: binary carries no vcs.revision build stamp — built "
                          "outside a VCS worktree or with -buildvcs disabled")
    if s["vcs.revision"] != commit:
        fail("buildinfo", f"{source}: binary build stamp vcs.revision {s['vcs.revision']} != "
                          f"release revision {commit} — these bytes were built from "
                          "different source")
    if s.get("vcs.modified") != "false":
        fail("buildinfo", f"{source}: binary build stamp vcs.modified="
                          f"{s.get('vcs.modified')!r} != false — built from a dirty tree, "
                          f"not the clean revision {commit}")
    if not BUILT_AT_RE.fullmatch(s.get("vcs.time", "")):
        fail("buildinfo", f"{source}: binary build stamp vcs.time {s.get('vcs.time')!r} is "
                          "not an RFC3339 UTC timestamp")


def verify_producer_raw(matrix_dir: pathlib.Path, commit: str) -> dict[str, str]:
    """Re-verify the raw matrix record set against actual bytes (independent
    re-implementation of the producer contract; returns verified digests)."""
    expected = [f"pocketshell-link-{plat}" for plat in PLATFORM_TAGS]
    sidecars: dict[str, str] = {}
    for name in expected:
        binary = matrix_dir / name
        if not binary.is_file():
            fail("producer", f"matrix binary missing: {binary}")
        side = matrix_dir / f"{name}.sha256"
        if not side.is_file():
            fail("producer", f"producer sidecar missing: {side.name}")
        rows = parse_sums(side.read_text(), "producer", side.name)
        if set(rows) != {name}:
            fail("producer", f"{side.name} must contain exactly one row for {name}")
        sidecars[name] = rows[name]
    sums_path = matrix_dir / SUMS_NAME
    if not sums_path.is_file():
        fail("producer", f"producer {SUMS_NAME} missing in {matrix_dir}")
    sums = parse_sums(sums_path.read_text(), "producer", SUMS_NAME)
    if set(sums) != set(expected):
        fail("producer", f"producer {SUMS_NAME} must cover exactly the four binaries; "
                         f"found {sorted(sums)}")
    digests: dict[str, str] = {}
    for name in expected:
        actual = sha256_hex((matrix_dir / name).read_bytes())
        if sidecars[name] != actual or sums[name] != actual:
            fail("producer", f"{name}: checksums disagree with actual bytes "
                             f"(sidecar {sidecars[name]}, SUMS {sums[name]}, actual {actual})")
        digests[name] = actual

    prov_path = matrix_dir / "PROVENANCE.txt"
    if not prov_path.is_file():
        fail("producer", f"producer provenance missing: {prov_path}")
    prov = parse_provenance(prov_path.read_text(), "producer", "PROVENANCE.txt")
    if prov["commit"] != commit:
        fail("producer", f"stale/conflicting producer provenance: commit {prov['commit']} "
                         f"!= expected source revision {commit}")
    parse_flags_line(prov["flags"], commit, prov["version"], "PROVENANCE.txt")
    for plat in PLATFORM_TAGS:
        name = f"pocketshell-link-{plat}"
        check_binary_identity(plat, name, (matrix_dir / name).read_bytes(),
                              prov["toolchain"], commit)
    return digests


def verify_wheel_structure(path: pathlib.Path, entry: dict, version: str, commit: str) -> bytes:
    """Re-derive the wheel's full structure from the manifest and return the
    embedded helper bytes."""
    tag = entry["platform_tag"]
    want_names = [
        BIN_PATH_IN_WHEEL,
        f"{PACKAGE}-{version}.dist-info/METADATA",
        f"{PACKAGE}-{version}.dist-info/WHEEL",
        f"{PACKAGE}-{version}.dist-info/RECORD",
    ]
    want_meta = (
        f"Metadata-Version: 2.1\nName: {DIST_NAME}\nVersion: {version}\n"
        f"Summary: PocketShell gateway link helper (raw binary wheel; internal distribution only)\n"
        f"Source-Commit: {commit}\nPlatform-Binary: {entry['platform']}\n"
        + "".join(f"Supported-Platform: {t}\n" for t in PLATFORM_TAGS.values())
    ).encode()
    want_wheel = (
        "Wheel-Version: 1.0\nGenerator: pocketshell-delivery scripts/packaging/build_wheel.py\n"
        f"Root-Is-Purelib: false\nTag: {tag}\n"
    ).encode()

    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        if names != want_names:
            fail("wheel", f"{path.name}: member set/order {names} != expected {want_names}")
        helper = zf.read(BIN_PATH_IN_WHEEL)
        for name in want_names:
            info = zf.getinfo(name)
            if info.date_time != FIXED_TIME:
                fail("wheel", f"{path.name}:{name}: date_time {info.date_time} != {FIXED_TIME}")
            if info.compress_type != zipfile.ZIP_DEFLATED:
                fail("wheel", f"{path.name}:{name}: not deflated")
            mode = (info.external_attr >> 16) & 0o7777
            want_mode = 0o755 if name == BIN_PATH_IN_WHEEL else 0o644
            if mode != want_mode:
                fail("wheel", f"{path.name}:{name}: mode {mode:o} != {want_mode:o}")
        if zf.read(f"{PACKAGE}-{version}.dist-info/METADATA") != want_meta:
            fail("wheel", f"{path.name}: METADATA does not match the manifest-bound "
                          "version/commit/platform")
        if zf.read(f"{PACKAGE}-{version}.dist-info/WHEEL") != want_wheel:
            fail("wheel", f"{path.name}: WHEEL metadata does not match tag {tag}")

        # RECORD: internal consistency only — recomputed against actual bytes.
        rec_name = f"{PACKAGE}-{version}.dist-info/RECORD"
        rows: dict[str, list[str]] = {}
        for row in csv.reader(zf.read(rec_name).decode().splitlines()):
            if not row:
                fail("RECORD", f"{path.name}: empty RECORD row")
            if row[0] in rows:
                fail("RECORD", f"{path.name}: duplicate RECORD row for {row[0]}")
            rows[row[0]] = row
        if set(rows) != set(want_names):
            fail("RECORD", f"{path.name}: RECORD covers {sorted(rows)}, "
                           f"wheel members are {sorted(want_names)}")
        for name in want_names:
            row = rows[name]
            if name == rec_name:
                if len(row) != 3 or row[1] != "" or row[2] != "":
                    fail("RECORD", f"{path.name}: RECORD self-row must be empty-hash/empty-size")
                continue
            data = zf.read(name)
            if len(row) != 3 or row[1] != record_hash(data) or row[2] != str(len(data)):
                fail("RECORD", f"{path.name}: RECORD row for {name} does not match actual bytes "
                               "(internal consistency broken)")
    return helper


def _reject_json_constant(const: str) -> None:
    raise ValueError(f"non-JSON constant {const!r} in manifest")


def _no_duplicate_pairs(pairs: list) -> dict:
    out: dict = {}
    for key, value in pairs:
        if key in out:
            raise ValueError(f"duplicate JSON key {key!r} — ambiguous manifest record")
        out[key] = value
    return out


def load_manifest(path: pathlib.Path) -> dict:
    raw = path.read_bytes()
    try:
        manifest = json.loads(raw, object_pairs_hook=_no_duplicate_pairs,
                              parse_constant=_reject_json_constant)
    except (json.JSONDecodeError, ValueError, UnicodeDecodeError) as exc:
        fail("manifest", f"{MANIFEST_NAME} is not valid unambiguous JSON: {exc}")
    if not isinstance(manifest, dict):
        fail("manifest", f"{MANIFEST_NAME} must be a JSON object")
    extra = sorted(set(manifest) - MANIFEST_TOP_KEYS)
    missing = sorted(MANIFEST_TOP_KEYS - set(manifest))
    if extra or missing:
        fail("manifest", f"{MANIFEST_NAME} top-level keys {sorted(manifest)} != expected "
                         f"{sorted(MANIFEST_TOP_KEYS)} (missing {missing}, extra {extra})")
    return manifest


def verify_manifest_producer(manifest: dict, revision: str) -> tuple[dict, dict]:
    """The manifest's producer record must carry the complete, exact schema:
    every required provenance field (missing fields cannot pass by refreshing
    checksums) and the complete canonical helper_matrix map."""
    producer = manifest.get("producer")
    if not isinstance(producer, dict) or set(producer) != MANIFEST_PRODUCER_KEYS:
        fail("manifest", f"manifest producer keys {sorted(producer) if isinstance(producer, dict) else producer!r} "
                         f"!= {sorted(MANIFEST_PRODUCER_KEYS)}")
    mp = producer.get("provenance")
    if not isinstance(mp, dict) or set(mp) != MANIFEST_PROVENANCE_KEYS:
        fail("manifest", f"manifest producer.provenance keys "
                         f"{sorted(mp) if isinstance(mp, dict) else mp!r} != "
                         f"{sorted(MANIFEST_PROVENANCE_KEYS)} — missing provenance fields "
                         "are a failure, not a gap to refresh away")
    if mp["file"] != PROVENANCE_COPY:
        fail("manifest", f"manifest producer.provenance.file {mp['file']!r} != {PROVENANCE_COPY!r}")
    if not HEX64_RE.fullmatch(str(mp.get("sha256", ""))):
        fail("manifest", f"manifest producer.provenance.sha256 {mp.get('sha256')!r} is not "
                         "a 64-hex digest")
    if mp["commit"] != revision:
        fail("manifest", f"manifest producer commit {mp.get('commit')!r} conflicts with "
                         f"source_revision {revision!r}")
    if not MATRIX_VERSION_RE.fullmatch(str(mp.get("version", ""))):
        fail("manifest", f"manifest producer version {mp.get('version')!r} is not a bounded "
                         "identifier-shaped version string")
    if not BUILT_AT_RE.fullmatch(str(mp.get("built_at", ""))):
        fail("manifest", f"manifest producer built_at {mp.get('built_at')!r} is not an "
                         "RFC3339 UTC timestamp")
    if not str(mp.get("toolchain", "")).startswith("go version "):
        fail("manifest", f"manifest producer toolchain {mp.get('toolchain')!r} is not a "
                         "`go version` line")
    if not isinstance(mp.get("flags"), str) or not mp["flags"]:
        fail("manifest", "manifest producer flags must be a non-empty string")
    if mp.get("platforms") != REQUIRED_PLATFORMS:
        fail("manifest", f"manifest producer platforms {mp.get('platforms')!r} != contracted "
                         f"canonical order {REQUIRED_PLATFORMS}")

    hm = producer.get("helper_matrix")
    canonical = {f"pocketshell-link-{plat}": None for plat in PLATFORM_TAGS}
    if not isinstance(hm, dict) or set(hm) != set(canonical):
        fail("helper-matrix", f"manifest producer.helper_matrix keys "
                              f"{sorted(hm) if isinstance(hm, dict) else hm!r} != the complete "
                              f"canonical producer set {sorted(canonical)} — a missing, extra "
                              "or renamed row is a failure")
    for name, row in hm.items():
        if not isinstance(row, dict) or set(row) != {"sha256"}:
            fail("helper-matrix", f"helper_matrix[{name!r}] must be exactly "
                                  f"{{\"sha256\": ...}}, got {row!r}")
        if not HEX64_RE.fullmatch(str(row.get("sha256", ""))):
            fail("helper-matrix", f"helper_matrix[{name!r}].sha256 {row.get('sha256')!r} is "
                                  "not a 64-hex digest")
    return mp, hm


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--release-dir", required=True, type=pathlib.Path)
    ap.add_argument("--expect-commit")
    ap.add_argument("--expect-version")
    ap.add_argument("--matrix-dir", type=pathlib.Path)
    args = ap.parse_args()

    rel = args.release_dir
    if not rel.is_dir():
        fail("release", f"release dir missing: {rel}")
    manifest_path = rel / MANIFEST_NAME
    if not manifest_path.is_file():
        fail("manifest", f"{MANIFEST_NAME} missing in {rel}")
    manifest = load_manifest(manifest_path)
    if manifest.get("schema") != MANIFEST_SCHEMA:
        fail("manifest", f"schema {manifest.get('schema')!r} != {MANIFEST_SCHEMA!r}")
    revision = manifest.get("source_revision", "")
    if not FULL_COMMIT_RE.fullmatch(revision):
        fail("manifest", f"source_revision {revision!r} is not a FULL 40-hex revision")
    version = manifest.get("wheel_version", "")
    if not version or not re.fullmatch(r"[0-9][0-9A-Za-z.]*([+][0-9A-Za-z.-]+)?", version):
        fail("manifest", f"wheel_version {version!r} is not a sane PEP 440 form")
    if not isinstance(manifest.get("notes"), list) or \
            not all(isinstance(n, str) for n in manifest["notes"]):
        fail("manifest", "manifest notes must be a list of strings")
    if args.expect_commit and revision != args.expect_commit:
        fail("manifest", f"stale/conflicting manifest: source_revision {revision} "
                         f"!= expected {args.expect_commit}")
    if args.expect_version and version != args.expect_version:
        fail("manifest", f"manifest wheel_version {version!r} != expected "
                         f"{args.expect_version!r}")

    mp, helper_matrix = verify_manifest_producer(manifest, revision)
    # The receipt flags as represented in the manifest must also parse under
    # the strict grammar and bind the revision.
    parse_flags_line(mp["flags"], revision, mp["version"], "manifest producer.provenance")

    entries = manifest.get("wheels")
    if not isinstance(entries, list) or len(entries) != len(PLATFORM_TAGS):
        fail("manifest", f"wheels must list exactly {len(PLATFORM_TAGS)} entries, "
                         f"got {entries if not isinstance(entries, list) else len(entries)}")

    # Canonical platform order and exact per-entry schema — the manifest is a
    # machine-generated record, not an arbitrary bag of keys.
    canonical_platforms = list(PLATFORM_TAGS)
    for pos, (entry, want_plat) in enumerate(zip(entries, canonical_platforms)):
        if not isinstance(entry, dict) or set(entry) != MANIFEST_WHEEL_KEYS:
            fail("manifest", f"wheels[{pos}] keys {sorted(entry) if isinstance(entry, dict) else entry!r} "
                             f"!= {sorted(MANIFEST_WHEEL_KEYS)}")
        if entry["platform"] != want_plat:
            fail("manifest", f"wheels[{pos}]: platform {entry['platform']!r} breaks the "
                             f"canonical order {canonical_platforms}")
        tag = entry["platform_tag"]
        if PLATFORM_TAGS.get(want_plat) != tag:
            fail("manifest", f"{entry['file']}: platform/tag pair {want_plat}/{tag} is not in "
                             "the contracted mapping")
        if entry["file"] != f"{PACKAGE}-{version}-{tag}.whl":
            fail("manifest", f"{entry['file']}: filename does not encode wheel version "
                             f"{version} and tag {tag}")
        embedded = entry["embedded_helper"]
        if not isinstance(embedded, dict) or set(embedded) != MANIFEST_EMBEDDED_KEYS:
            fail("manifest", f"{entry['file']}: embedded_helper keys "
                             f"{sorted(embedded) if isinstance(embedded, dict) else embedded!r} "
                             f"!= {sorted(MANIFEST_EMBEDDED_KEYS)}")
        if embedded["member"] != BIN_PATH_IN_WHEEL:
            fail("manifest", f"{entry['file']}: unexpected embedded member "
                             f"{embedded['member']!r}")
        canonical_file = f"pocketshell-link-{want_plat}"
        if embedded["producer_file"] != canonical_file:
            fail("manifest", f"{entry['file']}: embedded_helper.producer_file "
                             f"{embedded['producer_file']!r} != canonical {canonical_file!r} "
                             "for this wheel's platform")
        if not HEX64_RE.fullmatch(str(embedded.get("sha256", ""))) or \
                not HEX64_RE.fullmatch(str(entry.get("sha256", ""))):
            fail("manifest", f"{entry['file']}: digests must be 64-hex")
        if not isinstance(entry.get("size_bytes"), int) or entry["size_bytes"] < 0:
            fail("manifest", f"{entry['file']}: size_bytes must be a non-negative integer")

    # The directory must contain exactly the wheels the manifest lists —
    # no unlisted (stale) artifact rides along in the release set.
    listed = sorted(e["file"] for e in entries)
    present = sorted(p.name for p in rel.glob(f"{PACKAGE}-*.whl"))
    if listed != present:
        fail("manifest", f"manifest wheels {listed} != wheels present in {rel}: {present}")

    sums_path = rel / SUMS_NAME
    if not sums_path.is_file():
        fail("sums", f"{SUMS_NAME} missing in {rel}")
    sums = parse_sums(sums_path.read_text(), "sums", SUMS_NAME)
    want_sums_files = set(listed) | {MANIFEST_NAME, PROVENANCE_COPY}
    if set(sums) != want_sums_files:
        fail("sums", f"{SUMS_NAME} must cover exactly {sorted(want_sums_files)}; "
                     f"found {sorted(sums)}")

    prov_copy = rel / PROVENANCE_COPY
    if not prov_copy.is_file():
        fail("provenance", f"{PROVENANCE_COPY} missing in {rel}")
    prov_digest = sha256_hex(prov_copy.read_bytes())
    if mp["sha256"] != prov_digest:
        fail("provenance", f"{PROVENANCE_COPY} digest {prov_digest} != manifest "
                           f"{mp['sha256']}")
    if sums.get(PROVENANCE_COPY) != prov_digest:
        fail("provenance", f"{PROVENANCE_COPY} digest not covered by {SUMS_NAME}")
    if sums.get(MANIFEST_NAME) != sha256_hex(manifest_path.read_bytes()):
        fail("sums", f"{MANIFEST_NAME} digest not covered by {SUMS_NAME} "
                     "(manifest tampered after checksums were emitted)")

    # The carried provenance is PARSED in both modes and every required field
    # must equal its manifest representation — a copy that names another
    # commit/version/toolchain/flag set cannot ride under the manifest's claim.
    receipt = parse_provenance(prov_copy.read_text(), "provenance", PROVENANCE_COPY)
    if receipt["commit"] != mp["commit"]:
        fail("provenance", f"{PROVENANCE_COPY} commit {receipt['commit']!r} != manifest "
                           f"producer commit {mp['commit']!r}")
    if receipt["commit"] != revision:
        fail("provenance", f"{PROVENANCE_COPY} commit {receipt['commit']!r} conflicts with "
                           f"source_revision {revision!r}")
    for field in ("version", "built_at", "toolchain", "flags"):
        if receipt[field] != mp[field]:
            fail("provenance", f"{PROVENANCE_COPY} {field} {receipt[field]!r} != manifest "
                               f"producer {field} {mp[field]!r} — the carried receipt and the "
                               "manifest must describe the same build")
    if receipt["platforms"].split() != mp["platforms"]:
        fail("provenance", f"{PROVENANCE_COPY} platforms {receipt['platforms']!r} != manifest "
                           f"producer platforms {mp['platforms']!r}")
    parse_flags_line(receipt["flags"], revision, receipt["version"], PROVENANCE_COPY)

    for entry in entries:
        name = entry["file"]
        plat = entry["platform"]
        path = rel / name
        if not path.is_file():
            fail("outer", f"manifest wheel missing: {path}")
        data = path.read_bytes()
        actual = sha256_hex(data)
        if entry["sha256"] != actual:
            fail("outer", f"{name}: recomputed digest {actual} != manifest "
                          f"{entry['sha256']} — wheel bytes differ from the manifested "
                          "release")
        if entry["size_bytes"] != len(data):
            fail("outer", f"{name}: size {len(data)} != manifest {entry['size_bytes']}")
        side = rel / f"{name}.sha256"
        if not side.is_file():
            fail("outer", f"outer sidecar missing: {side.name}")
        side_rows = parse_sums(side.read_text(), "outer", side.name)
        if side_rows.get(name) != actual:
            fail("outer", f"{name}: outer sidecar {side_rows.get(name)} != actual {actual}")
        if sums.get(name) != actual:
            fail("outer", f"{name}: {SUMS_NAME} row {sums.get(name)} != actual {actual}")

        helper = verify_wheel_structure(path, entry, version, revision)
        helper_digest = sha256_hex(helper)
        embedded = entry["embedded_helper"]
        if embedded["sha256"] != helper_digest:
            fail("embedded-helper", f"{name}: embedded helper hashes to {helper_digest}, "
                                    f"manifest binds {embedded['sha256']} — the packaged "
                                    "binary is not the manifested one")
        # helper_matrix binds the canonical producer file to THIS wheel's
        # embedded bytes in BOTH modes — a stale/zeroed/renamed map row cannot
        # pass by refreshing checksums.
        canonical_file = embedded["producer_file"]
        if helper_matrix[canonical_file]["sha256"] != helper_digest:
            fail("helper-matrix", f"{name}: embedded helper hashes to {helper_digest} but "
                                  f"helper_matrix[{canonical_file!r}] binds "
                                  f"{helper_matrix[canonical_file]['sha256']} — the "
                                  "helper-matrix map contradicts the packaged bytes")
        # Independent format/architecture and build-stamp inspection of the
        # embedded bytes — no raw matrix access required.
        check_binary_identity(plat, f"{name}:{BIN_PATH_IN_WHEEL}", helper,
                              mp["toolchain"], revision)
        entry["_helper_bytes"] = helper

    if args.matrix_dir:
        if not args.matrix_dir.is_dir():
            fail("producer", f"matrix dir missing: {args.matrix_dir}")
        raw = verify_producer_raw(args.matrix_dir, revision)
        for name, row in helper_matrix.items():
            if raw.get(name) != row["sha256"]:
                fail("helper-matrix", f"{name}: helper_matrix digest {row['sha256']} != "
                                      f"verified raw matrix digest {raw.get(name)} — the "
                                      "manifest's helper map contradicts the raw record set")
        for entry in entries:
            producer_file = entry["embedded_helper"]["producer_file"]
            raw_path = args.matrix_dir / producer_file
            if not raw_path.is_file():
                fail("embedded-helper", f"named producer binary missing: {raw_path}")
            if raw_path.read_bytes() != entry["_helper_bytes"]:
                fail("embedded-helper", f"{entry['file']}: embedded helper is NOT the verified "
                                        f"raw producer binary {producer_file}")
        if prov_copy.read_bytes() != (args.matrix_dir / "PROVENANCE.txt").read_bytes():
            fail("provenance", f"{PROVENANCE_COPY} is not a byte-identical copy of the "
                               "checked producer provenance")

    print(f"OK: {len(entries)} wheels verified in {rel} at source revision {revision}"
          + (f" against raw matrix {args.matrix_dir}" if args.matrix_dir else ""))
    print("Scope: byte-level consistency between the release set, its claimed revision and "
          "the binaries' embedded build stamps. This is NOT authentication: a self-authored "
          "unsigned manifest does not prove who built the bytes. Bind the manifest digest "
          "out of band to a trusted copy and accept the source build via the trusted CI "
          "receipt at the final release gate.")


if __name__ == "__main__":
    main()
