# Gateway agent instructions

This private repository owns the Go server at gateway.pocketshell.io (legacy relay.pocketshell.io alias). Keep the existing browser SSH proxy wire contract operational. Production deployment must use GitHub OIDC, not phone AWS Gate credentials, after a one-time infrastructure bootstrap.

Read docs/design.md. Work in your assigned scope; other agents are editing other packages. Never revert their changes. No AWS mutations, deployments, GitHub changes, pushes, or global installs from delegated agents. Commit only your explicit assigned files. Use /usr/local/go/bin/go. Run meaningful tests and record incremental work in .tmp/<task>-progress.md. The coordinator owns root relay.go integration, README.md, go.mod/go.sum and infra/legacy-stack.yaml.

Security: actual end-to-end SSH, no custom shell execution protocol, no shared superuser relay token. Fail closed. Account identity is verified issuer+subject, not user-supplied account IDs or mutable email. Device registrations require enrolled Ed25519 public keys and proof of possession. Pin real SSH host keys during local enrollment. No secrets in URLs/logs/repo. Bound frames, queues, admissions, unauthenticated handshakes. Never use unrestricted AWS-RunShellScript deployment permission.
