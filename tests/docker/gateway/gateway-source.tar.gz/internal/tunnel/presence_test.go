package tunnel

import (
	"sync"
	"testing"
	"time"
)

// presenceClock is a controllable gateway clock: every presence assertion
// below pins exact connected_since / observed_at values instead of
// tolerating wall-clock jitter.
type presenceClock struct {
	mu  sync.Mutex
	now time.Time
}

func (c *presenceClock) Now() time.Time {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.now
}

func (c *presenceClock) Advance(d time.Duration) time.Time {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.now = c.now.Add(d)
	return c.now
}

func newPresenceWorld(t *testing.T) (*testWorld, *presenceClock) {
	t.Helper()
	clk := &presenceClock{now: time.Date(2026, 10, 10, 12, 0, 0, 0, time.UTC)}
	w := newTestWorld(t, func(o *ServiceOptions) { o.Now = clk.Now })
	return w, clk
}

// connectIdleHost performs the REAL signed host-agent handshake and keeps
// the session open with NO client stream. It returns the host-side mux so
// the test can disconnect the agent.
func connectIdleHost(t *testing.T, w *testWorld, deviceID string) *Mux {
	t.Helper()
	ws, _, err := dialAgentWS(t, w.wsURL, deviceID, w.devices[deviceID])
	if err != nil {
		t.Fatalf("agent dial: %v", err)
	}
	mux := NewMux(NewWSTransport(ws, Limits{}), Limits{}, RoleHost)
	t.Cleanup(func() { mux.Close() })
	return mux
}

func presenceOf(t *testing.T, s *Service, account, deviceID string) (time.Time, HostPresence) {
	t.Helper()
	observed, m := s.PresenceSnapshot(account, []string{deviceID})
	p, ok := m[deviceID]
	if !ok {
		t.Fatalf("snapshot has no entry for requested device %s", deviceID)
	}
	return observed, p
}

func waitPresence(t *testing.T, s *Service, account, deviceID string, online bool) HostPresence {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for {
		_, p := presenceOf(t, s, account, deviceID)
		if p.Online == online {
			return p
		}
		if time.Now().After(deadline) {
			t.Fatalf("device %s presence online=%v never reached %v", deviceID, p.Online, online)
		}
		time.Sleep(5 * time.Millisecond)
	}
}

func TestPresenceEnrolledButNeverConnectedIsOffline(t *testing.T) {
	w, clk := newPresenceWorld(t)
	observed, p := presenceOf(t, w.svc, acctAlice, "dev-alice")
	if p != (HostPresence{}) {
		t.Fatalf("never-connected device must be offline with zero fields, got %+v", p)
	}
	if !observed.Equal(clk.Now()) {
		t.Fatalf("observed_at = %v, want the gateway clock %v", observed, clk.Now())
	}
	// Unknown IDs are offline too, never an error or an omission.
	if _, m := w.svc.PresenceSnapshot(acctAlice, []string{"no-such-device"}); m["no-such-device"].Online {
		t.Fatal("unknown device reported online")
	}
}

func TestPresenceOnlineWithoutAnyStreamThenOfflineOnDisconnect(t *testing.T) {
	w, clk := newPresenceWorld(t)
	readyAt := clk.Advance(time.Minute)
	mux := connectIdleHost(t, w, "dev-alice")
	p := waitPresence(t, w.svc, acctAlice, "dev-alice", true)
	if !p.ConnectedSince.Equal(readyAt) || p.Session != 1 {
		t.Fatalf("first session: connected_since=%v session=%d, want %v / 1", p.ConnectedSince, p.Session, readyAt)
	}
	// No client ever opened a stream: presence is the host session alone.
	later := clk.Advance(30 * time.Second)
	observed, p2 := presenceOf(t, w.svc, acctAlice, "dev-alice")
	if !observed.Equal(later) || !p2.ConnectedSince.Equal(readyAt) {
		t.Fatalf("observed_at must move with the clock while connected_since stays: %v %v", observed, p2.ConnectedSince)
	}

	mux.Close() // the agent goes away
	if p := waitPresence(t, w.svc, acctAlice, "dev-alice", false); p != (HostPresence{}) {
		t.Fatalf("disconnected device must report zero presence fields, got %+v", p)
	}
}

func TestPresenceReplacementReportsNewSession(t *testing.T) {
	w, clk := newPresenceWorld(t)
	firstAt := clk.Advance(time.Second)
	old := connectIdleHost(t, w, "dev-alice")
	p1 := waitPresence(t, w.svc, acctAlice, "dev-alice", true)
	if !p1.ConnectedSince.Equal(firstAt) || p1.Session != 1 {
		t.Fatalf("first session = %+v", p1)
	}

	secondAt := clk.Advance(time.Minute)
	connectIdleHost(t, w, "dev-alice") // supersedes the first session
	deadline := time.Now().Add(5 * time.Second)
	var p2 HostPresence
	for {
		_, p2 = presenceOf(t, w.svc, acctAlice, "dev-alice")
		if p2.Session == 2 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("replacement never became the reported session: %+v", p2)
		}
		time.Sleep(5 * time.Millisecond)
	}
	if !p2.Online || !p2.ConnectedSince.Equal(secondAt) {
		t.Fatalf("replacement must be online since its own readiness: %+v want %v", p2, secondAt)
	}
	// The superseded session's teardown never takes the replacement down.
	select {
	case <-old.Done():
	case <-time.After(5 * time.Second):
		t.Fatal("superseded host session was not shut down")
	}
	time.Sleep(50 * time.Millisecond)
	if _, p3 := presenceOf(t, w.svc, acctAlice, "dev-alice"); !p3.Online || p3.Session != 2 {
		t.Fatalf("stale cleanup disturbed replacement presence: %+v", p3)
	}
}

func TestPresenceRevocationIsOfflineImmediately(t *testing.T) {
	w, _ := newPresenceWorld(t)
	connectIdleHost(t, w, "dev-alice")
	waitPresence(t, w.svc, acctAlice, "dev-alice", true)

	// Revocation unpublishes readiness synchronously with the epoch bump:
	// no window where the (still tearing down) entry reads as online.
	w.revoke(t, "dev-alice", acctAlice)
	if _, p := presenceOf(t, w.svc, acctAlice, "dev-alice"); p.Online {
		t.Fatal("revoked device reported online right after RevokeDevice returned")
	}
	if w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("revoked device still ready for client streams")
	}
	// And it can never come back.
	if _, _, err := dialAgentWS(t, w.wsURL, "dev-alice", w.devices["dev-alice"]); err == nil {
		t.Fatal("revoked device re-registered")
	}
	if _, p := presenceOf(t, w.svc, acctAlice, "dev-alice"); p.Online {
		t.Fatal("revoked device online after re-registration attempt")
	}
}

func TestPresenceIsAccountScoped(t *testing.T) {
	w, _ := newPresenceWorld(t)
	connectIdleHost(t, w, "dev-alice")
	connectIdleHost(t, w, "dev-bob")
	waitPresence(t, w.svc, acctAlice, "dev-alice", true)
	waitPresence(t, w.svc, acctBob, "dev-bob", true)

	// Even if a caller names another account's device, the snapshot never
	// reports it online for the wrong account.
	_, m := w.svc.PresenceSnapshot(acctAlice, []string{"dev-alice", "dev-bob"})
	if !m["dev-alice"].Online {
		t.Fatal("own device offline")
	}
	if m["dev-bob"] != (HostPresence{}) {
		t.Fatalf("foreign device leaked presence: %+v", m["dev-bob"])
	}
	if _, m := w.svc.PresenceSnapshot("", []string{"dev-alice"}); m["dev-alice"].Online {
		t.Fatal("empty account must never see presence")
	}
	// The per-device session counter does not reveal other accounts'
	// churn: bob's first session is 1 regardless of alice's history.
	_, pb := presenceOf(t, w.svc, acctBob, "dev-bob")
	if pb.Session != 1 {
		t.Fatalf("bob session = %d, want 1 (per-device, not global)", pb.Session)
	}
}

func TestPresenceUnreadyBeforeAcknowledgmentAndAfterClose(t *testing.T) {
	w, _ := newPresenceWorld(t)
	gate, _ := beginGatedRegistration(t, w, false)
	if _, p := presenceOf(t, w.svc, acctAlice, "dev-alice"); p.Online {
		t.Fatal("host reported online before its OK frame was written")
	}
	gate.unblock()
	waitPresence(t, w.svc, acctAlice, "dev-alice", true)
	w.svc.Close()
	if _, p := presenceOf(t, w.svc, acctAlice, "dev-alice"); p.Online {
		t.Fatal("closed gateway reported a device online")
	}
}
