package tunnel

// FH-2: stream-window negotiation on the agent handshake. The gateway owns
// the symmetric choice: it validates the agent's announcement (fail closed
// on negative/above-cap BEFORE any stream allocation), takes the min with
// its own configured window, builds its mux on the negotiated value, and
// announces the result in OKMsg.StreamWindow. Zero/absent is the legacy
// "no negotiation" marker and keeps the gateway's own window.

import (
	"encoding/json"
	"testing"
	"time"

	"github.com/gorilla/websocket"
)

// negotiatedHostWindow reports the StreamWindow the gateway's live host mux
// actually enforces (-1 when no connection is registered). Internal
// inspection: the symmetric-choice proof, not just the wire claim. It is
// only meaningful while the connection is open — the teardown unregisters
// the host — so assertions run inside negotiateWindow's inspect callback.
func negotiatedHostWindow(w *testWorld, deviceID string) int {
	w.svc.mu.Lock()
	defer w.svc.mu.Unlock()
	hc := w.svc.hosts[deviceID]
	if hc == nil {
		return -1
	}
	return hc.mux.limits.StreamWindow
}

// negotiateWindow runs one raw agent handshake announcing the given window
// (sendField=false omits the field entirely). inspect runs with the parsed
// verdict while the connection is still open.
func negotiateWindow(t *testing.T, w *testWorld, deviceID string, announce int, sendField bool, inspect func(ok *OKMsg, em *ErrMsg)) {
	t.Helper()
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := dialer.Dial(w.wsURL+PathAgentConnect, nil)
	if err != nil {
		t.Fatalf("dial: %v", err)
	}
	defer ws.Close()
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("challenge read: %v", err)
	}
	var ch HostChallenge
	if err := json.Unmarshal(raw, &ch); err != nil {
		t.Fatalf("challenge parse: %v", err)
	}
	idCh, err := ch.ToIdentityChallenge(deviceID)
	if err != nil {
		t.Fatalf("challenge build: %v", err)
	}
	sig, err := sshSignIdentity(w.devices[deviceID], idCh)
	if err != nil {
		t.Fatalf("sign: %v", err)
	}
	auth := HostAuth{
		Type: "auth", V: ProtocolVersion, DeviceID: deviceID, Signature: sig,
	}
	if sendField {
		auth.StreamWindow = announce
	}
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(auth)); err != nil {
		t.Fatalf("auth write: %v", err)
	}
	_, raw, err = ws.ReadMessage()
	if err != nil {
		t.Fatalf("no verdict frame: %v", err)
	}
	var generic map[string]any
	_ = json.Unmarshal(raw, &generic)
	if t2, _ := generic["type"].(string); t2 == msgTypeError {
		var em ErrMsg
		_ = json.Unmarshal(raw, &em)
		if inspect != nil {
			inspect(nil, &em)
		}
		return
	}
	var ok OKMsg
	if err := json.Unmarshal(raw, &ok); err != nil {
		t.Fatalf("verdict parse: %v (%s)", err, raw)
	}
	if inspect != nil {
		inspect(&ok, nil)
	}
}

// TestWindowNegotiationServiceSide (FH-2): the gateway picks the symmetric
// window as min(own, agent-announced), rejects malformed announcements
// before allocating anything, announces the choice in OK, and runs its mux
// on it. Each handshake supersedes the previous registration.
func TestWindowNegotiationServiceSide(t *testing.T) {
	const ownWindow = 16 << 10
	w := newTestWorld(t, func(o *ServiceOptions) {
		o.Limits.StreamWindow = ownWindow
	})

	for name, bad := range map[string]int{
		"negative": -1,
		"huge":     1 << 30, // far above MaxStreamWindow
	} {
		t.Run("malformed "+name+" rejected before allocation", func(t *testing.T) {
			// A broken or lying announcement fails closed at the auth
			// stage, before the mux (and any stream buffer) exists. These
			// subtests run FIRST so no earlier registration can be
			// mistaken for the rejected handshake's.
			negotiateWindow(t, w, "dev-alice", bad, true, func(ok *OKMsg, em *ErrMsg) {
				if em == nil {
					t.Fatalf("window %d accepted (OK=%+v); must fail closed", bad, ok)
				}
				if em.Code != "protocol" {
					t.Fatalf("rejection code %q, want protocol", em.Code)
				}
				if got := negotiatedHostWindow(w, "dev-alice"); got != -1 {
					t.Fatalf("device registered despite the malformed window (mux=%d)", got)
				}
			})
		})
	}

	t.Run("absent field keeps the gateway window", func(t *testing.T) {
		negotiateWindow(t, w, "dev-alice", 0, false, func(ok *OKMsg, em *ErrMsg) {
			if em != nil {
				t.Fatalf("handshake rejected: %+v", em)
			}
			if ok.StreamWindow != ownWindow {
				t.Fatalf("OK announced %d, want the gateway window %d", ok.StreamWindow, ownWindow)
			}
			if got := negotiatedHostWindow(w, "dev-alice"); got != ownWindow {
				t.Fatalf("gateway mux window %d, want %d", got, ownWindow)
			}
		})
	})

	t.Run("explicit zero is the legacy marker", func(t *testing.T) {
		negotiateWindow(t, w, "dev-alice", 0, true, func(ok *OKMsg, em *ErrMsg) {
			if em != nil {
				t.Fatalf("handshake rejected: %+v", em)
			}
			if ok.StreamWindow != ownWindow {
				t.Fatalf("OK announced %d, want the gateway window %d", ok.StreamWindow, ownWindow)
			}
		})
	})

	t.Run("smaller announcement is adopted symmetrically", func(t *testing.T) {
		const announced = 8 << 10
		negotiateWindow(t, w, "dev-alice", announced, true, func(ok *OKMsg, em *ErrMsg) {
			if em != nil {
				t.Fatalf("handshake rejected: %+v", em)
			}
			if ok.StreamWindow != announced {
				t.Fatalf("OK announced %d, want the agent's smaller %d", ok.StreamWindow, announced)
			}
			if got := negotiatedHostWindow(w, "dev-alice"); got != announced {
				t.Fatalf("gateway mux window %d, want negotiated %d", got, announced)
			}
		})
	})

	t.Run("gateway window is never raised by the announcement", func(t *testing.T) {
		// In-cap but larger than the gateway's own: legal, only lowers.
		negotiateWindow(t, w, "dev-alice", 64<<10, true, func(ok *OKMsg, em *ErrMsg) {
			if em != nil {
				t.Fatalf("handshake rejected: %+v", em)
			}
			if ok.StreamWindow != ownWindow {
				t.Fatalf("OK announced %d, want the gateway's own %d (announcement may only lower)", ok.StreamWindow, ownWindow)
			}
			if got := negotiatedHostWindow(w, "dev-alice"); got != ownWindow {
				t.Fatalf("gateway mux window %d, want %d", got, ownWindow)
			}
		})
	})
}
