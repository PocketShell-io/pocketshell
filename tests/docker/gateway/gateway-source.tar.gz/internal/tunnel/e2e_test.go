package tunnel

import (
	"crypto/ed25519"
	"crypto/rand"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
)

// serveAgentStreams runs a raw-WS agent session loop for a device: it
// accepts gateway-opened streams and bridges them to the test sshd (the
// same shape as internal/hostagent.serveStream).
func (w *testWorld) serveAgentStreams(t *testing.T, deviceID string, limits Limits) {
	t.Helper()
	key := w.devices[deviceID]
	ws, _, err := dialAgentWS(t, w.wsURL, deviceID, key)
	if err != nil {
		t.Fatalf("agent dial: %v", err)
	}
	mux := NewMux(NewWSTransport(ws, limits), limits, RoleHost)
	go func() {
		for {
			s, err := mux.Accept()
			if err != nil {
				return
			}
			go bridgeToSSH(s, w.sshd.addr)
		}
	}()
	t.Cleanup(func() { mux.Close() })
}

// bridgeToSSH dials the local sshd and pumps bytes both ways.
func bridgeToSSH(s *Stream, sshAddr string) {
	tcp, err := netDial(sshAddr)
	if err != nil {
		_ = s.Reset("dial failed")
		return
	}
	if err := s.Ack(); err != nil {
		tcp.Close()
		return
	}
	bridgeStreams(s, tcp)
}

// TestE2ESSHExecTwoOwners proves two different owners each reach only
// their own host over real end-to-end SSH, with concurrent sessions.
func TestE2ESSHExecTwoOwners(t *testing.T) {
	w := newTestWorld(t, nil)
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.serveAgentStreams(t, "dev-bob", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)
	w.svc.waitConnected(t, "dev-bob", 2*time.Second)

	aliceKey := w.sshd.AuthSigner()
	bobKey := w.sshd.AuthSigner()

	var wg sync.WaitGroup
	errs := make([]error, 4)
	for i := 0; i < 2; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			out, err := w.clientExec(t, "dev-alice", tokenAlice, aliceKey, "echo hello-alice")
			if err != nil {
				errs[i] = err
				return
			}
			if strings.TrimSpace(out) != "hello-alice" {
				errs[i] = fmt.Errorf("alice output %q", out)
			}
		}(i)
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			out, err := w.clientExec(t, "dev-bob", tokenBob, bobKey, "echo hello-bob")
			if err != nil {
				errs[2+i] = err
				return
			}
			if strings.TrimSpace(out) != "hello-bob" {
				errs[2+i] = fmt.Errorf("bob output %q", out)
			}
		}(i)
	}
	wg.Wait()
	for i, err := range errs {
		if err != nil {
			t.Fatalf("session %d: %v", i, err)
		}
	}
}

// TestRouteFrameDeviceMismatchRejected is finding F1: the auth frame's
// device_id must be the device on the dialed /api/v1/hosts/{deviceID}/ssh
// route. Two SAME-OWNER devices are enrolled and connected, so ownership
// alone cannot save a mismatched pair: dialing dev-alice's route with
// dev-alice2 in the auth frame must be refused with a protocol error
// before any device-store lookup (none is observed) and before any stream
// opens on either host, while the matching routes still work end-to-end.
func TestRouteFrameDeviceMismatchRejected(t *testing.T) {
	w := newTestWorld(t, nil)

	// A second alice-owned device, enrolled through the same real store.
	pub2, priv2, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	if err := w.idSvc.DeviceStore().Put(identity.Device{
		ID:         "dev-alice2",
		AccountID:  acctAlice,
		PublicKey:  pub2,
		SSHHostKey: w.pins["dev-alice"],
	}); err != nil {
		t.Fatal(err)
	}
	w.devices["dev-alice2"] = priv2
	w.pins["dev-alice2"] = w.pins["dev-alice"] // same lab sshd, provisioned out-of-band

	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.serveAgentStreams(t, "dev-alice2", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)
	w.svc.waitConnected(t, "dev-alice2", 2*time.Second)

	// Both agents are registered; any store lookup for either device from
	// here on can only come from a client connect.
	var clientLookups atomic.Int64
	inner := w.lookupFn
	w.setLookup(func(id string) (Device, error) {
		if id == "dev-alice" || id == "dev-alice2" {
			clientLookups.Add(1)
		}
		return inner(id)
	})

	// dev-alice's route, dev-alice2's device in the frame (same owner,
	// both connected): refused, and nothing opens on either host.
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := dialer.Dial(w.wsURL+clientSSHPath("dev-alice"), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer ws.Close()
	_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(ClientAuth{
		Type: "auth", V: ProtocolVersion, Token: tokenAlice, DeviceID: "dev-alice2",
	})); err != nil {
		t.Fatal(err)
	}
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("expected rejection frame, got %v", err)
	}
	var em ErrMsg
	if err := jsonUnmarshal(raw, &em); err != nil || em.Code != "protocol" {
		t.Fatalf("mismatched route/frame got %+v (err %v), want a protocol error frame", em, err)
	}
	if !readUntilClose(t, ws, 2*time.Second) {
		t.Fatal("connection not closed after route mismatch")
	}
	if n := clientLookups.Load(); n != 0 {
		t.Fatalf("route mismatch performed %d device-store lookup(s) before refusing", n)
	}
	if !w.svc.IsDeviceConnected("dev-alice") || !w.svc.IsDeviceConnected("dev-alice2") {
		t.Fatal("route mismatch disturbed an agent connection")
	}

	// The matching routes still reach ready and a real SSH session each.
	for _, dev := range []string{"dev-alice", "dev-alice2"} {
		out, err := w.clientExec(t, dev, tokenAlice, w.sshd.AuthSigner(), "echo hello-"+dev)
		if err != nil {
			t.Fatalf("%s: matching route failed: %v", dev, err)
		}
		if strings.TrimSpace(out) != "hello-"+dev {
			t.Fatalf("%s: output %q", dev, out)
		}
	}
}

// TestOwnerBoundaries covers the acceptance matrix: bob's token cannot
// reach alice's device, garbage tokens fail, and a token supplied only in
// the URL (never read) fails.
func TestOwnerBoundaries(t *testing.T) {
	w := newTestWorld(t, nil)
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)

	// Owner mismatch.
	if _, em, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenBob); err == nil || em == nil {
		t.Fatalf("bob's token on alice's device: err=%v em=%v, want forbidden", err, em)
	} else if em.Code != "forbidden" && em.Code != "not_found" {
		t.Fatalf("owner mismatch code = %s", em.Code)
	}

	// Invalid token.
	if _, em, _, err := dialClientWS(t, w.wsURL, "dev-alice", "garbage"); err == nil || em == nil {
		t.Fatalf("garbage token accepted: %v %v", err, em)
	} else if em.Code != "unauthorized" {
		t.Fatalf("bad token code = %s", em.Code)
	}

	// Token only in the URL must not authenticate (first-frame auth only).
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := dialer.Dial(w.wsURL+clientSSHPath("dev-alice")+"?token="+tokenAlice, nil)
	if err != nil {
		t.Fatalf("dial: %v", err)
	}
	defer ws.Close()
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	// Send a frame WITHOUT a token: if the gateway honored the query
	// parameter, this would be accepted.
	_ = ws.WriteMessage(websocket.TextMessage, mustJSON(ClientAuth{Type: "auth", V: ProtocolVersion, DeviceID: "dev-alice"}))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	var em ErrMsg
	_ = jsonUnmarshal(raw, &em)
	if em.Code != "unauthorized" && em.Code != "protocol" {
		t.Fatalf("query-token bypass: got %+v", em)
	}
}

// TestChallengeReplayRejected: a captured (challenge, signature) pair
// cannot authenticate a second connection.
func TestChallengeReplayRejected(t *testing.T) {
	w := newTestWorld(t, nil)
	key := w.devices["dev-alice"]

	// First connection: capture the exact auth frame.
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws1, _, err := dialer.Dial(w.wsURL+PathAgentConnect, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer ws1.Close()
	_ = ws1.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws1.ReadMessage()
	if err != nil {
		t.Fatal(err)
	}
	var ch HostChallenge
	if err := jsonUnmarshal(raw, &ch); err != nil {
		t.Fatal(err)
	}
	idCh, err := ch.ToIdentityChallenge("dev-alice")
	if err != nil {
		t.Fatal(err)
	}
	sig, err := sshSignIdentity(key, idCh)
	if err != nil {
		t.Fatal(err)
	}
	authFrame := mustJSON(HostAuth{Type: "auth", V: ProtocolVersion, DeviceID: "dev-alice", Signature: sig})
	if err := ws1.WriteMessage(websocket.TextMessage, authFrame); err != nil {
		t.Fatal(err)
	}
	_, raw, err = ws1.ReadMessage()
	if err != nil {
		t.Fatal(err)
	}
	var ok OKMsg
	if err := jsonUnmarshal(raw, &ok); err != nil || ok.Type != "ok" {
		t.Fatalf("first connection failed: %s", string(raw))
	}

	// A fresh connection gets a NEW challenge; presenting the captured
	// (challenge, sig) pair is rejected (challenge burned, nonce wrong).
	ws2, ch2, err := dialAgentWSCaptureOnly(t, w.wsURL)
	if err != nil {
		t.Fatal(err)
	}
	defer ws2.Close()
	if ch2.ChallengeID == ch.ChallengeID {
		t.Fatal("server reused a challenge ID")
	}
	if err := ws2.WriteMessage(websocket.TextMessage, authFrame); err != nil {
		t.Fatal(err)
	}
	_, raw, err = ws2.ReadMessage()
	if err != nil {
		t.Fatalf("expected rejection, got read error: %v", err)
	}
	var ok2 OKMsg
	if err := jsonUnmarshal(raw, &ok2); err == nil && ok2.Type == "ok" {
		t.Fatal("replayed auth accepted")
	}
}

// TestKeySubstitutionRejected: bob's key cannot authenticate as alice's
// device.
func TestKeySubstitutionRejected(t *testing.T) {
	w := newTestWorld(t, nil)

	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := dialer.Dial(w.wsURL+PathAgentConnect, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer ws.Close()
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatal(err)
	}
	var ch HostChallenge
	if err := jsonUnmarshal(raw, &ch); err != nil {
		t.Fatal(err)
	}
	// Sign as bob but claim alice's device.
	idCh, err := ch.ToIdentityChallenge("dev-alice")
	if err != nil {
		t.Fatal(err)
	}
	sig, err := sshSignIdentity(w.devices["dev-bob"], idCh)
	if err != nil {
		t.Fatal(err)
	}
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(HostAuth{
		Type: "auth", V: ProtocolVersion, DeviceID: "dev-alice", Signature: sig,
	})); err != nil {
		t.Fatal(err)
	}
	_, raw, err = ws.ReadMessage()
	if err != nil {
		t.Fatalf("expected error frame: %v", err)
	}
	var ok OKMsg
	if err := jsonUnmarshal(raw, &ok); err == nil && ok.Type == "ok" {
		t.Fatal("key substitution accepted")
	}
}

// TestO1ClientPinIsIndependent proves the client trust anchor is the
// out-of-band pin, not the gateway's advisory metadata (finding O1).
func TestO1ClientPinIsIndependent(t *testing.T) {
	t.Run("wrong provisioned pin is rejected end-to-end", func(t *testing.T) {
		w := newTestWorld(t, nil)
		w.serveAgentStreams(t, "dev-alice", Limits{})
		w.svc.waitConnected(t, "dev-alice", 2*time.Second)

		cc, _, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenAlice)
		if err != nil {
			t.Fatal(err)
		}
		defer cc.WS.Close()
		// A provisioned pin that does NOT match the real sshd (old pin
		// after a host reinstall). The gateway's advisory matches the real
		// host, but the client's SSH layer must still reject the host.
		_, wrong, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			t.Fatal(err)
		}
		wrongSigner, err := ssh.NewSignerFromKey(wrong)
		if err != nil {
			t.Fatal(err)
		}
		wrongPin := strings.TrimSpace(string(ssh.MarshalAuthorizedKey(wrongSigner.PublicKey())))
		userKey := w.sshd.AuthSigner()
		if _, err := sshDial(t, cc.WS, wrongPin, cc.SSHHostKey, userKey); err == nil {
			t.Fatal("SSH handshake succeeded against a changed host key")
		}
	})

	t.Run("tampered advisory metadata cannot normalize a swap", func(t *testing.T) {
		w := newTestWorld(t, nil)
		w.serveAgentStreams(t, "dev-alice", Limits{})
		w.svc.waitConnected(t, "dev-alice", 2*time.Second)
		cc, _, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenAlice)
		if err != nil {
			t.Fatal(err)
		}
		defer cc.WS.Close()
		userKey := mustSigner(t)
		// A compromised gateway lying in `ready`: advisory points at the
		// attacker's key while the client's pin still holds the honest
		// one. The cross-check aborts before SSH authentication.
		if _, err := sshDial(t, cc.WS, w.pins["dev-alice"], "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAA attacker-key", userKey); err == nil {
			t.Fatal("mismatched advisory accepted")
		}
	})

	t.Run("missing advisory does not weaken the pin check", func(t *testing.T) {
		w := newTestWorld(t, nil)
		w.serveAgentStreams(t, "dev-alice", Limits{})
		w.svc.waitConnected(t, "dev-alice", 2*time.Second)
		cc, _, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenAlice)
		if err != nil {
			t.Fatal(err)
		}
		defer cc.WS.Close()
		userKey := w.sshd.AuthSigner()
		// Advisory absent: the client relies on the pin alone; the SSH
		// layer still enforces it (host key = real sshd key, pin matches).
		cl, err := sshDial(t, cc.WS, w.pins["dev-alice"], "", userKey)
		if err != nil {
			t.Fatalf("pin-only connection failed: %v", err)
		}
		cl.Close()
	})
}

// TestInvalidSSHUserKeyRejected: end-to-end SSH auth is the shell
// boundary; a client without an authorized key gets nothing.
func TestInvalidSSHUserKeyRejected(t *testing.T) {
	w := newTestWorld(t, nil)
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)

	_, err := w.clientExec(t, "dev-alice", tokenAlice, mustSigner(t), "echo should-not-run")
	if err == nil {
		t.Fatal("unauthorized SSH user key was accepted")
	}
}

// TestReconnectSupersedesNoStaleCleanup: a reconnected agent replaces the
// old registration; the old connection's teardown must not unregister or
// disturb the replacement, and streams on the new connection keep working.
func TestReconnectSupersedesNoStaleCleanup(t *testing.T) {
	w := newTestWorld(t, nil)

	// First (old) connection.
	oldWS, _, err := dialAgentWS(t, w.wsURL, "dev-alice", w.devices["dev-alice"])
	if err != nil {
		t.Fatal(err)
	}
	oldMux := NewMux(NewWSTransport(oldWS, Limits{}), Limits{}, RoleGateway)
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)

	// Second (new) connection for the same device supersedes the first.
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)

	// The old mux must be dead (server shut the superseded connection).
	select {
	case <-oldMux.Done():
	case <-time.After(2 * time.Second):
		t.Fatal("superseded connection was not closed")
	}

	// Streams on the new connection work, including after the old
	// connection's cleanup goroutines have surely run.
	for i := 0; i < 3; i++ {
		out, err := w.clientExec(t, "dev-alice", tokenAlice, w.sshd.AuthSigner(), "echo round-"+fmt.Sprint(i))
		if err != nil {
			t.Fatalf("round %d: %v", i, err)
		}
		if strings.TrimSpace(out) != "round-"+fmt.Sprint(i) {
			t.Fatalf("round %d output %q", i, out)
		}
		time.Sleep(50 * time.Millisecond)
	}
	if !w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("replacement connection was stale-cleaned")
	}
	_ = oldWS
}

// TestRevokeDisconnectsActiveSessions: persist+RevokeDevice tears the
// active session down; further connects fail with the store reporting
// revoked; non-owner revoke is refused by the store.
func TestRevokeDisconnectsActiveSessions(t *testing.T) {
	w := newTestWorld(t, nil)
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)

	// Owner-only revocation at the registry.
	if _, _, _, err := w.idSvc.DeviceStore().Revoke("dev-alice", acctBob); err == nil {
		t.Fatal("bob revoked alice's device")
	}
	if _, _, changed, err := w.idSvc.DeviceStore().Revoke("dev-alice", acctAlice); err != nil || !changed {
		t.Fatalf("owner revoke failed: changed=%v err=%v", changed, err)
	}
	w.svc.RevokeDevice("dev-alice")

	// Active agent connection dies.
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) && w.svc.IsDeviceConnected("dev-alice") {
		time.Sleep(10 * time.Millisecond)
	}
	if w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("revoked device still connected")
	}

	// New client connect fails (store reports revoked, uniform response).
	if _, em, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenAlice); err == nil || em == nil {
		t.Fatalf("revoked device accepted a client: %v %v", err, em)
	}
	// New agent auth fails too (fatal for the agent).
	if _, _, err := dialAgentWS(t, w.wsURL, "dev-alice", w.devices["dev-alice"]); err == nil {
		t.Fatal("revoked device re-authenticated")
	}
}

// TestQuotasAndHostOffline covers per-account caps and the offline path.
func TestQuotasAndHostOffline(t *testing.T) {
	w := newTestWorld(t, func(o *ServiceOptions) {
		o.Limits.MaxClientsPerAccount = 1
		o.Limits.MaxClientsGlobal = 8
	})
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)

	cc1, em1, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenAlice)
	if err != nil || em1 != nil {
		t.Fatalf("first client rejected: %v %v", err, em1)
	}
	defer cc1.WS.Close()

	// Second concurrent client for the same account: quota.
	_, em2, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenAlice)
	if err == nil || em2 == nil || em2.Code != "quota" {
		t.Fatalf("per-account quota not enforced: %v %v", err, em2)
	}

	// A different account is fine.
	w.serveAgentStreams(t, "dev-bob", Limits{})
	w.svc.waitConnected(t, "dev-bob", 2*time.Second)
	cc3, em3, _, err := dialClientWS(t, w.wsURL, "dev-bob", tokenBob)
	if err != nil || em3 != nil {
		t.Fatalf("other account wrongly limited: %v %v", err, em3)
	}
	defer cc3.WS.Close()

	// Unknown device: uniform not_found.
	_, em4, _, err := dialClientWS(t, w.wsURL, "dev-unknown", tokenAlice)
	if err == nil || em4 == nil {
		t.Fatalf("unknown device accepted: %v %v", err, em4)
	}
}

// TestSessionMaxDuration: authenticated client sessions are absolutely
// bounded (JWT expiry semantics — no indefinite sessions).
func TestSessionMaxDuration(t *testing.T) {
	w := newTestWorld(t, func(o *ServiceOptions) {
		o.Limits.MaxSessionDuration = 300 * time.Millisecond
		o.Limits.HandshakeTimeout = 2 * time.Second
	})
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)

	cc, _, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenAlice)
	if err != nil {
		t.Fatal(err)
	}
	defer cc.WS.Close()
	_ = cc.WS.SetReadDeadline(time.Now().Add(3 * time.Second))
	start := time.Now()
	for {
		if _, _, err := cc.WS.ReadMessage(); err != nil {
			if d := time.Since(start); d < 150*time.Millisecond {
				t.Fatalf("session closed too early (%v)", d)
			}
			return
		}
		if time.Since(start) > 3*time.Second {
			t.Fatal("session not bounded by MaxSessionDuration")
		}
	}
}

// TestHandshakeDeadlines: silent peers are dropped within the handshake
// deadline for both roles.
func TestHandshakeDeadlines(t *testing.T) {
	w := newTestWorld(t, func(o *ServiceOptions) {
		o.Limits.HandshakeTimeout = 250 * time.Millisecond
	})

	// Silent client.
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	wsC, _, err := dialer.Dial(w.wsURL+clientSSHPath("dev-alice"), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer wsC.Close()
	start := time.Now()
	_ = wsC.SetReadDeadline(time.Now().Add(3 * time.Second))
	// The server sends a JSON error frame before closing; read until the
	// connection actually drops.
	dropped := false
	for {
		if _, _, err := wsC.ReadMessage(); err != nil {
			dropped = true
			break
		}
		if time.Since(start) > 2*time.Second {
			break
		}
	}
	if !dropped {
		t.Fatal("silent client not dropped")
	}
	if d := time.Since(start); d > 2*time.Second {
		t.Fatalf("silent client dropped after %v", d)
	}

	// Silent agent (no auth after challenge).
	wsA, _, err := dialer.Dial(w.wsURL+PathAgentConnect, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer wsA.Close()
	_, _, _ = wsA.ReadMessage() // the challenge
	if !readUntilClose(t, wsA, 3*time.Second) {
		t.Fatal("silent agent not dropped")
	}
	if d := time.Since(start); d > 2*time.Second {
		t.Fatalf("silent agent dropped after %v", d)
	}
}

// TestOriginCheck: browser origins must be same-origin or allowlisted.
func TestOriginCheck(t *testing.T) {
	w := newTestWorld(t, nil)
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, resp, err := dialer.Dial(w.wsURL+clientSSHPath("dev-alice"), nil)
	if err == nil {
		// Dial succeeded without Origin (non-browser): fine. Close it.
		ws.Close()
	} else if resp != nil && resp.StatusCode == http.StatusForbidden {
		t.Fatalf("non-browser client rejected: %v", err)
	}

	// Cross-origin request with a disallowed Origin header.
	req, err := newWSRequest(w.hs.URL + clientSSHPath("dev-alice"))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Origin", "https://evil.example")
	res, err := dialRaw(t, req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusForbidden && res.StatusCode != http.StatusBadRequest {
		t.Fatalf("cross-origin upgrade = %s, want 403/400", res.Status)
	}
}

// TestPendingAdmissionQuotas is finding A7: unauthenticated handshakes
// consume admission budget before any credential is presented, so a
// pre-auth flood is bounded, and the budget is released when the
// connection goes away.
func TestPendingAdmissionQuotas(t *testing.T) {
	w := newTestWorld(t, func(o *ServiceOptions) {
		o.Limits.MaxHosts = 1
		o.Limits.MaxClientsGlobal = 1
	})
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}

	// One silent host upgrade holds the only host slot.
	wsH, _, err := dialer.Dial(w.wsURL+PathAgentConnect, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer wsH.Close()
	// A second upgrade is refused with HTTP 429 while the slot is held.
	if _, resp, err := dialer.Dial(w.wsURL+PathAgentConnect, nil); err == nil || resp == nil || resp.StatusCode != http.StatusTooManyRequests {
		t.Fatalf("second silent host upgrade = %v, want HTTP 429", err)
	}
	// Same for silent client upgrades.
	wsC, _, err := dialer.Dial(w.wsURL+clientSSHPath("dev-alice"), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer wsC.Close()
	if _, resp, err := dialer.Dial(w.wsURL+clientSSHPath("dev-alice"), nil); err == nil || resp == nil || resp.StatusCode != http.StatusTooManyRequests {
		t.Fatalf("second silent client upgrade = %v, want HTTP 429", err)
	}

	// Releasing the held slots restores admission.
	wsH.Close()
	wsC.Close()
	time.Sleep(100 * time.Millisecond) // handler defers release
	wsH2, _, err := dialer.Dial(w.wsURL+PathAgentConnect, nil)
	if err != nil {
		t.Fatalf("host admission not restored after release: %v", err)
	}
	wsH2.Close()
}

// TestUniformClientDenial is finding F-04: unknown, revoked and
// other-owner devices get ONE identical client-visible denial, so a probe
// cannot enumerate devices.
func TestUniformClientDenial(t *testing.T) {
	w := newTestWorld(t, nil)
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)
	w.revoke(t, "dev-bob", acctBob)

	seen := map[string]ErrMsg{}
	for _, tc := range []struct {
		name   string
		device string
		token  string
	}{
		{"unknown", "dev-does-not-exist", tokenAlice},
		{"other-owner", "dev-alice", tokenBob},
		{"revoked-own", "dev-bob", tokenBob},
		{"revoked-other", "dev-bob", tokenAlice},
	} {
		_, em, _, err := dialClientWS(t, w.wsURL, tc.device, tc.token)
		if err == nil || em == nil {
			t.Fatalf("%s: expected denial, got err=%v em=%v", tc.name, err, em)
		}
		seen[tc.name] = *em
	}
	// Every variant must carry the same wire-visible code and message.
	want := seen["unknown"]
	for name, em := range seen {
		if em.Code != want.Code || em.Message != want.Message {
			t.Fatalf("%s denial %+v differs from unknown %+v (device oracle)", name, em, want)
		}
	}
}

// TestRevocationRaceRegistration is finding A1: a registration that raced
// a revocation must not complete after it.
func TestRevocationRaceRegistration(t *testing.T) {
	t.Run("lookup before revoke, insert after revoke", func(t *testing.T) {
		w := newTestWorld(t, nil)

		// Gate the store so the registration's lookup returns the
		// still-active record only after the revocation has fully run.
		gate := make(chan struct{})
		inner := w.lookupFn
		w.setLookup(func(id string) (Device, error) {
			d, err := inner(id)
			if err != nil {
				return d, err
			}
			if id == "dev-alice" {
				<-gate // hold the registration mid-flight
			}
			return d, err
		})

		done := make(chan error, 1)
		go func() {
			_, _, err := dialAgentWS(t, w.wsURL, "dev-alice", w.devices["dev-alice"])
			done <- err
		}()

		// Let the handshake reach the gated lookup, then revoke while it
		// is parked there (persist + epoch bump, the production order).
		time.Sleep(300 * time.Millisecond)
		if _, _, _, err := w.idSvc.DeviceStore().Revoke("dev-alice", acctAlice); err != nil {
			t.Fatal(err)
		}
		w.svc.RevokeDevice("dev-alice")
		close(gate)

		if err := <-done; err == nil {
			t.Fatal("raced registration completed after revocation")
		}
		if w.svc.IsDeviceConnected("dev-alice") {
			t.Fatal("revoked device registered after revocation")
		}
	})

	t.Run("lookup after revoke sees revoked record", func(t *testing.T) {
		w := newTestWorld(t, nil)
		if _, _, _, err := w.idSvc.DeviceStore().Revoke("dev-alice", acctAlice); err != nil {
			t.Fatal(err)
		}
		w.svc.RevokeDevice("dev-alice")
		if _, _, err := dialAgentWS(t, w.wsURL, "dev-alice", w.devices["dev-alice"]); err == nil {
			t.Fatal("revoked device authenticated")
		}
	})
}
