package tunnel

import "time"

// Limits bounds every untrusted dimension of the transport. All values
// have package defaults; ServiceOptions may override within hard ceilings.
type Limits struct {
	// MaxHosts caps concurrently connected host agents (global).
	MaxHosts int
	// MaxStreamsPerHost caps streams (client sessions) per host connection.
	MaxStreamsPerHost int
	// MaxClientsPerAccount caps concurrent client WebSockets per verified
	// account; 0 means the default.
	MaxClientsPerAccount int
	// MaxClientsGlobal caps concurrent client WebSockets gateway-wide.
	MaxClientsGlobal int
	// MaxFramePayload caps multiplexer frame payload bytes.
	MaxFramePayload int
	// StreamWindow is the per-stream per-direction credit window in bytes.
	StreamWindow int
	// HandshakeTimeout bounds the JSON auth handshakes (both roles) and
	// the OPEN->ACK wait.
	HandshakeTimeout time.Duration
	// ChallengeTTL is how long a host challenge stays redeemable.
	ChallengeTTL time.Duration
	// ChallengeCapacity caps outstanding challenges (memory bound).
	ChallengeCapacity int
	// WSWriteTimeout bounds every WebSocket write.
	WSWriteTimeout time.Duration
	// PongWait is the WS read deadline; refreshed by any inbound frame or
	// pong. A peer silent this long is dropped.
	PongWait time.Duration
	// PingInterval is how often keepalive pings are sent.
	PingInterval time.Duration
	// OpenAckTimeout bounds the host's local SSH dial after OPEN.
	OpenAckTimeout time.Duration
	// LocalDialTimeout bounds the host agent's dial to its loopback sshd
	// (host-side limit, shared default for the agent).
	LocalDialTimeout time.Duration
	// MaxSessionDuration caps an authenticated client session's lifetime.
	// Admission credentials are short-lived; client sessions must not
	// outlive any plausible credential window indefinitely — clients
	// reconnect and re-authenticate with a fresh token. Zero selects the
	// default.
	MaxSessionDuration time.Duration
}

// MaxStreamWindow is the hard rollout ceiling for the per-stream
// flow-control window, in bytes. It bounds BOTH the configured
// Limits.StreamWindow (clamped by Resolved) and any peer-announced
// negotiation value (rejected above it) — a remote can never negotiate an
// arbitrary memory commitment per stream.
const MaxStreamWindow = 256 << 10

// hardLimits are the non-negotiable ceilings: configured values are clamped
// to these so a wiring mistake cannot unbound the transport.
var hardLimits = Limits{
	MaxHosts:             256,
	MaxStreamsPerHost:    64,
	MaxClientsPerAccount: 64,
	MaxClientsGlobal:     512,
	MaxFramePayload:      64 << 10,
	StreamWindow:         MaxStreamWindow,
	HandshakeTimeout:     30 * time.Second,
	ChallengeTTL:         2 * time.Minute,
	ChallengeCapacity:    4096,
	WSWriteTimeout:       30 * time.Second,
	PongWait:             5 * time.Minute,
	PingInterval:         time.Minute,
	OpenAckTimeout:       time.Minute,
	LocalDialTimeout:     30 * time.Second,
	MaxSessionDuration:   24 * time.Hour,
}

func (l Limits) Resolved() Limits {
	// Conservative defaults sized for the rollout target: one small
	// instance (512MiB t4g.nano) that also serves the legacy browser proxy.
	// Aggregate accounting (both mux directions, legacy traffic, pending
	// buffers and GC headroom) is documented in docs/tunnel.md; these are
	// design budgets, not a memory measurement.
	d := Limits{
		MaxHosts:             64,
		MaxStreamsPerHost:    8,
		MaxClientsPerAccount: 8,
		MaxClientsGlobal:     64,
		MaxFramePayload:      32 << 10,
		StreamWindow:         64 << 10,
		HandshakeTimeout:     10 * time.Second,
		ChallengeTTL:         30 * time.Second,
		ChallengeCapacity:    256,
		WSWriteTimeout:       15 * time.Second,
		PongWait:             75 * time.Second,
		PingInterval:         25 * time.Second,
		OpenAckTimeout:       10 * time.Second,
		MaxSessionDuration:   12 * time.Hour,
		LocalDialTimeout:     5 * time.Second,
	}
	overwrite := func(dst *int, src, hard int) {
		if src > 0 {
			*dst = src
		}
		if hard > 0 && *dst > hard {
			*dst = hard
		}
	}
	overwrite(&d.MaxHosts, l.MaxHosts, hardLimits.MaxHosts)
	overwrite(&d.MaxStreamsPerHost, l.MaxStreamsPerHost, hardLimits.MaxStreamsPerHost)
	overwrite(&d.MaxClientsPerAccount, l.MaxClientsPerAccount, hardLimits.MaxClientsPerAccount)
	overwrite(&d.MaxClientsGlobal, l.MaxClientsGlobal, hardLimits.MaxClientsGlobal)
	overwrite(&d.MaxFramePayload, l.MaxFramePayload, hardLimits.MaxFramePayload)
	overwrite(&d.StreamWindow, l.StreamWindow, hardLimits.StreamWindow)
	overwrite(&d.ChallengeCapacity, l.ChallengeCapacity, hardLimits.ChallengeCapacity)
	if d.MaxFramePayload < 4096 {
		d.MaxFramePayload = 4096
	}
	dur := func(dst *time.Duration, src time.Duration, def, hard time.Duration) {
		if src > 0 {
			*dst = src
		}
		if *dst > hard {
			*dst = hard
		}
	}
	dur(&d.HandshakeTimeout, l.HandshakeTimeout, d.HandshakeTimeout, hardLimits.HandshakeTimeout)
	dur(&d.ChallengeTTL, l.ChallengeTTL, d.ChallengeTTL, hardLimits.ChallengeTTL)
	dur(&d.WSWriteTimeout, l.WSWriteTimeout, d.WSWriteTimeout, hardLimits.WSWriteTimeout)
	dur(&d.PongWait, l.PongWait, d.PongWait, hardLimits.PongWait)
	dur(&d.PingInterval, l.PingInterval, d.PingInterval, hardLimits.PingInterval)
	dur(&d.OpenAckTimeout, l.OpenAckTimeout, d.OpenAckTimeout, hardLimits.OpenAckTimeout)
	dur(&d.MaxSessionDuration, l.MaxSessionDuration, d.MaxSessionDuration, hardLimits.MaxSessionDuration)
	dur(&d.LocalDialTimeout, l.LocalDialTimeout, d.LocalDialTimeout, hardLimits.LocalDialTimeout)
	return d
}
