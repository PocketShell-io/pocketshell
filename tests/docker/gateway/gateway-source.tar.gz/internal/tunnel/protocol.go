// Package tunnel implements the PocketShell v1 reverse-tunnel transport:
// an authenticated host-agent WebSocket over which per-client, end-to-end
// SSH byte streams are multiplexed opaquely, plus the per-client WebSocket
// endpoint browsers use after authenticating with a short-lived,
// gateway-scoped routing credential minted by the sync broker.
//
// The gateway never parses SSH: every post-authentication byte is opaque.
// SSH authentication, host key pinning and shell access stay end-to-end
// between the browser SSH client and the host's local sshd. Host-agent
// authentication signs identity.Challenge transcripts (shared canonical
// encoding with the identity package; see docs/tunnel.md).
package tunnel

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
)

const (
	// ProtocolVersion is the multiplexer frame and handshake version.
	ProtocolVersion = 1
)

// WebSocket endpoints served by Service.
const (
	// PathAgentConnect is the host-agent control+data WebSocket. The first
	// messages are JSON (server challenge, then signed device auth); after
	// that the connection carries binary multiplexer frames only.
	PathAgentConnect = "/api/v1/agent/connect"
	// PathClientSSH is the prefix of the per-client WebSocket route,
	// /api/v1/hosts/{deviceID}/ssh. First message is a JSON auth frame
	// carrying the sync-broker routing token; afterwards binary SSH bytes
	// both ways. parseClientSSHPath (service.go) parses the published form
	// inside the service — no root-side path rewriting.
	PathClientSSH = "/api/v1/hosts/"
)

// Multiplexer frame types (binary WebSocket messages after JSON auth).
const (
	FrameVersion uint8 = 1
	FrameOpen    uint8 = 1 // gateway -> host: open a stream to local SSH
	FrameData    uint8 = 2 // either direction: stream bytes
	FrameEOF     uint8 = 3 // sender will not write more on this stream
	FrameReset   uint8 = 4 // abort the stream (payload: short reason, optional)
	FrameWindow  uint8 = 5 // credit the peer N more bytes on this stream
	FrameAck     uint8 = 6 // host -> gateway: stream opened, local SSH dial OK
)

// frameHeaderLen is the on-wire size of the multiplexer frame header:
// version(1) type(1) streamID(8) length(4).
const frameHeaderLen = 14

// FrameOverhead is the wire overhead per multiplexer frame; callers sizing
// WebSocket read limits add it to MaxFramePayload.
const FrameOverhead = frameHeaderLen

// Frame is one multiplexer frame.
type Frame struct {
	Type     uint8
	StreamID uint64
	Payload  []byte
}

// ErrProtocol is returned/closed on any wire-protocol violation. The whole
// connection is torn down whenever it surfaces; we never try to resync.
var ErrProtocol = errors.New("tunnel: protocol violation")

// AppendFrame marshals f onto buf (appended) with bounds checking.
func AppendFrame(buf []byte, f Frame) ([]byte, error) {
	if uint64(len(f.Payload)) > maxFramePayloadHard {
		return buf, fmt.Errorf("%w: payload %d exceeds %d", ErrProtocol, len(f.Payload), maxFramePayloadHard)
	}
	if f.StreamID == 0 {
		return buf, fmt.Errorf("%w: stream ID 0 is reserved", ErrProtocol)
	}
	start := len(buf)
	buf = append(buf, FrameVersion, f.Type, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
	binary.BigEndian.PutUint64(buf[start+2:], f.StreamID)
	binary.BigEndian.PutUint32(buf[start+10:], uint32(len(f.Payload)))
	return append(buf, f.Payload...), nil
}

// ParseFrame parses exactly one frame from b (a complete WS binary message).
func ParseFrame(b []byte) (Frame, error) {
	if len(b) < frameHeaderLen {
		return Frame{}, fmt.Errorf("%w: short frame header %d", ErrProtocol, len(b))
	}
	if b[0] != FrameVersion {
		return Frame{}, fmt.Errorf("%w: frame version %d", ErrProtocol, b[0])
	}
	n := binary.BigEndian.Uint32(b[10:14])
	if uint64(n) > maxFramePayloadHard {
		return Frame{}, fmt.Errorf("%w: payload %d exceeds %d", ErrProtocol, n, maxFramePayloadHard)
	}
	if uint64(len(b)-frameHeaderLen) != uint64(n) {
		return Frame{}, fmt.Errorf("%w: frame payload %d, header says %d", ErrProtocol, len(b)-frameHeaderLen, n)
	}
	return Frame{
		Type:     b[1],
		StreamID: binary.BigEndian.Uint64(b[2:10]),
		Payload:  b[frameHeaderLen:],
	}, nil
}

// maxFramePayloadHard is the absolute frame payload ceiling regardless of
// configuration; configured limits must stay at or below it.
const maxFramePayloadHard = 1 << 20 // 1 MiB

// --- JSON handshake messages ----------------------------------------------
//
// All handshake messages are WebSocket TEXT frames; everything after the
// handshake is BINARY. A binary message while the handshake expects JSON is
// a protocol violation.

const msgTypeChallenge = "challenge"
const msgTypeAuth = "auth"
const msgTypeOK = "ok"
const msgTypeError = "error"
const msgTypeReady = "ready"

// HostChallenge is sent by the gateway immediately after the agent WS
// upgrades (design: host WS first server challenge). Its fields are exactly
// the identity.Challenge binding fields; both sides build the same
// identity.Challenge and sign/verify its canonical transcript, so there is
// no transcript format drift between enrollment and host auth.
type HostChallenge struct {
	Type string `json:"type"`
	V    int    `json:"v"`
	// ChallengeID is a random single-use token.
	ChallengeID string `json:"challenge_id"`
	// Nonce is the server nonce (base64 std of 32 random bytes).
	Nonce string `json:"nonce"`
	// ConnectionNonce binds the challenge to this connection.
	ConnectionNonce string `json:"connection_nonce"`
	// Server is the canonical hostname (challenge Domain field); the agent
	// rejects challenges naming a different server than configured.
	Server string `json:"server"`
	// Role and Protocol are fixed ("host", ProtocolTunnel) and verified.
	Role     string `json:"role"`
	Protocol string `json:"protocol"`
	// ExpiresAt is the challenge deadline as a unix timestamp.
	ExpiresAt int64 `json:"expires_at"`
}

// ToIdentityChallenge rebuilds the canonical challenge for signing or
// verifying. accountID is bound as "" during host auth: the agent does not
// know it (the challenge is issued server-first), and device-to-account
// binding was established and signed at enrollment; the gateway derives
// the account from the store and checks ownership separately.
func (c *HostChallenge) ToIdentityChallenge(deviceID string) (*identity.Challenge, error) {
	if c.Role != identity.RoleHost || c.Protocol != ProtocolTunnel {
		return nil, fmt.Errorf("challenge: role/protocol mismatch (%s/%s)", c.Role, c.Protocol)
	}
	nonce, err := stdEncoding.DecodeString(c.Nonce)
	if err != nil || len(nonce) < 16 {
		return nil, errors.New("challenge: bad nonce")
	}
	return &identity.Challenge{
		ID:              c.ChallengeID,
		Role:            c.Role,
		Protocol:        c.Protocol,
		Domain:          c.Server,
		DeviceID:        deviceID,
		AccountID:       "",
		Nonce:           c.Nonce,
		ConnectionNonce: c.ConnectionNonce,
		ExpiresAt:       time.Unix(c.ExpiresAt, 0).UTC(),
	}, nil
}

// HostAuth is the agent's signed reply. StreamWindow is the agent's
// announced receive window (bytes/stream/direction) for flow-control
// negotiation (FH-2); zero/absent is the legacy "no negotiation" marker.
type HostAuth struct {
	Type     string `json:"type"`
	V        int    `json:"v"`
	DeviceID string `json:"device_id"`
	// Signature is Ed25519 over the identity.Challenge transcript,
	// base64 (std).
	Signature string `json:"signature"`
	// StreamWindow announces the agent's receive window to the gateway
	// (optional; 0 = pre-negotiation peer). It is NOT part of the signed
	// transcript: the gateway rejects malformed values (negative,
	// above-cap) and never raises its own window because of it.
	StreamWindow int `json:"stream_window,omitempty"`
}

// OKMsg is the gateway's handshake completion frame. StreamWindow carries
// the NEGOTIATED symmetric per-stream window (min of both sides, hard-cap
// bounded): both muxes must run exactly this value. Zero/absent means the
// gateway build predates negotiation; peers then run their own configured
// windows, which are only compatible when equal (shipped defaults match).
type OKMsg struct {
	Type         string `json:"type"`
	V            int    `json:"v"`
	StreamWindow int    `json:"stream_window,omitempty"`
}

// ErrMsg is sent before closing on any rejection.
type ErrMsg struct {
	Type    string `json:"type"`
	V       int    `json:"v"`
	Code    string `json:"code"`
	Message string `json:"message"`
}

// ClientAuth is the first message on a client WebSocket. The routing
// credential (the sync broker's short-lived gateway-scoped JWT) travels
// only inside this frame — never in a URL, header or query.
type ClientAuth struct {
	Type     string `json:"type"`
	V        int    `json:"v"`
	Token    string `json:"token"`
	DeviceID string `json:"device_id"`
}

// ReadyMsg tells the client the stream is open end-to-end. SSHHostKey is
// ADVISORY registry metadata only: it must never be the source of client
// trust — real clients verify the SSH host key against an independently
// provisioned pin (see docs/tunnel.md, finding O1).
type ReadyMsg struct {
	Type       string `json:"type"`
	V          int    `json:"v"`
	DeviceID   string `json:"device_id"`
	SSHHostKey string `json:"ssh_host_key"`
}

// stdEncoding is the base64 variant used for every base64 field on the
// wire (std alphabet, padded).
var stdEncoding = base64.StdEncoding

// randomToken returns n crypto-random bytes base64-encoded (std, padded).
func randomToken(n int) (string, error) {
	b, err := randomNonce(n)
	if err != nil {
		return "", err
	}
	return stdEncoding.EncodeToString(b), nil
}

// randomNonce returns n raw crypto-random bytes.
func randomNonce(n int) ([]byte, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return nil, err
	}
	return b, nil
}

// randomStreamID returns a nonzero random uint64.
func randomStreamID() (uint64, error) {
	var b [8]byte
	for {
		if _, err := rand.Read(b[:]); err != nil {
			return 0, err
		}
		id := binary.BigEndian.Uint64(b[:])
		if id != 0 {
			return id, nil
		}
	}
}
