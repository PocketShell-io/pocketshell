package tunnel

import (
	"errors"
	"fmt"
	"io"
	"net"
	"sync"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
)

// ProtocolTunnel is the tunnel's protocol string inside challenge
// transcripts (identity package owns the canonical enrollment protocol).
const ProtocolTunnel = "pocketshell-tunnel/1"

// Endpoint roles. Exactly one side of a connection opens streams; the
// other accepts. A frame that violates the role is answered with RESET
// (never a teardown of unrelated streams) and dropped.
type Role int

const (
	// RoleGateway is the gateway side: it opens streams toward the host
	// (one per authenticated client) and never accepts.
	RoleGateway Role = iota
	// RoleHost is the host-agent side: it accepts streams (bridging each
	// to its loopback SSH endpoint) and never opens.
	RoleHost
)

// Mux multiplexes independent byte streams over one Transport. Streams use
// credit-based flow control in each direction: a sender may only have
// StreamWindow bytes in flight per stream, the receiving side returns
// credit as its local reader consumes data, and the receiver enforces the
// window on arrival — a peer that overruns its credit is disconnected
// before any unbounded buffer can grow (fail closed).
//
// Stream IDs are random 64-bit values scoped to one Mux instance (one
// connection epoch): IDs never repeat across reconnects, so stale frames
// from a previous connection can never address a stream on a new one.
// Recently closed stream IDs are kept in a bounded tombstone set so late
// in-flight frames for a dead stream are dropped instead of tearing down
// unrelated streams; frames for never-seen IDs remain a hard protocol
// error.
type Mux struct {
	tr     Transport
	limits Limits
	role   Role

	mu        sync.Mutex
	streams   map[uint64]*Stream
	tombstone []uint64 // FIFO of recently closed stream IDs
	closed    bool
	doneErr   error
	doneCh    chan struct{}
	doneOnce  sync.Once

	// ctrlCh carries outbound control frames (RESET refusals the reader
	// must not block on). It is bounded; ONE worker goroutine drains it, so
	// a peer cannot make the mux spawn goroutines without limit (finding:
	// resetAsync previously spawned one goroutine per rejected frame).
	// Overflow under a sustained flood fails closed synchronously: the
	// frame that hit the full queue makes handleOpen/Open return a protocol
	// error, and the caller's own goroutine tears the connection down
	// rather than buffering without bound or spawning cleanup fanout.
	ctrlCh     chan Frame
	workerDone chan struct{}

	// acceptCh carries host-role OPEN deliveries. It is buffered and
	// NEVER closed: a closed-channel send would race concurrent senders;
	// shutdown is signaled by doneCh alone.
	acceptCh chan *Stream
}

// acceptQueueDepth bounds OPEN deliveries awaiting Accept before the peer
// gets a RESET instead of silence. The mux reader never blocks on it.
const acceptQueueDepth = 64

// ctrlQueueDepth bounds queued RESET control frames; the single worker
// drains it, so only a sustained flood can overflow it — and overflow is a
// hard teardown, never unbounded buffering.
const ctrlQueueDepth = 256

// tombstoneCap bounds how many recently closed stream IDs are remembered
// for late-frame tolerance.
const tombstoneCap = 1024

// ErrMuxClosed is returned once the Mux (or its transport) is down.
var ErrMuxClosed = errors.New("tunnel: multiplexer closed")

// NewMux starts the read loop over tr. role selects which side opens
// streams: gateways Open, hosts Accept.
func NewMux(tr Transport, limits Limits, role Role) *Mux {
	m := &Mux{
		tr:         tr,
		limits:     limits.Resolved(),
		role:       role,
		streams:    make(map[uint64]*Stream),
		acceptCh:   make(chan *Stream, acceptQueueDepth),
		ctrlCh:     make(chan Frame, ctrlQueueDepth),
		workerDone: make(chan struct{}),
		doneCh:     make(chan struct{}),
	}
	go m.controlWorker()
	go m.readLoop()
	return m
}

// controlWorker is the single writer of reader-generated control frames
// (RESET refusals). It exits when the mux is torn down; teardown joins it
// after closing the transport so a blocked write can always unblock.
func (m *Mux) controlWorker() {
	defer close(m.workerDone)
	for {
		// Prefer exit when shutdown and a queued frame are both ready.
		select {
		case <-m.doneCh:
			return
		default:
		}
		select {
		case f := <-m.ctrlCh:
			if err := m.tr.WriteFrame(f); err != nil {
				// The transport is dead. Tear down from a separate
				// goroutine: teardown joins this worker, and it must never
				// join itself.
				go m.teardown(err)
				return
			}
		case <-m.doneCh:
			return
		}
	}
}

// Done is closed exactly once when the Mux is torn down.
func (m *Mux) Done() <-chan struct{} { return m.doneCh }

// Err reports why the Mux closed. Meaningful once Done has closed.
func (m *Mux) Err() error {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.doneErr
}

// Len returns the number of live streams (quotas, tests).
func (m *Mux) Len() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.streams)
}

// teardown runs exactly once: wakes every waiter via doneCh, wakes all
// streams, closes the transport, and joins the control worker (which is
// guaranteed to exit once doneCh is closed and the transport is unblocked).
// acceptCh is deliberately left open so a concurrent handleOpen send can
// never hit a closed channel; it selects against doneCh instead.
func (m *Mux) teardown(err error) {
	m.doneOnce.Do(func() {
		m.mu.Lock()
		if m.closed {
			m.mu.Unlock()
			return
		}
		m.closed = true
		if err != nil {
			m.doneErr = err
		}
		streams := make([]*Stream, 0, len(m.streams))
		for id, s := range m.streams {
			streams = append(streams, s)
			m.tombstoneAddLocked(id)
		}
		m.streams = map[uint64]*Stream{}
		m.mu.Unlock()
		close(m.doneCh)
		_ = m.tr.Close()
		for _, s := range streams {
			s.muxGone()
		}
		<-m.workerDone
	})
}

// Close tears the Mux and its transport down and wakes all streams.
func (m *Mux) Close() error { m.teardown(nil); return nil }

// writeFrame serializes one frame write; a write error tears the Mux down.
func (m *Mux) writeFrame(f Frame) error {
	m.mu.Lock()
	closed := m.closed
	m.mu.Unlock()
	if closed {
		return ErrMuxClosed
	}
	if err := m.tr.WriteFrame(f); err != nil {
		m.teardown(err)
		return err
	}
	return nil
}

// resetAsync queues a RESET on the bounded control queue without blocking
// the caller (the mux reader must never wait on peer backpressure). One
// worker goroutine drains the queue; if a flood keeps it full, the enqueue
// FAILS and the caller must tear the connection down on its own goroutine —
// overflow never spawns cleanup goroutines, so no peer behavior can make
// the mux create work without bound.
func (m *Mux) resetAsync(id uint64, reason string) error {
	if len(reason) > 256 {
		reason = reason[:256]
	}
	f := Frame{Type: FrameReset, StreamID: id, Payload: []byte(reason)}
	select {
	case m.ctrlCh <- f:
		return nil
	default:
		return fmt.Errorf("%w: control frame queue overflow", ErrProtocol)
	}
}

func (m *Mux) readLoop() {
	for {
		f, err := m.tr.ReadFrame()
		if err != nil {
			if errors.Is(err, io.EOF) {
				err = io.ErrUnexpectedEOF
			}
			m.teardown(err)
			return
		}
		if err := m.handleFrame(f); err != nil {
			m.teardown(err)
			return
		}
	}
}

func (m *Mux) tombstoneAddLocked(id uint64) {
	m.tombstone = append(m.tombstone, id)
	if len(m.tombstone) > tombstoneCap {
		// Drop the oldest half; O(1) amortized, bounded memory.
		m.tombstone = append(m.tombstone[:0], m.tombstone[len(m.tombstone)/2:]...)
	}
}

func (m *Mux) isTombstonedLocked(id uint64) bool {
	for _, t := range m.tombstone {
		if t == id {
			return true
		}
	}
	return false
}

func (m *Mux) tombstoned(id uint64) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.isTombstonedLocked(id)
}

// bury removes a live stream and remembers its ID for late-frame tolerance.
func (m *Mux) bury(id uint64) {
	m.mu.Lock()
	delete(m.streams, id)
	m.tombstoneAddLocked(id)
	m.mu.Unlock()
}

func (m *Mux) handleFrame(f Frame) error {
	if f.StreamID == 0 {
		return fmt.Errorf("%w: stream ID 0 is reserved", ErrProtocol)
	}
	m.mu.Lock()
	s := m.streams[f.StreamID]
	dead := s == nil
	late := dead && m.isTombstonedLocked(f.StreamID)
	m.mu.Unlock()

	switch f.Type {
	case FrameOpen:
		return m.handleOpen(f)
	case FrameAck:
		if dead {
			if late {
				return nil // abandoned stream; the opener is long gone
			}
			return fmt.Errorf("%w: ACK for unknown stream %d", ErrProtocol, f.StreamID)
		}
		if len(f.Payload) != 0 {
			return fmt.Errorf("%w: ack frame carries payload", ErrProtocol)
		}
		s.markAcked()
		return nil
	case FrameReset:
		if dead {
			if late {
				return nil
			}
			return fmt.Errorf("%w: reset for unknown stream %d", ErrProtocol, f.StreamID)
		}
		reason := "reset by peer"
		if len(f.Payload) > 0 {
			if len(f.Payload) > 256 {
				f.Payload = f.Payload[:256]
			}
			reason = string(f.Payload)
		}
		s.pushReset(errors.New(reason))
		return nil
	case FrameData:
		if dead {
			if late {
				return nil
			}
			return fmt.Errorf("%w: data for unknown stream %d", ErrProtocol, f.StreamID)
		}
		return s.pushData(f.Payload)
	case FrameEOF:
		if dead {
			if late {
				return nil
			}
			return fmt.Errorf("%w: EOF for unknown stream %d", ErrProtocol, f.StreamID)
		}
		s.pushEOF()
		return nil
	case FrameWindow:
		if dead {
			if late {
				return nil
			}
			return fmt.Errorf("%w: window for unknown stream %d", ErrProtocol, f.StreamID)
		}
		if len(f.Payload) != 4 {
			return fmt.Errorf("%w: window frame payload %d bytes", ErrProtocol, len(f.Payload))
		}
		n := uint32(f.Payload[0])<<24 | uint32(f.Payload[1])<<16 | uint32(f.Payload[2])<<8 | uint32(f.Payload[3])
		return s.addCredit(n)
	default:
		return fmt.Errorf("%w: unknown frame type %d", ErrProtocol, f.Type)
	}
}

// handleOpen enforces the endpoint role and, on the host side, delivers
// the new stream to Accept through a bounded queue. It never blocks the
// mux reader: overflow and role violations get an immediate RESET.
func (m *Mux) handleOpen(f Frame) error {
	if len(f.Payload) != 0 {
		return fmt.Errorf("%w: open frame carries payload", ErrProtocol)
	}
	if m.role != RoleHost {
		// Role-invalid OPEN: refuse and forget, never deliver.
		m.mu.Lock()
		m.tombstoneAddLocked(f.StreamID)
		m.mu.Unlock()
		return m.resetAsync(f.StreamID, "unexpected open")
	}
	m.mu.Lock()
	if m.closed {
		m.mu.Unlock()
		return ErrMuxClosed
	}
	if _, dup := m.streams[f.StreamID]; dup {
		m.mu.Unlock()
		return fmt.Errorf("%w: duplicate stream %d", ErrProtocol, f.StreamID)
	}
	if m.isTombstonedLocked(f.StreamID) {
		// Replay of a recently closed ID: refuse, never resurrect.
		m.mu.Unlock()
		return m.resetAsync(f.StreamID, "stream id closed")
	}
	if len(m.streams) >= m.limits.MaxStreamsPerHost {
		m.mu.Unlock()
		return m.resetAsync(f.StreamID, "stream limit reached")
	}
	s := newStream(m, f.StreamID)
	m.streams[f.StreamID] = s
	m.mu.Unlock()

	select {
	case m.acceptCh <- s:
		return nil
	default:
		// Accept queue full: refuse without blocking the reader.
		m.mu.Lock()
		delete(m.streams, f.StreamID)
		m.tombstoneAddLocked(f.StreamID)
		m.mu.Unlock()
		s.muxGone()
		return m.resetAsync(f.StreamID, "too many pending streams")
	}
}

// Open (gateway role) creates a random-ID stream and waits for the host to
// ACK (local SSH dial succeeded) or RESET it, within timeout. On timeout
// the peer is RESET and the ID tombstoned, so the host's late frames are
// dropped without harming other streams.
func (m *Mux) Open(timeout time.Duration) (*Stream, error) {
	m.mu.Lock()
	if m.closed {
		m.mu.Unlock()
		return nil, ErrMuxClosed
	}
	if m.role != RoleGateway {
		m.mu.Unlock()
		return nil, errors.New("tunnel: only the gateway side opens streams")
	}
	if len(m.streams) >= m.limits.MaxStreamsPerHost {
		m.mu.Unlock()
		return nil, fmt.Errorf("tunnel: host stream limit %d reached", m.limits.MaxStreamsPerHost)
	}
	id, err := randomStreamID()
	if err != nil {
		m.mu.Unlock()
		return nil, err
	}
	if _, dup := m.streams[id]; dup {
		m.mu.Unlock()
		return nil, fmt.Errorf("tunnel: stream ID collision")
	}
	s := newStream(m, id)
	s.ackCh = make(chan struct{})
	m.streams[id] = s
	// Capture the channel under the same lock: a concurrent immediate ACK
	// closes and nils the field, and a select on a nil channel never fires.
	ackCh := s.ackCh
	m.mu.Unlock()

	if err := m.writeFrame(Frame{Type: FrameOpen, StreamID: id}); err != nil {
		m.bury(id)
		s.muxGone()
		return nil, err
	}
	timer := time.NewTimer(timeout)
	defer timer.Stop()
	select {
	case <-ackCh:
		if err := s.ackError(); err != nil {
			m.bury(id)
			return nil, err
		}
		return s, nil
	case <-timer.C:
		m.bury(id)
		s.muxGone()
		if err := m.resetAsync(id, "open timeout"); err != nil {
			// The refusal cannot be queued (queue overflowed): fail closed
			// from this goroutine instead of leaving the overflow dangling.
			// teardown is once-idempotent and joins the worker safely — its
			// transport close always unblocks the worker, and the caller
			// here is never the worker itself.
			m.teardown(err)
		}
		return nil, fmt.Errorf("tunnel: host did not acknowledge stream within %s", timeout)
	case <-m.doneCh:
		m.bury(id)
		return nil, ErrMuxClosed
	}
}

// Accept (host role) returns the next peer-opened stream. The caller dials
// its local endpoint, then either Ack()s or Reset(err)s the stream.
func (m *Mux) Accept() (*Stream, error) {
	select {
	case s := <-m.acceptCh:
		// A stream queued just before teardown is already dead.
		if s.isGone() {
			return nil, ErrMuxClosed
		}
		return s, nil
	case <-m.doneCh:
		// Drain queued streams so they are woken and garbage-collected.
		for {
			select {
			case s := <-m.acceptCh:
				s.muxGone()
			default:
				return nil, ErrMuxClosed
			}
		}
	}
}

// Stream is one independent, ordered, flow-controlled byte stream. On the
// wire its payload is opaque end-to-end SSH bytes and nothing else.
type Stream struct {
	id  uint64
	mux *Mux

	mu            sync.Mutex
	updateCh      chan struct{} // closed+replaced whenever observable state changes
	buf           []byte
	eof           bool // remote sent EOF
	reset         bool
	resetErr      error
	gone          bool // mux torn down / stream abandoned by its opener
	ackCh         chan struct{}
	ackErr        error
	localEOF      bool // we sent EOF (CloseWrite)
	sendWin       int64
	recvUnacked   int64 // bytes received but not yet credited back
	pendingUp     int64 // consumed bytes awaiting a WINDOW frame
	readDeadline  time.Time
	writeDeadline time.Time
	closed        bool
	closeOnce     sync.Once
}

const windowUpdateFlush = 32 << 10

func newStream(m *Mux, id uint64) *Stream {
	return &Stream{
		id:       id,
		mux:      m,
		updateCh: make(chan struct{}),
		sendWin:  int64(m.limits.StreamWindow),
	}
}

func (s *Stream) notify() {
	close(s.updateCh)
	s.updateCh = make(chan struct{})
}

// ID returns the stream's connection-epoch identifier.
func (s *Stream) ID() uint64 { return s.id }

func (s *Stream) markAcked() {
	s.mu.Lock()
	if s.ackCh != nil {
		s.ackErr = nil
		close(s.ackCh)
		s.ackCh = nil
	}
	s.mu.Unlock()
}

// ackError reports the OPEN outcome once the ack channel has closed.
func (s *Stream) ackError() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.ackErr
}

func (s *Stream) isGone() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.gone
}

func (s *Stream) waitCh() <-chan struct{} {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.updateCh
}

// pushData appends received bytes, enforcing the receive window first
// (finding A5): a peer that sends beyond its credit is a protocol error
// and the whole connection is torn down before buffers can grow unbounded.
func (s *Stream) pushData(p []byte) error {
	s.mu.Lock()
	if s.reset || s.closed || s.gone {
		s.mu.Unlock()
		return nil // torn down locally; peer learns via RESET/tombstone
	}
	s.recvUnacked += int64(len(p))
	if s.recvUnacked > int64(s.mux.limits.StreamWindow) {
		s.mu.Unlock()
		return fmt.Errorf("%w: stream %d exceeded its receive window", ErrProtocol, s.id)
	}
	s.buf = append(s.buf, p...)
	s.notify()
	s.mu.Unlock()
	return nil
}

func (s *Stream) pushEOF() {
	s.mu.Lock()
	s.eof = true
	s.notify()
	s.mu.Unlock()
}

func (s *Stream) pushReset(err error) {
	s.mu.Lock()
	if !s.reset {
		s.reset = true
		if err != nil {
			s.resetErr = err
		}
	}
	s.closeAckLocked(err)
	s.notify()
	s.mu.Unlock()
}

// addCredit grants send credit, rejecting window inflation (finding A5):
// credit can only return toward the initial window, never exceed it.
func (s *Stream) addCredit(n uint32) error {
	s.mu.Lock()
	if s.sendWin+int64(n) > int64(s.mux.limits.StreamWindow) {
		s.mu.Unlock()
		return fmt.Errorf("%w: stream %d window grant exceeds the window", ErrProtocol, s.id)
	}
	s.sendWin += int64(n)
	s.notify()
	s.mu.Unlock()
	return nil
}

// muxGone is invoked when the mux or the opener abandons the stream:
// readers and writers wake with an error, Open waiters fail.
func (s *Stream) muxGone() {
	s.mu.Lock()
	s.gone = true
	s.reset = true
	if s.resetErr == nil {
		s.resetErr = ErrMuxClosed
	}
	s.closeAckLocked(ErrMuxClosed)
	s.notify()
	s.mu.Unlock()
}

func (s *Stream) closeAckLocked(err error) {
	if s.ackCh != nil {
		s.ackErr = err
		close(s.ackCh)
		s.ackCh = nil
	}
}

// Ack (host role) confirms the local SSH dial succeeded.
func (s *Stream) Ack() error {
	if err := s.mux.writeFrame(Frame{Type: FrameAck, StreamID: s.id}); err != nil {
		return err
	}
	s.markAcked()
	return nil
}

// Reset (host role) aborts the stream with a short, non-sensitive reason.
func (s *Stream) Reset(reason string) error {
	if len(reason) > 256 {
		reason = reason[:256]
	}
	err := s.mux.writeFrame(Frame{Type: FrameReset, StreamID: s.id, Payload: []byte(reason)})
	s.pushReset(errors.New(reason))
	s.mux.bury(s.id)
	return err
}

// Read implements io.Reader. After a remote EOF and a drained buffer it
// returns io.EOF; after Reset or Close it returns the reset/close error.
// Consumed bytes are returned to the peer as window credit; credit is
// flushed whenever the buffer drains, so arbitrarily small windows keep
// making progress (finding A11).
func (s *Stream) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	for {
		s.mu.Lock()
		switch {
		case s.closed:
			s.mu.Unlock()
			return 0, io.ErrClosedPipe
		case len(s.buf) > 0:
			n := copy(p, s.buf)
			s.buf = s.buf[n:]
			s.pendingUp += int64(n)
			// Flush at the threshold OR on drain-to-empty: with a window
			// smaller than the threshold, drain-to-empty is the only
			// replenishment point and must not require EOF.
			flush := s.pendingUp >= windowUpdateFlush || len(s.buf) == 0
			s.notify()
			s.mu.Unlock()
			if flush {
				s.sendWindowUpdate()
			}
			return n, nil
		case s.reset:
			err := s.resetErr
			if err == nil {
				err = io.ErrClosedPipe
			}
			s.mu.Unlock()
			return 0, err
		case s.eof:
			pending := s.pendingUp
			s.pendingUp = 0
			s.mu.Unlock()
			if pending > 0 {
				s.sendWindowUpdate()
			}
			return 0, io.EOF
		}
		ch := s.updateCh
		var timer <-chan time.Time
		if !s.readDeadline.IsZero() {
			d := time.Until(s.readDeadline)
			if d <= 0 {
				s.mu.Unlock()
				return 0, errStreamTimeout
			}
			t := time.NewTimer(d)
			timer = t.C
			defer t.Stop()
		}
		s.mu.Unlock()
		select {
		case <-ch:
		case <-timer:
			return 0, errStreamTimeout
		case <-s.mux.doneCh:
			return 0, ErrMuxClosed
		}
	}
}

var errStreamTimeout = errors.New("tunnel: stream deadline exceeded")

// sendWindowUpdate returns consumed bytes as credit and mirrors the
// accounting on the receive side (recvUnacked drops by the granted amount).
func (s *Stream) sendWindowUpdate() {
	s.mu.Lock()
	n := s.pendingUp
	if n > 0xFFFFFFFF {
		n = 0xFFFFFFFF
	}
	s.pendingUp -= n
	s.recvUnacked -= n
	if n <= 0 {
		s.mu.Unlock()
		return
	}
	s.mu.Unlock()
	var payload [4]byte
	payload[0] = byte(n >> 24)
	payload[1] = byte(n >> 16)
	payload[2] = byte(n >> 8)
	payload[3] = byte(n)
	// A failed WINDOW write means the connection is dead anyway; the next
	// data write surfaces the error.
	_ = s.mux.writeFrame(Frame{Type: FrameWindow, StreamID: s.id, Payload: payload[:]})
}

// Write implements io.Writer. Credit is reserved atomically under the
// stream lock BEFORE the frame is written (finding A11), so concurrent
// writers can never jointly overspend the window; oversized writes are
// split into <=MaxFramePayload chunks.
func (s *Stream) Write(p []byte) (int, error) {
	total := len(p)
	sent := 0
	maxChunk := s.mux.limits.MaxFramePayload
	for sent < total {
		s.mu.Lock()
		if s.closed || s.reset || s.localEOF {
			err := io.ErrClosedPipe
			if s.reset && s.resetErr != nil && !s.closed {
				err = s.resetErr
			}
			s.mu.Unlock()
			return sent, err
		}
		n := total - sent
		if int64(n) > s.sendWin {
			n = int(s.sendWin)
		}
		if n > maxChunk {
			n = maxChunk
		}
		if n <= 0 {
			// Out of credit: wait for a WINDOW grant / reset / deadline.
			ch := s.updateCh
			var timer <-chan time.Time
			if !s.writeDeadline.IsZero() {
				d := time.Until(s.writeDeadline)
				if d <= 0 {
					s.mu.Unlock()
					return sent, errStreamTimeout
				}
				t := time.NewTimer(d)
				timer = t.C
				defer t.Stop()
			}
			s.mu.Unlock()
			select {
			case <-ch:
			case <-timer:
				return sent, errStreamTimeout
			case <-s.mux.doneCh:
				return sent, ErrMuxClosed
			}
			continue
		}
		// Reserve before sending: the deduction happens under the same
		// critical section that observed sendWin.
		s.sendWin -= int64(n)
		s.mu.Unlock()

		if err := s.mux.writeFrame(Frame{Type: FrameData, StreamID: s.id, Payload: p[sent : sent+n]}); err != nil {
			return sent, err
		}
		sent += n
	}
	return sent, nil
}

// CloseWrite half-closes: the peer's Read returns io.EOF after draining.
func (s *Stream) CloseWrite() error {
	s.mu.Lock()
	if s.localEOF {
		s.mu.Unlock()
		return nil
	}
	s.localEOF = true
	s.notify()
	s.mu.Unlock()
	return s.mux.writeFrame(Frame{Type: FrameEOF, StreamID: s.id})
}

// Close aborts the stream in both directions (RESET to the peer) and wakes
// local readers/writers with an error. Idempotent. The ID is tombstoned so
// the peer's late frames are dropped without harming other streams.
func (s *Stream) Close() error {
	var err error
	s.closeOnce.Do(func() {
		s.mu.Lock()
		s.closed = true
		s.notify()
		s.mu.Unlock()
		err = s.mux.writeFrame(Frame{Type: FrameReset, StreamID: s.id})
		s.mux.bury(s.id)
	})
	return err
}

// SetDeadline sets read and write deadlines (net.Conn compatibility).
func (s *Stream) SetDeadline(t time.Time) error {
	s.mu.Lock()
	s.readDeadline = t
	s.writeDeadline = t
	s.notify()
	s.mu.Unlock()
	return nil
}

// SetReadDeadline sets the deadline for future Read calls.
func (s *Stream) SetReadDeadline(t time.Time) error {
	s.mu.Lock()
	s.readDeadline = t
	s.notify()
	s.mu.Unlock()
	return nil
}

// SetWriteDeadline sets the deadline for future Write calls.
func (s *Stream) SetWriteDeadline(t time.Time) error {
	s.mu.Lock()
	s.writeDeadline = t
	s.notify()
	s.mu.Unlock()
	return nil
}

// pipeAddr is the symbolic address of a tunnel stream endpoint.
type pipeAddr struct{ network, addr string }

func (a pipeAddr) Network() string { return a.network }
func (a pipeAddr) String() string  { return a.addr }

// LocalAddr/RemoteAddr satisfy net.Conn; a tunnel stream has no meaningful
// IP addresses, so they are symbolic.
func (s *Stream) LocalAddr() net.Addr {
	return pipeAddr{"pocketshell-tunnel", fmt.Sprintf("tunnel-stream-%d-local", s.id)}
}

func (s *Stream) RemoteAddr() net.Addr {
	return pipeAddr{"pocketshell-tunnel", fmt.Sprintf("tunnel-stream-%d-remote", s.id)}
}

// Compile-time net.Conn conformance.
var _ net.Conn = (*Stream)(nil)

// identity is imported for the canonical challenge transcript contract:
// host authentication signs identity.Challenge transcripts with
// identity.RoleHost and ProtocolTunnel (see service.go and docs/tunnel.md).
var _ = identity.RoleHost
