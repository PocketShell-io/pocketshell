package tunnel

import (
	"context"
	"crypto/ed25519"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	neturl "net/url"
	"strings"
	"sync"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/gorilla/websocket"
)

// WebSocket close codes used by this service (4000-4999 application range).
// Exported: the host agent classifies them (auth failures are fatal, the
// rest are transient) and client implementers match on them.
const (
	CloseProtocol    = 4400
	CloseUnauth      = 4401
	CloseForbidden   = 4403
	CloseNotFound    = 4404
	CloseTimeout     = 4408
	CloseQuota       = 4429
	CloseHostOffline = 4503
)

// Service is the v1 tunnel gateway: it serves the host-agent WebSocket
// (Ed25519 device challenge auth) and the per-client WebSocket (routing
// credential auth, owner check against the registered device), and bridges
// the two with opaque multiplexed streams. It fails closed: NewService
// refuses to build without a device store and a token authenticator, so the
// new API is structurally disabled until a registry is configured.
//
// Revocation contract (for root wiring): the identity service registers
//
//	identitySvc.OnRevoke(func(d identity.Device) { tunnelSvc.RevokeDevice(d.ID) })
//
// after durably persisting the revocation (persist-before-notify).
// RevokeDevice atomically bumps the device's revocation epoch — the same
// generation host registrations check under the service mutex — tears down
// the host connection and every stream on it, and future registrations are
// refused because the epoch moved and the store reports Revoked. Re-revoking
// an unconnected device is fine and idempotent.
type Service struct {
	limits     Limits
	log        *slog.Logger
	store      DeviceStore
	auth       AuthenticateFunc
	challenges *challengeStore
	upgrader   websocket.Upgrader
	now        func() time.Time

	mu sync.Mutex
	// hosts maps device ID to its current connection; a new registration
	// supersedes (shuts down) the old one. Cleanups are pointer-guarded so
	// a superseded connection can never unregister its replacement.
	hosts map[string]*hostConn
	// generation increases per host registration (connection epoch).
	generation uint64
	// deviceSessions counts host registrations per device (the
	// per-device session generation exposed by PresenceSnapshot). It is
	// per device on purpose: the global generation would let one account
	// observe the connection churn of every other account. Entries are only
	// created after a valid device signature, so the map is bounded by the
	// enrolled registry (like revokedEpoch).
	deviceSessions map[string]uint64
	// revokedEpoch increases on every RevokeDevice for the device. Host
	// registration samples it before the device lookup and re-checks it
	// under this mutex at insert time, so a registration that raced a
	// revocation cannot complete after it (finding A1).
	revokedEpoch map[string]uint64
	// pendingHosts/pendingClients count pre-authentication WebSocket
	// upgrades in flight, so unauthenticated handshakes consume admission
	// budget too (finding A7).
	pendingHosts   int
	pendingClients int
	clientConns    int
	perAccount     map[string]int
	closed         bool
}

// ServiceOptions configures a Service. Store and Authenticate are required.
type ServiceOptions struct {
	Store DeviceStore
	// Authenticate verifies a routing credential (the sync broker's
	// short-lived scoped JWT; production wiring uses the shared routingauth
	// verifier) and returns the Principal it belongs to, including the
	// credential's ExpiresAt. Principals without a future ExpiresAt are
	// refused admission (fail closed).
	Authenticate AuthenticateFunc
	// AllowedOrigins lists extra browser origins (scheme+host) that may
	// open client WebSockets. Same-origin is always allowed; requests with
	// no Origin header (non-browser clients) are allowed. Empty list means
	// same-origin only.
	AllowedOrigins []string
	Logger         *slog.Logger
	Limits         Limits
	// Now overrides the clock (tests).
	Now func() time.Time
}

// NewService builds a gateway. It errors when Store or Authenticate is nil:
// no registry, no API.
func NewService(opts ServiceOptions) (*Service, error) {
	if opts.Store == nil {
		return nil, errors.New("tunnel: device store is required (new API stays disabled without a registry)")
	}
	if opts.Authenticate == nil {
		return nil, errors.New("tunnel: token authenticator is required")
	}
	log := opts.Logger
	if log == nil {
		log = slog.Default()
	}
	now := opts.Now
	if now == nil {
		now = time.Now
	}
	limits := opts.Limits.Resolved()
	return &Service{
		limits: limits,
		log:    log,
		store:  opts.Store,
		auth:   opts.Authenticate,
		now:    now,
		challenges: newChallengeStore(
			limits.ChallengeTTL,
			limits.ChallengeCapacity,
			now,
		),
		upgrader: websocket.Upgrader{
			ReadBufferSize:    4096,
			WriteBufferSize:   4096,
			EnableCompression: false, // SSH compresses its own way; no BREACH surface
			CheckOrigin:       checkOrigin(opts.AllowedOrigins),
		},
		hosts:          make(map[string]*hostConn),
		revokedEpoch:   make(map[string]uint64),
		deviceSessions: make(map[string]uint64),
		perAccount:     make(map[string]int),
	}, nil
}

// checkOrigin allows non-browser requests (no Origin header), same-origin
// requests and explicitly allowlisted origins; everything else is rejected.
func checkOrigin(allowed []string) func(*http.Request) bool {
	allow := make(map[string]bool, len(allowed))
	for _, o := range allowed {
		allow[strings.ToLower(strings.TrimSuffix(strings.ToLower(o), "/"))] = true
	}
	return func(r *http.Request) bool {
		origin := r.Header.Get("Origin")
		if origin == "" {
			return true // non-browser client
		}
		o := strings.ToLower(origin)
		if allow[o] {
			return true
		}
		// Same-origin: scheme and host must match the request itself.
		rhost := strings.ToLower(r.Host)
		if u, err := neturl.Parse(o); err == nil && strings.EqualFold(u.Host, rhost) {
			return true
		}
		return false
	}
}

// Close disconnects every host agent and marks the service closed.
func (s *Service) Close() {
	s.mu.Lock()
	s.closed = true
	conns := make([]*hostConn, 0, len(s.hosts))
	for _, hc := range s.hosts {
		conns = append(conns, hc)
	}
	s.hosts = map[string]*hostConn{}
	s.mu.Unlock()
	for _, hc := range conns {
		hc.shutdown()
	}
}

// IsDeviceConnected reports whether a host agent is currently connected.
func (s *Service) IsDeviceConnected(deviceID string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	hc := s.hosts[deviceID]
	return hc != nil && hc.ready
}

// HostPresence is the live state of one device's host agent at a snapshot.
// Online means a host session completed its handshake (OK written) and is
// the device's current, unrevoked registration — exactly the readiness the
// client path requires before it would OPEN a stream. ConnectedSince is the
// gateway time that session became ready; Session is the per-device
// registration count in this gateway process (it restarts at 1 after a
// gateway restart). Both are zero when offline.
type HostPresence struct {
	Online         bool
	ConnectedSince time.Time
	Session        uint64
}

// PresenceSnapshot reports, under ONE acquisition of the service mutex, the
// presence of each listed device owned by accountID, and the gateway time
// the snapshot was taken. A device is online only when its current host
// connection is ready AND was registered for the same account (defense in
// depth: callers pass the caller's own durable device list). Unknown,
// foreign, not-yet-acknowledged, revoked-and-tearing-down and superseded
// connections are all offline. Streams are irrelevant: an idle host is
// online. The returned map always has an entry per requested ID.
func (s *Service) PresenceSnapshot(accountID string, deviceIDs []string) (time.Time, map[string]HostPresence) {
	out := make(map[string]HostPresence, len(deviceIDs))
	s.mu.Lock()
	defer s.mu.Unlock()
	observed := s.now()
	for _, id := range deviceIDs {
		hc := s.hosts[id]
		if s.closed || accountID == "" || hc == nil || !hc.ready || hc.accountID != accountID {
			out[id] = HostPresence{}
			continue
		}
		out[id] = HostPresence{Online: true, ConnectedSince: hc.readySince, Session: hc.session}
	}
	return observed, out
}

// RevokeDevice forcibly disconnects the device's host agent and every
// active client stream riding on it. The identity package persists the
// revocation first (persist-before-notify) and calls this via OnRevoke;
// subsequent registrations fail because the epoch moved and the store
// reports Revoked. It reports whether the device was connected.
func (s *Service) RevokeDevice(deviceID string) bool {
	s.mu.Lock()
	s.revokedEpoch[deviceID]++ // closes the lookup/registration race (A1)
	hc := s.hosts[deviceID]
	if hc != nil {
		// Unpublish readiness in the same critical section as the epoch
		// bump: between here and the asynchronous cleanupHost the entry
		// still exists, and neither new client streams nor presence may
		// treat a revoked (or key-replaced) session as live.
		hc.ready = false
	}
	s.mu.Unlock()
	if hc == nil {
		return false
	}
	s.log.Info("tunnel: revoked device connected, disconnecting", "device", deviceID)
	hc.shutdown()
	return true
}

func (s *Service) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	s.mu.Lock()
	closed := s.closed
	s.mu.Unlock()
	if closed {
		http.Error(w, "gateway shutting down", http.StatusServiceUnavailable)
		return
	}
	switch {
	case r.URL.Path == PathAgentConnect:
		s.serveAgent(w, r)
	default:
		deviceID, ok := parseClientSSHPath(r.URL.Path)
		if !ok {
			http.Error(w, "not found", http.StatusNotFound)
			return
		}
		s.serveClient(w, r, deviceID)
	}
}

// parseClientSSHPath parses the published client route
// /api/v1/hosts/{deviceID}/ssh inside the service itself — root wiring does
// not need a path-rewriting shim, and clients and the gateway speak one
// route. The device ID must be registry-wellformed; anything else is not
// this route.
func parseClientSSHPath(path string) (deviceID string, ok bool) {
	if !strings.HasPrefix(path, PathClientSSH) {
		return "", false
	}
	rest := strings.TrimPrefix(path, PathClientSSH)
	if !strings.HasSuffix(rest, clientSSHPathSuffix) {
		return "", false
	}
	id := strings.TrimSuffix(rest, clientSSHPathSuffix)
	if id == "" || len(id) > 128 || !identity.ValidDeviceID(id) {
		return "", false
	}
	return id, true
}

// clientSSHPathSuffix is the fixed tail of the published client route.
const clientSSHPathSuffix = "/ssh"

func requireUpgrade(w http.ResponseWriter, r *http.Request) bool {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return false
	}
	if !websocket.IsWebSocketUpgrade(r) {
		http.Error(w, "pocketshell tunnel (websocket only)", http.StatusUpgradeRequired)
		return false
	}
	return true
}

// --- host agent side -------------------------------------------------------

type hostConn struct {
	svc        *Service
	deviceID   string
	accountID  string
	generation uint64
	// ready is protected by svc.mu; hosts also reserves handshaking capacity.
	ready bool
	// readySince (gateway clock) and session (per-device registration
	// count) are protected by svc.mu; readySince is set when ready is.
	readySince time.Time
	session    uint64
	ws         *websocket.Conn
	mux        *Mux
	transport  *wsTransport
	done       chan struct{}
	closeOnce  sync.Once
}

// shutdown tears the connection and every stream down exactly once.
func (hc *hostConn) shutdown() {
	hc.closeOnce.Do(func() {
		hc.mux.Close()
		_ = hc.ws.Close()
	})
}

// admitPending reserves a pending-handshake slot atomically (finding A7):
// unauthenticated upgrades consume budget so pre-auth floods are bounded.
func (s *Service) admitPendingHost() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || s.pendingHosts >= s.limits.MaxHosts {
		return false
	}
	s.pendingHosts++
	return true
}

func (s *Service) releasePendingHost() {
	s.mu.Lock()
	s.pendingHosts--
	s.mu.Unlock()
}

func (s *Service) admitPendingClient() bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || s.pendingClients >= s.limits.MaxClientsGlobal {
		return false
	}
	s.pendingClients++
	return true
}

func (s *Service) releasePendingClient() {
	s.mu.Lock()
	s.pendingClients--
	s.mu.Unlock()
}

func (s *Service) serveAgent(w http.ResponseWriter, r *http.Request) {
	if !requireUpgrade(w, r) {
		return
	}
	if !s.admitPendingHost() {
		http.Error(w, "gateway at host capacity", http.StatusTooManyRequests)
		return
	}
	defer s.releasePendingHost()

	ws, err := s.upgrader.Upgrade(w, r, nil)
	if err != nil {
		return // Upgrade already wrote the error
	}
	ws.SetReadLimit(int64(s.limits.MaxFramePayload + FrameOverhead + 4096))
	writer := NewWSWriter(ws, s.limits)

	// 1. Challenge (server speaks first). The full identity.Challenge is
	// stored; the agent signs its canonical transcript.
	challenge, err := s.challenges.issue(canonicalHost(r))
	if err != nil {
		s.reject(writer, CloseTimeout, "challenge", "challenge capacity reached")
		return
	}
	wire := HostChallenge{
		Type: msgTypeChallenge, V: ProtocolVersion,
		ChallengeID: challenge.ID, Nonce: challenge.Nonce,
		ConnectionNonce: challenge.ConnectionNonce,
		Server:          challenge.Domain,
		Role:            challenge.Role, Protocol: challenge.Protocol,
		ExpiresAt: challenge.ExpiresAt.Unix(),
	}
	if err := writer.WriteMessage(websocket.TextMessage, mustJSON(wire)); err != nil {
		_ = ws.Close()
		return
	}

	// 2. Signed auth within the handshake deadline.
	_ = ws.SetReadDeadline(time.Now().Add(s.limits.HandshakeTimeout))
	var auth HostAuth
	if !s.readJSON(ws, writer, &auth) {
		return // readJSON closes
	}
	if auth.Type != msgTypeAuth || auth.V != ProtocolVersion || auth.DeviceID == "" || auth.Signature == "" {
		s.reject(writer, CloseProtocol, "protocol", "malformed auth frame")
		return
	}
	// Flow-control negotiation (FH-2), before anything is allocated: a
	// negative or above-cap announcement is a broken or lying peer and
	// fails the handshake closed. Zero/absent is the legacy marker (the
	// peer does not negotiate); the window stays at this gateway's own
	// configured value — peers that do not negotiate must run equal
	// windows (shipped defaults do).
	if auth.StreamWindow < 0 || auth.StreamWindow > MaxStreamWindow {
		s.reject(writer, CloseProtocol, "protocol", "invalid stream window")
		return
	}
	// The negotiated window is the symmetric per-stream credit both muxes
	// enforce: min(gateway, agent), never raised by the announcement.
	negotiated := s.limits.StreamWindow
	if auth.StreamWindow > 0 && auth.StreamWindow < negotiated {
		negotiated = auth.StreamWindow
	}
	muxLimits := s.limits
	muxLimits.StreamWindow = negotiated
	stored, err := s.challenges.redeem(challenge.ID)
	if err != nil {
		s.log.Info("tunnel: host challenge redeem failed", "device", auth.DeviceID, "err", err)
		s.reject(writer, CloseUnauth, "challenge", "challenge invalid or expired")
		return
	}
	// Bind the claimed device ID into the stored challenge: it was issued
	// server-first without one, and the agent's signature covers it — a
	// replay for another device cannot verify.
	stored.DeviceID = auth.DeviceID
	// A1: sample the revocation epoch BEFORE the store lookup; at insert
	// time, re-check it under the service mutex. If it moved, a revocation
	// raced this registration and the retried lookup will see it.
	for attempt := 0; attempt < 3; attempt++ {
		s.mu.Lock()
		epoch := s.revokedEpoch[auth.DeviceID]
		s.mu.Unlock()

		dev, err := s.store.GetDevice(auth.DeviceID)
		if err != nil || dev.Revoked {
			s.log.Info("tunnel: host auth for missing or revoked device", "device", auth.DeviceID)
			s.reject(writer, CloseForbidden, "revoked", "device unknown or revoked")
			return
		}
		sig, sigErr := stdEncoding.DecodeString(auth.Signature)
		if sigErr != nil || len(sig) != ed25519.SignatureSize {
			s.reject(writer, CloseUnauth, "signature", "signature verification failed")
			return
		}
		if err := identity.Verify(ed25519.PublicKey(dev.PublicKey), stored, sig); err != nil {
			s.log.Info("tunnel: host auth signature rejected", "device", auth.DeviceID, "err", err)
			s.reject(writer, CloseUnauth, "signature", "signature verification failed")
			return
		}

		// 3. Register atomically: epoch unchanged + capacity + not closed.
		s.mu.Lock()
		if s.closed || s.revokedEpoch[auth.DeviceID] != epoch {
			s.mu.Unlock()
			continue // raced a revocation; retry the lookup
		}
		if len(s.hosts) >= s.limits.MaxHosts {
			s.mu.Unlock()
			s.reject(writer, CloseQuota, "quota", "gateway at host capacity")
			return
		}
		// Share the ONE writer with the JSON/ping paths above (A3).
		transport := NewWSTransportWithWriter(ws, writer, s.limits)
		hc := &hostConn{
			svc:       s,
			deviceID:  auth.DeviceID,
			accountID: dev.AccountID,
			ws:        ws,
			transport: transport,
			done:      make(chan struct{}),
		}
		// The gateway mux enforces the NEGOTIATED window (FH-2): the host
		// side runs the same value from OKMsg.StreamWindow, so asymmetric
		// local configs can never look like a protocol violation.
		hc.mux = NewMux(transport, muxLimits, RoleGateway)
		s.generation++
		hc.generation = s.generation
		s.deviceSessions[auth.DeviceID]++
		hc.session = s.deviceSessions[auth.DeviceID]
		if old := s.hosts[auth.DeviceID]; old != nil {
			go old.shutdown() // replaced; its cleanup is pointer-guarded
		}
		s.hosts[auth.DeviceID] = hc
		s.mu.Unlock()

		// 4. Handshake complete: acknowledge (announcing the negotiated
		// stream window, FH-2), switch to binary mux frames, and move to
		// the liveness deadline (finding A4): the handshake read deadline
		// must not survive into the session.
		if err := writer.WriteMessage(websocket.TextMessage, mustJSON(OKMsg{Type: msgTypeOK, V: ProtocolVersion, StreamWindow: negotiated})); err != nil {
			hc.shutdown()
			s.cleanupHost(hc)
			return
		}
		// Keep the capacity/generation reservation visible to revoke and replacement,
		// but expose it to clients only after the shared writer completes OK.
		// A concurrent revoke, Close or replacement must never publish stale readiness.
		s.mu.Lock()
		current := !s.closed && s.hosts[auth.DeviceID] == hc && s.revokedEpoch[auth.DeviceID] == epoch
		if current {
			hc.ready = true
			hc.readySince = s.now()
		}
		s.mu.Unlock()
		if !current {
			hc.shutdown()
			s.cleanupHost(hc)
			return
		}
		ws.SetPongHandler(func(string) error {
			return ws.SetReadDeadline(time.Now().Add(s.limits.PongWait))
		})
		_ = ws.SetReadDeadline(time.Now().Add(s.limits.PongWait))

		s.log.Info("tunnel: host connected", "device", hc.deviceID, "generation", hc.generation)
		go s.pingLoop(writer, hc.done)
		<-hc.mux.Done()
		hc.shutdown()
		s.cleanupHost(hc)
		s.log.Info("tunnel: host disconnected", "device", hc.deviceID, "generation", hc.generation,
			"reason", fmt.Sprint(hc.mux.Err()))
		return
	}
	// Every attempt raced a revocation: fail closed.
	s.log.Info("tunnel: host registration kept losing the revocation race", "device", auth.DeviceID)
	s.reject(writer, CloseForbidden, "revoked", "device unknown or revoked")
}

// cleanupHost unregisters hc only if it is still the current connection —
// a superseded connection's late teardown must never unregister or disturb
// its replacement (acceptance: host reconnect cannot stale-cleanup).
func (s *Service) cleanupHost(hc *hostConn) {
	close(hc.done)
	s.mu.Lock()
	defer s.mu.Unlock()
	if cur := s.hosts[hc.deviceID]; cur == hc {
		delete(s.hosts, hc.deviceID)
	}
}

// canonicalHost extracts the Host header value for challenge binding.
func canonicalHost(r *http.Request) string {
	h := r.Host
	if h == "" {
		return "unknown"
	}
	// Strip any port for transcript stability behind TLS terminators that
	// rewrite it; the hostname is the stable identity.
	if host, _, err := net.SplitHostPort(h); err == nil && host != "" {
		return host
	}
	return h
}

// --- client side -----------------------------------------------------------

func (s *Service) serveClient(w http.ResponseWriter, r *http.Request, deviceID string) {
	if !requireUpgrade(w, r) {
		return
	}
	if !s.admitPendingClient() {
		http.Error(w, "gateway at capacity", http.StatusTooManyRequests)
		return
	}
	defer s.releasePendingClient()

	ws, err := s.upgrader.Upgrade(w, r, nil)
	if err != nil {
		return
	}
	ws.SetReadLimit(int64(s.limits.MaxFramePayload + 4096))
	writer := NewWSWriter(ws, s.limits)

	// 1. First frame: JSON auth with the routing credential minted by the
	// sync broker (a short-lived scoped JWT). Never a query parameter; the
	// token never appears in any URL or log.
	_ = ws.SetReadDeadline(time.Now().Add(s.limits.HandshakeTimeout))
	var auth ClientAuth
	if !s.readJSON(ws, writer, &auth) {
		return
	}
	if auth.Type != msgTypeAuth || auth.V != ProtocolVersion || auth.Token == "" || auth.DeviceID == "" {
		s.reject(writer, CloseProtocol, "protocol", "malformed auth frame")
		return
	}
	// Route consistency: everything downstream (ownership, ready, OPEN) is
	// keyed by the frame's device, so the frame's device MUST be the device
	// on the dialed /api/v1/hosts/{deviceID}/ssh route. A mismatch is a
	// protocol violation refused before any store lookup or stream OPEN;
	// both values are client-chosen, so the verdict leaks nothing about
	// device existence or ownership.
	if auth.DeviceID != deviceID {
		s.log.Info("tunnel: client device route mismatch", "route", deviceID, "device", auth.DeviceID)
		s.reject(writer, CloseProtocol, "protocol", "device route mismatch")
		return
	}

	// 2. Verify the credential and the ownership chain: verified account
	// must equal the registered device owner. Account IDs come from the
	// authenticator, never from the client.
	authCtx, cancel := context.WithTimeout(context.Background(), s.limits.HandshakeTimeout)
	defer cancel()
	principal, err := s.auth(authCtx, auth.Token)
	if err != nil {
		s.log.Info("tunnel: client token rejected", "device", auth.DeviceID, "err", err)
		s.reject(writer, CloseUnauth, "unauthorized", "token verification failed")
		return
	}
	// The admission credential must carry a positive, unexpired lifetime.
	// A zero expiry means the verifier did not propagate the token's
	// lifetime and fails closed, matching the identity package's contract.
	if admissionExpired(principal, s.now()) {
		s.log.Info("tunnel: client admission credential has no future expiry", "device", auth.DeviceID)
		s.reject(writer, CloseUnauth, "unauthorized", "token verification failed")
		return
	}

	// 3. Ownership: unknown, revoked and other-owner devices are denied
	// with ONE identical response so a probe cannot tell which one it hit
	// (device-existence oracle). Specifics go to the log only.
	dev, err := s.store.GetDevice(auth.DeviceID)
	if err != nil || dev.Revoked || dev.AccountID == "" || dev.AccountID != principal.AccountID {
		if err == nil {
			s.log.Info("tunnel: client device denied", "device", auth.DeviceID,
				"account", principal.AccountID, "revoked", dev.Revoked, "owner", dev.AccountID != principal.AccountID)
		} else {
			s.log.Info("tunnel: client target device missing", "device", auth.DeviceID, "account", principal.AccountID)
		}
		s.reject(writer, CloseNotFound, "not_found", uniformClientDenial)
		return
	}
	// The lookup can block (a gated or slow store); the credential must
	// still be alive after it.
	if admissionExpired(principal, s.now()) {
		s.reject(writer, CloseUnauth, "unauthorized", "token verification failed")
		return
	}

	// 4. Admission quotas (per account, global), released on disconnect.
	if !s.admitClient(principal.AccountID) {
		s.reject(writer, CloseQuota, "quota", "too many concurrent sessions")
		return
	}
	defer s.releaseClient(principal.AccountID)

	// 5. Open a multiplexed stream to the host; the host dials its local
	// loopback sshd and ACKs.
	s.mu.Lock()
	hc := s.hosts[auth.DeviceID]
	ready := hc != nil && hc.ready
	s.mu.Unlock()
	if !ready {
		s.reject(writer, CloseHostOffline, "host_offline", uniformClientDenial)
		return
	}
	stream, err := hc.mux.Open(s.limits.OpenAckTimeout)
	if err != nil {
		s.log.Info("tunnel: stream open failed", "device", hc.deviceID, "err", err)
		s.reject(writer, CloseHostOffline, "host_offline", uniformClientDenial)
		return
	}
	// The OPEN wait (local SSH dial on the host) is bounded but not zero:
	// the credential must still be valid before the session becomes ready.
	if admissionExpired(principal, s.now()) {
		stream.Close()
		s.reject(writer, CloseUnauth, "unauthorized", "token verification failed")
		return
	}

	// 6. ready: stream is open. SSHHostKey is ADVISORY registry metadata;
	// clients must verify the SSH host key against an independently
	// provisioned pin and never derive trust from this frame (finding O1).
	if err := writer.WriteMessage(websocket.TextMessage, mustJSON(ReadyMsg{
		Type: msgTypeReady, V: ProtocolVersion,
		DeviceID: dev.ID, SSHHostKey: dev.SSHHostKey,
	})); err != nil {
		stream.Close()
		_ = ws.Close()
		return
	}

	// 7. From here the WebSocket carries opaque SSH bytes only. The
	// gateway never inspects them. Sessions are absolutely bounded
	// (MaxSessionDuration) independently of the admission credential's
	// short expiry: token expiry controls admission only; there is no
	// mid-session re-authentication, and no session is unbounded.
	s.log.Info("tunnel: client session open", "device", hc.deviceID, "account", principal.AccountID)
	s.bridgeClient(ws, writer, stream)
	s.log.Info("tunnel: client session closed", "device", hc.deviceID, "account", principal.AccountID)
}

// uniformClientDenial is the ONE client-visible denial message for unknown,
// revoked and other-owner devices (and for the offline/open-failure paths,
// which only verified owners reach). Constants by design: no delta, no oracle.
const uniformClientDenial = "host unknown, offline or forbidden"

// admissionExpired reports that the verified credential cannot admit a
// session: the verifier did not propagate a positive expiry, or it has
// already passed. Zero expiry fails closed.
func admissionExpired(p Principal, now time.Time) bool {
	return p.ExpiresAt.IsZero() || !p.ExpiresAt.After(now)
}

func (s *Service) admitClient(accountID string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || s.clientConns >= s.limits.MaxClientsGlobal {
		return false
	}
	if s.perAccount[accountID] >= s.limits.MaxClientsPerAccount {
		return false
	}
	s.clientConns++
	s.perAccount[accountID]++
	return true
}

func (s *Service) releaseClient(accountID string) {
	s.mu.Lock()
	s.clientConns--
	if s.perAccount[accountID]--; s.perAccount[accountID] <= 0 {
		delete(s.perAccount, accountID)
	}
	s.mu.Unlock()
}

// bridgeClient pumps opaque bytes between the client WebSocket and the
// host stream until either side ends or the session deadline fires; then
// both are torn down. It returns when the session is fully closed.
func (s *Service) bridgeClient(ws *websocket.Conn, writer *WSWriter, stream *Stream) {
	done := make(chan struct{})
	var once sync.Once
	stop := func() {
		once.Do(func() {
			_ = stream.Close()
			_ = ws.Close()
			close(done)
		})
	}

	// Absolute session bound (JWT semantics: the bearer token verified at
	// auth time expires; sessions must not outlive it indefinitely).
	timer := time.NewTimer(s.limits.MaxSessionDuration)
	go func() {
		defer timer.Stop()
		select {
		case <-timer.C:
			stop()
		case <-done:
		}
	}()

	// Client -> host.
	go func() {
		ws.SetPongHandler(func(string) error {
			return ws.SetReadDeadline(time.Now().Add(s.limits.PongWait))
		})
		for {
			_ = ws.SetReadDeadline(time.Now().Add(s.limits.PongWait))
			msgType, data, err := ws.ReadMessage()
			if err != nil {
				break
			}
			if msgType != websocket.BinaryMessage {
				break // JSON after handshake is a protocol violation
			}
			if _, err := stream.Write(data); err != nil {
				break
			}
		}
		stop()
	}()

	// Keepalive: periodic pings; pongs extend the reader's deadline.
	go s.pingLoop(writer, done)

	// Host -> client.
	buf := make([]byte, 32<<10)
	for {
		n, err := stream.Read(buf)
		if n > 0 {
			if werr := writer.WriteMessage(websocket.BinaryMessage, buf[:n]); werr != nil {
				break
			}
		}
		if err != nil {
			break
		}
	}
	stop()
	<-done
}

// pingLoop sends WS pings through the serialized writer; the peers' pong
// handlers extend their read deadlines.
func (s *Service) pingLoop(writer *WSWriter, done chan struct{}) {
	t := time.NewTicker(s.limits.PingInterval)
	defer t.Stop()
	for {
		select {
		case <-t.C:
			if err := writer.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		case <-done:
			return
		}
	}
}

// readJSON reads one handshake JSON text frame; on any failure it sends an
// error frame, closes the connection and returns false.
func (s *Service) readJSON(ws *websocket.Conn, writer *WSWriter, v any) bool {
	// Caller set the read deadline.
	msgType, data, err := ws.ReadMessage()
	if err != nil {
		s.reject(writer, CloseTimeout, "timeout", "handshake deadline exceeded")
		return false
	}
	if msgType != websocket.TextMessage {
		s.reject(writer, CloseProtocol, "protocol", "expected JSON auth frame")
		return false
	}
	if err := json.Unmarshal(data, v); err != nil {
		s.reject(writer, CloseProtocol, "protocol", "malformed JSON auth frame")
		return false
	}
	return true
}

// reject sends a JSON error frame and closes the WebSocket with an
// application close code. Text is generic by design; specifics go to logs.
func (s *Service) reject(writer *WSWriter, code int, errCode, logSafeMsg string) {
	_ = writer.WriteMessage(websocket.TextMessage, mustJSON(ErrMsg{
		Type: msgTypeError, V: ProtocolVersion, Code: errCode, Message: logSafeMsg,
	}))
	_ = writer.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(code, errCode))
	_ = writer.ws.Close()
}

func mustJSON(v any) []byte {
	b, err := json.Marshal(v)
	if err != nil {
		// Static structs only; this cannot happen.
		return []byte(`{"type":"error","v":1,"code":"internal","message":"encode"}`)
	}
	return b
}
