package tunnel

import (
	"bytes"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// peer is the raw protocol endpoint on the other side of a net.Pipe: it
// reads and writes multiplexer frames with full control (including
// malformed ones).
type peer struct {
	tr *pipeTransport
	c  net.Conn
}

func newMuxPair(t *testing.T, limits Limits, role Role) (*Mux, *peer) {
	t.Helper()
	c1, c2 := net.Pipe()
	mux := NewMux(newPipeTransport(c1), limits, role)
	t.Cleanup(func() { mux.Close(); c1.Close(); c2.Close() })
	return mux, &peer{tr: newPipeTransport(c2), c: c2}
}

func (p *peer) write(t *testing.T, f Frame) {
	t.Helper()
	if err := p.tr.WriteFrame(f); err != nil {
		t.Fatalf("peer write: %v", err)
	}
}

// tryWrite is the goroutine-safe variant: after a teardown the pipe is
// closed and writes legitimately fail; tests that race Close use this.
func (p *peer) tryWrite(f Frame) error { return p.tr.WriteFrame(f) }

// tryWriteRaw writes raw bytes; a teardown mid-frame can close the pipe
// under the writer, which callers treat as the teardown signal itself.
func (p *peer) tryWriteRaw(b []byte) error {
	_, err := p.c.Write(b)
	return err
}

func (p *peer) writeRaw(t *testing.T, b []byte) {
	t.Helper()
	if _, err := p.c.Write(b); err != nil {
		t.Fatalf("peer raw write: %v", err)
	}
}

// tryRead reads one frame with a deadline. There must be at most ONE
// reader goroutine calling this at any time: competing readers on one
// framed pipe steal each other's frames (harness bug in earlier rounds).
func (p *peer) tryRead(d time.Duration) (Frame, bool) {
	_ = p.c.SetReadDeadline(time.Now().Add(d))
	f, err := p.tr.ReadFrame()
	_ = p.c.SetReadDeadline(time.Time{})
	if err != nil {
		return Frame{}, false
	}
	return f, true
}

// spawnReader starts the ONE peer reader goroutine for a test. It collects
// RESET ids and frames losslessly until the test closes stopReader or the
// peer pipe dies. Every mux test drives outbound frames through exactly
// one reader.
//
// Lifecycle: reads are blocking pipeTransport.ReadFrame calls, so a frame
// is never abandoned half-consumed at a poll deadline and alignment
// survives peer writes that are split across time; a read error is
// terminal — the goroutine exits instead of retrying a closed pipe in a
// busy loop. One idempotent stop signal (close of the internal stop channel
// plus the peer conn close) terminates the reader out of BOTH parked
// states — a blocking read and a forwarding send parked on a full output
// channel — and every exit path funnels through it exactly once. The
// reader and the stop relay each close their own done channel (done,
// relayDone) on exit; the reader's exit also fires the shared stop, so a
// terminal read error releases the relay too. Workers only signal; nobody
// self-joins: the cleanup registered HERE is the owner — it signals the
// stop and then observes BOTH done channels before returning, reporting a
// timeout instead of leaving a worker runnable or unwinding past the test
// that owned it. A caller that stops the reader itself must observe the
// same complete lifetime boundedly (stopPeerReader). Callers must be done
// writing to the peer once they stop the reader — true of every current
// callsite, where the join is the test's last action. A peer pipe EOF
// alone, while the reader cannot read, is NOT promised to release a parked
// forwarding send; the stop signal is.
//
// On exit the reader closes both forwarding channels, so a consumer parked
// on a receive is released on every path. Every consumer of these channels
// must receive with the comma-ok form and stop on !ok — receiving blindly
// would spin on the closed channels.
func (p *peer) spawnReader(t *testing.T, stopReader <-chan struct{}) (resetIDs <-chan uint64, frames <-chan Frame, done <-chan struct{}, relayDone <-chan struct{}) {
	t.Helper()
	ids := make(chan uint64, 1024)
	fr := make(chan Frame, 1024)
	d := make(chan struct{})
	relayd := make(chan struct{})
	stop := make(chan struct{})
	var stopOnce sync.Once
	// stopReading is the single idempotent stop/conn-close signal: it
	// unblocks the parked blocking read and releases a forwarding send
	// parked on a full output channel. Workers call it only to signal; only
	// the owner cleanup (or a caller via stopPeerReader) joins.
	stopReading := func() {
		stopOnce.Do(func() {
			close(stop)
			p.c.Close()
		})
	}
	// Owner cleanup for every exit path, including a Fatal before the test
	// ever stops the reader: signal, then join BOTH workers before
	// returning — bounded, with the straggler named. The joins happen
	// before this cleanup returns, so they are observable immediately when
	// the owning subtest finishes, not eventually.
	t.Cleanup(func() {
		stopReading()
		select {
		case <-d:
		case <-time.After(5 * time.Second):
			t.Error("peer reader did not terminate within 5s of the owner stop")
		}
		select {
		case <-relayd:
		case <-time.After(5 * time.Second):
			t.Error("stop relay did not terminate within 5s of the owner stop")
		}
	})
	// Stop relay: the test's stop channel shares the owner stop semantics,
	// so the relay itself always has one live case and never leaks.
	go func() {
		defer close(relayd)
		select {
		case <-stopReader:
			stopReading()
		case <-stop:
		}
	}()
	go func() {
		defer close(d)
		defer close(ids) // release consumers parked on a receive
		defer close(fr)
		defer stopReading() // terminal reader exit releases the relay too
		for {
			// Blocking read: framing is never abandoned mid-frame. The only
			// possible error is the transport dying — the stop closed it, the
			// test's cleanup closed it, or the scenario failed — and it is
			// terminal either way; closed-pipe errors are never retried.
			f, err := p.tr.ReadFrame()
			if err != nil {
				return
			}
			switch f.Type {
			case FrameReset:
				select {
				case ids <- f.StreamID:
				case <-stop:
					return
				}
			default:
				select {
				case fr <- f:
				case <-stop:
					return
				}
			}
		}
	}()
	return ids, fr, d, relayd
}

// stopPeerReader is the bounded caller-side shutdown of a spawnReader
// worker set: close the caller's stop channel, then observe the reader's
// AND the relay's done channels — the complete lifetime — each within a
// bound, so a stalled shutdown names its straggler instead of hanging the
// test past its last line.
func stopPeerReader(t *testing.T, stopReader chan struct{}, readerDone, relayDone <-chan struct{}) {
	t.Helper()
	close(stopReader)
	select {
	case <-readerDone:
	case <-time.After(5 * time.Second):
		t.Error("peer reader did not terminate within 5s of the caller stop")
	}
	select {
	case <-relayDone:
	case <-time.After(5 * time.Second):
		t.Error("stop relay did not terminate within 5s of the caller stop")
	}
}

// ackResponder is the ACK consumer both A6 regressions launch against the
// spawnReader output: it ACKs every OPEN the peer reader forwards and
// publishes each written ACK's stream id. It exits when its stop closes OR
// its input channel closes (the reader's exit closes it on every path), so
// a parked receive is always released; a write parked on the synchronous
// pipe is released only by the owner conn close, which the registered
// cleanup performs BEFORE joining (close-before-join). ACK write failures
// are forwarded on errCh exactly once and terminate the responder, so a
// liveness regression surfaces its cause instead of silently pretending
// the ACKs still flow.
type ackResponder struct {
	p      *peer
	frames <-chan Frame

	stop     chan struct{}
	stopOnce sync.Once
	done     chan struct{}
	errCh    chan error  // first ACK write failure, buffered, never blocks
	ackedIDs chan uint64 // post-success ACK stream ids, never blocks
}

func newAckResponder(p *peer, frames <-chan Frame) *ackResponder {
	return &ackResponder{
		p:        p,
		frames:   frames,
		stop:     make(chan struct{}),
		done:     make(chan struct{}),
		errCh:    make(chan error, 1),
		ackedIDs: make(chan uint64, 8),
	}
}

// stopNow is the idempotent release signal: it ends the receive loop and,
// together with the owner conn close, any write parked on the pipe.
func (a *ackResponder) stopNow() {
	a.stopOnce.Do(func() { close(a.stop) })
}

// launch registers the responder's owner cleanup (idempotent stop, peer
// conn close, bounded join — in that order, so a parked receive is
// released by the stop and a parked write by the conn close before the
// join waits) and only then starts the goroutine. Registered after the
// peer reader's own cleanup, it runs FIRST at teardown (LIFO), so the
// consumer join never waits on a conn that is still open and the reader's
// owner joins complete after it.
func (a *ackResponder) launch(t *testing.T) {
	t.Helper()
	t.Cleanup(func() {
		a.stopNow()
		a.p.c.Close() // release a write parked on the synchronous pipe
		select {
		case <-a.done:
		case <-time.After(5 * time.Second):
			t.Error("ack responder did not terminate within 5s of the owner stop")
		}
	})
	go a.run()
}

func (a *ackResponder) run() {
	defer close(a.done)
	for {
		select {
		case <-a.stop:
			return
		case f, ok := <-a.frames:
			if !ok {
				return // the peer reader exited; its channels are closed
			}
			if f.Type != FrameOpen {
				continue
			}
			if err := a.p.tryWrite(Frame{Type: FrameAck, StreamID: f.StreamID}); err != nil {
				select {
				case a.errCh <- fmt.Errorf("ack write for stream %d: %w", f.StreamID, err):
				default:
				}
				return
			}
			select {
			case a.ackedIDs <- f.StreamID:
			default:
			}
		}
	}
}

func testLimits() Limits {
	return Limits{
		MaxFramePayload:    16 << 10,
		StreamWindow:       64 << 10,
		MaxStreamsPerHost:  8,
		HandshakeTimeout:   time.Second,
		PongWait:           time.Second,
		PingInterval:       100 * time.Millisecond,
		WSWriteTimeout:     time.Second,
		MaxSessionDuration: time.Hour,
	}
}

func frameStr(f Frame) string {
	return fmt.Sprintf("{type:%d id:%d len:%d}", f.Type, f.StreamID, len(f.Payload))
}

// writeAll is a deadline-bounded raw conn write for the reader-lifecycle
// controls: a regressed reader that stops consuming must fail the write at
// the deadline instead of wedging the control forever.
func writeAll(t *testing.T, c net.Conn, b []byte) {
	t.Helper()
	_ = c.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if _, err := c.Write(b); err != nil {
		t.Fatalf("raw write of %d bytes: %v", len(b), err)
	}
	_ = c.SetWriteDeadline(time.Time{})
}

// probeWrite attempts one deadline-bounded raw write and reports whether it
// completed before the deadline. A timeout is park evidence: net.Pipe
// writes are synchronous, so a write that outlives its deadline proves the
// reader never came back to consume. This is safe ONLY where the probe is
// the sole concurrent writer on the endpoint direction: a net.Pipe write
// deadline is a property of the endpoint, not of one write call, so
// SetWriteDeadline here also arms the deadline of any OTHER write already
// parked on this direction and can cancel it. The ACK write-park control
// therefore never probes the ACK writer's endpoint and observes real wire
// progress on the receiving endpoint instead.
func probeWrite(t *testing.T, c net.Conn, b []byte, within time.Duration) bool {
	t.Helper()
	_ = c.SetWriteDeadline(time.Now().Add(within))
	_, err := c.Write(b)
	_ = c.SetWriteDeadline(time.Time{})
	if err == nil {
		return true
	}
	if !errors.Is(err, os.ErrDeadlineExceeded) {
		t.Fatalf("probe write of %d bytes: %v", len(b), err)
	}
	return false
}

// fillReaderOutput fills one spawnReader output channel to capacity with
// real AppendFrame-encoded copies of f delivered through bounded raw
// writes, and leaves the reader provably PARKED forwarding into the full
// channel: each capacity write returns only once the reader has consumed
// those bytes (delivery barrier — nothing is dropped or batched away), the
// first probe may complete because the reader was still parked on its
// blocking read, but after consuming it the next send has no room, so the
// second probe must time out (park barrier). A completed second probe
// means the output was drained by someone: harness bug. The channel
// capacity is exactly the reader's buffer size; no buffer is enlarged.
func fillReaderOutput(t *testing.T, c net.Conn, f Frame, capacity int) {
	t.Helper()
	encoded, err := AppendFrame(nil, f)
	if err != nil {
		t.Fatal(err)
	}
	for i := 0; i < capacity; i++ {
		writeAll(t, c, encoded)
	}
	if !probeWrite(t, c, encoded, 500*time.Millisecond) {
		return // the reader was already parked on the full output
	}
	if probeWrite(t, c, encoded, 500*time.Millisecond) {
		t.Fatal("full output drained while nobody drains it: park barrier broken")
	}
}

// TestSpawnReaderReassemblesFragmentedFrame is the framing control for the
// peer reader: one real AppendFrame-encoded RESET reaches the reader in two
// pieces — the header, then the payload after a gap — and must still be
// delivered intact. The header write returns only once the reader has
// consumed all 14 header bytes, which pins any poll deadline the reader
// installed to at most 100ms after that moment; the payload arrives 300ms
// later, so a reader that abandons a half-consumed frame at its deadline
// deterministically restarts its parser on the payload bytes, loses frame
// alignment, and never recovers the frame. A reader that runs each
// ReadFrame to completion (or a terminal transport error) reassembles the
// same frame regardless of the gap.
func TestSpawnReaderReassemblesFragmentedFrame(t *testing.T) {
	cWrite, cRead := net.Pipe()
	t.Cleanup(func() { cWrite.Close(); cRead.Close() })
	p := &peer{tr: newPipeTransport(cRead), c: cRead}

	stopReader := make(chan struct{})
	resetIDs, _, readerDone, relayDone := p.spawnReader(t, stopReader)

	full, err := AppendFrame(nil, Frame{Type: FrameReset, StreamID: 4242, Payload: []byte("open timeout")})
	if err != nil {
		t.Fatal(err)
	}
	writeAll(t, cWrite, full[:frameHeaderLen]) // returns once the header is consumed
	time.Sleep(300 * time.Millisecond)         // gap beyond any poll deadline
	writeAll(t, cWrite, full[frameHeaderLen:])

	select {
	case id, ok := <-resetIDs:
		if !ok {
			t.Fatal("reset output closed before the fragmented RESET arrived: the peer reader terminated instead of reassembling the frame")
		}
		if id != 4242 {
			t.Fatalf("reset id %d, want 4242", id)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("fragmented RESET never delivered: the reader lost frame alignment across the gap")
	}
	stopPeerReader(t, stopReader, readerDone, relayDone)
}

// TestSpawnReaderExitsWhenPipeDiesWithoutStop is the no-retry-leak control
// for the early-failure state: the reader is spawned, the test "aborts"
// without ever closing stopReader, and the peer pipe dies (what a Fatal's
// cleanup does). The reader must treat the dead pipe as terminal and exit;
// a reader that retries every read error in a tight loop spins on the
// closed pipe forever, leaking a busy goroutine per aborted test.
func TestSpawnReaderExitsWhenPipeDiesWithoutStop(t *testing.T) {
	cWrite, cRead := net.Pipe()
	t.Cleanup(func() { cWrite.Close(); cRead.Close() })
	p := &peer{tr: newPipeTransport(cRead), c: cRead}

	stopReader := make(chan struct{}) // never closed: the aborted test
	_, _, readerDone, _ := p.spawnReader(t, stopReader)

	cWrite.Close() // the peer side dies mid-test
	select {
	case <-readerDone:
	case <-time.After(2 * time.Second):
		t.Fatal("reader goroutine kept retrying a dead pipe after the test aborted")
	}
}

// TestSpawnReaderCleanupJoinsAbandonedReader pins the guarantee behind
// every early-Fatal path: the owner cleanup the reader starter registers
// terminates AND joins the reader and its stop relay BEFORE it returns —
// even when the test never closes stopReader and the pipe is still live.
// The subtest abandons the reader on purpose; when its t.Run returns, its
// cleanups have returned too, so the parent requires both done channels to
// be ALREADY closed. The checks are non-blocking on purpose: waiting here
// would re-test eventual shutdown instead of the join-before-return
// contract. (Against the pre-repair source this is exactly the property
// that was missing: the old cleanup only signalled the stop and joined
// nothing.)
func TestSpawnReaderCleanupJoinsAbandonedReader(t *testing.T) {
	var readerDone, relayDone <-chan struct{}
	t.Run("abandoned", func(t *testing.T) {
		_, p := newMuxPair(t, testLimits(), RoleGateway)
		stopReader := make(chan struct{}) // never closed: the aborted test
		_, _, done, relayd := p.spawnReader(t, stopReader)
		readerDone, relayDone = done, relayd
	})
	select {
	case <-readerDone:
	default:
		t.Error("abandoned reader was not joined by its own registered cleanup before it returned")
	}
	select {
	case <-relayDone:
	default:
		t.Error("abandoned reader's stop relay was not joined by the registered cleanup before it returned")
	}
}

// TestSpawnReaderFullOutputCleanupJoins pins the other half of the owner
// contract: the registered cleanup must terminate a reader parked
// FORWARDING into a full output channel — not only one parked on a blocked
// read — and join it and the relay before returning. Each subtest fills one
// output (RESET ids, then ordinary frames) to capacity with real encoded
// frames through bounded raw writes against the live pipe, proves the park
// with a timing-out probe write, and then abandons everything: stopReader
// is never closed and the outputs stay undrained. The pipe stays live on
// purpose — a peer pipe EOF alone is NOT what releases a parked forwarding
// send, so that path is not what this control relies on (or promises). When
// the subtest's t.Run returns, its cleanup has returned too, so the parent
// requires both done channels to be ALREADY closed; the checks are
// non-blocking because waiting would re-test eventual shutdown.
func TestSpawnReaderFullOutputCleanupJoins(t *testing.T) {
	cases := []struct {
		name  string
		frame Frame
	}{
		{"full reset output", Frame{Type: FrameReset, StreamID: 4242, Payload: []byte("x")}},
		{"full ordinary output", Frame{Type: FrameData, StreamID: 7, Payload: []byte("y")}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			var readerDone, relayDone <-chan struct{}
			t.Run("abandoned", func(t *testing.T) {
				cWrite, cRead := net.Pipe()
				t.Cleanup(func() { cWrite.Close(); cRead.Close() })
				p := &peer{tr: newPipeTransport(cRead), c: cRead}
				stopReader := make(chan struct{}) // never closed: the abandoned test
				_, _, done, relayd := p.spawnReader(t, stopReader)
				readerDone, relayDone = done, relayd
				fillReaderOutput(t, cWrite, tc.frame, 1024)
				// The reader is provably parked forwarding into its full
				// output; abandon it in exactly that state.
			})
			select {
			case <-readerDone:
			default:
				t.Error("parked reader was not joined by its own registered cleanup before it returned")
			}
			select {
			case <-relayDone:
			default:
				t.Error("parked reader's stop relay was not joined by the registered cleanup before it returned")
			}
		})
	}
}

// TestSpawnReaderCallerStopUnderFullOutput pins the explicit caller-stop
// path under the same full-capacity park: closing stopReader — not the
// conn, not the pipe — must release the reader's parked forwarding send and
// let the caller observe the complete lifetime (reader and relay)
// boundedly.
func TestSpawnReaderCallerStopUnderFullOutput(t *testing.T) {
	cWrite, cRead := net.Pipe()
	t.Cleanup(func() { cWrite.Close(); cRead.Close() })
	p := &peer{tr: newPipeTransport(cRead), c: cRead}

	stopReader := make(chan struct{})
	_, _, readerDone, relayDone := p.spawnReader(t, stopReader)
	fillReaderOutput(t, cWrite, Frame{Type: FrameData, StreamID: 7, Payload: []byte("y")}, 1024)

	stopPeerReader(t, stopReader, readerDone, relayDone)
}

// TestResetConsumerClosedOutputFailsPromptlyNoPhantom calibrates the
// closed-output contract every RESET consumer of the spawnReader output
// relies on: the reader can terminate BEFORE the expected RESETs have
// arrived (here the peer dies mid-test — what any early harness failure
// looks like to the reader), and its exit closes the ids channel. The
// shared-consumer receive loop — the exact shape the A6 regressions run —
// must then fail promptly through the comma-ok form, naming the reader
// termination, and must never let the closed-channel zero through as a
// phantom RESET frame. The former blind receive did exactly that (RED
// calibration TestREDResetIDsBlindReceiveClosedOutput in the 3975d46
// scratch worktree: it recorded phantom id 0 and spun on the closed
// channel to its deadline in 4/4 runs).
func TestResetConsumerClosedOutputFailsPromptlyNoPhantom(t *testing.T) {
	cWrite, cRead := net.Pipe()
	t.Cleanup(func() { cWrite.Close(); cRead.Close() })
	p := &peer{tr: newPipeTransport(cRead), c: cRead}

	stopReader := make(chan struct{}) // never closed: the peer death is the scenario
	resetIDs, _, readerDone, _ := p.spawnReader(t, stopReader)

	// Deliver exactly ONE real RESET; the peer then dies with the rest
	// never sent.
	enc, err := AppendFrame(nil, Frame{Type: FrameReset, StreamID: 4242, Payload: []byte("real")})
	if err != nil {
		t.Fatal(err)
	}
	writeAll(t, cWrite, enc) // returns once the reader consumed the frame
	cWrite.Close()           // peer dies before the remaining RESETs exist
	select {
	case <-readerDone:
	case <-time.After(2 * time.Second):
		t.Fatal("reader did not terminate on the peer close: closed-output scenario not established")
	}

	// The shared-consumer shape at an expected count well above the
	// delivered total: on !ok the loop must stop through the closed-output
	// case immediately, and the recorded set must hold exactly the one real
	// RESET.
	const expected = 64
	sawReset := map[uint64]bool{}
	outputClosed := false
	start := time.Now()
	for !outputClosed && len(sawReset) < expected {
		select {
		case id, ok := <-resetIDs:
			if !ok {
				outputClosed = true
				continue
			}
			sawReset[id] = true
		case <-time.After(2 * time.Second):
			t.Fatal("closed reset output was never detected: the consumer kept waiting instead of failing on the closure")
		}
	}
	if !outputClosed {
		t.Fatalf("consumer collected %v without detecting the closed output: a closed-channel zero was accepted as a phantom RESET frame", sawReset)
	}
	if len(sawReset) != 1 || !sawReset[4242] {
		t.Fatalf("recorded RESET set %v does not match the one real RESET 4242: a phantom frame leaked through the closed output", sawReset)
	}
	if d := time.Since(start); d > time.Second {
		t.Errorf("closed output detected only after %s: the failure was not prompt", d)
	}
	// The exited reader fired the shared stop, releasing the relay; the
	// reader's registered owner cleanup joins both before this test ends.
}

// TestA2DoneClosedOnceAndNoSendPanic: Done closes exactly once, acceptCh
// is never closed, and concurrent OPEN/Close races never panic.
//
// Harness rules (regression for the earlier flaky version): every flooded
// OPEN carries a UNIQUE stream ID — repeating an ID is a duplicate-stream
// protocol error that would tear the mux down before the Close race is
// exercised — the flooders synchronize on a barrier so the teardown really
// races in-flight sends, and the peer reader + Accept waiter are bounded
// and joined before the test returns.
func TestA2DoneClosedOnceAndNoSendPanic(t *testing.T) {
	limits := testLimits()
	mux, p := newMuxPair(t, limits, RoleHost)

	stopReader := make(chan struct{})
	resetIDs, frames, readerDone, relayDone := p.spawnReader(t, stopReader)
	_ = resetIDs
	_ = frames

	var nextID atomic.Uint64
	start := make(chan struct{})
	var floodWG sync.WaitGroup
	for i := 0; i < 16; i++ {
		floodWG.Add(1)
		go func() {
			defer floodWG.Done()
			<-start // barrier: everyone floods into the Close race
			for {
				id := 2000 + nextID.Add(1) // unique per iteration
				if err := p.tryWrite(Frame{Type: FrameOpen, StreamID: id}); err != nil {
					return // pipe closed by the teardown; expected
				}
			}
		}()
	}

	// Bounded Accept waiter: drains queued streams until the mux dies.
	acceptDone := make(chan struct{})
	go func() {
		defer close(acceptDone)
		for {
			s, err := mux.Accept()
			if err != nil {
				return
			}
			s.muxGone() // release the queued stream; mux is going away
		}
	}()

	time.Sleep(20 * time.Millisecond) // let the flood and the waiter engage
	mux.Close()
	close(start)
	floodWG.Wait()
	<-acceptDone

	select {
	case <-mux.Done():
	default:
		t.Fatal("Done not closed after Close")
	}
	mux.Close() // idempotent
	select {
	case <-mux.Done():
	default:
		t.Fatal("Done closed twice / unstable")
	}
	stopPeerReader(t, stopReader, readerDone, relayDone)
}

// openResult publishes an Open outcome the moment Open returns, so a test
// can synchronize on the opener's completion (buffered, size 1: the opener
// never blocks on the publisher).
type openResult struct {
	stream *Stream
	err    error
}

// TestA5ExcessDataTearsDown: a peer sending beyond its receive window is
// disconnected before buffers can grow unbounded.
//
// Harness: the Open result is awaited AFTER the ACK and BEFORE either DATA
// frame, so the opener's {ack, timeout, done} select has completed while
// doneCh is still open — the overrun teardown can never race it into
// returning ErrMuxClosed. The returned stream is retained unread: a
// consumer could drain the first DATA frame before the overrun arrives and
// legitimize the second one, so the receiver side stays parked.
func TestA5ExcessDataTearsDown(t *testing.T) {
	limits := testLimits()
	limits.StreamWindow = 8 << 10
	mux, p := newMuxPair(t, limits, RoleGateway)

	opened := make(chan openResult, 1)
	go func() {
		s, err := mux.Open(5 * time.Second)
		opened <- openResult{stream: s, err: err}
	}()
	f, ok := p.tryRead(time.Second)
	if !ok || f.Type != FrameOpen {
		t.Fatalf("expected OPEN, got %v", f)
	}
	p.write(t, Frame{Type: FrameAck, StreamID: f.StreamID})

	var legit *Stream
	select {
	case r := <-opened:
		if r.err != nil {
			t.Fatalf("open failed before the overrun: %v", r.err)
		}
		legit = r.stream
	case <-time.After(5 * time.Second):
		t.Fatal("open never completed after the ACK")
	}
	_ = legit // retained unread: the receive window stays exhausted below

	// Send window+1 bytes in two DATA frames: the second must trip the
	// window check and tear the connection down.
	payload := make([]byte, 8<<10)
	p.write(t, Frame{Type: FrameData, StreamID: f.StreamID, Payload: payload})
	p.write(t, Frame{Type: FrameData, StreamID: f.StreamID, Payload: payload[:1]})

	select {
	case <-mux.Done():
	case <-time.After(2 * time.Second):
		t.Fatal("connection survived a receive-window overrun")
	}
	if err := mux.Err(); err == nil || !errors.Is(err, ErrProtocol) {
		t.Fatalf("teardown err = %v, want protocol violation", err)
	}
}

// TestA5WindowGrantOverflow: WINDOW grants beyond the initial window are
// rejected.
func TestA5WindowGrantOverflow(t *testing.T) {
	limits := testLimits()
	limits.StreamWindow = 8 << 10
	mux, p := newMuxPair(t, limits, RoleGateway)

	go func() {
		_, _ = mux.Open(time.Second)
	}()
	f, ok := p.tryRead(time.Second)
	if !ok || f.Type != FrameOpen {
		t.Fatalf("expected OPEN, got %v", f)
	}
	p.write(t, Frame{Type: FrameAck, StreamID: f.StreamID})

	grant := make([]byte, 4)
	binary.BigEndian.PutUint32(grant, uint32(limits.StreamWindow)+1) // one over
	p.write(t, Frame{Type: FrameWindow, StreamID: f.StreamID, Payload: grant})

	select {
	case <-mux.Done():
	case <-time.After(2 * time.Second):
		t.Fatal("connection survived a window-overflow grant")
	}
}

// TestA6RoleInvalidOpenGetsReset: a gateway-role mux never delivers
// role-invalid OPENs and never blocks its reader; it RESETs them.
func TestA6RoleInvalidOpenGetsReset(t *testing.T) {
	limits := testLimits()
	mux, p := newMuxPair(t, limits, RoleGateway)

	// ONE reader for the whole test: it ACKs the later legitimate OPEN
	// (the peer is the host side for that stream) and collects the RESETs
	// for the role-invalid OPENs.
	stopReader := make(chan struct{})
	resetIDs, frames, readerDone, relayDone := p.spawnReader(t, stopReader)

	// The ACK responder is the shared A6 consumer, and its lifecycle is
	// registered BEFORE it starts: an idempotent stop, the conn close, and
	// a bounded join go into cleanup before the goroutine exists, so an
	// early Fatal below releases any parked receive — and, close before
	// join, any write parked on the synchronous pipe — instead of leaving
	// the goroutine parked past the test (the former inline responder
	// selected only on the caller's stopReader and the open frames channel,
	// neither of which anything closed on the abort path).
	resp := newAckResponder(p, frames)
	resp.launch(t)

	// Send many role-invalid OPENs.
	const invalid = acceptQueueDepth + 10
	for i := 0; i < invalid; i++ {
		p.write(t, Frame{Type: FrameOpen, StreamID: uint64(5000 + i)})
	}
	// The reader must stay responsive: every single one is RESET. The
	// comma-ok receive is the closed-output contract: if the peer reader
	// terminates before all RESETs arrive, the closure must fail the test
	// promptly with that cause — never spin on the always-ready closed
	// channel and never let a closed-channel zero through as a RESET.
	sawReset := map[uint64]bool{}
	deadline := time.After(5 * time.Second)
	for len(sawReset) < invalid {
		select {
		case id, ok := <-resetIDs:
			if !ok {
				t.Fatalf("reset output closed after %d/%d role-invalid OPENs were reset: the peer reader terminated instead of delivering the rest", len(sawReset), invalid)
			}
			sawReset[id] = true
		case err := <-resp.errCh:
			t.Fatalf("ack responder failed: %v", err)
		case <-deadline:
			t.Fatalf("only %d/%d role-invalid OPENs were reset", len(sawReset), invalid)
		}
	}

	// A subsequent legit Open works end-to-end: the reader was never
	// blocked by the refusals (its ACK reached us, and our Close RESET is
	// collected by the reader below).
	s, err := mux.Open(time.Second)
	if err != nil {
		// Surface the responder's cause with the failure instead of letting
		// a dead responder masquerade as reader blocking.
		select {
		case rerr := <-resp.errCh:
			t.Fatalf("open failed: %v (ack responder failed first: %v)", err, rerr)
		default:
		}
		t.Fatalf("reader blocked by role-invalid OPENs: %v", err)
	}
	if err := s.Close(); err != nil {
		t.Fatalf("close: %v", err)
	}

	// Normal finish: bounded observation of the complete lifetime — the
	// reader and relay via stopPeerReader, the responder via its done
	// channel (released by the reader's exit closing its input).
	stopPeerReader(t, stopReader, readerDone, relayDone)
	select {
	case <-resp.done:
	case <-time.After(5 * time.Second):
		t.Error("ack responder did not terminate within 5s of the caller stop")
	}
}

// TestA6AcceptQueueFullResets proves the full A6 property set: with ONE
// peer reader started BEFORE the flood, the 64 queued OPENs are admitted,
// exactly the 32 overflow OPENs are RESET by id, the reader survives
// through ACK/RESET cleanup, and — the part "Accept returned a queued
// stream" cannot prove — frames sent AFTER the flood are still delivered
// to the accepted stream (read-loop liveness).
func TestA6AcceptQueueFullResets(t *testing.T) {
	limits := testLimits()
	limits.MaxStreamsPerHost = acceptQueueDepth + 64 // cap above queue depth
	mux, p := newMuxPair(t, limits, RoleHost)

	// ONE reader, started before the flood; lossless RESET-id collection.
	stopReader := make(chan struct{})
	resetIDs, frames, readerDone, relayDone := p.spawnReader(t, stopReader)

	// Flood OPENs; nobody Accepts yet.
	const flooded = acceptQueueDepth + 32
	for i := 0; i < flooded; i++ {
		p.write(t, Frame{Type: FrameOpen, StreamID: uint64(6000 + i)})
	}

	// Exactly the overflow IDs must be reset: 6000+64 .. 6000+95. The
	// comma-ok receive fails promptly on the reader's closed output — a
	// terminated reader must be reported as the cause, and a closed-channel
	// zero must never be counted as a RESET.
	resets := map[uint64]bool{}
	deadline := time.After(5 * time.Second)
	for len(resets) < flooded-acceptQueueDepth {
		select {
		case id, ok := <-resetIDs:
			if !ok {
				t.Fatalf("reset output closed after %d/%d overflow RESETs: the peer reader terminated instead of delivering the rest", len(resets), flooded-acceptQueueDepth)
			}
			resets[id] = true
		case <-deadline:
			t.Fatalf("got %d RESETs, want %d", len(resets), flooded-acceptQueueDepth)
		}
	}
	for i := acceptQueueDepth; i < flooded; i++ {
		if !resets[uint64(6000+i)] {
			t.Fatalf("overflow stream %d was not reset", 6000+i)
		}
	}
	if n := mux.Len(); n != acceptQueueDepth {
		t.Fatalf("%d streams admitted, want %d (queue depth)", n, acceptQueueDepth)
	}

	// The reader kept running through the RESETs: collect the ACK this
	// Accept's Ack() produces before moving on. The drain is the shared A6
	// responder with its stop, conn close, and bounded join registered
	// BEFORE it starts — the former local drain goroutine had no registered
	// cleanup at all, so any Fatal after this point left it parked on its
	// channel receive even after the peer reader cleanup had run.
	resp := newAckResponder(p, frames)
	resp.launch(t)

	done := make(chan error, 1)
	acceptedCh := make(chan *Stream, 1)
	go func() {
		s, err := mux.Accept()
		if err == nil {
			acceptedCh <- s // publish before the ack result unblocks the test
			// Propagate the Ack error: a failed ACK must fail the test,
			// not vanish (the reader above keeps the pipe drained).
			done <- s.Ack()
			return
		}
		done <- err
	}()
	var accepted *Stream
	select {
	case err := <-done:
		if err != nil {
			t.Fatalf("accept/ack failed: %v", err)
		}
		accepted = <-acceptedCh
	case err := <-resp.errCh:
		t.Fatalf("ack responder failed: %v", err)
	case <-time.After(2 * time.Second):
		t.Fatal("reader dead after queue-full rejections")
	}
	if accepted == nil {
		t.Fatal("no stream accepted")
	}

	// Reader-liveness proof: a DATA frame sent after the flood reaches the
	// accepted stream. A queued Accept alone would not prove this.
	p.write(t, Frame{Type: FrameData, StreamID: accepted.ID(), Payload: []byte("alive")})
	buf := make([]byte, 5)
	_ = accepted.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, err := io.ReadFull(accepted, buf); err != nil {
		t.Fatalf("accepted stream received no data after the flood: %v", err)
	}
	if string(buf) != "alive" {
		t.Fatalf("marker corrupted: %q", buf)
	}

	// Normal finish: bounded observation of the complete lifetime — the
	// reader and relay via stopPeerReader, the responder via its done
	// channel. (The old test joined the drain only on the success path.)
	stopPeerReader(t, stopReader, readerDone, relayDone)
	select {
	case <-resp.done:
	case <-time.After(5 * time.Second):
		t.Error("ack responder did not terminate within 5s of the caller stop")
	}
}

// TestAckResponderReceiveParkedEarlyAbortJoins drives the SAME helper the
// A6 regressions launch, in the state an early harness abort leaves behind:
// the responder is parked on its receive (no frames are ever delivered,
// stopReader is never closed, the pipe stays live). The cleanup registered
// before the launch must release it — via its stop, and via the reader's
// exit closing the forwarding channels — and join it BEFORE returning; the
// reader workers are joined by their own registered cleanup. When the
// subtest's t.Run returns, its cleanups have returned too, so the parent
// requires all three done channels to be ALREADY closed; the checks are
// non-blocking because waiting would re-test eventual shutdown instead of
// join-before-return. (Against the former inline callsite wiring this
// failed deterministically: nothing on the abort path ever closed
// stopReader or the frames channel.)
func TestAckResponderReceiveParkedEarlyAbortJoins(t *testing.T) {
	var readerDone, relayDone, consumerDone <-chan struct{}
	t.Run("receive-parked, abandoned", func(t *testing.T) {
		c1, c2 := net.Pipe() // nothing is ever sent; the pipe stays live
		t.Cleanup(func() { c1.Close(); c2.Close() })
		p := &peer{tr: newPipeTransport(c2), c: c2}
		stopReader := make(chan struct{}) // never closed: the aborted test
		_, frames, done, relayd := p.spawnReader(t, stopReader)
		resp := newAckResponder(p, frames)
		resp.launch(t)
		readerDone, relayDone, consumerDone = done, relayd, resp.done
		// Nothing delivered: the responder parks on its receive here.
	})
	select {
	case <-consumerDone:
	default:
		t.Error("receive-parked responder was not joined by its own registered cleanup before it returned")
	}
	select {
	case <-readerDone:
	default:
		t.Error("reader was not joined by its own registered cleanup before it returned")
	}
	select {
	case <-relayDone:
	default:
		t.Error("stop relay was not joined by the registered cleanup before it returned")
	}
}

// TestAckResponderWriteParkedEarlyAbortJoins drives the OTHER parked state
// an early abort leaves behind: the responder has ENTERED an ACK write that
// cannot complete (nobody drains c1, the ACK's receiving endpoint), so no
// channel close can release it — only the conn close can, and the
// registered cleanup must perform that close BEFORE joining
// (close-before-join). The park is proven by real wire progress, not by
// any concurrent writer or deadline on the ACK writer's own endpoint c2:
// net.Pipe write deadlines live on the endpoint, so perturbing c2 could
// cancel the already-parked ACK itself (the former probe did exactly that;
// see the 3975d46 RED calibration). The control consumes exactly ONE byte
// of the 14-byte ACK header on c1 under a read deadline — a read deadline
// bounds only c1's read operation and cannot touch c2's write deadline —
// proving the synchronous write entered and made progress while leaving 13
// bytes unconsumed. Nothing reads c1 again, so the write cannot finish;
// the responder must still be parked (done open), and after the abandon
// its terminal write failure must be io.ErrClosedPipe from the owner conn
// close — os.ErrDeadlineExceeded is explicitly rejected, since it would
// mean a test-set deadline, not the cleanup, released the park.
func TestAckResponderWriteParkedEarlyAbortJoins(t *testing.T) {
	var readerDone, relayDone, consumerDone <-chan struct{}
	var respErrCh chan error
	t.Run("write-parked, abandoned", func(t *testing.T) {
		c1, c2 := net.Pipe() // c1 is the ACK receiver; nobody drains it past the first byte
		t.Cleanup(func() { c1.Close(); c2.Close() })
		p := &peer{tr: newPipeTransport(c2), c: c2}
		stopReader := make(chan struct{}) // never closed: the aborted test
		_, frames, done, relayd := p.spawnReader(t, stopReader)
		resp := newAckResponder(p, frames)
		resp.launch(t)
		readerDone, relayDone, consumerDone = done, relayd, resp.done
		respErrCh = resp.errCh

		// Deliver exactly one OPEN: the raw write returns only once the
		// reader consumed it, so the responder receives it and ACKs.
		enc, err := AppendFrame(nil, Frame{Type: FrameOpen, StreamID: 4242})
		if err != nil {
			t.Fatal(err)
		}
		writeAll(t, c1, enc)

		// Wire-progress barrier: consume exactly ONE byte of the ACK header
		// on c1. The byte can only arrive from inside the responder's
		// synchronous write; the remaining 13 bytes stay unconsumed, so the
		// write can never complete.
		_ = c1.SetReadDeadline(time.Now().Add(5 * time.Second))
		first := make([]byte, 1)
		if _, err := io.ReadFull(c1, first); err != nil {
			t.Fatalf("responder's ACK write made no wire progress: %v", err)
		}
		_ = c1.SetReadDeadline(time.Time{})

		// Park barrier without perturbation: nothing reads c1 again and no
		// deadline was set on c2, so the responder must still be inside its
		// write.
		select {
		case <-resp.done:
			t.Error("responder returned while its ACK write was still incomplete: park barrier broken")
		default:
		}
		// Abandon: the responder stays parked INSIDE its ACK write.
	})
	select {
	case <-consumerDone:
	default:
		t.Error("write-parked responder was not joined by its own registered cleanup before it returned")
	}
	select {
	case err := <-respErrCh:
		if err == nil {
			t.Error("responder joined without recording its terminal write failure")
		}
		if !errors.Is(err, io.ErrClosedPipe) {
			t.Errorf("responder write failure = %v, want io.ErrClosedPipe from the owner conn close", err)
		}
		if errors.Is(err, os.ErrDeadlineExceeded) {
			t.Errorf("responder write failed with os.ErrDeadlineExceeded — a test-set deadline, not the owner close, released the park: %v", err)
		}
	default:
		t.Error("responder exited without a terminal write failure on the error channel")
	}
	select {
	case <-readerDone:
	default:
		t.Error("reader was not joined by its own registered cleanup before it returned")
	}
	select {
	case <-relayDone:
	default:
		t.Error("stop relay was not joined by the registered cleanup before it returned")
	}
}

// TestA8ImmediateAckStorm: ACKs racing the Open path never wedge; the ack
// channel is captured under the same lock that creates it.
func TestA8ImmediateAckStorm(t *testing.T) {
	limits := testLimits()
	limits.MaxStreamsPerHost = 1024
	mux, p := newMuxPair(t, limits, RoleGateway)

	// Responder: ACK every OPEN; exits once all 500 streams were closed
	// again by the client (each close produces a RESET), so no writer is
	// ever left blocked on the pipe.
	go func() {
		closed := 0
		for closed < 500 {
			f, ok := p.tryRead(2 * time.Second)
			if !ok {
				return // conn dead; nothing left to serve
			}
			switch f.Type {
			case FrameOpen:
				_ = p.tryWrite(Frame{Type: FrameAck, StreamID: f.StreamID})
			case FrameReset:
				closed++
			}
		}
	}()
	for i := 0; i < 500; i++ {
		s, err := mux.Open(2 * time.Second)
		if err != nil {
			t.Fatalf("open %d failed: %v", i, err)
		}
		if err := s.Close(); err != nil {
			t.Fatalf("close %d: %v", i, err)
		}
	}
}

// TestA10LateFramesDoNotKillUnrelatedStreams: DATA/EOF/WINDOW for a closed
// stream are dropped; an unrelated stream keeps transferring.
//
// Harness: ONE dispatcher goroutine reads the framed pipe for the entire
// test (ACKing OPENs, echoing the one registered stream). Earlier versions
// launched competing deadline-readers which stole each other's frames.
func TestA10LateFramesDoNotKillUnrelatedStreams(t *testing.T) {
	limits := testLimits()
	mux, p := newMuxPair(t, limits, RoleGateway)

	var echoID atomic.Uint64
	openAcked := make(chan uint64, 16)
	stopDisp := make(chan struct{})
	dispDone := make(chan struct{})
	go func() {
		defer close(dispDone)
		for {
			select {
			case <-stopDisp:
				return
			default:
			}
			f, ok := p.tryRead(200 * time.Millisecond)
			if !ok {
				continue
			}
			switch f.Type {
			case FrameOpen:
				_ = p.tryWrite(Frame{Type: FrameAck, StreamID: f.StreamID})
				select {
				case openAcked <- f.StreamID:
				default:
				}
			case FrameData:
				if id := echoID.Load(); id != 0 && f.StreamID == id {
					_ = p.tryWrite(Frame{Type: FrameData, StreamID: id, Payload: f.Payload})
				}
			}
		}
	}()

	// Open stream A; the dispatcher ACKs, then we close it.
	a, err := mux.Open(time.Second)
	if err != nil {
		t.Fatal(err)
	}
	aID := <-openAcked
	if err := a.Close(); err != nil {
		t.Fatal(err)
	} // tombstoned

	// Late frames for A must be tolerated (the dispatcher sees the RESET
	// from Close; these arrive after the tombstone).
	p.write(t, Frame{Type: FrameData, StreamID: aID, Payload: []byte("late data")})
	p.write(t, Frame{Type: FrameEOF, StreamID: aID})
	p.write(t, Frame{Type: FrameWindow, StreamID: aID, Payload: []byte{0, 0, 1, 0}})
	p.write(t, Frame{Type: FrameAck, StreamID: aID})

	// Stream B still works end-to-end.
	b, err := mux.Open(time.Second)
	if err != nil {
		t.Fatalf("unrelated stream broken by late frames: %v", err)
	}
	bID := <-openAcked
	echoID.Store(bID)
	msg := []byte("still alive")
	if _, err := b.Write(msg); err != nil {
		t.Fatal(err)
	}
	buf := make([]byte, len(msg))
	_ = b.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, err := io.ReadFull(b, buf); err != nil {
		t.Fatalf("unrelated stream did not echo: %v", err)
	}
	if !bytes.Equal(buf, msg) {
		t.Fatalf("echo corrupted: %q", buf)
	}
	if err := b.Close(); err != nil {
		t.Fatal(err)
	}
	close(stopDisp)
	<-dispDone
}

// TestA10OpenTimeoutSendsResetAndTombstones: a host that never ACKs gets a
// RESET and its late frames are ignored; the connection stays healthy.
//
// Harness: a persistent peer reader runs BEFORE Open — net.Pipe is
// synchronous, so without a reader the OPEN write itself would block and
// the timeout path would be unreachable (earlier harness bug).
func TestA10OpenTimeoutSendsResetAndTombstones(t *testing.T) {
	limits := testLimits()
	mux, p := newMuxPair(t, limits, RoleGateway)

	stopReader := make(chan struct{})
	resetIDs, _, readerDone, relayDone := p.spawnReader(t, stopReader)

	done := make(chan error, 1)
	go func() {
		_, err := mux.Open(100 * time.Millisecond)
		done <- err
	}()
	select {
	case err := <-done:
		if err == nil {
			t.Fatal("open should have timed out")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("open did not time out")
	}
	// Peer receives the RESET for the timed-out stream — an ACTUAL frame,
	// not the closed-output EOF: a peer reader that terminated early would
	// close the channel, and the comma-ok receive must reject that instead
	// of treating the closure as the frame witness.
	select {
	case _, ok := <-resetIDs:
		if !ok {
			t.Fatal("reset output closed before the open-timeout RESET arrived: the peer reader terminated instead of witnessing the frame")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("no RESET sent on open timeout")
	}
	// The timed-out stream is gone; the connection itself is healthy.
	if mux.Len() != 0 {
		t.Fatalf("timed-out stream leaked: %d live", mux.Len())
	}
	select {
	case <-mux.Done():
		t.Fatal("mux torn down by open timeout")
	default:
	}
	stopPeerReader(t, stopReader, readerDone, relayDone)
}

// TestA11SmallWindowTransfer: with a window smaller than the update
// threshold, credit replenishment on drain-to-empty keeps data flowing.
func TestA11SmallWindowTransfer(t *testing.T) {
	limits := testLimits()
	limits.StreamWindow = 4096 // < windowUpdateFlush (32 KiB)
	limits.MaxFramePayload = 1024
	client, server, wait := muxPipePair(t, limits)
	defer wait()

	payload := make([]byte, 512<<10) // 512 KiB through a 4 KiB window
	if _, err := rand.Read(payload); err != nil {
		t.Fatal(err)
	}
	go func() {
		if _, err := server.Write(payload); err != nil {
			t.Errorf("server write: %v", err)
		}
		_ = server.CloseWrite()
	}()
	got, err := io.ReadAll(client)
	if err != nil {
		t.Fatalf("small-window transfer failed: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("payload mismatch: got %d bytes", len(got))
	}
}

// TestA11ParallelWritersHonorCredit: concurrent writers reserve credit
// atomically; the receiver never sees a window overrun. The server
// terminates the protocol explicitly with EOF once it has drained — the
// client-side reader must observe it (earlier harness hung waiting for an
// EOF the server never sent).
func TestA11ParallelWritersHonorCredit(t *testing.T) {
	limits := testLimits()
	limits.StreamWindow = 8 << 10
	limits.MaxFramePayload = 1500
	client, server, wait := muxPipePair(t, limits)
	defer wait()

	const writers = 8
	const perWriter = 64 << 10
	var wg sync.WaitGroup
	for i := 0; i < writers; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			buf := make([]byte, perWriter)
			if _, err := rand.Read(buf); err != nil {
				t.Error(err)
				return
			}
			if _, err := client.Write(buf); err != nil {
				t.Errorf("writer %d: %v", i, err)
			}
		}(i)
	}
	// Concurrent reader on the client stream: it sees EOF only when the
	// server half-closes.
	total := make(chan int, 1)
	go func() {
		got, err := io.ReadAll(client)
		if err != nil {
			t.Errorf("read: %v", err)
		}
		total <- len(got)
	}()
	// Server drains everything, then sends the explicit EOF.
	drained := 0
	buf := make([]byte, 4096)
	for drained < writers*perWriter {
		n, err := server.Read(buf)
		drained += n
		if err != nil {
			t.Fatalf("server read at %d: %v", drained, err)
		}
	}
	if err := server.CloseWrite(); err != nil {
		t.Fatalf("server CloseWrite: %v", err)
	}
	wg.Wait()
	_ = client.CloseWrite()
	select {
	case n := <-total:
		if n != 0 {
			t.Fatalf("reader saw %d unexpected bytes", n)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("client reader never observed the server's EOF")
	}
}

// floodDispatcher is the single blocking frame reader shared by the
// reset-flood and overflow regressions. It ACKs every OPEN, echoes DATA
// for the one registered legit stream, collects flood-range RESET ids and
// parks on its gate after the first flood-range refusal (the controlled
// stall). Success signals are emitted only after the action that motivates
// them succeeded; any read or write failure is forwarded on errCh exactly
// once and terminates the dispatcher, so a harness failure surfaces with
// its cause instead of turning a later wait into an opaque timeout. errCh
// must be buffered (capacity 1); done is closed on every exit.
type floodDispatcher struct {
	tr      Transport         // blocking frame reads from the peer side
	write   func(Frame) error // outbound frames; injectable for failure controls
	floodLo uint64            // flood-range stream IDs are the half-open interval
	floodHi uint64            // (floodLo, floodHi]; lo > hi encodes an empty range

	gate    <-chan struct{} // released to end the controlled stall
	legitID *atomic.Uint64  // 0 until the test registers the legit stream

	acked   chan<- struct{} // non-blocking success signal after each ACK write
	stalled chan<- struct{} // non-blocking signal before the controlled stall
	resets  chan<- uint64   // flood-range RESET ids (sized by the caller)
	errCh   chan<- error    // exactly one terminal error, never swallowed
	done    chan struct{}   // closed when the dispatcher exits

	refusals int // flood-range RESETs observed (dispatcher goroutine only)
}

func (d *floodDispatcher) run() {
	defer close(d.done)
	for {
		// Blocking read: framing is never abandoned mid-frame. The only
		// possible error is the transport dying (the test closes it for
		// shutdown, or the scenario failed); it is terminal either way.
		f, err := d.tr.ReadFrame()
		if err != nil {
			d.errCh <- err
			return
		}
		switch f.Type {
		case FrameOpen:
			if werr := d.write(Frame{Type: FrameAck, StreamID: f.StreamID}); werr != nil {
				d.errCh <- fmt.Errorf("ack write for stream %d: %w", f.StreamID, werr)
				return
			}
			select {
			case d.acked <- struct{}{}:
			default:
			}
		case FrameReset:
			if f.StreamID <= d.floodLo || f.StreamID > d.floodHi {
				continue // e.g. the legit stream's close RESET
			}
			d.resets <- f.StreamID
			if d.refusals == 0 { // first refusal: become the slow reader
				d.refusals++
				select {
				case d.stalled <- struct{}{}:
				default:
				}
				<-d.gate // controlled stall: consume nothing until released
			}
			d.refusals++
		case FrameData:
			if id := d.legitID.Load(); id != 0 && f.StreamID == id {
				if werr := d.write(Frame{Type: FrameData, StreamID: id, Payload: f.Payload}); werr != nil {
					d.errCh <- fmt.Errorf("echo write for stream %d: %w", id, werr)
					return
				}
			}
		}
	}
}

// floodWriter tracks the flood-writer goroutine from launch to bounded
// join. The join is registered in cleanup before the dispatcher starts,
// but it waits only when the writer was actually launched: every
// registered join must correspond to a worker this test started and owns.
// An early open failure before the launch would otherwise leave cleanup
// waiting out its full bound on a done channel no goroutine will ever
// close — a fictitious non-terminating-writer failure stacked on top of
// the real one.
type floodWriter struct {
	launched chan struct{} // closed immediately before the goroutine starts
	done     chan struct{} // closed by the writer goroutine on exit
}

func newFloodWriter() *floodWriter {
	return &floodWriter{launched: make(chan struct{}), done: make(chan struct{})}
}

// launch arms the cleanup join and starts run on its own goroutine. The
// close happens before `go`, so a cleanup that observes launched is
// guaranteed a running writer whose exit closes done.
func (w *floodWriter) launch(run func()) {
	close(w.launched)
	go func() {
		defer close(w.done)
		run()
	}()
}

// joinIfLaunched is the cleanup-side bounded join. It reports whether the
// writer was launched; a never-launched writer owns no goroutine and is
// skipped instead of waited on.
func (w *floodWriter) joinIfLaunched(t *testing.T, bound time.Duration) bool {
	t.Helper()
	select {
	case <-w.launched:
	default:
		return false
	}
	select {
	case <-w.done:
	case <-time.After(bound):
		t.Errorf("flood writer did not terminate within %s of the peer transport closing", bound)
	}
	return true
}

// floodCleanup builds the cleanup sequence the flood regressions register
// BEFORE starting their dispatcher: idempotent gate release first (so the
// parked reader can always finish), then the peer transport close (so a
// write wedged on the pipe can fail), then the bounded joins — the flood
// writer only if it was actually launched, always the dispatcher. The
// same closure serves the main regression, its early-failure calibration,
// and the test-end re-run, so every exit path exercises one lifecycle.
func floodCleanup(t *testing.T, releaseGate func(), p *peer, writer *floodWriter, dispDone <-chan struct{}) func() {
	return func() {
		releaseGate()
		p.c.Close()
		writer.joinIfLaunched(t, 5*time.Second)
		select {
		case <-dispDone:
		case <-time.After(5 * time.Second):
			t.Error("responder did not terminate after gate release and peer close")
		}
	}
}

// TestResetFloodSlowReaderBoundedWork covers the bounded control-queue
// replacement for the old per-rejected-frame goroutine (resetAsync):
//
// Phase 1: a flood of role-invalid OPENs is answered by RESETs while the
// single peer reader (the floodDispatcher) is gated to a full stop after
// the first refusal — the control worker can then never complete its next
// RESET write, and the remaining refusals park in the bounded queue
// (outstanding count half the queue depth, so nothing overflows). While
// wedged, a frame pushed toward a previously established stream is still
// delivered: the mux reader never blocks on control-frame backpressure.
// After the gate opens, the queue drains to an exact RESET count and the
// stream completes a byte-exact round trip within the original 2s budget.
// All waits are count/queue barriers or deadlines bounding a terminal
// state — no pacing sleeps. Cleanup for every exit path (including early
// Fatals) is registered before the dispatcher starts: an idempotent gate
// release, the peer transport close, and bounded joins of the dispatcher
// and the flood writer.
//
// Phase 2 (separate connection, nobody draining): the overall write bound
// is installed before the flood, because these flood writes are
// synchronous on the test goroutine — a regressed read loop that stops
// consuming must fail them at the deadline so the verdict select is
// actually reached. Once the bounded control queue overflows because its
// single worker is wedged on the synchronous pipe, the mux fails closed —
// it tears down instead of buffering or spawning without bound.
func TestResetFloodSlowReaderBoundedWork(t *testing.T) {
	// --- phase 1: gated slow reader, bounded queue, proven progress -----
	limits := testLimits()
	limits.MaxStreamsPerHost = acceptQueueDepth + 256
	gw, p := newMuxPair(t, limits, RoleGateway)

	const (
		floodN    = ctrlQueueDepth / 2 // outstanding refusals stay well under the queue bound
		floodBase = uint64(7000)
	)

	var legitID atomic.Uint64
	acked := make(chan struct{}, 1)
	gated := make(chan struct{}, 1)       // responder parked on the gate
	resets := make(chan uint64, floodN+8) // flood-range RESET ids; cap >= count, never blocks
	dispErr := make(chan error, 1)        // exactly one terminal dispatcher error
	dispDone := make(chan struct{})
	gate := make(chan struct{})
	var gateOnce sync.Once
	releaseGate := func() { gateOnce.Do(func() { close(gate) }) }
	disp := &floodDispatcher{
		tr:      p.tr,
		write:   p.tryWrite,
		floodLo: floodBase,
		floodHi: floodBase + floodN,
		gate:    gate,
		legitID: &legitID,
		acked:   acked,
		stalled: gated,
		resets:  resets,
		errCh:   dispErr,
		done:    dispDone,
	}

	// Fixed-count flood of unique role-invalid OPENs: the outstanding
	// refusal count is bounded by construction, not by pacing. The writer
	// is launch-tracked, so cleanup joins only a goroutine this test
	// actually started.
	flood := newFloodWriter()
	floodErr := make(chan error, 1)

	// Cleanup for EVERY exit path, registered before the dispatcher starts:
	// an early Fatal must not leave the responder parked on its gate or any
	// join unbounded, and an early open failure before the writer launch
	// must not produce a fictitious writer wait (see floodWriter).
	t.Cleanup(floodCleanup(t, releaseGate, p, flood, dispDone))
	go disp.run()

	// Establish the legitimate stream before the flood; the buffered result
	// synchronizes on the opener's completion before any other frame moves.
	opened := make(chan openResult, 1)
	go func() {
		s, err := gw.Open(5 * time.Second)
		opened <- openResult{stream: s, err: err}
	}()
	var legit *Stream
	select {
	case r := <-opened:
		if r.err != nil {
			t.Fatalf("legitimate open before flood: %v", r.err)
		}
		legit = r.stream
	case <-time.After(5 * time.Second):
		t.Fatal("legitimate open never completed")
	}
	// The ACK success signal fires only after the dispatcher's ACK write
	// itself succeeded — consume it, bounded and error-aware: a missing
	// signal or a reader-exit regression must fail here with its real cause
	// instead of hanging the run on a plain receive.
	select {
	case <-acked:
	case err := <-dispErr:
		t.Fatalf("peer reader failed before signalling the ACK: %v", err)
	case <-time.After(5 * time.Second):
		t.Fatal("no ACK success signal after the legitimate open")
	}
	legitID.Store(legit.ID())

	flood.launch(func() {
		// Overall write bound installed before the first flood frame: if
		// the read loop stopped consuming, these writes terminate at the
		// deadline (surfaced through the select below) instead of wedging
		// the writer forever. It never paces success — a sub-capacity
		// flood completes in microseconds on a healthy mux.
		_ = p.c.SetWriteDeadline(time.Now().Add(10 * time.Second))
		for i := 0; i < floodN; i++ {
			if err := p.tryWrite(Frame{Type: FrameOpen, StreamID: floodBase + uint64(i) + 1}); err != nil {
				floodErr <- fmt.Errorf("flood open %d: %w", i, err)
				return
			}
		}
	})
	select {
	case <-flood.done:
	case <-gw.Done():
		t.Fatal("mux torn down by a sub-capacity refusal flood")
	case <-time.After(5 * time.Second):
		t.Fatal("flood writer never finished")
	}
	// The writer exited; surface a mid-flood failure with its real cause
	// before any later wait can turn it into an opaque verdict.
	select {
	case err := <-floodErr:
		t.Fatalf("flood writer failed: %v", err)
	default:
	}
	select {
	case <-gated:
	case err := <-dispErr:
		t.Fatalf("peer reader failed before the stall: %v", err)
	case <-time.After(5 * time.Second):
		t.Fatal("responder never stalled on its gate")
	}

	// The control worker can no longer complete a RESET write (the only
	// reader is parked), yet inbound stream data must still be delivered.
	// A full receive window (64 KiB, below the 32 KiB credit-flush threshold
	// per partial read) is pushed in 8 KiB frames — the read loop consumes
	// them all while no control write can complete. Reading only 8 bytes
	// leaves the buffer far from empty, so this Read returns without any
	// credit write onto the wedged pipe; the full byte-exact comparison
	// happens after the drain.
	const inboundLen = 64 << 10
	inbound := make([]byte, inboundLen)
	for i := range inbound {
		inbound[i] = byte(i % 251)
	}
	for off := 0; off < inboundLen; off += 8 << 10 {
		p.write(t, Frame{Type: FrameData, StreamID: legitID.Load(), Payload: inbound[off : off+8<<10]})
	}
	stalled := make([]byte, 8)
	_ = legit.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, err := io.ReadFull(legit, stalled); err != nil {
		t.Fatalf("no inbound progress while the RESET write was wedged: %v", err)
	}
	if !bytes.Equal(stalled, inbound[:8]) {
		t.Fatalf("inbound payload corrupted under flood: %q", stalled)
	}

	// Drain: opening the gate must let every queued refusal surface.
	releaseGate()
	drainDeadline := time.After(5 * time.Second)
	for got := 0; got < floodN; got++ {
		select {
		case <-resets:
		case err := <-dispErr:
			t.Fatalf("peer reader failed while draining refusals: %v", err)
		case <-gw.Done():
			t.Fatal("mux torn down while draining the refusal queue")
		case <-drainDeadline:
			t.Fatalf("only %d/%d refusals drained after the gate opened", got, floodN)
		}
	}
	// Everything delivered during the stall is intact: read the remaining
	// window (this empties the buffer, so the credit return now finds a
	// live pipe) and compare byte-exact.
	rest := make([]byte, inboundLen-8)
	_ = legit.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, err := io.ReadFull(legit, rest); err != nil {
		t.Fatalf("stall-window data unreadable after drain: %v", err)
	}
	if !bytes.Equal(rest, inbound[8:]) {
		t.Fatalf("stall-window data corrupted: %d bytes compared", len(rest))
	}

	// Byte-exact round trip within the original budget, now that the queue
	// is empty and the worker writes freely again.
	start := time.Now()
	msg3 := []byte("roundtrip")
	if _, err := legit.Write(msg3); err != nil {
		t.Fatalf("write after drain: %v", err)
	}
	buf3 := make([]byte, len(msg3))
	_ = legit.SetReadDeadline(time.Now().Add(2 * time.Second))
	if _, err := io.ReadFull(legit, buf3); err != nil {
		t.Fatalf("round trip after drain failed: %v", err)
	}
	if elapsed := time.Since(start); elapsed > 2*time.Second {
		t.Fatalf("round trip needed %s after drain; progress not within budget", elapsed)
	}
	if !bytes.Equal(buf3, msg3) {
		t.Fatalf("echo corrupted after drain: %q", buf3)
	}

	// The connection itself survived the flood: fail-closed is phase 2's job.
	select {
	case <-gw.Done():
		t.Fatal("phase 1 flooded below queue capacity yet tore the mux down")
	default:
	}
	if err := legit.Close(); err != nil {
		t.Fatalf("close under flood: %v", err)
	}

	// Shutdown: the responder is a blocking reader; close the transport and
	// join it. Its terminal read error is the expected shutdown signal
	// (forwarded on dispErr). The join itself is bounded — an unbounded
	// join here would run ahead of the registered cleanup, so a stall would
	// hang the test before cleanup could ever bound it.
	p.c.Close()
	select {
	case <-dispDone:
	case <-time.After(5 * time.Second):
		t.Fatal("responder did not terminate after the peer transport closed")
	}

	// --- phase 2: overflow fails closed ---------------------------------
	mux2, p2 := newMuxPair(t, testLimits(), RoleGateway)
	// Nobody reads the peer side: the first RESET the control worker writes
	// wedges on the synchronous pipe, the bounded queue fills, and overflow
	// must tear the connection down (fail closed) instead of buffering or
	// spawning without bound. The overall write bound goes on BEFORE the
	// flood: these writes are synchronous on the test goroutine, so a
	// regressed read loop that stops consuming must fail them at the
	// deadline and reach the verdict select instead of wedging the test
	// before any timeout is installed.
	const flood2 = ctrlQueueDepth + 16
	_ = p2.c.SetWriteDeadline(time.Now().Add(2 * time.Second))
	completed := 0
	for i := 0; i < flood2; i++ {
		if err := p2.tryWrite(Frame{Type: FrameOpen, StreamID: uint64(9000 + i)}); err != nil {
			break // teardown raced us (the expected end state), or the bound tripped
		}
		completed = i + 1
	}
	select {
	case <-mux2.Done():
		if err := mux2.Err(); err == nil || !errors.Is(err, ErrProtocol) {
			t.Fatalf("fail-closed teardown err = %v, want wrapped ErrProtocol", err)
		}
	case <-time.After(5 * time.Second):
		t.Fatalf("control queue overflow did not fail closed (%d/%d flood frames consumed before writes stopped)", completed, flood2)
	}
}

// gatedTransport parks WriteFrame and Close until the test releases them:
// the control worker wedges deterministically on its first write, and
// teardown progress (tr.Close) is under the test's control, which is what
// makes per-frame cleanup fanout observable. The parked barrier closes
// when a write has actually parked, so a test can prove the worker holds
// its refusal OUTSIDE the queue before making accounting claims.
type gatedTransport struct {
	tr       *pipeTransport
	released chan struct{}
	parked   chan struct{} // closed when a write has parked
	once     sync.Once
	parkOnce sync.Once
}

func (g *gatedTransport) release() { g.once.Do(func() { close(g.released) }) }

func (g *gatedTransport) ReadFrame() (Frame, error) { return g.tr.ReadFrame() }

func (g *gatedTransport) WriteFrame(f Frame) error {
	g.parkOnce.Do(func() { close(g.parked) })
	<-g.released // parked: the scenario never drains the peer side
	return errors.New("tunnel: gated transport closed")
}

func (g *gatedTransport) Close() error {
	<-g.released // teardown may not proceed until the test releases
	return g.tr.Close()
}

// TestControlQueueOverflowBoundedCleanup pins the bounded-work property of
// control-queue overflow: the read loop must stop and tear the connection
// down synchronously on the first overflow instead of keeping the connection
// alive and spawning one teardown goroutine per refused frame.
//
// Frame accounting, established by the parked barrier rather than inferred:
// one synchronous OPEN is consumed first and the test waits until the
// control worker is observed parked holding refusal #1 OUTSIDE the queue.
// From that moment the worker can dequeue nothing, so the flood fills the
// queue with refusals #2..#ctrlQueueDepth+1 and exactly ctrlQueueDepth+2
// frames complete writes: the worker-held refusal, the queue bound, and
// the one NEXT frame whose consumption is how the overflow is discovered
// and failed closed. Consuming the discovering frame is not reading past
// the overflow; a completed write of any LATER frame would be, and the
// exact written count together with the "stopped" verdict excludes it —
// the 1024-frame flood gives such a read loop ample room to expose itself.
// The overall write bound is installed before the first flood write, so a
// read loop that stalls early terminates the writer at the deadline
// instead of wedging it before any verdict is possible, and the verdict
// receive itself is bounded — no sleeps, no unbounded waits.
func TestControlQueueOverflowBoundedCleanup(t *testing.T) {
	c1, c2 := net.Pipe()
	gt := &gatedTransport{tr: newPipeTransport(c1), released: make(chan struct{}), parked: make(chan struct{})}
	mux := NewMux(gt, testLimits(), RoleGateway)
	t.Cleanup(func() {
		gt.release() // unblock teardown and the worker before closing
		mux.Close()
		c1.Close()
		c2.Close()
	})

	// Barrier 1: one synchronous, deadline-bounded OPEN is refused and the
	// worker parks holding that RESET outside the queue.
	p2 := &peer{tr: newPipeTransport(c2), c: c2}
	const floodN = 1024
	_ = c2.SetWriteDeadline(time.Now().Add(2 * time.Second))
	p2.write(t, Frame{Type: FrameOpen, StreamID: 9000})
	select {
	case <-gt.parked:
	case <-time.After(5 * time.Second):
		t.Fatal("control worker never parked on its first RESET write")
	}

	tr2 := newPipeTransport(c2)
	var written atomic.Int64
	written.Store(1) // the pre-barrier frame above
	baseline := runtime.NumGoroutine()
	verdictCh := make(chan string, 1)
	go func() {
		for i := 0; i < floodN; i++ {
			if err := tr2.WriteFrame(Frame{Type: FrameOpen, StreamID: uint64(9001 + i)}); err != nil {
				verdictCh <- "stopped"
				return
			}
			written.Store(1 + int64(i+1))
		}
		verdictCh <- "flooded"
	}()

	var verdict string
	select {
	case verdict = <-verdictCh:
	case <-time.After(5 * time.Second):
		t.Fatalf("flood writer never reached a verdict (%d/%d frames written)", written.Load(), floodN)
	}
	if verdict != "stopped" {
		t.Fatalf("read loop kept consuming after control-queue overflow (%d/%d frames absorbed): per-frame teardown fanout", written.Load(), floodN)
	}
	// Established by the parked barrier: the writer stopped after exactly
	// the worker-held refusal, the queue bound, and the overflow-
	// discovering frame — no later frame completed a write.
	if want := int64(ctrlQueueDepth + 2); written.Load() != want {
		t.Fatalf("overflow absorbed %d frames, want exactly %d (worker-held + queue bound + discoverer)", written.Load(), want)
	}
	if delta := runtime.NumGoroutine() - baseline; delta > 8 {
		t.Fatalf("overflow cleanup spawned %d goroutines (baseline %d, now %d); cleanup must be bounded", delta, baseline, runtime.NumGoroutine())
	}

	select {
	case <-mux.Done():
	default:
		t.Fatal("overflow did not tear the connection down")
	}
	if err := mux.Err(); err == nil || !errors.Is(err, ErrProtocol) {
		t.Fatalf("teardown err = %v, want wrapped ErrProtocol", err)
	}

	// Releasing the gate must let teardown finish: the parked RESET write
	// fails, the worker exits, nothing lingers.
	gt.release()
	select {
	case <-mux.workerDone:
	case <-time.After(5 * time.Second):
		t.Fatal("control worker did not terminate after the overflow teardown")
	}
}

// resetGateTransport parks RESET writes (and teardown's Close) until the
// test releases them, while letting every other frame through: the control
// worker wedges deterministically on its first refusal, the Open caller's
// own frames still reach the peer, and cleanup completion (tr.Close) stays
// under the test's control — which is what makes the timeout-originated
// overflow path observable.
type resetGateTransport struct {
	tr          *pipeTransport
	released    chan struct{}
	parked      chan struct{} // closed when a RESET write has parked
	releaseOnce sync.Once
	parkOnce    sync.Once
}

func (rt *resetGateTransport) release() { rt.releaseOnce.Do(func() { close(rt.released) }) }

func (rt *resetGateTransport) ReadFrame() (Frame, error) { return rt.tr.ReadFrame() }

func (rt *resetGateTransport) WriteFrame(f Frame) error {
	if f.Type == FrameReset {
		rt.parkOnce.Do(func() { close(rt.parked) })
		<-rt.released
		return errors.New("tunnel: reset-gated transport released with a RESET pending")
	}
	return rt.tr.WriteFrame(f)
}

func (rt *resetGateTransport) Close() error {
	<-rt.released // teardown may not proceed until the test releases
	return rt.tr.Close()
}

// TestOpenTimeoutOverflowTeardownBounded pins the timeout-originated
// control-queue overflow path (Open's timer firing while the queue is
// full): the refusal cannot be queued, so the Open caller itself tears the
// connection down. Barriers, no sleeps: (0) every synchronous peer write —
// the refusal OPEN, the queue fill, and the probe — is deadline-bounded
// from before the first frame, so a regressed read loop that stops
// consuming fails the writes at the deadline instead of wedging net.Pipe
// before any verdict select exists; (1) the control worker is provably
// parked on its first RESET write before the queue is filled; (2) the
// queue is filled to exactly its bound and a tombstoned-id RESET probe
// proves the last fill enqueue completed (the read loop consumes the
// probe only after it); (3) the peer reads the timed-out stream's OPEN but
// never ACKs it, so Open must hit its timer; (4) Done (shutdown
// initiation) is observed while Open has not returned and the worker is
// still parked — Done is not cleanup completion; (5) after release, Open
// returns its timeout verdict, teardown joins the worker, and no stream
// leaks — each step bounded.
func TestOpenTimeoutOverflowTeardownBounded(t *testing.T) {
	c1, c2 := net.Pipe()
	rt := &resetGateTransport{tr: newPipeTransport(c1), released: make(chan struct{}), parked: make(chan struct{})}
	mux := NewMux(rt, testLimits(), RoleGateway)
	// Cleanup for every exit path: unblock the worker and teardown before
	// closing, then close both pipe ends.
	t.Cleanup(func() {
		rt.release()
		mux.Close()
		c1.Close()
		c2.Close()
	})
	p2 := &peer{tr: newPipeTransport(c2), c: c2}

	// Barrier 0 — overall peer write bound, installed BEFORE the first
	// write: the OPEN below, the queue fill, and the probe are synchronous
	// on this goroutine and precede every bounded verdict select, so a
	// regressed read loop that stops consuming must fail them at this
	// deadline instead of wedging net.Pipe forever before any timeout is
	// reachable. Every write failure is asserted (peer.write fails the test
	// with its cause); a healthy mux completes all three phases in
	// microseconds.
	_ = p2.c.SetWriteDeadline(time.Now().Add(10 * time.Second))

	// Barrier 1: one role-invalid OPEN is refused and the worker parks
	// holding that RESET outside the queue.
	p2.write(t, Frame{Type: FrameOpen, StreamID: 8001})
	select {
	case <-rt.parked:
	case <-time.After(5 * time.Second):
		t.Fatal("control worker never parked on its first RESET write")
	}

	// Barrier 2: fill the bounded queue to exactly its capacity. Each
	// synchronous write returns once the read loop has consumed the frame;
	// the trailing RESET probe is a late frame for the already-tombstoned
	// refused id (dropped, no side effects), and the read loop can only
	// consume it after finishing the last fill enqueue — so the queue is
	// exactly full when the probe write returns.
	for i := 0; i < ctrlQueueDepth; i++ {
		p2.write(t, Frame{Type: FrameOpen, StreamID: uint64(8100 + i)})
	}
	p2.write(t, Frame{Type: FrameReset, StreamID: 8001})

	// Fire Open; the peer reads the OPEN and never ACKs it.
	opened := make(chan openResult, 1)
	go func() {
		s, err := mux.Open(250 * time.Millisecond)
		opened <- openResult{stream: s, err: err}
	}()
	f, ok := p2.tryRead(time.Second)
	if !ok || f.Type != FrameOpen {
		t.Fatalf("expected the opening stream's OPEN, got %v", f)
	}

	// The timeout fires into the full queue and the overflow tears the mux
	// down from the Open caller's goroutine...
	select {
	case <-mux.Done():
	case <-time.After(2 * time.Second):
		t.Fatal("open timeout into a full control queue did not initiate teardown")
	}
	if err := mux.Err(); err == nil || !errors.Is(err, ErrProtocol) {
		t.Fatalf("teardown err = %v, want the wrapped queue-overflow protocol error", err)
	}
	// ...but its cleanup cannot complete while the worker is parked: Open
	// has not returned and the worker has not been joined.
	select {
	case r := <-opened:
		t.Fatalf("open returned early (%v): teardown cleanup completed before the gate released", r.err)
	default:
	}
	select {
	case <-mux.workerDone:
		t.Fatal("control worker joined before the gated transport was released")
	default:
	}

	// Release: the parked RESET write fails, the worker exits, teardown
	// joins it, and Open returns its timeout verdict — each bounded.
	rt.release()
	select {
	case r := <-opened:
		want := fmt.Sprintf("tunnel: host did not acknowledge stream within %s", 250*time.Millisecond)
		if r.err == nil || r.err.Error() != want {
			t.Fatalf("open err = %v, want the open-timeout verdict %q", r.err, want)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("open never returned after the gate released")
	}
	select {
	case <-mux.workerDone:
	case <-time.After(5 * time.Second):
		t.Fatal("control worker did not terminate after release")
	}
	if n := mux.Len(); n != 0 {
		t.Fatalf("%d streams survived the overflow teardown", n)
	}
}

// readGateTransport parks ReadFrame (and teardown's Close) until the test
// releases them: the mux read loop is provably stalled before the first
// frame arrives, which is what makes the peer-write bound observable
// against a real read loop rather than a mocked reader.
type readGateTransport struct {
	tr          *pipeTransport
	released    chan struct{}
	releaseOnce sync.Once
}

func (rg *readGateTransport) release() { rg.releaseOnce.Do(func() { close(rg.released) }) }

func (rg *readGateTransport) ReadFrame() (Frame, error) {
	<-rg.released // parked: the scenario's reader regression
	return rg.tr.ReadFrame()
}

func (rg *readGateTransport) WriteFrame(f Frame) error { return rg.tr.WriteFrame(f) }

func (rg *readGateTransport) Close() error {
	<-rg.released // teardown may not proceed until the test releases
	return rg.tr.Close()
}

// TestPeerWriteBoundFailsAgainstStalledReader is the negative control for
// the peer-write discipline the flood and timeout-overflow regressions
// install before their first synchronous frame: with the read loop
// provably stalled before the first frame, the bounded write must refuse
// AT its deadline — with the deadline-exceeded cause asserted, the bound
// holding, no stream admitted, and no teardown blamed on the stall — and
// the registered cleanup (release, closes, bounded Done/worker joins) must
// still complete. Without the origin deadline the same stall wedges
// net.Pipe forever and the whole run hangs before any verdict select.
func TestPeerWriteBoundFailsAgainstStalledReader(t *testing.T) {
	c1, c2 := net.Pipe()
	rg := &readGateTransport{tr: newPipeTransport(c1), released: make(chan struct{})}
	mux := NewMux(rg, testLimits(), RoleGateway)
	// Cleanup for every exit path: unblock the stalled reader and teardown
	// before closing, then close both pipe ends and join boundedly.
	t.Cleanup(func() {
		rg.release()
		mux.Close()
		c1.Close()
		c2.Close()
		select {
		case <-mux.Done():
		case <-time.After(5 * time.Second):
			t.Error("mux did not tear down after the stalled reader was released and the pipe closed")
		}
		select {
		case <-mux.workerDone:
		case <-time.After(5 * time.Second):
			t.Error("control worker did not terminate after cleanup")
		}
	})
	p2 := &peer{tr: newPipeTransport(c2), c: c2}

	// The write bound is installed BEFORE the first frame — the same origin
	// discipline the flood regressions use.
	_ = p2.c.SetWriteDeadline(time.Now().Add(time.Second))
	start := time.Now()
	err := p2.tryWrite(Frame{Type: FrameOpen, StreamID: 8001})
	elapsed := time.Since(start)
	if err == nil {
		t.Fatal("write against a provably stalled reader succeeded; the bound never tripped")
	}
	if !errors.Is(err, os.ErrDeadlineExceeded) {
		t.Fatalf("stalled-reader write err = %v, want the write deadline", err)
	}
	if elapsed > 3*time.Second {
		t.Fatalf("stalled-reader write needed %s to fail; the bound did not hold", elapsed)
	}

	// The stall itself is silent: nothing was consumed, nothing admitted,
	// and a wedged reader is not a protocol failure.
	if n := mux.Len(); n != 0 {
		t.Fatalf("%d streams admitted past a stalled read loop", n)
	}
	select {
	case <-mux.Done():
		t.Fatal("a stalled reader tore the mux down without any frame")
	default:
	}

	// End the scenario: releasing the stall and closing the peer let the
	// read loop observe the dead pipe and tear the mux down; cleanup joins
	// it boundedly.
	rg.release()
	c2.Close()
	select {
	case <-mux.Done():
	case <-time.After(5 * time.Second):
		t.Fatal("mux never tore down after the stalled reader was released")
	}
}

// TestFloodDispatcherAckWriteErrorSurfaces injects an ACK-write failure
// into the shared dispatcher: the failure must be forwarded on the error
// channel and the success signal suppressed — a harness failure must fail
// with its cause instead of being swallowed into a later timeout — and the
// dispatcher must exit boundedly.
func TestFloodDispatcherAckWriteErrorSurfaces(t *testing.T) {
	mux, p := newMuxPair(t, testLimits(), RoleGateway)

	errInjected := errors.New("injected ack write failure")
	acked := make(chan struct{}, 1)
	errCh := make(chan error, 1)
	dispDone := make(chan struct{})
	gate := make(chan struct{})
	var gateOnce sync.Once
	releaseGate := func() { gateOnce.Do(func() { close(gate) }) }
	var legitID atomic.Uint64
	disp := &floodDispatcher{
		tr:    p.tr,
		write: func(Frame) error { return errInjected },
		// Empty flood range: nothing parks the dispatcher.
		floodLo: 1,
		floodHi: 0,
		gate:    gate,
		legitID: &legitID,
		acked:   acked,
		stalled: make(chan struct{}, 1),
		resets:  make(chan uint64, 1),
		errCh:   errCh,
		done:    dispDone,
	}
	t.Cleanup(func() {
		releaseGate()
		p.c.Close()
		select {
		case <-dispDone:
		case <-time.After(5 * time.Second):
			t.Error("dispatcher did not terminate after the injected failure")
		}
	})
	go disp.run()

	opened := make(chan openResult, 1)
	go func() {
		s, err := mux.Open(5 * time.Second)
		opened <- openResult{stream: s, err: err}
	}()

	select {
	case err := <-errCh:
		if err == nil || !strings.Contains(err.Error(), "ack write") {
			t.Fatalf("dispatcher error = %v, want the forwarded ack-write failure", err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("dispatcher never forwarded the injected ack-write failure")
	}
	select {
	case <-dispDone:
	case <-time.After(5 * time.Second):
		t.Fatal("dispatcher did not exit after the injected failure")
	}
	select {
	case <-acked:
		t.Fatal("success signalled despite the failed ack write")
	default:
	}
	// End the scenario: closing the peer unblocks the mux read loop, so
	// the opener returns instead of lingering to its timeout.
	p.c.Close()
	select {
	case <-opened:
	case <-time.After(5 * time.Second):
		t.Error("opener never returned after the peer transport closed")
	}
}

// TestFloodDispatcherEchoWriteErrorSurfaces runs the ACK path to success
// (its signal fires only after the write succeeded), then arms the echo
// write to fail: the failure must surface on the error channel and
// terminate the dispatcher boundedly.
func TestFloodDispatcherEchoWriteErrorSurfaces(t *testing.T) {
	mux, p := newMuxPair(t, testLimits(), RoleGateway)

	var armed atomic.Bool
	errInjected := errors.New("injected echo write failure")
	write := func(f Frame) error {
		if armed.Load() {
			return errInjected
		}
		return p.tryWrite(f)
	}
	acked := make(chan struct{}, 1)
	errCh := make(chan error, 1)
	dispDone := make(chan struct{})
	gate := make(chan struct{})
	var gateOnce sync.Once
	releaseGate := func() { gateOnce.Do(func() { close(gate) }) }
	var legitID atomic.Uint64
	disp := &floodDispatcher{
		tr:      p.tr,
		write:   write,
		floodLo: 1, // empty flood range: nothing parks the dispatcher
		floodHi: 0,
		gate:    gate,
		legitID: &legitID,
		acked:   acked,
		stalled: make(chan struct{}, 1),
		resets:  make(chan uint64, 1),
		errCh:   errCh,
		done:    dispDone,
	}
	t.Cleanup(func() {
		releaseGate()
		p.c.Close()
		select {
		case <-dispDone:
		case <-time.After(5 * time.Second):
			t.Error("dispatcher did not terminate after the injected failure")
		}
	})
	go disp.run()

	s, err := mux.Open(5 * time.Second)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	// Open can return the moment the mux consumed the ACK bytes, a hair
	// before the dispatcher is scheduled to emit its post-success signal,
	// so await the signal with a bound instead of a non-blocking check.
	select {
	case <-acked: // fired only after the ack write itself succeeded
	case <-time.After(5 * time.Second):
		t.Fatal("no ack success signal after a successful ack write")
	}
	legitID.Store(s.ID())
	armed.Store(true)
	if _, err := s.Write([]byte("echo me")); err != nil {
		t.Fatalf("stream write: %v", err)
	}
	select {
	case err := <-errCh:
		if err == nil || !strings.Contains(err.Error(), "echo write") {
			t.Fatalf("dispatcher error = %v, want the forwarded echo-write failure", err)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("dispatcher never forwarded the injected echo-write failure")
	}
	select {
	case <-dispDone:
	case <-time.After(5 * time.Second):
		t.Fatal("dispatcher did not exit after the injected failure")
	}
	// The dispatcher is gone, so the stream must NOT be closed here: its
	// RESET write would wedge on the now-unread pipe. Cleanup tears the
	// mux down without writing.
}

// TestFloodDispatcherEarlyAbortCleanupJoins simulates an early harness
// abort before the gate is ever released: the cleanup sequence every
// flood-regression test registers before starting its dispatcher (idempotent
// gate release, peer transport close, bounded join) must un-park the
// stalled reader and join it, with the terminal read error forwarded —
// never hanging the global test run and never swallowing the state.
func TestFloodDispatcherEarlyAbortCleanupJoins(t *testing.T) {
	mux, p := newMuxPair(t, testLimits(), RoleGateway)

	const floodID = uint64(7200) // the whole flood range is this one id
	gate := make(chan struct{})
	var gateOnce sync.Once
	releaseGate := func() { gateOnce.Do(func() { close(gate) }) }
	stalled := make(chan struct{}, 1)
	resets := make(chan uint64, 8)
	errCh := make(chan error, 1)
	dispDone := make(chan struct{})
	var legitID atomic.Uint64
	disp := &floodDispatcher{
		tr:      p.tr,
		write:   p.tryWrite,
		floodLo: floodID - 1,
		floodHi: floodID,
		gate:    gate,
		legitID: &legitID,
		acked:   make(chan struct{}, 1),
		stalled: stalled,
		resets:  resets,
		errCh:   errCh,
		done:    dispDone,
	}
	cleanup := func() {
		releaseGate()
		p.c.Close()
		select {
		case <-dispDone:
		case <-time.After(5 * time.Second):
			t.Error("parked dispatcher did not terminate after cleanup")
		}
	}
	t.Cleanup(cleanup) // re-run at test end; idempotent by construction
	go disp.run()

	// One role-invalid OPEN inside the dispatcher's flood range: the mux
	// refuses it, the worker writes the RESET, and the dispatcher parks.
	p.write(t, Frame{Type: FrameOpen, StreamID: floodID})
	select {
	case id := <-resets:
		if id != floodID {
			t.Fatalf("reset id %d, want %d", id, floodID)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("flood-range refusal never reached the dispatcher")
	}
	select {
	case <-stalled:
	case <-time.After(5 * time.Second):
		t.Fatal("dispatcher never reported the controlled stall")
	}
	select {
	case <-mux.Done():
		t.Fatal("a single sub-capacity refusal tore the mux down")
	default:
	}

	// The early-abort path itself: cleanup must release, close, and join
	// within bounds even though the dispatcher is parked on the gate.
	cleanup()
	select {
	case err := <-errCh:
		if err == nil {
			t.Fatal("dispatcher joined without forwarding its terminal read error")
		}
	case <-time.After(5 * time.Second):
		t.Fatal("dispatcher joined without a terminal error on the error channel")
	}
}

// TestFloodHarnessEarlyOpenFailureCleanup calibrates the flood harness's
// EARLY-OPEN-FAILURE lifecycle against a real mux and the real dispatcher
// (the later-abort and gated-flood shapes are covered above): the
// legitimate OPEN fails before the flood writer was ever launched — here
// the dispatcher provably blocks forever on its first ACK write, so Open
// hits its timer with no ACK possible — and the cleanup sequence
// registered before the dispatcher started must release the gate, join the
// stuck dispatcher boundedly, and neither wait out its bound on a writer
// that was never started nor leak the opener. A lifecycle that waits on
// the unlaunched writer stalls out its 5s join bound here and fails this
// test twice.
func TestFloodHarnessEarlyOpenFailureCleanup(t *testing.T) {
	mux, p := newMuxPair(t, testLimits(), RoleGateway)

	errInjected := errors.New("injected ack write failure")
	gate := make(chan struct{})
	var gateOnce sync.Once
	releaseGate := func() { gateOnce.Do(func() { close(gate) }) }
	errCh := make(chan error, 1)
	dispDone := make(chan struct{})
	var legitID atomic.Uint64
	disp := &floodDispatcher{
		tr: p.tr,
		// The dispatcher's first ACK write blocks on the gate and then
		// fails: the OPEN is consumed, but no ACK can ever be produced, so
		// the open fails early while the dispatcher stays alive and stuck —
		// the state the main regression's early Fatal leaves behind.
		write: func(Frame) error {
			<-gate
			return errInjected
		},
		// Empty flood range: nothing else parks the dispatcher.
		floodLo: 1,
		floodHi: 0,
		gate:    gate,
		legitID: &legitID,
		acked:   make(chan struct{}, 1),
		stalled: make(chan struct{}, 1),
		resets:  make(chan uint64, 1),
		errCh:   errCh,
		done:    dispDone,
	}
	flood := newFloodWriter()

	cleanup := floodCleanup(t, releaseGate, p, flood, dispDone)
	t.Cleanup(cleanup) // re-run at test end; idempotent by construction
	go disp.run()

	// The legitimate open fails early — its OPEN is consumed but never
	// ACKed, so the opener returns its timeout verdict.
	opened := make(chan openResult, 1)
	go func() {
		s, err := mux.Open(250 * time.Millisecond)
		opened <- openResult{stream: s, err: err}
	}()
	var r openResult
	select {
	case r = <-opened:
	case <-time.After(5 * time.Second):
		t.Fatal("opener never returned from the early failure")
	}
	if r.err == nil || !strings.Contains(r.err.Error(), "did not acknowledge") {
		t.Fatalf("open err = %v, want the open-timeout verdict", r.err)
	}
	// In the main regression the writer launch sits strictly after the
	// early-failure Fatal: it must never have been armed here either.
	select {
	case <-flood.launched:
		t.Fatal("flood writer launched despite the early open failure")
	default:
	}

	// The early-failure cleanup itself: gate release (unblocks the stuck
	// dispatcher), peer close, bounded joins. With the writer never
	// launched there is nothing to wait for, so this completes in well
	// under the join bound.
	start := time.Now()
	cleanup()
	if elapsed := time.Since(start); elapsed > 2*time.Second {
		t.Fatalf("early-failure cleanup took %s: it waited on work that was never started", elapsed)
	}
	select {
	case <-gate:
	default:
		t.Fatal("cleanup did not release the gate")
	}
	select {
	case <-dispDone:
	default:
		t.Fatal("cleanup did not join the stuck dispatcher")
	}
	select {
	case err := <-errCh:
		if err == nil || !strings.Contains(err.Error(), "ack write") {
			t.Fatalf("dispatcher error = %v, want the forwarded ack-write failure", err)
		}
	default:
		t.Fatal("dispatcher joined without forwarding its failure")
	}
	select {
	case <-flood.launched:
		t.Fatal("flood writer was launched by cleanup")
	default:
	}
	select {
	case <-flood.done:
		t.Fatal("unlaunched writer's done channel closed: fictitious worker")
	default:
	}
}

// muxPipePair connects two muxes back-to-back over a net.Pipe with the
// gateway opening and the host accepting a single stream.
func muxPipePair(t *testing.T, limits Limits) (client, server *Stream, wait func()) {
	t.Helper()
	c1, c2 := net.Pipe()
	gw := NewMux(newPipeTransport(c1), limits, RoleGateway)
	ho := NewMux(newPipeTransport(c2), limits, RoleHost)
	opened := make(chan *Stream, 1)
	var once sync.Once
	done := make(chan struct{})
	go func() {
		s, err := gw.Open(5 * time.Second)
		if err != nil {
			t.Errorf("open: %v", err)
			close(opened)
			return
		}
		opened <- s
	}()
	accepted := make(chan *Stream, 1)
	go func() {
		s, err := ho.Accept()
		if err != nil {
			t.Errorf("accept: %v", err)
			close(accepted)
			return
		}
		if err := s.Ack(); err != nil {
			t.Errorf("ack: %v", err)
		}
		accepted <- s
	}()
	select {
	case client = <-opened:
	case <-time.After(5 * time.Second):
		t.Fatal("open timeout")
	}
	select {
	case server = <-accepted:
	case <-time.After(5 * time.Second):
		t.Fatal("accept timeout")
	}
	return client, server, func() {
		once.Do(func() {
			gw.Close()
			ho.Close()
			c1.Close()
			c2.Close()
			close(done)
		})
		<-done
	}
}

// TestMalformedFramesTearDown: bad version, unknown type, short header,
// and length mismatch are hard protocol errors (fail closed).
//
// Harness: a byte stream cannot know a frame is truncated until the peer
// stops sending, so each case writes its raw bytes and then closes the
// peer end — a write that fails with a closed pipe is itself the teardown
// signal (the mux aborted mid-frame).
func TestMalformedFramesTearDown(t *testing.T) {
	cases := []struct {
		name string
		raw  []byte
	}{
		{"short header", make([]byte, 10)},
		{"bad version", func() []byte { b := make([]byte, 20); b[0] = 9; return b }()},
		{"unknown type", func() []byte {
			b := make([]byte, 20)
			b[0] = 1
			b[1] = 77
			binary.BigEndian.PutUint32(b[10:], 6)
			return b
		}()},
		{"length mismatch", func() []byte {
			b := make([]byte, 20)
			b[0] = 1
			b[1] = FrameData
			binary.BigEndian.PutUint32(b[10:], 8)
			return b
		}()},
		{"stream id zero", func() []byte {
			b := make([]byte, 14)
			b[0] = 1
			b[1] = FrameData
			binary.BigEndian.PutUint32(b[10:], 0)
			return b
		}()},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			limits := testLimits()
			mux, p := newMuxPair(t, limits, RoleHost)
			if err := p.tryWriteRaw(tc.raw); err != nil {
				// The mux tore down mid-write; verify and finish.
				select {
				case <-mux.Done():
					return
				default:
				}
				t.Fatalf("peer write failed but mux is still up: %v", err)
			}
			_ = p.c.Close() // end the byte stream (truncation)
			select {
			case <-mux.Done():
			case <-time.After(2 * time.Second):
				t.Fatal("malformed frame did not tear the connection down")
			}
			if err := mux.Err(); err == nil {
				t.Fatal("teardown recorded no cause")
			}
		})
	}
}

// TestUnknownStreamFramesTearDown: frames for never-seen stream IDs are a
// hard error (only tombstoned IDs are tolerated).
func TestUnknownStreamFramesTearDown(t *testing.T) {
	limits := testLimits()
	mux, p := newMuxPair(t, limits, RoleHost)
	p.write(t, Frame{Type: FrameData, StreamID: 12345, Payload: []byte("hi")})
	select {
	case <-mux.Done():
	case <-time.After(2 * time.Second):
		t.Fatal("unknown-stream frame did not tear the connection down")
	}
}

// TestA3ConcurrentKeepaliveAndData exercises the serialized writer under
// sustained traffic and pings (race detector target).
func TestA3ConcurrentKeepaliveAndData(t *testing.T) {
	limits := testLimits()
	client, server, wait := muxPipePair(t, limits)
	defer wait()

	stop := make(chan struct{})
	defer close(stop)
	// Concurrent writer storm.
	var wg sync.WaitGroup
	for i := 0; i < 4; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			buf := make([]byte, 3000)
			for {
				select {
				case <-stop:
					return
				default:
				}
				if _, err := client.Write(buf); err != nil {
					return
				}
			}
		}()
	}
	// Server drains everything.
	drained := 0
	buf := make([]byte, 8192)
	deadline := time.Now().Add(500 * time.Millisecond)
	for time.Now().Before(deadline) {
		n, err := server.Read(buf)
		drained += n
		if err != nil {
			t.Fatalf("server read: %v (drained %d)", err, drained)
		}
	}
}

// TestA4HealthySessionOutlivesHandshakeDeadline is at the service level;
// see service A4 test in e2e_keepalive_test.go.
var _ = errors.New
