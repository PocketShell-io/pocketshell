package tunnel

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	neturl "net/url"
	"os/exec"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel/wsnet"
)

// --- identity-backed fakes: the real identity.Service wired through the
// documented adapters (the same way root will wire production) ------------

type testWorld struct {
	idSvc   *identity.Service
	svc     *Service
	hs      *httptest.Server
	wsURL   string
	devices map[string]ed25519.PrivateKey
	sshd    *testSSHServer
	// pins holds the independently provisioned SSH host key pins per
	// device (finding O1): clients never derive trust from the gateway.
	pins map[string]string
	// lookup is the (overridable) device lookup path used by the gateway
	// adapter; tests gate it to exercise the revocation race.
	storeMu  sync.Mutex
	lookupFn func(id string) (Device, error)
}

const (
	acctAlice = "google:alice-sub-111"
	acctBob   = "google:bob-sub-222"

	tokenAlice = "test-token-alice"
	tokenBob   = "test-token-bob"
)

// newTestWorld builds a real identity service (in-memory registry, fake
// token verifier), the tunnel gateway over the documented adapters, the
// OnRevoke wiring, and a real in-process sshd. Two devices are enrolled
// for two different accounts, each pinned (independently, per O1) to the
// test sshd host key.
func newTestWorld(t *testing.T, mutate func(*ServiceOptions)) *testWorld {
	t.Helper()
	sshd := newTestSSHServer(t)
	hostKeyLine := strings.TrimSpace(string(ssh.MarshalAuthorizedKey(sshd.hostKey)))

	mem := identity.NewMemoryStore()
	idSvc, err := identity.NewService(identity.Config{
		Verifier: fakeVerifier(map[string]identity.Principal{
			tokenAlice: {AccountID: acctAlice, Email: "alice@example.com",
				ExpiresAt: time.Now().Add(5 * time.Minute)},
			tokenBob: {AccountID: acctBob, Email: "bob@example.com",
				ExpiresAt: time.Now().Add(5 * time.Minute)},
		}),
		Store:  mem,
		Domain: "127.0.0.1",
		Clock:  time.Now,
	})
	if err != nil {
		t.Fatal(err)
	}

	// Enroll two devices through the REAL identity store.
	devices := map[string]ed25519.PrivateKey{}
	for _, spec := range []struct {
		id      string
		account string
	}{
		{"dev-alice", acctAlice},
		{"dev-bob", acctBob},
	} {
		pub, priv, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			t.Fatal(err)
		}
		devices[spec.id] = priv
		if err := mem.Put(identity.Device{
			ID:         spec.id,
			AccountID:  spec.account,
			PublicKey:  pub,
			SSHHostKey: hostKeyLine,
		}); err != nil {
			t.Fatal(err)
		}
	}

	opts := ServiceOptions{
		Authenticate: tunnelAuth(idSvc),
		Limits: Limits{
			HandshakeTimeout: 5 * time.Second,
			PongWait:         60 * time.Second,
			PingInterval:     20 * time.Second,
		},
	}
	w := &testWorld{
		idSvc:   idSvc,
		devices: devices,
		sshd:    sshd,
		pins: map[string]string{
			"dev-alice": hostKeyLine,
			"dev-bob":   hostKeyLine,
		},
	}
	// The documented adapter path: tunnel.DeviceStore over identity.Store,
	// routed through the world so tests can gate/inspect lookups.
	w.lookupFn = func(id string) (Device, error) {
		d, err := idSvc.Store().GetDevice(id)
		if err != nil {
			return Device{}, err
		}
		return Device{
			ID:         d.ID,
			AccountID:  d.AccountID,
			PublicKey:  d.PublicKey,
			SSHHostKey: d.SSHHostKey,
			Revoked:    d.Revoked,
		}, nil
	}
	opts.Store = DeviceStoreFunc(func(id string) (Device, error) {
		w.storeMu.Lock()
		fn := w.lookupFn
		w.storeMu.Unlock()
		return fn(id)
	})
	if mutate != nil {
		mutate(&opts)
	}
	svc, err := NewService(opts)
	if err != nil {
		t.Fatal(err)
	}
	// OnRevoke wiring (the production contract): revoke tears sessions.
	idSvc.OnRevoke(func(d identity.Device) { svc.RevokeDevice(d.ID) })

	hs := httptest.NewServer(svc)
	t.Cleanup(func() {
		hs.Close()
		svc.Close()
	})
	w.svc = svc
	w.hs = hs
	w.wsURL = "ws" + strings.TrimPrefix(hs.URL, "http")
	return w
}

// gateStore replaces the lookup path (tests).
func (w *testWorld) setLookup(fn func(id string) (Device, error)) {
	w.storeMu.Lock()
	defer w.storeMu.Unlock()
	w.lookupFn = fn
}

type fakeVerifier map[string]identity.Principal

func (f fakeVerifier) VerifyToken(_ context.Context, token string) (identity.Principal, error) {
	if p, ok := f[token]; ok {
		return p, nil
	}
	return identity.Principal{}, errors.New("bad token")
}

// revoke updates the registry (persist) then fires the tunnel teardown —
// the same ordering identity's HTTP handler uses.
func (w *testWorld) revoke(t *testing.T, deviceID, byAccount string) {
	t.Helper()
	if _, _, _, err := w.idSvc.DeviceStore().Revoke(deviceID, byAccount); err != nil {
		t.Fatal(err)
	}
	w.svc.RevokeDevice(deviceID)
}

// --- a real in-process SSH server (x/crypto/ssh) ---------------------------

type testSSHServer struct {
	addr       string
	hostKey    ssh.PublicKey
	authSigner ssh.Signer // the only accepted user key (clients use it)
	ln         net.Listener
	wg         sync.WaitGroup
}

func newTestSSHServer(t *testing.T) *testSSHServer {
	t.Helper()
	hostSigner, err := ssh.NewSignerFromKey(newEd25519Key(t))
	if err != nil {
		t.Fatal(err)
	}
	authSigner, err := ssh.NewSignerFromKey(newEd25519Key(t))
	if err != nil {
		t.Fatal(err)
	}
	s := &testSSHServer{hostKey: hostSigner.PublicKey(), authSigner: authSigner}
	config := &ssh.ServerConfig{
		PublicKeyCallback: func(conn ssh.ConnMetadata, key ssh.PublicKey) (*ssh.Permissions, error) {
			if string(key.Marshal()) == string(s.authSigner.PublicKey().Marshal()) {
				return &ssh.Permissions{}, nil
			}
			return nil, fmt.Errorf("unknown public key for %q", conn.User())
		},
	}
	config.AddHostKey(hostSigner)
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	s.ln = ln
	s.addr = ln.Addr().String()
	s.wg.Add(1)
	go s.serve(config)
	t.Cleanup(func() {
		ln.Close()
		s.wg.Wait()
	})
	return s
}

func (s *testSSHServer) serve(config *ssh.ServerConfig) {
	defer s.wg.Done()
	for {
		c, err := s.ln.Accept()
		if err != nil {
			return
		}
		s.wg.Add(1)
		go func() {
			defer s.wg.Done()
			defer c.Close()
			sconn, chans, reqs, err := ssh.NewServerConn(c, config)
			if err != nil {
				return
			}
			defer sconn.Close()
			go ssh.DiscardRequests(reqs)
			for newChan := range chans {
				if newChan.ChannelType() != "session" {
					newChan.Reject(ssh.UnknownChannelType, "unsupported")
					continue
				}
				ch, requests, err := newChan.Accept()
				if err != nil {
					continue
				}
				s.handleSession(ch, requests)
			}
		}()
	}
}

func (s *testSSHServer) handleSession(ch ssh.Channel, requests <-chan *ssh.Request) {
	defer ch.Close()
	for req := range requests {
		switch req.Type {
		case "exec":
			if len(req.Payload) < 4 {
				req.Reply(false, nil)
				continue
			}
			cmdLen := int(req.Payload[0])<<24 | int(req.Payload[1])<<16 | int(req.Payload[2])<<8 | int(req.Payload[3])
			if cmdLen > len(req.Payload)-4 {
				req.Reply(false, nil)
				continue
			}
			cmd := string(req.Payload[4 : 4+cmdLen])
			req.Reply(true, nil)
			// Real command execution: the e2e is a genuine SSH exec round
			// trip through the tunnel, not a canned echo.
			out, err := exec.Command("/bin/sh", "-c", cmd).CombinedOutput()
			if len(out) > 0 {
				_, _ = ch.Write(out)
			}
			status := uint32(0)
			if err != nil {
				if ee, ok := err.(*exec.ExitError); ok {
					status = uint32(ee.ExitCode())
				} else {
					status = 127
				}
			}
			_, _ = ch.SendRequest("exit-status", false, ssh.Marshal(struct{ Status uint32 }{status}))
			ch.CloseWrite()
			return
		default:
			if req.WantReply {
				req.Reply(false, nil)
			}
		}
	}
}

func newEd25519Key(t *testing.T) ed25519.PrivateKey {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	return priv
}

func mustSigner(t *testing.T) ssh.Signer {
	t.Helper()
	s, err := ssh.NewSignerFromKey(newEd25519Key(t))
	if err != nil {
		t.Fatal(err)
	}
	return s
}

// --- WS dial helpers --------------------------------------------------------

// dialAgentWS connects to the agent endpoint and completes the challenge
// handshake with the device key, returning the connection, the seen
// challenge (for replay tests) and any error.
func dialAgentWS(t *testing.T, wsURL, deviceID string, key ed25519.PrivateKey) (*websocket.Conn, HostChallenge, error) {
	t.Helper()
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, resp, err := dialer.Dial(wsURL+PathAgentConnect, nil)
	if err != nil {
		code := 0
		if resp != nil {
			code = resp.StatusCode
		}
		return nil, HostChallenge{}, httpErr{code, err}
	}
	ws.SetReadLimit(1 << 20)
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		return nil, HostChallenge{}, err
	}
	var ch HostChallenge
	if err := json.Unmarshal(raw, &ch); err != nil {
		return nil, HostChallenge{}, err
	}
	identityCh, err := ch.ToIdentityChallenge(deviceID)
	if err != nil {
		return nil, HostChallenge{}, err
	}
	sig, err := identity.Sign(key, identityCh)
	if err != nil {
		return nil, HostChallenge{}, err
	}
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(HostAuth{
		Type: "auth", V: ProtocolVersion, DeviceID: deviceID,
		Signature: base64.StdEncoding.EncodeToString(sig),
	})); err != nil {
		return nil, HostChallenge{}, err
	}
	_, raw, err = ws.ReadMessage()
	if err != nil {
		return nil, HostChallenge{}, err
	}
	var ok OKMsg
	if err := json.Unmarshal(raw, &ok); err != nil || ok.Type != "ok" {
		return nil, HostChallenge{}, fmt.Errorf("handshake not ok: %s", string(raw))
	}
	_ = ws.SetReadDeadline(time.Time{})
	return ws, ch, nil
}

type httpErr struct {
	code int
	err  error
}

func (e httpErr) Error() string {
	if e.code != 0 {
		return fmt.Sprintf("HTTP %d: %v", e.code, e.err)
	}
	return e.err.Error()
}

// dialAgentMux completes the handshake and returns the muxed connection.
func dialAgentMux(t *testing.T, wsURL, deviceID string, key ed25519.PrivateKey, limits Limits) *Mux {
	t.Helper()
	ws, _, err := dialAgentWS(t, wsURL, deviceID, key)
	if err != nil {
		t.Fatalf("dial agent: %v", err)
	}
	t.Cleanup(func() { ws.Close() })
	return NewMux(NewWSTransport(ws, limits), limits, RoleGateway)
}

type clientConn struct {
	WS         *websocket.Conn
	SSHHostKey string // ADVISORY registry metadata from `ready` (O1: not a pin)
}

// clientSSHPath is the full published client route (the service parses it
// itself; there is no prefix-only dial form).
func clientSSHPath(deviceID string) string {
	return PathClientSSH + deviceID + clientSSHPathSuffix
}

// dialClientWS performs the client JSON auth; on rejection it returns the
// error frame and the close code (0 when the connection stayed open).
func dialClientWS(t *testing.T, wsURL, deviceID, token string) (*clientConn, *ErrMsg, int, error) {
	t.Helper()
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, resp, err := dialer.Dial(wsURL+clientSSHPath(deviceID), nil)
	if err != nil {
		code := 0
		if resp != nil {
			code = resp.StatusCode
		}
		return nil, nil, code, err
	}
	_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(ClientAuth{
		Type: "auth", V: ProtocolVersion, Token: token, DeviceID: deviceID,
	})); err != nil {
		return nil, nil, 0, err
	}
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		return nil, nil, 0, err
	}
	var generic map[string]any
	_ = json.Unmarshal(raw, &generic)
	if t2, _ := generic["type"].(string); t2 == "error" {
		var em ErrMsg
		_ = json.Unmarshal(raw, &em)
		return nil, &em, 0, errors.New("rejected: " + em.Code)
	}
	var ready ReadyMsg
	if err := json.Unmarshal(raw, &ready); err != nil || ready.Type != "ready" {
		return nil, nil, 0, fmt.Errorf("unexpected reply %s", string(raw))
	}
	_ = ws.SetReadDeadline(time.Time{})
	return &clientConn{WS: ws, SSHHostKey: ready.SSHHostKey}, nil, 0, nil
}

// --- SSH client over the tunnel ---------------------------------------------

// sshDial builds a real SSH client over the tunnel WebSocket. The pinned
// host key comes from independent provisioning ONLY (finding O1): the
// gateway's advisory metadata is cross-checked but never trusted. sshAuth
// rejects a user key that the test sshd does not accept, which is the
// end-to-end negative control for SSH authentication.
func sshDial(t *testing.T, ws *websocket.Conn, provisionedPin, advisory string, userKey ssh.Signer) (*ssh.Client, error) {
	t.Helper()
	// O1 cross-check: the advisory must match the pin or the client aborts
	// (a compromised gateway cannot normalize a key swap this way).
	if advisory != "" && !sameHostKeyLine(provisionedPin, advisory) {
		return nil, fmt.Errorf("advisory ssh host key differs from the provisioned pin; aborting")
	}
	pinned, _, _, _, err := ssh.ParseAuthorizedKey([]byte(provisionedPin))
	if err != nil {
		return nil, fmt.Errorf("parse provisioned pin: %w", err)
	}
	cfg := &ssh.ClientConfig{
		User: "alice",
		Auth: []ssh.AuthMethod{ssh.PublicKeys(userKey)},
		HostKeyCallback: func(hostname string, remote net.Addr, key ssh.PublicKey) error {
			if string(key.Marshal()) != string(pinned.Marshal()) {
				return fmt.Errorf("SSH host key mismatch: got %s", ssh.FingerprintSHA256(key))
			}
			return nil
		},
		Timeout: 5 * time.Second,
	}
	conn, chans, reqs, err := ssh.NewClientConn(wsnet.Wrap(ws), "pocketshell-tunnel", cfg)
	if err != nil {
		return nil, err
	}
	return ssh.NewClient(conn, chans, reqs), nil
}

// sameHostKeyLine compares algorithm+blob, ignoring comments.
func sameHostKeyLine(a, b string) bool {
	fa := strings.Fields(a)
	fb := strings.Fields(b)
	return len(fa) >= 2 && len(fb) >= 2 && fa[0] == fb[0] && fa[1] == fb[1]
}

// openClientSession is the full client path: authenticate, verify the
// provisioned pin, run SSH and exec a command.
func (w *testWorld) clientExec(t *testing.T, deviceID, token string, userKey ssh.Signer, cmd string) (string, error) {
	t.Helper()
	cc, em, _, err := dialClientWS(t, w.wsURL, deviceID, token)
	if em != nil || err != nil {
		if em != nil {
			return "", errors.New("rejected: " + em.Code)
		}
		return "", err
	}
	t.Cleanup(func() { cc.WS.Close() })
	pin := w.pins[deviceID] // provisioned out-of-band
	cl, err := sshDial(t, cc.WS, pin, cc.SSHHostKey, userKey)
	if err != nil {
		return "", err
	}
	defer cl.Close()
	sess, err := cl.NewSession()
	if err != nil {
		return "", err
	}
	defer sess.Close()
	out, err := sess.CombinedOutput(cmd)
	return string(out), err
}

// waitConnected polls IsDeviceConnected (agent handshakes are async).
func (s *Service) waitConnected(t *testing.T, deviceID string, within time.Duration) {
	t.Helper()
	deadline := time.Now().Add(within)
	for time.Now().Before(deadline) {
		if s.IsDeviceConnected(deviceID) {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatalf("device %s did not connect within %s", deviceID, within)
}

// --- pipeTransport: mux unit tests over an in-memory pipe ------------------

// pipeTransport is a Transport over a net.Conn (used with net.Pipe to
// drive mux protocol-level tests without WebSockets).
type pipeTransport struct {
	c  net.Conn
	wm chan struct{}
}

func newPipeTransport(c net.Conn) *pipeTransport {
	return &pipeTransport{c: c, wm: make(chan struct{}, 1)}
}

func (p *pipeTransport) ReadFrame() (Frame, error) {
	head := make([]byte, frameHeaderLen)
	if _, err := ioReadFull(p.c, head); err != nil {
		return Frame{}, err
	}
	if head[0] != FrameVersion {
		return Frame{}, ErrProtocol
	}
	n := int(head[10])<<24 | int(head[11])<<16 | int(head[12])<<8 | int(head[13])
	if n < 0 || uint64(n) > maxFramePayloadHard {
		return Frame{}, ErrProtocol
	}
	f := Frame{
		Type: head[1],
		StreamID: uint64(head[2])<<56 | uint64(head[3])<<48 | uint64(head[4])<<40 | uint64(head[5])<<32 |
			uint64(head[6])<<24 | uint64(head[7])<<16 | uint64(head[8])<<8 | uint64(head[9]),
	}
	if n > 0 {
		f.Payload = make([]byte, n)
		if _, err := ioReadFull(p.c, f.Payload); err != nil {
			return Frame{}, err
		}
	}
	return f, nil
}

func (p *pipeTransport) WriteFrame(f Frame) error {
	p.wm <- struct{}{}
	defer func() { <-p.wm }()
	buf, err := AppendFrame(make([]byte, 0, frameHeaderLen+len(f.Payload)), f)
	if err != nil {
		return err
	}
	_, err = p.c.Write(buf)
	return err
}

func (p *pipeTransport) Close() error { return p.c.Close() }

func ioReadFull(c net.Conn, buf []byte) (int, error) {
	total := 0
	for total < len(buf) {
		n, err := c.Read(buf[total:])
		total += n
		if err != nil {
			return total, err
		}
	}
	return total, nil
}

// readFrameWithTimeout reads one frame from a raw conn (test side).
func readFrameWithTimeout(t *testing.T, c net.Conn, d time.Duration) Frame {
	t.Helper()
	_ = c.SetReadDeadline(time.Now().Add(d))
	tr := newPipeTransport(c)
	f, err := tr.ReadFrame()
	if err != nil {
		t.Fatalf("read frame: %v", err)
	}
	_ = c.SetReadDeadline(time.Time{})
	return f
}

// netDial dials the test sshd (host-side bridge).
func netDial(addr string) (net.Conn, error) {
	return net.DialTimeout("tcp", addr, 3*time.Second)
}

// bridgeStreams pumps both directions with half-close handling (mirrors
// internal/hostagent.bridge).
func bridgeStreams(a io.ReadWriteCloser, b io.ReadWriteCloser) {
	done := make(chan struct{}, 2)
	halfClose := func(c io.ReadWriteCloser) {
		if t, ok := c.(interface{ CloseWrite() error }); ok {
			_ = t.CloseWrite()
		}
	}
	copyOne := func(dst, src io.ReadWriteCloser) {
		defer func() { done <- struct{}{} }()
		_, err := io.Copy(dst, src)
		switch {
		case err == nil || errors.Is(err, io.EOF):
			halfClose(dst)
		default:
			_ = dst.Close()
			_ = src.Close()
		}
	}
	go copyOne(b, a)
	go copyOne(a, b)
	<-done
	<-done
	a.Close()
	b.Close()
}

// dialAgentWSCaptureOnly dials the agent endpoint and reads just the
// challenge (replay tests drive the auth frame by hand).
func dialAgentWSCaptureOnly(t *testing.T, wsURL string) (*websocket.Conn, HostChallenge, error) {
	t.Helper()
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := dialer.Dial(wsURL+PathAgentConnect, nil)
	if err != nil {
		return nil, HostChallenge{}, err
	}
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		ws.Close()
		return nil, HostChallenge{}, err
	}
	var ch HostChallenge
	if err := jsonUnmarshal(raw, &ch); err != nil {
		ws.Close()
		return nil, HostChallenge{}, err
	}
	_ = ws.SetReadDeadline(time.Time{})
	return ws, ch, nil
}

// sshSignIdentity signs an identity.Challenge and base64-encodes it.
func sshSignIdentity(key ed25519.PrivateKey, ch *identity.Challenge) (string, error) {
	sig, err := identity.Sign(key, ch)
	if err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(sig), nil
}

func jsonUnmarshal(b []byte, v any) error { return json.Unmarshal(b, v) }

// newWSRequest builds a raw GET with WebSocket upgrade headers so tests
// can control the Origin header (CheckOrigin tests).
func newWSRequest(urlStr string) (*http.Request, error) {
	u, err := neturl.Parse(urlStr)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequest(http.MethodGet, urlStr, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Upgrade", "websocket")
	req.Header.Set("Connection", "Upgrade")
	req.Header.Set("Sec-WebSocket-Version", "13")
	req.Header.Set("Sec-WebSocket-Key", "dGhlIHNhbXBsZSBub25jZQ==")
	req.Header.Set("Host", u.Host)
	return req, nil
}

// dialRaw performs a plain HTTP request against the test server.
func dialRaw(t *testing.T, req *http.Request) (*http.Response, error) {
	t.Helper()
	client := &http.Client{Timeout: 5 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error {
		return http.ErrUseLastResponse
	}}
	return client.Do(req)
}

// tunnelAuth adapts identity.Authenticate to tunnel.AuthenticateFunc (the
// conversion root performs at wiring time; identical underlying types).
// ExpiresAt is propagated: the gateway refuses admission without it.
func tunnelAuth(svc *identity.Service) AuthenticateFunc {
	idAuth := svc.TokenAuthenticator()
	return func(ctx context.Context, token string) (Principal, error) {
		p, err := idAuth(ctx, token)
		if err != nil {
			return Principal{}, err
		}
		return Principal{AccountID: p.AccountID, Email: p.Email, ExpiresAt: p.ExpiresAt}, nil
	}
}

// AuthSigner returns the user key the test sshd accepts (valid clients).
func (s *testSSHServer) AuthSigner() ssh.Signer { return s.authSigner }

// readUntilClose reads frames until the connection drops (the server
// always sends a JSON error frame before closing).
func readUntilClose(t *testing.T, ws *websocket.Conn, within time.Duration) bool {
	t.Helper()
	_ = ws.SetReadDeadline(time.Now().Add(within))
	for {
		if _, _, err := ws.ReadMessage(); err != nil {
			return true
		}
	}
}
