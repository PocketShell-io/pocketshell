package tunnel

import (
	"fmt"
	"os/exec"
	"strings"
	"testing"
	"time"

	"github.com/gorilla/websocket"
)

// TestA3KeepaliveDuringSustainedTraffic: gateway pings and multiplexer
// data share the connection through the serialized writer; a sustained
// transfer under aggressive keepalives is race-free and byte-correct.
func TestA3KeepaliveDuringSustainedTraffic(t *testing.T) {
	w := newTestWorld(t, func(o *ServiceOptions) {
		o.Limits.PingInterval = 20 * time.Millisecond // aggressive
		o.Limits.PongWait = 2 * time.Second
		o.Limits.StreamWindow = 64 << 10
		o.Limits.MaxFramePayload = 16 << 10
	})
	w.serveAgentStreams(t, "dev-alice", Limits{
		PingInterval: 20 * time.Millisecond,
		PongWait:     2 * time.Second,
	})

	// Receiving OK can precede server readiness publication; wait for its witness.
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)

	cc, em, _, err := dialClientWS(t, w.wsURL, "dev-alice", tokenAlice)
	if err != nil || em != nil {
		t.Fatalf("client: %v %v", err, em)
	}
	defer cc.WS.Close()
	pin := w.pins["dev-alice"]
	cl, err := sshDial(t, cc.WS, pin, cc.SSHHostKey, w.sshd.AuthSigner())
	if err != nil {
		t.Fatal(err)
	}
	defer cl.Close()

	// 2 MiB of server-generated data through the tunnel while both ends
	// ping; the client verifies against the same pipeline run locally.
	const cmd = "seq 1 262144 | sha256sum"
	local, err := exec.Command("/bin/sh", "-c", cmd).Output()
	if err != nil {
		t.Fatal(err)
	}
	sess, err := cl.NewSession()
	if err != nil {
		t.Fatal(err)
	}
	defer sess.Close()
	out, err := sess.Output(cmd)
	if err != nil {
		t.Fatalf("session: %v", err)
	}
	if got, want := strings.TrimSpace(string(out)), strings.TrimSpace(string(local)); got != want {
		t.Fatalf("sha mismatch over tunnel: got %s want %s", got, want)
	}
	// The command streams ~1.8 MiB of digits; require it to be real.
	if !strings.Contains(cmd, "262144") {
		t.Fatal("test command shrank")
	}
}

// TestA4HealthyHostOutlivesHandshakeDeadline: after the handshake, the
// auth read deadline must not survive into the session — a healthy host
// exchanging keepalives survives many handshake-deadline multiples; a
// stalled host that stops answering pings is dropped at PongWait.
func TestA4HealthyHostOutlivesHandshakeDeadline(t *testing.T) {
	w := newTestWorld(t, func(o *ServiceOptions) {
		o.Limits.HandshakeTimeout = 150 * time.Millisecond
		o.Limits.PongWait = 600 * time.Millisecond
		o.Limits.PingInterval = 100 * time.Millisecond
	})

	// Healthy agent: gorilla auto-pongs our pings; run well past several
	// handshake deadlines and prove the session is still usable.
	w.serveAgentStreams(t, "dev-alice", Limits{
		PingInterval: 100 * time.Millisecond,
		PongWait:     600 * time.Millisecond,
	})
	w.svc.waitConnected(t, "dev-alice", 2*time.Second)
	deadline := time.Now().Add(1500 * time.Millisecond) // 10x handshake timeout
	rounds := 0
	for time.Now().Before(deadline) {
		out, err := w.clientExec(t, "dev-alice", tokenAlice, w.sshd.AuthSigner(), "echo alive")
		if err != nil || strings.TrimSpace(out) != "alive" {
			t.Fatalf("healthy host dropped at round %d: %v (%q)", rounds, err, out)
		}
		rounds++
		time.Sleep(150 * time.Millisecond)
	}
	if rounds < 3 {
		t.Fatalf("too few rounds over the window: %d", rounds)
	}

	// Stalled host: completes the handshake, then stops answering pings
	// entirely (no pong, no data). It must be dropped within ~PongWait.
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := dialer.Dial(w.wsURL+PathAgentConnect, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer ws.Close()
	if _, err := w.completeAgentHandshake(t, ws); err != nil {
		t.Fatal(err)
	}
	// Disable the automatic pong handler: this host is now brain-dead.
	ws.SetPingHandler(func(string) error { return nil })
	start := time.Now()
	if !readUntilClose(t, ws, 3*time.Second) {
		t.Fatal("stalled host was not dropped")
	}
	if d := time.Since(start); d > 2*time.Second {
		t.Fatalf("stalled host dropped after %v, want ~PongWait", d)
	}
	deadline2 := time.Now().Add(time.Second)
	for time.Now().Before(deadline2) && w.svc.IsDeviceConnected("dev-alice") {
		time.Sleep(10 * time.Millisecond)
	}
	if w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("stalled host still registered")
	}
}

// completeAgentHandshake finishes the agent handshake on an existing
// connection (used by the stalled-host test to control pong behavior).
func (w *testWorld) completeAgentHandshake(t *testing.T, ws *websocket.Conn) (HostChallenge, error) {
	t.Helper()
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		return HostChallenge{}, err
	}
	var ch HostChallenge
	if err := jsonUnmarshal(raw, &ch); err != nil {
		return HostChallenge{}, err
	}
	idCh, err := ch.ToIdentityChallenge("dev-alice")
	if err != nil {
		return HostChallenge{}, err
	}
	sig, err := sshSignIdentity(w.devices["dev-alice"], idCh)
	if err != nil {
		return HostChallenge{}, err
	}
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(HostAuth{
		Type: "auth", V: ProtocolVersion, DeviceID: "dev-alice", Signature: sig,
	})); err != nil {
		return HostChallenge{}, err
	}
	_, raw, err = ws.ReadMessage()
	if err != nil {
		return HostChallenge{}, err
	}
	var ok OKMsg
	if err := jsonUnmarshal(raw, &ok); err != nil || ok.Type != "ok" {
		return HostChallenge{}, fmt.Errorf("handshake: %s", string(raw))
	}
	_ = ws.SetReadDeadline(time.Time{})
	return ch, nil
}
