package tunnel

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"net"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/gorilla/websocket"
)

// ackGateConn holds the actual server OK frame before its socket write. HTTP
// upgrade, challenge, signature verification and registration remain real.
type ackGateConn struct {
	net.Conn
	gate *ackGate
}
type ackGate struct {
	entered, release chan struct{}
	once             sync.Once
	releaseOnce      sync.Once
	fail             bool
}

func (g *ackGate) unblock() { g.releaseOnce.Do(func() { close(g.release) }) }
func (c *ackGateConn) Write(p []byte) (int, error) {
	if len(p) >= 2 && p[0] == 0x81 && p[1] < 126 && int(p[1])+2 == len(p) {
		var msg struct {
			Type string `json:"type"`
		}
		if json.Unmarshal(p[2:], &msg) == nil && msg.Type == msgTypeOK {
			c.gate.once.Do(func() { close(c.gate.entered) })
			select {
			case <-c.gate.release:
			case <-time.After(3 * time.Second):
				return 0, errors.New("test ACK gate timeout")
			}
			if c.gate.fail {
				return 0, errors.New("test ACK write failure")
			}
		}
	}
	return c.Conn.Write(p)
}

type ackGateListener struct {
	net.Listener
	gate *ackGate
}

func (l *ackGateListener) Accept() (net.Conn, error) {
	c, e := l.Listener.Accept()
	if e != nil {
		return nil, e
	}
	return &ackGateConn{c, l.gate}, nil
}

func beginGatedRegistration(t *testing.T, w *testWorld, fail bool) (*ackGate, *websocket.Conn) {
	t.Helper()
	gate := &ackGate{entered: make(chan struct{}), release: make(chan struct{}), fail: fail}
	hs := httptest.NewUnstartedServer(w.svc)
	hs.Listener = &ackGateListener{hs.Listener, gate}
	hs.Start()
	t.Cleanup(func() { gate.unblock(); hs.Close() })
	ws, _, err := websocket.DefaultDialer.Dial("ws"+strings.TrimPrefix(hs.URL, "http")+PathAgentConnect, nil)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = ws.Close() })
	_ = ws.SetReadDeadline(time.Now().Add(3 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatal(err)
	}
	var ch HostChallenge
	if err = json.Unmarshal(raw, &ch); err != nil {
		t.Fatal(err)
	}
	transcript, err := ch.ToIdentityChallenge("dev-alice")
	if err != nil {
		t.Fatal(err)
	}
	sig, err := identity.Sign(w.devices["dev-alice"], transcript)
	if err != nil {
		t.Fatal(err)
	}
	err = ws.WriteMessage(websocket.TextMessage, mustJSON(HostAuth{Type: msgTypeAuth, V: ProtocolVersion, DeviceID: "dev-alice", Signature: base64.StdEncoding.EncodeToString(sig)}))
	if err != nil {
		t.Fatal(err)
	}
	select {
	case <-gate.entered:
	case <-time.After(3 * time.Second):
		t.Fatal("actual signed registration never reached OK socket write")
	}
	return gate, ws
}

func TestHostNotReadyUntilAcknowledgmentWritten(t *testing.T) {
	w := newTestWorld(t, nil)
	gate, ws := beginGatedRegistration(t, w, false)
	if w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("host published as connected before authentication OK socket write completed")
	}
	// The client path must not attempt a mux OPEN against this reservation.
	client, _, err := websocket.DefaultDialer.Dial(w.wsURL+clientSSHPath("dev-alice"), nil)
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	_ = client.SetReadDeadline(time.Now().Add(time.Second))
	if err := client.WriteMessage(websocket.TextMessage, mustJSON(ClientAuth{Type: msgTypeAuth, V: ProtocolVersion, Token: tokenAlice, DeviceID: "dev-alice"})); err != nil {
		t.Fatal(err)
	}
	_, denial, err := client.ReadMessage()
	if err != nil {
		t.Fatal(err)
	}
	var rejected ErrMsg
	if err := json.Unmarshal(denial, &rejected); err != nil || rejected.Code != "host_offline" || rejected.Message != uniformClientDenial {
		t.Fatalf("pre-ACK client must receive uniform host_offline: %v", err)
	}
	gate.unblock()
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatal(err)
	}
	var ok OKMsg
	if err = json.Unmarshal(raw, &ok); err != nil || ok.Type != msgTypeOK {
		t.Fatalf("expected actual authentication OK: %v", err)
	}
	deadline := time.Now().Add(time.Second)
	for !w.svc.IsDeviceConnected("dev-alice") && time.Now().Before(deadline) {
		time.Sleep(time.Millisecond)
	}
	if !w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("successful acknowledgment did not publish host readiness")
	}
	_ = ws.SetReadDeadline(time.Time{})
	mux := NewMux(NewWSTransport(ws, Limits{}), Limits{}, RoleHost)
	t.Cleanup(func() { mux.Close() })
	go func() {
		for {
			stream, err := mux.Accept()
			if err != nil {
				return
			}
			go bridgeToSSH(stream, w.sshd.addr)
		}
	}()
	out, err := w.clientExec(t, "dev-alice", tokenAlice, w.sshd.AuthSigner(), "echo acknowledged-host")
	if err != nil || strings.TrimSpace(out) != "acknowledged-host" {
		t.Fatalf("post-ACK actual pinned SSH stream failed: %v", err)
	}
}

func TestHostAcknowledgmentFailureDoesNotPublish(t *testing.T) {
	w := newTestWorld(t, nil)
	gate, ws := beginGatedRegistration(t, w, true)
	w.svc.mu.Lock()
	hc := w.svc.hosts["dev-alice"]
	w.svc.mu.Unlock()
	if hc == nil || w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("ACK must retain an unready capacity reservation")
	}
	gate.unblock()
	if _, _, err := ws.ReadMessage(); err == nil {
		t.Fatal("failed actual ACK write must not deliver OK")
	}
	select {
	case <-hc.done:
	case <-time.After(time.Second):
		t.Fatal("failed ACK reservation was not cleaned")
	}
	if w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("failed ACK published host")
	}
}

func TestHostRevokedDuringAcknowledgmentCannotPublish(t *testing.T) {
	w := newTestWorld(t, nil)
	gate, ws := beginGatedRegistration(t, w, false)
	w.svc.mu.Lock()
	hc := w.svc.hosts["dev-alice"]
	w.svc.mu.Unlock()
	w.revoke(t, "dev-alice", acctAlice)
	gate.unblock()
	if _, _, err := ws.ReadMessage(); err == nil {
		t.Fatal("revoked host unexpectedly received OK")
	}
	select {
	case <-hc.done:
	case <-time.After(time.Second):
		t.Fatal("revoked ACK reservation was not cleaned")
	}
	if w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("revoked ACK published host")
	}
}

func TestHostReplacementDuringAcknowledgmentKeepsNewGeneration(t *testing.T) {
	w := newTestWorld(t, nil)
	gate, oldWS := beginGatedRegistration(t, w, false)
	w.svc.mu.Lock()
	old := w.svc.hosts["dev-alice"]
	w.svc.mu.Unlock()
	w.serveAgentStreams(t, "dev-alice", Limits{})
	w.svc.waitConnected(t, "dev-alice", time.Second)
	gate.unblock()
	_, _, _ = oldWS.ReadMessage()
	select {
	case <-old.done:
	case <-time.After(time.Second):
		t.Fatal("superseded ACK reservation was not cleaned")
	}
	w.svc.mu.Lock()
	cur := w.svc.hosts["dev-alice"]
	w.svc.mu.Unlock()
	if cur == nil || cur == old || cur.generation <= old.generation || !w.svc.IsDeviceConnected("dev-alice") {
		t.Fatal("late ACK cleanup disturbed replacement")
	}
	out, err := w.clientExec(t, "dev-alice", tokenAlice, w.sshd.AuthSigner(), "echo replacement-host")
	if err != nil || strings.TrimSpace(out) != "replacement-host" {
		t.Fatalf("replacement actual SSH stream failed: %v", err)
	}
}
