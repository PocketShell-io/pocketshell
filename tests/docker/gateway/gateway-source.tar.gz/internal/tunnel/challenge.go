package tunnel

import (
	"errors"
	"sync"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
)

// challengeStore issues and redeems single-use host-authentication
// challenges. Redemption is atomic: a challenge is consumed exactly once,
// so a captured (challenge, signature) pair cannot be replayed on a new
// connection. The full identity.Challenge is stored at issue time and
// handed back at redeem time, so the gateway verifies the agent's signature
// against the exact object it issued — no transcript reconstruction on the
// verifying side. Capacity-bounded and TTL-swept to bound memory.
type challengeStore struct {
	ttl   time.Duration
	cap   int
	now   func() time.Time
	mu    sync.Mutex
	items map[string]*identity.Challenge
}

var (
	errChallengeFull    = errors.New("tunnel: challenge capacity reached")
	errChallengeInvalid = errors.New("tunnel: unknown or already-used challenge")
	errChallengeExpired = errors.New("tunnel: challenge expired")
)

// newChallengeStore builds the store; ttl bounds each challenge, capacity
// bounds how many may be outstanding.
func newChallengeStore(ttl time.Duration, capacity int, now func() time.Time) *challengeStore {
	if now == nil {
		now = time.Now
	}
	return &challengeStore{
		ttl:   ttl,
		cap:   capacity,
		now:   now,
		items: make(map[string]*identity.Challenge),
	}
}

// issue mints a new challenge bound to the canonical domain. It fails
// closed when the store is at capacity.
func (c *challengeStore) issue(domain string) (*identity.Challenge, error) {
	c.sweep()
	id, err := randomToken(16)
	if err != nil {
		return nil, err
	}
	nonce, err := randomToken(32)
	if err != nil {
		return nil, err
	}
	connNonce, err := randomToken(32)
	if err != nil {
		return nil, err
	}
	ch := &identity.Challenge{
		ID:              id,
		Role:            identity.RoleHost,
		Protocol:        ProtocolTunnel,
		Domain:          domain,
		DeviceID:        "", // the agent supplies it in its signed reply
		AccountID:       "", // bound at enrollment; derived from the store here
		Nonce:           nonce,
		ConnectionNonce: connNonce,
		ExpiresAt:       c.now().UTC().Add(c.ttl),
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if len(c.items) >= c.cap {
		return nil, errChallengeFull
	}
	c.items[id] = ch
	return ch, nil
}

// redeem atomically consumes a challenge by ID. Any miss (unknown, already
// used, expired) fails closed and leaves nothing to retry against.
func (c *challengeStore) redeem(id string) (*identity.Challenge, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	ch, ok := c.items[id]
	if !ok {
		return nil, errChallengeInvalid
	}
	delete(c.items, id) // single-use even when expired
	if c.now().UTC().After(ch.ExpiresAt) {
		return nil, errChallengeExpired
	}
	return ch, nil
}

func (c *challengeStore) sweep() {
	now := c.now().UTC()
	c.mu.Lock()
	defer c.mu.Unlock()
	for id, ch := range c.items {
		if now.After(ch.ExpiresAt) {
			delete(c.items, id)
		}
	}
}

// outstanding reports the number of live challenges (tests).
func (c *challengeStore) outstanding() int {
	c.sweep()
	c.mu.Lock()
	defer c.mu.Unlock()
	return len(c.items)
}
