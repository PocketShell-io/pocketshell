// Package wsnet adapts a tunnel client WebSocket (which carries opaque
// end-to-end SSH bytes after the JSON auth handshake) to net.Conn, so a
// standard Go SSH client (golang.org/x/crypto/ssh) — or any TCP-speaking
// client — can run directly over the tunnel. Gateway-side code does not
// need this: the gateway bridges frames, never SSH.
package wsnet

import (
	"errors"
	"io"
	"net"
	"sync"
	"time"

	"github.com/gorilla/websocket"
)

// Conn is a net.Conn over one WebSocket binary stream. Each Write becomes
// one binary WebSocket message; incoming messages are reassembled into a
// continuous byte stream for Read.
type Conn struct {
	ws        *websocket.Conn
	readMu    sync.Mutex
	writeMu   sync.Mutex
	cur       []byte // remainder of the current inbound message
	closeOnce sync.Once
	closed    chan struct{}
}

// Wrap turns a post-handshake tunnel client WebSocket into a net.Conn.
func Wrap(ws *websocket.Conn) *Conn {
	return &Conn{ws: ws, closed: make(chan struct{})}
}

func (c *Conn) Read(p []byte) (int, error) {
	c.readMu.Lock()
	defer c.readMu.Unlock()
	for len(c.cur) == 0 {
		select {
		case <-c.closed:
			return 0, io.ErrClosedPipe
		default:
		}
		msgType, data, err := c.ws.ReadMessage()
		if err != nil {
			return 0, err
		}
		if msgType != websocket.BinaryMessage {
			return 0, errors.New("wsnet: non-binary frame after handshake")
		}
		c.cur = data
	}
	n := copy(p, c.cur)
	c.cur = c.cur[n:]
	return n, nil
}

func (c *Conn) Write(p []byte) (int, error) {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	select {
	case <-c.closed:
		return 0, io.ErrClosedPipe
	default:
	}
	if err := c.ws.WriteMessage(websocket.BinaryMessage, p); err != nil {
		return 0, err
	}
	return len(p), nil
}

func (c *Conn) Close() error {
	c.closeOnce.Do(func() {
		close(c.closed)
	})
	return c.ws.Close()
}

func (c *Conn) LocalAddr() net.Addr  { return c.ws.LocalAddr() }
func (c *Conn) RemoteAddr() net.Addr { return c.ws.RemoteAddr() }

func (c *Conn) SetDeadline(t time.Time) error {
	if err := c.SetReadDeadline(t); err != nil {
		return err
	}
	return c.SetWriteDeadline(t)
}

func (c *Conn) SetReadDeadline(t time.Time) error  { return c.ws.SetReadDeadline(t) }
func (c *Conn) SetWriteDeadline(t time.Time) error { return c.ws.SetWriteDeadline(t) }

// Compile-time conformance.
var _ net.Conn = (*Conn)(nil)
