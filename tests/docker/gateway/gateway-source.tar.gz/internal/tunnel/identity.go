package tunnel

import (
	"context"
	"time"
)

// This file mirrors the identity types fixed by docs/design.md so the
// gateway can be wired to internal/identity with a trivial adapter (or
// none, once the identity worker publishes its final API). The tunnel
// package must not import internal/identity: the coordinator combines
// both worktrees and adapts at the wiring site. See docs/tunnel.md for
// the ready-made adapter snippet.

// Principal is the verified human behind a client WebSocket. AccountID is
// the stable identity (issuer+subject verified by the identity package);
// Email is informational only and is never used for authorization.
// ExpiresAt is the verified credential's expiry: it bounds ADMISSION (the
// client may not be handed a stream after it passes). It does NOT end an
// established session — sessions are bounded separately and absolutely by
// Limits.MaxSessionDuration. There is no token re-authentication mid-session.
type Principal struct {
	AccountID string
	Email     string
	// ExpiresAt must be a positive time for admission: a zero expiry is
	// treated as "verifier did not propagate the token lifetime" and fails
	// closed, exactly like the identity package's own admission check.
	ExpiresAt time.Time
}

// AuthenticateFunc verifies a routing credential (the sync broker's
// short-lived scoped JWT; production wiring uses the shared routingauth
// verifier) and returns its Principal. Identical in shape to
// identity.Authenticate; convert between the two named types with a plain
// type conversion.
type AuthenticateFunc func(ctx context.Context, token string) (Principal, error)

// Device is an enrolled host. PublicKey is the raw 32-byte Ed25519 public
// key the device enrolled with; SSHHostKey is the pinned authorized_keys
// line of the host's real sshd; Revoked is the durable revocation flag.
type Device struct {
	ID         string
	AccountID  string
	PublicKey  []byte
	SSHHostKey string
	Revoked    bool
}

// DeviceStore is the read path the gateway needs. It matches
// identity.Store.GetDevice; because identity.Device is a distinct struct
// type, the coordinator wraps it with a ~10-line adapter (docs/tunnel.md).
type DeviceStore interface {
	GetDevice(id string) (Device, error)
}

// storeFunc adapts a plain function to DeviceStore.
type storeFunc func(id string) (Device, error)

func (f storeFunc) GetDevice(id string) (Device, error) { return f(id) }

// DeviceStoreFunc lets tests and adapters build a DeviceStore from a closure.
func DeviceStoreFunc(f func(id string) (Device, error)) DeviceStore { return storeFunc(f) }
