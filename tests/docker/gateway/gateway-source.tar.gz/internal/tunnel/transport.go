package tunnel

import (
	"time"

	"github.com/gorilla/websocket"
)

// Transport is the framed byte channel the Mux runs over. Implementations
// must be safe for one concurrent reader and one concurrent writer; the
// WebSocket adapter below serializes writes internally.
type Transport interface {
	ReadFrame() (Frame, error)
	WriteFrame(Frame) error
	// Close tears the underlying connection down (idempotent).
	Close() error
}

// WSWriter is the single serialization point for all writes on one
// WebSocket connection (finding A3): keepalive pings, JSON handshake
// frames and multiplexer data frames all funnel through one mutex, so no
// two goroutines ever call WriteMessage concurrently (gorilla requires a
// single writer). Every write is deadline-bounded.
type WSWriter struct {
	ws           *websocket.Conn
	mu           chan struct{}
	writeTimeout time.Duration
}

// NewWSWriter builds a serialized writer for a WebSocket connection. When
// a connection carries both multiplexer frames and control/JSON frames,
// use ONE writer for everything (see NewWSTransportWithWriter).
func NewWSWriter(ws *websocket.Conn, limits Limits) *WSWriter {
	return &WSWriter{
		ws:           ws,
		mu:           make(chan struct{}, 1),
		writeTimeout: limits.Resolved().WSWriteTimeout,
	}
}

// WriteMessage sends one message under the write lock.
func (w *WSWriter) WriteMessage(msgType int, data []byte) error {
	w.mu <- struct{}{}
	defer func() { <-w.mu }()
	_ = w.ws.SetWriteDeadline(time.Now().Add(w.writeTimeout))
	return w.ws.WriteMessage(msgType, data)
}

// wsTransport adapts a gorilla WebSocket to the Transport interface: one
// binary WebSocket message carries exactly one multiplexer frame. Reads
// belong to the Mux read loop; writes share the WSWriter lock.
type wsTransport struct {
	ws *websocket.Conn
	w  *WSWriter
}

// NewWSTransport builds the framed transport over a post-handshake
// WebSocket with its own serialized writer. When other code paths write
// to the same connection (pings, JSON), use NewWSTransportWithWriter with
// a single shared writer instead — two writers on one conn can interleave.
func NewWSTransport(ws *websocket.Conn, limits Limits) *wsTransport {
	return NewWSTransportWithWriter(ws, NewWSWriter(ws, limits), limits)
}

// NewWSTransportWithWriter builds the transport over an existing shared
// serialized writer (finding A3: keepalive and data paths must share one
// write lock per connection).
func NewWSTransportWithWriter(ws *websocket.Conn, w *WSWriter, limits Limits) *wsTransport {
	return &wsTransport{ws: ws, w: w}
}

// Writer exposes the serialized writer for control frames (pings) and
// handshake JSON on the same connection.
func (t *wsTransport) Writer() *WSWriter { return t.w }

func (t *wsTransport) ReadFrame() (Frame, error) {
	msgType, data, err := t.ws.ReadMessage()
	if err != nil {
		return Frame{}, err
	}
	if msgType != websocket.BinaryMessage {
		return Frame{}, ErrProtocol // JSON after handshake is a violation
	}
	return ParseFrame(data)
}

func (t *wsTransport) WriteFrame(f Frame) error {
	buf, err := AppendFrame(make([]byte, 0, frameHeaderLen+len(f.Payload)), f)
	if err != nil {
		return err
	}
	return t.w.WriteMessage(websocket.BinaryMessage, buf)
}

func (t *wsTransport) Close() error { return t.ws.Close() }
