package testtoolchain

import (
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

// Move the actual go executable to another prefix, sharing its read-only
// standard library/compiler tree. Poison PATH with a real executable that
// leaves a marker, then compile and run a real Go fixture with the chosen tool.
func TestGoRelocatedToolchainIgnoresPoisonPATH(t *testing.T) {
	if os.Getenv("POCKETSHELL_RELOCATED_CHILD") == "1" {
		fixture := os.Getenv("POCKETSHELL_FIXTURE_DIR")
		marker := os.Getenv("POCKETSHELL_POISON_MARKER")
		chosen := Go(t)
		if chosen != filepath.Join(runtime.GOROOT(), "bin", filepath.Base(Go(t))) {
			t.Fatalf("configured executable: got %q", chosen)
		}
		// Establish the negative control is real: PATH resolves the poisoned go,
		// executes it and records the marker, then remove that control marker.
		bad := exec.Command("go")
		if out, err := bad.CombinedOutput(); err == nil {
			t.Fatalf("poisoned PATH negative control unexpectedly succeeded: %s", out)
		}
		if _, err := os.Stat(marker); err != nil {
			t.Fatalf("poisoned PATH negative control did not execute: %v", err)
		}
		if err := os.Remove(marker); err != nil {
			t.Fatal(err)
		}
		writeFile(t, filepath.Join(fixture, "main.go"), "package main\nimport \"fmt\"\nfunc main() { fmt.Print(\"relocated fixture ran\") }\n")
		binary := filepath.Join(fixture, "fixture")
		if runtime.GOOS == "windows" {
			binary += ".exe"
		}
		build := exec.Command(chosen, "build", "-buildvcs=false", "-o", binary, ".")
		build.Dir = fixture
		if out, err := build.CombinedOutput(); err != nil {
			t.Fatalf("real relocated toolchain build: %v: %s", err, out)
		}
		if out, err := exec.Command(binary).CombinedOutput(); err != nil || string(out) != "relocated fixture ran" {
			t.Fatalf("real built fixture: %v: %q", err, out)
		}
		if _, err := os.Stat(marker); !os.IsNotExist(err) {
			t.Fatalf("fixture build used poisoned PATH tool: %v", err)
		}
		return
	}

	originalRoot := runtime.GOROOT()
	originalGo := Go(t)
	base := t.TempDir()
	root := filepath.Join(base, "relocated toolchain")
	if err := os.MkdirAll(filepath.Join(root, "bin"), 0755); err != nil {
		t.Fatal(err)
	}
	entries, err := os.ReadDir(originalRoot)
	if err != nil {
		t.Fatal(err)
	}
	for _, entry := range entries {
		if entry.Name() == "bin" {
			continue
		}
		if err := os.Symlink(filepath.Join(originalRoot, entry.Name()), filepath.Join(root, entry.Name())); err != nil {
			t.Fatal(err)
		}
	}
	goName := filepath.Base(originalGo)
	copyExecutable(t, originalGo, filepath.Join(root, "bin", goName))
	fixture := filepath.Join(base, "fixture")
	poison := filepath.Join(base, "poison")
	for _, path := range []string{fixture, poison} {
		if err := os.Mkdir(path, 0755); err != nil {
			t.Fatal(err)
		}
	}
	writeFile(t, filepath.Join(fixture, "go.mod"), "module fixture\n\ngo 1.18\n")
	marker := filepath.Join(base, "path-tool-used")
	writeFile(t, filepath.Join(fixture, "main.go"), fmt.Sprintf("package main\nimport \"os\"\nfunc main() { _ = os.WriteFile(%q, []byte(\"wrong tool\"), 0600); os.Exit(97) }\n", marker))
	build := exec.Command(originalGo, "build", "-buildvcs=false", "-o", filepath.Join(poison, goName), ".")
	build.Dir = fixture
	build.Env = append(os.Environ(), "CGO_ENABLED=0", "GOTOOLCHAIN=local", "GOPROXY=off")
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("build real poison executable: %v: %s", err, out)
	}
	child := exec.Command(os.Args[0], "-test.run=^TestGoRelocatedToolchainIgnoresPoisonPATH$", "-test.v")
	child.Env = append(os.Environ(), "GOROOT="+root, "PATH="+poison,
		"CGO_ENABLED=0", "GOTOOLCHAIN=local", "GOPROXY=off",
		"POCKETSHELL_RELOCATED_CHILD=1", "POCKETSHELL_FIXTURE_DIR="+fixture,
		"POCKETSHELL_POISON_MARKER="+marker)
	if out, err := child.CombinedOutput(); err != nil {
		t.Fatalf("real relocated-toolchain child: %v: %s", err, out)
	}
}

func TestGoMissingConfiguredToolchainFailsClosed(t *testing.T) {
	if os.Getenv("POCKETSHELL_TOOLCHAIN_CHILD") == "1" {
		Go(t)
		t.Fatal("unavailable configured toolchain unexpectedly accepted")
	}
	for _, root := range []string{filepath.Join(t.TempDir(), "missing"), "relative-toolchain"} {
		cmd := exec.Command(os.Args[0], "-test.run=^TestGoMissingConfiguredToolchainFailsClosed$")
		cmd.Env = append(os.Environ(), "GOROOT="+root, "POCKETSHELL_TOOLCHAIN_CHILD=1")
		out, err := cmd.CombinedOutput()
		if err == nil || !strings.Contains(string(out), "configured Go toolchain") {
			t.Fatalf("invalid GOROOT %q did not fail closed: %v: %s", root, err, out)
		}
	}
}

func copyExecutable(t *testing.T, source, target string) {
	t.Helper()
	in, err := os.Open(source)
	if err != nil {
		t.Fatal(err)
	}
	defer in.Close()
	out, err := os.OpenFile(target, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0755)
	if err != nil {
		t.Fatal(err)
	}
	_, copyErr := io.Copy(out, in)
	closeErr := out.Close()
	if copyErr != nil || closeErr != nil {
		t.Fatalf("copy real compiler executable: copy=%v close=%v", copyErr, closeErr)
	}
}

func writeFile(t *testing.T, path, content string) {
	t.Helper()
	if err := os.WriteFile(path, []byte(content), 0600); err != nil {
		t.Fatal(err)
	}
}
