// Package testtoolchain locates the Go toolchain running the test suite.
// Test fixture builds must use that configured toolchain, independently of PATH.
package testtoolchain

import (
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

// Go returns the absolute configured Go executable or fails the calling test.
// It never falls back to PATH or to a machine-specific installation prefix.
func Go(t testing.TB) string {
	t.Helper()
	root := runtime.GOROOT()
	if !filepath.IsAbs(root) {
		t.Fatalf("configured Go toolchain GOROOT must be absolute: %q", root)
	}
	name := "go"
	if runtime.GOOS == "windows" {
		name += ".exe"
	}
	path := filepath.Join(root, "bin", name)
	info, err := os.Stat(path)
	if err != nil || !info.Mode().IsRegular() {
		t.Fatalf("configured Go toolchain executable unavailable at %q: %v", path, err)
	}
	return path
}
