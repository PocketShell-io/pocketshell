// Package hostagent implements the PocketShell host-side agent: it holds a
// local Ed25519 device identity, enrolls with the gateway (signed
// challenge, pinned local SSH host key), maintains one persistent outbound
// WSS control connection, and bridges gateway-opened streams to a
// strictly loopback-only local SSH endpoint. It speaks no shell protocol
// of its own: the bytes it moves are opaque end-to-end SSH.
package hostagent

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)

const (
	keyFileName  = "device_ed25519.pem"
	confFileName = "config.json"
	// keyFileMode is the required identity key permissions; the loader
	// refuses keys that are group/world readable.
	keyFileMode os.FileMode = 0o600
)

// LoadOrCreateKey loads the device identity key from path, creating a new
// Ed25519 key (Unix 0600, protected Windows ACL) when none exists. Returns the key and whether it
// was freshly created.
func LoadOrCreateKey(path string) (ed25519.PrivateKey, bool, error) {
	if key, err := LoadKey(path); err == nil {
		return key, false, nil
	} else if !errors.Is(err, os.ErrNotExist) {
		return nil, false, err
	}
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, false, fmt.Errorf("generate key: %w", err)
	}
	if err := SaveKey(path, priv); err != nil {
		return nil, false, err
	}
	return priv, true, nil
}

// SaveKey atomically writes PKCS#8 PEM with platform-specific protection.
func SaveKey(path string, key ed25519.PrivateKey) error {
	der, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		return fmt.Errorf("marshal key: %w", err)
	}
	block := &pem.Block{Type: "PRIVATE KEY", Bytes: der}
	dir := filepath.Dir(path)
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	tmp, err := createProtectedTemp(dir)
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName)
	if err := pem.Encode(tmp, block); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	return os.Rename(tmpName, path)
}

// LoadKey reads a PKCS#8 PEM Ed25519 key after validating Unix permissions
// or the Windows ACL: a device identity is a bearer secret.
func LoadKey(path string) (ed25519.PrivateKey, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	if err := validateProtectedFile(f); err != nil {
		return nil, err
	}
	raw, err := io.ReadAll(f)
	if err != nil {
		return nil, err
	}
	block, _ := pem.Decode(raw)
	if block == nil || block.Type != "PRIVATE KEY" {
		return nil, errors.New("not a PKCS#8 PRIVATE KEY pem block")
	}
	parsed, err := x509.ParsePKCS8PrivateKey(block.Bytes)
	if err != nil {
		return nil, fmt.Errorf("parse key: %w", err)
	}
	key, ok := parsed.(ed25519.PrivateKey)
	if !ok {
		return nil, errors.New("device key is not Ed25519")
	}
	return key, nil
}

// PublicKeyBase64 returns the raw 32-byte public key, base64 (std) — the
// encoding enrolled as Device.PublicKey (see docs/tunnel.md).
func PublicKeyBase64(key ed25519.PrivateKey) string {
	pub, ok := key.Public().(ed25519.PublicKey)
	if !ok {
		return ""
	}
	return base64.StdEncoding.EncodeToString(pub)
}

// KeyFingerprint returns the SHA256 fingerprint of the raw public key,
// "SHA256:<base64 unpadded>" (same shape as ssh-keygen for SSH keys).
func KeyFingerprint(key ed25519.PrivateKey) string {
	pub, ok := key.Public().(ed25519.PublicKey)
	if !ok {
		return ""
	}
	sum := sha256.Sum256(pub)
	return "SHA256:" + base64.RawStdEncoding.EncodeToString(sum[:])
}

// SuggestDeviceID derives a stable-enough default device ID:
// "host-<sanitized hostname>-<6 random hex>".
func SuggestDeviceID() string {
	host, err := os.Hostname()
	if err != nil {
		host = "unknown"
	}
	host = strings.ToLower(host)
	host = strings.Map(func(r rune) rune {
		switch {
		case r >= 'a' && r <= 'z', r >= '0' && r <= '9', r == '-':
			return r
		default:
			return -1
		}
	}, host)
	host = strings.Trim(host, "-")
	if len(host) > 24 {
		host = host[:24]
	}
	if host == "" {
		host = "host"
	}
	suffix := make([]byte, 3)
	if _, err := rand.Read(suffix); err != nil {
		return "host-" + host
	}
	return fmt.Sprintf("host-%s-%s", host, strings.ToLower(base64.RawURLEncoding.EncodeToString(suffix)))
}
