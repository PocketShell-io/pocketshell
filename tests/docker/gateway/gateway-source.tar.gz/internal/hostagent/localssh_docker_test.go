package hostagent

// Real-OpenSSH multi-key enrollment proof (Docker).
//
// The in-process x/crypto servers in localssh_test.go exercise the client
// side of the negotiation, but x/crypto's own server cannot prove how REAL
// sshd presents a multi-key HostKey list, and no existing fixture does:
// the production e2e image configures exactly one Ed25519 host key and the
// old in-process lab server registers a single signer — both mask the
// multi-key mismatch this policy repairs.
//
// SCOPE OF THESE PROOFS (nomenclature): every client below is Go x/crypto
// SSH configured with the browser's advertised host-key algorithm list — a
// MIRRORED browser algorithm contract, not the npm `ssh2` library and not a
// production browser bundle. They qualify that the pinned key is the one a
// browser-algorithm client requests, on real OpenSSH; they do NOT prove the
// shipping browser shim/parser/signature path pairs with these fixtures.
// Actual packaged-browser multi-key interoperability is a separate root
// combined acceptance gate.
//
// These tests run real OpenSSH servers in throwaway containers with the
// ordinary host key types (Ed25519, ECDSA, RSA) in different HostKey
// orders and prove:
//   - the enrollment probe pins ssh-ed25519 regardless of the server's
//     HostKey order (client preference dominates real negotiation);
//   - a Go x/crypto client offering exactly the mirrored browser algorithm
//     list (read-only qualification of the browser contract; the real
//     browser bundle is another worker's scope) authenticates successfully
//     against the SAME key the probe pinned;
//   - an RSA-only server still pairs (rsa-sha2-512 is browser-supported);
//   - an ECDSA-only server fails honestly on both ends (no fallback);
//   - a wrong or case-toggled pinned fingerprint never reaches userauth;
//   - the probe produces ZERO userauth requests of ANY method (verified
//     from the server's own auth log via the all-methods
//     "userauth-request" marker, calibrated by a positive client
//     before any zero comparison).
//
// Isolation: test-owned image tag and container names (unique per run),
// ephemeral host ports bound to 127.0.0.1 only, keys/configs/logs mounted
// from t.TempDir, no privileged mode, no host networking, and no shared
// image is touched or replaced. Everything is cleaned up precisely.

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"fmt"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"testing"
	"time"

	"encoding/pem"

	"golang.org/x/crypto/ssh"
)

const (
	fixtureUser      = "probeuser"
	fixtureImageBase = "pocketshell-hostagent-hostkey-fixture"
)

var (
	fixtureImage  string // set by TestMain when the image was built
	fixtureWhyNot string // set when docker or the image build is unavailable
)

func TestMain(m *testing.M) {
	// The early-failure regression (localssh_probe_test.go) re-executes
	// this binary in a child role for a genuinely failing in-process test.
	// The child runs no Docker fixture: skipping the setup keeps its
	// failure purely the induced one (a docker hiccup must never
	// masquerade as the early failure, or as its absence).
	if os.Getenv(envProbeEarlyFailureChild) == "1" {
		os.Exit(m.Run())
	}
	if _, err := exec.LookPath("docker"); err != nil {
		fixtureWhyNot = "docker CLI not found"
	} else {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		if err := exec.CommandContext(ctx, "docker", "info", "--format", "ok").Run(); err != nil {
			fixtureWhyNot = "docker daemon unreachable"
		}
		cancel()
	}
	if fixtureWhyNot == "" {
		if err := buildFixtureImage(); err != nil {
			fixtureWhyNot = fmt.Sprintf("fixture image build failed: %v", err)
		}
	}
	code := m.Run()
	if fixtureImage != "" {
		// Remove only the image this run built (unique tag).
		_ = exec.Command("docker", "rmi", "-f", fixtureImage).Run()
	}
	os.Exit(code)
}

// buildFixtureImage builds a minimal sshd image under a test-owned,
// run-unique tag, derived from alpine:3.22 pinned by digest on public ECR
// (no Docker Hub pull limit). No existing shared image is reused, renamed
// or replaced.
func buildFixtureImage() error {
	ctx, err := os.MkdirTemp("", "pksh-hostkey-img-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(ctx)

	dockerfile := `FROM public.ecr.aws/docker/library/alpine@sha256:5291449c3df73caf6ed85e649dec1b9e818b39a5d8c871e97afc13e9cd5e8fa8
RUN apk add --no-cache openssh-server
COPY entrypoint.sh /entrypoint.sh
RUN chmod 0755 /entrypoint.sh
ENTRYPOINT ["/entrypoint.sh"]
`
	entrypoint := `#!/bin/sh
set -eu
adduser -D -s /bin/sh "$USER_NAME"
# adduser leaves the account locked ('!'), which refuses even pubkey
# auth; '*' keeps password auth impossible without locking the account.
sed -i "s|^$USER_NAME:!:|$USER_NAME:*:|" /etc/shadow
mkdir -p "/home/$USER_NAME/.ssh" /var/empty
echo "$USER_PUBKEY" > "/home/$USER_NAME/.ssh/authorized_keys"
chown -R "$USER_NAME" "/home/$USER_NAME/.ssh"
chmod 0700 "/home/$USER_NAME/.ssh"
chmod 0600 "/home/$USER_NAME/.ssh/authorized_keys"
exec /usr/sbin/sshd -D -e -f /config/sshd_config -E /logs/sshd.log
`
	if err := os.WriteFile(filepath.Join(ctx, "Dockerfile"), []byte(dockerfile), 0o644); err != nil {
		return err
	}
	if err := os.WriteFile(filepath.Join(ctx, "entrypoint.sh"), []byte(entrypoint), 0o644); err != nil {
		return err
	}
	suffix, err := randomHex(6)
	if err != nil {
		return err
	}
	fixtureImage = fixtureImageBase + ":" + suffix
	cmd := exec.Command("docker", "build", "-q", "-t", fixtureImage, ctx)
	out, err := cmd.CombinedOutput()
	if err != nil {
		fixtureImage = ""
		return fmt.Errorf("%v: %s", err, strings.TrimSpace(string(out)))
	}
	return nil
}

// fixtureMandatory reports whether the environment DEMANDS executed real
// fixtures: POCKETSHELL_HOSTKEY_FIXTURE=required turns every unavailable
// prerequisite into a hard failure instead of a skip, so an acceptance run
// can never pass while silently skipping the Docker scenarios.
func fixtureMandatory() bool {
	return os.Getenv("POCKETSHELL_HOSTKEY_FIXTURE") == "required"
}

func needDockerFixture(t *testing.T) {
	t.Helper()
	if fixtureWhyNot == "" {
		return
	}
	if fixtureMandatory() {
		t.Fatalf("real-OpenSSH fixture REQUIRED (POCKETSHELL_HOSTKEY_FIXTURE=required) but unavailable in this environment: %s", fixtureWhyNot)
	}
	t.Skipf("real-OpenSSH fixture unavailable in this environment: %s", fixtureWhyNot)
}

func randomHex(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return fmt.Sprintf("%x", b), nil
}

// fixtureKeys holds the raw host keys (for OpenSSH PEM export) and their
// ssh.Signers (for independent fingerprint/line computation).
type fixtureKeys struct {
	edPriv  ed25519.PrivateKey
	ed      ssh.Signer
	ecPriv  *ecdsa.PrivateKey
	ec      ssh.Signer
	rsaPriv *rsa.PrivateKey
	rsa     ssh.Signer
}

func generateFixtureKeys(t *testing.T) fixtureKeys {
	t.Helper()
	_, edPriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	ed, err := ssh.NewSignerFromKey(edPriv)
	if err != nil {
		t.Fatal(err)
	}
	ecPriv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	ec, err := ssh.NewSignerFromKey(ecPriv)
	if err != nil {
		t.Fatal(err)
	}
	rsaPriv, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	rsaSigner, err := ssh.NewSignerFromKey(rsaPriv)
	if err != nil {
		t.Fatal(err)
	}
	return fixtureKeys{edPriv: edPriv, ed: ed, ecPriv: ecPriv, ec: ec, rsaPriv: rsaPriv, rsa: rsaSigner}
}

func fixtureKeyNames() []string { return []string{"host_ed25519", "host_ecdsa", "host_rsa"} }

// startFixtureSSHD starts a real OpenSSH container presenting the given
// host keys in exactly the given HostKey order, plus one Ed25519 user key
// in the account's authorized_keys. Returns the loopback-bound host
// address, the sshd log path, the container name (for stopFixtureSSHD — the
// quiesce/join barrier of the full-log audit) and the accepted user signer.
func startFixtureSSHD(t *testing.T, keys fixtureKeys, scenario string, hostKeyOrder []string) (addr, logPath, cname string, userSigner ssh.Signer) {
	t.Helper()
	root := t.TempDir()
	keysDir := filepath.Join(root, "keys")
	cfgDir := filepath.Join(root, "config")
	logDir := filepath.Join(root, "logs")
	for _, d := range []string{keysDir, cfgDir, logDir} {
		if err := os.MkdirAll(d, 0o755); err != nil {
			t.Fatal(err)
		}
	}
	// sshd -E creates its log as root with mode 0600 INSIDE the bind mount,
	// which the host user then cannot read — the auth-log oracle would die
	// on os.ReadFile. Pre-create the file host-owned so sshd appends to it.
	// (The old zero-on-read-failure counter masked exactly this.)
	if err := os.WriteFile(filepath.Join(logDir, "sshd.log"), nil, 0o644); err != nil {
		t.Fatal(err)
	}
	pems := map[string][]byte{}
	for _, item := range []struct {
		name string
		key  interface{}
	}{{"host_ed25519", keys.edPriv}, {"host_ecdsa", keys.ecPriv}, {"host_rsa", keys.rsaPriv}} {
		block, err := ssh.MarshalPrivateKey(item.key, "hostkey-fixture")
		if err != nil {
			t.Fatal(err)
		}
		pems[item.name] = pem.EncodeToMemory(block)
		if err := os.WriteFile(filepath.Join(keysDir, item.name), pems[item.name], 0o600); err != nil {
			t.Fatal(err)
		}
	}
	var cfg strings.Builder
	cfg.WriteString("Port 22\n")
	// DEBUG1 (not VERBOSE): the all-methods userauth oracle needs sshd's
	// "debug1: userauth-request ... method <m> [preauth]" line, which
	// OpenSSH logs ONLY at debug level — VERBOSE emits acceptance/failure
	// outcomes ("Accepted/Failed publickey") but no per-request line, so a
	// none-auth attempt would be invisible. The container and its log are
	// throwaway test fixtures.
	cfg.WriteString("LogLevel DEBUG1\n")
	cfg.WriteString("StrictModes yes\n")
	cfg.WriteString("PermitRootLogin no\n")
	cfg.WriteString("PasswordAuthentication no\n")
	cfg.WriteString("KbdInteractiveAuthentication no\n")
	cfg.WriteString("PubkeyAuthentication yes\n")
	cfg.WriteString("PidFile /tmp/sshd.pid\n")
	for _, hk := range hostKeyOrder {
		if _, ok := pems[hk]; !ok {
			t.Fatalf("HostKey %q has no generated key", hk)
		}
		cfg.WriteString("HostKey /keys/" + hk + "\n")
	}
	if err := os.WriteFile(filepath.Join(cfgDir, "sshd_config"), []byte(cfg.String()), 0o644); err != nil {
		t.Fatal(err)
	}

	_, userPriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	userSigner, err = ssh.NewSignerFromKey(userPriv)
	if err != nil {
		t.Fatal(err)
	}
	userPub := strings.TrimSpace(string(ssh.MarshalAuthorizedKey(userSigner.PublicKey())))

	suffix, err := randomHex(4)
	if err != nil {
		t.Fatal(err)
	}
	cname = fmt.Sprintf("%s-%s-%s", fixtureImageBase, scenario, suffix)
	run := exec.Command("docker", "run", "-d",
		"--name", cname,
		"-p", "127.0.0.1::22",
		"-v", keysDir+":/keys:ro",
		"-v", cfgDir+":/config:ro",
		"-v", logDir+":/logs",
		"-e", "USER_NAME="+fixtureUser,
		"-e", "USER_PUBKEY="+userPub,
		fixtureImage,
	)
	out, err := run.CombinedOutput()
	if err != nil {
		t.Fatalf("docker run %s: %v\n%s", cname, err, out)
	}
	t.Cleanup(func() { _ = exec.Command("docker", "rm", "-f", cname).Run() })

	portOut, err := exec.Command("docker", "port", cname, "22").CombinedOutput()
	if err != nil {
		t.Fatalf("docker port %s: %v\n%s", cname, err, portOut)
	}
	port := ""
	for _, line := range strings.Fields(string(portOut)) {
		if strings.Contains(line, "127.0.0.1:") {
			port = strings.TrimPrefix(line, "127.0.0.1:")
		}
	}
	if port == "" {
		t.Fatalf("no 127.0.0.1 port mapping for %s: %s", cname, portOut)
	}
	addr = net.JoinHostPort("127.0.0.1", port)

	// Wait for the real sshd banner before handing the address out.
	deadline := time.Now().Add(30 * time.Second)
	for {
		if time.Now().After(deadline) {
			logs, _ := exec.Command("docker", "logs", cname).CombinedOutput()
			t.Fatalf("sshd in %s never became ready on %s\ncontainer log:\n%s", cname, addr, logs)
		}
		banner, err := readSSHBanner(addr, 2*time.Second)
		if err == nil && strings.HasPrefix(banner, "SSH-2.0-OpenSSH") {
			break
		}
		time.Sleep(250 * time.Millisecond)
	}
	return addr, filepath.Join(logDir, "sshd.log"), cname, userSigner
}

// stopFixtureSSHD quiesces the isolated fixture: docker stop SIGTERMs sshd
// and WAITS for the process to exit, so the bind-mounted log can gain no
// further lines — sshd is joined, every write it ever made is final. This
// is the completion barrier for a zero-userauth claim: auditing the log
// only after this point means a delayed userauth request (landing after the
// client returned) is necessarily inside the audit and cannot escape it;
// the aggregate comparison then decides whether anything unaccounted
// landed.
func stopFixtureSSHD(t *testing.T, cname string) {
	t.Helper()
	out, err := exec.Command("docker", "stop", "-t", "15", cname).CombinedOutput()
	if err != nil {
		t.Fatalf("docker stop %s (fixture quiesce): %v\n%s", cname, err, out)
	}
}

// userauthRequestMethods extracts, in log order, the method name of every
// "userauth-request" line in the sshd log (DEBUG1 carries one line per
// userauth request of ANY method). A userauth-request line whose method
// cannot be parsed is a broken oracle, not an ignorable line.
//
// Evidence boundary, stated explicitly: the parser records ONLY the method.
// sshd's pinned DEBUG1 format carries no connection ID or PID on
// userauth-request lines, so per-connection origin is NOT extractable from
// this log. Every audit built on this parser is therefore an AGGREGATE
// accounted-footprint comparison; attribution to a specific connection
// rests on test-window isolation (strictly sequential connections, flush
// barriers before snapshots, quiesce before the final read), never on
// origin fields parsed from the log.
func userauthRequestMethods(t *testing.T, data string) []string {
	t.Helper()
	var methods []string
	for _, line := range strings.Split(data, "\n") {
		if !strings.Contains(line, "userauth-request") {
			continue
		}
		i := strings.Index(line, " method ")
		if i < 0 {
			t.Fatalf("unparseable sshd userauth-request line (no method field): %q", line)
		}
		rest := line[i+len(" method "):]
		if j := strings.IndexAny(rest, " ["); j >= 0 {
			rest = rest[:j]
		}
		if rest == "" {
			t.Fatalf("unparseable sshd userauth-request line (empty method): %q", line)
		}
		methods = append(methods, rest)
	}
	return methods
}

// compareUserauthAccounting is the pure audit core: every observed
// userauth-request method must be accounted within the given footprint with
// an exact count — anything beyond the accounted footprint (for example a
// delayed none that landed after the client returned) is a violation.
// Error-returning so the delayed-event oracle regressions can assert
// failures deterministically without Fatal control flow. Note: this is a
// pure aggregate comparison over method names — it sees no timestamps,
// origins or ordering guarantees of its own; those come from how tests
// capture and quiesce the log around it.
func compareUserauthAccounting(methods []string, accounted map[string]int) error {
	got := map[string]int{}
	for _, m := range methods {
		got[m]++
	}
	var extra []string
	for m, n := range got {
		want, ok := accounted[m]
		if !ok || n > want {
			extra = append(extra, fmt.Sprintf("%s x%d (accounted: %d)", m, n, want))
		}
	}
	if len(extra) > 0 {
		sort.Strings(extra)
		return fmt.Errorf("unaccounted userauth requests of ANY method reached the server: %v", extra)
	}
	var missing []string
	for m, want := range accounted {
		if got[m] < want {
			missing = append(missing, fmt.Sprintf("%s x%d (observed: %d)", m, want, got[m]))
		}
	}
	if len(missing) > 0 {
		sort.Strings(missing)
		return fmt.Errorf("accounted userauth requests missing from the log: %v", missing)
	}
	return nil
}

// positiveClientAccounting is the known userauth-request footprint of n
// browser-contract (Go x/crypto, mirrored browser list) pubkey clients: each
// first attempts none, then a publickey offer and its signed retry.
func positiveClientAccounting(n int) map[string]int {
	return map[string]int{"none": n, "publickey": 2 * n}
}

// auditFixtureUserauth reads the COMPLETE sshd log — called only after
// stopFixtureSSHD, when sshd has exited and no further write is possible —
// and fails the test unless every userauth request of every method in the
// whole log is accounted. A log read failure is a broken oracle, never a
// zero.
func auditFixtureUserauth(t *testing.T, logPath string, accounted map[string]int) {
	t.Helper()
	data, err := os.ReadFile(logPath)
	if err != nil {
		t.Fatalf("read sshd log %s (full-log audit): %v", logPath, err)
	}
	if err := compareUserauthAccounting(userauthRequestMethods(t, string(data)), accounted); err != nil {
		t.Fatalf("full-log userauth audit after fixture quiesce: %v\nlog:\n%s", err, strings.TrimSpace(string(data)))
	}
}

// readSSHBanner dials once and reads the server version string.
func readSSHBanner(addr string, timeout time.Duration) (string, error) {
	conn, err := net.DialTimeout("tcp", addr, timeout)
	if err != nil {
		return "", err
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(timeout))
	buf := make([]byte, 64)
	n, err := conn.Read(buf)
	if err != nil && n == 0 {
		return "", err
	}
	return strings.TrimSpace(string(buf[:n])), nil
}

// countLinesContaining counts sshd log lines containing marker. A log read
// failure is a BROKEN ORACLE, not a zero: it fails the test so a missing or
// unreadable log can never launder a zero-userauth claim.
func countLinesContaining(t *testing.T, logPath, marker string) int {
	t.Helper()
	data, err := os.ReadFile(logPath)
	if err != nil {
		t.Fatalf("read sshd log %s (marker %q): %v", logPath, marker, err)
	}
	return countMarker(string(data), marker)
}

// waitForLogMarker polls the sshd log until marker appears at least once,
// failing the test at the deadline. It is the calibration + completion
// barrier for every zero comparison: a positive event (typically the
// baseline client's successful authentication) must be PRESENT and flushed
// before any "nothing new appeared" claim is checked, and the returned
// count proves the log was readable. With LogLevel DEBUG1 the fixture log
// carries "debug1: userauth-request ... method <m> [preauth]" for EVERY
// userauth request of ANY method (marker "userauth-request"), so that
// marker observes all authentication, not only publickey outcomes.
func waitForLogMarker(t *testing.T, logPath, marker string, timeout time.Duration) int {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for {
		if _, err := os.Stat(logPath); err == nil {
			if data, readErr := os.ReadFile(logPath); readErr == nil {
				if n := countMarker(string(data), marker); n > 0 {
					return n
				}
			}
		}
		if time.Now().After(deadline) {
			data, _ := os.ReadFile(logPath)
			t.Fatalf("marker %q never appeared in %s within %s — the auth-log oracle is not calibrated\nlog:\n%s",
				marker, logPath, timeout, strings.TrimSpace(string(data)))
		}
		time.Sleep(200 * time.Millisecond)
	}
}

// countMarker is the pure counting core shared by countLinesContaining.
func countMarker(data, marker string) int {
	n := 0
	for _, line := range strings.Split(data, "\n") {
		if strings.Contains(line, marker) {
			n++
		}
	}
	return n
}

// browserContractDial dials addr as a Go x/crypto SSH client offering
// EXACTLY the mirrored browser host-key algorithm list — it is NOT the npm
// `ssh2` library and NOT a production browser bundle (packaged-browser
// multi-key interoperability is a separate root combined gate). It verifies
// the presented host key through verify (the independently provisioned
// pin), authenticates with pubkey and runs `echo`. It returns the presented
// key so tests can assert WHICH of the offered host keys was selected.
func browserContractDial(t *testing.T, addr string, userKey ssh.Signer, verify func(ssh.PublicKey) error) (presented ssh.PublicKey, echoOut string, err error) {
	t.Helper()
	cfg := &ssh.ClientConfig{
		User:              fixtureUser,
		Auth:              []ssh.AuthMethod{ssh.PublicKeys(userKey)},
		HostKeyAlgorithms: BrowserHostKeyAlgorithms(),
		HostKeyCallback: func(_ string, _ net.Addr, key ssh.PublicKey) error {
			presented = key
			return verify(key)
		},
		Timeout: 10 * time.Second,
	}
	client, err := ssh.Dial("tcp", addr, cfg)
	if err != nil {
		return presented, "", err
	}
	defer client.Close()
	sess, err := client.NewSession()
	if err != nil {
		return presented, "", err
	}
	defer sess.Close()
	out, err := sess.CombinedOutput("echo browser-contract-ok")
	return presented, strings.TrimSpace(string(out)), err
}

func exactKeyPin(want ssh.PublicKey) func(ssh.PublicKey) error {
	return func(key ssh.PublicKey) error {
		if bytes.Equal(key.Marshal(), want.Marshal()) {
			return nil
		}
		return fmt.Errorf("host key pin mismatch: presented %s %s", key.Type(), ssh.FingerprintSHA256(key))
	}
}

func exactFingerprintPin(fp string) func(ssh.PublicKey) error {
	return func(key ssh.PublicKey) error {
		if ssh.FingerprintSHA256(key) == strings.TrimSpace(fp) {
			return nil
		}
		return fmt.Errorf("host key fingerprint pin mismatch: presented %s", ssh.FingerprintSHA256(key))
	}
}

// TestDockerOpenSSHMultiKeyPinsBrowserRequestedKey: real sshd offering
// Ed25519 + ECDSA + RSA (HostKey order Ed, ECDSA, RSA). The probe must pin
// ssh-ed25519 — the key a browser-contract client then requests and
// authenticates with.
func TestDockerOpenSSHMultiKeyPinsBrowserRequestedKey(t *testing.T) {
	needDockerFixture(t)
	keys := generateFixtureKeys(t)
	addr, _, _, userKey := startFixtureSSHD(t, keys, "multi", fixtureKeyNames())

	info, err := ProbeSSHHostKey(context.Background(), addr)
	if err != nil {
		t.Fatalf("probe real multi-key OpenSSH: %v", err)
	}
	if info.Algorithm != ssh.KeyAlgoED25519 {
		t.Fatalf("probe pinned %s on a real multi-key sshd; want ssh-ed25519", info.Algorithm)
	}
	if want := ssh.FingerprintSHA256(keys.ed.PublicKey()); info.Fingerprint != want {
		t.Fatalf("pinned fingerprint %q, want the independently computed Ed25519 %q", info.Fingerprint, want)
	}

	presented, out, err := browserContractDial(t, addr, userKey, exactKeyPin(keys.ed.PublicKey()))
	if err != nil {
		t.Fatalf("browser-contract SSH client against the pinned key: %v", err)
	}
	if out != "browser-contract-ok" {
		t.Fatalf("exec output %q", out)
	}
	if presented.Type() != ssh.KeyAlgoED25519 || ssh.FingerprintSHA256(presented) != info.Fingerprint {
		t.Fatalf("client presented %s %s; the probe pinned %s %s",
			presented.Type(), ssh.FingerprintSHA256(presented), info.Algorithm, info.Fingerprint)
	}
}

// TestDockerOpenSSHReverseOrderStillPinsEd25519: same three keys, HostKey
// order reversed (RSA, ECDSA, Ed25519). Real servers still present by
// CLIENT preference — the probe must keep pinning Ed25519.
func TestDockerOpenSSHReverseOrderStillPinsEd25519(t *testing.T) {
	needDockerFixture(t)
	keys := generateFixtureKeys(t)
	addr, _, _, userKey := startFixtureSSHD(t, keys, "reverse", []string{"host_rsa", "host_ecdsa", "host_ed25519"})

	info, err := ProbeSSHHostKey(context.Background(), addr)
	if err != nil {
		t.Fatalf("probe real reverse-order sshd: %v", err)
	}
	if info.Algorithm != ssh.KeyAlgoED25519 {
		t.Fatalf("probe pinned %s in reverse HostKey order; client preference must dominate, want ssh-ed25519", info.Algorithm)
	}
	if want := ssh.FingerprintSHA256(keys.ed.PublicKey()); info.Fingerprint != want {
		t.Fatalf("pinned fingerprint %q, want %q", info.Fingerprint, want)
	}
	if _, out, err := browserContractDial(t, addr, userKey, exactKeyPin(keys.ed.PublicKey())); err != nil || out != "browser-contract-ok" {
		t.Fatalf("browser-contract client on reverse-order sshd: out=%q err=%v", out, err)
	}
}

// TestDockerOpenSSHRSAOnlyPairsBrowserCompatible: an RSA-only sshd pairs
// positively — the browser contract supports rsa-sha2-512/256/ssh-rsa —
// and the pinned line is the ssh-rsa key blob.
func TestDockerOpenSSHRSAOnlyPairsBrowserCompatible(t *testing.T) {
	needDockerFixture(t)
	keys := generateFixtureKeys(t)
	addr, _, _, userKey := startFixtureSSHD(t, keys, "rsaonly", []string{"host_rsa"})

	info, err := ProbeSSHHostKey(context.Background(), addr)
	if err != nil {
		t.Fatalf("probe real RSA-only OpenSSH: %v", err)
	}
	if info.Algorithm != ssh.KeyAlgoRSA {
		t.Fatalf("algorithm %q, want %q", info.Algorithm, ssh.KeyAlgoRSA)
	}
	if want := ssh.FingerprintSHA256(keys.rsa.PublicKey()); info.Fingerprint != want {
		t.Fatalf("pinned fingerprint %q, want the RSA key's %q", info.Fingerprint, want)
	}
	presented, out, err := browserContractDial(t, addr, userKey, exactKeyPin(keys.rsa.PublicKey()))
	if err != nil {
		t.Fatalf("browser-contract client against RSA-only sshd: %v", err)
	}
	if out != "browser-contract-ok" {
		t.Fatalf("exec output %q", out)
	}
	if ssh.FingerprintSHA256(presented) != info.Fingerprint {
		t.Fatalf("client presented %s, probe pinned %s", ssh.FingerprintSHA256(presented), info.Fingerprint)
	}
}

// TestDockerOpenSSHECDSAOnlyFailsHonestly: a server offering ONLY ECDSA
// cannot be paired — the probe fails naming the policy, and a
// browser-contract client cannot complete a handshake either. No fallback,
// no silent pin of an unverifiable key.
func TestDockerOpenSSHECDSAOnlyFailsHonestly(t *testing.T) {
	needDockerFixture(t)
	keys := generateFixtureKeys(t)
	addr, _, _, userKey := startFixtureSSHD(t, keys, "ecdsaonly", []string{"host_ecdsa"})

	info, err := ProbeSSHHostKey(context.Background(), addr)
	if err == nil {
		t.Fatalf("ECDSA-only sshd must fail the probe; got %+v", info)
	}
	if !strings.Contains(err.Error(), "offers none of the enrollment host key algorithms") {
		t.Fatalf("probe error does not name the honest failure:\n%v", err)
	}
	_, _, err = browserContractDial(t, addr, userKey, func(ssh.PublicKey) error { return nil })
	if err == nil {
		t.Fatal("browser-contract client connected to an ECDSA-only sshd; it offers no ECDSA host algorithm")
	}
	if !strings.Contains(err.Error(), "host key") {
		t.Fatalf("client error is not a host-key negotiation failure:\n%v", err)
	}
}

// TestDockerOpenSSHWrongOrToggledPinNeverReachesUserAuth: with the correct
// pin a browser-contract (Go x/crypto, mirrored browser algorithm list)
// client authenticates; with a DIFFERENT VALID key pinned, or a
// CASE-TOGGLED digest of the right one, the client refuses in the host-key
// check. The server's own log is used as a CALIBRATED oracle: the positive
// baseline's "Accepted publickey" line must be present before any zero
// comparison (a missing log fails, never passes as zero), the all-methods
// "userauth-request" marker counts userauth of ANY method (the fixture
// logs at DEBUG1 for exactly this), a second positive connection after the
// negatives proves the log was still flowing, and the FULL-LOG all-methods
// audit runs only after the fixture is QUIESCED (docker stop joined sshd's
// exit) — so a delayed userauth request from a refused connection, landing
// after the client returned, is necessarily inside the audited log and
// cannot escape the comparison the way a client-return snapshot would
// allow. The later positive is itself accounted in the audit; it is never
// the refused connection's completion proof.
func TestDockerOpenSSHWrongOrToggledPinNeverReachesUserAuth(t *testing.T) {
	needDockerFixture(t)
	keys := generateFixtureKeys(t)
	addr, logPath, cname, userKey := startFixtureSSHD(t, keys, "pinneg", fixtureKeyNames())

	info, err := ProbeSSHHostKey(context.Background(), addr)
	if err != nil || info.Algorithm != ssh.KeyAlgoED25519 {
		t.Fatalf("probe: info=%+v err=%v", info, err)
	}
	presented, out, err := browserContractDial(t, addr, userKey, exactKeyPin(keys.ed.PublicKey()))
	if err != nil || out != "browser-contract-ok" {
		t.Fatalf("baseline positive client failed: out=%q err=%v", out, err)
	}
	if presented == nil || presented.Type() != ssh.KeyAlgoED25519 {
		t.Fatalf("positive client presented %v", presented)
	}

	// Calibration (flush barrier): the baseline's successful authentication
	// must actually be in the log before any zero comparison, and VERBOSE
	// logging must have recorded its userauth requests. Missing/lagging
	// logs fail here instead of silently comparing zeros.
	if acceptedCal := waitForLogMarker(t, logPath, "Accepted publickey", 30*time.Second); acceptedCal < 1 {
		t.Fatalf("positive baseline produced %d 'Accepted publickey' lines; auth-log oracle not calibrated", acceptedCal)
	}
	waitForLogMarker(t, logPath, "userauth-request", 30*time.Second)

	// Snapshot AFTER calibration: any new userauth line of ANY method after
	// this point means a refused client still reached user authentication.
	authBefore := countLinesContaining(t, logPath, "userauth-request")
	acceptedBefore := countLinesContaining(t, logPath, "Accepted publickey")
	failedBefore := countLinesContaining(t, logPath, "Failed publickey")

	other := generateFixtureKeys(t)
	toggled := "SHA256:" + toggleFirstBase64Letter(strings.TrimPrefix(info.Fingerprint, "SHA256:"))
	negatives := []struct {
		name   string
		verify func(ssh.PublicKey) error
	}{
		{"different valid key pinned", exactKeyPin(other.ed.PublicKey())},
		{"case-toggled fingerprint pinned", exactFingerprintPin(toggled)},
	}
	for _, tc := range negatives {
		t.Run(tc.name, func(t *testing.T) {
			presented, out, err := browserContractDial(t, addr, userKey, tc.verify)
			if err == nil {
				t.Fatalf("client accepted a %s pin (presented %s %s, exec %q)",
					tc.name, presented.Type(), ssh.FingerprintSHA256(presented), out)
			}
			if !strings.Contains(err.Error(), "pin mismatch") {
				t.Fatalf("connection failed for the wrong reason:\n%v", err)
			}
		})
	}

	// The userauth count is read immediately after the refused clients
	// return: a client that reached userauth would have its requests logged
	// synchronously before its connection ended. This is only the FIRST,
	// weaker half of the proof — the complete all-methods audit runs after
	// the quiesce barrier below.
	authAfterNegatives := countLinesContaining(t, logPath, "userauth-request")
	if authAfterNegatives != authBefore {
		t.Fatalf("%d userauth requests of ANY method after pin-refused connections (before: %d, after: %d) — refused pins must not reach userauth",
			authAfterNegatives-authBefore, authBefore, authAfterNegatives)
	}

	// Flush barrier AFTER the negatives: a fresh positive connection must
	// be logged (its Accepted line raises the count), proving the log kept
	// flowing across the whole negative window. This liveness positive is
	// accounted for in the final audit; it is deliberately NOT the refused
	// connections' completion proof.
	presented, out, err = browserContractDial(t, addr, userKey, exactKeyPin(keys.ed.PublicKey()))
	if err != nil || out != "browser-contract-ok" {
		t.Fatalf("post-negative positive client failed: out=%q err=%v", out, err)
	}
	deadline := time.Now().Add(30 * time.Second)
	for countLinesContaining(t, logPath, "Accepted publickey") <= acceptedBefore {
		if time.Now().After(deadline) {
			t.Fatalf("post-negative flush barrier timed out: no new 'Accepted publickey' within 30s")
		}
		time.Sleep(200 * time.Millisecond)
	}

	// Completion/quiesce barrier: stop the fixture — docker stop SIGTERMs
	// sshd and waits for its exit, so the log is final. No write the
	// refused connections (or anything else) ever made can appear after
	// this point.
	stopFixtureSSHD(t, cname)

	// FULL-LOG all-methods audit over the complete, now-final log: exactly
	// two accounted positive pubkey clients (baseline + liveness), each
	// contributing its known none/publickey requests. ANY other userauth
	// request of ANY method — including a none that a refused connection
	// logged late — fails here. Rechecked AFTER the genuine completion
	// barrier, not vouched for by the later positive client.
	auditFixtureUserauth(t, logPath, positiveClientAccounting(2))

	if got := countLinesContaining(t, logPath, "Accepted publickey"); got != acceptedBefore+1 {
		t.Fatalf("unexpected acceptance delta after negative window (before: %d, after: %d)", acceptedBefore, got)
	}
	if got := countLinesContaining(t, logPath, "Failed publickey"); got != failedBefore {
		t.Fatalf("%d publickey userauth failures after pin-refused connections (before: %d) — refused pins must not reach userauth", got-failedBefore, failedBefore)
	}
}

// TestDockerOpenSSHProbeNeverAuthenticates: the probe must produce ZERO
// userauth requests of ANY method on real OpenSSH — not merely zero
// accepted publickey lines. The oracle is calibrated first: a positive
// browser-contract (Go x/crypto, mirrored browser algorithm list) client
// authenticates, its "Accepted publickey" line and its
// "userauth-request" lines must appear (log readable, per-request auth
// logging live at the fixture's DEBUG1 level), and only then are snapshots
// compared. A second positive connection after the probe proves the log
// kept flowing; it is accounted for in the final audit and is NOT the
// probe connection's completion proof. The ALL-METHODS verdict is instead
// re-checked after the fixture is QUIESCED (docker stop joined sshd's
// exit): auditing the complete, final log means a delayed userauth request
// — landing after the probe client returned — is necessarily inside the
// audit.
func TestDockerOpenSSHProbeNeverAuthenticates(t *testing.T) {
	needDockerFixture(t)
	keys := generateFixtureKeys(t)
	addr, logPath, cname, userKey := startFixtureSSHD(t, keys, "keyless", fixtureKeyNames())

	// Calibration: the positive baseline must authenticate and be logged.
	if _, out, err := browserContractDial(t, addr, userKey, exactKeyPin(keys.ed.PublicKey())); err != nil || out != "browser-contract-ok" {
		t.Fatalf("calibration positive client failed: out=%q err=%v", out, err)
	}
	if acceptedCal := waitForLogMarker(t, logPath, "Accepted publickey", 30*time.Second); acceptedCal < 1 {
		t.Fatalf("positive baseline produced %d 'Accepted publickey' lines; auth-log oracle not calibrated", acceptedCal)
	}
	waitForLogMarker(t, logPath, "userauth-request", 30*time.Second)

	authBefore := countLinesContaining(t, logPath, "userauth-request")
	acceptedBefore := countLinesContaining(t, logPath, "Accepted publickey")
	failedBefore := countLinesContaining(t, logPath, "Failed publickey")

	info, err := ProbeSSHHostKey(context.Background(), addr)
	if err != nil {
		t.Fatalf("probe: %v", err)
	}
	if info.Algorithm != ssh.KeyAlgoED25519 {
		t.Fatalf("probe pinned %s; want ssh-ed25519", info.Algorithm)
	}
	// The userauth count is read immediately when the probe returns: sshd
	// logs a userauth request synchronously while processing it (before any
	// reply the probe would have waited for). This is only the FIRST,
	// weaker half of the proof — the complete all-methods audit runs after
	// the quiesce barrier below.
	authAfterProbe := countLinesContaining(t, logPath, "userauth-request")
	if authAfterProbe != authBefore {
		t.Fatalf("probe produced %d userauth requests of ANY method (before: %d, after: %d); it must stay handshake-only",
			authAfterProbe-authBefore, authBefore, authAfterProbe)
	}

	// Flush barrier: a fresh positive connection must be logged after the
	// probe, proving the log kept flowing while the probe was observed.
	// This liveness positive is accounted for in the final audit; it is
	// deliberately NOT the probe connection's completion proof.
	if _, out, err := browserContractDial(t, addr, userKey, exactKeyPin(keys.ed.PublicKey())); err != nil || out != "browser-contract-ok" {
		t.Fatalf("post-probe positive client failed: out=%q err=%v", out, err)
	}
	deadline := time.Now().Add(30 * time.Second)
	for countLinesContaining(t, logPath, "Accepted publickey") <= acceptedBefore {
		if time.Now().After(deadline) {
			t.Fatalf("post-probe flush barrier timed out: no new 'Accepted publickey' within 30s")
		}
		time.Sleep(200 * time.Millisecond)
	}

	// Completion/quiesce barrier: stop the fixture — docker stop SIGTERMs
	// sshd and waits for its exit, so the log is final. No write the probe
	// connection (or anything else) ever made can appear after this point.
	stopFixtureSSHD(t, cname)

	// FULL-LOG all-methods audit over the complete, now-final log: exactly
	// two accounted positive pubkey clients (calibration + liveness), each
	// contributing its known none/publickey requests. ANY other userauth
	// request of ANY method — including a none the probe connection logged
	// late — fails here. Rechecked AFTER the genuine completion barrier.
	auditFixtureUserauth(t, logPath, positiveClientAccounting(2))

	if got := countLinesContaining(t, logPath, "Accepted publickey"); got != acceptedBefore+1 {
		t.Fatalf("unexpected acceptance delta around the probe (before: %d, after: %d)", acceptedBefore, got)
	}
	if got := countLinesContaining(t, logPath, "Failed publickey"); got != failedBefore {
		t.Fatalf("probe produced %d publickey userauth failures (before: %d, after: %d)", got-failedBefore, failedBefore, got)
	}
}

// TestFixtureUserauthAuditCatchesDelayedNone is ARITHMETIC COVERAGE of the
// audit core (deterministic, no fixture): method-name arrays are fed
// straight to compareUserauthAccounting, proving the exact-count comparison
// rejects one added "none" event, any unaccounted method, and missing
// accounted traffic, while exactly-accounted traffic passes. By itself it
// exercises NO delayed log write, NO sshd log parser, NO quiesce-barrier
// placement and NO request origin — removing the final audit from the live
// tests would not make this pure test fail. The end-to-end delayed-event
// proof through a real OpenSSH producer, the production parser and the
// post-quiesce full-log read is
// TestDockerFinalLogAuditRejectsDelayedNoneFromRealSSHD.
func TestFixtureUserauthAuditCatchesDelayedNone(t *testing.T) {
	accounted := positiveClientAccounting(1) // none x1, publickey x2

	// Exactly the accounted traffic passes.
	if err := compareUserauthAccounting([]string{"none", "publickey", "publickey"}, accounted); err != nil {
		t.Fatalf("audit rejected exactly-accounted traffic: %v", err)
	}

	// One delayed none after client return — the shape of a delayed
	// "userauth-request ... method none [preauth]" line in the quiesced
	// log — must fail.
	delayed := []string{"none", "publickey", "publickey", "none"}
	err := compareUserauthAccounting(delayed, accounted)
	if err == nil {
		t.Fatal("audit accepted a delayed none userauth request that arrived after the client returned — the all-methods barrier is vacuous")
	}
	if !strings.Contains(err.Error(), "none") {
		t.Fatalf("audit failure does not name the delayed none method: %v", err)
	}

	// Any other unaccounted method is likewise a violation (all-methods
	// audit, not a none-only check).
	err = compareUserauthAccounting([]string{"none", "publickey", "publickey", "keyboard-interactive"}, accounted)
	if err == nil {
		t.Fatal("audit accepted an unaccounted non-none userauth method")
	}

	// Missing accounted traffic is a violation too (the calibration lines
	// must really be present, never assumed).
	if err := compareUserauthAccounting([]string{"publickey", "publickey"}, accounted); err == nil {
		t.Fatal("audit accepted missing accounted none traffic")
	}
}

// TestDockerFinalLogAuditRejectsDelayedNoneFromRealSSHD is the delayed-event
// calibration through the REAL log pipeline: a controlled local OpenSSH
// producer writes the log, and the production parser (userauthRequestMethods)
// and audit core (compareUserauthAccounting) judge the COMPLETE file read
// after the quiesce barrier — not in-memory arrays. Sequence: one accounted
// positive client is flushed, the parsed initial footprint must pass the
// audit against the known accounting (initial excess zero), then exactly ONE
// owned extra none-userauth attempt is produced — a keyless x/crypto client
// carrying the mirrored browser host-key list making a normal auth-negative
// against this disposable loopback fixture (one connection, one request,
// nothing external) — the fixture is quiesced (docker stop joined sshd, so
// no further write is possible), and the final full-log audit must REJECT
// the excess the initial snapshot could not see. The produced event is
// proven present in the final log first, so the rejection is substantive,
// and the initial clean audit proves the guard both ways on real sshd
// lines.
//
// Evidence boundary (deliberate, not silently stronger): sshd's DEBUG1
// userauth-request lines carry no connection/PID/peer marker, so this is
// AGGREGATE quiescent accounted-footprint evidence. Attribution of the
// excess to the produced attempt rests on test-window isolation — the
// positive is flushed before the initial snapshot, the keyless client is
// the only connection in the tested window, and the quiesce rules out any
// later write — not on per-connection origin fields the log does not
// contain.
func TestDockerFinalLogAuditRejectsDelayedNoneFromRealSSHD(t *testing.T) {
	needDockerFixture(t)
	keys := generateFixtureKeys(t)
	addr, logPath, cname, userKey := startFixtureSSHD(t, keys, "delayednone", fixtureKeyNames())

	accounted := positiveClientAccounting(1) // known footprint: none x1, publickey x2

	// One accounted positive client, flushed into the log before the
	// initial capture.
	if _, out, err := browserContractDial(t, addr, userKey, exactKeyPin(keys.ed.PublicKey())); err != nil || out != "browser-contract-ok" {
		t.Fatalf("accounted positive client failed: out=%q err=%v", out, err)
	}
	if acceptedCal := waitForLogMarker(t, logPath, "Accepted publickey", 30*time.Second); acceptedCal < 1 {
		t.Fatalf("positive client produced %d 'Accepted publickey' lines; auth-log oracle not calibrated", acceptedCal)
	}

	// INITIAL capture through the production parser + audit core: the real
	// producer's footprint must match the known accounting exactly — the
	// initial excess is zero, and parser and real log format are proven to
	// agree (a format drift fails here, never silently).
	data, err := os.ReadFile(logPath)
	if err != nil {
		t.Fatalf("read sshd log %s (initial): %v", logPath, err)
	}
	initial := userauthRequestMethods(t, string(data))
	if err := compareUserauthAccounting(initial, accounted); err != nil {
		t.Fatalf("initial full-log audit rejected the accounted positive client (parser and real producer disagree):\n%v\nmethods: %v", err, initial)
	}
	t.Logf("initial accounted footprint (%d events): %v", len(initial), initial)

	// Produce exactly ONE owned extra none-userauth attempt: a keyless
	// x/crypto client (mirrored browser host-key list) against this
	// disposable loopback fixture. A normal auth-negative — sshd refuses
	// the none request and the client fails honestly; the request line it
	// leaves is the parseable delayed event under test.
	keyless := &ssh.ClientConfig{
		User:              fixtureUser,
		HostKeyAlgorithms: BrowserHostKeyAlgorithms(),
		HostKeyCallback: func(_ string, _ net.Addr, key ssh.PublicKey) error {
			return exactKeyPin(keys.ed.PublicKey())(key)
		},
		Timeout: 10 * time.Second,
	}
	if client, dialErr := ssh.Dial("tcp", addr, keyless); dialErr == nil {
		client.Close()
		t.Fatal("keyless client authenticated; the fixture must refuse none authentication for this calibration")
	}

	// Quiesce barrier: docker stop SIGTERMs sshd and waits for its exit —
	// the log is final; the produced event and every earlier write are
	// inside the audited file and nothing can appear after this point.
	stopFixtureSSHD(t, cname)

	// FINAL audit through the same parser + audit core on the complete,
	// now-final log. First prove the produced event really landed (an
	// absent event would make the rejection vacuous), then require the
	// audit to reject the excess despite the clean initial snapshot.
	data, err = os.ReadFile(logPath)
	if err != nil {
		t.Fatalf("read sshd log %s (final): %v", logPath, err)
	}
	final := userauthRequestMethods(t, string(data))
	noneCount := 0
	for _, m := range final {
		if m == "none" {
			noneCount++
		}
	}
	if noneCount != 2 {
		t.Fatalf("final log carries %d none requests, want exactly the accounted one plus the produced one; the calibration producer did not land its event\nmethods: %v", noneCount, final)
	}
	t.Logf("final quiesced footprint (%d events): %v", len(final), final)
	if auditErr := compareUserauthAccounting(final, accounted); auditErr == nil {
		t.Fatal("final full-log audit accepted a REAL extra none userauth request produced after the initial clean snapshot — the quiesced audit does not catch delayed events")
	} else if !strings.Contains(auditErr.Error(), "none") {
		t.Fatalf("audit failure does not name the delayed none request: %v", auditErr)
	}
}
