package hostagent

import (
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"
)

// craftJWT builds a JWT-shaped credential. The local guard does NOT verify
// signatures (the gateway does that); it validates the claimed shape, so a
// dummy signature is enough to reach the claim checks.
func craftJWT(t *testing.T, header, claims map[string]any) string {
	t.Helper()
	h, err := json.Marshal(header)
	if err != nil {
		t.Fatal(err)
	}
	c, err := json.Marshal(claims)
	if err != nil {
		t.Fatal(err)
	}
	enc := base64.RawURLEncoding.EncodeToString
	return enc(h) + "." + enc(c) + "." + enc([]byte("not-a-real-signature"))
}

func mustJWT(t *testing.T, header, claims map[string]any) string { return craftJWT(t, header, claims) }

func TestValidateBrokerCredential(t *testing.T) {
	now := time.Now()
	valid := mustJWT(t,
		map[string]any{"alg": "RS256", "kid": "broker-key-1"},
		map[string]any{
			"iss": ProductionBrokerIssuer, "aud": BrokerAudience,
			"scope": BrokerScope, "exp": now.Add(4 * time.Minute).Unix(), "iat": now.Unix(),
		})
	google := mustJWT(t,
		map[string]any{"alg": "RS256", "kid": "google-key"},
		map[string]any{
			"iss": "https://accounts.google.com", "aud": "pocketshell-sync.apps.googleusercontent.com",
			"email_verified": true, "exp": now.Add(time.Hour).Unix(), "iat": now.Unix(),
		})

	cases := []struct {
		name    string
		token   string
		wantErr bool
	}{
		{"valid broker token", valid, false},
		{"empty", "", true},
		{"not a jwt", "some-random-credential", true},
		{"google id token", google, true},
		{"google issuer case-insensitive", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": "https://Accounts.Google.com", "aud": "x", "scope": BrokerScope,
				"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()}), true},
		{"alg none", mustJWT(t,
			map[string]any{"alg": "none"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": BrokerScope,
				"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()}), true},
		{"wrong issuer", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": "https://evil.example", "aud": BrokerAudience, "scope": BrokerScope,
				"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()}), true},
		{"broker issuer with trailing slash", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer + "/", "aud": BrokerAudience, "scope": BrokerScope,
				"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()}), true},
		{"wrong audience", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": "other-service", "scope": BrokerScope,
				"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()}), true},
		{"audience array", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": []string{BrokerAudience, "x"}, "scope": BrokerScope,
				"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()}), true},
		{"missing scope", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience,
				"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()}), true},
		{"wrong scope", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": "pocketshell.sync",
				"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()}), true},
		{"string exp", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": BrokerScope,
				"exp": "soon", "iat": now.Unix()}), true},
		{"missing iat", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": BrokerScope,
				"exp": now.Add(time.Minute).Unix()}), true},
		{"lifetime 1h", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": BrokerScope,
				"exp": now.Add(time.Hour).Unix(), "iat": now.Unix()}), true},
		{"lifetime 9m", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": BrokerScope,
				"exp": now.Add(9 * time.Minute).Unix(), "iat": now.Unix()}), true},
		{"expired", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": BrokerScope,
				"exp": now.Add(-time.Minute).Unix(), "iat": now.Add(-5 * time.Minute).Unix()}), true},
		{"5m lifetime ok", mustJWT(t,
			map[string]any{"alg": "RS256"},
			map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": BrokerScope,
				"exp": now.Add(5 * time.Minute).Unix(), "iat": now.Unix()}), false},
	}
	policy := ProductionBrokerPolicy()
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			err := ValidateBrokerCredential(tc.token, policy, now)
			if tc.wantErr && err == nil {
				t.Fatal("credential accepted, want refusal")
			}
			if !tc.wantErr && err != nil {
				t.Fatalf("credential refused: %v", err)
			}
		})
	}

	// The Google refusal must name the problem: a user piping their Google
	// token must be told why nothing was sent.
	err := ValidateBrokerCredential(google, policy, now)
	if err == nil || !containsFold(err.Error(), "GOOGLE") {
		t.Fatalf("google refusal does not explain itself: %v", err)
	}
}

func containsFold(s, sub string) bool {
	if len(sub) == 0 {
		return true
	}
	n := len(s)
	m := len(sub)
	if m > n {
		return false
	}
	for i := 0; i+m <= n; i++ {
		if equalFoldASCII(s[i:i+m], sub) {
			return true
		}
	}
	return false
}

func equalFoldASCII(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := 0; i < len(a); i++ {
		ca, cb := a[i], b[i]
		if 'A' <= ca && ca <= 'Z' {
			ca += 'a' - 'A'
		}
		if 'A' <= cb && cb <= 'Z' {
			cb += 'a' - 'A'
		}
		if ca != cb {
			return false
		}
	}
	return true
}

// TestHostCLINeverSendsGoogleToken (F-09): piping a Google ID token into
// the CLI enroll flow must be refused LOCALLY — the recorder captures ZERO
// HTTP requests, so the credential with sync authority never leaves the
// machine. Same for any other non-broker credential shape.
func TestHostCLINeverSendsGoogleToken(t *testing.T) {
	var requests atomic.Int64
	recorder := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		http.Error(w, "the CLI must not contact anything", http.StatusInternalServerError)
	}))
	t.Cleanup(recorder.Close)

	now := time.Now()
	google := mustJWT(t,
		map[string]any{"alg": "RS256", "kid": "google-key"},
		map[string]any{
			"iss": "https://accounts.google.com", "aud": "pocketshell-sync.apps.googleusercontent.com",
			"email_verified": true, "exp": now.Add(time.Hour).Unix(), "iat": now.Unix(),
		})
	wrongScope := mustJWT(t,
		map[string]any{"alg": "RS256"},
		map[string]any{"iss": ProductionBrokerIssuer, "aud": BrokerAudience, "scope": "pocketshell.sync",
			"exp": now.Add(time.Minute).Unix(), "iat": now.Unix()})

	dir := t.TempDir()
	for _, tc := range []struct {
		name  string
		token string
	}{
		{"google id token", google},
		{"broker-shaped but wrong scope", wrongScope},
		{"garbage", "not a jwt at all"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			_, err := RunEnroll(t.Context(), EnrollOptions{
				Dir:         dir,
				Server:      "http://" + hostOf(recorder.URL),
				Token:       tc.token,
				SSHHost:     "127.0.0.1:22",
				InsecureDev: true,
			})
			if err == nil {
				t.Fatal("enroll accepted a credential it must refuse")
			}
			if n := requests.Load(); n != 0 {
				t.Fatalf("%d HTTP requests left the machine before the refusal", n)
			}
		})
	}
}

func hostOf(url string) string {
	for i := 0; i < len(url); i++ {
		if url[i] == '/' && i+2 < len(url) && url[i+1] == '/' {
			rest := url[i+2:]
			for j := 0; j < len(rest); j++ {
				if rest[j] == '/' {
					return rest[:j]
				}
			}
			return rest
		}
	}
	return url
}

// TestDevBrokerIssuerRequiresInsecureDev: the lab-issuer override is only
// reachable in insecure-dev mode; production can never be pointed at a
// look-alike issuer.
func TestDevBrokerIssuerRequiresInsecureDev(t *testing.T) {
	_, err := EnrollOptions{BrokerIssuer: "https://lab.example", InsecureDev: false}.brokerPolicy()
	if err == nil {
		t.Fatal("dev issuer override accepted without --insecure-dev")
	}
	policy, err := EnrollOptions{BrokerIssuer: "https://lab.example", InsecureDev: true}.brokerPolicy()
	if err != nil {
		t.Fatalf("dev issuer override refused in dev mode: %v", err)
	}
	if policy.Issuer != "https://lab.example" {
		t.Fatalf("policy issuer %q", policy.Issuer)
	}
	def, err := EnrollOptions{}.brokerPolicy()
	if err != nil || def.Issuer != ProductionBrokerIssuer {
		t.Fatalf("default policy %v err %v", def, err)
	}
}
