package hostagent

// Run-handshake VALIDATION-FIELD withholding (run-peer-fields-final): the
// peer-controlled strings left after the ErrMsg/close repair — the
// handshake reply type and the challenge type/server/role/protocol — are
// still refused exactly as before, but their values never render anymore.
// The old renderings exposed every byte (%q escapes controls without
// withholding; the shared ToIdentityChallenge error inlines Role/Protocol
// with %s, controls and forged lines included), so a misbehaving configured
// gateway could echo the enrollment bearer it saw during real enrollment
// back into the reconnect warnings through any of them. The boundary now
// returns fixed local diagnostics (plus the safe numeric version where one
// exists), and the refusal semantics are unchanged: validation failures
// stay transient (bounded reconnect), never fatal.

import (
	"context"
	"errors"
	"log/slog"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// validChallengeForTest builds a challenge that passes validateChallenge;
// each case below corrupts exactly one field with peer-controlled payload.
func validChallengeForTest(t *testing.T) tunnel.HostChallenge {
	t.Helper()
	nonce, err := randomNonceForTest(32)
	if err != nil {
		t.Fatal(err)
	}
	connNonce, err := randomNonceForTest(32)
	if err != nil {
		t.Fatal(err)
	}
	return tunnel.HostChallenge{
		Type: "challenge", V: tunnel.ProtocolVersion,
		ChallengeID: "gw-field-test",
		Nonce:       nonce, ConnectionNonce: connNonce,
		Server: "127.0.0.1", Role: identity.RoleHost,
		Protocol:  tunnel.ProtocolTunnel,
		ExpiresAt: time.Now().Add(time.Minute).Unix(),
	}
}

// TestValidateChallengeWithholdsPeerFields pins the boundary phrases
// EXACTLY: a corrupted field value — reflected bearer, terminal controls,
// forged lines — must produce the fixed local diagnostic and nothing else.
// Exact equality is the pin: any peer byte surviving the render would break
// it.
func TestValidateChallengeWithholdsPeerFields(t *testing.T) {
	fixtureBearerShapes(t)
	const rolePhrase = "challenge: peer role/protocol/nonce fields failed local validation (peer values withheld)"
	const serverPhrase = "challenge: peer server name does not match the configured server"

	cases := []struct {
		name  string
		cor   func(ch *tunnel.HostChallenge)
		want  string // exact error text
		token string // reflected credential that must not appear ("" = control payload only)
	}{
		{
			name:  "challenge type carries the short bearer",
			cor:   func(ch *tunnel.HostChallenge) { ch.Type = shortReflectedBearer },
			want:  "unexpected challenge: peer type withheld (v=" + strconv.Itoa(tunnel.ProtocolVersion) + ")",
			token: shortReflectedBearer,
		},
		{
			name: "challenge type correct but version wrong",
			cor:  func(ch *tunnel.HostChallenge) { ch.V = tunnel.ProtocolVersion + 1 },
			want: "unexpected challenge: peer type withheld (v=" + strconv.Itoa(tunnel.ProtocolVersion+1) + ")",
		},
		{
			name:  "role carries the short bearer",
			cor:   func(ch *tunnel.HostChallenge) { ch.Role = shortReflectedBearer },
			want:  rolePhrase,
			token: shortReflectedBearer,
		},
		{
			name:  "protocol carries the long bearer",
			cor:   func(ch *tunnel.HostChallenge) { ch.Protocol = longReflectedBearer },
			want:  rolePhrase,
			token: longReflectedBearer,
		},
		{
			name: "role carries terminal controls and forged lines",
			cor:  func(ch *tunnel.HostChallenge) { ch.Role = hostileJSONReason },
			want: rolePhrase,
		},
		{
			name:  "server carries the long bearer",
			cor:   func(ch *tunnel.HostChallenge) { ch.Server = longReflectedBearer },
			want:  serverPhrase,
			token: longReflectedBearer,
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			ch := validChallengeForTest(t)
			tc.cor(&ch)
			err := validateChallenge(&ch, "127.0.0.1")
			if err == nil {
				t.Fatal("validateChallenge accepted a corrupted challenge")
			}
			if err.Error() != tc.want {
				t.Fatalf("error %q, want exactly %q", err.Error(), tc.want)
			}
			assertTerminalSafe(t, err.Error(), false)
			if tc.token != "" {
				assertBearerWithheld(t, err.Error(), tc.token)
			}
			for _, frag := range []string{"FORGED", "pwned", "evil"} {
				if strings.Contains(err.Error(), frag) {
					t.Fatalf("hostile payload fragment %q survived: %q", frag, err.Error())
				}
			}
		})
	}
}

// TestAgentValidationRejectionsStayTransientWithheld drives the full Run
// loop against a gateway that reflects peer-controlled payload through each
// remaining validation field: a crafted challenge (type / server / role /
// protocol) at the pre-challenge stage and a crafted handshake reply after
// the signed proof. Every variant must stay TRANSIENT (bounded reconnect,
// never a fatal exit) and the reconnect warnings must carry the fixed local
// phrase only — no reflected credential, no hostile fragment.
func TestAgentValidationRejectionsStayTransientWithheld(t *testing.T) {
	fixtureBearerShapes(t)
	key := newAgentKey(t)

	shortCh := validChallengeForTest(t)
	shortCh.Type = shortReflectedBearer
	longCh := validChallengeForTest(t)
	longCh.Server = longReflectedBearer
	roleCh := validChallengeForTest(t)
	roleCh.Role = shortReflectedBearer
	roleCtlCh := validChallengeForTest(t)
	roleCtlCh.Role = hostileJSONReason
	protoCh := validChallengeForTest(t)
	protoCh.Protocol = longReflectedBearer

	cases := []struct {
		name       string
		mode       hostileRejectMode
		frame      []byte // raw first frame: crafted challenge, or (post-proof) crafted reply
		wantPhrase string
		token      string // reflected credential that must not appear ("" = control payload only)
	}{
		{
			name:       "challenge type",
			mode:       rejectBeforeChallenge,
			frame:      mustJSONForTest(shortCh),
			wantPhrase: "unexpected challenge: peer type withheld",
			token:      shortReflectedBearer,
		},
		{
			name:       "challenge server mismatch",
			mode:       rejectBeforeChallenge,
			frame:      mustJSONForTest(longCh),
			wantPhrase: "challenge: peer server name does not match the configured server",
			token:      longReflectedBearer,
		},
		{
			name:       "challenge role mismatch",
			mode:       rejectBeforeChallenge,
			frame:      mustJSONForTest(roleCh),
			wantPhrase: "challenge: peer role/protocol/nonce fields failed local validation (peer values withheld)",
			token:      shortReflectedBearer,
		},
		{
			name:       "challenge protocol mismatch",
			mode:       rejectBeforeChallenge,
			frame:      mustJSONForTest(protoCh),
			wantPhrase: "challenge: peer role/protocol/nonce fields failed local validation (peer values withheld)",
			token:      longReflectedBearer,
		},
		{
			name:       "role control payload",
			mode:       rejectBeforeChallenge,
			frame:      mustJSONForTest(roleCtlCh),
			wantPhrase: "challenge: peer role/protocol/nonce fields failed local validation (peer values withheld)",
		},
		{
			name:       "handshake reply type",
			mode:       rejectAfterProof,
			frame:      mustJSONForTest(tunnel.OKMsg{Type: shortReflectedBearer, V: tunnel.ProtocolVersion}),
			wantPhrase: "unexpected handshake reply: peer reply type withheld",
			token:      shortReflectedBearer,
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			// The crafted frame rides the same raw text-frame channel the
			// hostile gateway already serves: as the very first frame
			// (pre-challenge) or right after verifying the agent's signed
			// auth (post-proof).
			gw := startHostileGateway(t, tc.mode, "dev-agent-test", key, tc.frame, 0, "")
			ssh := localEcho(t)
			lw := &lockedWriter{}
			agent := NewAgent(AgentConfig{
				ServerURL: gw.url,
				DeviceID:  "dev-agent-test",
				Key:       key,
				SSHHost:   ssh,
				Limits:    agentLimits(),
				Logger:    slog.New(slog.NewTextHandler(lw, nil)),
			})

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			runErr := make(chan error, 1)
			go func() { runErr <- agent.Run(ctx) }()

			// Two connections prove the rejection stayed transient; a fatal
			// classification would have exited on the first.
			gw.connectionsWithin(t, 2, 10*time.Second)
			select {
			case err := <-runErr:
				t.Fatalf("Run exited on a validation rejection: %v", err)
			default:
			}

			log := lw.String()
			if !strings.Contains(log, "reconnecting") {
				t.Fatalf("reconnect diagnostics missing from the run log: %s", cutForTest(log))
			}
			if !strings.Contains(log, tc.wantPhrase) {
				t.Fatalf("run log lacks the fixed local phrase %q: %s", tc.wantPhrase, cutForTest(log))
			}
			assertTerminalSafe(t, log, true) // the local formatter owns the newlines
			if tc.token != "" {
				assertBearerWithheld(t, log, tc.token)
			}
			for _, frag := range []string{"FORGED", "pwned", "evil"} {
				if strings.Contains(log, frag) {
					t.Fatalf("hostile payload fragment %q survived in the run log: %s", frag, cutForTest(log))
				}
			}

			cancel()
			select {
			case err := <-runErr:
				if !errors.Is(err, context.Canceled) {
					t.Fatalf("Run returned %v after cancel, want context.Canceled", err)
				}
			case <-time.After(3 * time.Second):
				t.Fatal("Run did not return after cancel")
			}
		})
	}
}
