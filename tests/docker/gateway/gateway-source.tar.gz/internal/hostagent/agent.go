package hostagent

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"math/rand/v2"
	"net"
	"net/url"
	"strconv"
	"time"

	"github.com/gorilla/websocket"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// Agent defaults for the session loop.
const (
	defaultHandshakeTimeout = 10 * time.Second
	defaultLocalDialTimeout = 5 * time.Second
	backoffBase             = time.Second
	backoffMax              = 30 * time.Second
	backoffResetAfter       = 5 * time.Minute // a session this stable resets the backoff
)

// agentPath is the control endpoint on the gateway.
const agentPath = tunnel.PathAgentConnect

// errFatalAuth marks close codes that will not heal by reconnecting: the
// device is unknown, revoked, or its key/signature is wrong. Run surfaces
// it instead of looping. The reason is rendered verbatim into CLI stderr,
// so classify only ever stores bytes this process produced here: the
// canonical verdict literal for the matched code and a fixed withholding
// phrase — never raw close reasons or ErrMsg messages (run-credential-
// output-final; same policy as the enroll path's postJSON).
type errFatalAuth struct {
	code   int
	reason string
}

func (e *errFatalAuth) Error() string {
	return fmt.Sprintf("gateway rejected this device (close %d): %s", e.code, e.reason)
}

// errPeerRejected is a gateway rejection delivered as a JSON error frame
// (ErrMsg) instead of a WebSocket close code (FH-1). Both shapes carry the
// same verdicts; classify maps the terminal ones to errFatalAuth and lets
// the transient ones (quota, timeout, protocol) go through the bounded
// reconnect path.
//
// Only the wire code is retained: it is classification input, matched
// against canonical literals before anything renders. The frame's message
// field is peer-controlled free text — a misbehaving configured gateway or
// on-path proxy saw the enrollment request's Authorization bearer and can
// echo it back through this field, wholly, cut to any length, or
// re-encoded, and no practical redaction covers every partial or reversible
// encoding of a credential the agent does not even store — so the message
// is dropped at the acceptance boundary and never enters any error string,
// log line or CLI output (run-credential-output-final; the enroll path
// made the same call in the F2 repair).
type errPeerRejected struct {
	code string // raw wire ErrMsg code; classification input only, never rendered raw
}

func (e *errPeerRejected) Error() string {
	// Only a canonical code literal reaches the output; an unrecognized
	// (possibly hostile) code is described by a fixed local phrase, and the
	// peer message is always withheld.
	if canon := canonicalErrCode(e.code); canon != "" {
		return fmt.Sprintf("gateway error frame %q (peer message withheld)", canon)
	}
	return "gateway error frame: peer code and message withheld"
}

// canonicalErrCode reports the canonical spelling of a recognized ErrMsg
// verdict code — exactly the literals tunnel.Service emits — or "" for
// anything else. It is the RENDERING gate for peer codes: matched literals
// may be named, everything else is described by a fixed phrase.
func canonicalErrCode(code string) string {
	switch code {
	case "challenge", "host_offline", "not_found", "protocol", "quota",
		"revoked", "signature", "timeout", "unauthorized":
		return code
	}
	return ""
}

// canonicalCloseName maps the fatal application close codes to the verdict
// names the gateway pairs them with (tunnel.Service's reject pairings), so
// the close-frame route surfaces the same verdict spelling as the ErrMsg
// route.
func canonicalCloseName(code int) string {
	switch code {
	case tunnel.CloseUnauth:
		return "unauthorized"
	case tunnel.CloseForbidden:
		return "revoked"
	case tunnel.CloseNotFound:
		return "not_found"
	}
	return ""
}

// errTransientClose is a peer close frame without a terminal verdict. The
// wire reason is peer-controlled text (the same credential-echo channel as
// an ErrMsg message), so it is never rendered; the numeric close code is
// the local, safe diagnostic and the classification stays transient.
type errTransientClose struct {
	code int
}

func (e *errTransientClose) Error() string {
	return fmt.Sprintf("gateway closed the connection (close %d): peer close reason withheld", e.code)
}

// handshakeStage distinguishes the two points where the gateway can deliver
// a verdict during the agent handshake. The stage matters for exactly one
// wire code: "challenge" (FH-1 correction).
//
// Before the challenge exists (stageChallenge), the real service emits
// code "challenge" only for CHALLENGE-CAPACITY EXHAUSTION, paired with the
// TRANSIENT close code CloseTimeout ("challenge capacity reached"). After
// the signed proof (stageAck), code "challenge" is the terminal redeem
// failure, paired with CloseUnauth ("challenge invalid or expired").
// Classifying the pre-proof variant as fatal permanently exited the agent
// on a temporary condition.
type handshakeStage int

const (
	stageChallenge handshakeStage = iota // awaiting the server challenge
	stageAck                             // awaiting the ok ack (post-proof)
)

// fatalCloseCode maps a wire ErrMsg code to the WebSocket close code the
// gateway pairs it with, so fatal rejections surface identically however
// they were observed. False = transient (bounded reconnect applies). The
// "challenge" mapping here is the post-proof pairing; the pre-proof
// capacity variant is handled stage-aware in classify.
func fatalCloseCode(errCode string) (int, bool) {
	switch errCode {
	case "revoked":
		return tunnel.CloseForbidden, true
	case "signature", "challenge", "unauthorized":
		return tunnel.CloseUnauth, true
	case "not_found":
		return tunnel.CloseNotFound, true
	default: // quota, timeout, protocol, internal, unknown: transient
		return 0, false
	}
}

// AgentConfig configures an Agent.
type AgentConfig struct {
	// ServerURL is the gateway control URL, ws:// or wss:// (use
	// NormalizeServerURL; plain schemes require dev mode upstream).
	ServerURL string
	DeviceID  string
	Key       ed25519.PrivateKey
	// SSHHost is the loopback-only SSH endpoint (already validated; the
	// agent validates again on every dial — defense in depth).
	SSHHost string
	// Limits tunes the multiplexer (frame sizes, windows); zero = defaults.
	Limits tunnel.Limits
	Logger *slog.Logger
	// HandshakeTimeout / LocalDialTimeout override defaults (tests).
	HandshakeTimeout time.Duration
	LocalDialTimeout time.Duration
	// Dialer overrides the WebSocket dialer (tests inject ws:// to an
	// httptest server). TLS verification is never disabled.
	Dialer *websocket.Dialer
	// Now overrides the clock (tests).
	Now func() time.Time
}

// Agent maintains the persistent reverse connection: dial, challenge-auth,
// accept gateway-opened streams, dial loopback SSH, bridge bytes, and
// reconnect with bounded, jittered backoff until the context is canceled.
type Agent struct {
	cfg  AgentConfig
	log  *slog.Logger
	host string // hostname for challenge binding
}

func NewAgent(cfg AgentConfig) *Agent {
	log := cfg.Logger
	if log == nil {
		log = slog.Default()
	}
	ht := cfg.HandshakeTimeout
	if ht <= 0 {
		ht = defaultHandshakeTimeout
	}
	ld := cfg.LocalDialTimeout
	if ld <= 0 {
		ld = defaultLocalDialTimeout
	}
	// F-11: production callers never set Now; a nil clock would panic on
	// the first Run iteration. Default to the real clock here so the zero
	// configuration is runnable.
	if cfg.Now == nil {
		cfg.Now = time.Now
	}
	cfg.HandshakeTimeout = ht
	cfg.LocalDialTimeout = ld
	host := ""
	if u, err := url.Parse(cfg.ServerURL); err == nil {
		if h, _, err := net.SplitHostPort(u.Host); err == nil {
			host = h
		} else {
			host = u.Host
		}
	}
	return &Agent{cfg: cfg, log: log, host: host}
}

// Run serves sessions until ctx is canceled or an unrecoverable auth
// rejection happens. Reconnects are bounded: exponential backoff with
// jitter from 1s to 30s, reset after a stable session.
func (a *Agent) Run(ctx context.Context) error {
	backoff := backoffBase
	for {
		start := a.cfg.Now()
		if start.IsZero() {
			start = time.Now()
		}
		err := a.session(ctx)
		if ctx.Err() != nil {
			return ctx.Err()
		}
		var fatal *errFatalAuth
		if errors.As(err, &fatal) {
			// Terminal rejection: reconnecting cannot fix an unknown or
			// revoked device (or a bad key). Surface it; never loop.
			a.log.Error("tunnel: gateway rejected this device; giving up", "err", fatal)
			return fatal
		}
		a.log.Warn("tunnel session ended; reconnecting", "err", err)

		elapsed := time.Since(start)
		if elapsed >= backoffResetAfter {
			backoff = backoffBase
		}
		if err := sleepJitter(ctx, backoff); err != nil {
			return err
		}
		backoff *= 2
		if backoff > backoffMax {
			backoff = backoffMax
		}
	}
}

func sleepJitter(ctx context.Context, d time.Duration) error {
	// ±25% jitter, not a secret: math/rand is fine.
	j := d/4 + time.Duration(rand.Int64N(int64(d/2)+1))
	t := time.NewTimer(d - d/4 + j)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-t.C:
		return nil
	}
}

// session runs one control connection to completion.
func (a *Agent) session(ctx context.Context) error {
	u, err := url.Parse(a.cfg.ServerURL)
	if err != nil {
		return fmt.Errorf("server url: %w", err)
	}
	u.Path = agentPath
	u.RawQuery = ""

	dialer := a.cfg.Dialer
	if dialer == nil {
		// Default dialer: TLS verification stays on; there is deliberately
		// no certificate-skip option anywhere in this package.
		dialer = &websocket.Dialer{
			HandshakeTimeout: a.cfg.HandshakeTimeout,
		}
	}
	ws, resp, err := dialer.DialContext(ctx, u.String(), nil)
	if err != nil {
		if resp != nil {
			return fmt.Errorf("dial %s: HTTP %d", u.Host, resp.StatusCode)
		}
		return fmt.Errorf("dial %s: %w", u.Host, err)
	}
	defer ws.Close()
	ws.SetReadLimit(int64(a.cfg.Limits.Resolved().MaxFramePayload + tunnel.FrameOverhead + 4096))

	// 1. Server challenge. A rejection ErrMsg can arrive instead of the
	// challenge (e.g. capacity or a revoked device at the pre-challenge
	// stage); readHandshakeMsg surfaces it for classification instead of
	// losing the code in a type mismatch (FH-1).
	_ = ws.SetReadDeadline(time.Now().Add(a.cfg.HandshakeTimeout))
	var ch tunnel.HostChallenge
	if err := readHandshakeMsg(ws, &ch); err != nil {
		return a.classify(err, stageChallenge)
	}
	if err := validateChallenge(&ch, a.host); err != nil {
		return err
	}

	// 2. Sign and answer over the canonical identity.Challenge transcript
	// (shared with enrollment — no local transcript format). The signature
	// covers the nonce, connection nonce, device ID, role, protocol,
	// server name and expiry; replay to another server, role or connection
	// fails verification.
	challenge, err := ch.ToIdentityChallenge(a.cfg.DeviceID)
	if err != nil {
		// validateChallenge already ran the identical structural checks, so
		// this is unreachable for any challenge that passed them — but the
		// shared renderer embeds the peer's Role/Protocol verbatim, so the
		// boundary still refuses to carry that text and returns the fixed
		// local phrase instead.
		return errors.New("challenge: peer fields failed local validation (peer values withheld)")
	}
	sig, err := identity.Sign(a.cfg.Key, challenge)
	if err != nil {
		return fmt.Errorf("sign challenge: %w", err)
	}
	if err := writeJSONMsg(ws, tunnel.HostAuth{
		Type: "auth", V: tunnel.ProtocolVersion,
		DeviceID: a.cfg.DeviceID, Signature: base64Std(sig),
		// Announce our receive window so the gateway can pick a symmetric
		// per-stream window that both muxes enforce (FH-2).
		StreamWindow: a.cfg.Limits.Resolved().StreamWindow,
	}); err != nil {
		return fmt.Errorf("send auth: %w", err)
	}

	// 3. Await ack. This is the post-proof stage: the gateway verifies the
	// signed auth and may reject here (revoked/unknown device, bad
	// signature, failed challenge redeem). The error frame must be
	// classified, not lost in an OKMsg type mismatch (FH-1: the
	// revoked-device retry loop).
	var okMsg tunnel.OKMsg
	if err := readHandshakeMsg(ws, &okMsg); err != nil {
		return a.classify(err, stageAck)
	}
	if okMsg.Type != "ok" || okMsg.V != tunnel.ProtocolVersion {
		// The reply type is peer-controlled text: %q would escape controls
		// but still expose arbitrary peer bytes, and a misbehaving gateway
		// can echo the enrollment bearer it saw into any string field. Run
		// renders this error on every reconnect, so it carries only the
		// fixed local phrase and the safe numeric version.
		return fmt.Errorf("unexpected handshake reply: peer reply type withheld (v=%d)", okMsg.V)
	}
	// Flow-control negotiation (FH-2): the gateway announces the symmetric
	// per-stream window. Zero/absent = pre-negotiation gateway; the
	// documented backward default keeps our own configured window (safe
	// only when both sides run equal windows — the shipped defaults do).
	// The gateway may only return what we offered or less (it picks
	// min(own, offered)): a positive choice ABOVE our own announcement is
	// a broken or lying peer and fails the handshake closed BEFORE any mux
	// allocation — we must never commit buffers above our own offer, even
	// when the choice is within MaxStreamWindow (FH-2 correction).
	limits := a.cfg.Limits.Resolved()
	offered := limits.StreamWindow // exactly what HostAuth announced above
	switch {
	case okMsg.StreamWindow == 0:
		// Legacy gateway: no negotiation on the wire.
	case okMsg.StreamWindow > 0 && okMsg.StreamWindow <= offered:
		limits.StreamWindow = okMsg.StreamWindow
	default:
		return fmt.Errorf("%w: gateway chose stream window %d above the offered %d (cap %d)",
			tunnel.ErrProtocol, okMsg.StreamWindow, offered, tunnel.MaxStreamWindow)
	}
	a.log.Info("tunnel control connection established", "server", u.Host, "device", a.cfg.DeviceID)
	defer a.log.Info("tunnel control connection closed", "device", a.cfg.DeviceID)

	// 4. Serve streams until the connection dies. The handshake read
	// deadline set above must NOT survive into the session (finding F-13 /
	// A4: it would drop every healthy connection after one handshake
	// timeout). From here the deadline is a liveness bound, extended by
	// every inbound frame and by pongs answering our keepalive pings; a
	// peer silent for pongWait is dropped. The mux runs on the negotiated
	// window (FH-2): identical send and receive credit on both sides.
	pongWait := limits.PongWait
	if pongWait <= 0 {
		pongWait = 75 * time.Second
	}
	ws.SetPongHandler(func(string) error {
		return ws.SetReadDeadline(time.Now().Add(pongWait))
	})
	_ = ws.SetReadDeadline(time.Now().Add(pongWait))

	transport := tunnel.NewWSTransport(ws, limits)
	mux := tunnel.NewMux(newLivenessTransport(transport, ws, pongWait), limits, tunnel.RoleHost)
	watchDone := make(chan struct{})
	defer close(watchDone)
	go func() {
		select {
		case <-ctx.Done():
			mux.Close()
		case <-mux.Done():
		}
	}()
	go keepalive(transport.Writer(), a.cfg.Limits, mux.Done())
	for {
		stream, err := mux.Accept()
		if err != nil {
			if ctx.Err() != nil {
				return ctx.Err()
			}
			return fmt.Errorf("control connection: %w", err)
		}
		go a.serveStream(stream)
	}
}

// livenessTransport extends the WebSocket read deadline on every inbound
// frame (F-13): the session stays alive while pings or data keep arriving,
// and a stalled peer is dropped after pongWait of total silence.
type livenessTransport struct {
	tr       tunnel.Transport
	ws       *websocket.Conn
	pongWait time.Duration
}

func newLivenessTransport(tr tunnel.Transport, ws *websocket.Conn, pongWait time.Duration) tunnel.Transport {
	return &livenessTransport{tr: tr, ws: ws, pongWait: pongWait}
}

func (t *livenessTransport) ReadFrame() (tunnel.Frame, error) {
	_ = t.ws.SetReadDeadline(time.Now().Add(t.pongWait))
	return t.tr.ReadFrame()
}

func (t *livenessTransport) WriteFrame(f tunnel.Frame) error { return t.tr.WriteFrame(f) }

func (t *livenessTransport) Close() error { return t.tr.Close() }

// serveStream bridges one gateway stream to the configured loopback SSH
// endpoint. The dialed bytes are opaque; nothing here speaks SSH itself.
func (a *Agent) serveStream(s *tunnel.Stream) {
	addr, err := ValidateLoopback(a.cfg.SSHHost)
	if err != nil {
		// Config tampered since load; fail this stream and keep serving.
		a.log.Error("local ssh host failed loopback validation", "err", err)
		_ = s.Reset("local endpoint rejected")
		return
	}
	d := net.Dialer{Timeout: a.cfg.LocalDialTimeout}
	tcp, err := d.Dial("tcp", addr)
	if err != nil {
		a.log.Info("local ssh dial failed", "err", err)
		_ = s.Reset("dial failed")
		return
	}
	if err := s.Ack(); err != nil {
		tcp.Close()
		return
	}
	a.log.Debug("stream bridged", "stream", s.ID(), "local", addr)
	bridge(s, tcp)
	a.log.Debug("stream closed", "stream", s.ID())
}

// bridge copies both directions with half-close handling: an EOF in one
// direction becomes a half-close on the other (preserving TCP semantics
// for the end-to-end SSH transport); any hard error tears both down.
func bridge(a io.ReadWriteCloser, b io.ReadWriteCloser) {
	done := make(chan struct{}, 2)
	halfClose := func(c io.ReadWriteCloser) {
		if t, ok := c.(interface{ CloseWrite() error }); ok {
			_ = t.CloseWrite()
		}
	}
	copyOne := func(dst, src io.ReadWriteCloser) {
		defer func() { done <- struct{}{} }()
		_, err := io.Copy(dst, src)
		switch {
		case err == nil || errors.Is(err, io.EOF):
			halfClose(dst)
		default:
			_ = dst.Close()
			_ = src.Close()
		}
	}
	go copyOne(b, a) // gateway stream -> local TCP
	go copyOne(a, b) // local TCP -> gateway stream
	<-done
	<-done
	a.Close()
	b.Close()
}

// keepalive pings the server through the shared serialized writer;
// gorilla's default ping handler on the server replies with a pong that
// extends its read deadline.
func keepalive(writer *tunnel.WSWriter, limits tunnel.Limits, done <-chan struct{}) {
	iv := limits.Resolved().PingInterval
	if iv <= 0 {
		iv = 25 * time.Second
	}
	t := time.NewTicker(iv)
	defer t.Stop()
	for {
		select {
		case <-t.C:
			if err := writer.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		case <-done:
			return
		}
	}
}

// classify turns a handshake read failure into a fatal auth error when the
// server closed with an application close code that reconnecting cannot fix,
// or when it delivered the same verdict as a JSON error frame (FH-1: the
// frame's code used to be lost in an OKMsg/HostChallenge type mismatch).
// The stage disambiguates the one code whose meaning depends on when it is
// sent: pre-proof "challenge" is capacity exhaustion (transient, CloseTimeout
// pairing), post-proof "challenge" is the terminal redeem failure
// (CloseUnauth pairing). The stage is local knowledge — the agent knows
// which reply it is waiting for and never trusts the peer to be consistent.
//
// Every branch that builds surfaced output stores only bytes this process
// produced: canonical verdict literals for matched codes and fixed
// withholding phrases. Peer ErrMsg messages and raw close reasons are never
// copied into error strings, logs or CLI stderr (run-credential-output-
// final).
func (a *Agent) classify(err error, stage handshakeStage) error {
	var rej *errPeerRejected
	if errors.As(err, &rej) {
		if rej.code == "challenge" && stage == stageChallenge {
			// Capacity exhaustion on a fresh connection: quota/timeout
			// semantics. Transient — the bounded reconnect waits for a
			// slot instead of exiting a recoverable condition (FH-1
			// correction). Every other pre-proof verdict stays stage- and
			// code-classified below.
			return err
		}
		if code, fatal := fatalCloseCode(rej.code); fatal {
			// The code matched a canonical verdict literal; the peer's
			// message text is withheld entirely — the close code and the
			// canonical verdict keep triage useful without surfacing a
			// single peer byte.
			return &errFatalAuth{code: code, reason: rej.code + " (peer message withheld)"}
		}
		return err // errPeerRejected.Error() is fixed local diagnostics
	}
	var ce *websocket.CloseError
	if errors.As(err, &ce) {
		switch ce.Code {
		case tunnel.CloseUnauth, tunnel.CloseForbidden, tunnel.CloseNotFound:
			// The close reason is raw peer payload: withhold it; render the
			// canonical verdict name for the matched close code only.
			return &errFatalAuth{code: ce.Code, reason: canonicalCloseName(ce.Code) + " (peer close reason withheld)"}
		default:
			// Transient close: the classification is unchanged, but the
			// wire reason is still peer text that Run would log on every
			// reconnect — render the fixed local diagnostic instead.
			return &errTransientClose{code: ce.Code}
		}
	}
	return err
}

// validateChallenge checks the structural properties of the gateway's
// challenge before the agent answers it. Every rejection here is fixed
// local text: the challenge fields are peer-controlled (a misbehaving
// configured gateway or on-path proxy can echo the enrollment bearer it
// saw into any of them), so no field value is copied into the error — not
// even under %q, which escapes controls but still exposes the bytes. The
// classification is unchanged: these errors still return to Run's bounded
// transient reconnect path.
func validateChallenge(ch *tunnel.HostChallenge, expectServer string) error {
	if ch.Type != "challenge" || ch.V != tunnel.ProtocolVersion {
		return fmt.Errorf("unexpected challenge: peer type withheld (v=%d)", ch.V)
	}
	if ch.ChallengeID == "" {
		return errors.New("challenge: empty challenge_id")
	}
	// ToIdentityChallenge validates role, protocol and nonce encoding. Its
	// error text embeds the peer's Role/Protocol verbatim (shared protocol
	// rendering, deliberately left unchanged), so this boundary replaces
	// the whole error with a fixed local phrase: same refusal, no peer
	// bytes retained.
	if _, err := ch.ToIdentityChallenge("device-id-checked-elsewhere"); err != nil {
		return errors.New("challenge: peer role/protocol/nonce fields failed local validation (peer values withheld)")
	}
	if ch.ConnectionNonce == "" {
		return errors.New("challenge: missing connection nonce")
	}
	if ch.Server == "" {
		return errors.New("challenge: missing server name")
	}
	if expectServer != "" && !stringsEqualFold(ch.Server, expectServer) {
		return errors.New("challenge: peer server name does not match the configured server")
	}
	if ch.ExpiresAt > 0 && time.Unix(ch.ExpiresAt, 0).Before(time.Now()) {
		return errors.New("challenge: already expired")
	}
	return nil
}

// base64Std encodes signatures for the wire (std alphabet, padded).
func base64Std(b []byte) string { return base64.StdEncoding.EncodeToString(b) }

func stringsEqualFold(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := 0; i < len(a); i++ {
		ca, cb := a[i], b[i]
		if 'A' <= ca && ca <= 'Z' {
			ca += 'a' - 'A'
		}
		if 'A' <= cb && cb <= 'Z' {
			cb += 'a' - 'A'
		}
		if ca != cb {
			return false
		}
	}
	return true
}

// JSON helpers over text WebSocket frames.

// readHandshakeMsg reads one JSON text frame into v. If the gateway sent a
// rejection (ErrMsg) instead of the expected message — at either handshake
// stage — it returns errPeerRejected carrying the code so classify can
// surface terminal verdicts (FH-1) instead of a generic type mismatch that
// would be retried forever.
func readHandshakeMsg(ws *websocket.Conn, v any) error {
	msgType, data, err := ws.ReadMessage()
	if err != nil {
		return err
	}
	if msgType != websocket.TextMessage {
		return fmt.Errorf("expected JSON frame, got type %d", msgType)
	}
	var env struct {
		Type string `json:"type"`
	}
	if err := json.Unmarshal(data, &env); err != nil {
		return err
	}
	if env.Type == "error" { // tunnel's ErrMsg type marker (unexported there)
		var em tunnel.ErrMsg
		if err := json.Unmarshal(data, &em); err != nil {
			return fmt.Errorf("malformed gateway error frame: %w", err)
		}
		// Only the code is retained — classification input, matched against
		// canonical literals before anything renders. The message field is
		// peer-controlled free text that later ends up in error strings,
		// logs and CLI stderr; a misbehaving gateway or on-path proxy can
		// echo the enrollment bearer it saw in the Authorization header
		// back through it (wholly, cut, or re-encoded — no practical
		// redaction covers every encoding of a credential the agent does
		// not store), so it is dropped HERE and never retained
		// (run-credential-output-final).
		return &errPeerRejected{code: em.Code}
	}
	return json.Unmarshal(data, v)
}

func writeJSONMsg(ws *websocket.Conn, v any) error {
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}
	return ws.WriteMessage(websocket.TextMessage, data)
}

// HTTPStatus helpers re-exported for the CLI's error messages.
func WSStatusCode(err error) (int, bool) {
	var ce *websocket.CloseError
	if errors.As(err, &ce) {
		return ce.Code, true
	}
	return 0, false
}

// ParsePort is a small helper shared by config validation.
func ParsePort(s string) (int, error) {
	n, err := strconv.Atoi(s)
	if err != nil || n < 1 || n > 65535 {
		return 0, fmt.Errorf("port %q out of range", s)
	}
	return n, nil
}
