package hostagent

// Regression tests for the enrollment probe's two hard contracts that the
// algorithm-selection tests do not cover:
//
//  1. HANDSHAKE-ONLY, keyless AND userauth-free. x/crypto's ssh.NewClientConn
//     attempts the SSH "none" method even for a client with no Auth methods
//     (client.go clientAuthenticate → noneAuth), so a probe that merely runs
//     the transport handshake DOES reach user authentication — and a server
//     permitting none would authenticate it. The probe must stop at the
//     signature-verified host-key callback instead, and the tests observe ALL
//     authentication methods (AuthLogCallback), the "none" grant
//     (NoClientAuthCallback), public-key offers and VERIFIED signatures
//     (the private-signer proof), opened channels, and completed
//     authentications. Positive control clients prove every oracle is live.
//
//  2. The whole probe is bounded by min(probeHandshakeBudget, the caller's
//     earlier deadline): post-TCP cancelation closes the socket and returns
//     promptly, a caller deadline later than the budget never extends the
//     fixed cap, an earlier caller deadline still wins, and the localhost
//     resolution runs inside the SAME derived budget — the resolver seam
//     observes the derived deadline under a live long parent, consumes part
//     of it, and the dial/handshake continues on the remainder (never a
//     restarted budget). The barriers are real transport stalls (accepted
//     TCP, silent peer) and a deterministic channel hold, never sleeps.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"errors"
	"fmt"
	"net"
	"os"
	"os/exec"
	"strings"
	"sync"
	"testing"
	"time"

	"golang.org/x/crypto/ssh"
)

// probeUserAuthOracle records every post-handshake event a real SSH server
// can observe. The probe must leave it untouched; control clients must move
// every counter (proving the counters are live, i.e. a zero for the probe is
// evidence, not a broken meter).
type probeUserAuthOracle struct {
	// mu guards EVERY field below: all server callbacks run on concurrent
	// per-connection goroutines, and a snapshot must be a coherent cut of
	// all counters, never a torn mix of locked and plain reads.
	mu sync.Mutex
	// methods lists every SSH_USERAUTH request method name, ANY method,
	// successful or not (server AuthLogCallback).
	methods []string
	// noneGranted counts accepted "none" requests (NoClientAuthCallback).
	noneGranted int64
	// pubkeyOffers counts public-key auth offers (PublicKeyCallback).
	pubkeyOffers int64
	// pubkeyVerified counts VERIFIED public-key signatures
	// (VerifiedPublicKeyCallback) — proof a private signer was used.
	pubkeyVerified int64
	// channels counts channels opened by authenticated peers.
	channels int64
	// authenticated counts connections that passed user authentication.
	authenticated int64
}

func (o *probeUserAuthOracle) logMethod(method string) {
	o.mu.Lock()
	defer o.mu.Unlock()
	o.methods = append(o.methods, method)
}

func (o *probeUserAuthOracle) grantNone() {
	o.mu.Lock()
	defer o.mu.Unlock()
	o.noneGranted++
}

func (o *probeUserAuthOracle) offerPubkey() {
	o.mu.Lock()
	defer o.mu.Unlock()
	o.pubkeyOffers++
}

func (o *probeUserAuthOracle) verifyPubkey() {
	o.mu.Lock()
	defer o.mu.Unlock()
	o.pubkeyVerified++
}

func (o *probeUserAuthOracle) openChannel() {
	o.mu.Lock()
	defer o.mu.Unlock()
	o.channels++
}

func (o *probeUserAuthOracle) completeAuth() {
	o.mu.Lock()
	defer o.mu.Unlock()
	o.authenticated++
}

// snapshot is a comparable cut of all counters.
type oracleSnapshot struct {
	methods        []string
	noneGranted    int64
	pubkeyOffers   int64
	pubkeyVerified int64
	channels       int64
	authenticated  int64
}

// snapshot reads every counter under the same lock, so the cut is coherent
// even while server goroutines are mid-recording.
func (o *probeUserAuthOracle) snapshot() oracleSnapshot {
	o.mu.Lock()
	defer o.mu.Unlock()
	return oracleSnapshot{
		methods:        append([]string(nil), o.methods...),
		noneGranted:    o.noneGranted,
		pubkeyOffers:   o.pubkeyOffers,
		pubkeyVerified: o.pubkeyVerified,
		channels:       o.channels,
		authenticated:  o.authenticated,
	}
}

// deltaViolations compares two snapshots and returns one entry per oracle
// that moved. The comparison core is error-returning (not t.Fatal) so the
// join-barrier regression can assert that a released late event FAILS the
// zero-verdict, deterministically and without depending on Fatal control
// flow.
func deltaViolations(before, after oracleSnapshot) []string {
	var v []string
	if len(after.methods) != len(before.methods) {
		v = append(v, fmt.Sprintf("%d new SSH userauth requests %v (methods seen before: %v); the probe must not reach userauth with ANY method, including none",
			len(after.methods)-len(before.methods), after.methods[len(before.methods):], before.methods))
	}
	if after.noneGranted != before.noneGranted {
		v = append(v, fmt.Sprintf("%d additional none-grants; the probe must not be authenticated even by a server allowing none", after.noneGranted-before.noneGranted))
	}
	if after.pubkeyOffers != before.pubkeyOffers {
		v = append(v, fmt.Sprintf("%d additional public-key offers; the probe must never offer a key", after.pubkeyOffers-before.pubkeyOffers))
	}
	if after.pubkeyVerified != before.pubkeyVerified {
		v = append(v, fmt.Sprintf("%d additional verified public-key signatures; the probe must never use a private signer", after.pubkeyVerified-before.pubkeyVerified))
	}
	if after.channels != before.channels {
		v = append(v, fmt.Sprintf("%d additional channels opened; the probe must not open channels", after.channels-before.channels))
	}
	if after.authenticated != before.authenticated {
		v = append(v, fmt.Sprintf("%d additional authenticated connections; the probe must not complete authentication", after.authenticated-before.authenticated))
	}
	return v
}

// requireUntouched fails the test if anything was observed after snap.
func (o *probeUserAuthOracle) requireUntouched(t *testing.T, snap oracleSnapshot, phase string) {
	t.Helper()
	if v := deltaViolations(snap, o.snapshot()); v != nil {
		t.Fatalf("%s: the probe moved the userauth oracle: %v", phase, v)
	}
}

// startProbeUserAuthServer runs a real in-process SSH server whose
// configuration is maximally permissive: it grants "none" authentication AND
// accepts every public key. It returns the tracked server handle; tests
// compare oracle counters only after waitConnDone has joined the specific
// connection whose events they are judging — a later control connection is
// NOT a completion proof for an earlier one.
func startProbeUserAuthServer(t *testing.T, o *probeUserAuthOracle, signers ...ssh.Signer) *probeSSHServer {
	t.Helper()
	cfg := &ssh.ServerConfig{
		// The server MUST allow none authentication: the documented probe
		// contract is that it never REACHES userauth — even where userauth
		// would succeed. This callback is the receipt that a none request
		// arrived and was granted.
		NoClientAuth: true,
		NoClientAuthCallback: func(ssh.ConnMetadata) (*ssh.Permissions, error) {
			o.grantNone()
			return &ssh.Permissions{}, nil
		},
		PublicKeyCallback: func(_ ssh.ConnMetadata, _ ssh.PublicKey) (*ssh.Permissions, error) {
			o.offerPubkey()
			return &ssh.Permissions{}, nil
		},
		VerifiedPublicKeyCallback: func(_ ssh.ConnMetadata, _ ssh.PublicKey, p *ssh.Permissions, _ string) (*ssh.Permissions, error) {
			o.verifyPubkey()
			return p, nil
		},
		AuthLogCallback: func(_ ssh.ConnMetadata, method string, _ error) {
			o.logMethod(method)
		},
	}
	for _, s := range signers {
		cfg.AddHostKey(s)
	}
	return serveProbeSSH(t, cfg, o)
}

// startProbePubkeyOnlyServer is the same idea but none authentication is
// refused, so a client carrying a real signer exercises the offer/verified
// counters (on the none-allowed server the none grant wins first).
func startProbePubkeyOnlyServer(t *testing.T, o *probeUserAuthOracle, signers ...ssh.Signer) *probeSSHServer {
	t.Helper()
	cfg := &ssh.ServerConfig{
		PublicKeyCallback: func(_ ssh.ConnMetadata, _ ssh.PublicKey) (*ssh.Permissions, error) {
			o.offerPubkey()
			return &ssh.Permissions{}, nil
		},
		VerifiedPublicKeyCallback: func(_ ssh.ConnMetadata, _ ssh.PublicKey, p *ssh.Permissions, _ string) (*ssh.Permissions, error) {
			o.verifyPubkey()
			return p, nil
		},
		AuthLogCallback: func(_ ssh.ConnMetadata, method string, _ error) {
			o.logMethod(method)
		},
	}
	for _, s := range signers {
		cfg.AddHostKey(s)
	}
	return serveProbeSSH(t, cfg, o)
}

// probeSSHServer tracks every connection it accepts so tests can join a
// SPECIFIC connection's server-side processing before judging its events.
type probeSSHServer struct {
	addr   string
	oracle *probeUserAuthOracle

	// heldConn/holdRelease implement the delayed-event oracle: a conn
	// goroutine for the armed accept-index stalls before exiting and, only
	// on release, records its "late" event — simulating server-side
	// processing that completes strictly after the client returned.
	heldConn    int
	lateEvent   func()
	holdRelease chan struct{}
	// parked is closed by the armed handler the moment it reaches its park
	// point (before blocking on holdRelease), so a test can PROVE the
	// handler is stalled before exercising failure/cleanup paths.
	parked chan struct{}
	// releaseOnce makes release idempotent and concurrency-safe: both the
	// test's normal-path call and the cleanup-registered guarantee close
	// holdRelease exactly once.
	releaseOnce *sync.Once

	mu     sync.Mutex
	conns  []chan struct{} // done channel per accepted conn (accept order)
	live   []net.Conn      // still-open raw conns, closed by Cleanup
	closed bool
}

// holdConn arms the delayed-event hook for the conn accepted at index i:
// its goroutine will not exit until release() and only then record
// lateEvent. Deterministic — no sleeps. It registers the release with the
// test's cleanup IMMEDIATELY, before any failure-prone work: cleanups run
// LIFO, and the server cleanup (registered earlier by serveProbeSSH) joins
// every conn goroutine, so a parked handler MUST be released first — on
// EVERY exit path, including a Fatal long before the test's own
// normal-path release — or that join would hang forever.
func (s *probeSSHServer) holdConn(t *testing.T, i int, lateEvent func()) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.heldConn = i
	s.lateEvent = lateEvent
	s.holdRelease = make(chan struct{})
	s.parked = make(chan struct{})
	s.releaseOnce = &sync.Once{}
	t.Cleanup(s.release)
}

// parkPoint returns the channel closed when the armed handler reaches its
// park point (nil while no hold is armed).
func (s *probeSSHServer) parkPoint() <-chan struct{} {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.parked
}

// release unblocks the armed handler; idempotent and safe to call
// concurrently from the test body and from cleanup.
func (s *probeSSHServer) release() {
	s.mu.Lock()
	once := s.releaseOnce
	s.mu.Unlock()
	if once != nil {
		once.Do(func() {
			s.mu.Lock()
			rel := s.holdRelease
			s.mu.Unlock()
			if rel != nil {
				close(rel)
			}
		})
	}
}

// waitConnDone joins the server-side goroutine of the i-th accepted
// connection: it has finished processing (recorded everything it will ever
// record) once this returns. Tests must call this for the TESTED
// connection before comparing its counters.
func (s *probeSSHServer) waitConnDone(t *testing.T, i int, timeout time.Duration) {
	t.Helper()
	if !s.waitConnDoneIdx(i, timeout) {
		t.Fatalf("server-side processing of accepted connection %d did not finish within %s; per-connection completion is required before comparing counters", i, timeout)
	}
}

func (s *probeSSHServer) waitConnDoneIdx(i int, timeout time.Duration) bool {
	deadline := time.Now().Add(timeout)
	for {
		s.mu.Lock()
		var ch chan struct{}
		if i < len(s.conns) {
			ch = s.conns[i]
		}
		s.mu.Unlock()
		if ch != nil {
			select {
			case <-ch:
				return true
			case <-time.After(time.Until(deadline)):
				return false
			}
		}
		if time.Now().After(deadline) {
			return false
		}
		time.Sleep(5 * time.Millisecond)
	}
}

// serveProbeSSH listens on 127.0.0.1 and serves SSH connections: it records
// authentications, serves one session channel per authenticated peer with a
// trivial exec responder (so control clients prove channel observation is
// live), and rejects everything else. Cleanup closes the listener, closes
// every accepted connection and JOINS every connection goroutine — cleanup
// is a real quiesce point, not an accept-loop-only join.
func serveProbeSSH(t *testing.T, cfg *ssh.ServerConfig, o *probeUserAuthOracle) *probeSSHServer {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	s := &probeSSHServer{oracle: o}
	done := make(chan struct{})
	var conns sync.WaitGroup
	go func() {
		defer close(done)
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			s.mu.Lock()
			idx := len(s.conns)
			// The done channel is created, stored and captured as a LOCAL
			// under the same lock as the append: the goroutine below owns
			// its channel and never re-reads the shared slice header, whose
			// append the accept loop can replace concurrently.
			doneCh := make(chan struct{})
			s.conns = append(s.conns, doneCh)
			s.live = append(s.live, c)
			s.mu.Unlock()
			conns.Add(1)
			go func(c net.Conn, idx int, doneCh chan struct{}) {
				defer conns.Done()
				defer close(doneCh)
				s.mu.Lock()
				if s.closed {
					s.mu.Unlock()
					c.Close()
					return
				}
				s.mu.Unlock()
				defer c.Close()
				sconn, chans, reqs, err := ssh.NewServerConn(c, cfg)
				if err != nil {
					// includes pre-auth disconnects: no counters move —
					// unless a delayed-event hook is armed for this conn
					// (the join-barrier regression's oracle probe).
					s.mu.Lock()
					armed := s.holdRelease != nil && s.heldConn == idx
					rel := s.holdRelease
					parked := s.parked
					late := s.lateEvent
					s.mu.Unlock()
					if armed {
						// Only this conn's goroutine is armed, so it alone
						// closes parked. Signal BEFORE parking so tests can
						// deterministically observe the stall.
						close(parked)
						<-rel
						late()
					}
					return
				}
				o.completeAuth()
				defer sconn.Close()
				go ssh.DiscardRequests(reqs)
				for nc := range chans {
					o.openChannel()
					if nc.ChannelType() != "session" {
						nc.Reject(ssh.UnknownChannelType, "nothing to serve")
						continue
					}
					ch, reqs2, err := nc.Accept()
					if err != nil {
						continue
					}
					go serveProbeExec(ch, reqs2)
				}
			}(c, idx, doneCh)
		}
	}()
	t.Cleanup(func() {
		ln.Close()
		<-done
		// Close any connection still being served, then join every conn
		// goroutine: no server-side processing outlives the test.
		s.mu.Lock()
		s.closed = true
		live := append([]net.Conn(nil), s.live...)
		s.mu.Unlock()
		for _, c := range live {
			_ = c.Close()
		}
		conns.Wait()
	})
	s.addr = ln.Addr().String()
	return s
}

// serveProbeExec answers one exec request with a fixed line and exit 0.
func serveProbeExec(ch ssh.Channel, reqs <-chan *ssh.Request) {
	defer ch.Close()
	for req := range reqs {
		if req.Type != "exec" {
			if req.WantReply {
				req.Reply(false, nil)
			}
			continue
		}
		if req.WantReply {
			req.Reply(true, nil)
		}
		fmt.Fprint(ch, "probe-oracle-ok\n")
		ch.SendRequest("exit-status", false, ssh.Marshal(struct{ Status uint32 }{0}))
		return
	}
}

// probeControlDial is a NORMAL SSH client (the oracle's positive control):
// it connects, optionally authenticates with the given signer, runs one exec
// and returns the presented host key. Auth nil exercises the none method.
func probeControlDial(t *testing.T, addr, user string, auth []ssh.AuthMethod) (ssh.PublicKey, string) {
	t.Helper()
	var presented ssh.PublicKey
	cfg := &ssh.ClientConfig{
		User:              user,
		Auth:              auth,
		HostKeyAlgorithms: BrowserHostKeyAlgorithms(),
		HostKeyCallback: func(_ string, _ net.Addr, key ssh.PublicKey) error {
			presented = key
			return nil
		},
		Timeout: 5 * time.Second,
	}
	client, err := ssh.Dial("tcp", addr, cfg)
	if err != nil {
		t.Fatalf("control client (user %q, auth %v) must authenticate: %v", user, auth != nil, err)
	}
	defer client.Close()
	sess, err := client.NewSession()
	if err != nil {
		t.Fatalf("control client NewSession: %v", err)
	}
	defer sess.Close()
	out, err := sess.CombinedOutput("echo probe-oracle-ok")
	if err != nil || strings.TrimSpace(string(out)) != "probe-oracle-ok" {
		t.Fatalf("control client exec: out=%q err=%v", out, err)
	}
	return presented, strings.TrimSpace(string(out))
}

// TestProbeStopsBeforeUserAuthIncludingNone is the core userauth regression:
// against a server that would GRANT none authentication, the probe must come
// back with the signature-verified selected host key while producing ZERO
// userauth activity of any method, zero grants, zero offers, zero verified
// signatures, zero channels and zero authenticated connections — with
// positive control clients (none-authenticated and public-key-authenticated)
// proving every oracle counter is live before the zero is claimed.
func TestProbeStopsBeforeUserAuthIncludingNone(t *testing.T) {
	ks := generateProbeHostKeys(t)
	o := &probeUserAuthOracle{}
	noneAllowed := startProbeUserAuthServer(t, o, ks.ecdsa, ks.rsa, ks.ed)
	pubkeyOnly := startProbePubkeyOnlyServer(t, o, ks.ecdsa, ks.rsa, ks.ed)

	// Positive control 1: a client with NO auth methods DOES authenticate
	// (via none) against the permissive server and opens a working session.
	// This proves the oracle would have caught the probe authenticating.
	presented, _ := probeControlDial(t, noneAllowed.addr, "control-none", nil)
	if presented == nil || presented.Type() != ssh.KeyAlgoED25519 {
		t.Fatalf("none control presented %v; the server must negotiate the browser policy for the oracle to apply to the probe", presented)
	}
	// Join control 1's server-side goroutine: its counters are final.
	noneAllowed.waitConnDone(t, 0, 10*time.Second)

	// Positive control 2: a client with a real private signer moves the
	// offer AND verified-signature counters — the private-signer oracle is
	// live, so a zero after the probe is evidence the probe never signed.
	_, userPriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	userSigner, err := ssh.NewSignerFromKey(userPriv)
	if err != nil {
		t.Fatal(err)
	}
	probeControlDial(t, pubkeyOnly.addr, "control-pubkey", []ssh.AuthMethod{ssh.PublicKeys(userSigner)})
	pubkeyOnly.waitConnDone(t, 0, 10*time.Second)

	live := o.snapshot()
	if live.noneGranted < 1 {
		t.Fatal("none-grant counter never moved: the none oracle is not live")
	}
	if live.pubkeyOffers < 1 || live.pubkeyVerified < 1 {
		t.Fatalf("public-key counters never moved (offers=%d verified=%d): the signer oracle is not live", live.pubkeyOffers, live.pubkeyVerified)
	}
	if live.channels < 1 || live.authenticated < 2 {
		t.Fatalf("channel/authenticated counters not live (channels=%d authenticated=%d)", live.channels, live.authenticated)
	}

	// THE probe: succeeds, pins the browser-selected key, touches nothing.
	// It is noneAllowed's accepted connection #1 (after control 1).
	snap := o.snapshot()
	info, err := ProbeSSHHostKey(context.Background(), noneAllowed.addr)
	if err != nil {
		t.Fatalf("probe: %v", err)
	}
	if info.Algorithm != ssh.KeyAlgoED25519 {
		t.Fatalf("probe pinned %s; want the browser-selected ssh-ed25519", info.Algorithm)
	}
	if want := ssh.FingerprintSHA256(ks.ed.PublicKey()); info.Fingerprint != want {
		t.Fatalf("probe fingerprint %q, want the verified Ed25519 key %q", info.Fingerprint, want)
	}
	// Completion barrier for the TESTED connection: join the server-side
	// processing of the probe's own connection before comparing counters.
	// The probe client returning is not that join — a server-side event
	// (e.g. a userauth request observed late) could still land after the
	// client gave up, and a later control connection would not prove this
	// connection finished.
	noneAllowed.waitConnDone(t, 1, 10*time.Second)
	o.requireUntouched(t, snap, "probe against none-allowed server")

	// Liveness: a fresh control connection completes AFTER the probe,
	// proving the server is still serving and the counters still move. It
	// is deliberately NOT the probe's completion proof — the join above is.
	// The total delta from the pre-probe snapshot must be EXACTLY this
	// control's own traffic: one none request, one grant, one authenticated
	// connection, one session channel.
	probeControlDial(t, noneAllowed.addr, "control-after", nil)
	noneAllowed.waitConnDone(t, 2, 10*time.Second)
	final := o.snapshot()
	if len(final.methods) != len(snap.methods)+1 || final.methods[len(snap.methods)] != "none" {
		t.Fatalf("unexpected userauth traffic after the probe phase: new methods %v", final.methods[len(snap.methods):])
	}
	if final.noneGranted != snap.noneGranted+1 || final.authenticated != snap.authenticated+1 || final.channels != snap.channels+1 {
		t.Fatalf("liveness control's own counters moved unexpectedly (grants %d→%d, authenticated %d→%d, channels %d→%d): extra post-handshake activity beyond one control client",
			snap.noneGranted, final.noneGranted, snap.authenticated, final.authenticated, snap.channels, final.channels)
	}
	if final.pubkeyOffers != snap.pubkeyOffers || final.pubkeyVerified != snap.pubkeyVerified {
		t.Fatalf("probe phase moved public-key counters (offers %d→%d, verified %d→%d)",
			snap.pubkeyOffers, final.pubkeyOffers, snap.pubkeyVerified, final.pubkeyVerified)
	}
}

// TestProbeZeroVerdictRequiresTestedConnectionJoin is the join-barrier
// regression for the in-process oracle: the probe connection's server-side
// processing is deliberately HELD while a positive control completes
// cleanly, and the zero-verdict must refuse to conclude until the held
// connection is joined. On release the held connection records a late
// "none" request — a deterministic delayed event — and the joined verdict
// must FAIL (prove the barrier catches exactly the escape a client-return
// comparison would miss). No sleeps arbitrate correctness: the hold is a
// channel, the premature check is a bounded non-completion observation.
func TestProbeZeroVerdictRequiresTestedConnectionJoin(t *testing.T) {
	ks := generateProbeHostKeys(t)
	o := &probeUserAuthOracle{}
	srv := startProbeUserAuthServer(t, o, ks.ecdsa, ks.rsa, ks.ed)

	// Arm the delayed-event hook for accepted connection #0 — the probe's.
	// holdConn registers the idempotent release with cleanup NOW: every
	// exit path below (including any Fatal) releases the parked handler
	// before the server cleanup joins its goroutine.
	srv.holdConn(t, 0, func() { o.logMethod("none") })

	done := make(chan error, 1)
	go func() {
		_, err := ProbeSSHHostKey(context.Background(), srv.addr)
		done <- err
	}()
	select {
	case err := <-done:
		if err != nil {
			t.Fatalf("probe must still succeed against the held server: %v", err)
		}
	case <-time.After(10 * time.Second):
		t.Fatal("probe never returned; the hold must not block the client-side handshake stop")
	}

	// A positive control completes FULLY while the probe connection's
	// server goroutine is still held — its completion is not a join for the
	// probe connection.
	probeControlDial(t, srv.addr, "control-while-held", nil)
	srv.waitConnDone(t, 1, 10*time.Second)
	snapHeld := o.snapshot()
	if snapHeld.noneGranted < 1 || snapHeld.authenticated < 1 {
		t.Fatalf("control counters not live while probe conn held (grants=%d auth=%d)", snapHeld.noneGranted, snapHeld.authenticated)
	}

	// The zero-verdict evaluation joins the tested connection first — so it
	// must NOT conclude while the hold is closed. The join's boolean is
	// checked: a timed-out join is itself the failure verdict — the oracle
	// is never evaluated over an un-joined connection.
	verdict := make(chan error, 1)
	go func() {
		if !srv.waitConnDoneIdx(0, 30*time.Second) {
			verdict <- errors.New("tested connection's server processing did not finish within 30s")
			return
		}
		if v := deltaViolations(snapHeld, o.snapshot()); len(v) > 0 {
			verdict <- errors.New(strings.Join(v, "; "))
			return
		}
		verdict <- nil
	}()
	select {
	case err := <-verdict:
		t.Fatalf("zero verdict concluded while the tested connection's server processing was still held: %v — the completion join is missing", err)
	case <-time.After(500 * time.Millisecond):
		// Correctly blocked: no premature verdict.
	}

	// Release: the held goroutine records its late "none" event and exits;
	// the verdict then resumes and MUST report the violation.
	srv.release()
	select {
	case err := <-verdict:
		if err == nil {
			t.Fatal("released tested connection recorded a late none userauth request, but the joined zero-verdict reported no violation — the oracle does not catch delayed events")
		}
		if !strings.Contains(err.Error(), "none") {
			t.Fatalf("violation does not name the delayed none request: %v", err)
		}
	case <-time.After(30 * time.Second):
		t.Fatal("verdict never resumed after releasing the held connection")
	}
}

// envProbeEarlyFailureChild switches this test binary into the child role
// of the early-failure regression; it is set only by the parent test below
// when re-executing itself.
const envProbeEarlyFailureChild = "POCKETSHELL_PROBE_EARLY_FAILURE_CHILD"

// TestProbeEarlyFailureReleasesHeldConnectionBeforeCleanup is the
// failure-containment regression: a genuinely FAILING test with a
// connection handler parked at the hold must not hang cleanup, must keep
// its original error, and must leave no goroutine waiting. It re-executes
// this test binary as a child (a failing subtest would taint this test's
// verdict, so the failure must happen in a real, separate test run): the
// child arms the hold, proves the handler parked, then fails through the
// REAL t.Fatalf path on a genuine production error — a probe given an
// already-canceled caller budget fails honestly, deterministically, before
// any dial (standing in for any pre-release failure such as a failed
// positive control or a detected premature verdict). The parent requires,
// within a hard wall-clock bound: the child exited FAILED (failure
// preserved, never swallowed by cleanup), its report carries the induced
// message AND the classified original error, and it was not killed by its
// own test timeout — a child that exits at all proves the cleanup ran to
// completion (release → the server cleanup's conn goroutine join), since a
// parked handler blocking that join would instead hit the 75s test timeout
// and be reported with a goroutine dump.
func TestProbeEarlyFailureReleasesHeldConnectionBeforeCleanup(t *testing.T) {
	if os.Getenv(envProbeEarlyFailureChild) == "1" {
		runProbeEarlyFailureChild(t)
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, os.Args[0],
		"-test.run", "^TestProbeEarlyFailureReleasesHeldConnectionBeforeCleanup$",
		"-test.timeout", "75s")
	cmd.Env = append(os.Environ(), envProbeEarlyFailureChild+"=1")
	start := time.Now()
	out, err := cmd.CombinedOutput()
	elapsed := time.Since(start)
	text := string(out)

	if ctx.Err() != nil {
		t.Fatalf("early-failure child did not finish within 90s; the parked handler's release-before-join is not guaranteed\noutput:\n%s", text)
	}
	var exitErr *exec.ExitError
	if !errors.As(err, &exitErr) {
		t.Fatalf("early-failure child did not fail (err %v); the induced failure was swallowed by cleanup instead of preserved\noutput:\n%s", err, text)
	}
	if strings.Contains(text, "test timed out") {
		t.Fatalf("early-failure child hit its own test timeout — cleanup joined a still-parked handler\noutput:\n%s", text)
	}
	if !strings.Contains(text, "early failure while conn 0's handler is parked [context-canceled]") {
		t.Fatalf("child report does not carry the induced early failure with its classified original error\noutput:\n%s", text)
	}
	if elapsed > 45*time.Second {
		t.Fatalf("early-failure path took %s; failure → release → join must be bounded\noutput:\n%s", elapsed, text)
	}
}

// runProbeEarlyFailureChild is the child half: a real test body that arms
// the hold, parks the handler, and exits via t.Fatalf with the hold armed.
func runProbeEarlyFailureChild(t *testing.T) {
	ks := generateProbeHostKeys(t)
	o := &probeUserAuthOracle{}
	srv := startProbeUserAuthServer(t, o, ks.ecdsa, ks.rsa, ks.ed)

	// Arm the hold FIRST: it registers the idempotent release with cleanup
	// before any failure-prone work, so the parked handler is released
	// before the server cleanup joins conn goroutines on every exit path —
	// including the Fatal below.
	srv.holdConn(t, 0, func() { o.logMethod("none") })

	// Park conn #0's handler: the probe succeeds client-side (stops at the
	// verified host key), the server-side handshake errors, and the armed
	// hook parks the goroutine. The park point makes the stall observable
	// before the failure is induced — without it the failure could fire
	// before any handler was parked, weakening the control.
	info, err := ProbeSSHHostKey(context.Background(), srv.addr)
	if err != nil {
		t.Fatalf("probe: %v", err)
	}
	if info == nil || info.Algorithm != ssh.KeyAlgoED25519 {
		t.Fatalf("probe pinned %+v", info)
	}
	select {
	case <-srv.parkPoint():
	case <-time.After(5 * time.Second):
		t.Fatal("held handler never reached its park point; the early failure would not exercise a parked cleanup")
	}

	// The EARLY FAILURE: a genuine production-code error while the handler
	// is parked, classified against its expected cause so the parent can
	// verify the original error survived the failure/cleanup path.
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, err = ProbeSSHHostKey(ctx, srv.addr)
	kind := "unexpected"
	if errors.Is(err, context.Canceled) {
		kind = "context-canceled"
	}
	t.Fatalf("early failure while conn 0's handler is parked [%s]: %v", kind, err)
}

// TestProbeConcurrentAcceptsOwnDoneChannelsAndJoinExactly is the ownership
// regression for the accept path: n near-simultaneous control connections
// make the accept loop append the done-channel slice WHILE earlier
// connection goroutines already exit and close their done channels. Every
// goroutine closes the channel captured under the accept lock — never
// re-indexing the shared slice header — and the test joins each accepted
// connection by its exact accept index before judging counters. Under race
// detection this fails on any shared-slice access; the final accounting is
// exact, not a best-effort count.
func TestProbeConcurrentAcceptsOwnDoneChannelsAndJoinExactly(t *testing.T) {
	ks := generateProbeHostKeys(t)
	o := &probeUserAuthOracle{}
	srv := startProbeUserAuthServer(t, o, ks.ecdsa, ks.rsa, ks.ed)

	const n = 8
	results := make(chan error, n)
	start := make(chan struct{})
	for i := 0; i < n; i++ {
		go func() {
			<-start
			cfg := &ssh.ClientConfig{
				User:              "concurrent-control",
				HostKeyAlgorithms: BrowserHostKeyAlgorithms(),
				HostKeyCallback:   func(string, net.Addr, ssh.PublicKey) error { return nil },
				Timeout:           5 * time.Second,
			}
			client, err := ssh.Dial("tcp", srv.addr, cfg)
			if err != nil {
				results <- fmt.Errorf("control dial: %w", err)
				return
			}
			client.Close()
			results <- nil
		}()
	}
	close(start)
	for i := 0; i < n; i++ {
		select {
		case err := <-results:
			if err != nil {
				t.Fatalf("concurrent control %d: %v", i, err)
			}
		case <-time.After(10 * time.Second):
			t.Fatalf("concurrent control %d never completed", i)
		}
	}

	// Exact owned joins: every accepted connection's server-side processing
	// is joined by its accept index, in order.
	for i := 0; i < n; i++ {
		srv.waitConnDone(t, i, 10*time.Second)
	}

	// Exact accounting after the joins: n keyless x/crypto clients each
	// attempted exactly one none userauth request and were granted it;
	// nothing else moved.
	final := o.snapshot()
	if len(final.methods) != n {
		t.Fatalf("observed %d userauth requests, want exactly %d none attempts: %v", len(final.methods), n, final.methods)
	}
	for _, m := range final.methods {
		if m != "none" {
			t.Fatalf("unexpected method %q in %v", m, final.methods)
		}
	}
	if final.noneGranted != n || final.authenticated != n {
		t.Fatalf("grants=%d authenticated=%d, want %d each", final.noneGranted, final.authenticated, n)
	}
	if final.pubkeyOffers != 0 || final.pubkeyVerified != 0 || final.channels != 0 {
		t.Fatalf("offers=%d verified=%d channels=%d; keyless clients that never open a session must move nothing else", final.pubkeyOffers, final.pubkeyVerified, final.channels)
	}
}

// startStalledSSHListener returns a listener that accepts TCP connections
// and never speaks (no SSH banner, no kex) — a real transport stall — plus a
// channel delivering each accepted server-side conn. Cleanup closes the
// listener and every accepted connection, and joins the accept loop.
func startStalledSSHListener(t *testing.T) (addr string, accepted <-chan net.Conn) {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	acc := make(chan net.Conn, 16)
	done := make(chan struct{})
	go func() {
		defer close(done)
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			acc <- c
		}
	}()
	t.Cleanup(func() {
		ln.Close()
		<-done
		for {
			select {
			case c := <-acc:
				_ = c.Close()
			default:
				return
			}
		}
	})
	return ln.Addr().String(), acc
}

// waitProbeDone runs ProbeSSHHostKey in the background and returns a
// receive-only channel with its result.
func waitProbeDone(ctx context.Context, addr string) <-chan error {
	done := make(chan error, 1)
	go func() {
		info, err := ProbeSSHHostKey(ctx, addr)
		if err == nil && info == nil {
			err = errors.New("probe returned nil info and nil error")
		}
		done <- err
	}()
	return done
}

// TestProbeCancelAfterAcceptedTCPClosesAndReturnsPromptly: cancelation after
// the TCP connection was accepted but before the handshake produced any
// bytes must close the probe's socket and return promptly — not ride out a
// full socket deadline. The stalled peer must observe the close.
func TestProbeCancelAfterAcceptedTCPClosesAndReturnsPromptly(t *testing.T) {
	addr, accepted := startStalledSSHListener(t)
	ctx, cancel := context.WithCancel(context.Background())
	done := waitProbeDone(ctx, addr)

	var serverSide net.Conn
	select {
	case serverSide = <-accepted:
	case <-time.After(5 * time.Second):
		t.Fatal("probe never connected to the stalled server")
	}

	cancel()
	select {
	case err := <-done:
		if err == nil {
			t.Fatal("canceled probe must fail honestly, not succeed")
		}
	case <-time.After(5 * time.Second):
		t.Fatalf("probe still running 5s after post-TCP cancel; cancelation must close the connection and return promptly")
	}

	// The server side must see the socket closed: read to EOF. The probe
	// may have sent its SSH version banner before the cancel, so bytes can
	// legitimately arrive first — a bounded read TIMEOUT (no close) is the
	// failure this check exists to catch.
	_ = serverSide.SetReadDeadline(time.Now().Add(5 * time.Second))
	buf := make([]byte, 128)
	for {
		n, err := serverSide.Read(buf)
		if err != nil {
			if errors.Is(err, os.ErrDeadlineExceeded) {
				t.Fatal("stalled peer still sees an open connection 5s after the canceled probe returned")
			}
			break // EOF or reset: the probe's socket is closed
		}
		if n == 0 {
			break // zero-byte read: peer closed
		}
	}
	serverSide.Close()
}

// TestProbeHandshakeCapBoundsLongCallerDeadline: a caller deadline far in
// the future must NOT replace the fixed probe budget. The stalled peer
// means only the budget's socket deadline can end the handshake: the probe
// must return at the fixed cap (~10s), not at the caller's 1h deadline.
func TestProbeHandshakeCapBoundsLongCallerDeadline(t *testing.T) {
	addr, _ := startStalledSSHListener(t)
	ctx, cancel := context.WithTimeout(context.Background(), time.Hour)
	defer cancel()

	start := time.Now()
	done := waitProbeDone(ctx, addr)
	select {
	case err := <-done:
		elapsed := time.Since(start)
		if err == nil {
			t.Fatal("probe against a silent peer must fail, not succeed")
		}
		if elapsed > 15*time.Second {
			t.Fatalf("probe ran %s despite the fixed handshake cap; a long caller deadline must not replace it", elapsed)
		}
		if elapsed < 5*time.Second {
			t.Fatalf("probe returned after only %s; expected the fixed ~10s cap to be the binding barrier", elapsed)
		}
	case <-time.After(20 * time.Second):
		t.Fatal("probe still running after 20s: the fixed cap did not bound a 1h caller deadline")
	}
}

// TestProbeHonorsEarlierCallerDeadline: an explicit caller deadline earlier
// than the budget still wins — preserved behavior, pinned here.
func TestProbeHonorsEarlierCallerDeadline(t *testing.T) {
	addr, _ := startStalledSSHListener(t)
	ctx, cancel := context.WithTimeout(context.Background(), 700*time.Millisecond)
	defer cancel()

	start := time.Now()
	done := waitProbeDone(ctx, addr)
	select {
	case err := <-done:
		if err == nil {
			t.Fatal("probe past an earlier caller deadline must fail")
		}
		if elapsed := time.Since(start); elapsed > 5*time.Second {
			t.Fatalf("earlier caller deadline not honored: probe returned after %s", elapsed)
		}
	case <-time.After(5 * time.Second):
		t.Fatal("probe ignored an earlier caller deadline")
	}
}

// TestProbeCancelledContextFailsLocalhostResolutionBeforeDial: the probe
// claims a bound over its ENTIRE operation, so the localhost resolution runs
// under the caller's context — a canceled context fails in the resolution
// phase, before any dial is attempted.
func TestProbeCancelledContextFailsLocalhostResolutionBeforeDial(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	info, err := ProbeSSHHostKey(ctx, "localhost:22")
	if err == nil {
		t.Fatalf("canceled probe of localhost must fail; got %+v", info)
	}
	if info != nil {
		t.Fatalf("canceled probe returned info %+v", info)
	}
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("error does not carry context.Canceled: %v", err)
	}
	if !strings.Contains(err.Error(), "localhost does not resolve") {
		t.Fatalf("canceled context did not fail in the localhost RESOLUTION phase (bound-context contract): %v", err)
	}
}

// seamResolver is the constrained resolver/validation seam: it observes the
// deadline the probe passed into localhost validation, whether the context
// was ALREADY canceled at entry, and consumes a fixed slice of real time
// (bounded by the context) before returning a loopback answer — a live
// parent, real consumption, never an already-canceled-only proof.
type seamResolver struct {
	mu            sync.Mutex
	sawDeadline   time.Time
	sawOK         bool
	entryCanceled bool
	queriedHost   string
	consume       time.Duration
}

func (r *seamResolver) LookupHost(ctx context.Context, host string) ([]string, error) {
	dl, ok := ctx.Deadline()
	r.mu.Lock()
	r.sawDeadline, r.sawOK, r.entryCanceled, r.queriedHost = dl, ok, ctx.Err() != nil, host
	consume := r.consume
	r.mu.Unlock()
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	case <-time.After(consume):
	}
	return []string{"127.0.0.1"}, nil
}

// TestProbeResolutionConsumesFixedBudgetAndDialBudgetIsNotRestarted proves
// the fixed ~10s budget is derived BEFORE localhost validation and that the
// SAME context/deadline covers resolution, dial and handshake: the resolver
// seam observes the probe's derived ~10s deadline (not its caller's 1h
// deadline) under a LIVE parent, consumes ~7.5s of it inside resolution,
// and the stalled dial then ends at the ORIGINAL deadline (~10s total) — a
// restarted post-resolution budget would only fail at ~17.5s.
func TestProbeResolutionConsumesFixedBudgetAndDialBudgetIsNotRestarted(t *testing.T) {
	addr, _ := startStalledSSHListener(t) // the accepted conn is joined and closed by cleanup
	_, port, err := net.SplitHostPort(addr)
	if err != nil {
		t.Fatal(err)
	}

	parent, cancelParent := context.WithTimeout(context.Background(), time.Hour)
	defer cancelParent()

	seam := &seamResolver{consume: 7*time.Second + 500*time.Millisecond}
	orig := probeResolver
	probeResolver = seam
	defer func() { probeResolver = orig }()

	start := time.Now()
	done := waitProbeDone(parent, "localhost:"+port)
	var probeErr error
	select {
	case probeErr = <-done:
	case <-time.After(25 * time.Second):
		t.Fatal("probe still running 25s after start; one fixed budget must bound resolution and dial together")
	}
	elapsed := time.Since(start)

	if probeErr == nil {
		t.Fatal("probe against a silent peer must fail, not succeed — a spent budget must never return a key")
	}

	// The seam saw the probe's DERIVED deadline: present, ~10s from probe
	// start (the caller had 1h), and NOT already canceled at entry.
	seam.mu.Lock()
	sawDeadline, sawOK, entryCanceled, queriedHost := seam.sawDeadline, seam.sawOK, seam.entryCanceled, seam.queriedHost
	seam.mu.Unlock()
	if !sawOK {
		t.Fatal("resolver seam saw no deadline: the probe did not derive its fixed budget before localhost validation")
	}
	derived := sawDeadline.Sub(start)
	if derived > 11*time.Second {
		t.Fatalf("resolver observed a deadline %s after probe start; the fixed ~10s budget must be derived BEFORE localhost validation (caller had 1h)", derived)
	}
	if derived < 9*time.Second {
		t.Fatalf("resolver observed a deadline only %s after probe start; want the ~10s fixed budget", derived)
	}
	if entryCanceled {
		t.Fatal("resolver seam entered with an already-canceled context; the budget-consumption proof must run against a live parent")
	}
	if queriedHost != "localhost" {
		t.Fatalf("resolver seam was queried for %q, want localhost", queriedHost)
	}

	// Resolution consumed ~7.5s of the SAME budget; the dial then ran on the
	// remainder and the stall ended at the original ~10s deadline.
	if elapsed > 11*time.Second+500*time.Millisecond {
		t.Fatalf("probe ran %s in total; resolution consumed ~7.5s inside one fixed budget, so the stalled dial must end at the ORIGINAL ~10s deadline — not a restarted one", elapsed)
	}
	if elapsed < 7*time.Second {
		t.Fatalf("probe returned after only %s; the seam must have consumed its slice of the budget before the dial", elapsed)
	}
}

// TestProbeStopPathCapturedKeyIsVerifiedKey pins the sentinel contract from
// the implementation side: the ONLY accepted success path is the deliberate
// stop at the signature-verified host-key callback, and the returned
// authorized line is exactly the server's real key — bit for bit.
func TestProbeStopPathCapturedKeyIsVerifiedKey(t *testing.T) {
	ks := generateProbeHostKeys(t)
	ps := startProbeSSHD(t, ks.rsa, ks.ecdsa, ks.ed) // server order must not matter

	info, err := ProbeSSHHostKey(context.Background(), ps.addr)
	if err != nil {
		t.Fatalf("probe: %v", err)
	}
	if want := authorizedLine(t, ks.ed); info.AuthorizedKey != want {
		t.Fatalf("captured authorized line\n got %s\nwant the verified server key %s", info.AuthorizedKey, want)
	}
	if !bytes.Equal([]byte(info.AuthorizedKey), []byte(strings.TrimSpace(string(ssh.MarshalAuthorizedKey(ks.ed.PublicKey()))))) {
		t.Fatal("captured key is not the exact verified server key")
	}
}
