package hostagent

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

// DefaultServerURL is the canonical production gateway. Every CLI entry
// point defaults to it; --server overrides for staging, docker proofs and
// tests.
const DefaultServerURL = "wss://gateway.pocketshell.io"

// LegacyServerURL is kept only as documentation of the migration alias.
const LegacyServerURL = "wss://relay.pocketshell.io"

// EnrollOptions are the inputs of `pocketshell-link enroll`.
type EnrollOptions struct {
	Dir    string
	Server string
	// Token is the sync-broker gateway credential (short-lived scoped JWT
	// from the PocketShell web UI) read from stdin by the CLI. It is never
	// a Google ID token: ValidateBrokerCredential refuses anything else
	// before any bytes are sent (F-09).
	Token    string
	DeviceID string
	SSHHost  string
	// ExpectHostKey is an optional operator-supplied pin the probed host
	// key must match exactly, checked AFTER the probe (which selects the
	// browser-supported policy, see BrowserHostKeyAlgorithms) and BEFORE
	// any HTTP request. Accepts exactly ONE authorized_keys record or a
	// SHA256 fingerprint; multi-record pastes (a second key line, or a
	// second record hidden after the comment) are refused, never folded
	// into one key's comment. Comparison is canonical (whitespace,
	// "SHA256:" prefix and padding normalized) but strictly CASE-SENSITIVE
	// in the digest body and key bytes. A fingerprint of a non-selected
	// offered key type fails honestly — the pin is never swapped for
	// another offered key.
	ExpectHostKey string
	Reenroll      bool // request explicit replacement (gateway may refuse)
	InsecureDev   bool
	// BrokerIssuer overrides the locally required credential issuer. DEV
	// LABS ONLY: accepted exclusively together with InsecureDev, so a
	// production run can never be pointed at a look-alike issuer.
	BrokerIssuer string
	Stdout       io.Writer
	Stderr       io.Writer
}

// brokerPolicy resolves the local disclosure-guard policy for this run.
func (o EnrollOptions) brokerPolicy() (BrokerPolicy, error) {
	policy := ProductionBrokerPolicy()
	if o.BrokerIssuer != "" {
		if !o.InsecureDev {
			return policy, errors.New("--dev-broker-issuer requires --insecure-dev (development labs only)")
		}
		policy.Issuer = o.BrokerIssuer
	}
	return policy, nil
}

// RunEnroll performs the full enrollment flow and writes config + key.
func RunEnroll(ctx context.Context, opts EnrollOptions) (deviceID string, err error) {
	out := opts.Stdout
	if out == nil {
		out = io.Discard
	}
	if opts.Token == "" {
		return "", errors.New("no gateway token on stdin (use --token-stdin; get the token from the PocketShell web UI)")
	}
	policy, err := opts.brokerPolicy()
	if err != nil {
		return "", err
	}
	wsURL, apiBase, err := NormalizeServerURL(opts.Server, opts.InsecureDev)
	if err != nil {
		return "", err
	}
	if opts.DeviceID == "" {
		opts.DeviceID = SuggestDeviceID()
	}
	if _, err := ValidateLoopback(opts.SSHHost); err != nil {
		return "", err
	}
	// The disclosure guard runs before ANY outward or local action: a
	// credential that is not a broker gateway token is refused here, with
	// zero HTTP requests (F-09).
	if err := ValidateBrokerCredential(opts.Token, policy, time.Now()); err != nil {
		return "", err
	}

	key, created, err := LoadOrCreateKey(KeyPath(opts.Dir))
	if err != nil {
		return "", err
	}
	if created {
		fmt.Fprintf(out, "generated new device key %s\n", KeyFingerprint(key))
	} else {
		fmt.Fprintf(out, "using existing device key %s\n", KeyFingerprint(key))
	}

	fmt.Fprintf(out, "probing local sshd at %s ...\n", opts.SSHHost)
	info, err := ProbeSSHHostKey(ctx, opts.SSHHost)
	if err != nil {
		return "", fmt.Errorf("probe local sshd: %w", err)
	}
	fmt.Fprintf(out, "local sshd host key: %s %s\n", info.Algorithm, info.Fingerprint)
	if opts.ExpectHostKey != "" {
		if !sameHostKey(opts.ExpectHostKey, info.AuthorizedKey, info.Fingerprint) {
			// Strict, honest mismatch — no alternate-key retry, no silent
			// swap of the trusted pin. The probe selects exactly one key
			// under the browser-supported policy; an expected fingerprint
			// of a DIFFERENT offered type (e.g. the ECDSA key of a
			// multi-key sshd) or a case-changed digest is a refusal.
			return "", fmt.Errorf(
				"local sshd host key does NOT match --expect-host-key (probe selected %s %s under the browser-compatible policy %v); refusing to enroll",
				info.Algorithm, info.Fingerprint, BrowserHostKeyAlgorithms())
		}
		fmt.Fprintln(out, "host key matches --expect-host-key")
	}

	fmt.Fprintf(out, "enrolling device %s with %s ...\n", opts.DeviceID, apiBase)
	confirmed, err := Enroll(ctx, EnrollRequest{
		APIBase:    apiBase,
		Token:      opts.Token,
		Policy:     policy,
		DeviceID:   opts.DeviceID,
		Key:        key,
		SSHHostKey: info.AuthorizedKey,
		Reenroll:   opts.Reenroll,
	})
	if err != nil {
		return "", err
	}
	cfg := &Config{
		Server:     wsURL,
		DeviceID:   confirmed,
		SSHHost:    opts.SSHHost,
		SSHHostKey: info.AuthorizedKey,
		CreatedAt:  time.Now().UTC(),
	}
	if err := SaveConfig(opts.Dir, cfg); err != nil {
		return "", err
	}
	fmt.Fprintf(out, "enrolled; config written to %s\n", opts.Dir)
	fmt.Fprintf(out, "start the tunnel with: pocketshell-link run\n")
	return confirmed, nil
}

// sameHostKey compares an operator-supplied pinned key (exactly ONE
// authorized_keys record, or a SHA256 fingerprint) against the probe result
// for the SELECTED host key. Comparison is canonical and case-sensitive
// where it matters:
//
//   - SHA256 fingerprints: only the documented normalizations are applied —
//     surrounding/inner ASCII whitespace, the optional "SHA256:" prefix
//     (the prefix is a name, matched case-insensitively) and base64 padding
//     ("="). The digest BODY is base64 and therefore case-significant:
//     both sides are decoded and compared as raw bytes, so a case-toggled
//     fingerprint is a mismatch. Only "sha256" digests are part of the
//     contract; anything else (md5, hex, garbage) does not match.
//   - Authorized_keys lines: compared as the actual public key — both lines
//     are parsed and the key type plus marshalled key bytes must be equal;
//     comments are ignored. Base64 case is preserved by parsing: a
//     case-toggled blob decodes to a different key and is refused.
//
// There is deliberately no relaxation: a different but valid key, or the
// fingerprint of a host key type the browser-supported policy did not
// select, is a hard mismatch.
func sameHostKey(expect, authorizedKey, fingerprint string) bool {
	expect = strings.TrimSpace(expect)
	if expect == "" {
		return false
	}
	if expectDigest, ok := sha256DigestBytes(expect); ok {
		selectedDigest, ok := sha256DigestBytes(fingerprint)
		return ok && bytes.Equal(expectDigest, selectedDigest)
	}
	expected, err := parsePublicKeyLine(expect)
	if err != nil {
		return false
	}
	selected, err := parsePublicKeyLine(authorizedKey)
	if err != nil {
		return false
	}
	return expected.Type() == selected.Type() && bytes.Equal(expected.Marshal(), selected.Marshal())
}

// sha256DigestBytes extracts the raw digest bytes from a SHA256 fingerprint
// ("SHA256:<base64>", with optional padding and whitespace). It reports
// false for anything that is not exactly one sha256 digest under the
// documented normalization policy.
func sha256DigestBytes(s string) ([]byte, bool) {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil, false
	}
	if i := strings.IndexByte(s, ':'); i >= 0 {
		if !strings.EqualFold(s[:i], "sha256") {
			return nil, false
		}
		s = s[i+1:]
	}
	// Whitespace and padding are never significant inside the digest;
	// base64 letter CASE is: decode both sides and compare bytes.
	s = strings.Map(func(r rune) rune {
		if r == ' ' || r == '\t' {
			return -1
		}
		return r
	}, s)
	s = strings.TrimRight(s, "=")
	digest, err := base64.RawStdEncoding.DecodeString(s)
	if err != nil || len(digest) != sha256.Size {
		return nil, false
	}
	return digest, true
}

// parsePublicKeyLine parses exactly ONE authorized_keys record into its
// public key. It is the canonical reading used for expected-vs-selected
// comparison, so two spellings of the same key match and any other key
// (including a case-toggled blob of the same length) does not.
//
// The input contract is a single record, so multi-record pastes are refused
// instead of normalized: joining whitespace-separated fields would silently
// fold every following authorized_keys line into the first key's comment
// and "accept" an ambiguous two-key input.
func parsePublicKeyLine(line string) (ssh.PublicKey, error) {
	trimmed := strings.TrimSpace(line)
	if trimmed == "" {
		return nil, errors.New("empty authorized_keys input")
	}
	if strings.ContainsAny(trimmed, "\r\n") {
		return nil, errors.New("expected a single authorized_keys record; refusing input with embedded line breaks")
	}
	key, comment, _, _, err := ssh.ParseAuthorizedKey([]byte(trimmed))
	if err != nil {
		return nil, fmt.Errorf("parse authorized key: %w", err)
	}
	if hidesSecondKeyRecord(comment) {
		return nil, errors.New("expected a single authorized_keys record; refusing input that contains a second key record after the comment")
	}
	return key, nil
}

// hidesSecondKeyRecord reports whether a comment field contains a further
// parseable authorized_keys record ("algorithm base64"), which is how a
// pasted multi-key list hides when its line breaks have been turned into
// spaces. Only a genuinely parseable key record triggers this: ordinary
// comment text is unaffected.
func hidesSecondKeyRecord(comment string) bool {
	fields := strings.Fields(comment)
	for i := 0; i+1 < len(fields); i++ {
		if _, _, _, _, err := ssh.ParseAuthorizedKey([]byte(fields[i] + " " + fields[i+1])); err == nil {
			return true
		}
	}
	return false
}

// RunOptions are the inputs of `pocketshell-link run`.
type RunOptions struct {
	Dir         string
	Server      string // overrides the enrolled server when non-empty
	InsecureDev bool
	Logger      *slog.Logger
}

// RunAgent loads the enrolled state and maintains the tunnel until ctx is
// canceled.
func RunAgent(ctx context.Context, opts RunOptions) error {
	cfg, err := LoadConfig(opts.Dir)
	if err != nil {
		return err
	}
	server := cfg.Server
	if opts.Server != "" {
		server = opts.Server
	}
	wsURL, _, err := NormalizeServerURL(server, opts.InsecureDev)
	if err != nil {
		return err
	}
	key, err := LoadKey(KeyPath(opts.Dir))
	if err != nil {
		return err
	}
	// The stored SSH endpoint is re-validated on every dial as well; this
	// upfront check fails fast on a tampered config.
	addr, err := ValidateLoopback(cfg.SSHHost)
	if err != nil {
		return fmt.Errorf("configured ssh host: %w", err)
	}
	agent := NewAgent(AgentConfig{
		ServerURL: wsURL,
		DeviceID:  cfg.DeviceID,
		Key:       key,
		SSHHost:   addr,
		Logger:    opts.Logger,
	})
	opts.Logger.Info("starting pocketshell link",
		"server", wsURL,
		"device", cfg.DeviceID,
		"local_ssh", addr,
		"pinned_host_key_fp", fingerprintOfLine(cfg.SSHHostKey))
	return agent.Run(ctx)
}

// fingerprintOfLine renders the pinned host key for the run log: the key
// type plus the real SHA256 fingerprint of the parsed public key, so
// distinct pinned keys are distinguishable in diagnostics. Anything that
// is not exactly one parseable authorized_keys record logs "unknown"
// (never a partial blob); `show` remains the place to see the full line.
func fingerprintOfLine(line string) string {
	pub, err := parsePublicKeyLine(line)
	if err != nil {
		return "unknown"
	}
	return pub.Type() + ":" + ssh.FingerprintSHA256(pub)
}

// Status summarizes the enrolled state for humans. It never prints secrets.
type Status struct {
	Server        string
	DeviceID      string
	SSHHost       string
	PinnedHostKey string
	DeviceKeyFP   string
}

// ShowStatus reads the enrolled state.
func ShowStatus(dir string) (*Status, error) {
	cfg, err := LoadConfig(dir)
	if err != nil {
		return nil, err
	}
	key, err := LoadKey(KeyPath(dir))
	if err != nil {
		return nil, err
	}
	return &Status{
		Server:        cfg.Server,
		DeviceID:      cfg.DeviceID,
		SSHHost:       cfg.SSHHost,
		PinnedHostKey: cfg.SSHHostKey,
		DeviceKeyFP:   KeyFingerprint(key),
	}, nil
}

// ResolveServer applies flag/config/canonical-default precedence for any
// subcommand taking --server.
func ResolveServer(flagValue string) string {
	if flagValue != "" {
		return flagValue
	}
	return DefaultServerURL
}
