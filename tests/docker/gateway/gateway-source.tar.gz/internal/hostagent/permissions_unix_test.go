//go:build !windows

package hostagent

import (
	"crypto/ed25519"
	"crypto/rand"
	"os"
	"path/filepath"
	"testing"
)

func TestProtectedUnixPermissions(t *testing.T) {
	dir := t.TempDir()
	_, key, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	if err := SaveKey(KeyPath(dir), key); err != nil {
		t.Fatal(err)
	}
	if err := SaveConfig(dir, &Config{Server: "wss://example.invalid", DeviceID: "lab", SSHHost: "127.0.0.1:22"}); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{keyFileName, confFileName} {
		p := filepath.Join(dir, name)
		st, err := os.Stat(p)
		if err != nil || st.Mode().Perm() != 0o600 {
			t.Fatalf("expected 0600: %v", err)
		}
		if err := os.Chmod(p, 0o640); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := LoadKey(KeyPath(dir)); err == nil {
		t.Fatal("loaded group-readable key")
	}
	if _, _, err := LoadOrCreateKey(KeyPath(dir)); err == nil {
		t.Fatal("accepted unsafe existing key")
	}
	if _, err := LoadConfig(dir); err == nil {
		t.Fatal("loaded group-readable config")
	}
}
