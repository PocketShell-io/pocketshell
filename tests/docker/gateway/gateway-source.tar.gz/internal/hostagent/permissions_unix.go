//go:build !windows

package hostagent

import (
	"fmt"
	"os"
)

func createProtectedTemp(dir string) (*os.File, error) {
	f, err := os.CreateTemp(dir, ".protected-*")
	if err != nil {
		return nil, err
	}
	if err := f.Chmod(keyFileMode); err != nil {
		f.Close()
		os.Remove(f.Name())
		return nil, err
	}
	return f, nil
}

func validateProtectedFile(f *os.File) error {
	st, err := f.Stat()
	if err != nil {
		return err
	}
	if !st.Mode().IsRegular() || st.Mode().Perm()&0o077 != 0 {
		return fmt.Errorf("%s: protected files require a regular file with 0600 permissions (got %o)", f.Name(), st.Mode().Perm())
	}
	return nil
}
