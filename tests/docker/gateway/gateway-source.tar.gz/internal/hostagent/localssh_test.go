package hostagent

import (
	"bytes"
	"context"
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"errors"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"golang.org/x/crypto/ssh"
)

// The enrollment probe must select the SAME host key a PocketShell browser
// client will request (the browser offers exactly
// ssh-ed25519 > rsa-sha2-512 > rsa-sha2-256 > ssh-rsa; x/crypto's DEFAULT
// client order prefers ECDSA, which the browser never offers). On an
// ordinary multi-key sshd the uncorrected probe pinned the ECDSA
// fingerprint while browsers negotiated Ed25519 — every pairing failed the
// pin despite a perfectly ordinary home machine. These tests pin the
// selection policy with real SSH handshakes; localssh_docker_test.go proves
// the same policy against real OpenSSH servers.

type probeHostKeys struct {
	ed    ssh.Signer
	ecdsa ssh.Signer
	rsa   ssh.Signer
}

func generateProbeHostKeys(t *testing.T) probeHostKeys {
	t.Helper()
	_, edPriv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	ed, err := ssh.NewSignerFromKey(edPriv)
	if err != nil {
		t.Fatal(err)
	}
	ecKey, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	ec, err := ssh.NewSignerFromKey(ecKey)
	if err != nil {
		t.Fatal(err)
	}
	rsaKey, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	rs, err := ssh.NewSignerFromKey(rsaKey)
	if err != nil {
		t.Fatal(err)
	}
	return probeHostKeys{ed: ed, ecdsa: ec, rsa: rs}
}

// probeSSHD is a real in-process SSH server (transport handshake included)
// standing in for the local sshd. It counts userauth attempts: the probe
// must never authenticate, and pin-refused clients must never reach
// userauth at all.
type probeSSHD struct {
	addr      string
	authCalls atomic.Int64
	done      chan struct{}
}

// startProbeSSHD starts the server with the given host signers, in the
// given order. Negotiation follows the SSH wire rules: the CLIENT's
// ordered preference decides which of the offered keys is presented, so
// signer order here must not change the probe's selection.
func startProbeSSHD(t *testing.T, signers ...ssh.Signer) *probeSSHD {
	t.Helper()
	if len(signers) == 0 {
		t.Fatal("startProbeSSHD needs at least one host key")
	}
	ps := &probeSSHD{done: make(chan struct{})}
	cfg := &ssh.ServerConfig{
		PublicKeyCallback: func(_ ssh.ConnMetadata, _ ssh.PublicKey) (*ssh.Permissions, error) {
			ps.authCalls.Add(1)
			return nil, errors.New("no authentication is expected in these tests")
		},
	}
	for _, s := range signers {
		cfg.AddHostKey(s)
	}
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	go func() {
		defer close(ps.done)
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			go func(c net.Conn) {
				defer c.Close()
				sconn, chans, reqs, err := ssh.NewServerConn(c, cfg)
				if err != nil {
					return
				}
				defer sconn.Close()
				go ssh.DiscardRequests(reqs)
				for nc := range chans {
					nc.Reject(ssh.UnknownChannelType, "nothing to serve")
				}
			}(c)
		}
	}()
	ps.addr = ln.Addr().String()
	t.Cleanup(func() { ln.Close(); <-ps.done })
	return ps
}

func authorizedLine(t *testing.T, s ssh.Signer) string {
	t.Helper()
	return strings.TrimSpace(string(ssh.MarshalAuthorizedKey(s.PublicKey())))
}

// toggleFirstBase64Letter flips the case of the first base64 letter,
// keeping the string a valid same-length base64 that decodes to DIFFERENT
// bytes — a realistic fingerprint case-typo.
func toggleFirstBase64Letter(s string) string {
	for i := 0; i < len(s); i++ {
		c := s[i]
		switch {
		case c >= 'a' && c <= 'z':
			return s[:i] + string(c-'a'+'A') + s[i+1:]
		case c >= 'A' && c <= 'Z':
			return s[:i] + string(c-'A'+'a') + s[i+1:]
		}
	}
	return s
}

// toggleLastBase64Letter flips the case of the LAST base64 letter. For an
// authorized_keys blob this changes only trailing key bytes, so the line
// still parses as a valid public key of the same type that decodes to
// DIFFERENT bytes — unlike flipping the first letters, which encode the
// wire-format length prefix and would produce a malformed line.
func toggleLastBase64Letter(s string) string {
	for i := len(s) - 1; i >= 0; i-- {
		c := s[i]
		switch {
		case c >= 'a' && c <= 'z':
			return s[:i] + string(c-'a'+'A') + s[i+1:]
		case c >= 'A' && c <= 'Z':
			return s[:i] + string(c-'A'+'a') + s[i+1:]
		}
	}
	return s
}

// toggledBlobLine returns the signer's authorized_keys line with the key
// type and separator PRESERVED and the blob's last base64 letter
// case-toggled. It fails the test unless the result is a genuinely parseable
// authorized_keys line whose key bytes differ — an honest mutated-pub-blob
// negative, distinct from the fingerprint case-toggle cases.
func toggledBlobLine(t *testing.T, s ssh.Signer) string {
	t.Helper()
	fields := strings.Fields(authorizedLine(t, s))
	if len(fields) < 2 {
		t.Fatal("authorized line has no blob field")
	}
	out := fields[0] + " " + toggleLastBase64Letter(fields[1])
	key, err := parsePublicKeyLine(out)
	if err != nil {
		t.Fatalf("case-toggled blob must stay a VALID authorized_keys line for this negative: %v\nline: %s", err, out)
	}
	if bytes.Equal(key.Marshal(), s.PublicKey().Marshal()) {
		t.Fatal("case-toggled blob did not change the key bytes")
	}
	return out
}

func TestBrowserHostKeyAlgorithmsPolicy(t *testing.T) {
	algos := BrowserHostKeyAlgorithms()
	want := []string{"ssh-ed25519", "rsa-sha2-512", "rsa-sha2-256", "ssh-rsa"}
	if len(algos) != len(want) {
		t.Fatalf("policy list %v, want %v", algos, want)
	}
	for i := range want {
		if algos[i] != want[i] {
			t.Fatalf("policy[%d] = %q, want %q (full list %v)", i, algos[i], want[i], want)
		}
	}
	// The contract is documented as a fresh copy: mutating one return
	// value must never poison the next caller.
	algos[0] = "mutated"
	if BrowserHostKeyAlgorithms()[0] != "ssh-ed25519" {
		t.Fatal("BrowserHostKeyAlgorithms leaked internal state through the returned slice")
	}
}

// TestProbeSSHHostKeySelectsBrowserPreferredEd25519 is the core regression:
// a server offering ECDSA + RSA + Ed25519 must pin Ed25519 — the key the
// browser requests. The signers are added ECDSA-FIRST because ECDSA is
// x/crypto's own default preference; the explicit client policy, not
// either side's storage order, must decide.
func TestProbeSSHHostKeySelectsBrowserPreferredEd25519(t *testing.T) {
	ks := generateProbeHostKeys(t)
	ps := startProbeSSHD(t, ks.ecdsa, ks.rsa, ks.ed)

	info, err := ProbeSSHHostKey(context.Background(), ps.addr)
	if err != nil {
		t.Fatalf("probe multi-key sshd: %v", err)
	}
	if info.Algorithm != ssh.KeyAlgoED25519 {
		t.Fatalf("probe pinned %s; the browser-supported policy must select ssh-ed25519 on a multi-key server", info.Algorithm)
	}
	// Independent verification against the known Ed25519 key.
	if want := ssh.FingerprintSHA256(ks.ed.PublicKey()); info.Fingerprint != want {
		t.Fatalf("fingerprint %q, want the Ed25519 key's %q", info.Fingerprint, want)
	}
	if want := authorizedLine(t, ks.ed); info.AuthorizedKey != want {
		t.Fatalf("authorized line\n got %s\nwant %s", info.AuthorizedKey, want)
	}
	// The probe is keyless: the handshake must have stopped before any
	// user authentication was attempted.
	if n := ps.authCalls.Load(); n != 0 {
		t.Fatalf("probe triggered %d userauth attempts; it must stay keyless", n)
	}
}

// TestProbeSSHHostKeyRSAOnlyPositive: an RSA-only sshd still pairs. The
// negotiated signature variant is rsa-sha2-512 (client preference); the
// pinned line/fingerprint are of the ssh-rsa key blob — the same bytes
// ssh-keygen -lf prints and browser clients verify.
func TestProbeSSHHostKeyRSAOnlyPositive(t *testing.T) {
	ks := generateProbeHostKeys(t)
	ps := startProbeSSHD(t, ks.rsa)

	info, err := ProbeSSHHostKey(context.Background(), ps.addr)
	if err != nil {
		t.Fatalf("probe RSA-only sshd: %v", err)
	}
	if info.Algorithm != ssh.KeyAlgoRSA {
		t.Fatalf("algorithm %q, want %q", info.Algorithm, ssh.KeyAlgoRSA)
	}
	if want := ssh.FingerprintSHA256(ks.rsa.PublicKey()); info.Fingerprint != want {
		t.Fatalf("fingerprint %q, want the RSA key's %q", info.Fingerprint, want)
	}
	if want := authorizedLine(t, ks.rsa); info.AuthorizedKey != want {
		t.Fatalf("authorized line\n got %s\nwant %s", info.AuthorizedKey, want)
	}
}

// TestProbeSSHHostKeyLegacySSHRSAServerStillPairs: an old sshd that only
// signs with the legacy ssh-rsa algorithm still pairs (the documented,
// intentional compat tail of the policy).
func TestProbeSSHHostKeyLegacySSHRSAServerStillPairs(t *testing.T) {
	ks := generateProbeHostKeys(t)
	algSigner, ok := ks.rsa.(ssh.AlgorithmSigner)
	if !ok {
		t.Fatalf("RSA signer does not implement AlgorithmSigner")
	}
	legacy, err := ssh.NewSignerWithAlgorithms(algSigner, []string{ssh.KeyAlgoRSA})
	if err != nil {
		t.Fatal(err)
	}
	ps := startProbeSSHD(t, legacy)

	info, err := ProbeSSHHostKey(context.Background(), ps.addr)
	if err != nil {
		t.Fatalf("probe legacy ssh-rsa-only sshd: %v", err)
	}
	if info.Algorithm != ssh.KeyAlgoRSA {
		t.Fatalf("algorithm %q, want %q", info.Algorithm, ssh.KeyAlgoRSA)
	}
	if want := ssh.FingerprintSHA256(ks.rsa.PublicKey()); info.Fingerprint != want {
		t.Fatalf("fingerprint %q, want %q", info.Fingerprint, want)
	}
}

// TestProbeSSHHostKeyECDSAOnlyFailsHonestly: a server offering ONLY host
// key types PocketShell clients never request cannot be paired — the
// failure must say so explicitly instead of pinning an unverifiable key.
func TestProbeSSHHostKeyECDSAOnlyFailsHonestly(t *testing.T) {
	ks := generateProbeHostKeys(t)
	ps := startProbeSSHD(t, ks.ecdsa)

	info, err := ProbeSSHHostKey(context.Background(), ps.addr)
	if err == nil {
		t.Fatalf("ECDSA-only sshd must fail enrollment probing; got info %+v", info)
	}
	if info != nil {
		t.Fatalf("failed probe returned key info %+v", info)
	}
	if !strings.Contains(err.Error(), "offers none of the enrollment host key algorithms") {
		t.Fatalf("error does not name the honest failure:\n%v", err)
	}
	if !strings.Contains(err.Error(), "ecdsa-sha2-nistp256") {
		t.Fatalf("error does not name the server's actual offer:\n%v", err)
	}
}

func TestProbeSSHHostKeyRejectsNonLoopback(t *testing.T) {
	for _, addr := range []string{"10.1.2.3:22", "192.168.1.1:22", "ssh.example.invalid:22", "127.0.0.1"} {
		info, err := ProbeSSHHostKey(context.Background(), addr)
		if err == nil {
			t.Fatalf("probe of %q must refuse (loopback-only contract); got %+v", addr, info)
		}
		if info != nil {
			t.Fatalf("refused probe %q returned info %+v", addr, info)
		}
	}
}

// TestSameHostKeyCanonicalComparison pins the --expect-host-key contract:
// normalization covers whitespace, the optional SHA256: prefix and base64
// padding ONLY. The digest body and key bytes are case-sensitive — a
// case-toggled fingerprint or a different valid key is a mismatch.
func TestSameHostKeyCanonicalComparison(t *testing.T) {
	ks := generateProbeHostKeys(t)
	other := generateProbeHostKeys(t).ed

	line := authorizedLine(t, ks.ed)
	fp := ssh.FingerprintSHA256(ks.ed.PublicKey()) // "SHA256:<raw std base64>"
	body := strings.TrimPrefix(fp, "SHA256:")

	cases := []struct {
		name   string
		expect string
		want   bool
	}{
		{"exact fingerprint", fp, true},
		{"lowercase prefix", "sha256:" + body, true},
		{"uppercase prefix", "SHA256:" + body, true},
		{"bare digest without prefix", body, true},
		{"padded digest", "SHA256:" + body + "=", true},
		{"surrounding whitespace", "  " + fp + "\t", true},
		{"inner whitespace after prefix", "SHA256: " + body, true},
		{"case-toggled digest body", "SHA256:" + toggleFirstBase64Letter(body), false},
		{"case-toggled bare digest", toggleFirstBase64Letter(body), false},
		{"fingerprint of a different valid key", ssh.FingerprintSHA256(other.PublicKey()), false},
		{"md5-style prefix", "MD5:" + body, false},
		{"wrong digest scheme", "sha512:" + body, false},
		{"garbage", "not-a-key", false},
		{"empty", "   ", false},
		{"authorized line exact", line, true},
		{"authorized line with comment", line + " operator@lap", true},
		{"authorized line extra whitespace", "  " + line + "  ", true},
		{"authorized line of a different key", authorizedLine(t, other), false},
		{"ecdsa line vs selected ed25519", authorizedLine(t, ks.ecdsa), false},
		{"rsa line vs selected ed25519", authorizedLine(t, ks.rsa), false},
		// A case-toggled blob that REMAINS a valid authorized_keys line
		// (key type and separator preserved) but decodes to different key
		// bytes is a mismatch — toggledBlobLine proves the validity and
		// byte-difference invariants before the comparison runs.
		{"case-toggled line blob stays valid, different key", toggledBlobLine(t, ks.ed), false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := sameHostKey(tc.expect, line, fp); got != tc.want {
				t.Fatalf("sameHostKey(%q) = %v, want %v", tc.expect, got, tc.want)
			}
		})
	}
}

// TestExpectedHostKeyRejectsMultipleAuthorizedKeyLines: the --expect-host-key
// input is ONE authorized_keys record by contract. A paste of two records
// must be refused in BOTH orders — normalization that folds lines together
// would otherwise accept the first key and silently hide the second inside
// its comment. The same ambiguity when newlines have become spaces is
// refused too. Single-line inputs, with or without a comment and with
// ordinary surrounding whitespace (including newlines around the ONE line),
// remain valid controls.
func TestExpectedHostKeyRejectsMultipleAuthorizedKeyLines(t *testing.T) {
	ks := generateProbeHostKeys(t)
	lineEd := authorizedLine(t, ks.ed)
	lineRsa := authorizedLine(t, ks.rsa)
	fpEd := ssh.FingerprintSHA256(ks.ed.PublicKey())

	t.Run("two lines, selected first", func(t *testing.T) {
		expect := lineEd + "\n" + lineRsa
		if _, err := parsePublicKeyLine(expect); err == nil {
			t.Fatal("two-record input (selected key first) parsed as one line")
		} else if !strings.Contains(err.Error(), "single authorized_keys") {
			t.Fatalf("refusal does not name the single-record contract:\n%v", err)
		}
		if sameHostKey(expect, lineEd, fpEd) {
			t.Fatal("sameHostKey accepted a two-record paste whose first record matches the selected key")
		}
	})
	t.Run("two lines, other key first", func(t *testing.T) {
		expect := lineRsa + "\n" + lineEd
		if _, err := parsePublicKeyLine(expect); err == nil {
			t.Fatal("two-record input (other key first) parsed as one line")
		}
		if sameHostKey(expect, lineEd, fpEd) {
			t.Fatal("sameHostKey accepted a two-record paste whose second record matches the selected key")
		}
	})
	t.Run("CR LF separator", func(t *testing.T) {
		expect := lineEd + "\r\n" + lineRsa
		if _, err := parsePublicKeyLine(expect); err == nil {
			t.Fatal("CRLF-separated records parsed as one line")
		}
		if sameHostKey(expect, lineEd, fpEd) {
			t.Fatal("sameHostKey accepted CRLF-separated records")
		}
	})
	t.Run("two records collapsed to one line by spaces", func(t *testing.T) {
		// A multi-key paste whose newlines became spaces is the exact
		// ambiguity single-line normalization must not launder: the second
		// record would hide in the first key's comment.
		expect := lineEd + " " + lineRsa
		if _, err := parsePublicKeyLine(expect); err == nil {
			t.Fatal("a second full key record hidden after the comment parsed as one line")
		} else if !strings.Contains(err.Error(), "single authorized_keys") {
			t.Fatalf("refusal does not name the single-record contract:\n%v", err)
		}
		if sameHostKey(expect, lineEd, fpEd) {
			t.Fatal("sameHostKey accepted a space-joined two-record paste")
		}
	})
	t.Run("control single line", func(t *testing.T) {
		if !sameHostKey(lineEd, lineEd, fpEd) {
			t.Fatal("plain single-line pin refused")
		}
	})
	t.Run("control single line with comment", func(t *testing.T) {
		expect := lineEd + " operator@lap; u2f note"
		if !sameHostKey(expect, lineEd, fpEd) {
			t.Fatalf("single line with an ordinary comment refused")
		}
	})
	t.Run("control surrounding whitespace around the one line", func(t *testing.T) {
		expect := "\n\t " + lineEd + " \n"
		if !sameHostKey(expect, lineEd, fpEd) {
			t.Fatal("surrounding whitespace around a single record refused")
		}
	})
}

// startEnrollWorld wires a real identity service (real HTTP API), a local
// in-process sshd with the given signers and a recorder that counts ANY
// HTTP request — pin refusals must happen with zero requests.
func startEnrollWorld(t *testing.T, signers ...ssh.Signer) (*probeSSHD, string, *httptest.Server, *atomic.Int64) {
	t.Helper()
	newIdentityServer(t) // real identity API is not used by these refusal paths
	ps := startProbeSSHD(t, signers...)
	token := validBrokerToken(t, time.Now())
	var requests atomic.Int64
	recorder := httptest.NewServer(http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		requests.Add(1)
		http.Error(rw, "nothing may be sent here", http.StatusInternalServerError)
	}))
	t.Cleanup(recorder.Close)
	return ps, token, recorder, &requests
}

// TestRunEnrollExpectPinMismatchFailsBeforeAnyHTTP: an operator-supplied
// pin that does not describe the SELECTED key — a different valid key, a
// case-toggled digest, or the fingerprint of a non-selected offered type —
// refuses enrollment BEFORE any HTTP request. The pin is never swapped for
// another offered key.
func TestRunEnrollExpectPinMismatchFailsBeforeAnyHTTP(t *testing.T) {
	ks := generateProbeHostKeys(t)
	other := generateProbeHostKeys(t).ed
	ps, token, recorder, requests := startEnrollWorld(t, ks.ecdsa, ks.rsa, ks.ed)

	fp := ssh.FingerprintSHA256(ks.ed.PublicKey())
	body := strings.TrimPrefix(fp, "SHA256:")
	cases := []struct {
		name   string
		expect string
	}{
		{"fingerprint of a different valid key", ssh.FingerprintSHA256(other.PublicKey())},
		{"case-toggled digest of the selected key", "SHA256:" + toggleFirstBase64Letter(body)},
		{"authorized line of a different key", authorizedLine(t, other)},
		{"fingerprint of the non-selected ECDSA offer", ssh.FingerprintSHA256(ks.ecdsa.PublicKey())},
		{"fingerprint of the non-selected RSA offer", ssh.FingerprintSHA256(ks.rsa.PublicKey())},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			_, err := RunEnroll(context.Background(), EnrollOptions{
				Dir:           dir,
				Server:        recorder.URL,
				Token:         token,
				DeviceID:      "dev-pin-refused",
				SSHHost:       ps.addr,
				ExpectHostKey: tc.expect,
				InsecureDev:   true, // recorder is plain http; TLS stays verified
				Stdout:        io.Discard,
				Stderr:        io.Discard,
			})
			if err == nil {
				t.Fatal("enroll succeeded with a wrong --expect-host-key")
			}
			if !strings.Contains(err.Error(), "does NOT match --expect-host-key") {
				t.Fatalf("refusal does not name the expect-pin mismatch:\n%v", err)
			}
			if n := requests.Load(); n != 0 {
				t.Fatalf("%d HTTP requests left the machine on an expect-pin refusal", n)
			}
			if _, cfgErr := LoadConfig(dir); cfgErr == nil {
				t.Fatal("config was written despite the expect-pin refusal")
			}
		})
	}
}

// TestRunEnrollUnsupportedHostAlgorithmFailsBeforeHTTP: an sshd offering
// only unsupported host key types fails the PROBE honestly — no key is
// pinned and no request is sent.
func TestRunEnrollUnsupportedHostAlgorithmFailsBeforeHTTP(t *testing.T) {
	ks := generateProbeHostKeys(t)
	ps, token, recorder, requests := startEnrollWorld(t, ks.ecdsa)

	_, err := RunEnroll(context.Background(), EnrollOptions{
		Dir:         t.TempDir(),
		Server:      recorder.URL,
		Token:       token,
		DeviceID:    "dev-ecdsa-only",
		SSHHost:     ps.addr,
		InsecureDev: true,
		Stdout:      io.Discard,
		Stderr:      io.Discard,
	})
	if err == nil {
		t.Fatal("enroll succeeded against an ECDSA-only sshd")
	}
	if !strings.Contains(err.Error(), "offers none of the enrollment host key algorithms") {
		t.Fatalf("error does not name the unsupported-host-algorithm failure:\n%v", err)
	}
	if n := requests.Load(); n != 0 {
		t.Fatalf("%d HTTP requests left the machine on an unsupported host algorithm", n)
	}
}

// TestRunEnrollExpectPinSelectedKeyEnrolls: supplying the fingerprint of
// the key the browser-supported policy SELECTS (possibly normalized) is
// accepted, and the pinned registry line is the selected key's.
func TestRunEnrollExpectPinSelectedKeyEnrolls(t *testing.T) {
	ks := generateProbeHostKeys(t)
	_, ts, mem := newIdentityServer(t)
	ps := startProbeSSHD(t, ks.ecdsa, ks.rsa, ks.ed)
	token := validBrokerToken(t, time.Now())

	fp := ssh.FingerprintSHA256(ks.ed.PublicKey())
	body := strings.TrimPrefix(fp, "SHA256:")
	cases := []struct {
		name     string
		expect   string
		deviceID string
	}{
		{"exact selected fingerprint", fp, "dev-pin-ok-1"},
		{"normalized selected fingerprint", "  sha256: " + body + "=", "dev-pin-ok-2"},
		{"selected authorized line", authorizedLine(t, ks.ed) + " home", "dev-pin-ok-3"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			dir := t.TempDir()
			confirmed, err := RunEnroll(context.Background(), EnrollOptions{
				Dir:           dir,
				Server:        ts.URL,
				Token:         token,
				DeviceID:      tc.deviceID,
				SSHHost:       ps.addr,
				ExpectHostKey: tc.expect,
				InsecureDev:   true, // httptest identity API is plain http; TLS stays verified
				Stdout:        io.Discard,
				Stderr:        io.Discard,
			})
			if err != nil {
				t.Fatalf("enroll with the SELECTED key's pin: %v", err)
			}
			if confirmed != tc.deviceID {
				t.Fatalf("confirmed %q, want %q", confirmed, tc.deviceID)
			}
			dev, err := mem.GetDevice(tc.deviceID)
			if err != nil {
				t.Fatalf("device not registered: %v", err)
			}
			if want := authorizedLine(t, ks.ed); dev.SSHHostKey != want {
				t.Fatalf("registry pinned\n got %s\nwant the selected Ed25519 line %s", dev.SSHHostKey, want)
			}
		})
	}
}
