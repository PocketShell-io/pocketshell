package hostagent

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"
)

// ProductionBrokerIssuer is the only issuer whose credentials the CLI
// sends to the gateway in production: the PocketShell sync broker, which
// mints short-lived RS256 routing tokens scoped to the gateway (see
// docs/routing-credentials.md). Google ID tokens — and any other issuer —
// are refused LOCALLY, before any bytes leave the machine, so a credential
// with sync authority can never be disclosed to the gateway (finding F-09).
const ProductionBrokerIssuer = "https://a7sota2qic.execute-api.eu-west-1.amazonaws.com"

// Broker audience/scope/lifetime contract (docs/routing-credentials.md).
const (
	BrokerAudience    = "pocketshell-gateway"
	BrokerScope       = "pocketshell.gateway"
	BrokerMaxLifetime = 5 * time.Minute
	// brokerLeeway covers clock skew in the local time checks. It loosens
	// nothing structural: the gateway verifies the signature and enforces
	// its own (tighter) policy on arrival.
	brokerLeeway = 30 * time.Second
)

// BrokerPolicy is the local shape a sendable credential must have.
type BrokerPolicy struct {
	Issuer      string
	Audience    string
	Scope       string
	MaxLifetime time.Duration
}

// ProductionBrokerPolicy is the policy for production enrollment: broker
// issuer, gateway audience, gateway scope, 5-minute maximum lifetime.
func ProductionBrokerPolicy() BrokerPolicy {
	return BrokerPolicy{
		Issuer:      ProductionBrokerIssuer,
		Audience:    BrokerAudience,
		Scope:       BrokerScope,
		MaxLifetime: BrokerMaxLifetime,
	}
}

// GoogleIssuers are the known Google ID-token issuers, named so the local
// refusal can say precisely why a credential was not sent.
var GoogleIssuers = []string{
	"https://accounts.google.com",
	"accounts.google.com",
}

// brokerClaims are the JWT payload fields the local guard inspects. These
// are UNVERIFIED claims: this guard is a disclosure gate, not
// authentication. It prevents the CLI from transmitting credentials that
// do not even claim to be gateway routing tokens; the gateway alone
// verifies the signature and enforces the authoritative policy.
type brokerClaims struct {
	Issuer   string          `json:"iss"`
	Audience json.RawMessage `json:"aud"`
	Expiry   json.Number     `json:"exp"`
	IssuedAt json.Number     `json:"iat"`
	Scope    string          `json:"scope"`
}

// ValidateBrokerCredential checks — strictly LOCALLY, without network I/O
// and without signature verification — that token has the shape of a
// sync-broker routing credential for this gateway: three JWT segments, the
// exact broker issuer/audience/scope and a bounded, currently-valid
// lifetime. Anything else (including any Google ID token) is refused with
// an error, so RunEnroll never transmits it. A token that passes still
// proves nothing by itself: the gateway's verifier decides.
func ValidateBrokerCredential(token string, policy BrokerPolicy, now time.Time) error {
	if strings.TrimSpace(token) == "" {
		return errors.New("refusing to send: no credential provided (get a gateway token from the PocketShell web UI)")
	}
	parts := strings.Split(strings.TrimSpace(token), ".")
	if len(parts) != 3 {
		return errors.New("refusing to send: credential is not a JWT (want the short-lived gateway token from the PocketShell web UI)")
	}
	var header struct {
		Alg string `json:"alg"`
		Kid string `json:"kid"`
	}
	if err := decodeJWTPart(parts[0], &header); err != nil {
		return fmt.Errorf("refusing to send: unreadable JWT header: %w", err)
	}
	if header.Alg == "" || strings.EqualFold(header.Alg, "none") {
		return errors.New("refusing to send: unsigned JWT (alg none) is never a valid gateway credential")
	}
	var claims brokerClaims
	if err := decodeJWTPart(parts[1], &claims); err != nil {
		return fmt.Errorf("refusing to send: unreadable JWT payload: %w", err)
	}
	if claims.Issuer == "" {
		return errors.New("refusing to send: credential has no issuer claim")
	}
	for _, gi := range GoogleIssuers {
		if strings.EqualFold(claims.Issuer, gi) {
			return fmt.Errorf("refusing to send: this is a GOOGLE ID TOKEN (iss %s); it carries sync authority and must never be sent to the gateway — use the short-lived gateway token from the PocketShell web UI", claims.Issuer)
		}
	}
	if claims.Issuer != policy.Issuer {
		return fmt.Errorf("refusing to send: credential issuer %q is not the gateway broker %q", claims.Issuer, policy.Issuer)
	}
	aud, err := audienceValue(claims.Audience)
	if err != nil {
		return fmt.Errorf("refusing to send: %v", err)
	}
	if aud != policy.Audience {
		return fmt.Errorf("refusing to send: credential audience %q is not %q", aud, policy.Audience)
	}
	if claims.Scope != policy.Scope {
		return fmt.Errorf("refusing to send: credential scope %q is not %q", claims.Scope, policy.Scope)
	}
	exp, err := claims.Expiry.Float64()
	if err != nil || exp <= 0 {
		return errors.New("refusing to send: credential has no numeric exp claim")
	}
	iat, err := claims.IssuedAt.Float64()
	if err != nil || iat <= 0 {
		return errors.New("refusing to send: credential has no numeric iat claim")
	}
	if lifetime := time.Duration((exp-iat)*float64(time.Second)) + brokerLeeway; lifetime > policy.MaxLifetime+brokerLeeway {
		return fmt.Errorf("refusing to send: credential lifetime %s exceeds the broker maximum %s", lifetime-truncate(brokerLeeway), policy.MaxLifetime)
	}
	if now.Add(brokerLeeway).After(time.Unix(int64(exp), 0)) {
		return errors.New("refusing to send: gateway credential has expired; request a fresh token from the PocketShell web UI")
	}
	return nil
}

func decodeJWTPart(s string, v any) error {
	b, err := base64.RawURLEncoding.DecodeString(s)
	if err != nil {
		return err
	}
	return json.Unmarshal(b, v)
}

// audienceValue accepts the string form (the broker's issuance contract)
// and rejects arrays and anything else, so a credential minted for another
// audience set is refused rather than guessed at.
func audienceValue(raw json.RawMessage) (string, error) {
	if len(raw) == 0 {
		return "", errors.New("credential has no aud claim")
	}
	var s string
	if err := json.Unmarshal(raw, &s); err != nil {
		return "", errors.New("credential aud claim is not a string")
	}
	return s, nil
}

func truncate(d time.Duration) time.Duration {
	if d < 0 {
		return 0
	}
	return d
}
