package hostagent

import (
	"crypto/rand"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"unsafe"

	"golang.org/x/sys/windows"
)

func currentUserSID() (*windows.SID, error) {
	token, err := windows.OpenCurrentProcessToken()
	if err != nil {
		return nil, err
	}
	defer token.Close()
	user, err := token.GetTokenUser()
	if err != nil {
		return nil, err
	}
	return user.User.Sid.Copy()
}

func protectedDescriptor() (*windows.SECURITY_DESCRIPTOR, error) {
	sid, err := currentUserSID()
	if err != nil {
		return nil, err
	}
	// Numeric SIDs avoid localized account names. P disables inheritance.
	return windows.SecurityDescriptorFromString("O:" + sid.String() + "D:P(A;;FA;;;" + sid.String() + ")(A;;FA;;;SY)(A;;FA;;;BA)")
}

func createProtectedTemp(dir string) (*os.File, error) {
	sd, err := protectedDescriptor()
	if err != nil {
		return nil, err
	}
	sa := windows.SecurityAttributes{Length: uint32(unsafe.Sizeof(windows.SecurityAttributes{})), SecurityDescriptor: sd}
	for i := 0; i < 10; i++ {
		var nonce [16]byte
		if _, err := rand.Read(nonce[:]); err != nil {
			return nil, err
		}
		name := filepath.Join(dir, fmt.Sprintf(".protected-%x", nonce))
		p, err := windows.UTF16PtrFromString(name)
		if err != nil {
			return nil, err
		}
		// Apply the DACL in CreateFile, before any content or handle is exposed.
		h, err := windows.CreateFile(p, windows.GENERIC_READ|windows.GENERIC_WRITE|windows.READ_CONTROL, 0, &sa, windows.CREATE_NEW, windows.FILE_ATTRIBUTE_NORMAL, 0)
		runtime.KeepAlive(sd)
		if err == windows.ERROR_FILE_EXISTS || err == windows.ERROR_ALREADY_EXISTS {
			continue
		}
		if err != nil {
			return nil, err
		}
		f := os.NewFile(uintptr(h), name)
		if err := validateProtectedFile(f); err != nil {
			f.Close()
			os.Remove(name)
			return nil, err
		}
		return f, nil
	}
	return nil, fmt.Errorf("cannot create protected temporary file")
}

func validateProtectedFile(f *os.File) error {
	st, err := f.Stat()
	if err != nil {
		return err
	}
	if !st.Mode().IsRegular() {
		return fmt.Errorf("%s: protected file must be regular", f.Name())
	}
	sd, err := windows.GetSecurityInfo(windows.Handle(f.Fd()), windows.SE_FILE_OBJECT, windows.OWNER_SECURITY_INFORMATION|windows.DACL_SECURITY_INFORMATION)
	if err != nil {
		return fmt.Errorf("%s: query file ACL: %w", f.Name(), err)
	}
	if err := validateProtectedDescriptor(sd); err != nil {
		return fmt.Errorf("%s: unsafe file ACL: %w", f.Name(), err)
	}
	return nil
}

func validateProtectedDescriptor(sd *windows.SECURITY_DESCRIPTOR) error {
	user, err := currentUserSID()
	if err != nil {
		return err
	}
	allowed := func(sid *windows.SID) bool {
		return sid != nil && (windows.EqualSid(sid, user) || sid.IsWellKnown(windows.WinLocalSystemSid) || sid.IsWellKnown(windows.WinBuiltinAdministratorsSid))
	}
	owner, _, err := sd.Owner()
	if err != nil || !allowed(owner) {
		return fmt.Errorf("owner must be current user, SYSTEM or Administrators")
	}
	control, _, err := sd.Control()
	if err != nil || control&windows.SE_DACL_PROTECTED == 0 {
		return fmt.Errorf("DACL must disable inheritance")
	}
	dacl, _, err := sd.DACL()
	if err != nil || dacl == nil || dacl.AceCount == 0 {
		return fmt.Errorf("missing, null or empty DACL")
	}
	for i := uint32(0); i < uint32(dacl.AceCount); i++ {
		var ace *windows.ACCESS_ALLOWED_ACE
		if err := windows.GetAce(dacl, i, &ace); err != nil {
			return err
		}
		// Fail closed on unknown/object/callback/deny ACEs as well as inherited
		// ACEs. Even read-only grants to another principal expose the key.
		if ace.Header.AceType != windows.ACCESS_ALLOWED_ACE_TYPE || ace.Header.AceFlags != 0 {
			return fmt.Errorf("unsupported or inherited ACE")
		}
		sid := (*windows.SID)(unsafe.Pointer(&ace.SidStart))
		if !allowed(sid) {
			return fmt.Errorf("ACE grants access to an untrusted principal")
		}
	}
	return nil
}
