package hostagent

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

// ValidateLoopback enforces the hard host-agent rule: the SSH destination
// must be a loopback address on this machine. Literal loopback IPs
// (127.0.0.0/8, ::1) and "localhost" (only when it resolves exclusively to
// loopback) are accepted; everything else — other hostnames, private
// ranges, the wildcard address — is rejected. --insecure-dev never lifts
// this: the tunnel's trust boundary is that the gateway can only ever
// reach an SSH endpoint bound to the host itself.
func ValidateLoopback(addr string) (string, error) {
	return validateLoopbackAddr(context.Background(), addr)
}

// hostResolver is the slice of *net.Resolver the loopback validation needs.
type hostResolver interface {
	LookupHost(ctx context.Context, host string) ([]string, error)
}

// probeResolver is the resolver the probe's localhost validation resolves
// "localhost" with. It exists only so tests can install a constrained
// resolver seam that observes the probe's derived deadline and consumes
// budget; production always uses net.DefaultResolver and the behavior is
// identical.
var probeResolver hostResolver = net.DefaultResolver

// validateLoopbackAddr is ValidateLoopback with a context honored while
// resolving "localhost", so a caller that bounds its whole operation (the
// enrollment probe) cannot hang past its budget inside the resolver. The
// security contract is identical: loopback only, never more targets.
func validateLoopbackAddr(ctx context.Context, addr string) (string, error) {
	host, port, err := net.SplitHostPort(addr)
	if err != nil {
		return "", fmt.Errorf("ssh host %q must be host:port: %w", addr, err)
	}
	if port == "" {
		return "", fmt.Errorf("ssh host %q has an empty port", addr)
	}
	if p, perr := strconv.Atoi(port); perr != nil || p < 1 || p > 65535 {
		return "", fmt.Errorf("ssh host port %q out of range", port)
	}
	if host == "" {
		return "", fmt.Errorf("ssh host %q has an empty host", addr)
	}
	if strings.EqualFold(host, "localhost") {
		// Go's resolver answers "localhost" from /etc/hosts without ever
		// consulting the context, so a canceled/expired bound would not be
		// honored. Check it here: the whole-probe bound includes the
		// resolution phase, and the resolver itself gets the context for
		// lookups that do hang (DNS paths abort on it).
		if err := ctx.Err(); err != nil {
			return "", fmt.Errorf("localhost does not resolve: %w", err)
		}
		addrs, err := probeResolver.LookupHost(ctx, "localhost")
		if err != nil || len(addrs) == 0 {
			return "", fmt.Errorf("localhost does not resolve: %w", err)
		}
		for _, a := range addrs {
			ip, err := netip.ParseAddr(a)
			if err != nil || !ip.IsLoopback() {
				return "", fmt.Errorf("localhost resolves to non-loopback %q; refusing", a)
			}
		}
		return net.JoinHostPort("127.0.0.1", port), nil
	}
	ip, err := netip.ParseAddr(host)
	if err != nil {
		return "", fmt.Errorf("ssh host %q is not a loopback literal; hostnames other than localhost are not accepted", host)
	}
	if !ip.IsLoopback() {
		return "", fmt.Errorf("ssh host %q is not a loopback address", host)
	}
	return net.JoinHostPort(ip.String(), port), nil
}

// BrowserHostKeyAlgorithms returns the enrollment probe's host-key
// negotiation policy: exactly the ordered list the PocketShell browser SSH
// client offers when connecting to the home machine through the tunnel.
// SSH host-key negotiation is client-preference-dominated (the server's
// list is only searched for the client's first supported entry), so the
// key this probe selects is the key a browser client will request. The
// fingerprint displayed and pinned at enrollment therefore comes from THIS
// selection, never from the library default:
//
//	ssh-ed25519   strong preference (browser first choice)
//	rsa-sha2-512  strong RSA
//	rsa-sha2-256  strong RSA
//	ssh-rsa       legacy sshd compatibility (existing, intentional policy)
//
// ECDSA and certificate host algorithms are deliberately absent: the
// browser never offers them, and x/crypto's default client order prefers
// ECDSA — without this explicit policy a probe against an ordinary
// multi-key sshd (ECDSA + Ed25519 + RSA) would pin the ECDSA fingerprint
// while every browser client requests the Ed25519 key. The returned slice
// is a fresh copy; callers may treat it as immutable.
func BrowserHostKeyAlgorithms() []string {
	return []string{ssh.KeyAlgoED25519, ssh.KeyAlgoRSASHA512, ssh.KeyAlgoRSASHA256, ssh.KeyAlgoRSA}
}

// errProbeComplete is returned by the probe's HostKeyCallback to stop the
// SSH handshake deliberately. x/crypto invokes the host-key callback only
// AFTER the presented key's signature has been verified as part of the key
// exchange (handshake.go: verifyHostKeySignature, then hostKeyCallback), so
// the key captured at that moment is the signature-VERIFIED selected host
// key — and because the callback error aborts the handshake, NewClientConn
// never reaches user authentication (x/crypto's clientAuthenticate would
// otherwise attempt the SSH "none" method even with no configured Auth
// methods). Only errors.Is(err, errProbeComplete) from NewClientConn is
// accepted as the probe's success path.
var errProbeComplete = errors.New("pocketshell: verified host key captured; probe stops before user authentication")

// probeKeyCallback records the signature-verified host key and stops the
// handshake with errProbeComplete. Enrollment is the trust-on-first-use
// moment: the fingerprint is displayed for the operator to verify, and the
// value is pinned at the gateway for clients.
func probeKeyCallback(out *ssh.PublicKey) ssh.HostKeyCallback {
	return func(hostname string, remote net.Addr, key ssh.PublicKey) error {
		*out = key
		return errProbeComplete
	}
}

// SSHHostKeyInfo describes the probed local sshd host key.
type SSHHostKeyInfo struct {
	// AuthorizedKey is the single-line authorized_keys representation
	// (algorithm base64 [comment]) pinned at enrollment.
	AuthorizedKey string
	// Fingerprint is "SHA256:<base64>" like ssh-keygen -lf.
	Fingerprint string
	Algorithm   string
}

// probeHandshakeBudget bounds the ENTIRE probe — localhost resolution, TCP
// dial and SSH handshake — with a fixed cap. A caller deadline earlier than
// the cap still wins; a caller deadline later than the cap never extends
// it. The bounded context is derived BEFORE the loopback validation so a
// long/background caller cannot spend unbounded time resolving localhost
// and then receive a fresh ten seconds for dial/handshake.
const probeHandshakeBudget = 10 * time.Second

// ProbeSSHHostKey performs a real SSH handshake against addr (which must
// validate as loopback) purely to retrieve the host key. The handshake is
// deliberately stopped at the signature-verified host-key callback: the
// probe is keyless AND reaches no user authentication at all — not even the
// SSH "none" method x/crypto attempts for auth-less clients — and it never
// opens a channel; the connection is closed immediately after.
//
// One bounded context — deadline min(probeHandshakeBudget, the caller's) —
// covers the WHOLE operation: the localhost resolution inside loopback
// validation, the TCP dial, the handshake and the final completion gate.
// Cancelation closes the connection and returns promptly, even
// mid-handshake, and ClientConfig.Timeout is not relied upon (it does not
// apply to an already-connected NewClientConn).
func ProbeSSHHostKey(ctx context.Context, addr string) (*SSHHostKeyInfo, error) {
	probeCtx, cancel := context.WithTimeout(ctx, probeHandshakeBudget)
	defer cancel()

	addr, err := validateLoopbackAddr(probeCtx, addr)
	if err != nil {
		return nil, err
	}

	d := net.Dialer{}
	conn, err := d.DialContext(probeCtx, "tcp", addr)
	if err != nil {
		return nil, fmt.Errorf("dial %s: %w", addr, err)
	}
	// Socket-level cap over the whole handshake: probeCtx.Deadline() is
	// exactly min(budget, caller deadline). A stalled peer ends the probe
	// here even without cancelation.
	if dl, ok := probeCtx.Deadline(); ok {
		_ = conn.SetDeadline(dl)
	}
	// Cancelation must interrupt a handshake stalled mid-read promptly:
	// the watchdog closes the socket when probeCtx is done. stop releases
	// it on every return path; conn.Close is idempotent (the deferred close
	// below may fire on an already-closed socket).
	stopWatch := context.AfterFunc(probeCtx, func() { _ = conn.Close() })
	defer stopWatch()
	defer conn.Close()

	var key ssh.PublicKey
	cfg := &ssh.ClientConfig{
		User: "probe", // handshake only; never authenticated
		// Negotiate exactly the browser-supported policy so the key pinned
		// here is the key browser clients request; see
		// BrowserHostKeyAlgorithms for the compatibility reasoning.
		HostKeyAlgorithms: BrowserHostKeyAlgorithms(),
		HostKeyCallback:   probeKeyCallback(&key),
		// Deliberately no Auth methods and no Timeout: the handshake stops
		// at the verified host-key callback (errProbeComplete) and the
		// whole probe is bounded by probeCtx — ClientConfig.Timeout would
		// not bound this already-connected NewClientConn anyway.
	}
	_, _, _, err = ssh.NewClientConn(conn, addr, cfg)
	if err != nil {
		// Only the expected deliberate-stop path may succeed — and only
		// with a key actually captured through the signature-verified
		// callback. Any other error is refused outright, even if a key
		// variable happens to be non-empty; an unverified advertised key
		// is never trusted.
		if !errors.Is(err, errProbeComplete) {
			var algoErr *ssh.AlgorithmNegotiationError
			if errors.As(err, &algoErr) && algoErr.What == "host key" {
				// Honest failure, no silent fallback: the local sshd offers
				// only host key types PocketShell clients never request
				// (e.g. an ECDSA-only sshd). Pairing cannot work here.
				return nil, fmt.Errorf(
					"local sshd at %s offers none of the enrollment host key algorithms %v (browser-compatible policy); server offered %v",
					addr, BrowserHostKeyAlgorithms(), algoErr.RequestedAlgorithms)
			}
			return nil, fmt.Errorf("ssh handshake with %s: %w", addr, err)
		}
		if key == nil {
			return nil, fmt.Errorf("ssh handshake with %s stopped without a verified host key: %w", addr, err)
		}
	} else {
		// Unreachable by construction (the callback always errors); fail
		// closed rather than trust a handshake that ran past the stop.
		return nil, errors.New("ssh handshake with " + addr + " completed beyond the probe's verified-host-key stop")
	}
	// Final gate on the SAME context that bounded resolution, dial and
	// handshake: if the probe's bound is already done, a completed key
	// capture must not be reported as success merely because the sentinel
	// won a race against the deadline.
	if err := probeCtx.Err(); err != nil {
		return nil, fmt.Errorf("ssh handshake with %s reached the verified host key but the probe's bound is already done: %w", addr, err)
	}
	line := strings.TrimSpace(string(ssh.MarshalAuthorizedKey(key)))
	return &SSHHostKeyInfo{
		AuthorizedKey: line,
		Fingerprint:   ssh.FingerprintSHA256(key),
		Algorithm:     key.Type(),
	}, nil
}
