package hostagent

// Run-path peer-diagnostic WITHHOLDING (run-credential-output-final): every
// byte of gateway rejection diagnostics on the run path — the JSON ErrMsg
// message at either handshake stage, the raw WebSocket close reason, and
// unrecognized ErrMsg codes — is peer-controlled, and a misbehaving
// configured gateway or on-path proxy legitimately saw the enrollment
// request's Authorization bearer and can echo that credential back through
// any of them: wholly, cut to any length (printable bytes up to 256 survive
// readHandshakeMsg; at most 123 bytes fit a close-frame reason), or
// re-encoded. No practical redaction covers every partial or reversible
// encoding of a known credential, and no known-credential redaction is
// possible for a token the agent never stores, so the agent withholds the
// peer bytes STRUCTURALLY: nothing from an ErrMsg message or a close reason
// is retained at all, recognized wire codes render only as their canonical
// literals, unrecognized codes render as a fixed local phrase, and fatal
// verdicts keep the close-code + canonical-verdict status that keeps triage
// useful. The enroll path made the same call earlier (postJSON fixed safe
// status, F2 repair); this closes the run path the same way.
//
// These tests pin that contract: no reflected credential (whole, any usable
// prefix/suffix, or reversible re-encoding) and no hostile payload in any
// form — not even the old sanitizer's escaped rendering — may reach the
// rendered diagnostics, while the typed fatal/transient classification, the
// stage-aware "challenge" handling and the bounded reconnect stay exactly
// as the FH-1 tests pinned them.

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// bearerShapedToken mints a broker-shaped credential of the same shape
// enrollment transmits in the Authorization header; the fixtures below have
// the hostile gateway reflect these exact bytes back through rejection
// diagnostics.
func bearerShapedToken(jtiPad string) string {
	enc := base64.RawURLEncoding.EncodeToString
	head := enc([]byte(`{"alg":"RS256","kid":"k"}`))
	payload := enc([]byte(`{"iss":"https://gateway-broker.example","aud":"pocketshell-gateway",` +
		`"scope":"pocketshell.gateway","exp":9999999999,"iat":1,"jti":"` + jtiPad + `"}`))
	return head + "." + payload + "." + enc([]byte("sig"))
}

// longReflectedBearer exceeds every historical rendering bound (the 256-byte
// readHandshakeMsg cap): under the old bound-then-escape renderer its prefix
// leaked verbatim into CLI output.
var longReflectedBearer = bearerShapedToken(strings.Repeat("run-canary-", 40))

// shortReflectedBearer is below all of them: under the old renderer it was
// printed whole.
var shortReflectedBearer = bearerShapedToken("short")

// hostileJSONReason keeps a control-bearing payload in play: withholding
// must keep terminal escapes out of the output in ANY form, including the
// escaped rendering the previous sanitizer produced.
const hostileJSONReason = "\x1b[31mFORGED exit\x1b[0m\npocketshell-link exited: pwned\r\n" +
	"\x1b]0;evil\x07\x1b[3;H\ta\x7f\u0085\u202erev\u2066erse\u202c"

// hostileCloseText is the close-frame variant (raw payload; gorilla only
// requires valid UTF-8, so the reachable route carries UTF-8 controls).
const hostileCloseText = "\x1b[2J\x1b[H CLEAR\n\x1b]0;evil\x07tab\there\x7f\u0085\u202ebidi\u202c"

// assertTerminalSafe fails if s contains any character that must never reach
// a terminal verbatim from peer-controlled diagnostic text. Newlines are
// allowed only where the local formatter owns them (CLI stderr line
// endings) — never inside an error string itself.
func assertTerminalSafe(t *testing.T, s string, allowNewline bool) {
	t.Helper()
	for i, r := range s {
		switch {
		case r == '\n':
			if !allowNewline {
				t.Fatalf("byte %d: raw newline (forged line) in rendered diagnostics %q", i, s)
			}
		case r < 0x20, r == 0x7f, r >= 0x80 && r <= 0x9f,
			r == 0x061c, r == 0x200e, r == 0x200f,
			r >= 0x202a && r <= 0x202e, r >= 0x2066 && r <= 0x2069:
			t.Fatalf("byte %d: raw terminal control U+%04X in rendered diagnostics %q", i, r, s)
		}
	}
}

// assertBearerWithheld fails if any usable piece of bearer — the whole
// value, any contiguous prefix or suffix of 12+ bytes, or a reversible
// re-encoding — appears in out. Twelve bytes is far below any diagnostic
// utility threshold: even that much is correlatable credential material,
// and the old bound-then-escape renderer leaked 256-byte prefixes.
func assertBearerWithheld(t *testing.T, out, bearer string) {
	t.Helper()
	for n := 12; n <= len(bearer); n++ {
		if strings.Contains(out, bearer[:n]) {
			t.Fatalf("credential prefix of %d bytes leaked into %q", n, cutForTest(out))
		}
		if strings.Contains(out, bearer[len(bearer)-n:]) {
			t.Fatalf("credential suffix of %d bytes leaked into %q", n, cutForTest(out))
		}
	}
	for _, enc := range []string{
		url.QueryEscape(bearer),
		base64.StdEncoding.EncodeToString([]byte(bearer)),
		base64.URLEncoding.EncodeToString([]byte(bearer)),
	} {
		if strings.Contains(out, enc) {
			t.Fatalf("re-encoded credential variant leaked: %q", cutForTest(enc))
		}
	}
}

// cutForTest bounds a string for failure messages.
func cutForTest(s string) string {
	if len(s) <= 300 {
		return s
	}
	return s[:300] + "…"
}

// fixtureBearerShapes sanity-checks the two credential shapes before the
// tests rely on them.
func fixtureBearerShapes(t *testing.T) {
	t.Helper()
	if len(longReflectedBearer) <= 256 {
		t.Fatalf("fixture: long bearer is only %d bytes; want the reflected-prefix shape past the old 256-byte bound", len(longReflectedBearer))
	}
	if len(shortReflectedBearer) >= 256 || len(shortReflectedBearer) <= 12 {
		t.Fatalf("fixture: short bearer is %d bytes; want the prints-whole shape (13..255)", len(shortReflectedBearer))
	}
}

// hostileRejectMode picks where the hostile gateway delivers its verdict.
type hostileRejectMode int

const (
	rejectBeforeChallenge hostileRejectMode = iota // ErrMsg instead of the challenge
	rejectAfterProof                               // ErrMsg instead of the ok ack
)

// hostileGateway is a WS endpoint that speaks the agent handshake exactly
// like tunnel.Service up to the chosen stage and then rejects EVERY
// connection with the configured peer-controlled payload: an ErrMsg text
// frame and/or an application close frame.
type hostileGateway struct {
	srv   *httptest.Server
	url   string
	conns chan int
}

func (gw *hostileGateway) connectionsWithin(t *testing.T, n int, d time.Duration) {
	t.Helper()
	deadline := time.After(d)
	for seen := 0; seen < n; {
		select {
		case <-gw.conns:
			seen++
		case <-deadline:
			t.Fatalf("hostile gateway saw only %d connections, wanted %d", seen, n)
			return
		}
	}
}

// startHostileGateway serves one rejection shape to every connection.
// errJSON (may be nil) is the raw ErrMsg JSON; closeCode/closeText (0 = no
// close frame) form the application close frame.
func startHostileGateway(t *testing.T, mode hostileRejectMode, deviceID string, key ed25519.PrivateKey, errJSON []byte, closeCode int, closeText string) *hostileGateway {
	t.Helper()
	gw := &hostileGateway{conns: make(chan int, 32)}
	var conns atomic.Int64
	up := websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}
	gw.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ws, err := up.Upgrade(w, r, nil)
		if err != nil {
			return
		}
		defer ws.Close()
		n := int(conns.Add(1))
		select {
		case gw.conns <- n:
		default:
		}
		_ = ws.SetWriteDeadline(time.Now().Add(2 * time.Second))
		if mode == rejectAfterProof {
			if !hostileHandshake(t, ws, deviceID, key) {
				return
			}
		}
		if errJSON != nil {
			_ = ws.WriteMessage(websocket.TextMessage, errJSON)
		}
		if closeCode != 0 {
			_ = ws.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(closeCode, closeText))
		}
	}))
	t.Cleanup(gw.srv.Close)
	gw.url = "ws" + gw.srv.URL[len("http"):]
	return gw
}

// hostileHandshake sends the challenge and verifies the agent's signed auth
// (the same transcript rules as fakeGateway). It reports whether the
// handshake completed so the rejection lands at the post-proof stage.
func hostileHandshake(t *testing.T, ws *websocket.Conn, deviceID string, key ed25519.PrivateKey) bool {
	t.Helper()
	nonce, err := randomNonceForTest(32)
	if err != nil {
		return false
	}
	connNonce, err := randomNonceForTest(32)
	if err != nil {
		return false
	}
	wire := tunnel.HostChallenge{
		Type: "challenge", V: tunnel.ProtocolVersion,
		ChallengeID: "gw-hostile-" + time.Now().Format("150405.000000000"),
		Nonce:       nonce, ConnectionNonce: connNonce,
		Server: "127.0.0.1", Role: identity.RoleHost,
		Protocol:  tunnel.ProtocolTunnel,
		ExpiresAt: time.Now().Add(time.Minute).Unix(),
	}
	if err := ws.WriteMessage(websocket.TextMessage, mustJSONForTest(wire)); err != nil {
		return false
	}
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		return false
	}
	var auth tunnel.HostAuth
	if err := json.Unmarshal(raw, &auth); err != nil {
		return false
	}
	idCh, err := wire.ToIdentityChallenge(deviceID)
	if err != nil {
		return false
	}
	sig, err := base64.StdEncoding.DecodeString(auth.Signature)
	if err != nil || identity.Verify(pubOf(key), idCh, sig) != nil || auth.DeviceID != deviceID {
		return false
	}
	_ = ws.SetReadDeadline(time.Time{})
	return true
}

func newHostileAgent(t *testing.T, gw *hostileGateway, key ed25519.PrivateKey, sshHost string) *Agent {
	t.Helper()
	return NewAgent(AgentConfig{
		ServerURL: gw.url,
		DeviceID:  "dev-agent-test",
		Key:       key,
		SSHHost:   sshHost,
		Limits:    agentLimits(),
	})
}

// TestAgentFatalJSONRejectionWithholdsPeerText (pre-proof stage): the
// gateway rejects the device with a fatal ErrMsg (code "unauthorized")
// whose message reflects the enrollment bearer — once longer than every
// historical rendering bound (prefix-leak shape), once below it
// (prints-whole shape). Run must exit fatally with the same typed verdict,
// and the rendered reason must carry the fixed local diagnostics only: the
// close code, the canonical verdict literal and the withholding phrase —
// no credential bytes in any form.
func TestAgentFatalJSONRejectionWithholdsPeerText(t *testing.T) {
	fixtureBearerShapes(t)
	for name, bearer := range map[string]string{"long": longReflectedBearer, "short": shortReflectedBearer} {
		t.Run(name, func(t *testing.T) {
			key := newAgentKey(t)
			gw := startHostileGateway(t, rejectBeforeChallenge, "dev-agent-test", key,
				mustJSONForTest(tunnel.ErrMsg{
					Type: "error", V: tunnel.ProtocolVersion,
					Code: "unauthorized", Message: bearer,
				}),
				tunnel.CloseUnauth, "")
			ssh := localEcho(t)

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			runErr := make(chan error, 1)
			go func() { runErr <- newHostileAgent(t, gw, key, ssh).Run(ctx) }()

			fatal := runFatal(t, runErr, 10*time.Second)
			if fatal.code != tunnel.CloseUnauth {
				t.Fatalf("fatal code %d, want %d (classification changed)", fatal.code, tunnel.CloseUnauth)
			}
			msg := fatal.Error()
			assertTerminalSafe(t, msg, false)
			if !strings.Contains(msg, "gateway rejected this device (close 4401)") {
				t.Fatalf("fatal error lacks the local contract message: %q", msg)
			}
			if !strings.Contains(msg, "unauthorized") || !strings.Contains(msg, "peer message withheld") {
				t.Fatalf("fatal error lacks the canonical verdict + withholding phrase: %q", msg)
			}
			assertBearerWithheld(t, msg, bearer)
		})
	}
}

// TestAgentFatalJSONRejectionWithholdsControlPayload: even the previous
// sanitizer's escaped rendering must be gone — peer bytes (here terminal
// controls) never appear in the diagnostics, in raw or escaped form.
func TestAgentFatalJSONRejectionWithholdsControlPayload(t *testing.T) {
	key := newAgentKey(t)
	gw := startHostileGateway(t, rejectBeforeChallenge, "dev-agent-test", key,
		mustJSONForTest(tunnel.ErrMsg{
			Type: "error", V: tunnel.ProtocolVersion,
			Code: "revoked", Message: hostileJSONReason,
		}),
		tunnel.CloseForbidden, "")
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newHostileAgent(t, gw, key, ssh).Run(ctx) }()

	fatal := runFatal(t, runErr, 10*time.Second)
	if fatal.code != tunnel.CloseForbidden {
		t.Fatalf("fatal code %d, want %d (classification changed)", fatal.code, tunnel.CloseForbidden)
	}
	msg := fatal.Error()
	assertTerminalSafe(t, msg, false)
	for _, forbidden := range []string{"FORGED", "pwned", "evil", `esc`, `\x1b`, `\u202e`, "reverse"} {
		if strings.Contains(msg, forbidden) {
			t.Fatalf("peer payload fragment %q survived rendering: %q", forbidden, msg)
		}
	}
	if !strings.Contains(msg, "revoked") || !strings.Contains(msg, "(close 4403)") {
		t.Fatalf("fatal error lacks the canonical verdict + close code: %q", msg)
	}
}

// TestAgentFatalPostProofJSONRejectionWithholdsPeerText (post-proof stage):
// the gateway verifies the signed auth and THEN rejects with a fatal ErrMsg
// whose message reflects the bearer. Same withholding contract; the
// post-proof pairing (code "challenge" → CloseUnauth) stays intact.
func TestAgentFatalPostProofJSONRejectionWithholdsPeerText(t *testing.T) {
	fixtureBearerShapes(t)
	key := newAgentKey(t)
	gw := startHostileGateway(t, rejectAfterProof, "dev-agent-test", key,
		mustJSONForTest(tunnel.ErrMsg{
			Type: "error", V: tunnel.ProtocolVersion,
			Code: "challenge", Message: shortReflectedBearer,
		}),
		tunnel.CloseUnauth, "")
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newHostileAgent(t, gw, key, ssh).Run(ctx) }()

	fatal := runFatal(t, runErr, 10*time.Second)
	if fatal.code != tunnel.CloseUnauth {
		t.Fatalf("fatal code %d, want %d (post-proof pairing changed)", fatal.code, tunnel.CloseUnauth)
	}
	msg := fatal.Error()
	assertTerminalSafe(t, msg, false)
	if !strings.Contains(msg, "gateway rejected this device (close 4401)") {
		t.Fatalf("fatal error lacks the local contract message: %q", msg)
	}
	if !strings.Contains(msg, "challenge") || !strings.Contains(msg, "peer message withheld") {
		t.Fatalf("fatal error lacks the canonical verdict + withholding phrase: %q", msg)
	}
	assertBearerWithheld(t, msg, shortReflectedBearer)
}

// TestAgentFatalCloseReasonWithholdsPeerText: no ErrMsg at all — the
// gateway closes with a fatal application close code whose raw reason
// reflects the enrollment bearer. A close frame can carry at most 123 bytes
// of reason on the wire (control frames are capped at 125 bytes of payload
// including the two-byte code; anything longer is invalid and the client
// never sees the close error), so the reachable reflection is a prefix —
// the exact shape the old renderer then passed through. The close-text
// route must satisfy the same withholding contract.
func TestAgentFatalCloseReasonWithholdsPeerText(t *testing.T) {
	fixtureBearerShapes(t)
	if len(shortReflectedBearer) < 124 {
		t.Fatalf("fixture: bearer is %d bytes; want at least 124 so the 123-byte wire cut is meaningful", len(shortReflectedBearer))
	}
	key := newAgentKey(t)
	gw := startHostileGateway(t, rejectBeforeChallenge, "dev-agent-test", key,
		nil, tunnel.CloseUnauth, shortReflectedBearer[:123])
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newHostileAgent(t, gw, key, ssh).Run(ctx) }()

	fatal := runFatal(t, runErr, 10*time.Second)
	if fatal.code != tunnel.CloseUnauth {
		t.Fatalf("fatal code %d, want %d (classification changed)", fatal.code, tunnel.CloseUnauth)
	}
	msg := fatal.Error()
	assertTerminalSafe(t, msg, false)
	if !strings.Contains(msg, "gateway rejected this device (close 4401)") {
		t.Fatalf("fatal error lacks the local contract message: %q", msg)
	}
	if !strings.Contains(msg, "unauthorized") || !strings.Contains(msg, "peer close reason withheld") {
		t.Fatalf("fatal error lacks the canonical status + withholding phrase: %q", msg)
	}
	assertBearerWithheld(t, msg, shortReflectedBearer)
}

// TestAgentFatalCloseReasonWithholdsControlPayload: the close-reason route
// withholds hostile control-bearing payload too — never in raw or escaped
// form.
func TestAgentFatalCloseReasonWithholdsControlPayload(t *testing.T) {
	key := newAgentKey(t)
	gw := startHostileGateway(t, rejectBeforeChallenge, "dev-agent-test", key,
		nil, tunnel.CloseUnauth, hostileCloseText)
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newHostileAgent(t, gw, key, ssh).Run(ctx) }()

	fatal := runFatal(t, runErr, 10*time.Second)
	if fatal.code != tunnel.CloseUnauth {
		t.Fatalf("fatal code %d, want %d (classification changed)", fatal.code, tunnel.CloseUnauth)
	}
	msg := fatal.Error()
	assertTerminalSafe(t, msg, false)
	for _, forbidden := range []string{"CLEAR", "evil", `\x1b`, `\u202e`, "bidi"} {
		if strings.Contains(msg, forbidden) {
			t.Fatalf("close-text fragment %q survived rendering: %q", forbidden, msg)
		}
	}
	if !strings.Contains(msg, "(close 4401)") {
		t.Fatalf("fatal error lacks the close code: %q", msg)
	}
}

// TestAgentUnknownPeerCodeStaysTransientWithheld (classification guard): a
// peer code that is NOT a recognized verdict (here "revoked" laundered with
// a bidi mark) must stay transient exactly as before — bounded reconnect,
// never a fatal exit — and the reconnect diagnostics the agent logs must
// carry neither the raw hostile code nor the reflected bearer.
func TestAgentUnknownPeerCodeStaysTransientWithheld(t *testing.T) {
	fixtureBearerShapes(t)
	key := newAgentKey(t)
	laundered := "revoked\u202e" // bidi mark: NOT the "revoked" verdict
	gw := startHostileGateway(t, rejectBeforeChallenge, "dev-agent-test", key,
		mustJSONForTest(tunnel.ErrMsg{
			Type: "error", V: tunnel.ProtocolVersion,
			Code: laundered, Message: longReflectedBearer,
		}),
		tunnel.CloseForbidden, "")
	ssh := localEcho(t)
	lw := &lockedWriter{}
	agent := NewAgent(AgentConfig{
		ServerURL: gw.url,
		DeviceID:  "dev-agent-test",
		Key:       key,
		SSHHost:   ssh,
		Limits:    agentLimits(),
		Logger:    slog.New(slog.NewTextHandler(lw, nil)),
	})

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- agent.Run(ctx) }()

	// Two connections prove Run classified the rejection transient and
	// took the bounded reconnect path (fatal codes exit on the first).
	gw.connectionsWithin(t, 2, 10*time.Second)
	select {
	case err := <-runErr:
		t.Fatalf("Run exited on unrecognized peer code %q: %v", laundered, err)
	default:
	}
	cancel()
	select {
	case err := <-runErr:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("Run returned %v after cancel, want context.Canceled", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("Run did not return after cancel")
	}

	log := lw.String()
	if !strings.Contains(log, "reconnecting") {
		t.Fatalf("transient reconnect diagnostics missing from the run log: %s", cutForTest(log))
	}
	assertBearerWithheld(t, log, longReflectedBearer)
	assertTerminalSafe(t, log, true) // the local formatter owns the newlines
	if strings.Contains(log, laundered) {
		t.Fatalf("raw hostile peer code reached the run log: %s", cutForTest(log))
	}
}

// TestReadHandshakeMsgWithholdsPeerErrorMessage pins the acceptance
// boundary: the errPeerRejected built from a hostile ErrMsg frame keeps the
// RAW code (classification input, matched against canonical literals before
// anything renders) and its rendering is fixed local text — the peer
// message never survives in any form.
func TestReadHandshakeMsgWithholdsPeerErrorMessage(t *testing.T) {
	fixtureBearerShapes(t)
	for _, tc := range []struct {
		name     string
		code     string
		wantCode string // exactly what the peer sent — never rewritten
	}{
		{"recognized verdict stays raw for classification", "revoked", "revoked"},
		{"transient canonical code stays raw", "quota", "quota"},
		{"hostile code stays raw for classification", "revoked\u202e", "revoked\u202e"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			raw := mustJSONForTest(tunnel.ErrMsg{
				Type: "error", V: tunnel.ProtocolVersion,
				Code: tc.code, Message: longReflectedBearer,
			})
			rej := readHandshakeErrMsgForTest(t, raw)
			if rej.code != tc.wantCode {
				t.Fatalf("peer code was rewritten: %q, want exactly %q", rej.code, tc.wantCode)
			}
			msg := rej.Error()
			assertTerminalSafe(t, msg, false)
			assertBearerWithheld(t, msg, longReflectedBearer)
		})
	}
}

// TestPeerDiagnosticRenderingContract pins the local rendering table
// directly: recognized wire codes render as their canonical literals only,
// unrecognized codes and all close reasons render as fixed local phrases,
// and the canonical verdict spellings stay exact — no hostile spelling may
// match (code laundering) and no recognized spelling may be dropped.
func TestPeerDiagnosticRenderingContract(t *testing.T) {
	if got := (&errPeerRejected{code: "quota"}).Error(); got != `gateway error frame "quota" (peer message withheld)` {
		t.Fatalf("canonical transient code rendering changed: %q", got)
	}
	if got := (&errPeerRejected{code: "revoked\u202e"}).Error(); got != "gateway error frame: peer code and message withheld" {
		t.Fatalf("unrecognized code rendering changed: %q", got)
	}
	if got := (&errTransientClose{code: tunnel.CloseTimeout}).Error(); got != "gateway closed the connection (close 4408): peer close reason withheld" {
		t.Fatalf("transient close rendering changed: %q", got)
	}
	for code, name := range map[int]string{
		tunnel.CloseUnauth:    "unauthorized",
		tunnel.CloseForbidden: "revoked",
		tunnel.CloseNotFound:  "not_found",
	} {
		if got := canonicalCloseName(code); got != name {
			t.Fatalf("canonicalCloseName(%d) = %q, want %q", code, got, name)
		}
	}
	for _, code := range []string{
		"challenge", "host_offline", "not_found", "protocol", "quota",
		"revoked", "signature", "timeout", "unauthorized",
	} {
		if canonicalErrCode(code) != code {
			t.Fatalf("canonicalErrCode(%q) lost the exact literal", code)
		}
	}
	for hostile := range map[string]bool{"": true, "REVOKED": true, "revoked ": true, "revoked\u202e": true, "unauthorised": true} {
		if canonicalErrCode(hostile) != "" {
			t.Fatalf("canonicalErrCode(%q) matched a non-canonical spelling (code laundering)", hostile)
		}
	}
}

// readHandshakeErrMsgForTest feeds one raw text frame to readHandshakeMsg
// over a real socket pair and returns the errPeerRejected it produces.
func readHandshakeErrMsgForTest(t *testing.T, frame []byte) *errPeerRejected {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		up := websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}
		ws, err := up.Upgrade(w, r, nil)
		if err != nil {
			return
		}
		defer ws.Close()
		_ = ws.SetWriteDeadline(time.Now().Add(2 * time.Second))
		_ = ws.WriteMessage(websocket.TextMessage, frame)
		time.Sleep(2 * time.Second) // hold the socket while the client reads
	}))
	defer srv.Close()
	dialer := websocket.Dialer{HandshakeTimeout: 2 * time.Second}
	ws, _, err := dialer.Dial("ws"+srv.URL[len("http"):], nil)
	if err != nil {
		t.Fatalf("dial: %v", err)
	}
	defer ws.Close()
	var sink struct{}
	err = readHandshakeMsg(ws, &sink)
	var rej *errPeerRejected
	if !errorsAs(err, &rej) {
		t.Fatalf("readHandshakeMsg returned %v (%T), want errPeerRejected", err, err)
	}
	return rej
}
