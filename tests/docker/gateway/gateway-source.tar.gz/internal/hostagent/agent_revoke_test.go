package hostagent

// Deterministic FH-1/FH-2 regressions against the REAL tunnel.Service (not
// the fakeGateway): revocation must end Run with a fatal auth error within
// a bounded wait (P7's owned-level mirror), and a gateway configured with a
// stream window different from the agent's must negotiate it — large
// transfers must survive with correct bytes instead of tearing the whole
// host leg down as a protocol violation.

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// realWorld wires a real tunnel.Service (its own device store) with a
// loopback echo endpoint as the agent's local SSH target, plus a client
// path for byte-exact transfers through the host leg.
type realWorld struct {
	svc      *tunnel.Service
	ts       *httptest.Server
	wsURL    string
	deviceID string
	acct     string
	token    string
	key      ed25519.PrivateKey
	revoked  atomic.Bool // the durable store flag (persist-before-notify)
}

const (
	realWorldDeviceID = "dev-real-world"
	realWorldAcct     = "acct:real-world"
	realWorldToken    = "client-token-real-world"
)

func newRealWorld(t *testing.T, limits tunnel.Limits) *realWorld {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	w := &realWorld{
		deviceID: realWorldDeviceID,
		acct:     realWorldAcct,
		token:    realWorldToken,
		key:      priv,
	}
	store := tunnel.DeviceStoreFunc(func(id string) (tunnel.Device, error) {
		if id != w.deviceID {
			return tunnel.Device{}, fmt.Errorf("unknown device %q", id)
		}
		return tunnel.Device{
			ID:        w.deviceID,
			AccountID: w.acct,
			PublicKey: w.key.Public().(ed25519.PublicKey),
			Revoked:   w.revoked.Load(),
		}, nil
	})
	svc, err := tunnel.NewService(tunnel.ServiceOptions{
		Store: store,
		Authenticate: func(_ context.Context, tok string) (tunnel.Principal, error) {
			if tok != w.token {
				return tunnel.Principal{}, fmt.Errorf("unknown token")
			}
			return tunnel.Principal{AccountID: w.acct, ExpiresAt: time.Now().Add(5 * time.Minute)}, nil
		},
		Limits: limits,
	})
	if err != nil {
		t.Fatal(err)
	}
	w.svc = svc
	w.ts = httptest.NewServer(svc)
	t.Cleanup(func() { w.ts.Close(); svc.Close() })
	w.wsURL = "ws" + w.ts.URL[len("http"):]
	return w
}

// revoke is the persist-before-notify contract: the registry flag is
// durable first, then the tunnel teardown fires (OnRevoke).
func (w *realWorld) revoke() {
	w.revoked.Store(true)
	w.svc.RevokeDevice(w.deviceID)
}

// startAgent runs a real agent against the world; agentLimits is what a
// stock build would use (tunnel.Limits{} resolves to the shipped defaults).
func (w *realWorld) startAgent(t *testing.T, ssh string, agentLimits tunnel.Limits) (runErr <-chan error, cancel func()) {
	t.Helper()
	agent := NewAgent(AgentConfig{
		ServerURL: w.wsURL,
		DeviceID:  w.deviceID,
		Key:       w.key,
		SSHHost:   ssh,
		Limits:    agentLimits,
	})
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() { done <- agent.Run(ctx) }()
	return done, cancel
}

// waitConnected polls the real service until the device registers.
func (w *realWorld) waitConnected(t *testing.T, within time.Duration) {
	t.Helper()
	deadline := time.Now().Add(within)
	for time.Now().Before(deadline) {
		if w.svc.IsDeviceConnected(w.deviceID) {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("device never connected within %s", within)
}

// dialEchoClient walks the real client path: ClientAuth JSON, ready, then
// raw binary both ways through the host leg.
func (w *realWorld) dialEchoClient(t *testing.T) *websocket.Conn {
	t.Helper()
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, resp, err := dialer.Dial(w.wsURL+"/api/v1/hosts/"+w.deviceID+"/ssh", nil)
	if err != nil {
		if resp != nil {
			t.Fatalf("client dial: HTTP %d", resp.StatusCode)
		}
		t.Fatalf("client dial: %v", err)
	}
	t.Cleanup(func() { ws.Close() })
	auth, err := json.Marshal(tunnel.ClientAuth{
		Type: "auth", V: tunnel.ProtocolVersion,
		Token: w.token, DeviceID: w.deviceID,
	})
	if err != nil {
		t.Fatal(err)
	}
	_ = ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if err := ws.WriteMessage(websocket.TextMessage, auth); err != nil {
		t.Fatalf("client auth write: %v", err)
	}
	_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("client handshake read: %v", err)
	}
	var ready tunnel.ReadyMsg
	if err := json.Unmarshal(raw, &ready); err != nil || ready.Type != "ready" {
		t.Fatalf("client not ready: %s", raw)
	}
	_ = ws.SetReadDeadline(time.Time{})
	return ws
}

// TestServiceRevokeEndsAgentRunFatally (FH-1, deterministic): a real
// tunnel.Service revoking a connected device must end the agent's Run with
// a fatal auth error after the reconnect handshake is denied — never an
// infinite retry loop (the P7 production defect, owned-level mirror).
func TestServiceRevokeEndsAgentRunFatally(t *testing.T) {
	w := newRealWorld(t, tunnel.Limits{})
	ssh := localEcho(t)
	runErr, cancel := w.startAgent(t, ssh, tunnel.Limits{})
	defer cancel()
	w.waitConnected(t, 5*time.Second)

	w.revoke() // persist, then notify — exactly the OnRevoke ordering

	select {
	case err := <-runErr:
		var fatal *errFatalAuth
		if !errors.As(err, &fatal) {
			t.Fatalf("Run returned %v (%T), want a fatal auth rejection", err, err)
		}
		if fatal.code != tunnel.CloseForbidden || !strings.Contains(fatal.Error(), "revoked") {
			t.Fatalf("fatal error does not reflect the revocation: %v", fatal)
		}
	case <-time.After(15 * time.Second):
		t.Fatal("agent Run never returned after revocation (FH-1: unbounded retry)")
	}
}

// TestNegotiatedWindowMismatchedConfigLargeTransfer (FH-2 regression): the
// gateway runs a 16 KiB stream window (an operator-tuned, clamped setting)
// while the agent uses the shipped 64 KiB default. Before negotiation this
// killed the ENTIRE host leg with "stream exceeded its receive window" as
// soon as one stream moved more than 16 KiB. After the fix the peers agree
// on the window during the handshake, and a multi-window transfer stays
// alive and byte-correct with bounded buffers.
func TestNegotiatedWindowMismatchedConfigLargeTransfer(t *testing.T) {
	const window = 16 << 10
	w := newRealWorld(t, tunnel.Limits{StreamWindow: window})
	ssh := localEcho(t)
	runErr, cancel := w.startAgent(t, ssh, tunnel.Limits{}) // agent defaults: 64 KiB
	defer cancel()
	w.waitConnected(t, 5*time.Second)

	ws := w.dialEchoClient(t)

	// 8x the negotiated window in each direction: several credit
	// round trips, bounded buffers (window, not eager buffering).
	const total = 8 * window
	pattern := func(i int) byte { return byte(i*31 + i/251) }

	writeDone := make(chan error, 1)
	go func() {
		buf := make([]byte, 4096)
		for i := 0; i < total; i += len(buf) {
			for j := range buf {
				buf[j] = pattern(i + j)
			}
			_ = ws.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := ws.WriteMessage(websocket.BinaryMessage, buf); err != nil {
				writeDone <- err
				return
			}
		}
		writeDone <- nil
	}()

	got := 0
	_ = ws.SetReadDeadline(time.Now().Add(20 * time.Second))
	for got < total {
		msgType, data, err := ws.ReadMessage()
		if err != nil {
			t.Fatalf("host leg died after %d/%d bytes (pre-fix: protocol violation): %v", got, total, err)
		}
		if msgType != websocket.BinaryMessage {
			t.Fatalf("unexpected message type %d mid-transfer", msgType)
		}
		for j, b := range data {
			if b != pattern(got+j) {
				t.Fatalf("byte mismatch at %d+%d: got %d want %d", got, j, b, pattern(got+j))
			}
		}
		got += len(data)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("client write failed: %v", err)
	}

	// The host leg must have survived the whole transfer.
	if !w.svc.IsDeviceConnected(w.deviceID) {
		t.Fatal("host connection was torn down during the transfer (window mismatch not negotiated)")
	}
	cancel()
	select {
	case err := <-runErr:
		if err != context.Canceled {
			t.Fatalf("Run returned %v after cancel", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("Run did not return after cancel")
	}
}

// TestAgentRejectsMalformedNegotiatedWindow (FH-2): a peer announcing a
// zero, negative or above-cap stream window must fail the handshake, never
// allocate streams under an unbounded window (the agent dials the gateway,
// so a hostile gateway is exactly the adversary here). Zero is the legacy
// "no negotiation" marker, so only negative and above-cap are rejections.
func TestAgentRejectsMalformedNegotiatedWindow(t *testing.T) {
	for name, announced := range map[string]int{
		"negative":  -1,
		"above-cap": 1 << 30,
	} {
		t.Run(name, func(t *testing.T) {
			gw := newOKWindowGateway(t, announced)
			ssh := localEcho(t)
			agent := NewAgent(AgentConfig{
				ServerURL: gw.wsURL(),
				DeviceID:  "dev-window-test",
				Key:       newAgentKey(t),
				SSHHost:   ssh,
				Limits:    tunnel.Limits{},
			})
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			runErr := make(chan error, 1)
			go func() { runErr <- agent.Run(ctx) }()

			// The agent must tear the session down and reconnect with
			// bounded backoff — never accept the bogus window (a second
			// handshake arrives) and never exit fatally (it is a protocol
			// fault, not an auth verdict).
			deadline := time.Now().Add(10 * time.Second)
			for time.Now().Before(deadline) {
				if gw.handshakes.Load() >= 2 {
					return
				}
				time.Sleep(20 * time.Millisecond)
			}
			t.Fatalf("agent never retried after a malformed negotiated window (handshakes=%d)", gw.handshakes.Load())
		})
	}
}

// TestAgentLegacyGatewayNoNegotiation (FH-2 backward default): an OK frame
// without a stream_window field (a pre-negotiation gateway) must keep
// working with the agent's own configured window — the documented
// deployment requirement that both sides run equal windows.
func TestAgentLegacyGatewayNoNegotiation(t *testing.T) {
	gw := newOKWindowGateway(t, 0)
	ssh := localEcho(t)
	agent := NewAgent(AgentConfig{
		ServerURL: gw.wsURL(),
		DeviceID:  "dev-window-test",
		Key:       newAgentKey(t),
		SSHHost:   ssh,
		Limits:    tunnel.Limits{},
	})
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- agent.Run(ctx) }()

	// The handshake must complete and the session must stay up well past
	// the handshake timeout — the agent neither exits nor reconnects.
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) && gw.handshakes.Load() == 0 {
		time.Sleep(10 * time.Millisecond)
	}
	if gw.handshakes.Load() == 0 {
		t.Fatal("agent never reached the handshake")
	}
	time.Sleep(500 * time.Millisecond)
	if n := gw.handshakes.Load(); n != 1 {
		t.Fatalf("agent reconnected %d times against a legacy gateway (window fallback broken)", n-1)
	}
	select {
	case err := <-runErr:
		t.Fatalf("Run exited against a legacy gateway: %v", err)
	default:
	}
}

// okWindowGateway is a hostile/minimal gateway: it issues a real challenge
// and completes the handshake with an OK frame announcing the configured
// stream window (0 = omit the field, the legacy marker). It never serves
// streams; it counts completed handshakes. aborts counts connections the
// agent tore down after the OK — an accepting agent would hold the
// connection open (only control frames flow, which ReadMessage absorbs),
// so aborts>0 proves the agent rejected the announced window.
type okWindowGateway struct {
	srv        *httptest.Server
	window     int
	handshakes atomic.Int32
	aborts     atomic.Int32
}

func newOKWindowGateway(t *testing.T, window int) *okWindowGateway {
	t.Helper()
	gw := &okWindowGateway{window: window}
	up := websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}
	gw.srv = httptest.NewServer(http.HandlerFunc(func(rw http.ResponseWriter, r *http.Request) {
		ws, err := up.Upgrade(rw, r, nil)
		if err != nil {
			return
		}
		defer ws.Close()
		nonce, _ := randomNonceForTest(32)
		connNonce, _ := randomNonceForTest(32)
		wire := tunnel.HostChallenge{
			Type: "challenge", V: tunnel.ProtocolVersion,
			ChallengeID: "ok-window-challenge", Nonce: nonce, ConnectionNonce: connNonce,
			Server: "127.0.0.1", Role: identity.RoleHost,
			Protocol:  tunnel.ProtocolTunnel,
			ExpiresAt: time.Now().Add(time.Minute).Unix(),
		}
		if err := ws.WriteMessage(websocket.TextMessage, mustJSONForTest(wire)); err != nil {
			return
		}
		_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
		if _, _, err := ws.ReadMessage(); err != nil { // the signed auth; content irrelevant here
			return
		}
		ok := tunnel.OKMsg{Type: "ok", V: tunnel.ProtocolVersion, StreamWindow: gw.window}
		if err := ws.WriteMessage(websocket.TextMessage, mustJSONForTest(ok)); err != nil {
			return
		}
		gw.handshakes.Add(1)
		// Hold the connection open until the agent gives up on it.
		_ = ws.SetReadDeadline(time.Time{})
		for {
			if _, _, err := ws.ReadMessage(); err != nil {
				gw.aborts.Add(1)
				return
			}
		}
	}))
	t.Cleanup(gw.srv.Close)
	return gw
}

func (gw *okWindowGateway) wsURL() string {
	return "ws" + gw.srv.URL[len("http"):]
}

// TestRealServiceChallengeCapacityRecovers (FH-1 correction, real service):
// a real tunnel.Service out of challenge capacity rejects the handshake
// with code "challenge" paired with the TRANSIENT CloseTimeout ("challenge
// capacity reached") — a temporary condition, not an auth verdict. The
// agent must stay alive through the rejections and connect once a slot
// frees (TTL sweep on the next issue); before the correction the
// classifier exited Run fatally on the first such frame.
//
// The TTL doubles as the agent's own challenge-redeem budget, so it must
// stay generous enough for a loaded handshake (300ms starved the agent
// itself under -race load): 2s frees the squatter's slot within a couple
// of backoff windows while leaving ~100x margin for the agent's handshakes.
func TestRealServiceChallengeCapacityRecovers(t *testing.T) {
	w := newRealWorld(t, tunnel.Limits{
		ChallengeCapacity: 1, // the squatter below fills the only slot
		ChallengeTTL:      2 * time.Second,
	})

	// Squatter: take the only challenge slot and hold the connection. Its
	// ReadMessage returning proves the challenge was issued (capacity full).
	dialer := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	squatter, _, err := dialer.Dial(w.wsURL+tunnel.PathAgentConnect, nil)
	if err != nil {
		t.Fatalf("squatter dial: %v", err)
	}
	defer squatter.Close()
	_ = squatter.SetReadDeadline(time.Now().Add(5 * time.Second))
	if _, _, err := squatter.ReadMessage(); err != nil {
		t.Fatalf("squatter challenge read: %v", err)
	}
	_ = squatter.SetReadDeadline(time.Time{})

	ssh := localEcho(t)
	runErr, cancel := w.startAgent(t, ssh, tunnel.Limits{})
	defer cancel()

	// While the store is full, Run must NOT exit (transient verdict).
	select {
	case err := <-runErr:
		t.Fatalf("agent exited on temporary challenge capacity: %v", err)
	case <-time.After(3 * time.Second):
	}

	// Capacity frees via the TTL sweep on the next issue; the bounded
	// reconnect must then land normally.
	w.waitConnected(t, 20*time.Second)
	select {
	case err := <-runErr:
		t.Fatalf("agent exited after capacity recovered: %v", err)
	default:
	}
}

// TestAgentRejectsAboveOfferNegotiatedWindow (FH-2 correction): a gateway
// announcing an IN-CAP window (256 KiB) above what the agent itself offered
// (8 KiB) is broken or lying. The agent must refuse the choice BEFORE any
// mux allocation (no 256 KiB commitment exists on our side), tear the
// session down, and keep reconnecting — never serve on the inflated window,
// never exit fatally. offer=8 KiB / reply=256 KiB is the review's in-cap
// example: both values are individually legal, the CHOICE is not.
func TestAgentRejectsAboveOfferNegotiatedWindow(t *testing.T) {
	gw := newOKWindowGateway(t, 256<<10)
	ssh := localEcho(t)
	newWindowAgent := func() *Agent {
		return NewAgent(AgentConfig{
			ServerURL: gw.wsURL(),
			DeviceID:  "dev-window-test",
			Key:       newAgentKey(t),
			SSHHost:   ssh,
			Limits:    tunnel.Limits{StreamWindow: 8 << 10}, // offer 8 KiB
		})
	}

	// Session level: the exact verdict, deterministic. Before the
	// correction the agent accepted 256 KiB and blocked serving on it.
	func() {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		err := newWindowAgent().session(ctx)
		if !errors.Is(err, tunnel.ErrProtocol) {
			t.Fatalf("session did not reject the above-offer window (err=%v, want ErrProtocol)", err)
		}
		if !strings.Contains(err.Error(), "262144") || !strings.Contains(err.Error(), "8192") {
			t.Fatalf("verdict does not name the chosen and offered windows: %v", err)
		}
		// The close handshake takes a moment after session() returns.
		deadline := time.Now().Add(5 * time.Second)
		for time.Now().Before(deadline) && gw.aborts.Load() == 0 {
			time.Sleep(10 * time.Millisecond)
		}
		if n := gw.aborts.Load(); n != 1 {
			t.Fatalf("agent did not tear the above-offer connection down (aborts=%d)", n)
		}
	}()

	// Run level: a protocol fault by the peer means bounded reconnect —
	// not acceptance (the same offer returns every time) and not exit.
	runErr := make(chan error, 1)
	agent := newWindowAgent()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go func() { runErr <- agent.Run(ctx) }()

	// Wait on the ABORT count, not the handshake count: the gateway counts
	// a handshake when it writes the OK frame, but observes the resulting
	// teardown only when its read loop later notices the closed socket —
	// a pure scheduler gap for a correct agent. Each abort requires a
	// completed handshake, so the barrier still proves reconnection; the
	// handshake count is asserted independently below.
	deadline := time.Now().Add(10 * time.Second)
	for time.Now().Before(deadline) && gw.aborts.Load() < 3 {
		time.Sleep(20 * time.Millisecond)
	}
	if n := gw.handshakes.Load(); n < 3 {
		t.Fatalf("agent stopped negotiating after %d handshakes; above-offer rejection must reconnect", n)
	}
	if n := gw.aborts.Load(); n < 3 {
		t.Fatalf("agent kept an above-offer connection open (handshakes=%d aborts=%d)", gw.handshakes.Load(), n)
	}
	select {
	case err := <-runErr:
		t.Fatalf("Run exited on the above-offer protocol fault: %v", err)
	default:
	}
	cancel()
	select {
	case err := <-runErr:
		if err != context.Canceled {
			t.Fatalf("Run returned %v after cancel", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("Run did not return after cancel")
	}
}

// TestNegotiatedWindowAgentOfferBelowServiceLargeTransfer (FH-2 correction,
// real service, reverse mismatch): the agent OFFERS less than the gateway's
// own window (agent 8 KiB vs the service's 64 KiB default). The gateway
// must choose the offered value, and the agent must apply exactly that
// symmetric choice — a multi-window transfer survives byte-correct on the
// real host leg. Positive counterpart to the above-offer rejection.
func TestNegotiatedWindowAgentOfferBelowServiceLargeTransfer(t *testing.T) {
	const window = 8 << 10
	w := newRealWorld(t, tunnel.Limits{}) // service default: 64 KiB
	ssh := localEcho(t)
	runErr, cancel := w.startAgent(t, ssh, tunnel.Limits{StreamWindow: window})
	defer cancel()
	w.waitConnected(t, 5*time.Second)

	ws := w.dialEchoClient(t)

	// 8x the negotiated window in each direction: several credit round
	// trips through the real muxes, bounded buffers throughout.
	const total = 8 * window
	pattern := func(i int) byte { return byte(i*17 + i/131) }

	writeDone := make(chan error, 1)
	go func() {
		buf := make([]byte, 2048)
		for i := 0; i < total; i += len(buf) {
			for j := range buf {
				buf[j] = pattern(i + j)
			}
			_ = ws.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := ws.WriteMessage(websocket.BinaryMessage, buf); err != nil {
				writeDone <- err
				return
			}
		}
		writeDone <- nil
	}()

	got := 0
	_ = ws.SetReadDeadline(time.Now().Add(20 * time.Second))
	for got < total {
		msgType, data, err := ws.ReadMessage()
		if err != nil {
			t.Fatalf("host leg died after %d/%d bytes: %v", got, total, err)
		}
		if msgType != websocket.BinaryMessage {
			t.Fatalf("unexpected message type %d mid-transfer", msgType)
		}
		for j, b := range data {
			if b != pattern(got+j) {
				t.Fatalf("byte mismatch at %d+%d: got %d want %d", got, j, b, pattern(got+j))
			}
		}
		got += len(data)
	}
	if err := <-writeDone; err != nil {
		t.Fatalf("client write failed: %v", err)
	}
	if !w.svc.IsDeviceConnected(w.deviceID) {
		t.Fatal("host connection torn down during the reverse-mismatch transfer")
	}
	cancel()
	select {
	case err := <-runErr:
		if err != context.Canceled {
			t.Fatalf("Run returned %v after cancel", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("Run did not return after cancel")
	}
}
