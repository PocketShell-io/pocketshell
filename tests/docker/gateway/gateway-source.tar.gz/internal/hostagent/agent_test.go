package hostagent

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// agentLimits are tight but realistic: the handshake deadline is far below
// the session lifetime we expect the agent to survive (F-13), and the
// liveness windows are fast enough for tests.
func agentLimits() tunnel.Limits {
	return tunnel.Limits{
		HandshakeTimeout: 150 * time.Millisecond,
		PongWait:         600 * time.Millisecond,
		PingInterval:     150 * time.Millisecond,
		StreamWindow:     16 << 10,
		MaxFramePayload:  8 << 10,
	}
}

// newAgentKey makes the device identity used by the agent-side tests.
func newAgentKey(t *testing.T) ed25519.PrivateKey {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	return priv
}

// localEcho starts a TCP echo server on loopback standing in for sshd at
// the bridge target (the agent treats it as opaque bytes).
func localEcho(t *testing.T) string {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	done := make(chan struct{})
	go func() {
		defer close(done)
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			go func(c net.Conn) {
				defer c.Close()
				_, _ = io.Copy(c, c)
			}(c)
		}
	}()
	t.Cleanup(func() { ln.Close(); <-done })
	return ln.Addr().String()
}

// fakeGateway is a minimal WS endpoint that speaks the agent handshake
// exactly like tunnel.Service does, then either serves a real multiplexer
// (healthy mode) or goes silent (stalled mode, F-13 expiry).
type fakeGateway struct {
	srv      *httptest.Server
	ch       *websocket.Conn
	authed   chan struct{}
	authErr  chan error
	stall    bool // stop reading/ponging after the handshake
	closed   chan struct{}
	closeErr chan error
	// muxReady delivers the gateway-side mux exactly once it is serving;
	// tests must receive from it instead of polling the field (race-safe).
	muxReady chan *tunnel.Mux
	limits   tunnel.Limits

	// Rejection modes (FH-1): initialErrCode sends an ErrMsg frame instead
	// of the challenge (the pre-challenge stage); postProofErrCode sends an
	// ErrMsg instead of the `ok` ack. quotaFirstN rejects the first N
	// connections at the pre-challenge stage with the transient `quota`
	// code and only then serves normally (bounded reconnect must recover).
	initialErrCode   string
	postProofErrCode string
	closeCodeOnly    bool // rejection closes with the code, no ErrMsg text frame
	quotaFirstN      atomic.Int32
	// capacityFirstN rejects the first N connections at the pre-challenge
	// stage with tunnel.Service's exact challenge-capacity shape
	// (CloseTimeout + code "challenge") and serves normally afterwards:
	// the rejection is temporary, so the agent must recover (FH-1
	// correction — this code used to be classified terminal).
	capacityFirstN atomic.Int32
	connections    atomic.Int32
	// rejected records the wire error code of every rejection actually
	// sent (race-safe observation for tests).
	rejected chan string
}

// rejectedWithin waits for the gateway to actually send a rejection.
func (gw *fakeGateway) rejectedWithin(t *testing.T, d time.Duration) string {
	t.Helper()
	select {
	case code := <-gw.rejected:
		return code
	case <-time.After(d):
		t.Fatal("gateway never sent a rejection frame")
		return ""
	}
}

func (gw *fakeGateway) muxWithin(t *testing.T, d time.Duration) *tunnel.Mux {
	t.Helper()
	select {
	case m := <-gw.muxReady:
		return m
	case <-time.After(d):
		t.Fatal("gateway mux never started")
		return nil
	}
}

func newFakeGateway(t *testing.T, deviceID string, key ed25519.PrivateKey, stall bool) *fakeGateway {
	t.Helper()
	limits := agentLimits()
	gw := &fakeGateway{
		authed:   make(chan struct{}),
		authErr:  make(chan error, 1),
		closed:   make(chan struct{}),
		closeErr: make(chan error, 1),
		muxReady: make(chan *tunnel.Mux, 1),
		rejected: make(chan string, 8),
		stall:    stall,
		limits:   limits,
	}
	up := websocket.Upgrader{CheckOrigin: func(*http.Request) bool { return true }}
	gw.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ws, err := up.Upgrade(w, r, nil)
		if err != nil {
			return
		}
		gw.ch = ws
		defer ws.Close()
		connIdx := gw.connections.Add(1)

		// sendErr emulates tunnel.Service's reject(): an ErrMsg text frame
		// followed by the application close frame (closeCodeOnly drops the
		// text frame to exercise the close-code-only classification path).
		sendErr := func(code int, errCode, msg string) {
			select {
			case gw.rejected <- errCode:
			default:
			}
			if !gw.closeCodeOnly {
				_ = ws.WriteMessage(websocket.TextMessage, mustJSONForTest(tunnel.ErrMsg{
					Type: "error", V: tunnel.ProtocolVersion, Code: errCode, Message: msg,
				}))
			}
			_ = ws.WriteMessage(websocket.CloseMessage, websocket.FormatCloseMessage(code, errCode))
		}

		// Transient pre-challenge quota (FH-1 recovery coverage).
		if int32(connIdx) <= int32(gw.quotaFirstN.Load()) {
			sendErr(tunnel.CloseQuota, "quota", "gateway at host capacity")
			return
		}

		// Transient pre-challenge CAPACITY rejection: the exact wire shape
		// of tunnel.Service when the challenge store is full — code
		// "challenge" paired with the TRANSIENT CloseTimeout, not an auth
		// verdict (FH-1 correction coverage).
		if int32(connIdx) <= int32(gw.capacityFirstN.Load()) {
			sendErr(tunnel.CloseTimeout, "challenge", "challenge capacity reached")
			return
		}

		// Terminal pre-challenge rejection: ErrMsg before any challenge.
		if gw.initialErrCode != "" {
			sendErr(tunnel.CloseForbidden, gw.initialErrCode, "device unknown or revoked")
			return
		}

		// 1. Challenge (same fields and semantics as tunnel.Service).
		nonce, _ := randomNonceForTest(32)
		connNonce, _ := randomNonceForTest(32)
		wire := tunnel.HostChallenge{
			Type: "challenge", V: tunnel.ProtocolVersion,
			ChallengeID: "gw-challenge-" + time.Now().Format("150405.000000000"),
			Nonce:       nonce, ConnectionNonce: connNonce,
			Server: "127.0.0.1", Role: identity.RoleHost,
			Protocol:  tunnel.ProtocolTunnel,
			ExpiresAt: time.Now().Add(time.Minute).Unix(),
		}
		if err := ws.WriteMessage(websocket.TextMessage, mustJSONForTest(wire)); err != nil {
			gw.authErr <- err
			return
		}
		_ = ws.SetReadDeadline(time.Now().Add(5 * time.Second))
		_, raw, err := ws.ReadMessage()
		if err != nil {
			gw.authErr <- err
			return
		}
		var auth tunnel.HostAuth
		if err := json.Unmarshal(raw, &auth); err != nil {
			gw.authErr <- err
			return
		}
		idCh, err := wire.ToIdentityChallenge(deviceID)
		if err != nil {
			gw.authErr <- err
			return
		}
		sig, err := base64.StdEncoding.DecodeString(auth.Signature)
		if err != nil || identity.Verify(pubOf(key), idCh, sig) != nil {
			gw.authErr <- errBadSig
			return
		}
		if auth.DeviceID != deviceID {
			gw.authErr <- errBadSig
			return
		}
		// Terminal post-proof rejection: the gateway proves the device is
		// unknown/revoked only after verifying the signed auth. The pairing
		// mirrors tunnel.Service: the redeem failure is code "challenge"
		// with CloseUnauth ("challenge invalid or expired"); device
		// verdicts are code "revoked" with CloseForbidden.
		if gw.postProofErrCode != "" {
			closeCode, msg := tunnel.CloseForbidden, "device unknown or revoked"
			if gw.postProofErrCode == "challenge" {
				closeCode, msg = tunnel.CloseUnauth, "challenge invalid or expired"
			}
			sendErr(closeCode, gw.postProofErrCode, msg)
			return
		}
		if err := ws.WriteMessage(websocket.TextMessage, mustJSONForTest(tunnel.OKMsg{Type: "ok", V: tunnel.ProtocolVersion})); err != nil {
			gw.authErr <- err
			return
		}
		_ = ws.SetReadDeadline(time.Time{})
		close(gw.authed)

		if gw.stall {
			// Brain-dead gateway: never read again (so the agent's pings are
			// never answered) and never send data. Liveness must expire it.
			ticker := time.NewTicker(50 * time.Millisecond)
			defer ticker.Stop()
			for {
				select {
				case <-ticker.C:
					_ = ws.SetWriteDeadline(time.Now().Add(time.Second))
					if err := ws.WriteMessage(websocket.PingMessage, nil); err != nil {
						gw.closeErr <- err
						close(gw.closed)
						return
					}
				}
			}
		}

		// Healthy gateway: a real mux (RoleGateway) plus pings, exactly the
		// production shape — ONE serialized writer shared by the mux and
		// the ping loop (two writers on one conn would interleave). The
		// mux read loop auto-pongs the agent's pings.
		writer := tunnel.NewWSWriter(ws, limits)
		mux := tunnel.NewMux(tunnel.NewWSTransportWithWriter(ws, writer, limits), limits, tunnel.RoleGateway)
		gw.muxReady <- mux
		go func() {
			tk := time.NewTicker(limits.PingInterval)
			defer tk.Stop()
			for {
				select {
				case <-tk.C:
					if err := writer.WriteMessage(websocket.PingMessage, nil); err != nil {
						gw.closeErr <- err
						close(gw.closed)
						return
					}
				case <-mux.Done():
					return
				}
			}
		}()
		<-mux.Done()
		gw.closeErr <- nil
		close(gw.closed)
	}))
	t.Cleanup(gw.srv.Close)
	return gw
}

func (gw *fakeGateway) wsURL() string {
	return "ws" + gw.srv.URL[len("http"):]
}

var errBadSig = errString("bad signature")

type errString string

func (e errString) Error() string { return string(e) }

func randomNonceForTest(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.StdEncoding.EncodeToString(b), nil
}

func mustJSONForTest(v any) []byte {
	b, err := json.Marshal(v)
	if err != nil {
		panic(err)
	}
	return b
}

func pubOf(key ed25519.PrivateKey) ed25519.PublicKey {
	return key.Public().(ed25519.PublicKey)
}

func newTestAgent(t *testing.T, gw *fakeGateway, key ed25519.PrivateKey, sshHost string) *Agent {
	return NewAgent(AgentConfig{
		ServerURL: gw.wsURL(),
		DeviceID:  "dev-agent-test",
		Key:       key,
		SSHHost:   sshHost,
		Limits:    agentLimits(),
	})
}

// TestNewAgentDefaultClockMustNotPanic (F-11): the production CLI never
// sets Now; NewAgent defaults it so Run is safe with zero configuration.
func TestNewAgentDefaultClockMustNotPanic(t *testing.T) {
	key := newAgentKey(t)
	a := NewAgent(AgentConfig{
		ServerURL: "ws://127.0.0.1:1", // nothing listens; fails fast
		DeviceID:  "dev-clock",
		Key:       key,
		SSHHost:   "127.0.0.1:22",
	})
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	// Before the fix this panicked at agent.go:109 (nil clock deref).
	if err := a.Run(ctx); err == nil {
		t.Fatal("Run with canceled context returned nil")
	}
}

// TestAgentSessionOutlivesHandshakeDeadline (F-13): with a handshake
// timeout of 150ms, the authenticated session must still carry SSH-shaped
// traffic after MANY handshake deadlines. Before the fix the agent's
// handshake read deadline survived into the session and killed every
// connection at exactly 10s; with this limit it died at 150ms.
func TestAgentSessionOutlivesHandshakeDeadline(t *testing.T) {
	key := newAgentKey(t)
	gw := newFakeGateway(t, "dev-agent-test", key, false)
	ssh := localEcho(t)

	runErr := make(chan error, 1)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go func() { runErr <- newTestAgent(t, gw, key, ssh).Run(ctx) }()

	select {
	case <-gw.authed:
	case err := <-gw.authErr:
		t.Fatalf("handshake: %v", err)
	case <-time.After(3 * time.Second):
		t.Fatal("agent never completed the handshake")
	}

	// The gateway side drives streams; wait for the mux to be up.
	mux := gw.muxWithin(t, 3*time.Second)

	// Round trips spread over >5 handshake deadlines (>750ms). Before the
	// fix, the first one already died at the leftover handshake deadline.
	for round := 0; round < 6; round++ {
		s, err := mux.Open(2 * time.Second)
		if err != nil {
			t.Fatalf("round %d: open: %v", round, err)
		}
		msg := []byte("round-" + time.Now().Format("15:04:05.000"))
		if _, err := s.Write(msg); err != nil {
			t.Fatalf("round %d: write: %v", round, err)
		}
		_ = s.SetReadDeadline(time.Now().Add(2 * time.Second))
		buf := make([]byte, len(msg))
		if _, err := io.ReadFull(s, buf); err != nil {
			t.Fatalf("round %d: read: %v", round, err)
		}
		if string(buf) != string(msg) {
			t.Fatalf("round %d: echo mismatch", round)
		}
		if err := s.Close(); err != nil {
			t.Fatalf("round %d: close: %v", round, err)
		}
		time.Sleep(agentLimits().HandshakeTimeout) // cross at least one deadline per round
	}

	// The agent is still connected and serving; nothing reconnected.
	select {
	case <-gw.closed:
		t.Fatal("healthy session was dropped mid-run")
	default:
	}
	cancel()
	select {
	case err := <-runErr:
		if err != context.Canceled {
			t.Fatalf("Run returned %v, want context.Canceled", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("Run did not return after cancel")
	}
}

// TestStalledGatewayExpires (F-13 expiry side): a gateway that completed
// the handshake and then went completely silent (no pongs, no data) must
// be dropped by the agent within ~PongWait — the connection must not stay
// open forever just because nothing is wrong with the bytes.
func TestStalledGatewayExpires(t *testing.T) {
	key := newAgentKey(t)
	gw := newFakeGateway(t, "dev-agent-test", key, true)
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go newTestAgent(t, gw, key, ssh).Run(ctx)

	select {
	case <-gw.authed:
	case err := <-gw.authErr:
		t.Fatalf("handshake: %v", err)
	case <-time.After(3 * time.Second):
		t.Fatal("agent never completed the handshake")
	}

	// The agent stops answering (deadline expiry closes the socket), so
	// the gateway's writes start failing well within a couple of PongWaits.
	pongWait := agentLimits().PongWait
	select {
	case <-gw.closed:
		// Write failed: the agent tore the connection down.
	case <-time.After(3 * pongWait):
		t.Fatalf("stalled gateway still connected after %v (PongWait %v)", 3*pongWait, pongWait)
	}
}

// runFatal waits for Run to return a fatal auth rejection within d (FH-1:
// terminal rejections must surface, never retry forever).
func runFatal(t *testing.T, runErr <-chan error, d time.Duration) *errFatalAuth {
	t.Helper()
	select {
	case err := <-runErr:
		var fatal *errFatalAuth
		if !errorsAs(err, &fatal) {
			t.Fatalf("Run returned %v (%T), want a fatal auth rejection", err, err)
		}
		return fatal
	case <-time.After(d):
		t.Fatal("agent never exited on a terminal gateway rejection (FH-1: unbounded retry)")
		return nil
	}
}

// errorsAs decouples these tests from the errors package spelling.
func errorsAs(err error, target any) bool { return errors.As(err, target) }

// TestAgentFatalExitOnInitialErrorFrame (FH-1): a gateway that rejects the
// device with an ErrMsg TEXT frame BEFORE the challenge (the server-first
// stage) must end in a fatal auth error — the frame used to unmarshal into
// HostChallenge and surface as a generic type error that Run retried
// forever.
func TestAgentFatalExitOnInitialErrorFrame(t *testing.T) {
	key := newAgentKey(t)
	gw := newFakeGateway(t, "dev-agent-test", key, false)
	gw.initialErrCode = "revoked"
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newTestAgent(t, gw, key, ssh).Run(ctx) }()

	if code := gw.rejectedWithin(t, 5*time.Second); code != "revoked" {
		t.Fatalf("gateway sent %q, want revoked", code)
	}
	fatal := runFatal(t, runErr, 10*time.Second)
	if fatal.code != tunnel.CloseForbidden {
		t.Fatalf("fatal code %d, want %d (CloseForbidden)", fatal.code, tunnel.CloseForbidden)
	}
	if !strings.Contains(fatal.Error(), "gateway rejected this device") {
		t.Fatalf("fatal error lacks the local contract message: %v", fatal)
	}
	if !strings.Contains(fatal.Error(), "revoked") {
		t.Fatalf("fatal error does not carry the rejection code: %v", fatal)
	}
}

// TestAgentFatalExitOnPostProofErrorFrame (FH-1): the gateway verifies the
// signed auth and THEN rejects with an ErrMsg instead of the `ok` ack — the
// exact revoked-device shape (P7). The frame used to unmarshal into OKMsg
// and the code was lost before classify.
func TestAgentFatalExitOnPostProofErrorFrame(t *testing.T) {
	key := newAgentKey(t)
	gw := newFakeGateway(t, "dev-agent-test", key, false)
	gw.postProofErrCode = "revoked"
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newTestAgent(t, gw, key, ssh).Run(ctx) }()

	if code := gw.rejectedWithin(t, 5*time.Second); code != "revoked" {
		t.Fatalf("gateway sent %q, want revoked", code)
	}
	fatal := runFatal(t, runErr, 10*time.Second)
	if fatal.code != tunnel.CloseForbidden {
		t.Fatalf("fatal code %d, want %d", fatal.code, tunnel.CloseForbidden)
	}
}

// TestAgentFatalExitOnCloseCodeOnly (FH-1 regression guard): when only the
// application close frame is observed — no ErrMsg text frame at all — the
// close-code classification must still exit fatally.
func TestAgentFatalExitOnCloseCodeOnly(t *testing.T) {
	key := newAgentKey(t)
	gw := newFakeGateway(t, "dev-agent-test", key, false)
	gw.postProofErrCode = "revoked"
	gw.closeCodeOnly = true
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newTestAgent(t, gw, key, ssh).Run(ctx) }()
	if code := gw.rejectedWithin(t, 5*time.Second); code != "revoked" {
		t.Fatalf("gateway sent %q, want revoked", code)
	}
	fatal := runFatal(t, runErr, 10*time.Second)
	if fatal.code != tunnel.CloseForbidden {
		t.Fatalf("fatal code %d, want %d", fatal.code, tunnel.CloseForbidden)
	}
}

// TestAgentTransientQuotaRecovers (FH-1): a transient capacity rejection
// (quota) must NOT exit the agent — bounded backoff reconnects, and the
// next handshake serves normally.
func TestAgentTransientQuotaRecovers(t *testing.T) {
	key := newAgentKey(t)
	gw := newFakeGateway(t, "dev-agent-test", key, false)
	gw.quotaFirstN.Store(2) // first two connections: quota; then healthy
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newTestAgent(t, gw, key, ssh).Run(ctx) }()

	mux := gw.muxWithin(t, 15*time.Second) // includes the backoff windows

	s, err := mux.Open(2 * time.Second)
	if err != nil {
		t.Fatalf("open after recovery: %v", err)
	}
	msg := []byte("after-quota-recovery")
	if _, err := s.Write(msg); err != nil {
		t.Fatalf("write: %v", err)
	}
	_ = s.SetReadDeadline(time.Now().Add(2 * time.Second))
	buf := make([]byte, len(msg))
	if _, err := io.ReadFull(s, buf); err != nil {
		t.Fatalf("read: %v", err)
	}
	if string(buf) != string(msg) {
		t.Fatal("echo mismatch after recovery")
	}
	if err := s.Close(); err != nil {
		t.Fatalf("close: %v", err)
	}
	cancel()
	select {
	case err := <-runErr:
		if err != context.Canceled {
			t.Fatalf("Run returned %v after cancel", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("Run did not return after cancel")
	}
}

// TestAgentPreChallengeCapacityFrameRecovers (FH-1 correction): the real
// service signals challenge-CAPACITY exhaustion at the pre-challenge stage
// as code "challenge" paired with the TRANSIENT close code (CloseTimeout —
// service.go's "challenge capacity reached"). It is a temporary condition:
// the agent must ride it out with the bounded reconnect and serve once
// capacity frees. Before the correction the classifier mapped every
// "challenge" frame to a terminal auth verdict and exited Run permanently.
// The terminal pre-challenge verdicts (revoked etc.) keep their own tests.
func TestAgentPreChallengeCapacityFrameRecovers(t *testing.T) {
	key := newAgentKey(t)
	gw := newFakeGateway(t, "dev-agent-test", key, false)
	gw.capacityFirstN.Store(2) // first two connections: capacity; then healthy
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newTestAgent(t, gw, key, ssh).Run(ctx) }()

	for i := 0; i < 2; i++ {
		if code := gw.rejectedWithin(t, 5*time.Second); code != "challenge" {
			t.Fatalf("rejection %d: gateway sent %q, want challenge capacity", i+1, code)
		}
	}
	mux := gw.muxWithin(t, 15*time.Second) // includes the backoff windows

	s, err := mux.Open(2 * time.Second)
	if err != nil {
		t.Fatalf("open after capacity recovery: %v", err)
	}
	msg := []byte("after-capacity-recovery")
	if _, err := s.Write(msg); err != nil {
		t.Fatalf("write: %v", err)
	}
	_ = s.SetReadDeadline(time.Now().Add(2 * time.Second))
	buf := make([]byte, len(msg))
	if _, err := io.ReadFull(s, buf); err != nil {
		t.Fatalf("read: %v", err)
	}
	if string(buf) != string(msg) {
		t.Fatal("echo mismatch after capacity recovery")
	}
	if err := s.Close(); err != nil {
		t.Fatalf("close: %v", err)
	}
	select {
	case err := <-runErr:
		t.Fatalf("Run exited on a temporary capacity rejection: %v", err)
	default:
	}
	cancel()
	select {
	case err := <-runErr:
		if err != context.Canceled {
			t.Fatalf("Run returned %v after cancel", err)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("Run did not return after cancel")
	}
}

// TestAgentPostProofChallengeVerdictStillFatal (FH-1 correction guard): at
// the POST-PROOF stage code "challenge" is the terminal redeem-failure
// verdict ("challenge invalid or expired", CloseUnauth pairing — the real
// service's post-proof shape). The capacity correction must relax only the
// pre-challenge stage, never this one: a challenge proof that failed
// verification stays fatal. This guard is what forbids the lazy fix of
// retrying every "challenge" frame.
func TestAgentPostProofChallengeVerdictStillFatal(t *testing.T) {
	key := newAgentKey(t)
	gw := newFakeGateway(t, "dev-agent-test", key, false)
	gw.postProofErrCode = "challenge"
	ssh := localEcho(t)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	runErr := make(chan error, 1)
	go func() { runErr <- newTestAgent(t, gw, key, ssh).Run(ctx) }()

	if code := gw.rejectedWithin(t, 5*time.Second); code != "challenge" {
		t.Fatalf("gateway sent %q, want the post-proof challenge verdict", code)
	}
	fatal := runFatal(t, runErr, 10*time.Second)
	if fatal.code != tunnel.CloseUnauth {
		t.Fatalf("fatal code %d, want %d (CloseUnauth, the real post-proof pairing)", fatal.code, tunnel.CloseUnauth)
	}
	if !strings.Contains(fatal.Error(), "challenge") {
		t.Fatalf("fatal error does not carry the rejection code: %v", fatal)
	}
}
