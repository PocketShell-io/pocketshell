package hostagent

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"time"
)

// Config is the on-disk agent state (minus the identity key, which lives
// in its own protected file). Both files use Unix 0600 or a protected
// Windows ACL: the pinned SSH host key and server are security-relevant.
type Config struct {
	Server     string    `json:"server"`       // wss:// (or ws:// with --insecure-dev)
	DeviceID   string    `json:"device_id"`    // enrolled device ID
	SSHHost    string    `json:"ssh_host"`     // loopback host:port of the local sshd
	SSHHostKey string    `json:"ssh_host_key"` // pinned authorized_keys line of the local sshd
	CreatedAt  time.Time `json:"created_at"`
}

// ErrNotEnrolled is returned when no config exists in the directory yet.
var ErrNotEnrolled = errors.New("not enrolled: run `pocketshell-link enroll` first")

// DefaultDir returns the default configuration directory
// (${XDG_CONFIG_HOME:-$HOME/.config}/pocketshell-link).
func DefaultDir() string {
	if x := os.Getenv("XDG_CONFIG_HOME"); x != "" {
		return filepath.Join(x, "pocketshell-link")
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return "pocketshell-link"
	}
	return filepath.Join(home, ".config", "pocketshell-link")
}

func (c *Config) validate() error {
	if c.Server == "" {
		return errors.New("config: missing server")
	}
	if c.DeviceID == "" {
		return errors.New("config: missing device_id")
	}
	if _, err := ValidateLoopback(c.SSHHost); err != nil {
		return fmt.Errorf("config: %w", err)
	}
	return nil
}

// LoadConfig validates file protection before reading config.json from dir.
func LoadConfig(dir string) (*Config, error) {
	f, err := os.Open(filepath.Join(dir, confFileName))
	if errors.Is(err, os.ErrNotExist) {
		return nil, ErrNotEnrolled
	}
	if err != nil {
		return nil, err
	}
	defer f.Close()
	if err := validateProtectedFile(f); err != nil {
		return nil, err
	}
	raw, err := io.ReadAll(f)
	if err != nil {
		return nil, err
	}
	var c Config
	if err := json.Unmarshal(raw, &c); err != nil {
		return nil, fmt.Errorf("parse %s: %w", confFileName, err)
	}
	if err := c.validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

// SaveConfig atomically writes config.json with platform-specific protection.
func SaveConfig(dir string, c *Config) error {
	if err := c.validate(); err != nil {
		return err
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return err
	}
	raw, err := json.MarshalIndent(c, "", "  ")
	if err != nil {
		return err
	}
	raw = append(raw, '\n')
	tmp, err := createProtectedTemp(dir)
	if err != nil {
		return err
	}
	defer os.Remove(tmp.Name())
	if _, err := tmp.Write(raw); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	return os.Rename(tmp.Name(), filepath.Join(dir, confFileName))
}

// KeyPath returns the identity key file path inside dir.
func KeyPath(dir string) string { return filepath.Join(dir, keyFileName) }
