package hostagent

// The run log's pinned_host_key_fp diagnostic (opus-final-normal review F3):
// it must carry the REAL SHA256 fingerprint of the parsed pinned host key —
// the first base64 characters of the key blob are the constant Ed25519 type
// header ("AAAAC3NzaC1lZDI1…") and cannot tell two pinned keys apart. The
// log value is public metadata: no key blob and no private material may
// appear in it.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"log/slog"
	"strings"
	"sync"
	"testing"
	"time"

	"golang.org/x/crypto/ssh"
)

// newPinnedHostKey generates one independent Ed25519 host key and renders
// its authorized_keys line (the pinned-config spelling).
func newPinnedHostKey(t *testing.T) (ssh.PublicKey, ed25519.PrivateKey, string) {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	signer, err := ssh.NewSignerFromKey(priv)
	if err != nil {
		t.Fatal(err)
	}
	return signer.PublicKey(), priv, strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))
}

// TestFingerprintOfLineIsRealSHA256 pins fingerprintOfLine: the value is
// type + ssh.FingerprintSHA256 of the parsed key, distinct keys produce
// distinct values, the constant type-header prefix is gone, and unparseable
// input stays "unknown" (never a partial blob).
func TestFingerprintOfLineIsRealSHA256(t *testing.T) {
	pub1, _, line1 := newPinnedHostKey(t)
	pub2, _, line2 := newPinnedHostKey(t)

	fp1 := fingerprintOfLine(line1)
	fp2 := fingerprintOfLine(line2)

	if fp1 != pub1.Type()+":"+ssh.FingerprintSHA256(pub1) {
		t.Fatalf("fingerprintOfLine(line1) = %q, want %q", fp1, pub1.Type()+":"+ssh.FingerprintSHA256(pub1))
	}
	if fp2 != pub2.Type()+":"+ssh.FingerprintSHA256(pub2) {
		t.Fatalf("fingerprintOfLine(line2) = %q, want %q", fp2, pub2.Type()+":"+ssh.FingerprintSHA256(pub2))
	}
	if fp1 == fp2 {
		t.Fatal("distinct independently generated Ed25519 keys produced identical fingerprint diagnostics")
	}
	if !strings.HasPrefix(fp1, "ssh-ed25519:SHA256:") {
		t.Fatalf("fingerprint %q lacks the type + SHA256 shape", fp1)
	}
	// The old diagnostic logged the constant Ed25519 type header for every
	// key; it must be gone, and no key blob may appear either.
	if strings.Contains(fp1, "AAAAC3NzaC1lZDI1") {
		t.Fatalf("constant type-header prefix still logged: %q", fp1)
	}
	if blob := strings.Fields(line1)[1]; strings.Contains(fp1, blob) || strings.Contains(fp1, blob[:16]) {
		t.Fatalf("key blob material leaked into the fingerprint diagnostic: %q", fp1)
	}
	for _, garbage := range []string{"", "garbage", "ssh-ed25519 not!!!a-key"} {
		if got := fingerprintOfLine(garbage); got != "unknown" {
			t.Fatalf("fingerprintOfLine(%q) = %q, want \"unknown\"", garbage, got)
		}
	}
}

// lockedWriter is a concurrency-safe buffer for a logger written from the
// RunAgent goroutine while the test polls it.
type lockedWriter struct {
	mu  sync.Mutex
	buf bytes.Buffer
}

func (w *lockedWriter) Write(p []byte) (int, error) {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.buf.Write(p)
}

func (w *lockedWriter) String() string {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.buf.String()
}

// startAgentForPinLog writes an enrolled state (config + key) into dir and
// starts RunAgent against a closed loopback port just long enough for the
// startup log line; it returns the captured log after the agent stopped.
func startAgentForPinLog(t *testing.T, dir string, priv ed25519.PrivateKey, pinnedLine string) string {
	t.Helper()
	cfg := &Config{
		Server:     "ws://127.0.0.1:1", // loopback, closed: transient retries only
		DeviceID:   "dev-pin-fp-log",
		SSHHost:    "127.0.0.1:22",
		SSHHostKey: pinnedLine,
		CreatedAt:  time.Now().UTC(),
	}
	if err := SaveConfig(dir, cfg); err != nil {
		t.Fatal(err)
	}
	if err := SaveKey(KeyPath(dir), priv); err != nil {
		t.Fatal(err)
	}
	lw := &lockedWriter{}
	logger := slog.New(slog.NewTextHandler(lw, nil))

	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan struct{})
	go func() {
		defer close(done)
		_ = RunAgent(ctx, RunOptions{Dir: dir, InsecureDev: true, Logger: logger})
	}()

	// Wait for the startup line (logged synchronously before agent.Run),
	// then stop the agent before judging the log.
	deadline := time.Now().Add(5 * time.Second)
	for {
		if strings.Contains(lw.String(), "pinned_host_key_fp") || time.Now().After(deadline) {
			break
		}
		time.Sleep(5 * time.Millisecond)
	}
	cancel()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("RunAgent did not return after cancel")
	}
	return lw.String()
}

// TestRunAgentLogsTruePinnedKeyFingerprint drives the actual run log path:
// the logged pinned_host_key_fp carries the true SHA256 fingerprint of the
// pinned key, and two independently generated keys log distinct values —
// the diagnostic can tell pins apart.
func TestRunAgentLogsTruePinnedKeyFingerprint(t *testing.T) {
	pub1, priv1, line1 := newPinnedHostKey(t)
	pub2, priv2, line2 := newPinnedHostKey(t)

	want1 := pub1.Type() + ":" + ssh.FingerprintSHA256(pub1)
	want2 := pub2.Type() + ":" + ssh.FingerprintSHA256(pub2)
	if want1 == want2 {
		t.Fatal("test keys produced identical fingerprints")
	}

	log1 := startAgentForPinLog(t, t.TempDir(), priv1, line1)
	log2 := startAgentForPinLog(t, t.TempDir(), priv2, line2)

	if !strings.Contains(log1, "pinned_host_key_fp") {
		t.Fatalf("run log never recorded pinned_host_key_fp: %s", log1)
	}
	if !strings.Contains(log1, want1) {
		t.Fatalf("run log lacks the true fingerprint %q: %s", want1, log1)
	}
	if strings.Contains(log1, want2) {
		t.Fatalf("run log carried another key's fingerprint %q: %s", want2, log1)
	}
	if !strings.Contains(log2, want2) {
		t.Fatalf("second run log lacks its own fingerprint %q: %s", want2, log2)
	}
	// No key blob material in either log.
	for i, line := range []string{line1, line2} {
		log := map[int]string{0: log1, 1: log2}[i]
		if blob := strings.Fields(line)[1]; strings.Contains(log, blob) {
			t.Fatalf("key blob leaked into run log: %s", log)
		}
	}
}
