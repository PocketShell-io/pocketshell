package hostagent

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

// NormalizeServerURL validates the --server value and splits it into the
// WebSocket URL used for the agent control connection and the HTTP base
// used for the identity enrollment API. wss/https are the default; plain
// ws/http is only allowed with an explicit --insecure-dev (local docker
// proof), and never relaxes TLS verification — there is no cert-skip flag.
func NormalizeServerURL(server string, insecureDev bool) (wsURL, apiBase string, err error) {
	u, err := url.Parse(strings.TrimSpace(server))
	if err != nil {
		return "", "", fmt.Errorf("parse server URL: %w", err)
	}
	if u.User != nil {
		return "", "", errors.New("server URL must not contain credentials")
	}
	switch strings.ToLower(u.Scheme) {
	case "wss", "https":
		if u.Scheme == "https" {
			u.Scheme = "wss"
		}
	case "ws", "http":
		if !insecureDev {
			return "", "", errors.New("plain ws:// http:// server URLs require --insecure-dev (development only)")
		}
		if u.Scheme == "http" {
			u.Scheme = "ws"
		}
	default:
		return "", "", fmt.Errorf("server URL scheme %q not supported (use wss://)", u.Scheme)
	}
	if u.Host == "" {
		return "", "", errors.New("server URL has no host")
	}
	api := *u
	switch api.Scheme {
	case "wss":
		api.Scheme = "https"
	case "ws":
		api.Scheme = "http"
	}
	api.RawQuery = ""
	api.Fragment = ""
	return u.String(), strings.TrimRight(api.String(), "/"), nil
}

// EnrollRequest is the CLI-side enrollment input. Token is a sync-broker
// routing credential: the short-lived, gateway-scoped JWT minted by the
// PocketShell web UI. It travels only as an Authorization bearer header —
// never in a URL — and it is validated locally against BrokerPolicy BEFORE
// any request is made, so a Google ID token (or any other credential with
// sync authority) is refused without ever leaving the machine (F-09).
type EnrollRequest struct {
	// APIBase is the https:// (or http:// with --insecure-dev) gateway base.
	APIBase string
	// Token is the broker routing credential read from stdin.
	Token string
	// Policy bounds the local credential-shape guard; zero Issuer selects
	// ProductionBrokerPolicy. Dev labs override the issuer explicitly (and
	// only with --insecure-dev).
	Policy BrokerPolicy
	// DeviceID is the requested device ID (server validates the format).
	DeviceID string
	// Key is the device identity key.
	Key ed25519.PrivateKey
	// SSHHostKey is the pinned authorized_keys line of the local sshd.
	SSHHostKey string
	// Reenroll requests explicit replacement of an existing registration
	// (the gateway may have re-enrollment disabled entirely).
	Reenroll bool
	// Client is the HTTP client to use (defaults to one with sane
	// timeouts; TLS verification is never disabled).
	Client *http.Client
	// Now overrides the clock for the local credential check (tests).
	Now func() time.Time
}

// challengeResponse mirrors identity's POST /identity/v1/challenge.
type challengeResponse struct {
	ChallengeID     string `json:"challenge_id"`
	DeviceID        string `json:"device_id"`
	AccountID       string `json:"account_id"`
	Nonce           string `json:"nonce"`
	ConnectionNonce string `json:"connection_nonce"`
	ExpiresAt       int64  `json:"expires_at"`
	Domain          string `json:"domain"`
	Role            string `json:"role"`
	Protocol        string `json:"protocol"`
	// Transcript is base64 (std) of the bare challenge transcript (the
	// identity.Challenge.Transcript() bytes) for cross-checking only:
	// enrollment signatures cover the FULL enrollment payload (which
	// embeds these bindings), produced by identity.SignEnrollment.
	Transcript string `json:"transcript"`
}

type enrollRequest struct {
	DeviceID    string `json:"device_id"`
	PublicKey   string `json:"public_key"`   // base64 std of raw 32-byte Ed25519 public key
	SSHHostKey  string `json:"ssh_host_key"` // pinned OpenSSH public host key line
	ChallengeID string `json:"challenge_id"`
	Signature   string `json:"signature"` // base64 std Ed25519 over identity.EnrollmentTranscript (v2)
	Reenroll    bool   `json:"re_enroll"`
}

type deviceResponse struct {
	ID         string `json:"id"`
	AccountID  string `json:"account_id"`
	PublicKey  string `json:"public_key"`
	SSHHostKey string `json:"ssh_host_key"`
	Revoked    bool   `json:"revoked"`
}

// challengeFromResponse rebuilds the identity.Challenge from the challenge
// endpoint's wire fields through the SHARED identity.ChallengeFromWire
// helper — the exact function the server-side contract is defined against
// (finding F-08: the previous hand-rolled transcript parser did not strip
// the canonical `pocketshell-challenge-v1` domain prefix, so every real
// enrollment failed). The server-provided transcript bytes must round-trip
// byte-exactly against the rebuilt challenge, so any drift between the
// advertised JSON fields and the canonical encoding fails closed here
// rather than getting signed.
func challengeFromResponse(ch challengeResponse) (*identity.Challenge, error) {
	if ch.ChallengeID == "" || ch.Nonce == "" {
		return nil, errors.New("challenge response: missing fields")
	}
	if ch.Role != identity.RoleEnroll || ch.Protocol != identity.ProtocolIdentity {
		return nil, fmt.Errorf("challenge response: unexpected role/protocol %s/%s", ch.Role, ch.Protocol)
	}
	if ch.ExpiresAt <= 0 {
		return nil, errors.New("challenge response: missing or non-positive expires_at")
	}
	challenge, err := identity.ChallengeFromWire(
		ch.ChallengeID, ch.DeviceID, ch.AccountID, ch.Role, ch.Protocol,
		ch.Domain, ch.Nonce, ch.ConnectionNonce, ch.ExpiresAt,
	)
	if err != nil {
		return nil, fmt.Errorf("challenge response: %w", err)
	}
	want, err := challenge.Transcript()
	if err != nil {
		return nil, err
	}
	serverTranscript, err := base64.StdEncoding.DecodeString(ch.Transcript)
	if err != nil {
		return nil, errors.New("challenge response: bad transcript encoding")
	}
	if !bytes.Equal(want, serverTranscript) {
		return nil, errors.New("challenge response: transcript differs from advertised fields")
	}
	return challenge, nil
}

// Enroll runs the identity enrollment contract: request a single-use
// challenge bound to the authenticated account and device, verify its
// server-provided transcript against the canonical identity encoding and
// the advertised fields, then prove possession of the device key by
// signing the v2 enrollment payload (challenge binding + public key +
// SSH host key + re-enroll mode) with the shared identity primitive.
func Enroll(ctx context.Context, req EnrollRequest) (confirmedDeviceID string, err error) {
	if req.Token == "" {
		return "", errors.New("refusing to send: no credential provided (get a gateway token from the PocketShell web UI)")
	}
	if req.DeviceID == "" {
		return "", errors.New("enroll: empty device id")
	}
	if !identity.ValidDeviceID(req.DeviceID) {
		return "", fmt.Errorf("enroll: device id %q is not valid (letters, digits, . _ : -, 3..64 chars)", req.DeviceID)
	}
	if !identity.ValidSSHHostKey(req.SSHHostKey) {
		return "", errors.New("enroll: ssh host key is not a valid OpenSSH public key line")
	}
	// F-09 disclosure guard: validate the credential's claimed shape
	// LOCALLY, before any HTTP request. This is not authentication — the
	// gateway verifies the signature — but it guarantees this CLI never
	// transmits a Google ID token or any other non-broker credential.
	policy := req.Policy
	if policy.Issuer == "" {
		policy = ProductionBrokerPolicy()
	}
	now := req.Now
	if now == nil {
		now = time.Now
	}
	if err := ValidateBrokerCredential(req.Token, policy, now()); err != nil {
		return "", err
	}
	client := req.Client
	if client == nil {
		client = &http.Client{Timeout: 15 * time.Second}
	}

	// 1. Challenge (bearer token in the Authorization header only).
	chJSON, err := postJSON(ctx, client, req.APIBase+"/identity/v1/challenge", req.Token,
		struct {
			DeviceID string `json:"device_id"`
		}{DeviceID: req.DeviceID})
	if err != nil {
		return "", fmt.Errorf("challenge: %w", err)
	}
	var ch challengeResponse
	if err := json.Unmarshal(chJSON, &ch); err != nil {
		return "", fmt.Errorf("challenge response: %w", err)
	}
	if ch.DeviceID != req.DeviceID {
		return "", fmt.Errorf("challenge response: device %q does not match request %q", ch.DeviceID, req.DeviceID)
	}
	if ch.ExpiresAt > 0 && time.Unix(ch.ExpiresAt, 0).Before(time.Now()) {
		return "", errors.New("challenge response: already expired")
	}

	// 2. Rebuild the challenge through the shared identity wire contract
	// and cross-check the server transcript bytes against it (F-08).
	challenge, err := challengeFromResponse(ch)
	if err != nil {
		return "", err
	}

	pub, ok := req.Key.Public().(ed25519.PublicKey)
	if !ok {
		return "", errors.New("enroll: key is not Ed25519")
	}
	// v2 enrollment payload signature via the shared identity primitive —
	// the exact function the server verifies (no fallback format).
	sig, err := identity.SignEnrollment(req.Key, pub, challenge, req.SSHHostKey, req.Reenroll)
	if err != nil {
		return "", fmt.Errorf("sign enrollment: %w", err)
	}

	// 3. Submit the enrollment. postJSON encodes the struct exactly once
	// (F-08: the body was previously marshalled twice, sending a base64
	// JSON string instead of the enrollment object).
	devJSON, err := postJSON(ctx, client, req.APIBase+"/identity/v1/enroll", req.Token, enrollRequest{
		DeviceID:    req.DeviceID,
		PublicKey:   base64.StdEncoding.EncodeToString(pub),
		SSHHostKey:  req.SSHHostKey,
		ChallengeID: ch.ChallengeID,
		Signature:   base64.StdEncoding.EncodeToString(sig),
		Reenroll:    req.Reenroll,
	})
	if err != nil {
		return "", fmt.Errorf("enroll: %w", err)
	}
	var dev deviceResponse
	if err := json.Unmarshal(devJSON, &dev); err != nil {
		return "", fmt.Errorf("enroll response: %w", err)
	}
	if dev.ID != req.DeviceID {
		return "", fmt.Errorf("enroll response: device id %q does not match request %q", dev.ID, req.DeviceID)
	}
	if dev.Revoked {
		return "", errors.New("enroll response: device is revoked")
	}
	return dev.ID, nil
}

func postJSON(ctx context.Context, client *http.Client, url, token string, body any) ([]byte, error) {
	raw, err := json.Marshal(body)
	if err != nil {
		return nil, err
	}
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(raw))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Accept", "application/json")
	// Bearer token in the header only — never in a URL.
	httpReq.Header.Set("Authorization", "Bearer "+token)
	res, err := client.Do(httpReq)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK && res.StatusCode != http.StatusCreated {
		// Failure output policy: the peer's failure body — and the wire
		// reason phrase — is withheld ENTIRELY. The request carried the
		// broker credential in the Authorization header, so a misbehaving
		// gateway or on-path proxy can echo that credential back in its
		// error text, wholly or cut or re-encoded; a bounding renderer
		// (sanitizePeerReason truncates first) would leak a long JWT's
		// prefix, and no redaction can enumerate every partial/reversible
		// encoding. The error therefore contains only bytes this process
		// produced: the numeric status parsed from the response, Go's own
		// canonical status text, and this constant phrase. Ordinary peer
		// reasons are intentionally not surfaced on the enroll path (the
		// status code keeps triage useful); enrollment stays fail-closed
		// and re-enrollment semantics are unchanged. The body is not even
		// read: it is never rendered or parsed.
		return nil, fmt.Errorf("HTTP %d %s: gateway rejected the request (peer failure body withheld)",
			res.StatusCode, http.StatusText(res.StatusCode))
	}
	return io.ReadAll(io.LimitReader(res.Body, 64<<10))
}

// SignTunnelBytes is a small convenience for tests and tooling: signs
// arbitrary bytes with std-base64 encoding (used by the docker test kit).
func SignTunnelBytes(key ed25519.PrivateKey, data []byte) string {
	return base64.StdEncoding.EncodeToString(ed25519.Sign(key, data))
}

// ProtocolName re-exports the tunnel protocol identifier for docs/CLI help.
const ProtocolName = tunnel.ProtocolTunnel
