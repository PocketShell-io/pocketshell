package hostagent

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"sync"
	"testing"
	"time"

	"golang.org/x/crypto/ssh"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
)

// --- the real identity.Service over HTTP (finding F-08) ---------------------
//
// The previous implementation hand-rolled a transcript parser that never
// stripped the canonical `pocketshell-challenge-v1` prefix and JSON-encoded
// the enrollment body twice, so the REAL CLI could not enroll against the
// REAL identity API. These tests run hostagent.Enroll against an actual
// identity.Service HTTP handler — the same wire contract production uses.

type fixedVerifier map[string]identity.Principal

func (f fixedVerifier) VerifyToken(_ context.Context, token string) (identity.Principal, error) {
	if p, ok := f[token]; ok {
		return p, nil
	}
	return identity.Principal{}, errors.New("unknown token")
}

const (
	testAccount = "google:alice-sub-111"
	testDomain  = "127.0.0.1"
)

// validBrokerToken mints a credential with the exact shape the F-09 guard
// requires (the guard checks shape locally; the fake verifier accepts the
// string on the server side).
func validBrokerToken(t *testing.T, now time.Time) string {
	t.Helper()
	return mustJWT(t,
		map[string]any{"alg": "RS256", "kid": "broker-key-1"},
		map[string]any{
			"iss":   ProductionBrokerIssuer,
			"aud":   BrokerAudience,
			"scope": BrokerScope,
			"exp":   now.Add(4 * time.Minute).Unix(),
			"iat":   now.Unix(),
		})
}

func newIdentityServer(t *testing.T) (*identity.Service, *httptest.Server, *identity.MemoryStore) {
	t.Helper()
	token := validBrokerToken(t, time.Now())
	mem := identity.NewMemoryStore()
	svc, err := identity.NewService(identity.Config{
		Verifier: fixedVerifier{
			token: {AccountID: testAccount, Email: "alice@example.com",
				ExpiresAt: time.Now().Add(5 * time.Minute)},
		},
		Store:  mem,
		Domain: testDomain,
		Clock:  time.Now,
	})
	if err != nil {
		t.Fatal(err)
	}
	ts := httptest.NewServer(svc)
	t.Cleanup(ts.Close)
	return svc, ts, mem
}

func testHostKeyLine(t *testing.T) string {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	signer, err := ssh.NewSignerFromKey(priv)
	if err != nil {
		t.Fatal(err)
	}
	return strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))
}

// TestEnrollAgainstRealIdentityService: the full enrollment contract
// against the actual identity HTTP API — challenge fetch, shared
// ChallengeFromWire decoding, SignEnrollment over the v2 payload, and a
// body encoded exactly once (the real identity handler decodes strictly,
// so double encoding is an automatic failure here).
func TestEnrollAgainstRealIdentityService(t *testing.T) {
	idSvc, ts, mem := newIdentityServer(t)
	token := validBrokerToken(t, time.Now())
	hostKey := testHostKeyLine(t)
	_, key, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}

	devID := "dev-cli-enroll-1"
	got, err := Enroll(context.Background(), EnrollRequest{
		APIBase:    ts.URL,
		Token:      token,
		DeviceID:   devID,
		Key:        key,
		SSHHostKey: hostKey,
	})
	if err != nil {
		t.Fatalf("enroll against real identity service: %v", err)
	}
	if got != devID {
		t.Fatalf("confirmed device id %q, want %q", got, devID)
	}
	dev, err := mem.GetDevice(devID)
	if err != nil {
		t.Fatalf("device not in registry: %v", err)
	}
	if dev.AccountID != testAccount {
		t.Fatalf("owner %q, want %q", dev.AccountID, testAccount)
	}
	if dev.SSHHostKey != hostKey {
		t.Fatal("pinned ssh host key differs from the submitted line")
	}
	pub := key.Public().(ed25519.PublicKey)
	if string(dev.PublicKey) != string(pub) {
		t.Fatal("registered public key differs")
	}
	// The identity service must agree the device exists (round trip).
	if _, err := idSvc.Store().GetDevice(devID); err != nil {
		t.Fatalf("store readback: %v", err)
	}
}

// TestEnrollCanonicalTranscriptVector pins the canonical wire contract:
// the transcript the CLI signs starts with the `pocketshell-challenge-v1`
// domain separator (the prefix the old F-08 parser read as a length) and
// is exactly the 4-byte big-endian length-prefixed field sequence.
func TestEnrollCanonicalTranscriptVector(t *testing.T) {
	const (
		chID   = "fixed-challenge-id-0123456789abcdef"
		devID  = "dev-vector-device"
		acctID = "google:vector-account"
		role   = identity.RoleEnroll
		proto  = identity.ProtocolIdentity
		dom    = "gateway.example.com"
		nonce  = "AAECAwQFBgcICQ=="
		conn   = "CgsMDQ4PEBESExQ="
		exp    = int64(1893456000)
	)
	ch, err := identity.ChallengeFromWire(chID, devID, acctID, role, proto, dom, nonce, conn, exp)
	if err != nil {
		t.Fatal(err)
	}
	got, err := ch.Transcript()
	if err != nil {
		t.Fatal(err)
	}

	prefix := []byte("pocketshell-challenge-v1")
	if !bytesHasPrefix(got, prefix) {
		t.Fatalf("transcript does not start with the canonical domain separator: %q", got[:min(40, len(got))])
	}
	lp := func(dst []byte, s string) []byte {
		var l [4]byte
		binary.BigEndian.PutUint32(l[:], uint32(len(s)))
		return append(append(dst, l[:]...), s...)
	}
	want := append([]byte{}, prefix...)
	want = lp(want, role)
	want = lp(want, proto)
	want = lp(want, dom)
	want = lp(want, devID)
	want = lp(want, acctID)
	want = lp(want, nonce)
	want = lp(want, conn)
	want = lp(want, "1893456000")
	if string(got) != string(want) {
		t.Fatalf("canonical transcript drift:\n got %x\nwant %x", got, want)
	}
}

// TestEnrollRejectsTamperedChallenge: a man-in-the-middle (or lying
// gateway) that alters ANY signed binding of the challenge response is
// refused before anything is signed — the server-provided transcript must
// round-trip byte-exactly against the advertised fields.
func TestEnrollRejectsTamperedChallenge(t *testing.T) {
	upstream, _, _ := newIdentityServer(t)
	hostKey := testHostKeyLine(t)
	_, key, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}

	mutate := map[string]func(map[string]any){
		"device_id":  func(m map[string]any) { m["device_id"] = "dev-elsewhere" },
		"account_id": func(m map[string]any) { m["account_id"] = "google:attacker" },
		"domain":     func(m map[string]any) { m["domain"] = "evil.example.com" },
		"nonce": func(m map[string]any) {
			m["nonce"] = base64.StdEncoding.EncodeToString([]byte("attacker-chosen-nonce!!"))
		},
		"connection_nonce": func(m map[string]any) {
			m["connection_nonce"] = base64.StdEncoding.EncodeToString([]byte("replay-conn-nonce-000000"))
		},
		"expires_at": func(m map[string]any) { m["expires_at"] = time.Now().Add(time.Hour).Unix() + 3600 },
		"role":       func(m map[string]any) { m["role"] = "host" },
		"protocol":   func(m map[string]any) { m["protocol"] = "pocketshell-tunnel/1" },
		"transcript": func(m map[string]any) {
			m["transcript"] = base64.StdEncoding.EncodeToString([]byte("forged-transcript-bytes"))
		},
	}
	for name, fn := range mutate {
		t.Run(name, func(t *testing.T) {
			var tampered bool
			token := validBrokerToken(t, time.Now())
			srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.URL.Path == "/identity/v1/challenge" {
					// Serve the honest identity response in-process, then
					// alter it the way an on-path attacker would.
					rec := httptest.NewRecorder()
					upstream.ServeHTTP(rec, r)
					var m map[string]any
					if err := json.Unmarshal(rec.Body.Bytes(), &m); err != nil {
						t.Errorf("upstream challenge: %v", err)
						return
					}
					fn(m)
					tampered = true
					w.Header().Set("Content-Type", "application/json")
					_ = json.NewEncoder(w).Encode(m)
					return
				}
				// The client must refuse the tampered challenge before it
				// would ever submit an enrollment.
				http.Error(w, "enroll must not be reached", http.StatusBadGateway)
			}))
			t.Cleanup(srv.Close)
			_, err := Enroll(context.Background(), EnrollRequest{
				APIBase:    srv.URL,
				Token:      token,
				DeviceID:   "dev-tamper-target",
				Key:        key,
				SSHHostKey: hostKey,
			})
			if err == nil {
				t.Fatalf("tampered %s accepted", name)
			}
			if !tampered {
				t.Fatal("challenge was never served")
			}
		})
	}
}

// TestEnrollSecondJSONEncodingRejected proves the body is encoded exactly
// once: the real identity handler decodes strictly, so the historical
// double-encoded body (a base64 JSON *string*) would be rejected here.
// The positive test above IS this regression; this test pins the negative
// explicitly by feeding the old broken body shape.
func TestEnrollSecondJSONEncodingRejected(t *testing.T) {
	_, ts, _ := newIdentityServer(t)
	body := fmt.Sprintf("%q", "not-an-object") // a JSON string, like the old bug
	req, err := http.NewRequest(http.MethodPost, ts.URL+"/identity/v1/enroll", strings.NewReader(body))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+validBrokerToken(t, time.Now()))
	res, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	if res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated {
		t.Fatal("identity service accepted a JSON-string body; double encoding would go unnoticed")
	}
}

// --- tiny helpers (avoid importing tunnel test helpers) ---------------------

func bytesHasPrefix(b, p []byte) bool { return len(b) >= len(p) && string(b[:len(p)]) == string(p) }

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// --- enroll failure output withholds the peer body (credential-reflection
// repair, opus-routing-diagnostics F2) ---------------------------------------
//
// The failure body of an enrollment HTTP request — and the wire reason
// phrase — is fully peer-controlled, and a misbehaving gateway or on-path
// proxy legitimately sees the Authorization bearer header and can echo it
// back: wholly, cut to any length, or re-encoded. postJSON therefore
// renders NO peer bytes on failure: the error carries the numeric status
// plus Go's own canonical status text and a fixed constant phrase.
//
// A bounding, control-escaping renderer (the run path's former
// sanitizePeerReason) is not a redactor: it truncates BEFORE any redaction
// could run, so a >256-byte JWT would leak its prefix, and no practical
// redaction covers every partial or reversible encoding of a known
// credential. Withholding the whole body makes the no-credential-print
// property structural rather than best-effort. Ordinary gateway reasons are
// intentionally NOT surfaced on the enroll path — the status code keeps
// triage useful (401 bad/expired token, 403 forbidden, 404 unknown device,
// 429 rate limit, 5xx server fault) — and the run path withholds its
// peer-controlled diagnostics the same way now (ErrMsg messages and close
// reasons are never rendered; only canonical code literals and fixed
// phrases). Fail-closed and re-enrollment semantics are unchanged.

// startProbeOnlySSHD starts a minimal loopback sshd whose Ed25519 host key
// the enrollment probe pins. The probe stops at its verified-host-key
// callback and never reaches userauth; the callback exists only to satisfy
// the server handshake shape.
func startProbeOnlySSHD(t *testing.T) (addr, hostKeyLine string) {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	signer, err := ssh.NewSignerFromKey(priv)
	if err != nil {
		t.Fatal(err)
	}
	cfg := &ssh.ServerConfig{
		PublicKeyCallback: func(ssh.ConnMetadata, ssh.PublicKey) (*ssh.Permissions, error) {
			return &ssh.Permissions{}, nil // never reached by the probe
		},
	}
	cfg.AddHostKey(signer)
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { ln.Close() })
	go func() {
		for {
			c, err := ln.Accept()
			if err != nil {
				return
			}
			go func() {
				defer c.Close()
				// Returns an error when the probe disconnects at its
				// verified-host-key stop; that is the expected path.
				_, _, _, _ = ssh.NewServerConn(c, cfg)
			}()
		}
	}()
	return ln.Addr().String(), strings.TrimSpace(string(ssh.MarshalAuthorizedKey(signer.PublicKey())))
}

// receivedAuth records the Authorization header the client actually
// transmitted (mutex-protected: the handler runs on the server goroutine).
type receivedAuth struct {
	mu            sync.Mutex
	authorization string
}

func (r *receivedAuth) set(v string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.authorization = v
}

func (r *receivedAuth) get() string {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.authorization
}

// reflectingAuthServer answers every request with the given HTTP status and
// a failure body that reflects back the exact bearer credential the client
// transmitted — whole, cut to the old 256-byte input bound and shorter,
// and re-encoded several reversible ways — plus raw terminal controls. It
// is a normal local fixture for a misbehaving gateway or logging proxy.
func reflectingAuthServer(t *testing.T, status int) (*httptest.Server, *receivedAuth) {
	t.Helper()
	got := &receivedAuth{}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got.set(r.Header.Get("Authorization"))
		auth := strings.TrimPrefix(got.get(), "Bearer ")
		body := fmt.Sprintf("invalid credential %q (auth=%s)\n\x1b[2Jforged\nline\nprefix=%s cut=%s tail=%s url=%q b64=%s b64url=%s hex=%s",
			auth, got.authorization,
			cut(auth, 256), cut(auth, 96), cutTail(auth, 64),
			url.QueryEscape(auth),
			base64.StdEncoding.EncodeToString([]byte(auth)),
			base64.URLEncoding.EncodeToString([]byte(auth)),
			hex.EncodeToString([]byte(auth)))
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.WriteHeader(status)
		_, _ = w.Write([]byte(body))
	}))
	t.Cleanup(srv.Close)
	return srv, got
}

func cut(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}

func cutTail(s string, n int) string {
	if len(s) > n {
		return s[len(s)-n:]
	}
	return s
}

// encodedVariants lists reversible re-encodings of a reflected credential
// (whole and partial) that a peer could put in an error body.
func encodedVariants(s string) []string {
	return []string{
		url.QueryEscape(s),
		base64.StdEncoding.EncodeToString([]byte(s)),
		base64.URLEncoding.EncodeToString([]byte(s)),
		hex.EncodeToString([]byte(s)),
		base64.StdEncoding.EncodeToString([]byte(cut(s, 256))),
		url.QueryEscape(cut(s, 64)),
	}
}

// longBrokerToken is a broker-shaped credential whose encoded form is far
// past the 256-byte sanitizePeerReason input bound (long jti padding) —
// the case where the old bound-then-escape output leaked the token's
// prefix through a reflected body.
func longBrokerToken(t *testing.T, now time.Time) string {
	t.Helper()
	return mustJWT(t,
		map[string]any{"alg": "RS256", "kid": "broker-key-1"},
		map[string]any{
			"iss":   ProductionBrokerIssuer,
			"aud":   BrokerAudience,
			"scope": BrokerScope,
			"exp":   now.Add(4 * time.Minute).Unix(),
			"iat":   now.Unix(),
			"jti":   strings.Repeat("prefix-leak-canary-", 40),
		})
}

// shortBrokerToken is a minimized broker-shaped credential strictly under
// the 256-byte bound — the case where the old output repeated a reflected
// token COMPLETELY, not just as a prefix. Built inline (shared craftJWT's
// dummy signature would push the total one byte past the bound).
func shortBrokerToken(t *testing.T, now time.Time) string {
	t.Helper()
	h, err := json.Marshal(map[string]any{"alg": "RS256"})
	if err != nil {
		t.Fatal(err)
	}
	c, err := json.Marshal(map[string]any{
		"iss":   ProductionBrokerIssuer,
		"aud":   BrokerAudience,
		"scope": BrokerScope,
		"exp":   now.Add(4 * time.Minute).Unix(),
		"iat":   now.Unix(),
	})
	if err != nil {
		t.Fatal(err)
	}
	enc := base64.RawURLEncoding.EncodeToString
	token := enc(h) + "." + enc(c) + "." + enc([]byte("sig"))
	if len(token) >= 256 {
		t.Fatalf("fixture setup: short credential is %d bytes, want < 256 so the old bound repeated it whole", len(token))
	}
	return token
}

// runReflectedCredentialEnroll drives the REAL RunEnroll flow (loopback
// sshd probe, then HTTP) against the reflecting server and asserts the
// fixed-status output policy end to end: the fixture credential was really
// transmitted, the error is exactly the fixed safe message with the HTTP
// status, and no stream carries the credential in whole, part, or any
// reversible encoding.
func runReflectedCredentialEnroll(t *testing.T, token string, status int) {
	t.Helper()
	addr, _ := startProbeOnlySSHD(t)
	srv, got := reflectingAuthServer(t, status)

	var stdout, stderr bytes.Buffer
	_, err := RunEnroll(context.Background(), EnrollOptions{
		Dir:         t.TempDir(),
		Server:      srv.URL,
		Token:       token,
		DeviceID:    "dev-withhold-api",
		SSHHost:     addr,
		InsecureDev: true, // lab http:// URL
		Stdout:      &stdout,
		Stderr:      &stderr,
	})
	if err == nil {
		t.Fatal("enroll against a failing challenge endpoint succeeded")
	}

	// The fixture is meaningful: the server received the exact bearer
	// credential over HTTP before reflecting it back in the body.
	if auth := got.get(); auth != "Bearer "+token {
		t.Fatalf("server saw Authorization %q, want the transmitted bearer", auth)
	}

	// Fixed safe error: exact bytes — numeric status plus Go's own
	// canonical status text and a constant phrase; nothing peer-derived.
	want := fmt.Sprintf("challenge: HTTP %d %s: gateway rejected the request (peer failure body withheld)",
		status, http.StatusText(status))
	if err.Error() != want {
		t.Fatalf("error %q, want exactly %q", err.Error(), want)
	}
	// cmd/pocketshell-link prints exactly "enroll failed: %v\n"; mirror
	// those bytes here (the actual subprocess stderr is asserted separately
	// in cmd/pocketshell-link).
	msg := "enroll failed: " + err.Error() + "\n"

	// No declared credential — whole, any usable prefix or suffix, or any
	// reversible re-encoding — may appear in any output stream, and no raw
	// terminal control byte may reach one.
	streams := map[string]string{"stdout": stdout.String(), "stderr": stderr.String(), "cli line": msg}
	for name, out := range streams {
		if strings.Contains(out, token) {
			t.Fatalf("%s: full fixture credential leaked", name)
		}
		for n := 12; n <= len(token); n++ {
			if strings.Contains(out, token[:n]) {
				t.Fatalf("%s: credential prefix of length %d leaked: %q", name, n, token[:n])
			}
			if strings.Contains(out, token[len(token)-n:]) {
				t.Fatalf("%s: credential suffix of length %d leaked: %q", name, n, token[len(token)-n:])
			}
		}
		for _, enc := range encodedVariants(token) {
			if strings.Contains(out, enc) {
				t.Fatalf("%s: re-encoded credential variant leaked: %q", name, enc)
			}
		}
		if strings.ContainsRune(out, '\x1b') {
			t.Fatalf("%s: raw ESC byte reached enroll output", name)
		}
	}
	// Control-safety of the CLI line itself (newlines are the formatter's).
	assertTerminalSafe(t, msg, true)
}

// TestEnrollFailureOutputWithholdsPeerBody pins the enrollment failure
// output policy: a peer body that reflects the transmitted credential is
// never printed — neither a short credential repeated whole nor a long JWT
// cut to the old 256-byte rendering bound — and the useful fixed HTTP
// status survives.
func TestEnrollFailureOutputWithholdsPeerBody(t *testing.T) {
	t.Run("short reflected credential withheld whole, fixed status kept", func(t *testing.T) {
		runReflectedCredentialEnroll(t, shortBrokerToken(t, time.Now()), http.StatusUnauthorized)
	})

	t.Run("long JWT past 256-byte bound leaks no prefix", func(t *testing.T) {
		token := longBrokerToken(t, time.Now())
		if len(token) <= 256 {
			t.Fatalf("fixture setup: long credential is only %d bytes; must exceed the old 256-byte bound", len(token))
		}
		runReflectedCredentialEnroll(t, token, http.StatusUnauthorized)
	})

	t.Run("fixed safe status across failure codes", func(t *testing.T) {
		token := shortBrokerToken(t, time.Now())
		for _, status := range []int{
			http.StatusUnauthorized,
			http.StatusForbidden,
			http.StatusTooManyRequests,
			http.StatusInternalServerError,
		} {
			runReflectedCredentialEnroll(t, token, status)
		}
	})
}

// TestEnrollOrdinaryReasonIntentionallyNotSurfaced documents the UX trade
// of the withholding policy: an ordinary, non-hostile gateway reason is no
// longer echoed on the enroll path — the fixed status message replaces it.
func TestEnrollOrdinaryReasonIntentionallyNotSurfaced(t *testing.T) {
	addr, _ := startProbeOnlySSHD(t)
	got := &receivedAuth{}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got.set(r.Header.Get("Authorization"))
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		w.WriteHeader(http.StatusUnauthorized)
		_, _ = w.Write([]byte("invalid or expired token\n"))
	}))
	t.Cleanup(srv.Close)

	_, err := RunEnroll(context.Background(), EnrollOptions{
		Dir:         t.TempDir(),
		Server:      srv.URL,
		Token:       validBrokerToken(t, time.Now()),
		DeviceID:    "dev-plain-api",
		SSHHost:     addr,
		InsecureDev: true,
		Stdout:      io.Discard,
		Stderr:      io.Discard,
	})
	if err == nil {
		t.Fatal("enroll against a 401 challenge endpoint succeeded")
	}
	want := "challenge: HTTP 401 Unauthorized: gateway rejected the request (peer failure body withheld)"
	if err.Error() != want {
		t.Fatalf("error %q, want exactly %q (peer reason must stay withheld even when ordinary)", err.Error(), want)
	}
}
