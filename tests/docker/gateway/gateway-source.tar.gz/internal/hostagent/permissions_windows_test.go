package hostagent

import (
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"os"
	"path/filepath"
	"testing"

	"golang.org/x/sys/windows"
)

func TestWindowsProtectedRoundTrip(t *testing.T) {
	dir := t.TempDir()
	user, err := currentUserSID()
	if err != nil {
		t.Fatal(err)
	}
	// Deliberately permissive parent: children would inherit Everyone read
	// unless creation supplies a protected DACL.
	sd, err := windows.SecurityDescriptorFromString("D:P(A;OICI;FA;;;" + user.String() + ")(A;OICI;FR;;;WD)")
	if err != nil {
		t.Fatal(err)
	}
	dacl, _, err := sd.DACL()
	if err != nil {
		t.Fatal(err)
	}
	if err := windows.SetNamedSecurityInfo(dir, windows.SE_FILE_OBJECT, windows.DACL_SECURITY_INFORMATION|windows.PROTECTED_DACL_SECURITY_INFORMATION, nil, nil, dacl, nil); err != nil {
		t.Fatal(err)
	}
	key, created, err := LoadOrCreateKey(KeyPath(dir))
	if err != nil || !created {
		t.Fatalf("create key: created=%v err=%v", created, err)
	}
	loaded, created, err := LoadOrCreateKey(KeyPath(dir))
	if err != nil || created || !bytes.Equal(key, loaded) {
		t.Fatalf("reload key: created=%v err=%v", created, err)
	}
	c := &Config{Server: "wss://example.invalid", DeviceID: "lab", SSHHost: "127.0.0.1:22", SSHHostKey: "lab-pin"}
	for i := 0; i < 2; i++ {
		if err := SaveKey(KeyPath(dir), key); err != nil {
			t.Fatal(err)
		}
		if err := SaveConfig(dir, c); err != nil {
			t.Fatal(err)
		}
		got, err := LoadConfig(dir)
		if err != nil || got == nil || got.SSHHostKey != c.SSHHostKey {
			t.Fatalf("config reload: %v", err)
		}
	}
	// Both files must have exactly the three explicit trusted grants.
	for _, name := range []string{keyFileName, confFileName} {
		p := filepath.Join(dir, name)
		sd, err := windows.GetNamedSecurityInfo(p, windows.SE_FILE_OBJECT, windows.OWNER_SECURITY_INFORMATION|windows.DACL_SECURITY_INFORMATION)
		if err != nil {
			t.Fatal(err)
		}
		if err := validateProtectedDescriptor(sd); err != nil {
			t.Fatal(err)
		}
		dacl, _, err := sd.DACL()
		if err != nil || dacl == nil || dacl.AceCount != 3 {
			t.Fatalf("expected three explicit grants: %v", err)
		}
	}
}

func TestWindowsACLPolicy(t *testing.T) {
	user, err := currentUserSID()
	if err != nil {
		t.Fatal(err)
	}
	owner := "O:" + user.String()
	grant := "(A;;FA;;;" + user.String() + ")"
	for _, tc := range []struct {
		name string
		sddl string
		ok   bool
	}{
		{"trusted", owner + "D:P" + grant + "(A;;FA;;;SY)(A;;FA;;;BA)", true},
		{"user only", owner + "D:P" + grant, true},
		{"everyone read", owner + "D:P" + grant + "(A;;FR;;;WD)", false},
		{"users read", owner + "D:P" + grant + "(A;;FR;;;BU)", false},
		{"authenticated users write", owner + "D:P" + grant + "(A;;FW;;;AU)", false},
		{"other SID", owner + "D:P" + grant + "(A;;FR;;;S-1-5-21-1-2-3-1001)", false},
		{"inherited read", owner + "D:P" + grant + "(A;ID;FR;;;WD)", false},
		{"inherited trusted", owner + "D:P(A;ID;FA;;;" + user.String() + ")", false},
		{"inheritance enabled", owner + "D:" + grant, false},
		{"empty", owner + "D:P", false},
		{"null", owner + "D:NO_ACCESS_CONTROL", false},
		{"untrusted owner", "O:WDD:P" + grant, false},
		{"deny ACE", owner + "D:P(D;;FR;;;WD)" + grant, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			sd, err := windows.SecurityDescriptorFromString(tc.sddl)
			if err != nil {
				t.Fatal(err)
			}
			if err := validateProtectedDescriptor(sd); (err == nil) != tc.ok {
				t.Fatalf("accepted=%v want=%v err=%v", err == nil, tc.ok, err)
			}
		})
	}
}

func TestWindowsLoadRejectsPermissiveACL(t *testing.T) {
	dir := t.TempDir()
	_, key, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	if err := SaveKey(KeyPath(dir), key); err != nil {
		t.Fatal(err)
	}
	if err := SaveConfig(dir, &Config{Server: "wss://example.invalid", DeviceID: "lab", SSHHost: "127.0.0.1:22"}); err != nil {
		t.Fatal(err)
	}
	user, err := currentUserSID()
	if err != nil {
		t.Fatal(err)
	}
	sd, err := windows.SecurityDescriptorFromString("D:P(A;;FA;;;" + user.String() + ")(A;;FR;;;WD)")
	if err != nil {
		t.Fatal(err)
	}
	dacl, _, err := sd.DACL()
	if err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{keyFileName, confFileName} {
		if err := windows.SetNamedSecurityInfo(filepath.Join(dir, name), windows.SE_FILE_OBJECT, windows.DACL_SECURITY_INFORMATION|windows.PROTECTED_DACL_SECURITY_INFORMATION, nil, nil, dacl, nil); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := LoadKey(KeyPath(dir)); err == nil {
		t.Fatal("loaded key with Everyone read access")
	}
	if _, _, err := LoadOrCreateKey(KeyPath(dir)); err == nil {
		t.Fatal("accepted unsafe existing key")
	}
	if _, err := LoadConfig(dir); err == nil {
		t.Fatal("loaded config with Everyone read access")
	}
	// Failed loads do not repair or replace existing identities.
	if _, err := os.Stat(KeyPath(dir)); err != nil {
		t.Fatal(err)
	}
}
