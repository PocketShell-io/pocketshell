package routingauth

// Optional cross-language rotation vector. The sandbox lifecycle test
// (aws-infra sandbox/pocketshell-sync scripts/test-gateway-token.mjs) mints
// broker tokens with the REAL Lambda signer at every rotation intermediate —
// the retained old environment still signing OLD past its cache TTL, the
// prepublish (deploy-A) environment, and the first NEW-key issuance after
// the reference flip — and hands them to this verifier via
// BROKER_ROTATION_VECTOR, together with the overlap JWKS the broker serves
// (old+new) and the post-retirement JWKS (old kid removed). Every sample
// must verify while valid (claims, signature, its real kid) and fail closed
// once past exp plus leeway; the old-signed samples must be REJECTED by the
// actual verifier once the old kid has left the JWKS, while the new-signed
// sample still verifies from the same set. Fails unless that sandbox run
// drives it (the sandbox suite treats a missing gateway checkout or Go
// toolchain as a hard failure).

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"os"
	"strings"
	"testing"
	"time"
)

type jwksKey struct {
	Kty string `json:"kty"`
	Alg string `json:"alg"`
	Use string `json:"use"`
	Kid string `json:"kid"`
	N   string `json:"n"`
	E   string `json:"e"`
}

type jwkSet struct {
	Keys []jwksKey `json:"keys"`
}

// rotationSample is one real issuance from one rotation intermediate.
type rotationSample struct {
	Label     string `json:"label"`
	Token     string `json:"token"`
	Kid       string `json:"kid"`
	ValidAt   int64  `json:"valid_at"`   // the sample's last valid second
	ExpiredAt int64  `json:"expired_at"` // one step past exp plus leeway
}

type rotationVector struct {
	Issuer         string           `json:"issuer"`
	AllowlistEmail string           `json:"allowlist_email"`
	Samples        []rotationSample `json:"samples"`
	// JWKS is the overlap set the broker serves while old+new are both in
	// use; RemovedOldJWKS is what it serves AFTER the old key is retired.
	JWKS           jwkSet `json:"jwks"`
	RemovedOldJWKS jwkSet `json:"removed_old_jwks"`
}

// mutationEnv is the self-test hook for the removed-old negative below.
// BROKER_ROTATION_VECTOR_MUTATION=serve-old-after-removal makes the
// verifier's JWKS endpoint serve the OLD key again after its removal —
// simulating a broker that never retired the key (or a verifier that kept
// accepting it). The removed-old assertions MUST fail under this mutation;
// the sandbox release harness drives exactly this run and asserts the
// failure, proving the negative detects attempted old acceptance instead of
// passing vacuously. Production suites never set this variable.
const mutationEnv = "BROKER_ROTATION_VECTOR_MUTATION"

const mutationServeOldAfterRemoval = "serve-old-after-removal"

func TestBrokerRotationOverlapVector(t *testing.T) {
	path := os.Getenv("BROKER_ROTATION_VECTOR")
	if path == "" {
		t.Skip("BROKER_ROTATION_VECTOR not set; driven by the sandbox rotation lifecycle test")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var vec rotationVector
	if err := json.Unmarshal(raw, &vec); err != nil {
		t.Fatalf("rotation vector: %v", err)
	}
	if len(vec.Samples) == 0 || vec.Issuer == "" || vec.AllowlistEmail == "" {
		t.Fatal("rotation vector is missing required fields")
	}
	if len(vec.JWKS.Keys) == 0 || len(vec.RemovedOldJWKS.Keys) == 0 {
		t.Fatal("rotation vector must carry the overlap JWKS and the removed-old JWKS")
	}
	overlapKids := make(map[string]bool, len(vec.JWKS.Keys))
	for _, k := range vec.JWKS.Keys {
		overlapKids[k.Kid] = true
	}
	removedKids := make(map[string]bool, len(vec.RemovedOldJWKS.Keys))
	for _, k := range vec.RemovedOldJWKS.Keys {
		removedKids[k.Kid] = true
	}
	oldSamples := 0
	// The sample's kid must be the token's REAL header kid — the harness
	// cannot label a token with a kid it does not carry.
	assertKid := func(token, want, label string) {
		t.Helper()
		var header struct {
			Kid string `json:"kid"`
		}
		headerJSON, err := base64.RawURLEncoding.DecodeString(strings.SplitN(token, ".", 2)[0])
		if err != nil {
			t.Fatalf("sample %q: %v", label, err)
		}
		if err := json.Unmarshal(headerJSON, &header); err != nil {
			t.Fatalf("sample %q: %v", label, err)
		}
		if header.Kid != want {
			t.Fatalf("sample %q: token kid %q is not the declared key %q", label, header.Kid, want)
		}
	}
	for _, s := range vec.Samples {
		if s.Token == "" || s.Kid == "" || s.Label == "" || s.ValidAt == 0 || s.ExpiredAt == 0 {
			t.Fatalf("sample %+v: missing required fields", s.Label)
		}
		assertKid(s.Token, s.Kid, s.Label)
		if !overlapKids[s.Kid] {
			t.Fatalf("sample %q: overlap JWKS does not publish kid %q", s.Label, s.Kid)
		}
		if s.ExpiredAt <= s.ValidAt {
			t.Fatalf("sample %q: expired_at %d is not after valid_at %d", s.Label, s.ExpiredAt, s.ValidAt)
		}
		if !removedKids[s.Kid] {
			oldSamples++
		}
	}
	if oldSamples == 0 {
		t.Fatal("rotation vector carries no old-signed sample — the removed-old negative would be vacuous")
	}
	if !mutating() {
		// Fixture sanity: the removed-old JWKS must genuinely belong to the
		// same family (it may only drop kids, never invent them). Under the
		// mutation hook the old key is deliberately served again — that is
		// the condition the negative must detect, asserted by the sandbox
		// harness as a FAILED run.
		for kid := range removedKids {
			if !overlapKids[kid] {
				t.Fatalf("removed_old_jwks publishes kid %q that the overlap set does not — harness bug", kid)
			}
		}
	}

	t.Run("per_phase_valid_and_expired", func(t *testing.T) {
		// Each sample gets its own verifier against the overlap JWKS the
		// broker serves at that point (same-era samples have overlapping
		// validity windows, so one chronological walk cannot cover them
		// all): the token must verify at its own valid time — claims,
		// signature, its real kid — and fail closed at expired_at (past
		// exp plus leeway).
		h := newJWKSHarness(t, mustMarshal(t, vec.JWKS))
		for _, s := range vec.Samples {
			clock := newFakeClock(s.ValidAt)
			v := newTestVerifier(t, h, clock, func(c *Config) {
				c.Issuer = vec.Issuer
				c.Allowlist = []string{vec.AllowlistEmail}
			})
			got, err := v.VerifyToken(context.Background(), s.Token)
			if err != nil {
				t.Fatalf("sample %q must verify at %d through the overlap window: %v", s.Label, s.ValidAt, err)
			}
			if got.AccountID == "" || !strings.HasPrefix(got.AccountID, "google:") {
				t.Fatalf("sample %q: AccountID = %q, want google:<sub>", s.Label, got.AccountID)
			}
			if got.Email != vec.AllowlistEmail {
				t.Fatalf("sample %q: Email = %q, want %q", s.Label, got.Email, vec.AllowlistEmail)
			}
			clock.Advance(time.Duration(s.ExpiredAt-s.ValidAt) * time.Second)
			if _, err := v.VerifyToken(context.Background(), s.Token); !errors.Is(err, ErrUnauthorized) {
				t.Fatalf("sample %q expired at %d must fail closed, got %v", s.Label, s.ExpiredAt, err)
			}
		}
	})

	t.Run("removed_old_jwks_rejects_old_accepts_new", func(t *testing.T) {
		// The strong negative runs the ACTUAL verifier against the JWKS
		// served after the old key's retirement: an old-signed token —
		// whose claims are still inside their validity window, so claims
		// checking cannot be the reason — must be rejected with
		// ErrUnauthorized because its kid is gone, and the new-signed
		// token must still verify from the same set.
		served := vec.RemovedOldJWKS
		if mutating() {
			// Re-serve the old keys: under the mutation the old-signed
			// token is ACCEPTED again, and the assertion below must fail
			// loudly. A green run under this hook would mean the negative
			// is tautological.
			served = jwkSet{Keys: append(append([]jwksKey{}, vec.RemovedOldJWKS.Keys...), vec.JWKS.Keys...)}
		}
		h := newJWKSHarness(t, mustMarshal(t, served))
		for _, s := range vec.Samples {
			clock := newFakeClock(s.ValidAt)
			v := newTestVerifier(t, h, clock, func(c *Config) {
				c.Issuer = vec.Issuer
				c.Allowlist = []string{vec.AllowlistEmail}
			})
			_, err := v.VerifyToken(context.Background(), s.Token)
			if removedKids[s.Kid] {
				// The new-signed (still-published) sample keeps verifying.
				if err != nil {
					t.Fatalf("sample %q (kid still published) must verify after the old key's removal: %v", s.Label, err)
				}
				continue
			}
			if !errors.Is(err, ErrUnauthorized) {
				t.Fatalf("MUTATION DETECTED — attempted old acceptance: old-signed sample %q was NOT rejected (err=%v) from the JWKS served after its kid's removal; the removed-old negative is live", s.Label, err)
			}
			t.Logf("sample %q rejected with ErrUnauthorized from the removed-old JWKS (kid unpublished, claims still in-window)", s.Label)
		}
	})
}

func mutating() bool {
	return os.Getenv(mutationEnv) == mutationServeOldAfterRemoval
}

func mustMarshal(t *testing.T, v any) string {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	return string(b)
}
