// Package routingauth verifies the short-lived gateway credentials minted
// by the separately trusted PocketShell sync service (the "auth broker").
//
// Trust boundary: the gateway must NEVER see the user's Google bearer
// token — that token authorizes sync reads/writes/deletes of the encrypted
// settings and destructive sync operations. Instead, the sync service
// exchanges the Google ID token (which never leaves it) for an RS256 JWT
// that is valid only for the gateway — SSH routing plus this account's
// device enrollment/listing/revocation — with a fixed issuer (the sync API
// base URL), fixed audience ("pocketshell-gateway"), ≤5-minute lifetime, a
// route-permission scope, and the verified account identity. This package
// verifies exactly that token shape against the broker's PUBLIC keys and
// nothing else — there is no discovery, no shared secret, and no way for a
// Google token (or a sync session) to authenticate here.
//
// The package imports internal/identity ONLY for the Principal type so a
// routingauth.Verifier is a drop-in for the gateway's verifier interface
// (VerifyToken(context.Context, string) (identity.Principal, error), the
// same method set as identity.TokenVerifier). It never imports tunnel.
package routingauth

import (
	"context"
	"crypto"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
)

// ErrUnauthorized is returned (wrapped) for every rejected token. Reasons
// are logged, never returned to clients, and never contain token material.
var ErrUnauthorized = errors.New("routingauth: unauthorized")

const (
	// Audience is the aud claim the broker mints into gateway tokens.
	Audience = "pocketshell-gateway"
	// ScopeGatewayRoute is the fixed permission marker for the gateway
	// surface: SSH routing plus this account's device
	// enrollment/listing/revocation — not routing-only, and not a blank
	// check for anything else. Tokens with a different or missing scope are
	// rejected, so a future broker scope for some other protocol cannot
	// silently become valid here.
	ScopeGatewayRoute = "pocketshell.gateway"
	// MaxTokenLifetime is both the DEFAULT and the MAXIMUM accepted
	// exp-iat span. The broker caps issuance at five minutes; a verifier
	// configured to allow more would honor tokens the broker contract
	// never mints, so NewVerifier rejects larger values.
	MaxTokenLifetime = 5 * time.Minute
)

// Config configures a Verifier. The zero value fails closed: Issuer and
// JWKSURL are required.
type Config struct {
	// Issuer is the exact iss claim of broker tokens: the sync API's
	// public base URL (e.g. https://<api-id>.execute-api.eu-west-1
	// .amazonaws.com). Compared byte-for-byte after normalization of a
	// single trailing slash. Required.
	Issuer string
	// JWKSURL is the fixed broker public-key URL
	// (https://<sync API>/gateway/jwks). HTTPS only; there is no OIDC
	// discovery and the URL is never taken from token headers (no jku/x5u).
	// Required.
	JWKSURL string
	// Audience overrides the expected aud claim (default Audience).
	Audience string
	// Allowlist is the set of permitted verified emails (case-insensitive).
	// Empty denies everyone — the existing rollout semantics.
	Allowlist []string
	// HTTPClient fetches the JWKS. Defaults to a client with a 10s timeout
	// that refuses redirects — the key URL is pinned in configuration and
	// must never silently hop to another host.
	HTTPClient *http.Client
	// Clock defaults to time.Now.
	Clock func() time.Time
	// CacheTTL is how long a fetched JWKS may be used. Past the TTL a
	// refresh is mandatory and a failed refresh REJECTS the token (no
	// unbounded stale-key serving — broker tokens live only 5 minutes, so
	// a bounded cache is enough to cover rotation overlap). Default 5m.
	CacheTTL time.Duration
	// RefreshCooldown is the minimum spacing of forced refreshes when an
	// unknown kid appears, so a flood of garbage tokens cannot storm the
	// broker. Default 30s.
	RefreshCooldown time.Duration
	// Leeway tolerates small clock skew on exp/iat/nbf. Default 30s.
	Leeway time.Duration
	// MaxLifetime rejects tokens whose exp-iat exceeds the bound. Default
	// AND hard maximum: MaxTokenLifetime (5 minutes) — the broker never
	// mints longer tokens, and NewVerifier fails a configuration that
	// asks to accept them.
	MaxLifetime time.Duration
	// MaxTokenBytes bounds token size. Default 8192.
	MaxTokenBytes int
	// MaxJWKSBytes bounds the JWKS response body. Default 1 MiB.
	MaxJWKSBytes int
	// MaxKeys bounds the number of published keys. Default 16.
	MaxKeys int
	// AllowInsecureDev permits plain-HTTP Issuer/JWKSURL values for local
	// Docker fixtures. It defaults to false, and setting it never disables
	// HTTPS verification: an https:// issuer/JWKS is always verified
	// exactly as in production, and there is no wildcard, discovery, or
	// token-header-driven key source in either mode. Root integration may
	// pass true ONLY for plain-HTTP development runs (no public domain,
	// explicit --broker-allow-insecure-dev); production wiring must leave
	// it false.
	AllowInsecureDev bool
	// Logger receives rejection reasons; it must never receive token
	// material.
	Logger func(format string, args ...any)
}

// Verifier verifies broker-issued RS256 gateway tokens against a cached
// JWKS, with claims checks and the rollout email allowlist. It implements
// the same method set as identity.TokenVerifier.
type Verifier struct {
	issuer     string
	jwksURL    string
	audience   string
	allow      []string // lowercased
	client     *http.Client
	clock      func() time.Time
	ttl        time.Duration
	cooldown   time.Duration
	leeway     time.Duration
	maxLife    time.Duration
	maxToken   int
	maxJWKS    int
	maxKeys    int
	logger     func(string, ...any)
	defaultNow func() time.Time

	// mu guards the cache state and refresh bookkeeping below. It is never
	// held across network I/O: refreshes run single-flight in a detached
	// goroutine and waiters block on the done channel, honoring their own
	// context cancellation.
	mu          sync.Mutex
	keys        map[string]*rsa.PublicKey
	fetchedAt   time.Time
	lastAttempt time.Time
	refreshing  chan struct{} // non-nil while one refresh fetch is in flight
}

// NewVerifier builds a verifier. It fails closed on a configuration that
// cannot be honored (missing issuer/JWKS URL, non-https JWKS URL).
func NewVerifier(cfg Config) (*Verifier, error) {
	issuer, err := normalizeIssuer(cfg.Issuer, cfg.AllowInsecureDev)
	if err != nil {
		return nil, fmt.Errorf("routingauth: %w", err)
	}
	jwksURL, err := fixedJWKSURL(cfg.JWKSURL, cfg.AllowInsecureDev)
	if err != nil {
		return nil, fmt.Errorf("routingauth: %w", err)
	}
	clock := cfg.Clock
	if clock == nil {
		clock = time.Now
	}
	client := cfg.HTTPClient
	if client == nil {
		client = &http.Client{
			Timeout: 10 * time.Second,
			CheckRedirect: func(*http.Request, []*http.Request) error {
				// The JWKS URL is pinned in configuration; a redirect
				// would silently move key trust to another host.
				return http.ErrUseLastResponse
			},
		}
	}
	ttl := cfg.CacheTTL
	if ttl <= 0 {
		ttl = 5 * time.Minute
	}
	cooldown := cfg.RefreshCooldown
	if cooldown <= 0 {
		cooldown = 30 * time.Second
	}
	leeway := cfg.Leeway
	if leeway < 0 {
		leeway = 0
	}
	maxLife := cfg.MaxLifetime
	if maxLife <= 0 {
		maxLife = MaxTokenLifetime
	}
	if maxLife > MaxTokenLifetime {
		return nil, fmt.Errorf("routingauth: MaxLifetime %v exceeds the broker bound of %v", maxLife, MaxTokenLifetime)
	}
	maxToken := cfg.MaxTokenBytes
	if maxToken <= 0 {
		maxToken = 8192
	}
	maxJWKS := cfg.MaxJWKSBytes
	if maxJWKS <= 0 {
		maxJWKS = 1 << 20
	}
	maxKeys := cfg.MaxKeys
	if maxKeys <= 0 {
		maxKeys = 16
	}
	logger := cfg.Logger
	if logger == nil {
		logger = func(string, ...any) {}
	}
	audience := cfg.Audience
	if audience == "" {
		audience = Audience
	}
	allow := make([]string, 0, len(cfg.Allowlist))
	for _, e := range cfg.Allowlist {
		e = strings.ToLower(strings.TrimSpace(e))
		if e != "" {
			allow = append(allow, e)
		}
	}
	return &Verifier{
		issuer:   issuer,
		jwksURL:  jwksURL,
		audience: audience,
		allow:    allow,
		client:   client,
		clock:    clock,
		ttl:      ttl,
		cooldown: cooldown,
		leeway:   leeway,
		maxLife:  maxLife,
		maxToken: maxToken,
		maxJWKS:  maxJWKS,
		maxKeys:  maxKeys,
		logger:   logger,
	}, nil
}

// normalizeIssuer pins the exact iss value: an https origin (http only
// under AllowInsecureDev) plus an optional path, with one trailing slash
// removed, no query/fragment/userinfo.
func normalizeIssuer(issuer string, allowInsecureDev bool) (string, error) {
	if issuer == "" {
		return "", errors.New("issuer is required")
	}
	u, err := url.Parse(issuer)
	if err != nil {
		return "", fmt.Errorf("issuer is not a URL: %w", err)
	}
	if !schemeAllowed(u.Scheme, allowInsecureDev) || u.Host == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return "", fmt.Errorf("issuer %q must be an https origin (optionally with a path)%s",
			issuer, insecureHint(allowInsecureDev))
	}
	u.Path = strings.TrimSuffix(u.Path, "/")
	return u.String(), nil
}

// fixedJWKSURL validates the one trusted key URL: https (http only under
// AllowInsecureDev), no userinfo, no query, no fragment. Fetching keys is
// never driven by token contents.
func fixedJWKSURL(raw string, allowInsecureDev bool) (string, error) {
	if raw == "" {
		return "", errors.New("JWKS URL is required")
	}
	u, err := url.Parse(raw)
	if err != nil {
		return "", fmt.Errorf("JWKS URL is not a URL: %w", err)
	}
	if !schemeAllowed(u.Scheme, allowInsecureDev) || u.Host == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" {
		return "", fmt.Errorf("JWKS URL %q must be a plain https URL%s", raw, insecureHint(allowInsecureDev))
	}
	return u.String(), nil
}

func schemeAllowed(scheme string, allowInsecureDev bool) bool {
	if scheme == "https" {
		return true
	}
	return allowInsecureDev && scheme == "http"
}

func insecureHint(allowInsecureDev bool) string {
	if allowInsecureDev {
		return " (dev-insecure mode)"
	}
	return ""
}

type jwtHeader struct {
	Alg string `json:"alg"`
	Kid string `json:"kid"`
}

type jwtClaims struct {
	Iss           string          `json:"iss"`
	Aud           json.RawMessage `json:"aud"`
	Exp           int64           `json:"exp"`
	Iat           int64           `json:"iat"`
	Nbf           int64           `json:"nbf"`
	Sub           string          `json:"sub"`
	Email         string          `json:"email"`
	EmailVerified *bool           `json:"email_verified"`
	Scope         string          `json:"scope"`
}

// VerifyToken implements the gateway verifier interface. Every failure path
// returns an ErrUnauthorized-wrapped error; reasons are logged, never
// returned to clients, and never contain token material.
func (v *Verifier) VerifyToken(ctx context.Context, token string) (identity.Principal, error) {
	if token == "" || len(token) > v.maxToken {
		return identity.Principal{}, v.reject("empty or oversized token")
	}
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return identity.Principal{}, v.reject("malformed token")
	}
	decode := func(s string, limit int) ([]byte, error) {
		if len(s) > limit {
			return nil, errors.New("segment too large")
		}
		b, err := base64.RawURLEncoding.DecodeString(s)
		if err != nil {
			return nil, fmt.Errorf("bad base64: %w", err)
		}
		return b, nil
	}
	hb, err := decode(parts[0], 1024)
	if err != nil {
		return identity.Principal{}, v.reject("header: %v", err)
	}
	cb, err := decode(parts[1], 8192)
	if err != nil {
		return identity.Principal{}, v.reject("claims: %v", err)
	}
	sig, err := decode(parts[2], 1024)
	if err != nil {
		return identity.Principal{}, v.reject("signature: %v", err)
	}
	var h jwtHeader
	if err := json.Unmarshal(hb, &h); err != nil {
		return identity.Principal{}, v.reject("header: %v", err)
	}
	if h.Alg != "RS256" {
		return identity.Principal{}, v.reject("alg %q not allowed", h.Alg)
	}
	if h.Kid == "" || len(h.Kid) > 128 {
		return identity.Principal{}, v.reject("bad kid")
	}

	// Cheap local claim checks before any key material is touched.
	now := v.clock().Unix()
	leewaySecs := int64(v.leeway / time.Second)
	var c jwtClaims
	if err := json.Unmarshal(cb, &c); err != nil {
		return identity.Principal{}, v.reject("claims: %v", err)
	}
	if c.Iss != v.issuer {
		// In particular, Google tokens (accounts.google.com) and sync
		// sessions can never authenticate for routing.
		return identity.Principal{}, v.reject("issuer %q not allowed", c.Iss)
	}
	if string(c.Aud) != `"`+v.audience+`"` {
		// The broker mints a single string audience; arrays and other
		// values are not the broker contract.
		return identity.Principal{}, v.reject("audience mismatch")
	}
	if c.Exp <= 0 || now >= c.Exp+leewaySecs {
		return identity.Principal{}, v.reject("token expired or missing exp")
	}
	if c.Iat <= 0 || c.Iat > now+leewaySecs {
		return identity.Principal{}, v.reject("iat missing or in the future")
	}
	if c.Nbf <= 0 || c.Nbf > now+leewaySecs {
		return identity.Principal{}, v.reject("nbf missing or in the future")
	}
	if life := c.Exp - c.Iat; life < 0 || life > int64(v.maxLife/time.Second) {
		return identity.Principal{}, v.reject("token lifetime outside the broker bound")
	}
	if len(c.Sub) == 0 || len(c.Sub) > 128 {
		return identity.Principal{}, v.reject("bad sub")
	}
	for i := 0; i < len(c.Sub); i++ {
		if !isSubChar(c.Sub[i]) {
			return identity.Principal{}, v.reject("bad sub")
		}
	}
	if c.Email == "" || len(c.Email) > 254 || !strings.Contains(c.Email, "@") {
		return identity.Principal{}, v.reject("bad email")
	}
	if c.EmailVerified == nil || !*c.EmailVerified {
		return identity.Principal{}, v.reject("email not verified")
	}
	if c.Scope != ScopeGatewayRoute {
		return identity.Principal{}, v.reject("scope %q not allowed", c.Scope)
	}
	email := strings.ToLower(c.Email)
	if len(v.allow) == 0 {
		return identity.Principal{}, v.reject("allowlist empty; denying all")
	}
	allowed := false
	for _, a := range v.allow {
		if subtle.ConstantTimeCompare([]byte(email), []byte(a)) == 1 {
			allowed = true
			break
		}
	}
	if !allowed {
		return identity.Principal{}, v.reject("email not allowlisted")
	}

	key, err := v.signingKey(ctx, h.Kid)
	if err != nil {
		return identity.Principal{}, v.reject("signing key: %v", err)
	}
	digest := sha256.Sum256([]byte(parts[0] + "." + parts[1]))
	if err := rsa.VerifyPKCS1v15(key, crypto.SHA256, digest[:], sig); err != nil {
		return identity.Principal{}, v.reject("signature verify: %v", err)
	}
	// Admission gate, re-run against the CURRENT clock and caller context:
	// a slow JWKS fetch (or a queue behind one) must never admit a token
	// that has expired while verification was in flight, and a caller whose
	// context died while waiting — including on the ready cached-key fast
	// path, which never touches ctx — is not admitted.
	if err := ctx.Err(); err != nil {
		return identity.Principal{}, v.reject("caller context canceled: %v", err)
	}
	if now := v.clock().Unix(); now >= c.Exp+leewaySecs {
		return identity.Principal{}, v.reject("token expired during verification")
	}
	// The stable account identity: issuer+subject, never the mutable email
	// (same "google:<sub>" convention as identity.GoogleAccountID).
	return identity.Principal{
		AccountID: "google:" + c.Sub,
		Email:     email,
		ExpiresAt: time.Unix(c.Exp, 0).UTC(),
	}, nil
}

func (v *Verifier) reject(format string, args ...any) error {
	v.logger("routingauth: token rejected: "+format, args...)
	return fmt.Errorf("%w: %s", ErrUnauthorized, fmt.Sprintf(format, args...))
}

// signingKey returns the cached public key for kid. Refresh policy is fail
// closed (round-two correction, aligned with identity A12):
//
//   - at most one refresh is in flight; waiters block on its completion
//     channel and honor their own context cancellation, so a stalled fetch
//     cannot hold verifications hostage longer than the callers allow;
//   - the fetch runs detached from the initiating request
//     (context.WithoutCancel) with its own timeout, so one canceled request
//     cannot kill a shared refresh;
//   - refresh ATTEMPTS — successful or not, for ANY trigger including a
//     cold cache and an expired cache — are rate-limited by the cooldown,
//     so outage bursts cannot storm the broker;
//   - cached keys are served only within the cache TTL; past it the cache
//     is rejected even when a refresh is still cooling down — broker keys
//     rotate, and a key the JWKS stops publishing must stop verifying HERE
//     within one TTL (the broker's own warm JWKS producers add their own
//     cache window on top; end-to-end revocation is documented in the
//     broker rotation runbook).
func (v *Verifier) signingKey(ctx context.Context, kid string) (*rsa.PublicKey, error) {
	for {
		v.mu.Lock()
		now := v.clock()
		var (
			key   *rsa.PublicKey
			found bool
			age   time.Duration
		)
		if v.keys != nil {
			key, found = v.keys[kid]
			age = now.Sub(v.fetchedAt)
		}
		if found && age <= v.ttl {
			v.mu.Unlock()
			return key, nil
		}
		if v.refreshing != nil {
			done := v.refreshing
			v.mu.Unlock()
			select {
			case <-done:
				continue // re-evaluate against the refreshed cache
			case <-ctx.Done():
				return nil, fmt.Errorf("%w: refresh wait: %v", ErrUnauthorized, ctx.Err())
			}
		}
		if now.Sub(v.lastAttempt) < v.cooldown {
			v.mu.Unlock()
			// No fresh key, refresh not due: fail closed. There is no
			// stale serving past the TTL and no guessable kid.
			return nil, fmt.Errorf("%w: signing keys unavailable (refresh rate-limited or expired)", ErrUnauthorized)
		}
		// Become the refresher. The fetch runs outside the mutex, detached
		// from this request's lifetime; this caller then waits like any
		// other, honoring its own context.
		done := make(chan struct{})
		v.refreshing = done
		v.lastAttempt = now
		v.mu.Unlock()
		go v.runRefresh(ctx, done)
		select {
		case <-done:
			// Loop: serve the fresh key or fail closed; the cooldown
			// governs any further attempt.
		case <-ctx.Done():
			return nil, fmt.Errorf("%w: refresh wait: %v", ErrUnauthorized, ctx.Err())
		}
	}
}

// runRefresh performs one JWKS fetch and publishes the result. It always
// releases waiters, even on panic.
func (v *Verifier) runRefresh(parent context.Context, done chan struct{}) {
	defer func() {
		v.mu.Lock()
		v.refreshing = nil
		v.mu.Unlock()
		close(done)
	}()
	// Detach from the initiating request: waiters must not be abandoned by
	// someone else's cancellation. The fetch keeps its own timeout.
	fetchCtx, cancel := context.WithTimeout(context.WithoutCancel(parent), 10*time.Second)
	defer cancel()
	keys, err := v.fetch(fetchCtx)
	if err != nil {
		v.logger("routingauth: jwks refresh failed: %v", err)
		return
	}
	v.mu.Lock()
	v.keys = keys
	v.fetchedAt = v.clock()
	v.mu.Unlock()
}

func (v *Verifier) fetch(ctx context.Context) (map[string]*rsa.PublicKey, error) {
	cctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(cctx, http.MethodGet, v.jwksURL, nil)
	if err != nil {
		return nil, err
	}
	res, err := v.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("jwks fetch: HTTP %d", res.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(res.Body, int64(v.maxJWKS)+1))
	if err != nil {
		return nil, err
	}
	if len(body) > v.maxJWKS {
		return nil, fmt.Errorf("jwks response exceeds %d bytes", v.maxJWKS)
	}
	var set struct {
		Keys []struct {
			Kty string `json:"kty"`
			Alg string `json:"alg"`
			Use string `json:"use"`
			Kid string `json:"kid"`
			N   string `json:"n"`
			E   string `json:"e"`
		} `json:"keys"`
	}
	if err := json.Unmarshal(body, &set); err != nil {
		return nil, err
	}
	if len(set.Keys) > v.maxKeys {
		return nil, fmt.Errorf("jwks publishes %d keys, over the bound of %d", len(set.Keys), v.maxKeys)
	}
	keys := make(map[string]*rsa.PublicKey, len(set.Keys))
	for _, k := range set.Keys {
		if k.Kid == "" || len(k.Kid) > 128 {
			continue
		}
		// RSA signing keys only; anything else in the set is skipped, and
		// an attacker-supplied key of another type can never sneak in.
		if k.Kty != "RSA" || (k.Alg != "" && k.Alg != "RS256") || (k.Use != "" && k.Use != "sig") {
			continue
		}
		nb, err := base64.RawURLEncoding.DecodeString(k.N)
		if err != nil || len(nb) == 0 || len(nb) > 1024 {
			continue
		}
		eb, err := base64.RawURLEncoding.DecodeString(k.E)
		if err != nil || len(eb) == 0 || len(eb) > 4 {
			continue
		}
		e := uint32(0)
		for _, b := range eb {
			e = e<<8 | uint32(b)
		}
		if e < 3 || e%2 == 0 {
			continue
		}
		n := new(big.Int).SetBytes(nb)
		if n.BitLen() < 2048 || n.BitLen() > 8192 {
			continue
		}
		keys[k.Kid] = &rsa.PublicKey{N: n, E: int(e)}
	}
	if len(keys) == 0 {
		return nil, errors.New("jwks had no usable RSA signing keys")
	}
	return keys, nil
}

func isSubChar(c byte) bool {
	return c >= '0' && c <= '9' || c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c == '-' || c == '_'
}
