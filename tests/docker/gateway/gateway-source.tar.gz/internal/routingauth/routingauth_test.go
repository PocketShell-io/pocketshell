package routingauth

import (
	"context"
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"math/big"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
)

// The gateway's verifier slot takes this method set (identity.TokenVerifier
// shape); the routingauth package itself only needs identity.Principal.
var _ interface {
	VerifyToken(ctx context.Context, token string) (identity.Principal, error)
} = (*Verifier)(nil)

// --- fixtures ---------------------------------------------------------------

// Cross-language RS256 vector: the token and kid below were produced by
// Node's crypto (scripts in sandbox/pocketshell-sync generate the same
// shape in production) over this throwaway RSA-2048 key. Verifying it here
// proves Go accepts a broker token minted by a non-Go implementation,
// including the RFC 7638 kid derivation.
const (
	nodeVectorPrivateKey = `-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC+MAWotB1f6EC1
FpaDTYHMLbJbuk3276/a90Pl3FOKJmg4EENe77u5WQZbl5EQ/R2nrkAkoNsWNsEn
l0otcK8ermBHUbjv6kRjS+wPX1rPAENtLK/2z9SOUi1Qbr+vgzqpK8R1KfIm14iR
QaFtVj+u9u/4X6qoICXWlzHoin2ayCcqxDkEWA7y6uA85ymqnMrm7p94TsMyciNU
9SZeQxyp1Wch3znLfoSkv2qzrtmxUnys7Ihlrjd60qbEJNZd7/dmjidJRINsW+AJ
KPljwxBR0BwwTjH8ilWT8CxI1rt+JF8qTJSW920ufes2NHj+RoFDBxbtMCQoAfB2
yfyrl9dxAgMBAAECggEAEeBRp9nGKQ2bh2noG89dM+PXr+eDDILa9KnpJ+HduE6D
3UEqE/JUosdLYbCNYhtofipSvR6heSUMYrxFrJ+61hdt1UZJK8PJScwJFCjSUEKm
E8zvfTNrtzTiLX07ZzPef6gtfxXCPQRlQcH5el1w/vEW/TGAyOy8ob70YfcidznP
ZxLoZcI4o+Iu3Xyh9nCvV6nog3/BhsD+g88XthnExe7E5j4qnnxyZb3vzyRnlJGt
LrH5iK67vopvCgEtftGB1sJrQC07p2OvzK3S6B6sW8GN2J3ALNlfmwb0E0Ojselk
1U8bVAICS91ODDAVs/ocrlceO4UeTMGnfYJBxfFvAQKBgQDqHMH9E+L74V0QQQIT
r25pHJCktPvrwXRjvV/nqC+FPxWNPD74uc7XjTWyclPmWM9uNS3N4dUWCIFgWJZ+
DxtK9hve/sRyI3TPrfzgPLNbkZr7vH2Jtn5Hsl0KfetoJqC0cXxwiZwJN0OuIimt
3sMst5tR++xAK52QGJ3lekjB5QKBgQDP9/hINn/HrV0obx2g0yzP0qB3Nq26lCDF
YH4ojXQ4V/vo+3ECChQLa/iIgFlXYMV6K/o7Ecz6VCN+wVLaoqduQblYznhC9nph
doiKnAY1+s7+Hjivz/TtyAjc4TTYGSGkIGER+DCSmXz8L2HSRMHOipkgmAZO9mja
wC1zRx5WnQKBgQDGmOyrLrKP78bNoggMAPcNrdC6GFnYzbxZW+2+i7r8Mt6qeCAH
SUBBNKYHodqwfkhA+lXH4DquPTrbK2tGtrP1bD+KdN7a4F8YSkVJR9Ty6drqkCSC
rVAErDcnTlhjetk7GUZyBRpb6wi78Hkg6ObyyTK2YpoweY9pDKjtYUXVTQKBgFtU
rd+gt3sMYoX4Tk2rj9lwyXGxPJhcpwunNaA/htObqBCII/feTzE46Huhyhp6cB8Y
Ixs/1QH2Y2QuKGHF3run92rNubjGn7YfpRUiMgQQskidIw3qyMiH+YRvDpL8bm6y
nY6TrVkkOORTNqVt9qLq8RaETPjuc9vlW9BtYiBtAoGBANWncYvSERc6sFChqQGH
YoP2Jh5LFbfIAujyJ67XC50YJoLH3ObkngmICazC972gddR1Aiqv5Kuha4Ksn2qJ
eQyfTL+lZTSdPyfsW80o3o6WaVo/GRiy4I16SMlO3DKhgvE9A6Yagd6L9YK4qJXk
LPDw1+qKE9oBHdiwPpgo/2lW
-----END PRIVATE KEY-----`
	nodeVectorN    = "vjAFqLQdX-hAtRaWg02BzC2yW7pN9u-v2vdD5dxTiiZoOBBDXu-7uVkGW5eREP0dp65AJKDbFjbBJ5dKLXCvHq5gR1G47-pEY0vsD19azwBDbSyv9s_UjlItUG6_r4M6qSvEdSnyJteIkUGhbVY_rvbv-F-qqCAl1pcx6Ip9msgnKsQ5BFgO8urgPOcpqpzK5u6feE7DMnIjVPUmXkMcqdVnId85y36EpL9qs67ZsVJ8rOyIZa43etKmxCTWXe_3Zo4nSUSDbFvgCSj5Y8MQUdAcME4x_IpVk_AsSNa7fiRfKkyUlvdtLn3rNjR4_kaBQwcW7TAkKAHwdsn8q5fXcQ"
	nodeVectorE    = "AQAB"
	nodeVectorKid  = "qZ6RbmoC-yOlWbgIshw5Jb5ikjSDuFUztgrLcfMhufo"
	nodeVectorTkn  = "eyJhbGciOiJSUzI1NiIsImtpZCI6InFaNlJibW9DLXlPbFdiZ0lzaHc1SmI1aWtqU0R1RlV6dGdyTGNmTWh1Zm8iLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2E3c290YTJxaWMuZXhlY3V0ZS1hcGkuZXUtd2VzdC0xLmFtYXpvbmF3cy5jb20iLCJhdWQiOiJwb2NrZXRzaGVsbC1nYXRld2F5Iiwic3ViIjoiMTEzOTU4NDMwODU4MzU0NTI5MDcyIiwiZW1haWwiOiJhbGV4ZXkucy5ncmlnb3JpZXZAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsInNjb3BlIjoicG9ja2V0c2hlbGwuZ2F0ZXdheSIsImlhdCI6MTc2NzIyNTYwMCwibmJmIjoxNzY3MjI1NjAwLCJleHAiOjE3NjcyMjU5MDB9.Ju04kjqQgdywghG8n2aqbiwpL-SJqBxJ0bcSEp89wm4yaSVqKSsOkEHkEL1ZJp_hsPk9fnLeTpQ2uf2bXKjALvmv4I2IwIJaG2-4i50t7W8CS5oWsUBheHHQ8JRqBCxpiUSSAdijllr5JlwYlfmLz8OeIsKaHH3gzyFNdpkGtiTKqz01ifv3OJ0tmYB1sB_8Vw-qdzGrNc55O5u3xGPUX-6owf54RBoPPtd56FDawGq3rPkY4MYGyvNz1DtyLyZ9rD8vchfYwaNYEi80D3yYU64dTjoZJfUVQ5ptIq9u4Vz-PfdbMQxFHq291g-Mrsxh6HVbaBHeKF0XOtNR2aElWg"
	nodeVectorNow  = 1767225700
	nodeVectorIss  = "https://a7sota2qic.execute-api.eu-west-1.amazonaws.com"
	nodeVectorMail = "alexey.s.grigoriev@gmail.com"
)

const testIssuer = "https://broker.example"

type fakeClock struct {
	mu  sync.Mutex
	sec int64
}

func newFakeClock(at int64) *fakeClock { return &fakeClock{sec: at} }

func (c *fakeClock) Now() time.Time {
	c.mu.Lock()
	defer c.mu.Unlock()
	return time.Unix(c.sec, 0)
}

func (c *fakeClock) Advance(d time.Duration) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.sec += int64(d / time.Second)
}

// jwksHarness runs a local TLS JWKS server (real https; no external
// network) whose body can be swapped at any time, counting fetches.
type jwksHarness struct {
	server  *httptest.Server
	client  *http.Client
	fetches atomic.Int64
	mu      sync.Mutex
	status  int
	body    string
}

func newJWKSHarness(t *testing.T, body string) *jwksHarness {
	t.Helper()
	h := &jwksHarness{status: http.StatusOK, body: body}
	h.server = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h.fetches.Add(1)
		h.mu.Lock()
		status, body := h.status, h.body
		h.mu.Unlock()
		w.Header().Set("content-type", "application/json")
		w.WriteHeader(status)
		_, _ = w.Write([]byte(body))
	}))
	t.Cleanup(h.server.Close)
	h.client = h.server.Client()
	return h
}

func (h *jwksHarness) set(status int, body string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.status, h.body = status, body
}

var (
	testKeyOnce sync.Once
	testKey     *rsa.PrivateKey
)

func brokerKey(t *testing.T) *rsa.PrivateKey {
	t.Helper()
	testKeyOnce.Do(func() {
		k, err := rsa.GenerateKey(rand.Reader, 2048)
		if err != nil {
			panic(err)
		}
		testKey = k
	})
	return testKey
}

// jwkThumbprint mirrors RFC 7638 exactly as the broker computes it.
func jwkThumbprint(t *testing.T, key *rsa.PublicKey) string {
	t.Helper()
	b64 := func(b []byte) string { return base64.RawURLEncoding.EncodeToString(b) }
	jwk := struct {
		E   string `json:"e"`
		Kty string `json:"kty"`
		N   string `json:"n"`
	}{E: b64(bigEndian(key.E)), Kty: "RSA", N: b64(key.N.Bytes())}
	raw, err := json.Marshal(jwk)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(raw)
	return base64.RawURLEncoding.EncodeToString(sum[:])
}

func bigEndian(e int) []byte {
	out := []byte{}
	for e > 0 {
		out = append([]byte{byte(e)}, out...)
		e >>= 8
	}
	return out
}

func jwksFor(t *testing.T, keys ...*rsa.PublicKey) string {
	t.Helper()
	type k struct {
		Kty string `json:"kty"`
		Alg string `json:"alg"`
		Use string `json:"use"`
		Kid string `json:"kid"`
		N   string `json:"n"`
		E   string `json:"e"`
	}
	set := struct {
		Keys []k `json:"keys"`
	}{}
	for _, key := range keys {
		set.Keys = append(set.Keys, k{
			Kty: "RSA", Alg: "RS256", Use: "sig",
			Kid: jwkThumbprint(t, key),
			N:   base64.RawURLEncoding.EncodeToString(key.N.Bytes()),
			E:   base64.RawURLEncoding.EncodeToString(bigEndian(key.E)),
		})
	}
	b, err := json.Marshal(set)
	if err != nil {
		t.Fatal(err)
	}
	return string(b)
}

func signToken(t *testing.T, key *rsa.PrivateKey, header, payload map[string]any) string {
	t.Helper()
	b64 := func(v any) string {
		b, err := json.Marshal(v)
		if err != nil {
			t.Fatal(err)
		}
		return base64.RawURLEncoding.EncodeToString(b)
	}
	si := b64(header) + "." + b64(payload)
	digest := sha256.Sum256([]byte(si))
	sig, err := rsa.SignPKCS1v15(rand.Reader, key, crypto.SHA256, digest[:])
	if err != nil {
		t.Fatal(err)
	}
	return si + "." + base64.RawURLEncoding.EncodeToString(sig)
}

func brokerClaims(now int64) map[string]any {
	return map[string]any{
		"iss":            testIssuer,
		"aud":            Audience,
		"sub":            "113958430858354529072",
		"email":          "user@example.com",
		"email_verified": true,
		"scope":          ScopeGatewayRoute,
		"iat":            now,
		"nbf":            now,
		"exp":            now + 300,
	}
}

func rs256Header(kid string) map[string]any {
	return map[string]any{"alg": "RS256", "kid": kid, "typ": "JWT"}
}

// newTestVerifier wires a verifier against the harness with a mutable clock.
func newTestVerifier(t *testing.T, h *jwksHarness, clock *fakeClock, mutate func(*Config)) *Verifier {
	t.Helper()
	cfg := Config{
		Issuer:     testIssuer,
		JWKSURL:    h.server.URL,
		Allowlist:  []string{"user@example.com"},
		HTTPClient: h.client,
		Clock:      clock.Now,
	}
	if mutate != nil {
		mutate(&cfg)
	}
	v, err := NewVerifier(cfg)
	if err != nil {
		t.Fatal(err)
	}
	return v
}

// --- cross-language vector ---------------------------------------------------

func TestNodeMintedVectorVerifies(t *testing.T) {
	h := newJWKSHarness(t, fmt.Sprintf(`{"keys":[{"kty":"RSA","alg":"RS256","use":"sig","kid":%q,"n":%q,"e":%q}]}`,
		nodeVectorKid, nodeVectorN, nodeVectorE))
	clock := newFakeClock(nodeVectorNow)
	v := newTestVerifier(t, h, clock, func(c *Config) {
		c.Issuer = nodeVectorIss
		c.Allowlist = []string{nodeVectorMail}
	})

	// The kid Node derived is exactly the RFC 7638 thumbprint Go computes.
	var n big.Int
	nBytes, err := base64.RawURLEncoding.DecodeString(nodeVectorN)
	if err != nil {
		t.Fatal(err)
	}
	n.SetBytes(nBytes)
	eBytes, _ := base64.RawURLEncoding.DecodeString(nodeVectorE)
	e := 0
	for _, b := range eBytes {
		e = e<<8 | int(b)
	}
	if got := jwkThumbprint(t, &rsa.PublicKey{N: &n, E: e}); got != nodeVectorKid {
		t.Fatalf("kid mismatch: Go %q vs Node %q", got, nodeVectorKid)
	}

	got, err := v.VerifyToken(context.Background(), nodeVectorTkn)
	if err != nil {
		t.Fatalf("Node-signed broker token must verify in Go: %v", err)
	}
	if got.AccountID != "google:113958430858354529072" {
		t.Fatalf("AccountID = %q, want google:<sub>", got.AccountID)
	}
	if got.Email != nodeVectorMail {
		t.Fatalf("Email = %q", got.Email)
	}
	if want := time.Unix(1767225900, 0).UTC(); !got.ExpiresAt.Equal(want) {
		t.Fatalf("ExpiresAt = %v, want %v", got.ExpiresAt, want)
	}
}

// --- claims matrix -----------------------------------------------------------

func TestClaimsMatrix(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey))
	clock := newFakeClock(1767225700)

	mutate := func(f func(map[string]any)) map[string]any {
		c := brokerClaims(clock.Now().Unix())
		f(c)
		return c
	}
	cases := map[string]map[string]any{
		"wrong issuer":           mutate(func(c map[string]any) { c["iss"] = "https://evil.example" }),
		"google issuer":          mutate(func(c map[string]any) { c["iss"] = "https://accounts.google.com" }),
		"issuer with slash":      mutate(func(c map[string]any) { c["iss"] = testIssuer + "/" }),
		"wrong audience":         mutate(func(c map[string]any) { c["aud"] = "some-other-service" }),
		"audience array":         mutate(func(c map[string]any) { c["aud"] = []string{Audience} }),
		"expired":                mutate(func(c map[string]any) { c["exp"] = clock.Now().Unix() - 1 }),
		"exp missing":            mutate(func(c map[string]any) { delete(c, "exp") }),
		"nbf future":             mutate(func(c map[string]any) { c["nbf"] = clock.Now().Unix() + 120 }),
		"nbf missing":            mutate(func(c map[string]any) { delete(c, "nbf") }),
		"iat future":             mutate(func(c map[string]any) { c["iat"] = clock.Now().Unix() + 120 }),
		"iat missing":            mutate(func(c map[string]any) { delete(c, "iat") }),
		"lifetime over bound":    mutate(func(c map[string]any) { c["exp"] = c["iat"].(int64) + 3600 }),
		"lifetime one over cap":  mutate(func(c map[string]any) { c["exp"] = c["iat"].(int64) + 301 }),
		"email not verified":     mutate(func(c map[string]any) { c["email_verified"] = false }),
		"email_verified missing": mutate(func(c map[string]any) { delete(c, "email_verified") }),
		"email missing":          mutate(func(c map[string]any) { delete(c, "email") }),
		"email malformed":        mutate(func(c map[string]any) { c["email"] = "not-an-email" }),
		"email unlisted":         mutate(func(c map[string]any) { c["email"] = "stranger@example.com" }),
		"scope missing":          mutate(func(c map[string]any) { delete(c, "scope") }),
		"scope escalated":        mutate(func(c map[string]any) { c["scope"] = "pocketshell.gateway sync:admin" }),
		"scope other protocol":   mutate(func(c map[string]any) { c["scope"] = "pocketshell.sync" }),
		"sub missing":            mutate(func(c map[string]any) { delete(c, "sub") }),
		"sub with separator":     mutate(func(c map[string]any) { c["sub"] = "abc.def" }),
		"sub overlong":           mutate(func(c map[string]any) { c["sub"] = strings.Repeat("a", 129) }),
	}
	for name, claims := range cases {
		t.Run(name, func(t *testing.T) {
			v := newTestVerifier(t, h, clock, nil)
			tok := signToken(t, key, rs256Header(kid), claims)
			if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
				t.Fatalf("must reject %q, got %v", name, err)
			}
		})
	}

	// Header-level rejections.
	v := newTestVerifier(t, h, clock, nil)
	for name, tok := range map[string]string{
		"empty token":      "",
		"not a jwt":        "garbage",
		"two segments":     "a.b",
		"alg none":         signToken(t, key, map[string]any{"alg": "none", "kid": kid}, brokerClaims(clock.Now().Unix())),
		"alg swapped":      signToken(t, key, map[string]any{"alg": "RS256 ", "kid": kid}, brokerClaims(clock.Now().Unix())),
		"kid empty":        signToken(t, key, map[string]any{"alg": "RS256"}, brokerClaims(clock.Now().Unix())),
		"kid unknown":      signToken(t, key, rs256Header("no-such-kid"), brokerClaims(clock.Now().Unix())),
		"oversized token":  "x." + strings.Repeat("y", 9000) + ".z",
		"tampered payload": tamperPayload(t, signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))),
	} {
		t.Run(name, func(t *testing.T) {
			if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
				t.Fatalf("must reject %q, got %v", name, err)
			}
		})
	}
}

func tamperPayload(t *testing.T, token string) string {
	t.Helper()
	parts := strings.Split(token, ".")
	raw, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		t.Fatal(err)
	}
	raw[len(raw)-1] ^= 0x01 // flip one bit in a signed claim
	parts[1] = base64.RawURLEncoding.EncodeToString(raw)
	return strings.Join(parts, ".")
}

func TestAllowlistAndPrincipal(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey))
	clock := newFakeClock(1767225700)
	now := clock.Now().Unix()

	// Empty allowlist denies everyone (rollout semantics).
	v := newTestVerifier(t, h, clock, func(c *Config) { c.Allowlist = nil })
	tok := signToken(t, key, rs256Header(kid), brokerClaims(now))
	if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("empty allowlist must deny")
	}

	// Case-insensitive allowlist match, exact principal mapping.
	v = newTestVerifier(t, h, clock, func(c *Config) { c.Allowlist = []string{"  USER@Example.com "} })
	got, err := v.VerifyToken(context.Background(), tok)
	if err != nil {
		t.Fatal(err)
	}
	if got.AccountID != "google:113958430858354529072" || got.Email != "user@example.com" {
		t.Fatalf("principal = %+v", got)
	}
	if want := time.Unix(now+300, 0).UTC(); !got.ExpiresAt.Equal(want) {
		t.Fatalf("ExpiresAt = %v, want %v", got.ExpiresAt, want)
	}
}

// The broker mints CLI-session tokens that carry extra claims the gateway
// does not consume ("amr":["cli_device"], "sid":<session id>). They must be
// accepted and yield exactly the same Principal as the plain token: if claim
// decoding ever turns strict (DisallowUnknownFields or similar), every
// CLI-issued token would silently stop authenticating, and this test fails.
func TestCLISessionExtraClaimsAccepted(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey))
	clock := newFakeClock(1767225700)
	now := clock.Now().Unix()
	v := newTestVerifier(t, h, clock, nil)

	plain := signToken(t, key, rs256Header(kid), brokerClaims(now))
	cliClaims := brokerClaims(now)
	cliClaims["amr"] = []string{"cli_device"}
	cliClaims["sid"] = "0123456789ab"
	cli := signToken(t, key, rs256Header(kid), cliClaims)

	want, err := v.VerifyToken(context.Background(), plain)
	if err != nil {
		t.Fatalf("plain broker token must verify: %v", err)
	}
	got, err := v.VerifyToken(context.Background(), cli)
	if err != nil {
		t.Fatalf("CLI-session token with amr/sid claims must verify: %v", err)
	}
	if got.AccountID != want.AccountID || got.Email != want.Email || !got.ExpiresAt.Equal(want.ExpiresAt) {
		t.Fatalf("CLI-session principal = %+v, want %+v", got, want)
	}
	if got.AccountID != "google:113958430858354529072" || got.Email != "user@example.com" {
		t.Fatalf("principal = %+v", got)
	}
}

// --- JWKS key policy ----------------------------------------------------------

func TestJWKSPolicies(t *testing.T) {
	clock := newFakeClock(1767225700)
	claims := brokerClaims(clock.Now().Unix())

	t.Run("weak and foreign keys are skipped", func(t *testing.T) {
		weak, err := rsa.GenerateKey(rand.Reader, 1024)
		if err != nil {
			t.Fatal(err)
		}
		h := newJWKSHarness(t, jwksFor(t, &weak.PublicKey))
		v := newTestVerifier(t, h, clock, nil)
		tok := signToken(t, weak, rs256Header(jwkThumbprint(t, &weak.PublicKey)), claims)
		if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
			t.Fatal("a 1024-bit JWKS key must never verify")
		}
	})

	t.Run("non-RSA and wrong-purpose key entries are skipped", func(t *testing.T) {
		key := brokerKey(t)
		kid := jwkThumbprint(t, &key.PublicKey)
		body := fmt.Sprintf(`{"keys":[{"kty":"EC","crv":"P-256","kid":%q,"x":"a","y":"b"},{"kty":"RSA","alg":"RS512","kid":%q,"n":%q,"e":"AQAB"},{"kty":"RSA","use":"enc","kid":%q,"n":%q,"e":"AQAB"}]}`,
			kid, kid, base64.RawURLEncoding.EncodeToString(key.N.Bytes()), kid, base64.RawURLEncoding.EncodeToString(key.N.Bytes()))
		h := newJWKSHarness(t, body)
		v := newTestVerifier(t, h, clock, nil)
		tok := signToken(t, key, rs256Header(kid), claims)
		if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
			t.Fatal("only RSA/RS256/sig keys may verify")
		}
	})

	t.Run("broken responses fail closed", func(t *testing.T) {
		key := brokerKey(t)
		kid := jwkThumbprint(t, &key.PublicKey)
		tok := signToken(t, key, rs256Header(kid), claims)
		for name, setup := range map[string]func(h *jwksHarness){
			"http 500":        func(h *jwksHarness) { h.set(500, "{}") },
			"not json":        func(h *jwksHarness) { h.set(200, "<html>") },
			"no keys":         func(h *jwksHarness) { h.set(200, `{"keys":[]}`) },
			"key count bound": func(h *jwksHarness) { h.set(200, oversizedKeySet(t, 17)) },
			"oversized body":  func(h *jwksHarness) { h.set(200, `{"keys":[],"pad":"`+strings.Repeat("a", 1<<20)+`"}`) },
		} {
			t.Run(name, func(t *testing.T) {
				h := newJWKSHarness(t, "{}")
				setup(h)
				v := newTestVerifier(t, h, clock, nil)
				if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
					t.Fatalf("%s must fail closed", name)
				}
			})
		}
	})
}

func oversizedKeySet(t *testing.T, n int) string {
	t.Helper()
	var sb strings.Builder
	sb.WriteString(`{"keys":[`)
	for i := 0; i < n; i++ {
		fmt.Fprintf(&sb, `{"kty":"RSA","kid":"k%d","n":"AQAB","e":"AQAB"},`, i)
	}
	sb.WriteString(`]}`)
	return sb.String()
}

// --- refresh, staleness and rotation -----------------------------------------

func TestUnknownKidRefreshCooldown(t *testing.T) {
	key := brokerKey(t)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey)) // publishes a kid the token won't use
	clock := newFakeClock(1767225700)
	v := newTestVerifier(t, h, clock, nil)

	other, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	tok := signToken(t, other, rs256Header(jwkThumbprint(t, &other.PublicKey)), brokerClaims(clock.Now().Unix()))

	for i := 0; i < 3; i++ {
		if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
			t.Fatal("unknown kid must reject")
		}
	}
	if n := h.fetches.Load(); n != 1 {
		t.Fatalf("cooldown must bound refreshes to 1, got %d", n)
	}
	clock.Advance(31 * time.Second)
	if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("still unknown kid")
	}
	if n := h.fetches.Load(); n != 2 {
		t.Fatalf("after the cooldown exactly one more refresh, got %d", n)
	}
}

func TestStaleCacheFailsClosedPastTTL(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey))
	clock := newFakeClock(1767225700)
	v := newTestVerifier(t, h, clock, func(c *Config) { c.CacheTTL = time.Minute })

	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))
	if _, err := v.VerifyToken(context.Background(), tok); err != nil {
		t.Fatal(err)
	}
	before := h.fetches.Load()

	// Past the TTL the cache may not silently serve: a failed refresh must
	// reject the token even though the cached key would verify it, and the
	// cooldown bounds how often the failing refresh is attempted.
	h.set(500, "down")
	clock.Advance(2 * time.Minute)
	for i := 0; i < 3; i++ {
		if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
			t.Fatal("stale cache must not serve past TTL when refresh fails")
		}
	}
	if n := h.fetches.Load() - before; n != 1 {
		t.Fatalf("outage burst past TTL must attempt exactly one refresh, got %d", n)
	}

	// A working refresh recovers after the cooldown, and rotation drops the
	// old kid.
	fresh, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	h.set(200, jwksFor(t, &fresh.PublicKey))
	clock.Advance(31 * time.Second)
	if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("rotated-out kid must reject after refresh")
	}
	newTok := signToken(t, fresh, rs256Header(jwkThumbprint(t, &fresh.PublicKey)), brokerClaims(clock.Now().Unix()))
	if _, err := v.VerifyToken(context.Background(), newTok); err != nil {
		t.Fatalf("new kid after rotation must verify: %v", err)
	}
}

// Round-two correction: an outage past the cache TTL must not turn every
// verification into a network call — the cooldown governs expired-cache
// refreshes exactly like unknown-kid refreshes.
func TestExpiredCacheOutageBurstsAreRateLimited(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey))
	clock := newFakeClock(1767225700)
	v := newTestVerifier(t, h, clock, nil)

	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))
	if _, err := v.VerifyToken(context.Background(), tok); err != nil {
		t.Fatal(err)
	}
	before := h.fetches.Load()

	h.set(500, "down")
	clock.Advance(10 * time.Minute) // cache well past TTL, cooldown long passed
	// The original token has expired under the advanced clock; sign a fresh
	// one so rejection isolates the key-fetch path, not the exp check.
	tok = signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))
	for i := 0; i < 5; i++ {
		if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
			t.Fatal("expired cache with failing refresh must reject")
		}
	}
	if n := h.fetches.Load() - before; n != 1 {
		t.Fatalf("expired-cache outage burst must fetch once, got %d fetches", n)
	}

	clock.Advance(31 * time.Second) // cooldown elapsed: exactly one more attempt
	if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("still failing, must reject")
	}
	if n := h.fetches.Load() - before; n != 2 {
		t.Fatalf("after the cooldown exactly one more refresh, got %d", n)
	}
}

// Round-two correction (identity A12 alignment): refreshes are single-flight,
// no network I/O under the mutex, detached from the initiating request, and
// waiters honor their own context cancellation.
func TestRefreshSingleflightDetachedAndContextAware(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	clock := newFakeClock(1767225700)
	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))

	var fetches atomic.Int64
	entered := make(chan struct{})
	release := make(chan struct{})
	freeRelease := sync.OnceFunc(func() { close(release) })
	t.Cleanup(freeRelease) // never leave the handler blocked across FailNow
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fetches.Add(1)
		close(entered) // exactly one request reaches this handler in this test
		<-release
		w.Header().Set("content-type", "application/json")
		_, _ = w.Write([]byte(jwksFor(t, &key.PublicKey)))
	}))
	defer srv.Close()

	v, err := NewVerifier(Config{
		Issuer:     testIssuer,
		JWKSURL:    srv.URL,
		Allowlist:  []string{"user@example.com"},
		HTTPClient: srv.Client(),
		Clock:      clock.Now,
	})
	if err != nil {
		t.Fatal(err)
	}

	const n = 8
	errs := make([]error, n)
	var wg sync.WaitGroup
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			_, errs[i] = v.VerifyToken(context.Background(), tok)
		}(i)
	}
	<-entered // the single-flight fetch is now in flight

	// A waiter whose context is canceled must return promptly with its own
	// cancellation instead of blocking behind the network call. The
	// package's caller-facing errors are ErrUnauthorized with a reason
	// string (never raw wrapped causes), so the cancellation is asserted by
	// name in the message.
	waiterCtx, cancelWaiter := context.WithCancel(context.Background())
	cancelWaiter()
	waiterErr := make(chan error, 1)
	go func() {
		_, err := v.VerifyToken(waiterCtx, tok)
		waiterErr <- err
	}()
	select {
	case err := <-waiterErr:
		if !errors.Is(err, ErrUnauthorized) || !strings.Contains(err.Error(), "context canceled") {
			t.Fatalf("canceled waiter must fail with its own cancellation, got %v", err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("canceled waiter blocked behind the in-flight refresh")
	}

	freeRelease()
	wg.Wait()
	for i, err := range errs {
		if err != nil {
			t.Fatalf("verifier %d: %v", i, err)
		}
	}
	if got := fetches.Load(); got != 1 {
		t.Fatalf("cold stampede must fetch once, got %d", got)
	}
}

// Detached refresh: canceling the initiator while the fetch is in flight
// must not kill the shared refresh — the cache still gets populated and no
// second fetch is needed.
func TestRefreshDetachedFromInitiatorCancellation(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	clock := newFakeClock(1767225700)
	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))

	var fetches atomic.Int64
	entered := make(chan struct{})
	release := make(chan struct{})
	freeRelease := sync.OnceFunc(func() { close(release) })
	t.Cleanup(freeRelease)
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		fetches.Add(1)
		close(entered)
		<-release
		w.Header().Set("content-type", "application/json")
		_, _ = w.Write([]byte(jwksFor(t, &key.PublicKey)))
	}))
	defer srv.Close()

	v, err := NewVerifier(Config{
		Issuer:     testIssuer,
		JWKSURL:    srv.URL,
		Allowlist:  []string{"user@example.com"},
		HTTPClient: srv.Client(),
		Clock:      clock.Now,
	})
	if err != nil {
		t.Fatal(err)
	}

	ctxA, cancelA := context.WithCancel(context.Background())
	leaderErr := make(chan error, 1)
	go func() {
		_, err := v.VerifyToken(ctxA, tok)
		leaderErr <- err
	}()
	<-entered
	cancelA()
	if err := <-leaderErr; !errors.Is(err, ErrUnauthorized) || !strings.Contains(err.Error(), "context canceled") {
		t.Fatalf("canceled initiator must return its own cancellation, got %v", err)
	}

	// The fetch itself was detached from ctxA and still completes.
	freeRelease()
	deadline := time.Now().Add(2 * time.Second)
	for {
		if _, err := v.VerifyToken(context.Background(), tok); err == nil {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("detached refresh did not populate the cache")
		}
		time.Sleep(5 * time.Millisecond)
	}
	if got := fetches.Load(); got != 1 {
		t.Fatalf("cache must come from the detached fetch alone, got %d fetches", got)
	}
}

// Round-two correction: five minutes is both the default and the maximum
// token lifetime this verifier accepts.
func TestMaxLifetimeDefaultAndCapFiveMinutes(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey))
	clock := newFakeClock(1767225700)
	now := clock.Now().Unix()

	if _, err := NewVerifier(Config{
		Issuer:      testIssuer,
		JWKSURL:     h.server.URL,
		MaxLifetime: 10 * time.Minute,
	}); err == nil {
		t.Fatal("MaxLifetime beyond the 5-minute broker bound must not build")
	}

	v := newTestVerifier(t, h, clock, nil)
	if _, err := v.VerifyToken(context.Background(), signToken(t, key, rs256Header(kid), brokerClaims(now))); err != nil {
		t.Fatal(err)
	}
	over := brokerClaims(now)
	over["exp"] = now + 301
	if _, err := v.VerifyToken(context.Background(), signToken(t, key, rs256Header(kid), over)); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("a 301-second token exceeds the broker lifetime bound")
	}
}

// The trusted JWKS URL must not silently hop hosts via redirects.
func TestJWKSRedirectsRejected(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	clock := newFakeClock(1767225700)
	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))

	redirecting := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/elsewhere", http.StatusFound)
	}))
	defer redirecting.Close()
	client := redirecting.Client()
	client.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	v, err := NewVerifier(Config{
		Issuer:     testIssuer,
		JWKSURL:    redirecting.URL,
		Allowlist:  []string{"user@example.com"},
		HTTPClient: client,
		Clock:      clock.Now,
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
		t.Fatalf("redirecting JWKS endpoint must fail closed, got %v", err)
	}

	// The default client carries the same policy.
	dv, err := NewVerifier(Config{Issuer: testIssuer, JWKSURL: "https://broker.example/gateway/jwks"})
	if err != nil {
		t.Fatal(err)
	}
	if dv.client.CheckRedirect == nil {
		t.Fatal("default client must refuse redirects")
	}
}

// Astra P1 regression: a slow JWKS fetch must never admit a token that
// expired while verification was in flight. Deterministic barrier — the
// fake clock crosses exp while the transport is parked, then the fetch is
// released; no sleeps.
func TestExpiredDuringSlowFetchRejected(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	clock := newFakeClock(1767225700)
	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix())) // exp = T0+300

	entered := make(chan struct{})
	release := make(chan struct{})
	freeRelease := sync.OnceFunc(func() { close(release) })
	t.Cleanup(freeRelease)
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		close(entered)
		<-release
		w.Header().Set("content-type", "application/json")
		_, _ = w.Write([]byte(jwksFor(t, &key.PublicKey)))
	}))
	defer srv.Close()

	v, err := NewVerifier(Config{
		Issuer:     testIssuer,
		JWKSURL:    srv.URL,
		Allowlist:  []string{"user@example.com"},
		HTTPClient: srv.Client(),
		Clock:      clock.Now,
	})
	if err != nil {
		t.Fatal(err)
	}

	resCh := make(chan error, 1)
	go func() {
		_, err := v.VerifyToken(context.Background(), tok)
		resCh <- err
	}()
	<-entered
	clock.Advance((301 + 30 + 1) * time.Second) // exp (300) plus full leeway (30) elapses in flight
	freeRelease()
	if err := <-resCh; !errors.Is(err, ErrUnauthorized) || !strings.Contains(err.Error(), "expired during verification") {
		t.Fatalf("token expiring during the fetch must be rejected, got %v", err)
	}
}

// Astra P1 regression: callers whose context died are rejected both while
// waiting on a fetch and on the ready cached-key fast path — which never
// touches ctx inside signingKey — via the admission gate.
func TestCanceledCallersRejectedAfterFetchAndOnCachedPath(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	clock := newFakeClock(1767225700)
	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))

	entered := make(chan struct{})
	release := make(chan struct{})
	freeRelease := sync.OnceFunc(func() { close(release) })
	t.Cleanup(freeRelease)
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		close(entered)
		<-release
		w.Header().Set("content-type", "application/json")
		_, _ = w.Write([]byte(jwksFor(t, &key.PublicKey)))
	}))
	defer srv.Close()

	v, err := NewVerifier(Config{
		Issuer:     testIssuer,
		JWKSURL:    srv.URL,
		Allowlist:  []string{"user@example.com"},
		HTTPClient: srv.Client(),
		Clock:      clock.Now,
	})
	if err != nil {
		t.Fatal(err)
	}

	// Phase 1: cancel the initiator while its fetch is in flight, then
	// release the transport — the caller must come back unauthorized.
	ctxA, cancelA := context.WithCancel(context.Background())
	leaderErr := make(chan error, 1)
	go func() {
		_, err := v.VerifyToken(ctxA, tok)
		leaderErr <- err
	}()
	<-entered
	cancelA()
	freeRelease()
	if err := <-leaderErr; !errors.Is(err, ErrUnauthorized) || !strings.Contains(err.Error(), "context canceled") {
		t.Fatalf("canceled initiator must be rejected, got %v", err)
	}

	// Wait for the detached fetch to publish the cache (background caller
	// succeeds), so phase 2 deterministically takes the ready cached-key
	// fast path instead of racing the refresh cleanup.
	deadline := time.Now().Add(2 * time.Second)
	for {
		if _, err := v.VerifyToken(context.Background(), tok); err == nil {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("detached refresh did not populate the cache")
		}
		time.Sleep(5 * time.Millisecond)
	}

	// Phase 2: a canceled caller on the ready cached-key path is rejected
	// by the admission gate (signingKey itself never sees the context here).
	ctxB, cancelB := context.WithCancel(context.Background())
	cancelB()
	if _, err := v.VerifyToken(ctxB, tok); !errors.Is(err, ErrUnauthorized) || !strings.Contains(err.Error(), "caller context canceled") {
		t.Fatalf("canceled caller must be rejected on the cached-key path, got %v", err)
	}

	// The cache itself is intact: an uncanceled caller still verifies.
	if _, err := v.VerifyToken(context.Background(), tok); err != nil {
		t.Fatal(err)
	}
}

// A cold-cache outage must stay bounded under concurrency: one single-flight
// fetch per cooldown window, every caller rejected, no per-caller requests.
func TestConcurrentColdFailureBoundedToOneFetch(t *testing.T) {
	h := newJWKSHarness(t, "{}")
	h.set(500, "down")
	clock := newFakeClock(1767225700)
	v := newTestVerifier(t, h, clock, nil)

	key := brokerKey(t)
	tok := signToken(t, key, rs256Header(jwkThumbprint(t, &key.PublicKey)), brokerClaims(clock.Now().Unix()))
	const n = 16
	var wg sync.WaitGroup
	errs := make([]error, n)
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			_, errs[i] = v.VerifyToken(context.Background(), tok)
		}(i)
	}
	wg.Wait()
	for i, err := range errs {
		if !errors.Is(err, ErrUnauthorized) {
			t.Fatalf("goroutine %d: %v", i, err)
		}
	}
	if got := h.fetches.Load(); got != 1 {
		t.Fatalf("cold failed refresh under concurrency must fetch once, got %d", got)
	}
}

// AllowInsecureDev is an explicit dev-only escape hatch: without it plain
// HTTP is rejected (see TestConfigFailsClosed); with it an http broker
// works end-to-end for local Docker fixtures — while HTTPS verification is
// never disabled, so an untrusted TLS endpoint still fails.
func TestAllowInsecureDevHTTPAllowedAndTLSStillVerified(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	clock := newFakeClock(1767225700)

	// Plain-HTTP dev fixture: construct and verify end to end.
	plain := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("content-type", "application/json")
		_, _ = w.Write([]byte(jwksFor(t, &key.PublicKey)))
	}))
	defer plain.Close()
	dv, err := NewVerifier(Config{
		Issuer:           plain.URL,
		JWKSURL:          plain.URL + "/gateway/jwks",
		Allowlist:        []string{"user@example.com"},
		Clock:            clock.Now,
		AllowInsecureDev: true,
	})
	if err != nil {
		t.Fatalf("explicit dev-HTTP configuration must construct: %v", err)
	}
	tok := signToken(t, key, rs256Header(kid), map[string]any{
		"iss": plain.URL, "aud": Audience, "sub": "113958430858354529072",
		"email": "user@example.com", "email_verified": true,
		"scope": ScopeGatewayRoute, "iat": clock.Now().Unix(), "nbf": clock.Now().Unix(),
		"exp": clock.Now().Unix() + 300,
	})
	if _, err := dv.VerifyToken(context.Background(), tok); err != nil {
		t.Fatalf("dev-HTTP verify must succeed: %v", err)
	}

	// Without the flag the same configuration is rejected.
	if _, err := NewVerifier(Config{Issuer: plain.URL, JWKSURL: plain.URL + "/gateway/jwks"}); err == nil {
		t.Fatal("plain-HTTP configuration must be rejected without AllowInsecureDev")
	}

	// The flag never weakens TLS: with the DEFAULT client (no test-cert
	// trust) the self-signed https endpoint still fails verification.
	tlsSrv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(jwksFor(t, &key.PublicKey)))
	}))
	defer tlsSrv.Close()
	tv, err := NewVerifier(Config{
		Issuer:           testIssuer,
		JWKSURL:          tlsSrv.URL,
		Allowlist:        []string{"user@example.com"},
		Clock:            clock.Now,
		AllowInsecureDev: true,
	})
	if err != nil {
		t.Fatal(err)
	}
	httpsTok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))
	if _, err := tv.VerifyToken(context.Background(), httpsTok); !errors.Is(err, ErrUnauthorized) {
		t.Fatalf("untrusted TLS must fail even in dev-insecure mode, got %v", err)
	}
}

func TestRotationOverlapWindow(t *testing.T) {
	oldKey, newKey := brokerKey(t), func() *rsa.PrivateKey {
		k, err := rsa.GenerateKey(rand.Reader, 2048)
		if err != nil {
			t.Fatal(err)
		}
		return k
	}()
	clock := newFakeClock(1767225700)
	h := newJWKSHarness(t, jwksFor(t, &oldKey.PublicKey, &newKey.PublicKey))
	v := newTestVerifier(t, h, clock, nil)

	oldTok := signToken(t, oldKey, rs256Header(jwkThumbprint(t, &oldKey.PublicKey)), brokerClaims(clock.Now().Unix()))
	newTok := signToken(t, newKey, rs256Header(jwkThumbprint(t, &newKey.PublicKey)), brokerClaims(clock.Now().Unix()))
	for name, tok := range map[string]string{"old key": oldTok, "new key": newTok} {
		if _, err := v.VerifyToken(context.Background(), tok); err != nil {
			t.Fatalf("%s must verify during the published overlap: %v", name, err)
		}
	}
}

func TestConcurrentVerificationSingleFlight(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey))
	clock := newFakeClock(1767225700)
	v := newTestVerifier(t, h, clock, nil)

	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))
	const n = 32
	var wg sync.WaitGroup
	errs := make([]error, n)
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			_, errs[i] = v.VerifyToken(context.Background(), tok)
		}(i)
	}
	wg.Wait()
	for i, err := range errs {
		if err != nil {
			t.Fatalf("goroutine %d: %v", i, err)
		}
	}
	if n := h.fetches.Load(); n != 1 {
		t.Fatalf("cold-cache stampede must fetch once, got %d fetches", n)
	}
}

// --- configuration fails closed ----------------------------------------------

func TestConfigFailsClosed(t *testing.T) {
	cases := map[string]Config{
		"no issuer":            {JWKSURL: "https://broker.example/gateway/jwks"},
		"http issuer":          {Issuer: "http://broker.example", JWKSURL: "https://broker.example/gateway/jwks"},
		"issuer with query":    {Issuer: "https://broker.example/?x=1", JWKSURL: "https://broker.example/gateway/jwks"},
		"issuer with userinfo": {Issuer: "https://user@broker.example", JWKSURL: "https://broker.example/gateway/jwks"},
		"no jwks url":          {Issuer: testIssuer},
		"http jwks url":        {Issuer: testIssuer, JWKSURL: "http://broker.example/gateway/jwks"},
		"jwks with query":      {Issuer: testIssuer, JWKSURL: "https://broker.example/jwks?x=1"},
	}
	for name, cfg := range cases {
		t.Run(name, func(t *testing.T) {
			if _, err := NewVerifier(cfg); err == nil {
				t.Fatalf("%s must not build", name)
			}
		})
	}
}

func TestIssuerTrailingSlashNormalized(t *testing.T) {
	key := brokerKey(t)
	kid := jwkThumbprint(t, &key.PublicKey)
	h := newJWKSHarness(t, jwksFor(t, &key.PublicKey))
	clock := newFakeClock(1767225700)
	v := newTestVerifier(t, h, clock, func(c *Config) { c.Issuer = testIssuer + "/" })

	// The broker never mints a trailing slash; a config that carries one is
	// normalized to the exact contract value.
	tok := signToken(t, key, rs256Header(kid), brokerClaims(clock.Now().Unix()))
	if _, err := v.VerifyToken(context.Background(), tok); err != nil {
		t.Fatal(err)
	}
	// A trailing slash minted INTO the token is not the contract value.
	bad := brokerClaims(clock.Now().Unix())
	bad["iss"] = testIssuer + "/"
	tok = signToken(t, key, rs256Header(kid), bad)
	if _, err := v.VerifyToken(context.Background(), tok); !errors.Is(err, ErrUnauthorized) {
		t.Fatal("token issuer must match byte-for-byte")
	}
}
