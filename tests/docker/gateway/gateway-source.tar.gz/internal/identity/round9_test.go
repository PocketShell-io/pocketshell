package identity

// Round-nine regressions (final independent review):
//
//  1. NewService accepted ANY DeviceStore and wrapped it in the quota
//     decorator as an AuthorizedStore — a false guarantee. The decorator
//     evaluated the check, then called opaque inner Count/Put/Replace/
//     Revoke/List whose internals may block arbitrarily; a principal that
//     expired (or a context that canceled) inside that window reached the
//     plain inner Put with no final gate. Construction now REFUSES injected
//     stores without AuthorizedStore semantics, and the decorator forwards
//     every check into supported stores' actual mutation/list locks.
//  2. The paused-lock HTTP tests signaled inside VerifyToken — BEFORE
//     authenticate's final clock/context checks — so they could pass by
//     rejection at initial authentication instead of at the store-lock
//     gate (fixed in round8_test.go with store-entry barriers).
//
// Determinism: entered/gate channel pairs synchronize every blocked region;
// the 2-second channel waits are hang guards on expected events, never
// pacing sleeps.

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

// opaqueBlockingStore is a plain DeviceStore (NO AuthorizedStore methods)
// whose Count and Put block forever once entered — defusable via the gate
// channels. The blocking design makes construction-time side effects
// impossible to miss: if NewService (or anything else) ever called Count or
// Put, the caller would hang on the gate, and once defused the entered
// channels prove whether the calls happened.
type opaqueBlockingStore struct {
	inner *MemoryStore

	countEntered chan struct{}
	countGate    chan struct{}
	putEntered   chan struct{}
	putGate      chan struct{}

	countOnce, putOnce sync.Once
}

func (o *opaqueBlockingStore) GetDevice(id string) (Device, error) { return o.inner.GetDevice(id) }
func (o *opaqueBlockingStore) Replace(d Device) (Device, bool, error) {
	return o.inner.Replace(d)
}
func (o *opaqueBlockingStore) List(a string) ([]Device, error) { return o.inner.List(a) }
func (o *opaqueBlockingStore) Revoke(id, a string) (Device, []Device, bool, error) {
	return o.inner.Revoke(id, a)
}
func (o *opaqueBlockingStore) Count(a string) (int, error) {
	o.countOnce.Do(func() { close(o.countEntered) })
	<-o.countGate
	return o.inner.Count(a)
}
func (o *opaqueBlockingStore) Put(d Device) error {
	o.putOnce.Do(func() { close(o.putEntered) })
	<-o.putGate
	return o.inner.Put(d)
}

// NewService must refuse stores that cannot carry the final under-lock
// admission gate — at construction, with no store side effects. The
// previous decorator-only design accepted this store and pretended the
// admission guarantee held.
func TestUnsupportedInjectedStoreRejected(t *testing.T) {
	opaque := &opaqueBlockingStore{
		inner:        NewMemoryStore(),
		countEntered: make(chan struct{}),
		countGate:    make(chan struct{}),
		putEntered:   make(chan struct{}),
		putGate:      make(chan struct{}),
	}
	clock := newFakeClock()
	errc := make(chan error, 1)
	go func() {
		_, err := NewService(Config{
			Verifier: newStubVerifier(clock.Now().Add(time.Hour), map[string]Principal{
				tokenA: {AccountID: "google:" + subA, Email: emailA},
			}),
			Store:  opaque,
			Clock:  clock.Now,
			Logger: func(string, ...any) {},
		})
		errc <- err
	}()
	var err error
	select {
	case err = <-errc:
	case <-time.After(2 * time.Second):
		// Defuse before failing so no fixture goroutine stays blocked.
		close(opaque.countGate)
		close(opaque.putGate)
		t.Fatal("NewService blocked constructing an unsupported (non-AuthorizedStore) injected store")
	}
	if err == nil {
		t.Fatal("NewService accepted a plain DeviceStore; the final under-lock admission guarantee cannot hold for opaque stores")
	}
	if !strings.Contains(err.Error(), "AuthorizedStore") {
		t.Fatalf("rejection must name the missing contract, got: %v", err)
	}
	// Construction returned: any store call it made has completed (or the
	// timeout above fired). Defuse and prove nothing was ever called.
	close(opaque.countGate)
	close(opaque.putGate)
	select {
	case <-opaque.countEntered:
		t.Fatal("store Count was called during construction")
	default:
	}
	select {
	case <-opaque.putEntered:
		t.Fatal("store Put was called during construction")
	default:
	}
}

// blockingPutStore is a SUPPORTED (AuthorizedStore) injected store whose
// PutAdmitted blocks after the decorator's checks and before the inner
// registry call — modeling arbitrary work inside an admitted call. The
// check is forwarded (never stubbed), so the inner registry re-runs it
// under its own mutation lock as the final gate.
type blockingPutStore struct {
	inner *MemoryStore

	putEntered chan struct{}
	putGate    chan struct{}
	once       sync.Once
}

func (b *blockingPutStore) GetDevice(id string) (Device, error) { return b.inner.GetDevice(id) }
func (b *blockingPutStore) Put(d Device) error                  { return b.inner.Put(d) }
func (b *blockingPutStore) Replace(d Device) (Device, bool, error) {
	return b.inner.Replace(d)
}
func (b *blockingPutStore) List(a string) ([]Device, error) { return b.inner.List(a) }
func (b *blockingPutStore) Count(a string) (int, error)     { return b.inner.Count(a) }
func (b *blockingPutStore) Revoke(id, a string) (Device, []Device, bool, error) {
	return b.inner.Revoke(id, a)
}
func (b *blockingPutStore) PutAdmitted(check AdmissionCheck, d Device) error {
	b.once.Do(func() { close(b.putEntered) })
	<-b.putGate
	return b.inner.PutAdmitted(check, d)
}
func (b *blockingPutStore) ReplaceAdmitted(check AdmissionCheck, d Device) (Device, bool, error) {
	return b.inner.ReplaceAdmitted(check, d)
}
func (b *blockingPutStore) ListAdmitted(check AdmissionCheck, a string) ([]Device, error) {
	return b.inner.ListAdmitted(check, a)
}
func (b *blockingPutStore) RevokeAdmitted(check AdmissionCheck, id, a string) (Device, []Device, bool, error) {
	return b.inner.RevokeAdmitted(check, id, a)
}

// The supported-store counterpart of the old false guarantee: a principal
// that expires INSIDE the admitted call (after the decorator's check, while
// the store's admitted work is in flight) is still denied by the final gate
// under the inner registry's mutation lock — nothing is enrolled.
func TestSupportedInjectedStoreAdmissionCoversInnerWork(t *testing.T) {
	t.Run("expiry-during-admitted-put", func(t *testing.T) {
		blk := &blockingPutStore{
			inner:      NewMemoryStore(),
			putEntered: make(chan struct{}),
			putGate:    make(chan struct{}),
		}
		f := newRound8Fixture(t, blk)
		_, priv := newKeyPair(t)
		reqBody := f.issueChallenge(t, priv, "supported-expiry-1")
		raw, err := json.Marshal(reqBody)
		if err != nil {
			t.Fatal(err)
		}
		req := httptest.NewRequest(http.MethodPost, "/identity/v1/enroll", bytes.NewReader(raw))
		req.Host = "gateway.test"
		req.Header.Set("Authorization", "Bearer "+tokenA)
		await := serveAsync(f.service, req)

		// The decorator's own check has already passed (clock at base); the
		// request is now inside the store's admitted put.
		select {
		case <-blk.putEntered:
		case <-time.After(2 * time.Second):
			t.Fatal("enroll never reached the admitted put inside the supported store")
		}
		f.clock.Advance(2 * time.Hour) // expiry crosses during the inner work
		close(blk.putGate)

		resp := await()
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusUnauthorized {
			t.Fatalf("enroll surviving expiry inside the admitted put = %s, want 401", resp.Status)
		}
		if _, err := blk.inner.GetDevice("supported-expiry-1"); !errors.Is(err, ErrDeviceNotFound) {
			t.Fatal("expired request must not enroll anything")
		}
	})

	t.Run("cancel-during-admitted-put", func(t *testing.T) {
		blk := &blockingPutStore{
			inner:      NewMemoryStore(),
			putEntered: make(chan struct{}),
			putGate:    make(chan struct{}),
		}
		f := newRound8Fixture(t, blk)
		_, priv := newKeyPair(t)
		reqBody := f.issueChallenge(t, priv, "supported-cancel-1")
		raw, err := json.Marshal(reqBody)
		if err != nil {
			t.Fatal(err)
		}
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		req := httptest.NewRequest(http.MethodPost, "/identity/v1/enroll", bytes.NewReader(raw)).WithContext(ctx)
		req.Host = "gateway.test"
		req.Header.Set("Authorization", "Bearer "+tokenA)
		await := serveAsync(f.service, req)

		select {
		case <-blk.putEntered:
		case <-time.After(2 * time.Second):
			t.Fatal("enroll never reached the admitted put inside the supported store")
		}
		cancel() // the caller gives up while the store work is in flight
		close(blk.putGate)

		resp := await()
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusUnauthorized {
			t.Fatalf("enroll surviving cancellation inside the admitted put = %s, want 401", resp.Status)
		}
		if _, err := blk.inner.GetDevice("supported-cancel-1"); !errors.Is(err, ErrDeviceNotFound) {
			t.Fatal("canceled request must not enroll anything")
		}
	})
}

// forwardStore is a minimal admission-capable injected registry: every
// authorized call forwards the check into the inner MemoryStore's actual
// mutation/list lock.
type forwardStore struct{ inner *MemoryStore }

func (f *forwardStore) GetDevice(id string) (Device, error) { return f.inner.GetDevice(id) }
func (f *forwardStore) Put(d Device) error                  { return f.inner.Put(d) }
func (f *forwardStore) Replace(d Device) (Device, bool, error) {
	return f.inner.Replace(d)
}
func (f *forwardStore) List(a string) ([]Device, error) { return f.inner.List(a) }
func (f *forwardStore) Count(a string) (int, error)     { return f.inner.Count(a) }
func (f *forwardStore) Revoke(id, a string) (Device, []Device, bool, error) {
	return f.inner.Revoke(id, a)
}
func (f *forwardStore) PutAdmitted(check AdmissionCheck, d Device) error {
	return f.inner.PutAdmitted(check, d)
}
func (f *forwardStore) ReplaceAdmitted(check AdmissionCheck, d Device) (Device, bool, error) {
	return f.inner.ReplaceAdmitted(check, d)
}
func (f *forwardStore) ListAdmitted(check AdmissionCheck, a string) ([]Device, error) {
	return f.inner.ListAdmitted(check, a)
}
func (f *forwardStore) RevokeAdmitted(check AdmissionCheck, id, a string) (Device, []Device, bool, error) {
	return f.inner.RevokeAdmitted(check, id, a)
}

// Supported stores keep working end to end: the default StorePath→FileStore
// still constructs, an injected AuthorizedStore enrolls normally, and the
// quota decorator still applies its per-account bound on top.
func TestSupportedInjectedStoreEnrollPositive(t *testing.T) {
	// StorePath→FileStore remains a supported configuration.
	if _, err := NewService(Config{
		Verifier: newStubVerifier(time.Now().Add(time.Hour), map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA},
		}),
		StorePath: filepath.Join(t.TempDir(), "devices.json"),
		Logger:    func(string, ...any) {},
	}); err != nil {
		t.Fatalf("StorePath FileStore must remain supported: %v", err)
	}

	fwd := &forwardStore{inner: NewMemoryStore()}
	f := newRound8Fixture(t, fwd, func(c *Config) { c.MaxDevicesPerAccount = 1 })

	_, priv := newKeyPair(t)
	reqBody := f.issueChallenge(t, priv, "supported-ok-1")
	raw, err := json.Marshal(reqBody)
	if err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, "/identity/v1/enroll", bytes.NewReader(raw))
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	rec := httptest.NewRecorder()
	f.service.ServeHTTP(rec, req)
	if rec.Code != http.StatusCreated {
		t.Fatalf("positive enroll through supported injected store = %d, want 201: %s", rec.Code, rec.Body.String())
	}
	dev, err := fwd.inner.GetDevice("supported-ok-1")
	if err != nil || dev.Revoked {
		t.Fatalf("device not enrolled: %+v err=%v", dev, err)
	}

	// The decorator's quota still binds on top of the supported store.
	_, priv2 := newKeyPair(t)
	reqBody2 := f.issueChallenge(t, priv2, "supported-ok-2")
	raw2, err := json.Marshal(reqBody2)
	if err != nil {
		t.Fatal(err)
	}
	req2 := httptest.NewRequest(http.MethodPost, "/identity/v1/enroll", bytes.NewReader(raw2))
	req2.Host = "gateway.test"
	req2.Header.Set("Authorization", "Bearer "+tokenA)
	rec2 := httptest.NewRecorder()
	f.service.ServeHTTP(rec2, req2)
	if rec2.Code != http.StatusForbidden {
		t.Fatalf("second enroll at quota 1 = %d, want 403: %s", rec2.Code, rec2.Body.String())
	}
	if _, err := fwd.inner.GetDevice("supported-ok-2"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("quota-exceeded request must not enroll anything")
	}
}

// Compile-time proof the adapted fixtures are genuinely admission-capable
// (not always-allow stubs): they satisfy AuthorizedStore and forward checks
// to a real registry.
var (
	_ AuthorizedStore = (*forwardStore)(nil)
	_ AuthorizedStore = (*blockingPutStore)(nil)
	_ AuthorizedStore = (*observedStore)(nil)
	_ AuthorizedStore = (*slowLookupStore)(nil)
	_ AuthorizedStore = (*countingStore)(nil)
	// The opaque fixture must NOT satisfy it — the compile fails if the
	// interface is ever accidentally implemented.
	_ DeviceStore = (*opaqueBlockingStore)(nil)
)
