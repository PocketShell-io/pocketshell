// Package identity verifies Google-issued account identity and owns the
// durable device registry for the PocketShell gateway.
//
// Account identity comes from a verified Google ID token: RS256 signature
// against Google's JWKS, audience, issuer, expiry, verified email, and (for
// the rollout) the same email allowlist the legacy relay uses. The stable
// account identifier is issuer+subject ("google:<sub>"), never the
// user-supplied or mutable email; the email is carried on Principal for
// display and allowlist purposes only.
//
// Devices are enrolled per account through an owner-authorized HTTP API.
// Enrollment requires proof of possession of the device's Ed25519 private
// key over a single-use, expiring challenge bound to the role, gateway
// domain, protocol, device ID and a per-connection nonce, plus the real SSH
// public host key to pin. Public keys are never silently replaced; key
// rotation requires explicit re-enrollment that is disabled unless the
// operator turns it on.
//
// The package is stdlib-only and must NOT import the tunnel package: the
// tunnel worker consumes identity.Store and identity.Authenticate from here.
package identity

import (
	"context"
	"errors"
	"regexp"
	"time"
)

// Principal is the verified account identity.
type Principal struct {
	// AccountID is the stable issuer+subject identifier ("google:<sub>").
	// It is derived only from a verified token, never from request input.
	AccountID string
	// Email is the verified email from the token. Not an identifier.
	Email string
	// ExpiresAt is the token's expiry (zero if the verifier does not expose
	// one). Authentication is validated at verification time: an active
	// tunnel session is not automatically killed at this instant, but the
	// tunnel worker SHOULD re-authenticate before it passes.
	ExpiresAt time.Time
}

// Authenticate verifies a bearer credential (Google ID token) and returns
// the verified Principal, or an error. Implemented by GoogleVerifier and
// satisfied by *Service.TokenAuthenticator for the tunnel worker.
type Authenticate func(context.Context, string) (Principal, error)

// Device is an enrolled device (one private key + one pinned SSH host key).
type Device struct {
	ID         string
	AccountID  string
	PublicKey  []byte // raw 32-byte Ed25519 public key
	SSHHostKey string // pinned OpenSSH-format public host key line
	Revoked    bool
}

// Store is the read-only device lookup contract the tunnel worker uses.
type Store interface {
	GetDevice(id string) (Device, error)
}

// Roles and protocol identifiers used in challenge transcripts.
const (
	RoleEnroll       = "enroll"
	RoleHost         = "host"
	ProtocolIdentity = "pocketshell-identity/1"
)

// Sentinel errors. Handlers map these to status codes; consumers should
// compare with errors.Is.
var (
	ErrUnauthorized         = errors.New("identity: unauthorized")
	ErrDeviceNotFound       = errors.New("identity: device not found")
	ErrDeviceRevoked        = errors.New("identity: device revoked")
	ErrOwnerMismatch        = errors.New("identity: device owned by another account")
	ErrDeviceIDTaken        = errors.New("identity: device id already in use")
	ErrReenrollmentRequired = errors.New("identity: key or host key differs; explicit re-enrollment required")
	ErrReenrollmentDisabled = errors.New("identity: re-enrollment is disabled")
	ErrChallengeInvalid     = errors.New("identity: challenge invalid")
	ErrProofInvalid         = errors.New("identity: proof of possession failed")
	ErrLimitExceeded        = errors.New("identity: limit exceeded")
	ErrBadRequest           = errors.New("identity: bad request")
	ErrStoreFailure         = errors.New("identity: store failure")
	ErrHostKeyInvalid       = errors.New("identity: ssh host key invalid")
	ErrAccountQuotaExceeded = errors.New("identity: device quota exceeded")
	ErrPublicKeyRevoked     = errors.New("identity: public key belongs to a revoked device")
	ErrDuplicateKey         = errors.New("identity: public key already enrolled on another active device")
	ErrDurabilityUncertain  = errors.New("identity: mutation applied but durability unproven")
)

const (
	deviceIDPattern = `^[A-Za-z0-9][A-Za-z0-9._:-]{2,63}$`
	accountPattern  = `^google:[0-9A-Za-z_-]{1,128}$`
	maxSSHHostKey   = 4096
)

var (
	deviceIDRe = regexp.MustCompile(deviceIDPattern)
	accountRe  = regexp.MustCompile(accountPattern)
)

// ValidDeviceID reports whether id is a well-formed device identifier.
func ValidDeviceID(id string) bool { return deviceIDRe.MatchString(id) }

// ValidAccountID reports whether id is a well-formed issuer+subject ID.
func ValidAccountID(id string) bool { return accountRe.MatchString(id) }

// ValidPublicKey reports whether key is a raw Ed25519 public key.
func ValidPublicKey(key []byte) bool { return len(key) == 32 }

// ValidSSHHostKey reports whether hostKey looks like a single OpenSSH-format
// public key line ("<keytype> <base64>[ <comment>]"). It is pinned and
// compared byte-for-byte later; only shape is validated here.
func ValidSSHHostKey(hostKey string) bool {
	if len(hostKey) == 0 || len(hostKey) > maxSSHHostKey {
		return false
	}
	for _, r := range hostKey {
		if r == '\n' || r == '\r' || r == 0 || r < 0x20 {
			return false
		}
	}
	fields := splitFields(hostKey)
	if len(fields) < 2 {
		return false
	}
	switch fields[0] {
	case "ssh-ed25519", "ssh-rsa",
		"ecdsa-sha2-nistp256", "ecdsa-sha2-nistp384", "ecdsa-sha2-nistp521":
	default:
		return false
	}
	// Base64 blob: OpenSSH uses the standard alphabet, possibly padded.
	// Everything after the blob is a free-form comment; the value is pinned
	// and compared byte-for-byte, so only the shape above matters.
	n := len(fields[1])
	if n == 0 || n > 16384 {
		return false
	}
	for i, c := range fields[1] {
		switch {
		case c >= 'A' && c <= 'Z', c >= 'a' && c <= 'z', c >= '0' && c <= '9',
			c == '+' || c == '/':
		case c == '=':
			return i == n-1 || i == n-2
		default:
			return false
		}
	}
	return true
}

func splitFields(s string) []string {
	var out []string
	start := -1
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c == ' ' || c == '\t' {
			if start >= 0 {
				out = append(out, s[start:i])
				start = -1
			}
			continue
		}
		if start < 0 {
			start = i
		}
	}
	if start >= 0 {
		out = append(out, s[start:])
	}
	return out
}
