package identity

import (
	"context"
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"strings"
	"sync"
	"time"
)

// DefaultJWKSURL is Google's OAuth2 signing-key set.
const DefaultJWKSURL = "https://www.googleapis.com/oauth2/v3/certs"

// GoogleIssuer values accepted in the iss claim. Canonical form used in
// AccountID is "google".
var googleIssuers = map[string]bool{
	"https://accounts.google.com": true,
	"accounts.google.com":         true,
}

// GoogleAccountID derives the stable AccountID from a verified subject.
func GoogleAccountID(sub string) string { return "google:" + sub }

// TokenVerifier verifies a bearer credential and returns the Principal it
// belongs to, or an error. Fail-closed by construction.
type TokenVerifier interface {
	VerifyToken(ctx context.Context, token string) (Principal, error)
}

// GoogleConfig configures a GoogleVerifier. The allowlist keeps the legacy
// relay rollout semantics: an empty allowlist denies everyone.
type GoogleConfig struct {
	// ClientID is the OAuth audience that tokens must carry. Required.
	ClientID string
	// JWKSURL overrides the signing-key URL (tests only).
	JWKSURL string
	// Allowlist is the set of permitted verified emails (case-insensitive).
	// Empty means deny all.
	Allowlist []string
	// HTTPClient fetches JWKS. Defaults to a client with a 10s timeout.
	HTTPClient *http.Client
	// Clock defaults to time.Now.
	Clock func() time.Time
	// CacheTTL is how long a fetched JWKS is trusted (default 1h).
	CacheTTL time.Duration
	// RefreshCooldown is the minimum spacing of refresh attempts, whether
	// triggered by an unknown kid, an expired cache or an outage (default
	// 30s). Every attempt counts, successful or not.
	RefreshCooldown time.Duration
	// MaxStaleAge bounds how long cached signing keys are trusted when
	// refreshes keep failing (default 24h). Beyond it verification fails
	// closed instead of freezing trust in possibly-rotated keys forever.
	MaxStaleAge time.Duration
	// Leeway tolerates small clock skew on exp/iat/nbf (default 30s).
	Leeway time.Duration
	// MaxTokenBytes bounds token size (default 8192).
	MaxTokenBytes int
	// Logger receives rejection reasons; must never receive token material.
	Logger func(format string, args ...any)
}

// GoogleVerifier verifies Google-issued RS256 ID tokens against a cached
// JWKS, with claims checks and the rollout email allowlist.
type GoogleVerifier struct {
	clientID    string
	jwksURL     string
	allow       []string // lowercased
	client      *http.Client
	clock       func() time.Time
	ttl         time.Duration
	cooldown    time.Duration
	maxStaleAge time.Duration
	leeway      time.Duration
	maxToken    int
	logger      func(string, ...any)

	// mu guards the cache state and refresh bookkeeping below. It is never
	// held across network I/O: refreshes run single-flight in a detached
	// goroutine and waiters block on the done channel, honoring their own
	// context cancellation.
	mu          sync.Mutex
	keys        map[string]*rsa.PublicKey
	fetchedAt   time.Time
	lastAttempt time.Time
	refreshing  chan struct{} // non-nil while one refresh fetch is in flight
}

// NewGoogleVerifier builds a verifier. It fails closed: no clientID, no
// verification. An empty JWKSURL uses the Google default endpoint.
func NewGoogleVerifier(cfg GoogleConfig) (*GoogleVerifier, error) {
	if cfg.ClientID == "" {
		return nil, errors.New("identity: Google verifier requires ClientID")
	}
	clock := cfg.Clock
	if clock == nil {
		clock = time.Now
	}
	client := cfg.HTTPClient
	if client == nil {
		client = &http.Client{Timeout: 10 * time.Second}
	}
	jwksURL := cfg.JWKSURL
	if jwksURL == "" {
		jwksURL = DefaultJWKSURL
	}
	ttl := cfg.CacheTTL
	if ttl <= 0 {
		ttl = time.Hour
	}
	maxStaleAge := cfg.MaxStaleAge
	if maxStaleAge <= 0 {
		maxStaleAge = 24 * time.Hour
	}
	cooldown := cfg.RefreshCooldown
	if cooldown <= 0 {
		cooldown = 30 * time.Second
	}
	maxToken := cfg.MaxTokenBytes
	if maxToken <= 0 {
		maxToken = 8192
	}
	logger := cfg.Logger
	if logger == nil {
		logger = func(string, ...any) {}
	}
	allow := make([]string, 0, len(cfg.Allowlist))
	for _, e := range cfg.Allowlist {
		e = strings.ToLower(strings.TrimSpace(e))
		if e != "" {
			allow = append(allow, e)
		}
	}
	return &GoogleVerifier{
		clientID:    cfg.ClientID,
		jwksURL:     jwksURL,
		allow:       allow,
		client:      client,
		clock:       clock,
		ttl:         ttl,
		cooldown:    cooldown,
		maxStaleAge: maxStaleAge,
		leeway:      cfg.Leeway,
		maxToken:    maxToken,
		logger:      logger,
	}, nil
}

type jwtHeader struct {
	Alg string `json:"alg"`
	Kid string `json:"kid"`
}

type jwtClaims struct {
	Iss           string          `json:"iss"`
	Aud           json.RawMessage `json:"aud"`
	Exp           int64           `json:"exp"`
	Iat           int64           `json:"iat"`
	Nbf           int64           `json:"nbf"`
	Sub           string          `json:"sub"`
	Email         string          `json:"email"`
	EmailVerified bool            `json:"email_verified"`
}

// VerifyToken implements TokenVerifier. Every failure path returns
// ErrUnauthorized-wrapped errors; reasons are logged, never returned to
// clients, and never contain token material.
func (v *GoogleVerifier) VerifyToken(ctx context.Context, token string) (Principal, error) {
	if token == "" || len(token) > v.maxToken {
		return Principal{}, v.reject("empty or oversized token")
	}
	leeway := v.leeway
	if leeway < 0 {
		leeway = 0
	}
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return Principal{}, v.reject("malformed token")
	}
	decode := func(s string, limit int) ([]byte, error) {
		if len(s) > limit {
			return nil, errors.New("segment too large")
		}
		b, err := base64.RawURLEncoding.DecodeString(s)
		if err != nil {
			return nil, fmt.Errorf("bad base64: %w", err)
		}
		return b, nil
	}
	hb, err := decode(parts[0], 1024)
	if err != nil {
		return Principal{}, v.reject("header: %v", err)
	}
	cb, err := decode(parts[1], 8192)
	if err != nil {
		return Principal{}, v.reject("claims: %v", err)
	}
	sig, err := decode(parts[2], 1024)
	if err != nil {
		return Principal{}, v.reject("signature: %v", err)
	}
	var h jwtHeader
	if err := json.Unmarshal(hb, &h); err != nil {
		return Principal{}, v.reject("header: %v", err)
	}
	if h.Alg != "RS256" {
		return Principal{}, v.reject("alg %q not allowed", h.Alg)
	}
	if h.Kid == "" || len(h.Kid) > 128 {
		return Principal{}, v.reject("bad kid")
	}

	now := v.clock().Unix()
	var c jwtClaims
	dec := json.NewDecoder(strings.NewReader(string(cb)))
	if err := dec.Decode(&c); err != nil {
		return Principal{}, v.reject("claims: %v", err)
	}
	if !googleIssuers[c.Iss] {
		return Principal{}, v.reject("issuer %q not allowed", c.Iss)
	}
	if !audMatches(c.Aud, v.clientID) {
		return Principal{}, v.reject("audience mismatch")
	}
	if c.Exp <= 0 || now >= c.Exp+int64(leeway/time.Second) {
		return Principal{}, v.reject("token expired or missing exp")
	}
	if c.Iat > 0 && c.Iat > now+int64(leeway/time.Second) {
		return Principal{}, v.reject("iat in the future")
	}
	if c.Nbf > 0 && c.Nbf > now+int64(leeway/time.Second) {
		return Principal{}, v.reject("nbf in the future")
	}
	if len(c.Sub) == 0 || len(c.Sub) > 128 {
		return Principal{}, v.reject("bad sub")
	}
	for i := 0; i < len(c.Sub); i++ {
		if !isSubChar(c.Sub[i]) {
			return Principal{}, v.reject("bad sub")
		}
	}
	if c.Email == "" || len(c.Email) > 254 || !strings.Contains(c.Email, "@") {
		return Principal{}, v.reject("bad email")
	}
	if !c.EmailVerified {
		return Principal{}, v.reject("email not verified")
	}
	email := strings.ToLower(c.Email)
	if len(v.allow) == 0 {
		return Principal{}, v.reject("allowlist empty; denying all")
	}
	allowed := false
	for _, a := range v.allow {
		if subtle.ConstantTimeCompare([]byte(email), []byte(a)) == 1 {
			allowed = true
			break
		}
	}
	if !allowed {
		return Principal{}, v.reject("email not allowlisted")
	}

	key, err := v.signingKey(ctx, h.Kid)
	if err != nil {
		return Principal{}, v.reject("signing key: %v", err)
	}
	digest := sha256.Sum256([]byte(parts[0] + "." + parts[1]))
	if err := rsa.VerifyPKCS1v15(key, crypto.SHA256, digest[:], sig); err != nil {
		return Principal{}, v.reject("signature verify: %v", err)
	}
	// Recheck AFTER the potentially slow signing-key fetch (round-three #6):
	// a token valid at parse time may have expired while the JWKS call was
	// in flight, and a canceled caller must never be authorized by a
	// verification it abandoned.
	if ctx.Err() != nil {
		return Principal{}, v.reject("context canceled during verification")
	}
	if nowAfterFetch := v.clock().Unix(); nowAfterFetch >= c.Exp+int64(leeway/time.Second) {
		return Principal{}, v.reject("token expired during verification")
	}
	return Principal{
		AccountID: GoogleAccountID(c.Sub),
		Email:     email,
		ExpiresAt: time.Unix(c.Exp, 0).UTC(),
	}, nil
}

func (v *GoogleVerifier) reject(format string, args ...any) error {
	v.logger("identity: token rejected: "+format, args...)
	return fmt.Errorf("%w: %s", ErrUnauthorized, fmt.Sprintf(format, args...))
}

// signingKey returns the cached key for kid, refreshing the JWKS when the
// cache is cold, the kid is unknown (key rotation) or the cache is stale.
//
// Concurrency and failure contract (round-two A12):
//   - at most one refresh is in flight; waiters block on its completion
//     channel and honor their own context cancellation, so a stalled fetch
//     cannot hold verifications hostage longer than the callers allow;
//   - the fetch runs detached from the initiating request
//     (context.WithoutCancel) with its own timeout, so one canceled request
//     cannot kill a shared refresh;
//   - refresh ATTEMPTS — successful or not, for any trigger — are
//     rate-limited by the cooldown, so outage bursts cannot storm the
//     endpoint;
//   - cached keys are served stale only within maxStaleAge; beyond it
//     verification fails closed instead of trusting possibly-rotated keys
//     forever.
func (v *GoogleVerifier) signingKey(ctx context.Context, kid string) (*rsa.PublicKey, error) {
	for {
		v.mu.Lock()
		now := v.clock()
		var (
			key   *rsa.PublicKey
			found bool
			age   time.Duration
		)
		if v.keys != nil {
			key, found = v.keys[kid]
			age = now.Sub(v.fetchedAt)
		}
		if found && age <= v.ttl {
			v.mu.Unlock()
			return key, nil
		}
		if v.refreshing != nil {
			done := v.refreshing
			v.mu.Unlock()
			select {
			case <-done:
				continue // re-evaluate against the refreshed cache
			case <-ctx.Done():
				return nil, fmt.Errorf("%w: refresh wait: %v", ErrUnauthorized, ctx.Err())
			}
		}
		// Every refresh trigger — cold cache, expired cache, unknown kid —
		// is gated by the same cooldown. A failed cold fetch leaves the
		// cache empty; without this gate the loop would immediately start
		// another fetch and spin until the caller deadline (round-six P1).
		refreshDue := (v.keys == nil || (found && age > v.ttl) || !found) &&
			now.Sub(v.lastAttempt) >= v.cooldown
		if !refreshDue {
			// Classify from a snapshot taken under the mutex: runRefresh
			// publishes v.keys under the same lock, and reading it after the
			// unlock would race the publish (round-seven P2).
			cacheEmpty := v.keys == nil
			v.mu.Unlock()
			if found {
				if age > v.maxStaleAge {
					return nil, fmt.Errorf("%w: signing keys stale beyond maximum age", ErrUnauthorized)
				}
				return key, nil // stale but trusted within maxStaleAge
			}
			if cacheEmpty {
				return nil, fmt.Errorf("%w: signing keys unavailable (refresh rate-limited)", ErrUnauthorized)
			}
			return nil, fmt.Errorf("%w: unknown kid (refresh rate-limited)", ErrUnauthorized)
		}
		// Become the refresher. The fetch runs outside the mutex, detached
		// from this request's lifetime; this caller then waits like any
		// other, honoring its own context.
		done := make(chan struct{})
		v.refreshing = done
		v.lastAttempt = now
		v.mu.Unlock()
		go v.runRefresh(ctx, done)
		select {
		case <-done:
			// Loop: serve fresh key, serve stale within max age, or fail.
		case <-ctx.Done():
			return nil, fmt.Errorf("%w: refresh wait: %v", ErrUnauthorized, ctx.Err())
		}
	}
}

// runRefresh performs one JWKS fetch and publishes the result. It always
// releases waiters, even on panic.
func (v *GoogleVerifier) runRefresh(parent context.Context, done chan struct{}) {
	defer func() {
		v.mu.Lock()
		v.refreshing = nil
		v.mu.Unlock()
		close(done)
	}()
	// Detach from the initiating request: waiters must not be abandoned by
	// someone else's cancellation. The fetch keeps its own timeout.
	fetchCtx, cancel := context.WithTimeout(context.WithoutCancel(parent), 10*time.Second)
	defer cancel()
	keys, err := v.fetch(fetchCtx)
	if err != nil {
		v.logger("identity: jwks refresh failed: %v", err)
		return
	}
	v.mu.Lock()
	v.keys = keys
	v.fetchedAt = v.clock()
	v.mu.Unlock()
}

func (v *GoogleVerifier) fetch(ctx context.Context) (map[string]*rsa.PublicKey, error) {
	cctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(cctx, http.MethodGet, v.jwksURL, nil)
	if err != nil {
		return nil, err
	}
	res, err := v.client.Do(req)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("jwks fetch: HTTP %d", res.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(res.Body, 1<<20))
	if err != nil {
		return nil, err
	}
	var set struct {
		Keys []struct {
			Kid string `json:"kid"`
			N   string `json:"n"`
			E   string `json:"e"`
		} `json:"keys"`
	}
	if err := json.Unmarshal(body, &set); err != nil {
		return nil, err
	}
	keys := make(map[string]*rsa.PublicKey, len(set.Keys))
	for _, k := range set.Keys {
		if k.Kid == "" || len(k.Kid) > 128 {
			continue
		}
		nb, err := base64.RawURLEncoding.DecodeString(k.N)
		if err != nil || len(nb) == 0 || len(nb) > 1024 {
			continue
		}
		eb, err := base64.RawURLEncoding.DecodeString(k.E)
		if err != nil || len(eb) == 0 || len(eb) > 4 {
			continue
		}
		e := uint32(0)
		for _, b := range eb {
			e = e<<8 | uint32(b)
		}
		if e < 3 || e%2 == 0 {
			continue
		}
		n := new(big.Int).SetBytes(nb)
		if n.BitLen() < 2048 || n.BitLen() > 8192 {
			continue
		}
		keys[k.Kid] = &rsa.PublicKey{N: n, E: int(e)}
	}
	if len(keys) == 0 {
		return nil, errors.New("jwks had no usable keys")
	}
	return keys, nil
}

func audMatches(raw json.RawMessage, want string) bool {
	var s string
	if err := json.Unmarshal(raw, &s); err == nil {
		return s == want
	}
	var list []string
	if err := json.Unmarshal(raw, &list); err == nil && len(list) == 1 {
		return list[0] == want
	}
	return false
}

func isSubChar(c byte) bool {
	return c >= '0' && c <= '9' || c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c == '-' || c == '_'
}

// randomToken returns a URL-safe random string with n bytes of entropy.
func randomToken(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}

// lengthPrefix appends a 4-byte big-endian length-prefixed field to dst.
// The prefixing removes any ambiguity between field boundaries when the
// transcript is signed.
func lengthPrefix(dst []byte, s string) []byte {
	var l [4]byte
	binary.BigEndian.PutUint32(l[:], uint32(len(s)))
	dst = append(dst, l[:]...)
	return append(dst, s...)
}
