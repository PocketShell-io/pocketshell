package identity

// Round-two review regression tests (source-review-findings.md I2, I4, A9,
// A12, A13, C1 + tombstone-capacity and duplicate-key properties).
//
// History: the property cases below ran RED against the pre-fix code
// (temporary red-only harness, 2026-10-07, output recorded in
// .tmp/identity-progress.md): v1 revoked keys escaped tombstones, keys
// escaped at tombstone capacity, duplicate active keys were accepted, an
// injected store admitted 2 devices at limit 1, an empty JWKSURL errored,
// stale keys were trusted without limit, an outage burst caused 30 refresh
// attempts inside one cooldown, and JWKS waiters blocked indefinitely
// behind in-flight I/O. All of these must stay green now.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

// --- shared test infrastructure ----------------------------------------------

// roundTripperFunc adapts a function into an http.RoundTripper.
type roundTripperFunc func(*http.Request) (*http.Response, error)

func (f roundTripperFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

// jwksBody marshals keys into a JWKS JSON document.
func jwksBody(keys map[string]*rsa.PrivateKey) []byte {
	type k struct {
		Kid string `json:"kid"`
		N   string `json:"n"`
		E   string `json:"e"`
	}
	set := struct {
		Keys []k `json:"keys"`
	}{}
	for kid, key := range keys {
		e := new(big.Int).SetInt64(int64(key.E))
		set.Keys = append(set.Keys, k{
			Kid: kid,
			N:   base64.RawURLEncoding.EncodeToString(key.N.Bytes()),
			E:   base64.RawURLEncoding.EncodeToString(e.Bytes()),
		})
	}
	out, _ := json.Marshal(set)
	return out
}

func jwksHTTPResponse(keys map[string]*rsa.PrivateKey) *http.Response {
	return &http.Response{
		StatusCode: http.StatusOK,
		Header:     http.Header{"Content-Type": []string{"application/json"}},
		Body:       io.NopCloser(bytes.NewReader(jwksBody(keys))),
	}
}

// outageJWKS is a JWKS transport stub: serves keys, can simulate an outage,
// can gate one specific fetch for cancellation tests, and counts fetches.
type outageJWKS struct {
	mu     sync.Mutex
	keys   map[string]*rsa.PrivateKey
	outage bool
	gate   chan struct{}
	gateAt int64 // block fetch number gateAt (1-based); 0 = never
	n      int64
}

func (o *outageJWKS) RoundTrip(r *http.Request) (*http.Response, error) {
	o.mu.Lock()
	o.n++
	n := o.n
	gate := o.gate
	gateAt := o.gateAt
	outage := o.outage
	o.mu.Unlock()
	if gate != nil && gateAt == n {
		<-gate
	}
	if outage {
		return nil, errors.New("jwks outage")
	}
	return jwksHTTPResponse(o.keys), nil
}

func (o *outageJWKS) setOutage(v bool) {
	o.mu.Lock()
	defer o.mu.Unlock()
	o.outage = v
}

func (o *outageJWKS) fetches() int64 {
	o.mu.Lock()
	defer o.mu.Unlock()
	return o.n
}

// fixedKey is deterministic so duplicate-key tests can share it.
var fixedKey = func() ed25519.PublicKey {
	seed := sha256.Sum256([]byte("pocketshell-identity-round-two-fixed-seed"))
	pub, _, err := ed25519.GenerateKey(bytes.NewReader(seed[:]))
	if err != nil {
		panic(err)
	}
	return pub
}()

func mustKey(t *testing.T) ed25519.PublicKey { return fixedKey }

func httptestServer(t *testing.T, h http.Handler) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(h)
	t.Cleanup(srv.Close)
	return srv
}

// writeRegistryFile writes a registry file in the shape the round-1 code
// produced (embedded Device has no JSON tags, so keys are Go field names).
func writeRegistryFile(t *testing.T, path string, version int, devices []Device, revokedKeys []string) {
	t.Helper()
	type rec struct {
		Device
		EnrolledAt string
	}
	// Field names mirror the production registry exactly: storeFile carries
	// explicit snake_case tags for the top-level fields, while device
	// records keep Go-case names (embedded Device has no tags).
	f := struct {
		Version     int      `json:"version"`
		Devices     []rec    `json:"devices"`
		RevokedKeys []string `json:"revoked_keys,omitempty"`
	}{Version: version}
	for _, d := range devices {
		f.Devices = append(f.Devices, rec{Device: d, EnrolledAt: "2026-01-01T00:00:00Z"})
	}
	f.RevokedKeys = revokedKeys
	data, err := json.MarshalIndent(f, "", " ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, data, 0o600); err != nil {
		t.Fatal(err)
	}
}

func readRegistryDevices(t *testing.T, path string) []Device {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var f struct {
		Devices []deviceRecord
	}
	if err := json.Unmarshal(data, &f); err != nil {
		t.Fatal(err)
	}
	out := make([]Device, 0, len(f.Devices))
	for _, rec := range f.Devices {
		out = append(out, rec.Device)
	}
	return out
}

func mustRevoked(t *testing.T, fs *FileStore, id string) bool {
	t.Helper()
	dev, err := fs.GetDevice(id)
	if err != nil {
		t.Fatal(err)
	}
	return dev.Revoked
}

// --- I2: injected stores get the configured quota ---------------------------

// RED (round 4 admitted 2 devices at limit 1 with an injected FileStore):
// Config.Store bypassed Config.MaxDevicesPerAccount entirely.
func TestInjectedStoreQuotaDeterministic(t *testing.T) {
	s := newTestService(t, func(c *Config) {
		c.Store = NewMemoryStore()
		c.MaxDevicesPerAccount = 1
		c.MaxOutstandingChallenges = 128
	})
	srv := httptestServer(t, s)
	const n = 16
	release := make(chan struct{})
	var linedUp sync.WaitGroup
	linedUp.Add(n)
	results := make(chan int, n)
	for i := 0; i < n; i++ {
		go func(i int) {
			linedUp.Done() // lined up; now wait for the common start signal
			<-release      // awaited: all goroutines start together
			_, priv, err := ed25519.GenerateKey(rand.Reader)
			if err != nil {
				t.Error(err)
				results <- 0
				return
			}
			resp := runEnrollmentAt(t, srv.URL, tokenA, fmt.Sprintf("dev-%d", i), priv, testHostKey, false)
			results <- resp.StatusCode
		}(i)
	}
	linedUp.Wait()
	close(release)
	accepted := 0
	for i := 0; i < n; i++ {
		switch status := <-results; status {
		case http.StatusCreated:
			accepted++
		case http.StatusForbidden:
		default:
			t.Fatalf("unexpected status %d", status)
		}
	}
	if accepted != 1 {
		t.Fatalf("injected store admitted %d devices at limit 1, want exactly 1", accepted)
	}
}

// --- I4: v1 registries derive tombstones from revoked records ---------------

// RED (escaped): a v1 registry's revoked record did not tombstone its key.
func TestV1MigrationDerivesTombstones(t *testing.T) {
	_, priv := newKeyPair(t)
	dev := Device{
		ID: "old-dev", AccountID: "google:1",
		PublicKey: priv.Public().(ed25519.PublicKey), SSHHostKey: testHostKey,
		Revoked: true,
	}
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	writeRegistryFile(t, path, 1, []Device{dev}, nil)

	for attempt := 0; attempt < 2; attempt++ {
		fs, err := NewFileStore(path)
		if err != nil {
			t.Fatalf("attempt %d: load v1: %v", attempt, err)
		}
		if !mustRevoked(t, fs, "old-dev") {
			t.Fatalf("attempt %d: revoked record not visible", attempt)
		}
		// Same key under a new ID and a different account must fail —
		// before and after restart.
		err = fs.Put(Device{ID: fmt.Sprintf("new-dev-%d", attempt), AccountID: "google:2", PublicKey: dev.PublicKey, SSHHostKey: testHostKey})
		if !errors.Is(err, ErrPublicKeyRevoked) {
			t.Fatalf("attempt %d: escaped v1 tombstone: %v, want ErrPublicKeyRevoked", attempt, err)
		}
	}
}

// --- I4: duplicate active registration keys ---------------------------------

// RED (accepted): the same public key could be enrolled on multiple active
// devices; and revoking one device must invalidate every copy of the key.
func TestDuplicateActiveKeyRejected(t *testing.T) {
	fs := NewMemoryStore()
	if err := fs.Put(Device{ID: "dev-d1", AccountID: "google:1", PublicKey: mustKey(t), SSHHostKey: testHostKey}); err != nil {
		t.Fatal(err)
	}
	err := fs.Put(Device{ID: "dev-d2", AccountID: "google:2", PublicKey: mustKey(t), SSHHostKey: testHostKey})
	if !errors.Is(err, ErrDuplicateKey) {
		t.Fatalf("duplicate active key: %v, want ErrDuplicateKey", err)
	}
	// After revocation the tombstone (not mere duplication) is the reason.
	if _, _, _, err := fs.Revoke("dev-d1", "google:1"); err != nil {
		t.Fatal(err)
	}
	err = fs.Put(Device{ID: "dev-d3", AccountID: "google:3", PublicKey: mustKey(t), SSHHostKey: testHostKey})
	if !errors.Is(err, ErrPublicKeyRevoked) {
		t.Fatalf("revoked key reuse: %v, want ErrPublicKeyRevoked", err)
	}
}

// RED (twin stayed active): revoking one of two devices sharing a key left
// the duplicate active. Historical duplicates are cascaded in the same
// atomic write and stay revoked across restart.
func TestRevokeCascadesDuplicateKeys(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	// Seed a legacy duplicate pair directly into a registry file: current
	// admission would refuse to create it, but old data can contain it.
	writeRegistryFile(t, path, 2,
		[]Device{
			{ID: "dev-e1", AccountID: "google:1", PublicKey: mustKey(t), SSHHostKey: testHostKey},
			{ID: "dev-e2", AccountID: "google:2", PublicKey: mustKey(t), SSHHostKey: testHostKey},
		},
		nil)
	fs, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	_, cascaded, changed, err := fs.Revoke("dev-e1", "google:1")
	if err != nil || !changed {
		t.Fatalf("revoke: changed=%v err=%v", changed, err)
	}
	if len(cascaded) != 1 || cascaded[0].ID != "dev-e2" || !cascaded[0].Revoked {
		t.Fatalf("cascade missing: %+v", cascaded)
	}
	got, err := fs.GetDevice("dev-e2")
	if err != nil || !got.Revoked {
		t.Fatalf("duplicate escaped revocation: %+v err=%v", got, err)
	}
	fs2, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	if got, err = fs2.GetDevice("dev-e2"); err != nil || !got.Revoked {
		t.Fatalf("cascade not durable: %+v err=%v", got, err)
	}
}

// --- I4/tombstone capacity: derivation, never silent weakening --------------

// RED (escaped at capacity): once the tombstone set hit its cap, revocation
// "succeeded" but the key remained enrollable under a new ID.
func TestTombstoneCapacityBoundary(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	limits := Limits{MaxPerAccount: -1, MaxRevokedKeys: 2}
	fs, err := NewFileStore(path, WithLimits(limits))
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []string{"dev-a", "dev-b", "dev-c"} {
		if err := fs.Put(testDevice(id, "google:1")); err != nil {
			t.Fatal(err)
		}
	}
	for _, id := range []string{"dev-a", "dev-b", "dev-c"} {
		if _, _, changed, err := fs.Revoke(id, "google:1"); err != nil || !changed {
			t.Fatalf("revoke %s must succeed regardless of tombstone capacity: changed=%v err=%v", id, changed, err)
		}
	}
	for _, id := range []string{"dev-a", "dev-b", "dev-c"} {
		dev, err := fs.GetDevice(id)
		if err != nil {
			t.Fatal(err)
		}
		err = fs.Put(Device{ID: id + "-x", AccountID: "google:9", PublicKey: dev.PublicKey, SSHHostKey: testHostKey})
		if !errors.Is(err, ErrPublicKeyRevoked) {
			t.Fatalf("key from revoked %s escaped at capacity: %v", id, err)
		}
	}
	// Restart: derivation from revoked records keeps the guarantee.
	fs2, err := NewFileStore(path, WithLimits(limits))
	if err != nil {
		t.Fatal(err)
	}
	dev, err := fs2.GetDevice("dev-c")
	if err != nil {
		t.Fatal(err)
	}
	if err := fs2.Put(Device{ID: "dev-c-x2", AccountID: "google:9", PublicKey: dev.PublicKey, SSHHostKey: testHostKey}); !errors.Is(err, ErrPublicKeyRevoked) {
		t.Fatalf("post-restart escape at capacity: %v", err)
	}
}

// --- A9: default JWKS URL ----------------------------------------------------

// RED (Get ""): an empty JWKSURL errored instead of using the Google
// default. The transport stub verifies the actual request URL.
func TestDefaultJWKSURLUsed(t *testing.T) {
	var gotURL string
	key := mustRSA(t)
	rt := roundTripperFunc(func(r *http.Request) (*http.Response, error) {
		gotURL = r.URL.String()
		if r.URL.String() != DefaultJWKSURL {
			return nil, fmt.Errorf("unexpected JWKS URL %q", r.URL.String())
		}
		return jwksHTTPResponse(map[string]*rsa.PrivateKey{"kid-1": key}), nil
	})
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID:   "test-client-id",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: rt},
		Clock:      newFakeClock().Now,
		Logger:     func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	clock := newFakeClock()
	if _, err := v.VerifyToken(context.Background(), signToken(t, key, "kid-1", nil, baseClaims(clock, "113958430858354529072", "user@example.com"))); err != nil {
		t.Fatalf("default JWKS URL not applied: %v", err)
	}
	if gotURL != DefaultJWKSURL {
		t.Fatalf("request went to %q, want %q", gotURL, DefaultJWKSURL)
	}
}

// --- A12: stale acceptance has a maximum age ---------------------------------

// RED (accepted after 50h of outage): stale keys were trusted forever.
func TestStaleAcceptanceMaximumAge(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	stub := &outageJWKS{keys: map[string]*rsa.PrivateKey{"kid-1": key}}
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: stub},
		Clock:      clock.Now,
		Logger:     func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	claims["exp"] = clock.Now().Add(365 * 24 * time.Hour).Unix() // outlive clock advances
	tok := signToken(t, key, "kid-1", nil, claims)
	if _, err := v.VerifyToken(ctx, tok); err != nil {
		t.Fatal(err)
	}
	stub.setOutage(true)
	clock.Advance(2 * time.Hour) // past TTL, within max stale age
	if _, err := v.VerifyToken(ctx, tok); err != nil {
		t.Fatalf("stale key within max age must be served: %v", err)
	}
	clock.Advance(48 * time.Hour) // far beyond the maximum stale age
	if _, err := v.VerifyToken(ctx, tok); err == nil {
		t.Fatal("stale key accepted without any maximum age — outage could freeze trust forever")
	}
}

// RED (blocked until the test binary timed out): waiters ignored context
// cancellation while another refresh performed I/O.
func TestJWKSRefreshWaiterCancellation(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	gate := make(chan struct{})
	stub := &outageJWKS{keys: map[string]*rsa.PrivateKey{"kid-1": key}, gate: gate, gateAt: 2}
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: stub},
		Clock:      clock.Now,
		Logger:     func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	claims["exp"] = clock.Now().Add(365 * 24 * time.Hour).Unix()
	tok := signToken(t, key, "kid-1", nil, claims)
	if _, err := v.VerifyToken(ctx, tok); err != nil {
		t.Fatal(err)
	}
	clock.Advance(2 * time.Minute) // cooldown elapsed: unknown kid will refresh
	refreshDone := make(chan struct{})
	go func() {
		defer close(refreshDone)
		_, _ = v.VerifyToken(ctx, signToken(t, key, "kid-unknown", nil, claims))
	}()
	time.Sleep(100 * time.Millisecond) // refresh starts and blocks in gated I/O
	waiterCtx, cancel := context.WithTimeout(ctx, 150*time.Millisecond)
	defer cancel()
	start := time.Now()
	_, waitErr := v.VerifyToken(waiterCtx, tok)
	waited := time.Since(start)
	if waited > time.Second {
		t.Fatalf("waiter blocked %v behind in-flight I/O; cancellation must be honored", waited)
	}
	_ = waitErr // a canceled waiter may serve stale or fail; it must not hang
	close(gate) // unblock the in-flight fetch; the refresh then completes
	<-refreshDone
}

// RED (30 attempts inside one cooldown): an expired-cache outage triggered a
// refresh attempt on every verification. Extends the round-one warm-cache
// unknown-kid coverage to the expired-cache outage burst.
func TestExpiredCacheOutageBurstRateLimited(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	stub := &outageJWKS{keys: map[string]*rsa.PrivateKey{"kid-1": key}}
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: stub},
		Clock:      clock.Now, RefreshCooldown: time.Second,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	claims["exp"] = clock.Now().Add(365 * 24 * time.Hour).Unix()
	tok := signToken(t, key, "kid-1", nil, claims)
	if _, err := v.VerifyToken(ctx, tok); err != nil {
		t.Fatal(err)
	}
	stub.setOutage(true)
	clock.Advance(2 * time.Hour) // cache expired, outage ongoing
	before := stub.fetches()
	for i := 0; i < 30; i++ {
		clock.Advance(10 * time.Millisecond)
		if _, err := v.VerifyToken(ctx, tok); err != nil {
			t.Fatalf("stale key must be served during outage burst: %v", err)
		}
	}
	if got := stub.fetches() - before; got > 1 {
		t.Fatalf("outage burst caused %d refresh attempts within one cooldown, want <= 1", got)
	}
}

// --- A13: post-rename durability uncertainty --------------------------------

// RED (200 acknowledged, nothing checked): a directory fsync failure after
// rename was ignored, so revocation acknowledged unproven durability.
//
// Semantics after the round-four containment fix: an uncertain revocation is
// APPLIED (memory + file, never reverted), is NOT acknowledged
// (acknowledged=false, HTTP error), still reports every affected device so
// containment callbacks fire (see the service-level regressions in
// revocation_durability_test.go), and a retry re-attempts the flush — it
// acknowledges only once the fsync succeeds.
func TestPostRenameDurabilityUncertainty(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	fs, err := NewFileStore(path, WithLimits(Limits{MaxPerAccount: -1}))
	if err != nil {
		t.Fatal(err)
	}
	if err := fs.Put(testDevice("dev-1", "google:1")); err != nil {
		t.Fatal(err)
	}
	// Install the hook after the setup Put: only mutation-time durability
	// is under test here.
	fs.dirSync = func(*os.File) error { return errors.New("boom: dir fsync failed") }

	// Failing retries never acknowledge.
	for attempt := 1; attempt <= 3; attempt++ {
		dev, _, acknowledged, err := fs.Revoke("dev-1", "google:1")
		if !errors.Is(err, ErrDurabilityUncertain) {
			t.Fatalf("attempt %d: err = %v, want ErrDurabilityUncertain", attempt, err)
		}
		if acknowledged {
			t.Fatalf("attempt %d: uncertain revocation reported as acknowledged", attempt)
		}
		// The affected device is still reported so containment can run.
		if dev.ID != "dev-1" || !dev.Revoked {
			t.Fatalf("attempt %d: affected device not reported for containment: %+v", attempt, dev)
		}
	}
	// The rename DID happen: memory must match disk (new state), never the
	// pre-mutation snapshot.
	got, err := fs.GetDevice("dev-1")
	if err != nil || !got.Revoked {
		t.Fatalf("memory must keep the applied state after rename: %+v err=%v", got, err)
	}
	onDisk := readRegistryDevices(t, path)
	if len(onDisk) != 1 || !onDisk[0].Revoked {
		t.Fatalf("disk state after post-rename failure: %+v", onDisk)
	}

	// Restored fsync: the retry flushes and only then acknowledges.
	fs.dirSync = nil
	dev, cascaded, acknowledged, err := fs.Revoke("dev-1", "google:1")
	if err != nil || !acknowledged {
		t.Fatalf("retry after flush restored: acknowledged=%v err=%v", acknowledged, err)
	}
	if dev.ID != "dev-1" {
		t.Fatalf("acknowledged device = %+v", dev)
	}
	if len(cascaded) != 0 {
		t.Fatalf("no duplicates expected, got %+v", cascaded)
	}

	// Restart sees the applied revocation; further revocations are no-ops.
	fs2, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, acknowledged2, err := fs2.Revoke("dev-1", "google:1"); err != nil || acknowledged2 {
		t.Fatalf("post-acknowledge retry: acknowledged=%v err=%v", acknowledged2, err)
	}
}

// Pre-rename failure keeps the old semantics: rollback + plain store error.
func TestPreRenameFailureRollsBack(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	fs, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	fs.Put(testDevice("dev-1", "google:1"))
	if err := os.Chmod(dir, 0o500); err != nil {
		t.Fatal(err)
	}
	defer os.Chmod(dir, 0o700) //nolint:errcheck — restore for cleanup
	err = fs.Put(testDevice("dev-2", "google:1"))
	if !errors.Is(err, ErrStoreFailure) || errors.Is(err, ErrDurabilityUncertain) {
		t.Fatalf("pre-rename failure: %v, want ErrStoreFailure", err)
	}
	if _, err := fs.GetDevice("dev-2"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatalf("pre-rename failure must roll back memory: %v", err)
	}
}

// --- C1: canonical wire contract ---------------------------------------------

// RED (no account_id field): the challenge response omitted the verified
// account, so clients could not reconstruct the enrollment payload. Nonces
// must be URL-safe and expires_at an integer.
func TestChallengeResponseExposesAccountID(t *testing.T) {
	s := newTestService(t, nil)
	resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-1"})
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("challenge = %s", resp.Status)
	}
	body, err := io.ReadAll(resp.Body)
	resp.Body.Close()
	if err != nil {
		t.Fatal(err)
	}
	var raw map[string]any
	if err := json.Unmarshal(body, &raw); err != nil {
		t.Fatal(err)
	}
	if raw["account_id"] != "google:"+subA {
		t.Fatalf("account_id = %v, want %v", raw["account_id"], "google:"+subA)
	}
	if _, ok := raw["expires_at"].(float64); !ok {
		t.Fatalf("expires_at = %T, want JSON number", raw["expires_at"])
	}
	for _, f := range []string{"nonce", "connection_nonce"} {
		s, _ := raw[f].(string)
		if s == "" || strings.ContainsAny(s, "+/=") {
			t.Fatalf("%s = %q, want URL-safe encoding", f, s)
		}
	}
	// ChallengeFromWire must reproduce the challenge and its transcript.
	var ch challengeResponse
	if err := json.Unmarshal(body, &ch); err != nil {
		t.Fatal(err)
	}
	rebuilt, err := ChallengeFromWire(ch.ChallengeID, ch.DeviceID, ch.AccountID, ch.Role, ch.Protocol, ch.Domain, ch.Nonce, ch.ConnectionNonce, ch.ExpiresAt)
	if err != nil {
		t.Fatal(err)
	}
	want, err := rebuilt.Transcript()
	if err != nil {
		t.Fatal(err)
	}
	got, err := base64.StdEncoding.DecodeString(ch.Transcript)
	if err != nil || !bytes.Equal(got, want) {
		t.Fatalf("response transcript mismatch: err=%v", err)
	}
}

// --- C1: fixed independent signing vector ------------------------------------

// Enrollment signing vector, fixed for cross-worker interoperability
// (hostagent / tunnel CLI / any future client). Anyone must be able to
// reproduce this signature byte-for-byte from the inputs via
// identity.SignEnrollment — and the obsolete bare-challenge format must be
// rejected for the same inputs. The vector is also published in
// docs/identity.md.
func TestEnrollmentSigningVector(t *testing.T) {
	seed, err := hex.DecodeString("201d9d97027b268f30ed2b9a75cf8e107984618b067c8a7721cdb7ef4adf7d0a")
	if err != nil {
		t.Fatal(err)
	}
	priv := ed25519.NewKeyFromSeed(seed)
	pub := priv.Public().(ed25519.PublicKey)
	if got := base64.StdEncoding.EncodeToString(pub); got != "fK7L9oR+0QFZhblBJ0lVKn/CclYl4DRfpxoFFABV/5A=" {
		t.Fatalf("public key mismatch: %s", got)
	}
	hostKey := "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFiXedVecTorHostKeyPublicKeyAAAA="
	ch := &Challenge{
		ID:              "vec-challenge-0001",
		AccountID:       "google:113958430858354529072",
		DeviceID:        "laptop-1",
		Role:            RoleEnroll,
		Protocol:        ProtocolIdentity,
		Domain:          "gateway.pocketshell.io",
		Nonce:           "vec-nonce-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
		ConnectionNonce: "vec-conn-BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
		ExpiresAt:       time.Unix(2000000000, 0).UTC(),
	}
	// The inner challenge transcript is pinned so wire-level reconstruction
	// via ChallengeFromWire can be cross-checked.
	tr, err := ch.Transcript()
	if err != nil {
		t.Fatal(err)
	}
	if got := base64.StdEncoding.EncodeToString(tr); got != "cG9ja2V0c2hlbGwtY2hhbGxlbmdlLXYxAAAABmVucm9sbAAAABZwb2NrZXRzaGVsbC1pZGVudGl0eS8xAAAAFmdhdGV3YXkucG9ja2V0c2hlbGwuaW8AAAAIbGFwdG9wLTEAAAAcZ29vZ2xlOjExMzk1ODQzMDg1ODM1NDUyOTA3MgAAADV2ZWMtbm9uY2UtQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQQAAADJ2ZWMtY29ubi1CQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQgAAAAoyMDAwMDAwMDAw" {
		t.Fatalf("challenge transcript mismatch: %s", got)
	}
	sig, err := SignEnrollment(priv, pub, ch, hostKey, false)
	if err != nil {
		t.Fatal(err)
	}
	if got := base64.StdEncoding.EncodeToString(sig); got != "bAOA9th0OZ3OQCY0dq6XCIVwUVwzRryqsnnVxxp8fJNNRB1OfAELhaOAtfEX0y11nojdktfr19hQwLQrXINZDw==" {
		t.Fatalf("enrollment signature mismatch: %s", got)
	}
	if err := VerifyEnrollment(pub, ch, hostKey, false, sig); err != nil {
		t.Fatalf("vector signature does not verify: %v", err)
	}
	// The obsolete format (signature over the bare challenge transcript) is
	// NOT a valid enrollment proof for the same inputs.
	if err := Verify(pub, ch, sig); err == nil {
		t.Fatal("enrollment signature accepted as a bare host-auth signature")
	}
	bare := ed25519.Sign(priv, tr)
	if err := VerifyEnrollment(pub, ch, hostKey, false, bare); !errors.Is(err, ErrProofInvalid) {
		t.Fatal("obsolete bare-challenge signature accepted as enrollment proof")
	}
	// One altered input byte invalidates the signature.
	if err := VerifyEnrollment(pub, ch, hostKey, true, sig); !errors.Is(err, ErrProofInvalid) {
		t.Fatal("mode flip accepted under vector signature")
	}
}

func TestChallengeFromWireValidation(t *testing.T) {
	type wire struct {
		challengeID, deviceID, accountID, role, protocol, domain, nonce, connNonce string
		expiresAt                                                                  int64
	}
	base := func() wire {
		return wire{
			challengeID: "challenge-id-1", deviceID: "laptop-1",
			accountID: "google:113958430858354529072", role: RoleEnroll,
			protocol: ProtocolIdentity, domain: "gateway.pocketshell.io",
			nonce: "AAAA", connNonce: "BBBB",
			expiresAt: time.Now().Add(time.Minute).Unix(),
		}
	}
	build := func(w wire) (*Challenge, error) {
		return ChallengeFromWire(w.challengeID, w.deviceID, w.accountID, w.role, w.protocol, w.domain, w.nonce, w.connNonce, w.expiresAt)
	}
	if _, err := build(base()); err != nil {
		t.Fatalf("valid wire challenge rejected: %v", err)
	}
	bad := []struct {
		name   string
		mutate func(*wire)
	}{
		{"empty challenge id", func(w *wire) { w.challengeID = "" }},
		{"bad device", func(w *wire) { w.deviceID = "../etc" }},
		{"email account", func(w *wire) { w.accountID = "alice@example.com" }},
		{"bad role", func(w *wire) { w.role = "bad role" }},
		{"zero expiry", func(w *wire) { w.expiresAt = 0 }},
		{"empty nonce", func(w *wire) { w.nonce = "" }},
	}
	for _, tc := range bad {
		t.Run(tc.name, func(t *testing.T) {
			w := base()
			tc.mutate(&w)
			if _, err := build(w); !errors.Is(err, ErrBadRequest) {
				t.Fatalf("err = %v, want ErrBadRequest", err)
			}
		})
	}
}
