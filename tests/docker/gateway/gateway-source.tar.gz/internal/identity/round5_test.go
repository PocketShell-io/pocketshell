package identity

// Round-five findings (security-review-round-three #2 inherited duplicates,
// #6 expiry-after-network-wait, plus applied-replacement containment):
// named regressions with the actual gateway read path (Store().GetDevice)
// and the real enrollment/re-enrollment HTTP flows.

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/rsa"
	"encoding/base64"
	"errors"
	"fmt"
	"net/http"
	"os"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// --- Finding 1: historical duplicate keys inherit revocation -----------------

// inheritedFixture writes a registry with revokedA (or a bare tombstone over
// the shared key) plus an ACTIVE device B carrying the same key, then opens
// it both directly and through a real Service.
type inheritedFixture struct {
	path  string
	store *FileStore
	svc   *Service
	key   []byte
}

func newInheritedFixture(t *testing.T, version int, mode string) *inheritedFixture {
	t.Helper()
	seedKey := mustKey(t) // shared registration key
	dir := t.TempDir()
	path := dir + "/devices.json"
	var (
		devices []Device
		tombs   []string
	)
	a := Device{
		ID: "dev-a", AccountID: "google:1", PublicKey: seedKey,
		SSHHostKey: testHostKey, Revoked: true,
	}
	b := Device{
		ID: "dev-b", AccountID: "google:2", PublicKey: seedKey,
		SSHHostKey: testHostKey, Revoked: false,
	}
	switch mode {
	case "v1-revoked":
		// v1 has no tombstone table; the revoked record alone must poison
		// the key.
		if version != 1 {
			t.Fatal("v1-revoked requires version 1")
		}
		devices = []Device{a, b}
	case "v2-revoked":
		devices = []Device{a, b}
	case "v2-tombstone":
		// No revoked record at all: only the explicit tombstone over B's key.
		a.Revoked = false
		devices = []Device{b}
		tombs = []string{base64.StdEncoding.EncodeToString(seedKey)}
	default:
		t.Fatalf("unknown mode %q", mode)
	}
	writeRegistryFile(t, path, version, devices, tombs)

	fs, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	s, err := NewService(Config{
		Verifier: newStubVerifier(time.Now().Add(time.Hour), map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA},
		}),
		Store:  fs,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	return &inheritedFixture{path: path, store: fs, svc: s, key: seedKey}
}

// checkInheritedRevoked asserts the actual gateway read path —
// Service.Store().GetDevice — reports B revoked, B cannot be replaced or
// reused, and the state survives a restart.
func checkInheritedRevoked(t *testing.T, f *inheritedFixture, attempt int) {
	t.Helper()
	// The gateway's actual read: tunnel authentication uses Store().GetDevice.
	got, err := f.svc.Store().GetDevice("dev-b")
	if err != nil {
		t.Fatalf("[attempt %d] gateway GetDevice: %v", attempt, err)
	}
	if !got.Revoked {
		t.Fatalf("[attempt %d] active device B with a dead key served as active: %+v", attempt, got)
	}
	// Direct store view agrees.
	if got, err = f.store.GetDevice("dev-b"); err != nil || !got.Revoked {
		t.Fatalf("[attempt %d] store GetDevice: %+v err=%v", attempt, got, err)
	}
	// List agrees.
	list, err := f.store.List("google:2")
	if err != nil || len(list) != 1 || !list[0].Revoked {
		t.Fatalf("[attempt %d] list = %+v err=%v", attempt, list, err)
	}
	// Replacement is refused: revocation is terminal.
	if _, _, err := f.store.Replace(Device{ID: "dev-b", AccountID: "google:2", PublicKey: mustNewKey(t), SSHHostKey: testHostKey}); !errors.Is(err, ErrDeviceRevoked) {
		t.Fatalf("[attempt %d] replace of inherited-revoked B: %v, want ErrDeviceRevoked", attempt, err)
	}
	// The dead key cannot come back under a new ID.
	if err := f.store.Put(Device{ID: fmt.Sprintf("dev-new-%d", attempt), AccountID: "google:9", PublicKey: f.key, SSHHostKey: testHostKey}); !errors.Is(err, ErrPublicKeyRevoked) {
		t.Fatalf("[attempt %d] dead key reused: %v", attempt, err)
	}
}

func mustNewKey(t *testing.T) ed25519.PublicKey {
	t.Helper()
	_, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	return priv.Public().(ed25519.PublicKey)
}

func TestInheritedRevocationV1RevokedActive(t *testing.T) {
	f := newInheritedFixture(t, 1, "v1-revoked")
	checkInheritedRevoked(t, f, 1)
	// Restart: derivation re-runs on load; B stays revoked.
	f2, err := f.reopen(t)
	if err != nil {
		t.Fatal(err)
	}
	checkInheritedRevoked(t, f2, 2)
}

func TestInheritedRevocationV2RevokedActive(t *testing.T) {
	f := newInheritedFixture(t, 2, "v2-revoked")
	checkInheritedRevoked(t, f, 1)
	f2, err := f.reopen(t)
	if err != nil {
		t.Fatal(err)
	}
	checkInheritedRevoked(t, f2, 2)
}

func TestInheritedRevocationV2ExplicitTombstone(t *testing.T) {
	f := newInheritedFixture(t, 2, "v2-tombstone")
	checkInheritedRevoked(t, f, 1)
	f2, err := f.reopen(t)
	if err != nil {
		t.Fatal(err)
	}
	checkInheritedRevoked(t, f2, 2)
}

// reopen simulates a gateway restart: a fresh store and service over the
// same registry file.
func (f *inheritedFixture) reopen(t *testing.T) (*inheritedFixture, error) {
	t.Helper()
	fs, err := NewFileStore(f.path)
	if err != nil {
		return nil, err
	}
	s, err := NewService(Config{
		Verifier: newStubVerifier(time.Now().Add(time.Hour), map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA},
		}),
		Store:  fs,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		return nil, err
	}
	return &inheritedFixture{path: f.path, store: fs, svc: s, key: f.key}, nil
}

// --- Finding 2: applied replacement uncertainty contains the original -------

// RED (old device contained only on success): a re-enrollment whose swap
// applied but whose fsync failed must still tear down the ORIGINAL device's
// stream, keep the new key coherent, and never return a durable-success 200
// until the flush is proven.
func TestUncertainReplacementContainment(t *testing.T) {
	dir := t.TempDir()
	path := dir + "/devices.json"
	fs, err := NewFileStore(path, WithLimits(Limits{MaxPerAccount: -1}))
	if err != nil {
		t.Fatal(err)
	}
	failSync := &atomic.Bool{}
	failSync.Store(false)
	fs.dirSync = func(*os.File) error {
		if failSync.Load() {
			return errors.New("dirsync unavailable")
		}
		return nil
	}
	oldPub, oldPriv := newKeyPair(t)
	s, err := NewService(Config{
		Verifier:                 newStubVerifier(time.Now().Add(time.Hour), map[string]Principal{tokenA: {AccountID: "google:" + subA, Email: emailA}}),
		Store:                    fs,
		AllowReenrollment:        true,
		MaxOutstandingChallenges: 32,
		Logger:                   func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	// Initial enrollment succeeds (fsync healthy).
	if resp := runEnrollment(t, s, tokenA, "laptop-1", oldPriv, testHostKey, false); resp.StatusCode != http.StatusCreated {
		t.Fatalf("initial enroll = %s", resp.Status)
	}

	var mu sync.Mutex
	contained := map[string]int{}
	live := map[string]bool{"laptop-1": true}
	s.OnRevoke(func(d Device) {
		mu.Lock()
		defer mu.Unlock()
		contained[d.ID]++
		live[d.ID] = false
	})

	// Re-enroll with a NEW key while fsync fails: applied, unproven.
	newPub, newPriv := newKeyPair(t)
	failSync.Store(true)
	resp := runEnrollment(t, s, tokenA, "laptop-1", newPriv, testHostKey, true)
	if resp.StatusCode != http.StatusInternalServerError {
		t.Fatalf("uncertain replacement = %s, want 500", resp.Status)
	}
	mu.Lock()
	if contained["laptop-1"] == 0 {
		mu.Unlock()
		t.Fatal("original device was not contained after applied replacement uncertainty")
	}
	if live["laptop-1"] {
		mu.Unlock()
		t.Fatal("old-key stream survived the replacement")
	}
	mu.Unlock()
	// The new key is the coherent current state (applied, not reverted).
	got, err := fs.GetDevice("laptop-1")
	if err != nil || !sameKey(got.PublicKey, newPub) || sameKey(got.PublicKey, oldPub) {
		t.Fatalf("post-uncertainty state incoherent: %+v err=%v", got, err)
	}

	// Retries while fsync still fails: never a durable-success 200.
	for attempt := 0; attempt < 2; attempt++ {
		if resp := runEnrollment(t, s, tokenA, "laptop-1", newPriv, testHostKey, true); resp.StatusCode != http.StatusInternalServerError {
			t.Fatalf("failing retry %d = %s, want 500", attempt, resp.Status)
		}
	}

	// Fsync restored: the flush completes and the enrollment acknowledges.
	failSync.Store(false)
	resp = runEnrollment(t, s, tokenA, "laptop-1", newPriv, testHostKey, true)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("acknowledged retry = %s, want 200", resp.Status)
	}
	// Restart: the new key is durable.
	fs2, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	got, err = fs2.GetDevice("laptop-1")
	if err != nil || !sameKey(got.PublicKey, newPub) {
		t.Fatalf("restarted state: %+v err=%v", got, err)
	}
	_ = oldPub
}

// Store-level contract: an uncertain Replace returns the pre-replacement
// record (the old key identity) and is not acknowledged.
func TestUncertainReplacementStoreContract(t *testing.T) {
	fs, err := NewFileStore(t.TempDir()+"/devices.json", WithLimits(Limits{MaxPerAccount: -1}))
	if err != nil {
		t.Fatal(err)
	}
	old := testDevice("dev-1", "google:1")
	if err := fs.Put(old); err != nil {
		t.Fatal(err)
	}
	fs.dirSync = func(*os.File) error { return errors.New("dirsync down") }
	updated := testDevice("dev-1", "google:1")
	previous, acknowledged, err := fs.Replace(updated)
	if !errors.Is(err, ErrDurabilityUncertain) || acknowledged {
		t.Fatalf("uncertain replace: acknowledged=%v err=%v", acknowledged, err)
	}
	if previous.ID != "dev-1" || !sameKey(previous.PublicKey, old.PublicKey) {
		t.Fatalf("previous = %+v, want the pre-replacement (old key) record", previous)
	}
	// Applied state is coherent: the new key is current.
	got, _ := fs.GetDevice("dev-1")
	if !sameKey(got.PublicKey, updated.PublicKey) {
		t.Fatal("applied replacement state lost")
	}
}

// --- Finding 3: expiry/cancellation rechecked after network waits -----------

// RED (expired during a blocked JWKS fetch still authorized): the token is
// valid at parse time, but the fetch is gated and the fake clock crosses
// expiry before the signature check runs. The transport signals entry into
// the blocked region (entered) so the test triggers expiry only after the
// fetch — and therefore the verification — has genuinely started; no sleeps.
func TestVerifierRejectsExpiredAfterBlockedFetch(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	gate := make(chan struct{})
	entered := make(chan struct{})
	var enteredOnce sync.Once
	var blocked atomic.Bool
	rt := roundTripperFunc(func(r *http.Request) (*http.Response, error) {
		if blocked.Load() {
			enteredOnce.Do(func() { close(entered) })
			<-gate
		}
		return jwksHTTPResponse(map[string]*rsa.PrivateKey{"kid-1": key}), nil
	})
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: rt},
		Clock:      clock.Now, Leeway: 0,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	claims["exp"] = clock.Now().Add(2 * time.Second).Unix() // short-lived
	tok := signToken(t, key, "kid-1", nil, claims)

	blocked.Store(true)
	done := make(chan error, 1)
	go func() {
		_, err := v.VerifyToken(context.Background(), tok)
		done <- err
	}()
	select {
	case <-entered: // fetch (and verification) has genuinely started
	case <-time.After(2 * time.Second):
		t.Fatal("blocked fetch never entered")
	}
	clock.Advance(30 * time.Second) // expiry passes while the fetch waits
	close(gate)                     // release the fetch
	if err := <-done; err == nil {
		t.Fatal("token that expired during the JWKS fetch was authorized")
	}
}

// A caller whose context is canceled while verification waits must never be
// authorized, even though the fetch later completes. The transport signals
// entry (entered) so cancellation is only issued after the fetch — and the
// verification — has genuinely started; no sleeps.
func TestVerifierRejectsCanceledCaller(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	gate := make(chan struct{})
	entered := make(chan struct{})
	var enteredOnce sync.Once
	var blocked atomic.Bool
	rt := roundTripperFunc(func(r *http.Request) (*http.Response, error) {
		if blocked.Load() {
			enteredOnce.Do(func() { close(entered) })
			<-gate
		}
		return jwksHTTPResponse(map[string]*rsa.PrivateKey{"kid-1": key}), nil
	})
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: rt},
		Clock:      clock.Now, Leeway: 0,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	claims["exp"] = clock.Now().Add(365 * 24 * time.Hour).Unix()
	tok := signToken(t, key, "kid-1", nil, claims)

	blocked.Store(true)
	ctx, cancel := context.WithCancel(context.Background())
	done := make(chan error, 1)
	go func() {
		_, err := v.VerifyToken(ctx, tok)
		done <- err
	}()
	select {
	case <-entered: // fetch (and verification) has genuinely started
	case <-time.After(2 * time.Second):
		t.Fatal("blocked fetch never entered")
	}
	cancel()    // caller gives up while the fetch is blocked
	close(gate) // fetch eventually completes for everyone else
	select {
	case err := <-done:
		if err == nil {
			t.Fatal("canceled caller authorized despite abandoning verification")
		}
	case <-time.After(2 * time.Second):
		t.Fatal("canceled caller not released promptly")
	}
}

// Service boundary: injected verifiers returning expired or zero-expiry
// principals must not authorize management operations; production stubs
// carry explicit positive expiry.
func TestServiceExpiryBoundary(t *testing.T) {
	now := time.Now()
	byToken := map[string]Principal{
		"expired": {AccountID: "google:" + subA, Email: emailA, ExpiresAt: now.Add(-time.Minute)},
		"zero":    {AccountID: "google:" + subA, Email: emailA},
		"valid":   {AccountID: "google:" + subA, Email: emailA, ExpiresAt: now.Add(time.Hour)},
	}
	// Direct struct construction: zero fixture expiry so the "zero"
	// principal genuinely carries zero (the production rejection case).
	s, err := NewService(Config{
		Verifier: stubVerifier{principals: byToken},
		Store:    NewMemoryStore(),
		Logger:   func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	if resp := postJSON(t, s, "/identity/v1/challenge", "expired", map[string]string{"device_id": "dev-1"}); resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("expired principal = %s, want 401", resp.Status)
	}
	if resp := postJSON(t, s, "/identity/v1/challenge", "zero", map[string]string{"device_id": "dev-1"}); resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("zero-expiry principal = %s, want 401", resp.Status)
	}
	if resp := postJSON(t, s, "/identity/v1/challenge", "valid", map[string]string{"device_id": "dev-1"}); resp.StatusCode != http.StatusOK {
		t.Fatalf("valid principal = %s, want 200", resp.Status)
	}
}
