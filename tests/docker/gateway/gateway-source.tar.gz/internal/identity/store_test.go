package identity

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"
)

func testDevice(id, account string) Device {
	pub, _, _ := ed25519.GenerateKey(rand.Reader)
	return Device{
		ID:         id,
		AccountID:  account,
		PublicKey:  pub,
		SSHHostKey: "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIExAmPlE+host+key+data== host@example",
	}
}

func TestFileStoreCRUD(t *testing.T) {
	path := filepath.Join(t.TempDir(), "registry", "devices.json")
	fs, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	dev := testDevice("dev-1", "google:123")
	if err := fs.Put(dev); err != nil {
		t.Fatal(err)
	}
	got, err := fs.GetDevice("dev-1")
	if err != nil {
		t.Fatal(err)
	}
	if got.ID != dev.ID || got.AccountID != dev.AccountID || !sameKey(got.PublicKey, dev.PublicKey) {
		t.Fatalf("roundtrip mismatch: %+v", got)
	}
	if _, err := fs.GetDevice("missing"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatalf("missing device: %v", err)
	}
	dev2 := testDevice("dev-2", "google:123")
	if err := fs.Put(dev2); err != nil {
		t.Fatal(err)
	}
	if err := fs.Put(testDevice("dev-3", "google:456")); err != nil {
		t.Fatal(err)
	}
	list, err := fs.List("google:123")
	if err != nil {
		t.Fatal(err)
	}
	if len(list) != 2 || list[0].ID != "dev-1" || list[1].ID != "dev-2" {
		t.Fatalf("list = %+v", list)
	}
	if n, _ := fs.Count("google:123"); n != 2 {
		t.Fatalf("count = %d", n)
	}
}

func TestFileStorePutRejectsDuplicateAndInvalid(t *testing.T) {
	fs, err := NewFileStore(filepath.Join(t.TempDir(), "devices.json"))
	if err != nil {
		t.Fatal(err)
	}
	if err := fs.Put(testDevice("dev-1", "google:123")); err != nil {
		t.Fatal(err)
	}
	if err := fs.Put(testDevice("dev-1", "google:123")); !errors.Is(err, ErrDeviceIDTaken) {
		t.Fatalf("duplicate put: %v", err)
	}
	bad := testDevice("dev-2", "google:123")
	bad.PublicKey = bad.PublicKey[:16]
	if err := fs.Put(bad); !errors.Is(err, ErrBadRequest) {
		t.Fatalf("short key put: %v", err)
	}
	bad = testDevice("dev-2", "google:123")
	bad.SSHHostKey = "ssh-rsa not-base64!!"
	if err := fs.Put(bad); !errors.Is(err, ErrHostKeyInvalid) {
		t.Fatalf("bad host key put: %v", err)
	}
	bad = testDevice("dev-2", "user@example.com")
	if err := fs.Put(bad); !errors.Is(err, ErrBadRequest) {
		t.Fatalf("email as account put: %v", err)
	}
}

func TestFileStoreRevokeOwnershipAndTransition(t *testing.T) {
	fs, _ := NewFileStore(filepath.Join(t.TempDir(), "devices.json"))
	fs.Put(testDevice("dev-1", "google:123"))

	if _, _, _, err := fs.Revoke("dev-1", "google:999"); !errors.Is(err, ErrOwnerMismatch) {
		t.Fatalf("cross-owner revoke: %v", err)
	}
	if _, _, _, err := fs.Revoke("missing", "google:123"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatalf("unknown revoke: %v", err)
	}
	dev, _, changed, err := fs.Revoke("dev-1", "google:123")
	if err != nil || !changed || !dev.Revoked {
		t.Fatalf("revoke: dev=%+v changed=%v err=%v", dev, changed, err)
	}
	dev, _, changed, err = fs.Revoke("dev-1", "google:123")
	if err != nil || changed || !dev.Revoked {
		t.Fatalf("second revoke must be a no-op: dev=%+v changed=%v err=%v", dev, changed, err)
	}
}

func TestFileStoreReplace(t *testing.T) {
	fs, _ := NewFileStore(filepath.Join(t.TempDir(), "devices.json"))
	old := testDevice("dev-1", "google:123")
	fs.Put(old)
	updated := testDevice("dev-1", "google:123")
	previous, acknowledged, err := fs.Replace(updated)
	if err != nil || !acknowledged {
		t.Fatalf("replace: acknowledged=%v err=%v", acknowledged, err)
	}
	if previous.ID != old.ID || !sameKey(previous.PublicKey, old.PublicKey) {
		t.Fatalf("previous record = %+v, want the pre-replacement device", previous)
	}
	got, _ := fs.GetDevice("dev-1")
	if sameKey(got.PublicKey, old.PublicKey) {
		t.Fatal("key was not replaced")
	}
	// Ownership is immutable through Replace.
	hijack := testDevice("dev-1", "google:999")
	if _, _, err := fs.Replace(hijack); !errors.Is(err, ErrOwnerMismatch) {
		t.Fatalf("owner-changing replace: %v", err)
	}
	// Unknown devices cannot be created through Replace.
	if _, _, err := fs.Replace(testDevice("dev-x", "google:123")); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatalf("replace unknown: %v", err)
	}
}

func TestFileStorePersistenceAcrossRestart(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	fs, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	dev := testDevice("dev-1", "google:123")
	fs.Put(dev)
	if _, _, _, err := fs.Revoke("dev-1", "google:123"); err != nil {
		t.Fatal(err)
	}

	reopened, err := NewFileStore(path)
	if err != nil {
		t.Fatalf("reopen: %v", err)
	}
	got, err := reopened.GetDevice("dev-1")
	if err != nil {
		t.Fatal(err)
	}
	if !got.Revoked {
		t.Fatal("revocation did not persist")
	}
	if !sameKey(got.PublicKey, dev.PublicKey) || got.SSHHostKey != dev.SSHHostKey {
		t.Fatalf("device content mismatch after restart: %+v", got)
	}
	// The file itself is well-formed JSON with a version.
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var f storeFile
	if err := json.Unmarshal(data, &f); err != nil || f.Version != storeFileVersion {
		t.Fatalf("registry file invalid: v=%d err=%v", f.Version, err)
	}
}

func TestFileStoreFailsClosedOnCorruption(t *testing.T) {
	dir := t.TempDir()
	cases := map[string]string{
		"garbage":       "definitely not json",
		"empty file":    "",
		"wrong version": `{"version":99,"devices":[]}`,
		"bad record":    `{"version":1,"devices":[{"id":"d","account_id":"google:1","public_key":"AAAA","ssh_host_key":"nope","revoked":false,"enrolled_at":"2026-01-01T00:00:00Z"}]}`,
		"duplicate":     `{"version":1,"devices":[{"id":"d","account_id":"google:1","public_key":"` + b64url(make([]byte, 32)) + `","ssh_host_key":"ssh-ed25519 AAAA","revoked":false,"enrolled_at":"2026-01-01T00:00:00Z"},{"id":"d","account_id":"google:1","public_key":"` + b64url(make([]byte, 32)) + `","ssh_host_key":"ssh-ed25519 AAAA","revoked":false,"enrolled_at":"2026-01-01T00:00:00Z"}]}`,
	}
	for name, content := range cases {
		t.Run(name, func(t *testing.T) {
			path := filepath.Join(dir, name, "devices.json")
			if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(path, []byte(content), 0o600); err != nil {
				t.Fatal(err)
			}
			if _, err := NewFileStore(path); err == nil {
				t.Fatal("corrupt registry must refuse to load")
			}
		})
	}
}

func TestFileStoreRollbackOnPersistFailure(t *testing.T) {
	dir := t.TempDir()
	fs, err := NewFileStore(filepath.Join(dir, "devices.json"))
	if err != nil {
		t.Fatal(err)
	}
	fs.Put(testDevice("dev-1", "google:123"))

	// Make the directory unwritable so the atomic rename target cannot be created.
	if err := os.Chmod(dir, 0o500); err != nil {
		t.Fatal(err)
	}
	defer os.Chmod(dir, 0o700) //nolint:errcheck — restore for cleanup

	err = fs.Put(testDevice("dev-2", "google:123"))
	if !errors.Is(err, ErrStoreFailure) {
		t.Fatalf("put on read-only dir: %v, want ErrStoreFailure", err)
	}
	if _, err := fs.GetDevice("dev-2"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatalf("failed put must roll back in-memory state: %v", err)
	}
	if _, err := fs.GetDevice("dev-1"); err != nil {
		t.Fatalf("existing device must survive failed put: %v", err)
	}
}

func TestMemoryStoreMatchesFileStoreSemantics(t *testing.T) {
	ms := NewMemoryStore()
	dev := testDevice("dev-1", "google:123")
	if err := ms.Put(dev); err != nil {
		t.Fatal(err)
	}
	if err := ms.Put(testDevice("dev-1", "google:123")); !errors.Is(err, ErrDeviceIDTaken) {
		t.Fatalf("duplicate: %v", err)
	}
	if _, _, _, err := ms.Revoke("dev-1", "google:999"); !errors.Is(err, ErrOwnerMismatch) {
		t.Fatalf("cross-owner: %v", err)
	}
	updated := testDevice("dev-1", "google:123")
	if _, _, err := ms.Replace(updated); err != nil {
		t.Fatal(err)
	}
	got, _ := ms.GetDevice("dev-1")
	if sameKey(got.PublicKey, dev.PublicKey) {
		t.Fatal("replace did not swap key")
	}
	if _, _, changed, err := ms.Revoke("dev-1", "google:123"); err != nil || !changed {
		t.Fatalf("revoke: changed=%v err=%v", changed, err)
	}
}

func TestSSHHostKeyValidation(t *testing.T) {
	good := []string{
		"ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIB1234567890abcdefghijklmnopqrstuvwxyz==",
		"ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQD1234",
		"ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTY=",
		"ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIA== user@host comment",
	}
	for _, k := range good {
		if !ValidSSHHostKey(k) {
			t.Fatalf("valid host key rejected: %q", k)
		}
	}
	bad := []string{
		"",
		"ssh-ed25519",
		"not-a-type AAAA",
		"ssh-ed25519 AAAA\nsecond-line",
		"telnet AAAA",
		"ssh-ed25519",
		"ssh-ed25519 AA=AA",
	}
	bad = append(bad, "ssh-ed25519 AAAA\x00AAAA")
	for _, k := range bad {
		if ValidSSHHostKey(k) {
			t.Fatalf("invalid host key accepted: %q", k)
		}
	}
	if ValidSSHHostKey("ssh-ed25519 " + string(make([]byte, 20000))) {
		t.Fatal("oversized host key accepted")
	}
}
