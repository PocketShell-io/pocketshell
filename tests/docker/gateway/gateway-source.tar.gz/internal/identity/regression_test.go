package identity

// Coordinator-review regression tests (Astra requirements 3/4/5/7).
//
// History: each "Test*" attack case here ran RED against the pre-fix
// implementation (2026-10-07, documented in .tmp/identity-progress.md) and
// must stay GREEN: bare-challenge enrollment signatures, altered SSH host
// keys under a valid challenge signature, resurrection of revoked devices
// via Replace, revoked keys re-enrolled under new IDs, unbounded aggregate
// challenges, and host-checking gaps on the list path were all accepted by
// the earlier code and must never be again.

import (
	"context"
	"crypto/ed25519"
	"crypto/rsa"
	"encoding/base64"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

// bareSign signs only the challenge transcript — the pre-fix enrollment
// signature format. Post-fix servers must reject it: the signature does not
// cover the registration payload.
func bareSign(t *testing.T, priv ed25519.PrivateKey, resp *http.Response) (enrollRequest, ed25519.PublicKey) {
	t.Helper()
	var ch challengeResponse
	decodeBody(t, resp, &ch)
	transcript, err := base64.StdEncoding.DecodeString(ch.Transcript)
	if err != nil {
		t.Fatal(err)
	}
	pub, privOK := priv.Public().(ed25519.PublicKey)
	if !privOK {
		t.Fatal("bad key")
	}
	_ = privOK
	return enrollRequest{
		DeviceID:    ch.DeviceID,
		PublicKey:   base64.StdEncoding.EncodeToString(pub),
		ChallengeID: ch.ChallengeID,
		Signature:   base64.StdEncoding.EncodeToString(ed25519.Sign(priv, transcript)),
	}, pub
}

// Fix 1 (Astra #3): the enrollment signature must cover the registration
// payload, not just the challenge. A bare-challenge signature must be
// rejected outright — no legacy-format fallback.
func TestEnrollRejectsBareChallengeSignature(t *testing.T) {
	s := newTestService(t, nil)
	_, priv := newKeyPair(t)

	resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-1"})
	req, _ := bareSign(t, priv, resp)
	req.SSHHostKey = testHostKey
	out := postJSON(t, s, "/identity/v1/enroll", tokenA, req)
	if out.StatusCode == http.StatusCreated {
		t.Fatal("enrollment accepted a signature that does not cover the registration payload")
	}
}

// Fix 1: signing the bare challenge and then altering the asserted SSH host
// key must not enroll — this was the coordinator's concrete attack.
func TestEnrollRejectsAlteredHostKey(t *testing.T) {
	s := newTestService(t, nil)
	_, priv := newKeyPair(t)

	resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-1"})
	req, _ := bareSign(t, priv, resp)
	req.SSHHostKey = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAADIFferent+host+key== evil"
	out := postJSON(t, s, "/identity/v1/enroll", tokenA, req)
	if out.StatusCode == http.StatusCreated {
		t.Fatal("altered ssh_host_key accepted under the same challenge signature")
	}
	if _, err := s.Store().GetDevice("dev-1"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("device was created despite invalid proof")
	}
}

// Fix 3 (Astra #5): a revoked device is terminal. Replace must refuse to
// resurrect it — the service checks Revoked outside the store, so the store
// itself must guard.
func TestReplaceAfterRevokeIsRefused(t *testing.T) {
	fs, err := NewFileStore(storePath(t))
	if err != nil {
		t.Fatal(err)
	}
	dev := testDevice("dev-1", "google:123")
	if err := fs.Put(dev); err != nil {
		t.Fatal(err)
	}
	if _, _, changed, err := fs.Revoke("dev-1", "google:123"); err != nil || !changed {
		t.Fatalf("revoke: changed=%v err=%v", changed, err)
	}
	replacement := testDevice("dev-1", "google:123") // same owner, fresh key, Revoked=false
	if _, _, err := fs.Replace(replacement); err == nil {
		t.Fatal("Replace resurrected a revoked device")
	}
	got, err := fs.GetDevice("dev-1")
	if err != nil || !got.Revoked {
		t.Fatalf("revocation not terminal: %+v err=%v", got, err)
	}
}

// Fix 4 (Astra #5): a revoked registration public key must not be enrollable
// under a new device ID. The enrollment uses a fully VALID v2 signature so
// the 403 isolates tombstone admission (the earlier draft used the obsolete
// bare-challenge signature and failed at proof verification, before the
// tombstone was ever consulted — the review called this out).
func TestRevokedKeyNotEnrollableUnderNewID(t *testing.T) {
	s := newTestService(t, nil)
	_, priv := newKeyPair(t)

	// Seed + revoke a device holding the key directly in the store.
	dev := Device{
		ID: "old-dev", AccountID: "google:" + subA,
		PublicKey: priv.Public().(ed25519.PublicKey), SSHHostKey: testHostKey,
	}
	if err := s.DeviceStore().Put(dev); err != nil {
		t.Fatal(err)
	}
	if _, _, _, err := s.DeviceStore().Revoke("old-dev", "google:"+subA); err != nil {
		t.Fatal(err)
	}

	out := runEnrollment(t, s, tokenA, "new-dev", priv, testHostKey, false)
	if out.StatusCode != http.StatusForbidden {
		t.Fatalf("revoked key under new ID with valid signature = %s, want 403", out.Status)
	}
	if _, err := s.Store().GetDevice("new-dev"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("device was created despite revoked key")
	}
}

// Fix 5 (Astra #7): the aggregate outstanding-challenge count must be
// bounded, not just the per-account count. With per-account limits raised,
// thousands of distinct accounts must still hit a global ceiling.
func TestAggregateChallengeBound(t *testing.T) {
	s := newTestService(t, func(c *Config) { c.MaxOutstandingChallenges = 100000 })
	const total = 4100 // above the default global bound of 4096
	accepted := 0
	for i := 0; i < total; i++ {
		resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-" + strconv.Itoa(i)})
		if resp.StatusCode == http.StatusTooManyRequests {
			continue
		}
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("challenge %d: unexpected status %s", i, resp.Status)
		}
		accepted++
	}
	if accepted >= total {
		t.Fatalf("no aggregate challenge bound: accepted all %d", accepted)
	}
	if accepted > 4096 {
		t.Fatalf("aggregate bound above default: %d accepted", accepted)
	}
}

// Fix 6 (Astra #4): host enforcement must be consistent on every endpoint,
// including list — not only challenge/enroll.
func TestListRejectsForeignHost(t *testing.T) {
	s := newTestService(t, func(c *Config) { c.Domain = "gateway.test" })
	req := httptest.NewRequest(http.MethodGet, "/identity/v1/devices", nil)
	req.Host = "evil.example"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	rec := httptest.NewRecorder()
	s.ServeHTTP(rec, req)
	if rec.Code != http.StatusForbidden {
		t.Fatalf("list from foreign host = %d, want 403", rec.Code)
	}
}

// Fix 6: identity = issuer+sub. A verifier returning an email or otherwise
// malformed AccountID must never reach the API surface.
func TestMalformedAccountIDRejected(t *testing.T) {
	s := newTestService(t, func(c *Config) {
		c.Verifier = newStubVerifier(time.Now().Add(time.Hour), map[string]Principal{
			"tok": {AccountID: "alice@example.com", Email: "alice@example.com"},
		})
	})
	resp := postJSON(t, s, "/identity/v1/challenge", "tok", map[string]string{"device_id": "dev-1"})
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("email-as-account challenge = %s, want 401", resp.Status)
	}
}

// Fix 6: no token material in logs, even for oversized or malformed tokens.
func TestNoTokenMaterialInLogs(t *testing.T) {
	var mu sync.Mutex
	var logs strings.Builder
	s := newTestService(t, func(c *Config) {
		c.Logger = func(format string, args ...any) {
			mu.Lock()
			defer mu.Unlock()
			logs.WriteString(fmt.Sprintf(format, args...))
		}
	})
	marker := "SECRETTOKENMARKER"
	postJSON(t, s, "/identity/v1/challenge", "not-a-token-"+marker, map[string]string{"device_id": "dev-1"})
	postJSON(t, s, "/identity/v1/challenge", strings.Repeat(marker, 1000), map[string]string{"device_id": "dev-1"})
	getJSON(t, s, "/identity/v1/devices", "Bearer-garbage-"+marker)
	mu.Lock()
	defer mu.Unlock()
	if strings.Contains(logs.String(), marker) {
		t.Fatal("token material leaked into logs")
	}
}

// Fix 5: unknown-kid lookups must not storm the JWKS endpoint; refreshes are
// cooldown-bounded regardless of how many distinct unknown kids arrive.
func TestUnknownKidRefreshBounded(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: jw.srv.URL,
		Allowlist: []string{"user@example.com"}, Clock: clock.Now,
		RefreshCooldown: time.Second, Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	// Warm the cache with the real kid.
	if _, err := v.VerifyToken(ctx, signToken(t, key, "kid-1", nil, claims)); err != nil {
		t.Fatal(err)
	}
	before := jw.Fetches()
	// Burst of distinct unknown kids inside one cooldown window.
	for i := 0; i < 50; i++ {
		clock.Advance(10 * time.Millisecond)
		if _, err := v.VerifyToken(ctx, signToken(t, key, "unknown-kid-"+strconv.Itoa(i), nil, claims)); err == nil {
			t.Fatal("unknown kid accepted")
		}
	}
	if got := jw.Fetches() - before; got > 1 {
		t.Fatalf("unknown-kid burst caused %d JWKS fetches within cooldown, want <= 1", got)
	}
}

func storePath(t *testing.T) string {
	t.Helper()
	return filepath.Join(t.TempDir(), "devices.json")
}
