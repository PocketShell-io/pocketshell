package identity

import (
	"context"
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"math/big"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// --- test scaffolding -------------------------------------------------------

type fakeClock struct {
	mu sync.Mutex
	t  time.Time
}

func newFakeClock() *fakeClock { return &fakeClock{t: time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)} }

func (c *fakeClock) Now() time.Time {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.t
}

func (c *fakeClock) Advance(d time.Duration) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.t = c.t.Add(d)
}

// jwksServer serves a mutable set of RSA signing keys in JWKS form.
type jwksServer struct {
	mu      sync.Mutex
	fetches atomic.Int64
	keys    map[string]*rsa.PrivateKey
	srv     *httptest.Server
}

func newJWKSServer(t *testing.T, keys map[string]*rsa.PrivateKey) *jwksServer {
	t.Helper()
	j := &jwksServer{keys: keys}
	j.srv = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		j.fetches.Add(1)
		j.mu.Lock()
		defer j.mu.Unlock()
		type k struct {
			Kid string `json:"kid"`
			N   string `json:"n"`
			E   string `json:"e"`
		}
		set := struct {
			Keys []k `json:"keys"`
		}{}
		for kid, key := range j.keys {
			e := new(big.Int).SetInt64(int64(key.E))
			set.Keys = append(set.Keys, k{
				Kid: kid,
				N:   base64.RawURLEncoding.EncodeToString(key.N.Bytes()),
				E:   base64.RawURLEncoding.EncodeToString(e.Bytes()),
			})
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(set)
	}))
	t.Cleanup(j.srv.Close)
	return j
}

func (j *jwksServer) setKeys(keys map[string]*rsa.PrivateKey) {
	j.mu.Lock()
	defer j.mu.Unlock()
	j.keys = keys
}

// Fetches reports how many times the JWKS endpoint was queried.
func (j *jwksServer) Fetches() int64 { return j.fetches.Load() }

func b64url(b []byte) string { return base64.RawURLEncoding.EncodeToString(b) }

func signToken(t *testing.T, key *rsa.PrivateKey, kid string, header map[string]any, claims map[string]any) string {
	t.Helper()
	if header == nil {
		header = map[string]any{"alg": "RS256", "kid": kid}
	}
	hb, err := json.Marshal(header)
	if err != nil {
		t.Fatal(err)
	}
	cb, err := json.Marshal(claims)
	if err != nil {
		t.Fatal(err)
	}
	signingInput := b64url(hb) + "." + b64url(cb)
	digest := sha256.Sum256([]byte(signingInput))
	sig, err := rsa.SignPKCS1v15(rand.Reader, key, crypto.SHA256, digest[:])
	if err != nil {
		t.Fatal(err)
	}
	return signingInput + "." + b64url(sig)
}

func baseClaims(clock *fakeClock, sub, email string) map[string]any {
	now := clock.Now().Unix()
	return map[string]any{
		"iss":            "https://accounts.google.com",
		"aud":            "test-client-id",
		"exp":            now + 3600,
		"iat":            now,
		"sub":            sub,
		"email":          email,
		"email_verified": true,
	}
}

func newTestVerifier(t *testing.T, jw *jwksServer, clock *fakeClock, allowlist []string) *GoogleVerifier {
	t.Helper()
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID:        "test-client-id",
		JWKSURL:         jw.srv.URL,
		Allowlist:       allowlist,
		Clock:           clock.Now,
		RefreshCooldown: time.Second,
		Logger:          func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	return v
}

func mustRSA(t *testing.T) *rsa.PrivateKey {
	t.Helper()
	key, err := rsa.GenerateKey(rand.Reader, 2048)
	if err != nil {
		t.Fatal(err)
	}
	return key
}

// --- tests ------------------------------------------------------------------

func TestGoogleVerifierValidToken(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v := newTestVerifier(t, jw, clock, []string{"User@Example.com"})

	token := signToken(t, key, "kid-1", nil, baseClaims(clock, "113958430858354529072", "user@example.com"))
	p, err := v.VerifyToken(context.Background(), token)
	if err != nil {
		t.Fatalf("valid token rejected: %v", err)
	}
	if p.AccountID != "google:113958430858354529072" {
		t.Fatalf("AccountID = %q, want google:<sub>", p.AccountID)
	}
	if p.Email != "user@example.com" {
		t.Fatalf("Email = %q, want lowercased email", p.Email)
	}
}

func TestGoogleVerifierAccountIDIsIssuerSubNotEmail(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v := newTestVerifier(t, jw, clock, []string{"a@example.com", "b@example.com"})

	sub := "113958430858354529072"
	p1, err1 := v.VerifyToken(context.Background(), signToken(t, key, "kid-1", nil, baseClaims(clock, sub, "a@example.com")))
	p2, err2 := v.VerifyToken(context.Background(), signToken(t, key, "kid-1", nil, baseClaims(clock, sub, "b@example.com")))
	if err1 != nil || err2 != nil {
		t.Fatalf("verify: %v %v", err1, err2)
	}
	// The stable identity survives an email change; the email never defines it.
	if p1.AccountID != p2.AccountID {
		t.Fatalf("AccountID changed with email: %q vs %q", p1.AccountID, p2.AccountID)
	}
}

func TestGoogleVerifierClaimFailures(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v := newTestVerifier(t, jw, clock, []string{"user@example.com"})

	cases := []struct {
		name   string
		header map[string]any
		mutate func(map[string]any)
	}{
		{"wrong aud", nil, func(c map[string]any) { c["aud"] = "other-client" }},
		{"wrong iss", nil, func(c map[string]any) { c["iss"] = "https://evil.example" }},
		{"expired", nil, func(c map[string]any) { c["exp"] = clock.Now().Unix() - 3600 }},
		{"missing exp", nil, func(c map[string]any) { delete(c, "exp") }},
		{"iat in future", nil, func(c map[string]any) { c["iat"] = clock.Now().Unix() + 3600 }},
		{"email unverified", nil, func(c map[string]any) { c["email_verified"] = false }},
		{"missing sub", nil, func(c map[string]any) { delete(c, "sub") }},
		{"empty sub", nil, func(c map[string]any) { c["sub"] = "" }},
		{"missing email", nil, func(c map[string]any) { delete(c, "email") }},
		{"alg none", map[string]any{"alg": "none", "kid": "kid-1"}, nil},
		{"alg hs256", map[string]any{"alg": "HS256", "kid": "kid-1"}, nil},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			claims := baseClaims(clock, "113958430858354529072", "user@example.com")
			if tc.mutate != nil {
				tc.mutate(claims)
			}
			token := signToken(t, key, "kid-1", tc.header, claims)
			if _, err := v.VerifyToken(context.Background(), token); err == nil {
				t.Fatal("expected rejection")
			}
		})
	}
}

func TestGoogleVerifierAllowlist(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v := newTestVerifier(t, jw, clock, []string{"user@example.com"})

	token := signToken(t, key, "kid-1", nil, baseClaims(clock, "113958430858354529072", "attacker@evil.example"))
	if _, err := v.VerifyToken(context.Background(), token); err == nil {
		t.Fatal("non-allowlisted email must be rejected")
	}

	// Rollout semantics: an empty allowlist denies everyone.
	empty, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: jw.srv.URL,
		Clock: clock.Now, Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	token = signToken(t, key, "kid-1", nil, baseClaims(clock, "113958430858354529072", "user@example.com"))
	if _, err := empty.VerifyToken(context.Background(), token); err == nil {
		t.Fatal("empty allowlist must deny all")
	}
}

func TestGoogleVerifierBadSignature(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	other := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v := newTestVerifier(t, jw, clock, []string{"user@example.com"})

	token := signToken(t, other, "kid-1", nil, baseClaims(clock, "113958430858354529072", "user@example.com"))
	if _, err := v.VerifyToken(context.Background(), token); err == nil {
		t.Fatal("signature from an untrusted key must be rejected")
	}
}

func TestGoogleVerifierKeyRotation(t *testing.T) {
	clock := newFakeClock()
	key1, key2 := mustRSA(t), mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key1})
	v := newTestVerifier(t, jw, clock, []string{"user@example.com"})

	tok1 := signToken(t, key1, "kid-1", nil, baseClaims(clock, "113958430858354529072", "user@example.com"))
	if _, err := v.VerifyToken(context.Background(), tok1); err != nil {
		t.Fatalf("kid-1 token: %v", err)
	}
	// Google rotates: the new kid is unknown until a refresh.
	jw.setKeys(map[string]*rsa.PrivateKey{"kid-2": key2})
	clock.Advance(2 * time.Second) // past RefreshCooldown, inside CacheTTL
	tok2 := signToken(t, key2, "kid-2", nil, baseClaims(clock, "113958430858354529072", "user@example.com"))
	if _, err := v.VerifyToken(context.Background(), tok2); err != nil {
		t.Fatalf("kid-2 token after rotation: %v", err)
	}
}

func TestGoogleVerifierMalformedTokens(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v := newTestVerifier(t, jw, clock, []string{"user@example.com"})

	good := signToken(t, key, "kid-1", nil, baseClaims(clock, "113958430858354529072", "user@example.com"))
	cases := map[string]string{
		"empty":        "",
		"no dots":      "garbage",
		"two parts":    "a.b",
		"bad b64":      "!!!.!!!.!!!",
		"truncated":    good[:len(good)-10],
		"oversized":    "x" + strings.Repeat("y", 9000),
		"tampered":     good[:len(good)-4] + "AAAA",
		"padding junk": good + ".junk",
	}
	for name, token := range cases {
		t.Run(name, func(t *testing.T) {
			if _, err := v.VerifyToken(context.Background(), token); err == nil {
				t.Fatal("expected rejection")
			}
		})
	}
}

func TestGoogleVerifierErrorsAreSentinelWrapped(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v := newTestVerifier(t, jw, clock, []string{"user@example.com"})
	_, err := v.VerifyToken(context.Background(), "garbage")
	if !errors.Is(err, ErrUnauthorized) {
		t.Fatalf("error = %v, want ErrUnauthorized wrap", err)
	}
}
