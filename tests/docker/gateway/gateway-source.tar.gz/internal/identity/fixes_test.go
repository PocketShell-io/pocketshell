package identity

// Post-fix contract tests for the coordinator review fixes. Each test maps
// to a fix; the companion attack regressions live in regression_test.go.

import (
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/rsa"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// --- Fix 1: enrollment signatures cover the full payload --------------------

func TestEnrollmentTranscriptBindsPayload(t *testing.T) {
	clock := newFakeClock()
	ch := testChallenge(clock)
	pub, priv, _ := ed25519.GenerateKey(rand.Reader)

	sig, err := SignEnrollment(priv, pub, ch, testHostKey, false)
	if err != nil {
		t.Fatal(err)
	}
	if err := VerifyEnrollment(pub, ch, testHostKey, false, sig); err != nil {
		t.Fatalf("valid enrollment signature rejected: %v", err)
	}
	// Every payload dimension is inside the signature: altering the SSH host
	// key, the mode, the key, or any challenge binding must fail.
	otherPub, _, _ := ed25519.GenerateKey(rand.Reader)
	cases := []struct {
		name     string
		pub      ed25519.PublicKey
		hostKey  string
		reenroll bool
	}{
		{"altered host key", pub, "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAADIFferent+host+key==", false},
		{"flipped reenroll mode", pub, testHostKey, true},
		{"different key", otherPub, testHostKey, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if err := VerifyEnrollment(tc.pub, ch, tc.hostKey, tc.reenroll, sig); !errors.Is(err, ErrProofInvalid) {
				t.Fatalf("err = %v, want ErrProofInvalid", err)
			}
		})
	}
	// Challenge bindings are covered via the embedded challenge transcript.
	otherCh := testChallenge(clock)
	otherCh.Nonce = "different"
	if err := VerifyEnrollment(pub, otherCh, testHostKey, false, sig); !errors.Is(err, ErrProofInvalid) {
		t.Fatal("signature accepted under a different challenge")
	}
	// Bare challenge signature (old format) must not verify as enrollment.
	bare := ed25519.Sign(priv, mustTranscript(t, ch))
	if err := VerifyEnrollment(pub, ch, testHostKey, false, bare); !errors.Is(err, ErrProofInvalid) {
		t.Fatal("bare challenge signature accepted as enrollment proof")
	}
	// SignEnrollment refuses to sign a payload whose key mismatches the
	// signer (client-bug guard).
	if _, err := SignEnrollment(priv, otherPub, ch, testHostKey, false); !errors.Is(err, ErrBadRequest) {
		t.Fatalf("mismatched key signing: %v, want ErrBadRequest", err)
	}
}

func TestEnrollAlteredPayloadAfterSigning(t *testing.T) {
	s := newTestService(t, nil)
	_, priv := newKeyPair(t)
	pub := priv.Public().(ed25519.PublicKey)

	// Each case signs an honest payload under a FRESH challenge, then
	// submits one altered field. (The earlier draft reused one challenge for
	// both cases; the second rejection was then replay rejection, not mode
	// binding — exactly the misleading regression the review flagged.)
	cases := []struct {
		name     string
		hostKey  string
		reenroll bool
	}{
		{"altered host key", "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAADIFferent+host+key==", false},
		{"flipped re-enroll mode", testHostKey, true},
	}
	for i, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			deviceID := fmt.Sprintf("dev-%d", i)
			resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": deviceID})
			if resp.StatusCode != http.StatusOK {
				t.Fatalf("challenge = %s", resp.Status)
			}
			var ch challengeResponse
			decodeBody(t, resp, &ch)
			rebuilt := &Challenge{
				ID: ch.ChallengeID, DeviceID: ch.DeviceID, Role: ch.Role, Protocol: ch.Protocol,
				Domain: ch.Domain, Nonce: ch.Nonce, ConnectionNonce: ch.ConnectionNonce,
				ExpiresAt: time.Unix(ch.ExpiresAt, 0).UTC(), AccountID: accountIDForToken(tokenA),
			}
			// ChallengeFromWire must agree with the manual reconstruction.
			fromWire, err := ChallengeFromWire(ch.ChallengeID, ch.DeviceID, ch.AccountID, ch.Role, ch.Protocol, ch.Domain, ch.Nonce, ch.ConnectionNonce, ch.ExpiresAt)
			if err != nil {
				t.Fatal(err)
			}
			wireBytes, err := fromWire.Transcript()
			if err != nil {
				t.Fatal(err)
			}
			rebuiltBytes, err := rebuilt.Transcript()
			if err != nil || !bytes.Equal(wireBytes, rebuiltBytes) {
				t.Fatalf("wire reconstruction mismatch: err=%v", err)
			}
			sig, err := SignEnrollment(priv, pub, rebuilt, testHostKey, false)
			if err != nil {
				t.Fatal(err)
			}
			out := postJSON(t, s, "/identity/v1/enroll", tokenA, enrollRequest{
				DeviceID: deviceID, PublicKey: base64.StdEncoding.EncodeToString(pub),
				SSHHostKey: tc.hostKey, ChallengeID: ch.ChallengeID,
				Signature: base64.StdEncoding.EncodeToString(sig),
				Reenroll:  tc.reenroll,
			})
			if out.StatusCode != http.StatusUnauthorized {
				t.Fatalf("%s = %s, want 401", tc.name, out.Status)
			}
		})
	}
	if _, err := s.Store().GetDevice("dev-0"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("device created despite altered payload")
	}
	if _, err := s.Store().GetDevice("dev-1"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("device created despite altered mode")
	}
}

// --- Fix 2: atomic per-account quota ----------------------------------------

func TestStorePerAccountLimitAtomic(t *testing.T) {
	fs, err := NewFileStore(storePath(t), WithLimits(Limits{MaxPerAccount: 1}))
	if err != nil {
		t.Fatal(err)
	}
	if err := fs.Put(testDevice("dev-1", "google:1")); err != nil {
		t.Fatal(err)
	}
	// Sequential: second device for the same account refused by the store.
	if err := fs.Put(testDevice("dev-2", "google:1")); !errors.Is(err, ErrAccountQuotaExceeded) {
		t.Fatalf("second device: %v, want ErrAccountQuotaExceeded", err)
	}
	// Other accounts unaffected; Replace never consumes quota.
	if err := fs.Put(testDevice("dev-3", "google:2")); err != nil {
		t.Fatal(err)
	}
	replaced := testDevice("dev-1", "google:1")
	if _, ack, err := fs.Replace(replaced); err != nil || !ack {
		t.Fatalf("replace must not consume quota: acknowledged=%v err=%v", ack, err)
	}

	// Concurrent: exactly one enrollment of a fresh account wins, the rest
	// are refused — no count-then-put race.
	const n = 24
	var wg sync.WaitGroup
	var accepted atomic.Int64
	quotaErrs := make(chan error, n)
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			err := fs.Put(testDevice(fmt.Sprintf("race-%d", i), "google:race"))
			if err == nil {
				accepted.Add(1)
			} else {
				quotaErrs <- err
			}
		}(i)
	}
	wg.Wait()
	close(quotaErrs)
	if got := accepted.Load(); got != 1 {
		t.Fatalf("accepted %d of %d concurrent devices at limit 1, want exactly 1", got, n)
	}
	for err := range quotaErrs {
		if !errors.Is(err, ErrAccountQuotaExceeded) {
			t.Fatalf("concurrent put error: %v", err)
		}
	}
}

// Deterministic end-to-end twin via the HTTP API: with MaxDevicesPerAccount
// set to 1, concurrent client enrollments produce exactly one 201.
func TestConcurrentEnrollExactOneAccepted(t *testing.T) {
	s := newTestService(t, func(c *Config) { c.MaxDevicesPerAccount = 1 })
	srv := httptest.NewServer(s)
	t.Cleanup(srv.Close)

	const n = 16
	release := make(chan struct{})
	var linedUp sync.WaitGroup
	linedUp.Add(n)
	results := make(chan int, n)
	for i := 0; i < n; i++ {
		go func(i int) {
			linedUp.Done() // lined up; now block on the common start signal
			<-release      // the release channel IS awaited (review fix)
			_, priv, err := ed25519.GenerateKey(rand.Reader)
			if err != nil {
				t.Error(err)
				results <- 0
				return
			}
			resp := runEnrollmentAt(t, srv.URL, tokenA, fmt.Sprintf("dev-%d", i), priv, testHostKey, false)
			results <- resp.StatusCode
		}(i)
	}
	linedUp.Wait()
	close(release) // everyone is connected; start the race

	accepted := 0
	denied := 0
	for i := 0; i < n; i++ {
		switch status := <-results; status {
		case http.StatusCreated:
			accepted++
		case http.StatusForbidden:
			denied++
		default:
			t.Fatalf("unexpected status %d during quota race", status)
		}
	}
	if accepted != 1 {
		t.Fatalf("accepted %d enrollments at limit 1, want exactly 1", accepted)
	}
	if denied != n-1 {
		t.Fatalf("denied %d, want %d", denied, n-1)
	}
}

var srvClient = &http.Client{Timeout: 10 * time.Second}

// runEnrollmentAt talks to a real HTTP server (network peer of the recorder
// helpers in service_test.go).
func runEnrollmentAt(t *testing.T, baseURL, token, deviceID string, priv ed25519.PrivateKey, hostKey string, reenroll bool) *http.Response {
	t.Helper()
	resp := postAt(t, srvClient, baseURL, "/identity/v1/challenge", token, map[string]string{"device_id": deviceID})
	if resp.StatusCode != http.StatusOK {
		return resp
	}
	var ch challengeResponse
	decodeBody(t, resp, &ch)
	rebuilt := &Challenge{
		ID: ch.ChallengeID, DeviceID: ch.DeviceID, Role: ch.Role, Protocol: ch.Protocol,
		Domain: ch.Domain, Nonce: ch.Nonce, ConnectionNonce: ch.ConnectionNonce,
		ExpiresAt: time.Unix(ch.ExpiresAt, 0).UTC(), AccountID: accountIDForToken(token),
	}
	sig, err := SignEnrollment(priv, priv.Public().(ed25519.PublicKey), rebuilt, hostKey, reenroll)
	if err != nil {
		t.Fatal(err)
	}
	return postAt(t, srvClient, baseURL, "/identity/v1/enroll", token, enrollRequest{
		DeviceID:    deviceID,
		PublicKey:   base64.StdEncoding.EncodeToString(priv.Public().(ed25519.PublicKey)),
		SSHHostKey:  hostKey,
		ChallengeID: ch.ChallengeID,
		Signature:   base64.StdEncoding.EncodeToString(sig),
		Reenroll:    reenroll,
	})
}

func postAt(t *testing.T, c *http.Client, baseURL, path, token string, body any) *http.Response {
	t.Helper()
	raw, err := json.Marshal(body)
	if err != nil {
		t.Fatal(err)
	}
	req, err := http.NewRequest(http.MethodPost, baseURL+path, bytes.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Authorization", "Bearer "+token)
	req.Header.Set("Content-Type", "application/json")
	resp, err := c.Do(req)
	if err != nil {
		t.Fatalf("POST %s: %v", path, err)
	}
	return resp
}

// --- Fix 3: revocation is terminal under replace/revoke races ---------------

func TestRevokeReplaceRaceKeepsRevocationTerminal(t *testing.T) {
	for round := 0; round < 50; round++ {
		fs, err := NewFileStore(storePath(t), WithLimits(Limits{MaxPerAccount: 0}))
		if err != nil {
			t.Fatal(err)
		}
		dev := testDevice("dev-1", "google:1")
		if err := fs.Put(dev); err != nil {
			t.Fatal(err)
		}
		var wg sync.WaitGroup
		replaceErr := make(chan error, 1)
		revokeErr := make(chan error, 1)
		wg.Add(2)
		go func() {
			defer wg.Done()
			for i := 0; i < 20; i++ {
				if _, _, err := fs.Replace(testDevice("dev-1", "google:1")); err != nil {
					if errors.Is(err, ErrDeviceRevoked) {
						replaceErr <- err
						return
					}
					replaceErr <- err
					return
				}
			}
			replaceErr <- nil
		}()
		go func() {
			defer wg.Done()
			for i := 0; i < 20; i++ {
				_, _, _, err := fs.Revoke("dev-1", "google:1")
				revokeErr <- err
				return // one revoke decides the round
			}
		}()
		wg.Wait()
		revErr := <-revokeErr
		repErr := <-replaceErr
		if revErr != nil {
			t.Fatalf("round %d: revoke: %v", round, revErr)
		}
		if repErr != nil && !errors.Is(repErr, ErrDeviceRevoked) {
			t.Fatalf("round %d: replace: %v", round, repErr)
		}
		got, err := fs.GetDevice("dev-1")
		if err != nil {
			t.Fatalf("round %d: get: %v", round, err)
		}
		// Invariant: once revoke ran, the device is and stays revoked —
		// no interleaving may resurrect it.
		if !got.Revoked {
			t.Fatalf("round %d: device not revoked after revoke+replace race: %+v", round, got)
		}
	}
}

// --- Fix 4: durable revoked-key tombstones ----------------------------------

func TestRevokedKeyTombstoneSurvivesRestartAndBlocksAllIDs(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	fs, err := NewFileStore(path)
	if err != nil {
		t.Fatal(err)
	}
	_, priv := newKeyPair(t)
	key := priv.Public().(ed25519.PublicKey)
	victim := Device{ID: "dev-1", AccountID: "google:1", PublicKey: key, SSHHostKey: testHostKey}
	if err := fs.Put(victim); err != nil {
		t.Fatal(err)
	}
	if _, _, changed, err := fs.Revoke("dev-1", "google:1"); err != nil || !changed {
		t.Fatalf("revoke: changed=%v err=%v", changed, err)
	}

	// Tombstone applies to new IDs, other accounts included.
	fs2, err := NewFileStore(path) // restart: tombstones must be durable
	if err != nil {
		t.Fatal(err)
	}
	if err := fs2.Put(Device{ID: "dev-2", AccountID: "google:1", PublicKey: key, SSHHostKey: testHostKey}); !errors.Is(err, ErrPublicKeyRevoked) {
		t.Fatalf("same account new ID: %v, want ErrPublicKeyRevoked", err)
	}
	if err := fs2.Put(Device{ID: "dev-3", AccountID: "google:2", PublicKey: key, SSHHostKey: testHostKey}); !errors.Is(err, ErrPublicKeyRevoked) {
		t.Fatalf("other account new ID: %v, want ErrPublicKeyRevoked", err)
	}
	// A genuinely new key enrolls fine.
	_, priv2 := newKeyPair(t)
	if err := fs2.Put(Device{ID: "dev-4", AccountID: "google:2", PublicKey: priv2.Public().(ed25519.PublicKey), SSHHostKey: testHostKey}); err != nil {
		t.Fatalf("fresh key rejected: %v", err)
	}

	// Service level: exact 403 with the documented message path.
	s := newTestService(t, func(c *Config) { c.StorePath = path })
	resp := runEnrollment(t, s, tokenA, "dev-5", priv, testHostKey, false)
	if resp.StatusCode != http.StatusForbidden {
		t.Fatalf("service enroll with revoked key = %s, want 403", resp.Status)
	}
}

// --- Fix 5: token expiry is exposed ------------------------------------------

func TestPrincipalExpiresAtExposed(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	jw := newJWKSServer(t, map[string]*rsa.PrivateKey{"kid-1": key})
	v := newTestVerifier(t, jw, clock, []string{"user@example.com"})
	p, err := v.VerifyToken(t.Context(), signToken(t, key, "kid-1", nil, baseClaims(clock, "113958430858354529072", "user@example.com")))
	if err != nil {
		t.Fatal(err)
	}
	want := clock.Now().Add(time.Hour).Truncate(time.Second).UTC()
	if p.ExpiresAt.IsZero() {
		t.Fatal("ExpiresAt not exposed")
	}
	if !p.ExpiresAt.Equal(want) {
		t.Fatalf("ExpiresAt = %v, want %v", p.ExpiresAt, want)
	}
}

// --- helpers -----------------------------------------------------------------

func mustTranscript(t *testing.T, ch *Challenge) []byte {
	t.Helper()
	b, err := ch.Transcript()
	if err != nil {
		t.Fatal(err)
	}
	return b
}
