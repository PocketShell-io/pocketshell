package identity

// Round-four revocation-durability regressions (blocking Astra finding):
// a post-rename-applied revocation with a failing directory fsync must
// trigger containment (OnRevoke) for EVERY affected device immediately —
// containment is not a durability ACK — while the HTTP layer keeps
// returning errors; retries re-attempt the flush and cannot return 200
// while durability remains uncertain; a restored fsync acknowledges only
// after the flush; and the persisted/reloaded state remains revoked.
//
// The OnRevoke callback registry doubles as the active-stream substitute:
// each registered callback tears down a simulated live stream, mirroring
// what the tunnel worker does for real SSH streams (root/tunnel verify
// actual live-stream teardown in integration).

import (
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// durabilityFixture seeds a registry with a device and a same-key duplicate
// (simulating legacy data), opens it with a toggleable dirsync failure hook,
// and serves it through a real identity Service with callback accounting.
type durabilityFixture struct {
	t         *testing.T
	path      string
	store     *FileStore
	service   *Service
	server    *httptest.Server
	failSync  *atomic.Bool
	mu        sync.Mutex
	callbacks []string          // every OnRevoke invocation, in order
	live      map[string]bool   // active-stream substitute: device -> connected
	revokedAt map[string]string // which callback event revoked which stream
}

func newDurabilityFixture(t *testing.T) *durabilityFixture {
	t.Helper()
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	key := mustKey(t)
	// One account device and a legacy duplicate sharing the same key on a
	// second account: revoking either must contain both.
	writeRegistryFile(t, path, 2, []Device{
		{ID: "dev-target", AccountID: "google:" + subA, PublicKey: key, SSHHostKey: testHostKey},
		{ID: "dev-duplicate", AccountID: "google:" + subB, PublicKey: key, SSHHostKey: testHostKey},
	}, nil)

	fs, err := NewFileStore(path, WithLimits(Limits{MaxPerAccount: -1}))
	if err != nil {
		t.Fatal(err)
	}
	failSync := &atomic.Bool{}
	failSync.Store(true) // dirsync fails until the test restores it
	fs.dirSync = func(*os.File) error {
		if failSync.Load() {
			return errors.New("dirsync unavailable")
		}
		return nil
	}

	f := &durabilityFixture{
		t:         t,
		path:      path,
		store:     fs,
		failSync:  failSync,
		live:      map[string]bool{"dev-target": true, "dev-duplicate": true},
		revokedAt: map[string]string{},
	}
	s, err := NewService(Config{
		Verifier: newStubVerifier(time.Now().Add(time.Hour), map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA},
			tokenB: {AccountID: "google:" + subB, Email: emailB},
		}),
		Store:  fs,
		Domain: "gateway.test",
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	f.service = s
	s.OnRevoke(func(d Device) {
		f.mu.Lock()
		defer f.mu.Unlock()
		f.callbacks = append(f.callbacks, d.ID)
		// Active-stream substitute: the tunnel worker tears the SSH stream
		// down inside this callback.
		f.live[d.ID] = false
		f.revokedAt[d.ID] = d.ID
	})
	f.server = httptest.NewServer(s)
	t.Cleanup(f.server.Close)
	return f
}

// revoke issues an authenticated revoke over real HTTP and returns the
// status code.
func (f *durabilityFixture) revoke(token, deviceID string) int {
	f.t.Helper()
	resp := postJSON(f.t, f.service, "/identity/v1/devices/"+deviceID+"/revoke", token, nil)
	defer resp.Body.Close()
	return resp.StatusCode
}

func (f *durabilityFixture) callbackCount() int {
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.callbacks)
}

func (f *durabilityFixture) callbackIDs() map[string]int {
	f.mu.Lock()
	defer f.mu.Unlock()
	out := map[string]int{}
	for _, id := range f.callbacks {
		out[id]++
	}
	return out
}

func (f *durabilityFixture) liveStreams() map[string]bool {
	f.mu.Lock()
	defer f.mu.Unlock()
	out := map[string]bool{}
	for id, up := range f.live {
		out[id] = up
	}
	return out
}

// RED (callbacks suppressed on the failing attempt): a revocation whose
// directory fsync fails after the rename must still fire OnRevoke for the
// target AND every cascaded duplicate immediately, while HTTP returns an
// error.
func TestUncertainRevocationContainmentCallbacks(t *testing.T) {
	f := newDurabilityFixture(t)

	status := f.revoke(tokenA, "dev-target")
	if status != http.StatusInternalServerError {
		t.Fatalf("uncertain revocation status = %d, want 500", status)
	}
	// Containment happened despite the error: both affected devices.
	ids := f.callbackIDs()
	if ids["dev-target"] != 1 || ids["dev-duplicate"] != 1 {
		t.Fatalf("containment callbacks = %v, want exactly dev-target and dev-duplicate once each", ids)
	}
	// Active-stream substitute: no live stream survives for affected devices.
	live := f.liveStreams()
	if live["dev-target"] || live["dev-duplicate"] {
		t.Fatalf("streams survived uncertain revocation: %v", live)
	}
	// The applied state is visible and the key is dead for new IDs.
	got, err := f.store.GetDevice("dev-target")
	if err != nil || !got.Revoked {
		t.Fatalf("target not revoked: %+v err=%v", got, err)
	}
	if got, err = f.store.GetDevice("dev-duplicate"); err != nil || !got.Revoked {
		t.Fatalf("duplicate not revoked: %+v err=%v", got, err)
	}
}

// RED (false 200 on retry): while durability stays uncertain, repeated
// retries keep failing and never acknowledge.
func TestUncertainRevocationRetryNeverAcknowledges(t *testing.T) {
	f := newDurabilityFixture(t)

	for attempt := 1; attempt <= 3; attempt++ {
		if status := f.revoke(tokenA, "dev-target"); status != http.StatusInternalServerError {
			t.Fatalf("attempt %d: status = %d, want 500 (no 200 while durability is uncertain)", attempt, status)
		}
	}
	if got := f.callbackCount(); got < 2 {
		t.Fatalf("containment callbacks lost across retries: %d", got)
	}
}

// Restored fsync: the retry performs the flush and acknowledges only after
// it succeeds; containment re-runs alongside the acknowledgment (callbacks
// are idempotent teardowns).
func TestUncertainRevocationAcknowledgedAfterFlushRestored(t *testing.T) {
	f := newDurabilityFixture(t)

	if status := f.revoke(tokenA, "dev-target"); status != http.StatusInternalServerError {
		t.Fatalf("first attempt = %d, want 500", status)
	}
	before := f.callbackCount()
	f.failSync.Store(false) // dirsync restored
	status := f.revoke(tokenA, "dev-target")
	if status != http.StatusOK {
		t.Fatalf("retry after flush restored = %d, want 200", status)
	}
	if got := f.callbackCount(); got <= before {
		t.Fatal("acknowledged retry did not re-run containment callbacks")
	}
	// Durability proven: a further retry is a clean idempotent no-op (200).
	if status := f.revoke(tokenA, "dev-target"); status != http.StatusOK {
		t.Fatalf("idempotent retry after acknowledgment = %d, want 200", status)
	}
	// And the persisted state is revoked.
	got, err := f.store.GetDevice("dev-target")
	if err != nil || !got.Revoked {
		t.Fatalf("device state after acknowledgment: %+v err=%v", got, err)
	}
}

// The uncertain-but-applied revocation is durable across restart: a
// reloaded registry still shows it revoked and still rejects the key under
// a new ID (no resurrection through the uncertainty window).
func TestRevokedStateSurvivesUncertaintyRestart(t *testing.T) {
	f := newDurabilityFixture(t)

	if status := f.revoke(tokenA, "dev-target"); status != http.StatusInternalServerError {
		t.Fatalf("uncertain revocation = %d, want 500", status)
	}
	fs2, err := NewFileStore(f.path)
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []string{"dev-target", "dev-duplicate"} {
		got, err := fs2.GetDevice(id)
		if err != nil || !got.Revoked {
			t.Fatalf("%s after restart: %+v err=%v", id, got, err)
		}
	}
	// The revoked key cannot be re-enrolled under a new ID.
	got, err := fs2.GetDevice("dev-target")
	if err != nil {
		t.Fatal(err)
	}
	if err := fs2.Put(Device{ID: "dev-fresh", AccountID: "google:9", PublicKey: got.PublicKey, SSHHostKey: testHostKey}); !errors.Is(err, ErrPublicKeyRevoked) {
		t.Fatalf("revoked key reused after uncertain revocation: %v", err)
	}
}

// The uncertain revocation is visible through the authenticated list API
// (the owner sees the applied state, not a stale active device).
func TestUncertainRevocationVisibleInList(t *testing.T) {
	f := newDurabilityFixture(t)

	if status := f.revoke(tokenA, "dev-target"); status != http.StatusInternalServerError {
		t.Fatalf("uncertain revocation = %d, want 500", status)
	}
	resp := getJSON(t, f.service, "/identity/v1/devices", tokenA)
	var out struct {
		Devices []deviceJSON `json:"devices"`
	}
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.Unmarshal(raw, &out); err != nil {
		t.Fatal(err)
	}
	for _, d := range out.Devices {
		if d.ID == "dev-target" && !d.Revoked {
			t.Fatal("list shows the target active despite applied revocation")
		}
	}
}
