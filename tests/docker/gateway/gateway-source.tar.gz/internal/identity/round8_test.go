package identity

// Round-eight admission regressions (root/Astra final review):
//
//  1. Authentication happens at header time; the principal's expiry and the
//     request context were never rechecked at the ACTUAL admission points
//     (after the body, after lookups, before Issue/Consume/Put/Replace/
//     Revoke/List). A token valid at authentication could finish a slow body
//     after expiry and still mint challenges, enroll, list, or revoke.
//  2. decodeStrict accepted a complete JSON value followed by stalled
//     trailing data: dec.More() returns false on READ ERRORS (including
//     timeouts), so valid-prefix-plus-error bodies passed.
//  3. The final admission gate must live UNDER the store's mutation lock
//     (registry.mutate acquires a context-less lock and never rechecks
//     after acquiring it) — a service-only check before the store call is
//     insufficient when a request queues behind a slow fsync.
//
// Determinism: every blocked region is synchronized with entered/gate
// channel pairs — no sleeps; boundaries use exact clock advances. The
// paused-lock tests signal at the STORE call boundary (after authenticate
// has fully returned), never inside the verifier, so a 401 can only come
// from the final gate under the store lock — not from initial
// authentication.

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// gatedBody is a request body that delivers one data chunk, then blocks on
// the gate before reporting its ending (EOF or trailingErr). entered closes
// on the first Read, proving the handler genuinely started consuming the
// body (authentication necessarily already passed: it precedes decoding).
type gatedBody struct {
	data        []byte
	off         int
	extra       string // padding served only after the data chunk is consumed
	extraOff    int
	trailingErr error // ending after data; nil means clean EOF

	entered chan struct{}
	gate    chan struct{}
	once    sync.Once
}

func newGatedBody(data string, trailingErr error) *gatedBody {
	return &gatedBody{
		data:        []byte(data),
		trailingErr: trailingErr,
		entered:     make(chan struct{}),
		gate:        make(chan struct{}),
	}
}

func (b *gatedBody) Read(p []byte) (int, error) {
	b.once.Do(func() { close(b.entered) })
	<-b.gate
	if b.off < len(b.data) {
		n := copy(p, b.data[b.off:])
		b.off += n
		return n, nil
	}
	if b.extraOff < len(b.extra) {
		n := copy(p, b.extra[b.extraOff:])
		b.extraOff += n
		return n, nil
	}
	if b.trailingErr != nil {
		return 0, b.trailingErr
	}
	return 0, io.EOF
}

func (b *gatedBody) Close() error { return nil }

// serveAsync runs the handler in its own goroutine (it will block in the
// body) and returns a func awaiting the recorded response.
func serveAsync(s *Service, req *http.Request) func() *http.Response {
	done := make(chan *http.Response, 1)
	go func() {
		rec := httptest.NewRecorder()
		s.ServeHTTP(rec, req)
		done <- rec.Result()
	}()
	return func() *http.Response { return <-done }
}

func waitEntered(t *testing.T, entered chan struct{}) {
	t.Helper()
	select {
	case <-entered:
	case <-time.After(2 * time.Second):
		t.Fatal("handler never started reading the body")
	}
}

// round8Fixture builds a fake-clock service whose single principal (tokenA)
// expires exactly one hour after the clock base, backed by an injected
// store. ChallengeTTL is long enough that challenges outlive the expiry
// advances used below.
type round8Fixture struct {
	clock     *fakeClock
	service   *Service
	expiresAt time.Time
}

func newRound8Fixture(t *testing.T, store DeviceStore, mutate ...func(*Config)) *round8Fixture {
	t.Helper()
	clock := newFakeClock()
	expiresAt := clock.Now().Add(time.Hour)
	cfg := Config{
		Verifier: stubVerifier{principals: map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA, ExpiresAt: expiresAt},
			tokenB: {AccountID: "google:" + subB, Email: emailB, ExpiresAt: expiresAt},
		}},
		Store:        store,
		Clock:        clock.Now,
		ChallengeTTL: 24 * time.Hour,
		Logger:       func(string, ...any) {},
	}
	for _, m := range mutate {
		m(&cfg)
	}
	s, err := NewService(cfg)
	if err != nil {
		t.Fatal(err)
	}
	return &round8Fixture{clock: clock, service: s, expiresAt: expiresAt}
}

// issueChallenge requests and signs an enrollment for deviceID while the
// fixture clock is still at base (principal valid), returning the enroll
// request body the client would send.
func (f *round8Fixture) issueChallenge(t *testing.T, priv ed25519.PrivateKey, deviceID string) enrollRequest {
	t.Helper()
	resp := postJSON(t, f.service, "/identity/v1/challenge", tokenA, map[string]string{"device_id": deviceID})
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("pre-test challenge = %s, want 200", resp.Status)
	}
	var ch challengeResponse
	decodeBody(t, resp, &ch)
	rebuilt := &Challenge{
		ID: ch.ChallengeID, DeviceID: ch.DeviceID, Role: ch.Role, Protocol: ch.Protocol,
		Domain: ch.Domain, Nonce: ch.Nonce, ConnectionNonce: ch.ConnectionNonce,
		ExpiresAt: time.Unix(ch.ExpiresAt, 0).UTC(), AccountID: "google:" + subA,
	}
	pub := priv.Public().(ed25519.PublicKey)
	sig, err := SignEnrollment(priv, pub, rebuilt, testHostKey, false)
	if err != nil {
		t.Fatal(err)
	}
	return enrollRequest{
		DeviceID:    deviceID,
		PublicKey:   base64.StdEncoding.EncodeToString(pub),
		SSHHostKey:  testHostKey,
		ChallengeID: ch.ChallengeID,
		Signature:   base64.StdEncoding.EncodeToString(sig),
	}
}

// Finding 1a RED: a token valid at authentication finishing a slow body
// after expiry must not enroll. The body is delivered completely but the
// handler stalls reading the trailing end; expiry crosses while it stalls;
// release must yield 401 with NO challenge consumption and NO enrollment.
func TestEnrollAdmissionDeniedAfterBodyStallsPastExpiry(t *testing.T) {
	f := newRound8Fixture(t, NewMemoryStore())
	_, priv := newKeyPair(t)
	reqBody := f.issueChallenge(t, priv, "stall-enroll-1")
	raw, err := json.Marshal(reqBody)
	if err != nil {
		t.Fatal(err)
	}

	body := newGatedBody(string(raw), nil) // clean single JSON, stalled ending
	req := httptest.NewRequest(http.MethodPost, "/identity/v1/enroll", body)
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(f.service, req)

	waitEntered(t, body.entered) // authentication passed; body being read
	f.clock.Advance(2 * time.Hour)
	close(body.gate)

	resp := await()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("enroll admitted after expiry = %s, want 401", resp.Status)
	}
	resp.Body.Close()
	if got := f.service.challenges.Outstanding("google:" + subA); got != 1 {
		t.Fatalf("challenge outstanding = %d, want 1 (admission must deny BEFORE consuming the challenge)", got)
	}
	if _, err := f.service.store.GetDevice("stall-enroll-1"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("expired request must not enroll anything")
	}
}

// Exact boundary: at expiry-1ns the admission must still pass (strictly
// future expiry required, nothing sloppier).
func TestEnrollAdmittedJustBeforeExpiryBoundary(t *testing.T) {
	f := newRound8Fixture(t, NewMemoryStore())
	_, priv := newKeyPair(t)
	reqBody := f.issueChallenge(t, priv, "boundary-enroll-1")
	raw, err := json.Marshal(reqBody)
	if err != nil {
		t.Fatal(err)
	}

	body := newGatedBody(string(raw), nil)
	req := httptest.NewRequest(http.MethodPost, "/identity/v1/enroll", body)
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(f.service, req)

	waitEntered(t, body.entered)
	f.clock.Advance(time.Hour - time.Nanosecond) // still strictly before expiry
	close(body.gate)

	resp := await()
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusCreated {
		t.Fatalf("enroll at expiry-1ns = %s, want 201 (admission is valid strictly before expiry)", resp.Status)
	}
	if got := f.service.challenges.Outstanding("google:" + subA); got != 0 {
		t.Fatalf("challenge outstanding = %d, want 0 (consumed)", got)
	}
	if _, err := f.service.store.GetDevice("boundary-enroll-1"); err != nil {
		t.Fatalf("device not enrolled: %v", err)
	}
}

// Finding 1b RED: the same gap on the challenge endpoint — a stalled body
// finishing after expiry must not mint a fresh challenge.
func TestChallengeAdmissionDeniedAfterBodyStalls(t *testing.T) {
	f := newRound8Fixture(t, NewMemoryStore())

	body := newGatedBody(`{"device_id":"stall-ch-1"}`, nil)
	req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", body)
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(f.service, req)

	waitEntered(t, body.entered)
	f.clock.Advance(2 * time.Hour)
	close(body.gate)

	resp := await()
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("challenge issued after expiry = %s, want 401", resp.Status)
	}
	if got := f.service.challenges.Outstanding("google:" + subA); got != 0 {
		t.Fatalf("outstanding challenges = %d, want 0 (no challenge may be issued after expiry)", got)
	}
}

// Finding 1c RED: a store lookup that returns after expiry (injected slow
// store) must deny BEFORE any mutation decision.
func TestSlowInjectedLookupDeniesBeforeMutation(t *testing.T) {
	mem := NewMemoryStore()
	slow := &slowLookupStore{inner: mem, entered: make(chan struct{}), gate: make(chan struct{})}
	f := newRound8Fixture(t, slow)
	_, priv := newKeyPair(t)
	reqBody := f.issueChallenge(t, priv, "slow-lookup-1")
	raw, err := json.Marshal(reqBody)
	if err != nil {
		t.Fatal(err)
	}

	req := httptest.NewRequest(http.MethodPost, "/identity/v1/enroll", strings.NewReader(string(raw)))
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(f.service, req)

	select {
	case <-slow.entered:
	case <-time.After(2 * time.Second):
		t.Fatal("enroll never reached the device lookup")
	}
	f.clock.Advance(2 * time.Hour)
	close(slow.gate)

	resp := await()
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("enroll after slow lookup past expiry = %s, want 401", resp.Status)
	}
	if got := slow.putCalls.Load(); got != 0 {
		t.Fatalf("Put called %d times after expired admission, want 0", got)
	}
	if _, err := mem.GetDevice("slow-lookup-1"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("expired request must not enroll anything")
	}
}

// observedStore wraps the fixture's FileStore and provides the entry
// barriers for the paused-lock tests:
//
//   - revokeEntered/listEntered close when the service handler (not a test
//     helper) enters RevokeAdmitted/ListAdmitted. The handler calls these
//     only AFTER authenticate has fully returned and accepted the still-
//     valid principal, so awaiting them proves authentication completed.
//     (The previous design signaled inside VerifyToken — BEFORE
//     authenticate's final clock/context checks — so a test that advanced
//     the clock after the signal could pass by rejection at initial auth
//     instead of at the store-lock gate.)
//   - gateEntered closes when the ADMISSION CHECK itself is invoked: the
//     wrapper wraps the check before forwarding it, and the inner
//     FileStore runs the check only under its mutation lock, so
//     gateEntered after the fsync release proves the final gate ran after
//     lock acquisition.
type observedStore struct {
	inner AuthorizedStore

	revokeEntered chan struct{}
	listEntered   chan struct{}
	gateEntered   chan struct{}

	revokeOnce, listOnce, gateOnce sync.Once
}

func (o *observedStore) wrapCheck(check AdmissionCheck) AdmissionCheck {
	return func() error {
		o.gateOnce.Do(func() { close(o.gateEntered) })
		if check == nil {
			return nil
		}
		return check()
	}
}

func (o *observedStore) GetDevice(id string) (Device, error) { return o.inner.GetDevice(id) }
func (o *observedStore) Put(d Device) error                  { return o.inner.Put(d) }
func (o *observedStore) Replace(d Device) (Device, bool, error) {
	return o.inner.Replace(d)
}
func (o *observedStore) List(a string) ([]Device, error) { return o.inner.List(a) }
func (o *observedStore) Count(a string) (int, error)     { return o.inner.Count(a) }
func (o *observedStore) Revoke(id, a string) (Device, []Device, bool, error) {
	return o.inner.Revoke(id, a)
}
func (o *observedStore) PutAdmitted(check AdmissionCheck, d Device) error {
	return o.inner.PutAdmitted(o.wrapCheck(check), d)
}
func (o *observedStore) ReplaceAdmitted(check AdmissionCheck, d Device) (Device, bool, error) {
	return o.inner.ReplaceAdmitted(o.wrapCheck(check), d)
}
func (o *observedStore) ListAdmitted(check AdmissionCheck, a string) ([]Device, error) {
	o.listOnce.Do(func() { close(o.listEntered) })
	return o.inner.ListAdmitted(o.wrapCheck(check), a)
}
func (o *observedStore) RevokeAdmitted(check AdmissionCheck, id, a string) (Device, []Device, bool, error) {
	o.revokeOnce.Do(func() { close(o.revokeEntered) })
	return o.inner.RevokeAdmitted(o.wrapCheck(check), id, a)
}

// pausedLockFixture seeds a registry with dev-target and opens it with a
// directory-fsync hook that pauses while holding the store's mutation lock.
type pausedLockFixture struct {
	clock     *fakeClock
	expiresAt time.Time
	fs        *FileStore
	observed  *observedStore
	service   *Service
	m1Entered chan struct{}
	m1Gate    chan struct{}
}

func newPausedLockFixture(t *testing.T) *pausedLockFixture {
	t.Helper()
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	writeRegistryFile(t, path, 2, []Device{
		{ID: "dev-target", AccountID: "google:" + subA, PublicKey: mustKey(t), SSHHostKey: testHostKey},
	}, nil)

	clock := newFakeClock()
	expiresAt := clock.Now().Add(time.Hour)
	f := &pausedLockFixture{
		clock:     clock,
		expiresAt: expiresAt,
		m1Entered: make(chan struct{}),
		m1Gate:    make(chan struct{}),
		observed: &observedStore{
			revokeEntered: make(chan struct{}),
			listEntered:   make(chan struct{}),
			gateEntered:   make(chan struct{}),
		},
	}
	// Only the FIRST persist (M1's enrollment) pauses; later persists pass
	// through so the test can observe post-release mutations.
	var pauseOnce sync.Once
	fs, err := NewFileStore(path,
		WithLimits(Limits{MaxPerAccount: -1}),
		WithDirSyncHook(func(*os.File) error {
			pauseOnce.Do(func() {
				close(f.m1Entered)
				<-f.m1Gate
			})
			return nil
		}))
	if err != nil {
		t.Fatal(err)
	}
	f.fs = fs
	f.observed.inner = fs

	s, err := NewService(Config{
		Verifier: stubVerifier{principals: map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA, ExpiresAt: expiresAt},
		}},
		Store:  f.observed,
		Clock:  clock.Now,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	f.service = s
	return f
}

// pauseUnderLock starts M1 — a legitimately admitted, direct-store
// enrollment whose fsync pauses while holding the store lock — and waits
// until the lock is genuinely held.
func (f *pausedLockFixture) pauseUnderLock(t *testing.T) {
	t.Helper()
	_, m1priv := newKeyPair(t)
	m1Done := make(chan error, 1)
	go func() {
		m1Done <- f.fs.Put(Device{
			ID: "dev-m1", AccountID: "google:m1",
			PublicKey: m1priv.Public().(ed25519.PublicKey), SSHHostKey: testHostKey,
		})
	}()
	select {
	case <-f.m1Entered:
	case <-time.After(2 * time.Second):
		t.Fatal("M1 never reached the paused fsync (lock not held)")
	}
	go func() {
		if err := <-m1Done; err != nil {
			t.Errorf("legitimately admitted M1 enrollment failed: %v", err)
		}
	}()
}

// Finding 1d RED (the store-lock boundary): a request that passed
// authentication while its principal was valid, but whose mutation queues
// behind a slow lock-holding fsync, must be denied by the FINAL gate — the
// mutation may not apply after the expiry. Zero containment callbacks fire
// (nothing was applied), and M1's legitimately admitted work completes.
//
// Determinism: the test advances the clock only AFTER the handler has
// provably entered RevokeAdmitted (which happens strictly after
// authenticate returned and accepted the principal), so the 401 can only
// come from the final gate under the store lock — never from initial
// authentication.
func TestPausedStoreLockZeroMutationOnExpiry(t *testing.T) {
	f := newPausedLockFixture(t)
	var callbacks atomic.Int64
	f.service.OnRevoke(func(Device) { callbacks.Add(1) })

	f.pauseUnderLock(t)

	// R2: an HTTP revocation queuing behind M1 on the same lock.
	req := httptest.NewRequest(http.MethodPost, "/identity/v1/devices/dev-target/revoke", nil)
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(f.service, req)

	// Barrier 1: the handler entered RevokeAdmitted — authenticate has
	// fully returned and the request is queued on the lock M1 holds.
	waitEntered(t, f.observed.revokeEntered)

	// The final gate must not have run while the lock is still held by M1.
	select {
	case <-f.observed.gateEntered:
		t.Fatal("final admission gate ran before the store lock was acquired")
	default:
	}

	f.clock.Advance(2 * time.Hour) // R2's authorization expires while it waits
	close(f.m1Gate)                // M1 finishes; R2 acquires the lock and reaches the gate

	// Barrier 2: the admission check was invoked — which happens only after
	// the lock was acquired (M1 held it until the release above).
	waitEntered(t, f.observed.gateEntered)

	resp := await()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("revocation admitted after expiry while queued on the store lock = %s, want 401", resp.Status)
	}
	resp.Body.Close()
	dev, err := f.fs.GetDevice("dev-target")
	if err != nil || dev.Revoked {
		t.Fatalf("expired request revoked the device: %+v err=%v", dev, err)
	}
	if callbacks.Load() != 0 {
		t.Fatalf("%d revocation callbacks fired for a denied request, want 0", callbacks.Load())
	}
	if dev, err := f.fs.GetDevice("dev-m1"); err != nil {
		t.Fatalf("M1's legitimately admitted enrollment must complete: %v", err)
	} else if dev.Revoked {
		t.Fatal("M1 device damaged")
	}
}

// Finding 1e RED: the same lock boundary must gate LIST disclosure — an
// expired request queued behind a slow mutation must not receive device
// data. Same barrier discipline as the mutation test: the clock advances
// only after the handler provably entered ListAdmitted.
func TestPausedStoreLockZeroDisclosureOnExpiry(t *testing.T) {
	f := newPausedLockFixture(t)
	f.pauseUnderLock(t)

	req := httptest.NewRequest(http.MethodGet, "/identity/v1/devices", nil)
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(f.service, req)

	waitEntered(t, f.observed.listEntered)
	select {
	case <-f.observed.gateEntered:
		t.Fatal("disclosure gate ran before the store lock was acquired")
	default:
	}

	f.clock.Advance(2 * time.Hour)
	close(f.m1Gate)
	waitEntered(t, f.observed.gateEntered)

	resp := await()
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("device list disclosed after expiry = %s, want 401", resp.Status)
	}
	var out struct {
		Devices []deviceJSON `json:"devices"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&out); err == nil && len(out.Devices) > 0 {
		t.Fatalf("expired request received %d devices", len(out.Devices))
	}
}

// A mutation LEGITIMATELY admitted (fresh, valid principal at the gate
// under the store lock) whose directory fsync then fails after the rename
// must keep the full uncertainty contract even when the principal expires
// while the fsync is in flight: containment still fires and the response
// stays a non-acknowledging error — a later expiry must not mask an
// applied-and-contained mutation as a clean 401. A retry with the now-
// expired token is denied without re-firing anything.
func TestAdmittedRevocationUncertainAfterLaterExpiryStillContains(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	writeRegistryFile(t, path, 2, []Device{
		{ID: "dev-target", AccountID: "google:" + subA, PublicKey: mustKey(t), SSHHostKey: testHostKey},
	}, nil)

	clock := newFakeClock()
	expiresAt := clock.Now().Add(time.Hour)
	dsEntered := make(chan struct{})
	dsGate := make(chan struct{})
	var pauseOnce sync.Once
	fs, err := NewFileStore(path,
		WithLimits(Limits{MaxPerAccount: -1}),
		WithDirSyncHook(func(*os.File) error {
			pauseOnce.Do(func() {
				close(dsEntered)
				<-dsGate
			})
			return errors.New("dirsync down") // post-rename failure
		}))
	if err != nil {
		t.Fatal(err)
	}
	s, err := NewService(Config{
		Verifier: stubVerifier{principals: map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA, ExpiresAt: expiresAt},
		}},
		Store:  fs,
		Clock:  clock.Now,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	var callbacks atomic.Int64
	s.OnRevoke(func(Device) { callbacks.Add(1) })

	req := httptest.NewRequest(http.MethodPost, "/identity/v1/devices/dev-target/revoke", nil)
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(s, req)

	// Barrier: the revocation was admitted (valid principal at the gate
	// under the lock), applied, renamed — the handler is paused in the
	// directory fsync that holds the lock.
	select {
	case <-dsEntered:
	case <-time.After(2 * time.Second):
		t.Fatal("revocation never reached the paused directory fsync")
	}

	clock.Advance(2 * time.Hour) // the principal expires mid-persist
	close(dsGate)                // the fsync now fails (post-rename)

	resp := await()
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusInternalServerError {
		t.Fatalf("uncertain revocation after expiry = %s, want 500 (non-acknowledging; admission was valid)", resp.Status)
	}
	if got := callbacks.Load(); got != 1 {
		t.Fatalf("containment callbacks = %d, want 1 (containment runs despite the later expiry)", got)
	}
	dev, err := fs.GetDevice("dev-target")
	if err != nil || !dev.Revoked {
		t.Fatalf("applied revocation lost: %+v err=%v", dev, err)
	}

	// A retry with the now-expired token is denied at admission: nothing
	// re-fires, and the applied state is untouched.
	retry := postJSON(t, s, "/identity/v1/devices/dev-target/revoke", tokenA, nil)
	defer retry.Body.Close()
	if retry.StatusCode != http.StatusUnauthorized {
		t.Fatalf("retry with expired token = %s, want 401", retry.Status)
	}
	if got := callbacks.Load(); got != 1 {
		t.Fatalf("denied retry re-fired containment: %d callbacks, want 1", got)
	}
	if dev, err := fs.GetDevice("dev-target"); err != nil || !dev.Revoked {
		t.Fatalf("applied revocation damaged by denied retry: %+v err=%v", dev, err)
	}
}

// Finding 1f: request-context cancellation rejects at admission — the
// context is canceled while the body is being consumed (after
// authentication), and the request must die with no side effects.
func TestCanceledRequestDeniedAtAdmission(t *testing.T) {
	f := newRound8Fixture(t, NewMemoryStore())

	ctx, cancel := context.WithCancel(context.Background())
	body := &cancelingBody{data: []byte(`{"device_id":"cancel-ch-1"}`), cancel: cancel,
		entered: make(chan struct{}), gate: make(chan struct{})}
	req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", body).WithContext(ctx)
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(f.service, req)

	waitEntered(t, body.entered) // authentication passed; body read started
	close(body.gate)             // body completes cleanly

	resp := await()
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("canceled request admitted = %s, want 401", resp.Status)
	}
	if got := f.service.challenges.Outstanding("google:" + subA); got != 0 {
		t.Fatalf("outstanding challenges = %d, want 0 (canceled request must not issue)", got)
	}
}

// Finding 2 RED: a complete JSON value followed by stalled trailing data is
// NOT a valid body. dec.More() returns false on read errors, so the old
// decoder accepted these; the second-Decode-to-EOF discipline must deny
// with 408 on timeouts/cancellation and 400 on other read errors — and
// issue nothing.
func TestStalledTrailingBodyDenied(t *testing.T) {
	t.Run("deadline-exceeded", func(t *testing.T) {
		f := newRound8Fixture(t, NewMemoryStore())
		body := newGatedBody(`{"device_id":"stall-1"}`, context.DeadlineExceeded)
		req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", body)
		req.Host = "gateway.test"
		req.Header.Set("Authorization", "Bearer "+tokenA)
		await := serveAsync(f.service, req)

		waitEntered(t, body.entered)
		close(body.gate)
		resp := await()
		defer resp.Body.Close()
		var got struct {
			Error string `json:"error"`
		}
		_ = json.NewDecoder(resp.Body).Decode(&got)
		if resp.StatusCode != http.StatusRequestTimeout {
			t.Fatalf("trailing stalled read = %s (%q), want 408", resp.Status, got.Error)
		}
		if got := f.service.challenges.Outstanding("google:" + subA); got != 0 {
			t.Fatalf("outstanding challenges = %d, want 0 (no issue on bad body)", got)
		}
	})
	t.Run("canceled", func(t *testing.T) {
		f := newRound8Fixture(t, NewMemoryStore())
		body := newGatedBody(`{"device_id":"stall-2"}`, context.Canceled)
		req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", body)
		req.Host = "gateway.test"
		req.Header.Set("Authorization", "Bearer "+tokenA)
		await := serveAsync(f.service, req)

		waitEntered(t, body.entered)
		close(body.gate)
		resp := await()
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusRequestTimeout {
			t.Fatalf("trailing canceled read = %s, want 408", resp.Status)
		}
	})
	t.Run("read-error", func(t *testing.T) {
		f := newRound8Fixture(t, NewMemoryStore())
		body := newGatedBody(`{"device_id":"stall-3"}`, errors.New("connection reset"))
		req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", body)
		req.Host = "gateway.test"
		req.Header.Set("Authorization", "Bearer "+tokenA)
		await := serveAsync(f.service, req)

		waitEntered(t, body.entered)
		close(body.gate)
		resp := await()
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusBadRequest {
			t.Fatalf("trailing read error = %s, want 400", resp.Status)
		}
	})
	// Trailing WHITESPACE delivered before the stall is the sharp form of
	// the finding: the whitespace is buffered, so the decoder's trailing
	// peek looks clean until the NEXT read fails. A body must not be
	// accepted until its definitive ending (timeout here → 408).
	t.Run("whitespace-then-timeout", func(t *testing.T) {
		f := newRound8Fixture(t, NewMemoryStore())
		body := newGatedBody(`{"device_id":"stall-6"}  `, context.DeadlineExceeded)
		req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", body)
		req.Host = "gateway.test"
		req.Header.Set("Authorization", "Bearer "+tokenA)
		await := serveAsync(f.service, req)

		waitEntered(t, body.entered)
		close(body.gate)
		resp := await()
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusRequestTimeout {
			t.Fatalf("trailing whitespace then stalled read = %s, want 408", resp.Status)
		}
		if got := f.service.challenges.Outstanding("google:" + subA); got != 0 {
			t.Fatalf("outstanding challenges = %d, want 0 (no issue on bad body)", got)
		}
	})
	// A stall that resolves with a clean EOF is a VALID single-JSON body
	// (trailing whitespace before EOF is legal JSON whitespace).
	t.Run("stall-then-eof-accepted", func(t *testing.T) {
		f := newRound8Fixture(t, NewMemoryStore())
		body := newGatedBody(`{"device_id":"stall-4"}  `, nil)
		req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", body)
		req.Host = "gateway.test"
		req.Header.Set("Authorization", "Bearer "+tokenA)
		await := serveAsync(f.service, req)

		waitEntered(t, body.entered)
		close(body.gate)
		resp := await()
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("clean body with trailing whitespace = %s, want 200", resp.Status)
		}
		if got := f.service.challenges.Outstanding("google:" + subA); got != 1 {
			t.Fatalf("outstanding challenges = %d, want 1", got)
		}
	})
}

// Finding 2 (oversize at the trailing end): the body must still be denied
// when garbage beyond the byte cap arrives only after the JSON value
// completed. The decoder reports the buffered garbage as a syntax error
// before any pending byte-cap error can surface, so the observable status
// here is 400 (deny) rather than 413; the cap itself stays enforced — a
// value that CROSSES the cap still yields 413 via the propagated
// MaxBytesError (covered by TestBodyAndProtocolBounds).
func TestOversizedTrailingBodyDenied(t *testing.T) {
	f := newRound8Fixture(t, NewMemoryStore(), func(c *Config) { c.MaxBodyBytes = 64 })
	body := newGatedBody(`{"device_id":"stall-5"}`, nil)
	// Append padding only on the reads after the first chunk.
	body.extra = strings.Repeat("a", 256)
	req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", body)
	req.Host = "gateway.test"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	await := serveAsync(f.service, req)

	waitEntered(t, body.entered)
	close(body.gate)
	resp := await()
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusBadRequest && resp.StatusCode != http.StatusRequestEntityTooLarge {
		t.Fatalf("oversized trailing data = %s, want 400/413", resp.Status)
	}
	if got := f.service.challenges.Outstanding("google:" + subA); got != 0 {
		t.Fatalf("outstanding challenges = %d, want 0 (no issue on bad body)", got)
	}
}

// Finding 2 (already-deny cases that must STAY denied under the second-
// Decode discipline): extra JSON values and stray closing delimiters.
func TestExtraJSONAndDelimiterDenied(t *testing.T) {
	cases := []struct {
		name string
		body string
	}{
		{"extra-json-object", `{"device_id":"d1"}{"device_id":"d2"}`},
		{"extra-empty-object", `{"device_id":"d1"}{}`},
		{"extra-closing-delimiter", `{"device_id":"d1"}]`},
		{"extra-number", `{"device_id":"d1"}42`},
		{"extra-null", `{"device_id":"d1"}null`},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f := newRound8Fixture(t, NewMemoryStore())
			req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", strings.NewReader(tc.body))
			req.Host = "gateway.test"
			req.Header.Set("Authorization", "Bearer "+tokenA)
			rec := httptest.NewRecorder()
			f.service.ServeHTTP(rec, req)
			if rec.Code != http.StatusBadRequest {
				t.Fatalf("body %q = %d, want 400", tc.body, rec.Code)
			}
			if got := f.service.challenges.Outstanding("google:" + subA); got != 0 {
				t.Fatalf("outstanding challenges = %d, want 0 (no issue on bad body)", got)
			}
		})
	}
}

// Guard (round-four containment must survive the admission gate): a
// revocation legitimately admitted while the principal is valid, whose
// directory fsync fails AFTER the rename, stays applied, fires containment
// for every affected device, and never returns 200.
func TestAdmittedRevocationContainsAfterPostRenameFailure(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	key := mustKey(t)
	writeRegistryFile(t, path, 2, []Device{
		{ID: "dev-target", AccountID: "google:" + subA, PublicKey: key, SSHHostKey: testHostKey},
	}, nil)
	fs, err := NewFileStore(path, WithLimits(Limits{MaxPerAccount: -1}),
		WithDirSyncHook(func(*os.File) error { return errors.New("dirsync down") }))
	if err != nil {
		t.Fatal(err)
	}
	s, err := NewService(Config{
		Verifier: newStubVerifier(time.Now().Add(time.Hour), map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA},
		}),
		Store:  fs,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	var callbacks atomic.Int64
	s.OnRevoke(func(Device) { callbacks.Add(1) })

	resp := postJSON(t, s, "/identity/v1/devices/dev-target/revoke", tokenA, nil)
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusInternalServerError {
		t.Fatalf("unacknowledged revocation = %s, want 500 (no false 200)", resp.Status)
	}
	if got := callbacks.Load(); got != 1 {
		t.Fatalf("containment callbacks = %d, want 1 (containment is not a durability ACK)", got)
	}
	dev, err := fs.GetDevice("dev-target")
	if err != nil || !dev.Revoked {
		t.Fatalf("applied revocation lost: %+v err=%v", dev, err)
	}
}

// --- helpers ---------------------------------------------------------------

// slowLookupStore models an injected registry whose GetDevice blocks (a
// slow or contended registry) and counts Put attempts, so tests can prove
// the mutation never happens. It implements full AuthorizedStore semantics:
// every admitted call forwards the check into the inner registry's actual
// mutation/list lock — never an always-allow stub.
type slowLookupStore struct {
	inner    *MemoryStore
	putCalls atomic.Int64

	entered chan struct{}
	gate    chan struct{}
	once    sync.Once
}

func (s *slowLookupStore) GetDevice(id string) (Device, error) {
	s.once.Do(func() { close(s.entered) })
	<-s.gate
	return s.inner.GetDevice(id)
}
func (s *slowLookupStore) Put(d Device) error { s.putCalls.Add(1); return s.inner.Put(d) }
func (s *slowLookupStore) Replace(d Device) (Device, bool, error) {
	return s.inner.Replace(d)
}
func (s *slowLookupStore) List(accountID string) ([]Device, error) {
	return s.inner.List(accountID)
}
func (s *slowLookupStore) Count(accountID string) (int, error) {
	return s.inner.Count(accountID)
}
func (s *slowLookupStore) Revoke(id, accountID string) (Device, []Device, bool, error) {
	return s.inner.Revoke(id, accountID)
}
func (s *slowLookupStore) PutAdmitted(check AdmissionCheck, d Device) error {
	if err := admitUnderLock(check); err != nil {
		return err
	}
	s.putCalls.Add(1)
	return s.inner.PutAdmitted(check, d)
}
func (s *slowLookupStore) ReplaceAdmitted(check AdmissionCheck, d Device) (Device, bool, error) {
	return s.inner.ReplaceAdmitted(check, d)
}
func (s *slowLookupStore) ListAdmitted(check AdmissionCheck, a string) ([]Device, error) {
	return s.inner.ListAdmitted(check, a)
}
func (s *slowLookupStore) RevokeAdmitted(check AdmissionCheck, id, a string) (Device, []Device, bool, error) {
	return s.inner.RevokeAdmitted(check, id, a)
}

// cancelingBody cancels the request context on its first Read — after
// authentication, in the middle of body consumption — then serves the data
// and a clean EOF.
type cancelingBody struct {
	data    []byte
	off     int
	cancel  context.CancelFunc
	entered chan struct{}
	gate    chan struct{}
	once    sync.Once
}

func (b *cancelingBody) Read(p []byte) (int, error) {
	b.once.Do(func() {
		close(b.entered)
		b.cancel()
	})
	<-b.gate
	if b.off < len(b.data) {
		n := copy(p, b.data[b.off:])
		b.off += n
		return n, nil
	}
	return 0, io.EOF
}

func (b *cancelingBody) Close() error { return nil }

// --- Store-boundary regressions (AuthorizedStore) ---------------------------

// countingStore is an injected admission-capable store (full AuthorizedStore
// semantics: checks forwarded into the inner registry's mutation/list lock)
// that counts every mutation and disclosure, so tests can prove the service
// never lets a denied request reach it.
type countingStore struct {
	inner                                  *MemoryStore
	puts, replaces, revokes, lists, counts atomic.Int64
}

func (c *countingStore) GetDevice(id string) (Device, error) { return c.inner.GetDevice(id) }
func (c *countingStore) Put(d Device) error {
	c.puts.Add(1)
	return c.inner.Put(d)
}
func (c *countingStore) Replace(d Device) (Device, bool, error) {
	c.replaces.Add(1)
	return c.inner.Replace(d)
}
func (c *countingStore) List(a string) ([]Device, error) {
	c.lists.Add(1)
	return c.inner.List(a)
}
func (c *countingStore) Count(a string) (int, error) {
	c.counts.Add(1)
	return c.inner.Count(a)
}
func (c *countingStore) Revoke(id, a string) (Device, []Device, bool, error) {
	c.revokes.Add(1)
	return c.inner.Revoke(id, a)
}
func (c *countingStore) PutAdmitted(check AdmissionCheck, d Device) error {
	if err := admitUnderLock(check); err != nil {
		return err
	}
	c.puts.Add(1)
	return c.inner.PutAdmitted(check, d)
}
func (c *countingStore) ReplaceAdmitted(check AdmissionCheck, d Device) (Device, bool, error) {
	if err := admitUnderLock(check); err != nil {
		return Device{}, false, err
	}
	c.replaces.Add(1)
	return c.inner.ReplaceAdmitted(check, d)
}
func (c *countingStore) ListAdmitted(check AdmissionCheck, a string) ([]Device, error) {
	if err := admitUnderLock(check); err != nil {
		return nil, err
	}
	c.lists.Add(1)
	return c.inner.ListAdmitted(check, a)
}
func (c *countingStore) RevokeAdmitted(check AdmissionCheck, id, a string) (Device, []Device, bool, error) {
	if err := admitUnderLock(check); err != nil {
		return Device{}, nil, false, err
	}
	c.revokes.Add(1)
	return c.inner.RevokeAdmitted(check, id, a)
}

// The Astra final review requires the authorization admission at the FINAL
// pre-mutation gate UNDER the store lock: a service-only check before the
// store call is insufficient when the request queues behind a lock-holding
// mutation. This test proves the admitted calls run the check while holding
// the store's lock: a paused check blocks a second admitted call that would
// otherwise succeed, and denial applies nothing.
func TestStoreGateRunsUnderLockBeforeStateChange(t *testing.T) {
	fs, err := NewFileStore(filepath.Join(t.TempDir(), "devices.json"), WithLimits(Limits{MaxPerAccount: -1}))
	if err != nil {
		t.Fatal(err)
	}
	_, priv := newKeyPair(t)
	dev := Device{ID: "gate-dev-1", AccountID: "google:gate", PublicKey: priv.Public().(ed25519.PublicKey), SSHHostKey: testHostKey}

	// Call 1: holds the store lock while paused inside its admission check,
	// then denies (the authorization expired while queued).
	running := make(chan struct{})
	release := make(chan struct{})
	done1 := make(chan error, 1)
	go func() {
		done1 <- fs.PutAdmitted(func() error {
			close(running)
			<-release
			return context.DeadlineExceeded
		}, dev)
	}()
	<-running

	// Call 2: an ALWAYS-ADMITTING check must still not reach a state change
	// while call 1 holds the lock inside its check — proof the gate runs
	// under the same lock, before fn. Negative wait: we assert nothing
	// happens.
	_, priv2 := newKeyPair(t)
	dev2 := Device{ID: "gate-dev-2", AccountID: "google:gate", PublicKey: priv2.Public().(ed25519.PublicKey), SSHHostKey: testHostKey}
	done2 := make(chan error, 1)
	go func() {
		done2 <- fs.PutAdmitted(func() error { return nil }, dev2)
	}()
	select {
	case err := <-done2:
		t.Fatalf("second admitted call completed while the first paused inside its check under the lock: %v — gate is not under the store lock", err)
	case <-time.After(100 * time.Millisecond):
	}

	close(release)
	err1 := <-done1
	if !errors.Is(err1, ErrAdmissionDenied) || !errors.Is(err1, context.DeadlineExceeded) {
		t.Fatalf("paused check denial = %v, want ErrAdmissionDenied wrapping context.DeadlineExceeded", err1)
	}
	// The queued call legitimately admits and runs after the release.
	if err := <-done2; err != nil {
		t.Fatalf("second call after release = %v, want success (it queued, then ran)", err)
	}
	if _, err := fs.GetDevice(dev.ID); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("denied admission must not enroll anything")
	}
	if _, err := fs.GetDevice(dev2.ID); err != nil {
		t.Fatalf("admitted call after release must enroll: %v", err)
	}
}

// The same under-lock proof for the disclosure gate: ListAdmitted pauses
// under the lock, a concurrent mutation queues behind it, and a denied
// check discloses nothing.
func TestListGateUnderLockDisclosesNothingOnDenial(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "devices.json")
	writeRegistryFile(t, path, 2, []Device{
		{ID: "dev-target", AccountID: "google:" + subA, PublicKey: mustKey(t), SSHHostKey: testHostKey},
	}, nil)
	fs, err := NewFileStore(path, WithLimits(Limits{MaxPerAccount: -1}))
	if err != nil {
		t.Fatal(err)
	}
	running := make(chan struct{})
	release := make(chan struct{})
	type listResult struct {
		devices []Device
		err     error
	}
	done := make(chan listResult, 1)
	go func() {
		devices, err := fs.ListAdmitted(func() error {
			close(running)
			<-release
			return context.Canceled
		}, "google:"+subA)
		done <- listResult{devices, err}
	}()
	<-running

	// While the check holds the lock, a revoke must queue (nothing may
	// interleave between the admission decision and the disclosure).
	revokeDone := make(chan error, 1)
	go func() {
		_, _, _, err := fs.RevokeAdmitted(func() error { return nil }, "dev-target", "google:"+subA)
		revokeDone <- err
	}()
	select {
	case <-revokeDone:
		t.Fatal("revoke completed while the list check held the lock — disclosure gate is not under the store lock")
	case <-time.After(100 * time.Millisecond):
	}

	close(release)
	res := <-done
	if !errors.Is(res.err, ErrAdmissionDenied) {
		t.Fatalf("paused list check = %v, want ErrAdmissionDenied", res.err)
	}
	if len(res.devices) != 0 {
		t.Fatalf("denied disclosure returned %d devices", len(res.devices))
	}
	// The queued revoke legitimately admits and runs after the disclosure.
	if err := <-revokeDone; err != nil {
		t.Fatalf("queued revoke after release: %v", err)
	}
	dev, err := fs.GetDevice("dev-target")
	if err != nil || !dev.Revoked {
		t.Fatalf("queued revoke did not apply: %+v err=%v", dev, err)
	}
}

// Injected stores cannot silently bypass the admission policy: the service
// exposes an AuthorizedStore for injected stores, and admitted calls with a
// denying check never reach the inner store. (Construction-time rejection of
// stores WITHOUT AuthorizedStore semantics is proven separately in
// round9_test.go; the expiry-during-queued-work proof lives in the
// paused-lock tests above — this test only covers the already-denying path.)
func TestInjectedStoreCannotBypassAdmission(t *testing.T) {
	counting := &countingStore{inner: NewMemoryStore()}
	f := newRound8Fixture(t, counting)
	as, ok := f.service.store.(AuthorizedStore)
	if !ok {
		t.Fatal("service store must satisfy AuthorizedStore even for opaque injected stores")
	}
	deny := func() error { return context.Canceled }
	_, priv := newKeyPair(t)
	dev := Device{ID: "bypass-dev-1", AccountID: "google:" + subA, PublicKey: priv.Public().(ed25519.PublicKey), SSHHostKey: testHostKey}

	if err := as.PutAdmitted(deny, dev); !errors.Is(err, ErrAdmissionDenied) {
		t.Fatalf("PutAdmitted deny = %v, want ErrAdmissionDenied", err)
	}
	if _, _, err := as.ReplaceAdmitted(deny, dev); !errors.Is(err, ErrAdmissionDenied) {
		t.Fatalf("ReplaceAdmitted deny = %v, want ErrAdmissionDenied", err)
	}
	if _, _, _, err := as.RevokeAdmitted(deny, "dev-x", "google:"+subA); !errors.Is(err, ErrAdmissionDenied) {
		t.Fatalf("RevokeAdmitted deny = %v, want ErrAdmissionDenied", err)
	}
	if devices, err := as.ListAdmitted(deny, "google:"+subA); !errors.Is(err, ErrAdmissionDenied) || devices != nil {
		t.Fatalf("ListAdmitted deny = %v, %v, want ErrAdmissionDenied and no data", err, devices)
	}
	if got := counting.puts.Load() + counting.replaces.Load() + counting.revokes.Load() + counting.lists.Load(); got != 0 {
		t.Fatalf("denied calls reached the injected store %d times, want 0", got)
	}

	// Denial causes stay inspectable: ErrAdmissionDenied wraps the cause.
	err := as.PutAdmitted(deny, dev)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("ErrAdmissionDenied must wrap the denial cause, got %v", err)
	}

	// An ADMITTING check passes through to the inner store (and the quota
	// decorator still applies).
	if err := as.PutAdmitted(func() error { return nil }, dev); err != nil {
		t.Fatalf("PutAdmitted admit: %v", err)
	}
	if got := counting.puts.Load(); got != 1 {
		t.Fatalf("admitted Put reached the inner store %d times, want 1", got)
	}
}

// The production admission rule: alive context, strictly future expiry, no
// zero expiry — at the CURRENT clock, not the authentication-time clock.
func TestValidAdmissionRule(t *testing.T) {
	now := time.Unix(1799999999, 0)
	clock := func() time.Time { return now }
	p := Principal{AccountID: "google:1", ExpiresAt: now.Add(time.Second)}

	if err := ValidAdmission(context.Background(), clock, p); err != nil {
		t.Fatalf("valid principal rejected: %v", err)
	}
	exactlyNow := Principal{AccountID: "google:1", ExpiresAt: now}
	if err := ValidAdmission(context.Background(), clock, exactlyNow); !errors.Is(err, ErrAdmissionDenied) {
		t.Fatalf("expiry == now must deny, got %v", err)
	}
	zero := Principal{AccountID: "google:1"}
	if err := ValidAdmission(context.Background(), clock, zero); !errors.Is(err, ErrAdmissionDenied) {
		t.Fatalf("zero expiry must deny, got %v", err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := ValidAdmission(ctx, clock, p); !errors.Is(err, ErrAdmissionDenied) {
		t.Fatalf("canceled context must deny, got %v", err)
	}
}
