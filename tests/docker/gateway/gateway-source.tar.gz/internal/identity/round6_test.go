package identity

// Round-six findings: P1 cold-cache fetch bypassed the refresh cooldown
// (failed cold fetch spun new fetch attempts until the caller deadline),
// P2a the auth boundary checked the parent request context instead of the
// derived authentication deadline, P2b the blocked-fetch regressions gated
// on sleeps instead of transport entry signals.

import (
	"context"
	"crypto/rsa"
	"errors"
	"net/http"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// failingJWKS is a transport stub whose endpoint answers 503 immediately
// and counts every fetch attempt.
type failingJWKS struct {
	n atomic.Int64
}

func (f *failingJWKS) RoundTrip(r *http.Request) (*http.Response, error) {
	f.n.Add(1)
	return nil, errors.New("upstream unavailable (503)")
}

// P1 RED (retry spin): with an empty cache and a failing endpoint, one
// verification must make exactly ONE fetch attempt and return unauthorized
// promptly; the failed cold fetch must cooldown exactly like the warm and
// expired-cache paths.
func TestColdFetchFailureCooldownBoundedSingleCaller(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	stub := &failingJWKS{}
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: stub},
		Clock:      clock.Now, RefreshCooldown: time.Minute,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	claims["exp"] = clock.Now().Add(365 * 24 * time.Hour).Unix()
	tok := signToken(t, key, "kid-1", nil, claims)

	ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
	defer cancel()
	start := time.Now()
	if _, err := v.VerifyToken(ctx, tok); err == nil {
		t.Fatal("cold fetch failure must not authorize")
	}
	if elapsed := time.Since(start); elapsed > 400*time.Millisecond {
		t.Fatalf("verification spun until the caller deadline (%v) instead of failing promptly", elapsed)
	}
	if got := stub.n.Load(); got != 1 {
		t.Fatalf("cold fetch failure caused %d fetch attempts within one cooldown, want exactly 1", got)
	}
	// Additional verifications inside the cooldown window stay bounded.
	for i := 0; i < 5; i++ {
		clock.Advance(10 * time.Millisecond)
		if _, err := v.VerifyToken(context.Background(), tok); err == nil {
			t.Fatal("unavailable signing keys must not authorize")
		}
	}
	if got := stub.n.Load(); got != 1 {
		t.Fatalf("in-cooldown verifications caused %d total fetches, want exactly 1", got)
	}

	// Recovery: after the cooldown elapses and the endpoint recovers, the
	// next verification refreshes and succeeds.
	clock.Advance(2 * time.Minute)
	recovered := roundTripperFunc(func(r *http.Request) (*http.Response, error) {
		return jwksHTTPResponse(map[string]*rsa.PrivateKey{"kid-1": key}), nil
	})
	v.client = &http.Client{Transport: recovered}
	if _, err := v.VerifyToken(context.Background(), tok); err != nil {
		t.Fatalf("no recovery after cooldown: %v", err)
	}
}

// P1 RED (concurrent spin): many cold callers against a failing endpoint
// produce exactly one fetch per cooldown, not one per waiter.
func TestColdFetchFailureCooldownBoundedConcurrent(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	stub := &failingJWKS{}
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: stub},
		Clock:      clock.Now, RefreshCooldown: time.Minute,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	claims["exp"] = clock.Now().Add(365 * 24 * time.Hour).Unix()
	tok := signToken(t, key, "kid-1", nil, claims)

	const n = 10
	var wg sync.WaitGroup
	wg.Add(n)
	for i := 0; i < n; i++ {
		go func() {
			defer wg.Done()
			ctx, cancel := context.WithTimeout(context.Background(), 500*time.Millisecond)
			defer cancel()
			_, _ = v.VerifyToken(ctx, tok)
		}()
	}
	wg.Wait()
	if got := stub.n.Load(); got != 1 {
		t.Fatalf("concurrent cold failures caused %d fetch attempts within one cooldown, want exactly 1", got)
	}
}

// waitingVerifier blocks until its authentication context is done and THEN
// returns a valid principal — a boundary that only checks the parent
// request context (or nothing) accepts it.
type waitingVerifier struct {
	principal Principal
}

func (w waitingVerifier) VerifyToken(ctx context.Context, _ string) (Principal, error) {
	<-ctx.Done()
	return w.principal, nil
}

// P2 RED: an injected verifier returning a valid principal only after the
// AUTHENTICATION deadline must be rejected at the boundary, even though the
// parent request context is still alive.
func TestServiceRejectsVerifierThatWaitsPastAuthDeadline(t *testing.T) {
	s, err := NewService(Config{
		Verifier: waitingVerifier{principal: Principal{
			AccountID: "google:" + subA, Email: emailA,
			ExpiresAt: time.Now().Add(time.Hour),
		}},
		Store:       NewMemoryStore(),
		AuthTimeout: 50 * time.Millisecond,
		Logger:      func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-1"})
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("principal returned after auth deadline = %s, want 401", resp.Status)
	}
}
