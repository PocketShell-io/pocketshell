package identity

import (
	"encoding/json"
	"io"
	"net/http"
	"sort"
	"sync"
	"testing"
	"time"
)

// recordingPresence is a presence source double that records every call,
// so tests can prove WHICH account and WHICH devices the handler asked
// about (never another account's, never before authentication).
type recordingPresence struct {
	mu       sync.Mutex
	calls    []presenceCall
	observed time.Time
	live     map[string]DevicePresence // keyed by device ID, any account
}

type presenceCall struct {
	account string
	ids     []string
}

func (r *recordingPresence) source(account string, ids []string) (time.Time, map[string]DevicePresence) {
	r.mu.Lock()
	defer r.mu.Unlock()
	cp := append([]string(nil), ids...)
	sort.Strings(cp)
	r.calls = append(r.calls, presenceCall{account: account, ids: cp})
	out := map[string]DevicePresence{}
	for _, id := range ids {
		if p, ok := r.live[id]; ok {
			out[id] = p
		}
	}
	return r.observed, out
}

func (r *recordingPresence) snapshot() []presenceCall {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]presenceCall(nil), r.calls...)
}

type listedPresence struct {
	Online            bool   `json:"online"`
	ObservedAt        string `json:"observed_at"`
	ConnectedSince    string `json:"connected_since"`
	SessionGeneration uint64 `json:"session_generation"`
}

type listedDevice struct {
	ID       string          `json:"id"`
	Revoked  bool            `json:"revoked"`
	Presence *listedPresence `json:"presence"`
}

func listDevices(t *testing.T, s *Service, token string) (map[string]listedDevice, []byte) {
	t.Helper()
	resp := getJSON(t, s, "/identity/v1/devices", token)
	defer resp.Body.Close()
	raw, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatal(err)
	}
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("list = %s: %s", resp.Status, raw)
	}
	var out struct {
		Devices []listedDevice `json:"devices"`
	}
	if err := json.Unmarshal(raw, &out); err != nil {
		t.Fatal(err)
	}
	m := map[string]listedDevice{}
	for _, d := range out.Devices {
		m[d.ID] = d
	}
	return m, raw
}

func enrollForPresence(t *testing.T, s *Service, token, id string) {
	t.Helper()
	_, priv := newKeyPair(t)
	if resp := runEnrollment(t, s, token, id, priv, testHostKey, false); resp.StatusCode != http.StatusCreated {
		t.Fatalf("enroll %s: %s", id, resp.Status)
	}
}

// Without a wired source the list is byte-for-byte the durable contract:
// presence is ABSENT (unknown), never a fabricated offline.
func TestDeviceListWithoutPresenceSourceOmitsPresence(t *testing.T) {
	s := newTestService(t, nil)
	enrollForPresence(t, s, tokenA, "laptop-1")
	m, raw := listDevices(t, s, tokenA)
	if m["laptop-1"].Presence != nil {
		t.Fatalf("presence must be absent without a source: %s", raw)
	}
	var generic struct {
		Devices []map[string]json.RawMessage `json:"devices"`
	}
	if err := json.Unmarshal(raw, &generic); err != nil {
		t.Fatal(err)
	}
	if _, ok := generic.Devices[0]["presence"]; ok {
		t.Fatalf("presence key emitted without a source: %s", raw)
	}
}

func TestDeviceListPresenceFromSource(t *testing.T) {
	s := newTestService(t, nil)
	enrollForPresence(t, s, tokenA, "laptop-1") // online
	enrollForPresence(t, s, tokenA, "laptop-2") // enrolled, never connected
	enrollForPresence(t, s, tokenA, "laptop-3") // revoked; source still claims online
	enrollForPresence(t, s, tokenB, "bob-box")  // other account, online
	if resp := postJSON(t, s, "/identity/v1/devices/laptop-3/revoke", tokenA, nil); resp.StatusCode != http.StatusOK {
		t.Fatalf("revoke: %s", resp.Status)
	}

	observed := time.Date(2026, 10, 10, 12, 0, 30, 123456789, time.FixedZone("x", 3600))
	since := time.Date(2026, 10, 10, 11, 0, 0, 0, time.UTC)
	rec := &recordingPresence{
		observed: observed,
		live: map[string]DevicePresence{
			"laptop-1": {Online: true, ConnectedSince: since, Session: 3},
			"laptop-3": {Online: true, ConnectedSince: since, Session: 1},
			"bob-box":  {Online: true, ConnectedSince: since, Session: 7},
		},
	}
	s.SetPresenceSource(rec.source)

	// Unauthenticated: 401 and the source is never consulted.
	if resp := getJSON(t, s, "/identity/v1/devices", ""); resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("anonymous list = %s", resp.Status)
	}
	if resp := getJSON(t, s, "/identity/v1/devices", "not-a-token"); resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("bad-token list = %s", resp.Status)
	}
	if n := len(rec.snapshot()); n != 0 {
		t.Fatalf("presence source consulted %d times before authentication", n)
	}

	m, raw := listDevices(t, s, tokenA)
	if len(m) != 3 {
		t.Fatalf("alice sees %d devices: %s", len(m), raw)
	}
	if _, leaked := m["bob-box"]; leaked {
		t.Fatalf("other account's device listed: %s", raw)
	}
	wantObserved := "2026-10-10T11:00:30.123Z" // UTC, millisecond precision
	on := m["laptop-1"].Presence
	if on == nil || !on.Online || on.ObservedAt != wantObserved ||
		on.ConnectedSince != "2026-10-10T11:00:00.000Z" || on.SessionGeneration != 3 {
		t.Fatalf("online device presence = %+v (%s)", on, raw)
	}
	never := m["laptop-2"].Presence
	if never == nil || never.Online || never.ObservedAt != wantObserved || never.ConnectedSince != "" || never.SessionGeneration != 0 {
		t.Fatalf("never-connected device presence = %+v", never)
	}
	rev := m["laptop-3"]
	if !rev.Revoked || rev.Presence == nil || rev.Presence.Online || rev.Presence.ConnectedSince != "" {
		t.Fatalf("revoked device must never be online: %+v", rev)
	}

	// The source was asked only about alice's own devices, under alice's
	// VERIFIED account.
	calls := rec.snapshot()
	if len(calls) != 1 || calls[0].account != "google:"+subA {
		t.Fatalf("presence calls = %+v", calls)
	}
	if got := calls[0].ids; len(got) != 3 || got[0] != "laptop-1" || got[1] != "laptop-2" || got[2] != "laptop-3" {
		t.Fatalf("presence asked about %v", got)
	}

	// Bob sees only his device, online.
	mb, rawB := listDevices(t, s, tokenB)
	if len(mb) != 1 || mb["bob-box"].Presence == nil || !mb["bob-box"].Presence.Online {
		t.Fatalf("bob list: %s", rawB)
	}
}

func TestDeviceListPresenceSkippedForEmptyAccountAndEnrollResponse(t *testing.T) {
	s := newTestService(t, nil)
	rec := &recordingPresence{observed: time.Now()}
	s.SetPresenceSource(rec.source)
	m, _ := listDevices(t, s, tokenA)
	if len(m) != 0 || len(rec.snapshot()) != 0 {
		t.Fatalf("empty account: devices=%d calls=%d", len(m), len(rec.snapshot()))
	}
	// Enroll responses are the durable record only.
	_, priv := newKeyPair(t)
	resp := runEnrollment(t, s, tokenA, "laptop-9", priv, testHostKey, false)
	defer resp.Body.Close()
	var generic map[string]json.RawMessage
	if err := json.NewDecoder(resp.Body).Decode(&generic); err != nil {
		t.Fatal(err)
	}
	if _, ok := generic["presence"]; ok {
		t.Fatal("enroll response carries presence")
	}
}

// A source that returns a zero observation time still yields a usable,
// gateway-clock observed_at rather than the zero time.
func TestDeviceListPresenceZeroObservedFallsBackToClock(t *testing.T) {
	fixed := time.Now().UTC().Truncate(time.Millisecond)
	s := newTestService(t, func(c *Config) { c.Clock = func() time.Time { return fixed } })
	s.SetPresenceSource(func(string, []string) (time.Time, map[string]DevicePresence) {
		return time.Time{}, nil
	})
	enrollForPresence(t, s, tokenA, "laptop-1")
	m, raw := listDevices(t, s, tokenA)
	p := m["laptop-1"].Presence
	if p == nil || p.Online || p.ObservedAt != fixed.Format("2006-01-02T15:04:05.000Z07:00") {
		t.Fatalf("fallback presence = %+v (%s)", p, raw)
	}
}
