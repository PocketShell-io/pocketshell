package identity

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

// Defaults for the HTTP service bounds.
const (
	DefaultMaxBodyBytes             = 32 << 10 // 32 KiB per request body
	DefaultMaxDevicesPerAccount     = 32
	DefaultMaxOutstandingChallenges = 16
	DefaultChallengeTTL             = 2 * time.Minute
	DefaultAuthTimeout              = 10 * time.Second
	// enrollmentDomain is used in transcripts when Config.Domain is unset.
	enrollmentDomain = "pocketshell-identity"
)

// Config configures a Service. Either Verifier or ClientID must be set, and
// either Store or StorePath must be set — a service without a durable
// registry refuses to start (fail closed). Allowlist keeps the legacy
// rollout semantics: empty denies everyone.
type Config struct {
	// ClientID is the Google OAuth audience. Required unless Verifier is set.
	ClientID string
	// JWKSURL overrides Google's JWKS endpoint (tests only; empty uses the
	// Google default).
	JWKSURL string
	// JWKSMaxStaleAge bounds how long cached signing keys are trusted when
	// refreshes keep failing (default 24h).
	JWKSMaxStaleAge time.Duration
	// Allowlist of verified emails; empty denies all.
	Allowlist []string
	// HTTPClient is used for JWKS fetches.
	HTTPClient *http.Client
	// Verifier replaces the Google verifier (tests, alternative IdPs).
	Verifier TokenVerifier

	// StorePath enables the durable file registry at this path.
	StorePath string
	// Store injects a registry directly (overrides StorePath). It MUST
	// implement AuthorizedStore: NewService refuses plain DeviceStore
	// implementations, because the final under-lock admission gate cannot be
	// guaranteed around a store whose internals may block arbitrarily
	// (a check evaluated before an opaque call says nothing about the state
	// after the call returns).
	Store DeviceStore

	// Domain is the canonical gateway hostname (e.g. gateway.pocketshell.io).
	// When set, requests whose Host differs are rejected and the domain is
	// bound into every challenge transcript.
	Domain string
	// AllowReenrollment gates explicit key/host-key replacement. Default
	// off: no mutable key replacement, period.
	AllowReenrollment bool
	// MaxDevicesPerAccount bounds admissions (default 32). It is enforced
	// atomically inside the store, so concurrent enrollments cannot exceed
	// it.
	MaxDevicesPerAccount int
	// ChallengeTTL is the challenge lifetime (default 2m).
	ChallengeTTL time.Duration
	// MaxOutstandingChallenges per account (default 16).
	MaxOutstandingChallenges int
	// MaxOutstandingChallengesGlobal bounds live challenges across all
	// accounts (default 4096).
	MaxOutstandingChallengesGlobal int
	// MaxBodyBytes bounds request bodies (default 32 KiB).
	MaxBodyBytes int64
	// Leeway tolerates clock skew in token verification (default 30s).
	Leeway time.Duration
	// AuthTimeout bounds token verification per request (default 10s).
	AuthTimeout time.Duration
	// RequestReadDeadline bounds reading the request body via the actual
	// network deadline (http.ResponseController.SetReadDeadline) when the
	// server's own ReadTimeout does not already cover identity routes.
	// Zero (default) leaves the deadline to the HTTP server; on writers
	// without deadline support the setting is ignored. Production MUST
	// provide this bound at one of the two layers: the strict body decoder
	// waits for the definitive end of the body, so a body stalled forever
	// without a network deadline holds the request forever.
	RequestReadDeadline time.Duration
	// Clock overrides time.Now (tests).
	Clock func() time.Time
	// Logger defaults to the standard logger; never receives secrets.
	Logger func(format string, args ...any)
}

// Service serves the identity HTTP API and exposes the contract surface for
// the tunnel worker: TokenAuthenticator, Store and revocation callbacks.
type Service struct {
	verifier   TokenVerifier
	store      AuthorizedStore // every service store enforces admission checks
	challenges *ChallengeIssuer
	cfg        Config
	domain     string
	logger     func(string, ...any)
	clock      func() time.Time

	revokeMu  sync.Mutex
	revokeFns []func(Device)

	presenceMu sync.Mutex
	presence   PresenceSource
}

// DevicePresence is one device's live host-agent state as reported by the
// presence source (the tunnel service, via root wiring). ConnectedSince and
// Session are meaningful only when Online.
type DevicePresence struct {
	Online         bool
	ConnectedSince time.Time
	Session        uint64
}

// PresenceSource reports the live presence of the listed devices of one
// account in a single consistent snapshot, plus the gateway time the
// snapshot was taken. It must be fast and non-blocking (it runs on the
// list request path) and must report a device online only when its
// current host session is ready and belongs to accountID.
type PresenceSource func(accountID string, deviceIDs []string) (observedAt time.Time, presence map[string]DevicePresence)

// SetPresenceSource attaches the live presence source consulted by
// GET /identity/v1/devices. Without one (tunnel disabled or not wired) the
// list response carries no presence fields at all: absent means UNKNOWN,
// never offline.
func (s *Service) SetPresenceSource(src PresenceSource) {
	s.presenceMu.Lock()
	defer s.presenceMu.Unlock()
	s.presence = src
}

func (s *Service) presenceSource() PresenceSource {
	s.presenceMu.Lock()
	defer s.presenceMu.Unlock()
	return s.presence
}

// NewService validates the configuration and constructs the service.
func NewService(cfg Config) (*Service, error) {
	logger := cfg.Logger
	if logger == nil {
		logger = func(format string, args ...any) { log.Printf("identity: "+format, args...) }
	}
	clock := cfg.Clock
	if clock == nil {
		clock = time.Now
	}

	// Normalize bounds before anything consumes them.
	if cfg.MaxDevicesPerAccount <= 0 {
		cfg.MaxDevicesPerAccount = DefaultMaxDevicesPerAccount
	}
	if cfg.ChallengeTTL <= 0 {
		cfg.ChallengeTTL = DefaultChallengeTTL
	}
	if cfg.MaxOutstandingChallenges <= 0 {
		cfg.MaxOutstandingChallenges = DefaultMaxOutstandingChallenges
	}
	if cfg.MaxOutstandingChallengesGlobal <= 0 {
		cfg.MaxOutstandingChallengesGlobal = 4096
	}
	if cfg.MaxBodyBytes <= 0 {
		cfg.MaxBodyBytes = DefaultMaxBodyBytes
	}
	if cfg.AuthTimeout <= 0 {
		cfg.AuthTimeout = DefaultAuthTimeout
	}

	var verifier TokenVerifier
	if cfg.Verifier != nil {
		verifier = cfg.Verifier
	} else {
		v, err := NewGoogleVerifier(GoogleConfig{
			ClientID:    cfg.ClientID,
			JWKSURL:     cfg.JWKSURL,
			Allowlist:   cfg.Allowlist,
			HTTPClient:  cfg.HTTPClient,
			Clock:       clock,
			Leeway:      cfg.Leeway,
			MaxStaleAge: cfg.JWKSMaxStaleAge,
			Logger:      logger,
		})
		if err != nil {
			return nil, err
		}
		verifier = v
	}

	var store AuthorizedStore
	if cfg.Store != nil {
		// Fail closed at construction: only admission-capable stores are
		// accepted. An opaque DeviceStore cannot carry the final gate — its
		// Count/Replace/Revoke/List internals may block arbitrarily, and a
		// check evaluated before such a call proves nothing about the state
		// when the call finally returns (round-nine P1). Injected
		// AuthorizedStore implementations keep the quota decorator (I2),
		// which forwards every check into the inner store's actual
		// mutation/list lock, where it runs again as the final gate.
		authorized, ok := cfg.Store.(AuthorizedStore)
		if !ok {
			return nil, errors.New("identity: injected store must implement AuthorizedStore " +
				"(PutAdmitted/ReplaceAdmitted/ListAdmitted/RevokeAdmitted); a plain DeviceStore " +
				"cannot guarantee the final under-lock admission gate")
		}
		store = &quotaStore{inner: authorized, maxPerAccount: cfg.MaxDevicesPerAccount}
	} else if cfg.StorePath != "" {
		fs, err := NewFileStore(cfg.StorePath, WithLimits(Limits{
			MaxPerAccount: cfg.MaxDevicesPerAccount,
		}))
		if err != nil {
			return nil, err
		}
		store = fs
	} else {
		return nil, errors.New("identity: durable registry required: set StorePath or Store")
	}

	domain := cfg.Domain
	if domain == "" {
		domain = enrollmentDomain
	}
	if len(domain) > 253 {
		return nil, errors.New("identity: domain too long")
	}

	return &Service{
		verifier: verifier,
		store:    store,
		challenges: NewChallengeIssuer(cfg.ChallengeTTL, cfg.MaxOutstandingChallenges, clock,
			WithGlobalMax(cfg.MaxOutstandingChallengesGlobal)),
		cfg:    cfg,
		domain: domain,
		logger: logger,
		clock:  clock,
	}, nil
}

// TokenAuthenticator returns the contract Authenticate function backed by
// the configured verifier. The tunnel worker uses it for the first
// WebSocket auth frame (never query params).
func (s *Service) TokenAuthenticator() Authenticate {
	return s.verifier.VerifyToken
}

// Store returns the read-only device lookup for the tunnel worker.
func (s *Service) Store() Store { return s.store }

// DeviceStore returns the full registry (read and mutate). It always
// satisfies AuthorizedStore: mutations and list disclosures made through it
// can enforce an admission check (see AuthorizedStore, ValidAdmission).
// Callers without a request admission context pass a nil check.
func (s *Service) DeviceStore() DeviceStore { return s.store }

// Handler returns the identity HTTP API as an http.Handler.
func (s *Service) Handler() http.Handler { return s }

// OnRevoke registers a callback fired after a revocation is durably
// persisted (persist-before-notify). Callbacks must be fast and must not
// block; a panic in one is recovered and logged, never propagated.
func (s *Service) OnRevoke(fn func(Device)) {
	s.revokeMu.Lock()
	defer s.revokeMu.Unlock()
	s.revokeFns = append(s.revokeFns, fn)
}

func (s *Service) notifyRevoke(dev Device) {
	s.revokeMu.Lock()
	fns := make([]func(Device), len(s.revokeFns))
	copy(fns, s.revokeFns)
	s.revokeMu.Unlock()
	for _, fn := range fns {
		func() {
			defer func() {
				if r := recover(); r != nil {
					s.logger("revoke callback panicked: %v", r)
				}
			}()
			fn(dev)
		}()
	}
}

// --- HTTP API --------------------------------------------------------------

// fail logs the internal cause and answers with a constant 500.
func (s *Service) fail(w http.ResponseWriter, what string, err error) {
	s.logger("%s error: %v", what, err)
	writeJSONError(w, http.StatusInternalServerError, "internal error")
}

func (s *Service) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	// JSON API only; no cookies, no caching of authenticated responses.
	w.Header().Set("Cache-Control", "no-store")

	path := r.URL.Path
	switch {
	case path == "/identity/v1/challenge" && r.Method == http.MethodPost:
		s.handleChallenge(w, r)
	case path == "/identity/v1/enroll" && r.Method == http.MethodPost:
		s.handleEnroll(w, r)
	case path == "/identity/v1/devices" && r.Method == http.MethodGet:
		s.handleList(w, r)
	case strings.HasPrefix(path, "/identity/v1/devices/") && strings.HasSuffix(path, "/revoke") && r.Method == http.MethodPost:
		id := strings.TrimSuffix(strings.TrimPrefix(path, "/identity/v1/devices/"), "/revoke")
		s.handleRevoke(w, r, id)
	case path == "/identity/v1/challenge" || path == "/identity/v1/enroll" ||
		path == "/identity/v1/devices" ||
		(strings.HasPrefix(path, "/identity/v1/devices/") && strings.HasSuffix(path, "/revoke")):
		w.Header().Set("Allow", allowForPath(path))
		writeJSONError(w, http.StatusMethodNotAllowed, "method not allowed")
	default:
		writeJSONError(w, http.StatusNotFound, "not found")
	}
}

func allowForPath(path string) string {
	if path == "/identity/v1/devices" {
		return "GET"
	}
	return "POST"
}

// apiError pairs an HTTP status with a client-safe message.
type apiError struct {
	status  int
	message string
}

// quotaStore decorates an injected AuthorizedStore with the service-
// configured per-account quota. The check, the quota count and the
// insertion happen under one decorator lock, so concurrent enrollments
// cannot exceed the limit even when the inner store enforces no bound of
// its own (I2). Every admitted call FORWARDS the check to the inner store,
// which re-runs it under its own mutation/list lock as the final gate —
// this is the only configuration with an atomicity guarantee: a store
// whose internals can block arbitrarily is refused at NewService
// (round-nine P1), not decorated in a way that only looks safe.
type quotaStore struct {
	inner         AuthorizedStore
	maxPerAccount int
	mu            sync.Mutex
}

func (q *quotaStore) GetDevice(id string) (Device, error) { return q.inner.GetDevice(id) }

func (q *quotaStore) Put(dev Device) error { return q.PutAdmitted(nil, dev) }

func (q *quotaStore) PutAdmitted(check AdmissionCheck, dev Device) error {
	// The decorator lock spans check + quota count + inner call: the count
	// and the insertion stay atomic against other enrollments (I2), and no
	// other service mutation can slip between the admission decision and
	// the call. The inner store then re-runs the check under its own lock
	// as the final gate, covering any wait queued there.
	q.mu.Lock()
	defer q.mu.Unlock()
	if err := admitUnderLock(check); err != nil {
		return err
	}
	if q.maxPerAccount > 0 {
		n, err := q.inner.Count(dev.AccountID)
		if err != nil {
			return err
		}
		if n >= q.maxPerAccount {
			return ErrAccountQuotaExceeded
		}
	}
	return q.inner.PutAdmitted(check, dev)
}

func (q *quotaStore) Replace(dev Device) (Device, bool, error) { return q.ReplaceAdmitted(nil, dev) }

func (q *quotaStore) ReplaceAdmitted(check AdmissionCheck, dev Device) (Device, bool, error) {
	if err := admitUnderLock(check); err != nil {
		return Device{}, false, err
	}
	return q.inner.ReplaceAdmitted(check, dev)
}

func (q *quotaStore) List(accountID string) ([]Device, error) { return q.ListAdmitted(nil, accountID) }

func (q *quotaStore) ListAdmitted(check AdmissionCheck, accountID string) ([]Device, error) {
	if err := admitUnderLock(check); err != nil {
		return nil, err
	}
	return q.inner.ListAdmitted(check, accountID)
}

func (q *quotaStore) Count(accountID string) (int, error) { return q.inner.Count(accountID) }

func (q *quotaStore) Revoke(id, accountID string) (Device, []Device, bool, error) {
	return q.RevokeAdmitted(nil, id, accountID)
}

func (q *quotaStore) RevokeAdmitted(check AdmissionCheck, id, accountID string) (Device, []Device, bool, error) {
	if err := admitUnderLock(check); err != nil {
		return Device{}, nil, false, err
	}
	return q.inner.RevokeAdmitted(check, id, accountID)
}

var _ AuthorizedStore = (*quotaStore)(nil)

// ValidAdmission is the standard production admission rule: the request
// context must still be alive and the principal must carry a strictly
// future expiry at the current clock — a zero expiry never admits. It is
// the check stores consult under their mutation lock and handlers consult
// at request admission; root consumers build one per authenticated request.
func ValidAdmission(ctx context.Context, now func() time.Time, p Principal) error {
	if err := ctx.Err(); err != nil {
		return fmt.Errorf("%w: request context done: %v", ErrAdmissionDenied, err)
	}
	if now == nil {
		now = time.Now
	}
	if p.ExpiresAt.IsZero() {
		return fmt.Errorf("%w: principal has no expiry", ErrAdmissionDenied)
	}
	if !p.ExpiresAt.After(now()) {
		return fmt.Errorf("%w: principal expired at %s", ErrAdmissionDenied, p.ExpiresAt.UTC().Format(time.RFC3339))
	}
	return nil
}

// admission returns the per-request authorization gate consulted at every
// admission point (after the body, after slow lookups, and as the store's
// final pre-mutation gate under its lock). It evaluates the CURRENT request
// context and clock on every call — not the values seen at authentication.
func (s *Service) admission(r *http.Request, p Principal) AdmissionCheck {
	ctx := r.Context()
	return func() error { return ValidAdmission(ctx, s.clock, p) }
}

// authenticate extracts and verifies the bearer token with a per-request
// timeout. All failures are 401 with a constant message.
func (s *Service) authenticate(r *http.Request) (Principal, *apiError) {
	auth := r.Header.Get("Authorization")
	const prefix = "Bearer "
	if !strings.HasPrefix(auth, prefix) {
		return Principal{}, &apiError{http.StatusUnauthorized, "missing bearer token"}
	}
	token := strings.TrimPrefix(auth, prefix)
	if token == "" || len(token) > 8192 {
		return Principal{}, &apiError{http.StatusUnauthorized, "invalid bearer token"}
	}
	ctx, cancel := context.WithTimeout(r.Context(), s.cfg.AuthTimeout)
	defer cancel()
	principal, err := s.verifier.VerifyToken(ctx, token)
	if err != nil {
		if !errors.Is(err, ErrUnauthorized) {
			s.logger("token verify error: %v", err)
		}
		return Principal{}, &apiError{http.StatusUnauthorized, "invalid bearer token"}
	}
	// Expiry boundary (round-three #6): verification may have waited on a
	// JWKS fetch, so recheck the AUTHENTICATION context (deadline plus
	// parent cancellation) and the current clock before authorizing any
	// management operation. Checking only the parent request context would
	// accept a verifier that returns a valid principal after its
	// authentication deadline has already passed (round-six P2).
	if ctx.Err() != nil {
		s.logger("auth rejected: authentication deadline exceeded or canceled")
		return Principal{}, &apiError{http.StatusUnauthorized, "invalid bearer token"}
	}
	if principal.ExpiresAt.IsZero() {
		// Never trust a zero lifetime: the production Google verifier always
		// populates ExpiresAt; zero means a stub or misconfigured verifier.
		// Test doubles must carry explicit positive expiry.
		s.logger("auth rejected: verifier returned zero expiry")
		return Principal{}, &apiError{http.StatusUnauthorized, "invalid bearer token"}
	}
	if !principal.ExpiresAt.After(s.clock()) {
		s.logger("auth rejected: principal expired at boundary")
		return Principal{}, &apiError{http.StatusUnauthorized, "invalid bearer token"}
	}
	if !ValidAccountID(principal.AccountID) {
		s.logger("verifier returned malformed account id")
		return Principal{}, &apiError{http.StatusUnauthorized, "invalid bearer token"}
	}
	return principal, nil
}

type challengeRequest struct {
	DeviceID string `json:"device_id"`
}

type challengeResponse struct {
	ChallengeID     string `json:"challenge_id"`
	DeviceID        string `json:"device_id"`
	AccountID       string `json:"account_id"`
	Nonce           string `json:"nonce"`
	ConnectionNonce string `json:"connection_nonce"`
	ExpiresAt       int64  `json:"expires_at"`
	Domain          string `json:"domain"`
	Role            string `json:"role"`
	Protocol        string `json:"protocol"`
	// Transcript carries the INNER challenge transcript (base64 std) for
	// binding reference and cross-checks via ChallengeFromWire. It is NOT
	// the enrollment signing input: enrollment signatures are produced by
	// SignEnrollment over the enrollment transcript (challenge bindings
	// plus the submitted public key, SSH host key and re-enroll mode).
	Transcript string `json:"transcript"`
}

func (s *Service) handleChallenge(w http.ResponseWriter, r *http.Request) {
	principal, apiErr := s.authenticate(r)
	if apiErr != nil {
		writeJSONError(w, apiErr.status, apiErr.message)
		return
	}
	admit := s.admission(r, principal)
	if err := s.enforceHost(r); err != nil {
		writeJSONError(w, http.StatusForbidden, "wrong host")
		return
	}
	var req challengeRequest
	if apiErr := decodeStrict(w, r, &req, s.cfg.MaxBodyBytes, s.cfg.RequestReadDeadline); apiErr != nil {
		writeJSONError(w, apiErr.status, apiErr.message)
		return
	}
	// Admission at the actual request admission point: the body may have
	// taken arbitrarily long, so the authorization verified at header time
	// is rechecked NOW, before the challenge is issued.
	if err := admit(); err != nil {
		s.logger("challenge admission denied: account=%s: %v", principal.AccountID, err)
		writeJSONError(w, http.StatusUnauthorized, "invalid bearer token")
		return
	}
	if !ValidDeviceID(req.DeviceID) {
		writeJSONError(w, http.StatusBadRequest, "invalid device_id")
		return
	}
	ch, err := s.challenges.Issue(ChallengeParams{
		AccountID: principal.AccountID,
		DeviceID:  req.DeviceID,
		Role:      RoleEnroll,
		Protocol:  ProtocolIdentity,
		Domain:    s.domain,
	})
	if err != nil {
		if errors.Is(err, ErrBadRequest) {
			writeJSONError(w, http.StatusBadRequest, "invalid challenge request")
			return
		}
		if errors.Is(err, ErrLimitExceeded) {
			writeJSONError(w, http.StatusTooManyRequests, "too many pending challenges")
			return
		}
		s.fail(w, "challenge", err)
		return
	}
	t, err := ch.Transcript()
	if err != nil {
		s.fail(w, "challenge transcript", err)
		return
	}
	writeJSON(w, http.StatusOK, challengeResponse{
		ChallengeID:     ch.ID,
		DeviceID:        ch.DeviceID,
		AccountID:       ch.AccountID,
		Nonce:           ch.Nonce,
		ConnectionNonce: ch.ConnectionNonce,
		ExpiresAt:       ch.ExpiresAt.Unix(),
		Domain:          ch.Domain,
		Role:            ch.Role,
		Protocol:        ch.Protocol,
		Transcript:      base64.StdEncoding.EncodeToString(t),
	})
}

type enrollRequest struct {
	DeviceID    string `json:"device_id"`
	PublicKey   string `json:"public_key"`   // base64 (std) of raw 32-byte Ed25519 public key
	SSHHostKey  string `json:"ssh_host_key"` // pinned OpenSSH public host key line
	ChallengeID string `json:"challenge_id"`
	Signature   string `json:"signature"` // base64 (std) Ed25519 signature over the transcript
	Reenroll    bool   `json:"re_enroll"`
}

type deviceJSON struct {
	ID         string `json:"id"`
	AccountID  string `json:"account_id"`
	PublicKey  string `json:"public_key"`
	SSHHostKey string `json:"ssh_host_key"`
	Revoked    bool   `json:"revoked"`
	// Presence is additive and only present on list responses when a
	// presence source is wired; enroll responses never carry it.
	Presence *presenceJSON `json:"presence,omitempty"`
}

// presenceJSON is the live host-agent state of a listed device. Times are
// RFC 3339 UTC with millisecond precision, gateway clock. connected_since
// and session_generation are present only while online.
type presenceJSON struct {
	Online            bool   `json:"online"`
	ObservedAt        string `json:"observed_at"`
	ConnectedSince    string `json:"connected_since,omitempty"`
	SessionGeneration uint64 `json:"session_generation,omitempty"`
}

// presenceTimeLayout is RFC 3339 with fixed millisecond precision.
const presenceTimeLayout = "2006-01-02T15:04:05.000Z07:00"

// toPresenceJSON renders one device's presence. A durably revoked device is
// never online, whatever the source reports (the tunnel unpublishes on the
// revoke callback, but the store is the authority on revocation).
func toPresenceJSON(d Device, observedAt time.Time, p DevicePresence, known bool) *presenceJSON {
	out := &presenceJSON{ObservedAt: observedAt.UTC().Format(presenceTimeLayout)}
	if d.Revoked || !known || !p.Online {
		return out
	}
	out.Online = true
	if !p.ConnectedSince.IsZero() {
		out.ConnectedSince = p.ConnectedSince.UTC().Format(presenceTimeLayout)
	}
	out.SessionGeneration = p.Session
	return out
}

func toDeviceJSON(d Device) deviceJSON {
	return deviceJSON{
		ID:         d.ID,
		AccountID:  d.AccountID,
		PublicKey:  base64.StdEncoding.EncodeToString(d.PublicKey),
		SSHHostKey: d.SSHHostKey,
		Revoked:    d.Revoked,
	}
}

func (s *Service) handleEnroll(w http.ResponseWriter, r *http.Request) {
	principal, apiErr := s.authenticate(r)
	if apiErr != nil {
		writeJSONError(w, apiErr.status, apiErr.message)
		return
	}
	admit := s.admission(r, principal)
	if err := s.enforceHost(r); err != nil {
		writeJSONError(w, http.StatusForbidden, "wrong host")
		return
	}
	var req enrollRequest
	if apiErr := decodeStrict(w, r, &req, s.cfg.MaxBodyBytes, s.cfg.RequestReadDeadline); apiErr != nil {
		writeJSONError(w, apiErr.status, apiErr.message)
		return
	}
	// Admission after the body: a slow body must not extend a lapsed
	// authorization, and a denied request must not burn the single-use
	// challenge (the gate below precedes Consume).
	if err := admit(); err != nil {
		s.logger("enroll admission denied: account=%s: %v", principal.AccountID, err)
		writeJSONError(w, http.StatusUnauthorized, "invalid bearer token")
		return
	}
	if !ValidDeviceID(req.DeviceID) {
		writeJSONError(w, http.StatusBadRequest, "invalid device_id")
		return
	}
	pub, err := base64.StdEncoding.DecodeString(req.PublicKey)
	if err != nil || !ValidPublicKey(pub) {
		writeJSONError(w, http.StatusBadRequest, "public_key must be base64 of a raw 32-byte Ed25519 public key")
		return
	}
	if !ValidSSHHostKey(req.SSHHostKey) {
		writeJSONError(w, http.StatusBadRequest, "invalid ssh_host_key")
		return
	}
	sig, err := base64.StdEncoding.DecodeString(req.Signature)
	if err != nil || len(sig) != ed25519.SignatureSize {
		writeJSONError(w, http.StatusBadRequest, "invalid signature encoding")
		return
	}

	// Single-use consume happens before any state decision: a failed or
	// replayed enrollment attempt burns the challenge.
	ch, err := s.challenges.Consume(req.ChallengeID)
	if err != nil {
		writeJSONError(w, http.StatusUnauthorized, "invalid or expired challenge")
		return
	}
	if ch.AccountID != principal.AccountID || ch.DeviceID != req.DeviceID ||
		ch.Role != RoleEnroll || ch.Protocol != ProtocolIdentity {
		writeJSONError(w, http.StatusBadRequest, "challenge does not match enrollment")
		return
	}
	// Proof of possession over the FULL payload: the signature must cover
	// the challenge binding plus the submitted public key, SSH host key and
	// re-enrollment mode (v2 format; the bare challenge transcript is
	// rejected — no legacy fallback). The store only ever sees keys whose
	// holder signed these exact values.
	if err := VerifyEnrollment(ed25519.PublicKey(pub), ch, req.SSHHostKey, req.Reenroll, sig); err != nil {
		s.logger("enroll proof failed: account=%s device=%s", principal.AccountID, req.DeviceID)
		writeJSONError(w, http.StatusUnauthorized, "proof of possession failed")
		return
	}

	existing, getErr := s.store.GetDevice(req.DeviceID)
	if getErr != nil && !errors.Is(getErr, ErrDeviceNotFound) {
		s.fail(w, "enroll lookup", getErr)
		return
	}
	// Admission after the lookup: an injected (or contended) store may take
	// arbitrarily long to answer, so the authorization is rechecked against
	// the current clock and context before ANY decision or mutation below.
	// The mutations themselves carry the same gate again INSIDE the store
	// lock (AuthorizedStore), covering the wait on a contended lock.
	if err := admit(); err != nil {
		s.logger("enroll admission denied after lookup: account=%s device=%s: %v", principal.AccountID, req.DeviceID, err)
		writeJSONError(w, http.StatusUnauthorized, "invalid bearer token")
		return
	}
	if getErr == nil {
		// Any mutation of an existing device is rejected unless it is the
		// owner explicitly re-enrolling; a revoked device is never revived.
		if existing.AccountID != principal.AccountID {
			s.logger("enroll rejected: device %q owned by another account", req.DeviceID)
			writeJSONError(w, http.StatusForbidden, "device id taken")
			return
		}
		if existing.Revoked {
			writeJSONError(w, http.StatusConflict, "device is revoked; enroll a new device")
			return
		}
		if sameKey(existing.PublicKey, pub) && existing.SSHHostKey == req.SSHHostKey {
			// Idempotent re-enrollment must still prove durability before
			// acknowledging: route the no-op through Replace, which flushes
			// any pending uncertainty. A 200 here means the applied state is
			// durable, not merely present.
			if _, _, rerr := s.store.ReplaceAdmitted(admit, existing); rerr != nil {
				if errors.Is(rerr, ErrAdmissionDenied) {
					s.logger("enroll admission denied at store gate: account=%s device=%s: %v", principal.AccountID, req.DeviceID, rerr)
					writeJSONError(w, http.StatusUnauthorized, "invalid bearer token")
					return
				}
				if errors.Is(rerr, ErrDurabilityUncertain) {
					s.logger("idempotent enroll durability uncertain: account=%s device=%s: %v", principal.AccountID, req.DeviceID, rerr)
					writeJSONError(w, http.StatusInternalServerError, "enrollment not acknowledged; retry")
					return
				}
				if errors.Is(rerr, ErrDeviceRevoked) {
					// Inherited revocation landed between the lookup and the
					// flush: fail closed.
					writeJSONError(w, http.StatusConflict, "device is revoked; enroll a new device")
					return
				}
				s.fail(w, "idempotent enroll", rerr)
				return
			}
			writeJSON(w, http.StatusOK, toDeviceJSON(existing))
			return
		}
		if !req.Reenroll {
			writeJSONError(w, http.StatusConflict, "device already enrolled with a different key; explicit re-enrollment required")
			return
		}
		if !s.cfg.AllowReenrollment {
			writeJSONError(w, http.StatusForbidden, "re-enrollment is disabled on this gateway")
			return
		}
		updated := Device{
			ID:         existing.ID,
			AccountID:  existing.AccountID,
			PublicKey:  pub,
			SSHHostKey: req.SSHHostKey,
			Revoked:    false,
		}
		if _, _, rerr := s.replaceDevice(admit, existing, updated); rerr != nil {
			// A revoke that raced the re-enrollment wins: revocation is
			// terminal and the replace is refused by the store.
			if errors.Is(rerr, ErrAdmissionDenied) {
				s.logger("enroll admission denied at store gate: account=%s device=%s: %v", principal.AccountID, req.DeviceID, rerr)
				writeJSONError(w, http.StatusUnauthorized, "invalid bearer token")
				return
			}
			if errors.Is(rerr, ErrDeviceRevoked) {
				writeJSONError(w, http.StatusConflict, "device is revoked; enroll a new device")
				return
			}
			if errors.Is(rerr, ErrPublicKeyRevoked) {
				writeJSONError(w, http.StatusForbidden, "public key has been revoked")
				return
			}
			if errors.Is(rerr, ErrDuplicateKey) {
				writeJSONError(w, http.StatusConflict, "public key already enrolled")
				return
			}
			if errors.Is(rerr, ErrDurabilityUncertain) {
				// Replacement applied (containment for the old key already
				// fired) but durability unproven: never acknowledge. Retries
				// re-attempt the flush.
				s.logger("enroll replace durability uncertain: account=%s device=%s: %v", principal.AccountID, req.DeviceID, rerr)
				writeJSONError(w, http.StatusInternalServerError, "re-enrollment not acknowledged; retry")
				return
			}
			s.fail(w, "enroll replace", rerr)
			return
		}
		s.logger("device re-enrolled: account=%s device=%s", principal.AccountID, req.DeviceID)
		writeJSON(w, http.StatusOK, deviceJSON(toDeviceJSON(updated)))
		return
	}

	count, err := s.store.Count(principal.AccountID)
	if err != nil {
		s.fail(w, "enroll count", err)
		return
	}
	if count >= s.cfg.MaxDevicesPerAccount {
		s.logger("enroll rejected: device quota exceeded for account=%s", principal.AccountID)
		writeJSONError(w, http.StatusForbidden, "device quota exceeded")
		return
	}
	dev := Device{
		ID:         req.DeviceID,
		AccountID:  principal.AccountID,
		PublicKey:  pub,
		SSHHostKey: req.SSHHostKey,
	}
	if err := s.store.PutAdmitted(admit, dev); err != nil {
		if errors.Is(err, ErrAdmissionDenied) {
			// The final gate under the store lock denied: the authorization
			// lapsed between the lookup and the mutation (e.g. the request
			// queued behind another write). Nothing was applied.
			s.logger("enroll admission denied at store gate: account=%s device=%s: %v", principal.AccountID, req.DeviceID, err)
			writeJSONError(w, http.StatusUnauthorized, "invalid bearer token")
			return
		}
		if errors.Is(err, ErrDeviceIDTaken) {
			writeJSONError(w, http.StatusConflict, "device id taken")
			return
		}
		if errors.Is(err, ErrPublicKeyRevoked) {
			// Durable tombstone: a revoked registration key can never come
			// back under a new device ID.
			s.logger("enroll rejected: revoked key for account=%s device=%s", principal.AccountID, req.DeviceID)
			writeJSONError(w, http.StatusForbidden, "public key has been revoked")
			return
		}
		if errors.Is(err, ErrDuplicateKey) {
			writeJSONError(w, http.StatusConflict, "public key already enrolled")
			return
		}
		if errors.Is(err, ErrAccountQuotaExceeded) || errors.Is(err, ErrLimitExceeded) {
			writeJSONError(w, http.StatusForbidden, "device quota exceeded")
			return
		}
		if errors.Is(err, ErrDurabilityUncertain) {
			// Applied but not proven durable: no acknowledgment. The client
			// retries with a fresh challenge; GetDevice shows the truth.
			s.logger("enroll durability uncertain: account=%s device=%s: %v", principal.AccountID, req.DeviceID, err)
			writeJSONError(w, http.StatusInternalServerError, "enrollment not acknowledged; retry")
			return
		}
		s.fail(w, "enroll put", err)
		return
	}
	s.logger("device enrolled: account=%s device=%s", principal.AccountID, req.DeviceID)
	writeJSON(w, http.StatusCreated, deviceJSON(toDeviceJSON(dev)))
}

// replaceDevice performs the explicit trusted re-enrollment: the store's
// Replace swaps the pinned key/host key atomically for the same owner, and
// the admission check is enforced as the final gate under the store lock.
// Containment for the ORIGINAL device (old key) fires on every path where
// the replacement is applied — durable success AND uncertain failure — so
// old-key sessions are torn down immediately; on uncertainty the HTTP layer
// still reports an error and retries re-attempt the flush (no durable-
// success response until proven).
func (s *Service) replaceDevice(check AdmissionCheck, old, updated Device) (previous Device, acknowledged bool, err error) {
	previous, acknowledged, err = s.store.ReplaceAdmitted(check, updated)
	if err != nil {
		if errors.Is(err, ErrDurabilityUncertain) && previous.ID != "" {
			s.notifyRevoke(previous)
		}
		return previous, false, err
	}
	if acknowledged {
		s.notifyRevoke(previous)
	}
	return previous, acknowledged, nil
}

func (s *Service) handleList(w http.ResponseWriter, r *http.Request) {
	principal, apiErr := s.authenticate(r)
	if apiErr != nil {
		writeJSONError(w, apiErr.status, apiErr.message)
		return
	}
	admit := s.admission(r, principal)
	if err := s.enforceHost(r); err != nil {
		writeJSONError(w, http.StatusForbidden, "wrong host")
		return
	}
	// ListAdmitted gates the DISCLOSURE under the store lock: devices are
	// only copied out for an authorization that is valid at that instant.
	devices, err := s.store.ListAdmitted(admit, principal.AccountID)
	if err != nil {
		if errors.Is(err, ErrAdmissionDenied) {
			s.logger("list admission denied: account=%s: %v", principal.AccountID, err)
			writeJSONError(w, http.StatusUnauthorized, "invalid bearer token")
			return
		}
		s.fail(w, "list", err)
		return
	}
	if devices == nil {
		devices = []Device{}
	}
	out := make([]deviceJSON, 0, len(devices))
	for _, d := range devices {
		out = append(out, toDeviceJSON(d))
	}
	// Presence is snapshotted AFTER the admitted disclosure, only for the
	// caller's own listed devices (the account comes from the verified
	// principal, never the request), in one consistent source snapshot.
	if src := s.presenceSource(); src != nil && len(devices) > 0 {
		ids := make([]string, len(devices))
		for i, d := range devices {
			ids[i] = d.ID
		}
		observedAt, live := src(principal.AccountID, ids)
		if observedAt.IsZero() {
			observedAt = s.clock()
		}
		for i, d := range devices {
			p, known := live[d.ID]
			out[i].Presence = toPresenceJSON(d, observedAt, p, known)
		}
	}
	writeJSON(w, http.StatusOK, struct {
		Devices []deviceJSON `json:"devices"`
	}{Devices: out})
}

func (s *Service) handleRevoke(w http.ResponseWriter, r *http.Request, id string) {
	principal, apiErr := s.authenticate(r)
	if apiErr != nil {
		writeJSONError(w, apiErr.status, apiErr.message)
		return
	}
	admit := s.admission(r, principal)
	if err := s.enforceHost(r); err != nil {
		writeJSONError(w, http.StatusForbidden, "wrong host")
		return
	}
	if !ValidDeviceID(id) {
		// Uniform with unknown device: no existence oracle.
		writeJSONError(w, http.StatusNotFound, "device not found")
		return
	}
	// RevokeAdmitted runs the same gate as the FINAL check under the store
	// lock, immediately before the state change: a request that expires
	// while queued behind another mutation applies nothing.
	dev, cascaded, acknowledged, err := s.store.RevokeAdmitted(admit, id, principal.AccountID)
	if err != nil {
		if errors.Is(err, ErrAdmissionDenied) {
			s.logger("revoke admission denied: account=%s device=%s: %v", principal.AccountID, id, err)
			writeJSONError(w, http.StatusUnauthorized, "invalid bearer token")
			return
		}
		// Unknown and other-owner devices are indistinguishable: no leak,
		// and nothing was applied — no containment needed.
		if errors.Is(err, ErrDeviceNotFound) || errors.Is(err, ErrOwnerMismatch) {
			writeJSONError(w, http.StatusNotFound, "device not found")
			return
		}
		if errors.Is(err, ErrDurabilityUncertain) {
			// The revocation IS applied (never reverted) but durability is
			// unproven. Containment is not a durability ACK: tear sessions
			// down NOW for the target and every cascaded device, while the
			// HTTP answer stays an error. Retries re-attempt the flush and
			// cannot return 200 while durability remains uncertain.
			s.notifyRevoke(dev)
			for _, c := range cascaded {
				s.notifyRevoke(c)
			}
			s.logger("revoke applied but durability uncertain: account=%s device=%s cascaded=%d: %v",
				principal.AccountID, id, len(cascaded), err)
			writeJSONError(w, http.StatusInternalServerError, "revocation not acknowledged; retry")
			return
		}
		s.fail(w, "revoke", err)
		return
	}
	if acknowledged {
		// Durably persisted; tell the tunnel to tear sessions down — for the
		// revoked device AND every cascade (duplicate-key) device. (An
		// uncertain earlier attempt may already have fired these callbacks;
		// they are containment and idempotent.)
		s.notifyRevoke(dev)
		for _, c := range cascaded {
			s.notifyRevoke(c)
		}
		s.logger("device revoked: account=%s device=%s cascaded=%d", principal.AccountID, id, len(cascaded))
	}
	writeJSON(w, http.StatusOK, struct {
		ID      string `json:"id"`
		Revoked bool   `json:"revoked"`
	}{ID: dev.ID, Revoked: dev.Revoked})
}

// enforceHost rejects requests whose Host is not the configured canonical
// domain. Unset Domain disables the check (dev).
func (s *Service) enforceHost(r *http.Request) error {
	if s.cfg.Domain == "" {
		return nil
	}
	host := r.Host
	if i := strings.LastIndex(host, ":"); i >= 0 && !strings.Contains(host[i:], "]") {
		host = host[:i]
	}
	if !strings.EqualFold(host, s.cfg.Domain) {
		return errors.New("host mismatch")
	}
	return nil
}

// decodeStrict bounds the body, sets the optional network read deadline,
// and rejects unknown fields and ANY trailing data, so malformed or hostile
// payloads fail closed.
//
// Acceptance requires a definitive ending: after the JSON value decodes, a
// SECOND decode must return exactly io.EOF. This is the only portable way
// to end a body: json.Decoder.More() has unspecified semantics on read
// errors (Go versions have differed on whether a failed refill reads as
// "no more"), so a complete value followed by stalled trailing data —
// whitespace or a hostile suffix — could be treated as valid depending on
// the toolchain. Here every non-EOF ending denies: extra JSON values,
// stray delimiters, byte-cap overflow (413), stalled reads, timeouts,
// cancellation, and read errors (408 for deadline/cancellation, 400
// otherwise). A valid prefix never licenses an error body.
func decodeStrict(w http.ResponseWriter, r *http.Request, v any, max int64, readDeadline time.Duration) *apiError {
	if readDeadline > 0 {
		// An actual network deadline (not a context timeout): on real
		// connections this unblocks a stalled Body.Read. Writers without
		// deadline support ignore the error.
		_ = http.NewResponseController(w).SetReadDeadline(time.Now().Add(readDeadline))
	}
	r.Body = http.MaxBytesReader(w, r.Body, max)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()
	if err := dec.Decode(v); err != nil {
		return decodeBodyError(err)
	}
	// The value alone is not acceptance: read to the definitive end of the
	// body. Only io.EOF may follow.
	if err := dec.Decode(&struct{}{}); err != io.EOF {
		if err == nil {
			// Another JSON value decoded cleanly — still trailing data.
			return &apiError{http.StatusBadRequest, "invalid JSON body"}
		}
		return decodeBodyError(err)
	}
	return nil
}

// decodeBodyError maps body read/decode failures to client-safe statuses.
func decodeBodyError(err error) *apiError {
	var maxErr *http.MaxBytesError
	if errors.As(err, &maxErr) {
		return &apiError{http.StatusRequestEntityTooLarge, "request body too large"}
	}
	if errors.Is(err, context.DeadlineExceeded) || errors.Is(err, context.Canceled) ||
		errors.Is(err, os.ErrDeadlineExceeded) {
		return &apiError{http.StatusRequestTimeout, "request body incomplete"}
	}
	return &apiError{http.StatusBadRequest, "invalid JSON body"}
}

func sameKey(a, b []byte) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	enc := json.NewEncoder(w)
	enc.SetEscapeHTML(false)
	_ = enc.Encode(v)
}

func writeJSONError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, struct {
		Error string `json:"error"`
	}{Error: message})
}
