package identity

import (
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"
)

// Default store bounds. The identity service always passes explicit limits;
// standalone users get these defaults.
const (
	// MaxTotalDevices bounds the registry file size regardless of accounts.
	MaxTotalDevices = 10000
	// MaxRevokedKeys bounds the durable revoked-key tombstone set.
	MaxRevokedKeys = 100000
)

// Limits are the store-enforced admission bounds. Zero means "use default";
// a negative value disables the bound (not recommended).
type Limits struct {
	// MaxPerAccount bounds devices per account. The identity service passes
	// its Config.MaxDevicesPerAccount here so the quota is enforced
	// atomically inside the store's mutation lock, not via a racy
	// count-then-put.
	MaxPerAccount int
	// MaxTotal bounds devices registry-wide (default MaxTotalDevices).
	MaxTotal int
	// MaxRevokedKeys bounds tombstones (default MaxRevokedKeys).
	MaxRevokedKeys int
}

func (l Limits) perAccount() int {
	if l.MaxPerAccount < 0 {
		return 0 // disabled
	}
	return l.MaxPerAccount
}

func (l Limits) total() int {
	if l.MaxTotal <= 0 {
		return MaxTotalDevices
	}
	return l.MaxTotal
}

func (l Limits) revokedKeys() int {
	if l.MaxRevokedKeys <= 0 {
		return MaxRevokedKeys
	}
	return l.MaxRevokedKeys
}

// StoreOption customizes store construction.
type StoreOption func(*storeOptions)

type storeOptions struct {
	limits      Limits
	dirSyncHook func(*os.File) error
}

// WithLimits sets store-enforced admission bounds.
func WithLimits(l Limits) StoreOption {
	return func(o *storeOptions) { o.limits = l }
}

// WithDirSyncHook replaces the post-rename directory fsync. Test-only: it
// models durability failures at exactly that stage (A13). Never set in
// production.
func WithDirSyncHook(h func(*os.File) error) StoreOption {
	return func(o *storeOptions) { o.dirSyncHook = h }
}

// DeviceStore is the full registry contract the identity service uses. The
// exported Store contract (GetDevice) is the read-only slice the tunnel
// worker consumes.
//
// Concurrency and lifecycle guarantees (single instance, durable local
// registry — no distributed claims):
//   - Every mutation (Put/Replace/Revoke) serializes on the store lock and
//     persists durably before returning, so quota admission, ownership
//     checks and revocation terminality are atomic with respect to each
//     other. Callers must not make admission decisions outside the store.
//   - Revocation is terminal: a revoked device can never be replaced or
//     revived through Replace, and its public key is recorded as a durable
//     tombstone that refuses enrollment under any other device ID. There is
//     deliberately no API escape; only a privileged operator editing the
//     registry file offline could clear a tombstone.
//   - A public key enrolled on one device cannot be enrolled on another
//     active device (duplicates are refused). Revoking a device therefore
//     also revokes every other device sharing its key (historical
//     duplicates from older data are cascaded in the same atomic write), so
//     no copy of a revoked key survives as an active registration.
//   - Key revocation is derived, not just stored: tombstones plus revoked
//     records jointly reject reuse, so a full tombstone table can never
//     silently weaken a successful revocation.
//   - Mutations are acknowledged only after the registry file rename is
//     durable (directory fsync). A failure before the rename rolls the
//     in-memory state back; a failure after the rename keeps the applied
//     state but reports ErrDurabilityUncertain instead of acknowledging.
type DeviceStore interface {
	Store
	Put(dev Device) error
	// Replace swaps the pinned key/host key of an existing device for the
	// same owner. It returns the pre-replacement record and whether the
	// swap is durably ACKNOWLEDGED. On ErrDurabilityUncertain the
	// replacement is applied (never reverted) but unproven: `previous`
	// carries the OLD key identity so callers contain the original device
	// immediately, and every retry re-attempts the flush. It fails with
	// ErrDeviceRevoked if the device was revoked — concurrently or through
	// inherited revocation — so revocation is terminal.
	Replace(dev Device) (previous Device, acknowledged bool, err error)
	List(accountID string) ([]Device, error)
	// Revoke marks the device revoked, cascading to any other device that
	// carries the same public key. It returns the directly revoked device,
	// every other affected device, and whether the revocation is now
	// durably ACKNOWLEDGED. On ErrDurabilityUncertain the revocation is
	// applied (never reverted) but unproven: the affected devices are still
	// returned so callers run containment (disconnect) immediately, the
	// caller must not acknowledge, and every retry re-attempts the flush —
	// it cannot succeed until the directory fsync does. Unknown IDs fail
	// with ErrDeviceNotFound, foreign owners with ErrOwnerMismatch. The key
	// is tombstoned in the same atomic write as the revocation.
	Revoke(id, accountID string) (revoked Device, affectedOthers []Device, acknowledged bool, err error)
	Count(accountID string) (int, error)
}

// ErrAdmissionDenied is returned when a request's authorization was no
// longer valid at the moment of admission: the caller context is canceled
// or the principal's expiry has passed. Nothing was applied or disclosed.
var ErrAdmissionDenied = errors.New("identity: request admission denied")

// AdmissionCheck is the authorization probe consulted at admission points.
// A production check rejects a canceled request context and an expired (or
// zero-expiry) principal against the CURRENT clock (see ValidAdmission).
// Stores run it as their FINAL pre-mutation gate: under the same lock as
// the state change, immediately before it, so a request that expires while
// queued behind another mutation is still denied.
type AdmissionCheck func() error

// admitUnderLock runs a check in the context that already holds the guard;
// a nil check (internal/compat callers) admits.
func admitUnderLock(check AdmissionCheck) error {
	if check == nil {
		return nil
	}
	if err := check(); err != nil {
		return fmt.Errorf("%w: %w", ErrAdmissionDenied, err)
	}
	return nil
}

// AuthorizedStore is a DeviceStore whose mutations and list disclosures can
// enforce an admission check atomically with the state change: the check
// runs under the store's mutation lock, as the last step before anything is
// applied or copied out, so a principal that expires while waiting on the
// lock can never complete a mutation or receive data. FileStore and
// MemoryStore implement it natively; NewService accepts ONLY injected
// stores that implement it themselves — a store whose internals may block
// arbitrarily cannot be made atomic from the outside, and no decorator can
// cover a wait that happens inside an opaque call. The service's quota
// decorator forwards every non-nil check into the inner store's actual
// mutation/list lock. Plain Put/Replace/List/Revoke remain for internal and
// compat use with a nil gate.
type AuthorizedStore interface {
	DeviceStore
	// PutAdmitted stores dev only if check admits under the store lock.
	PutAdmitted(check AdmissionCheck, dev Device) error
	// ReplaceAdmitted swaps the pinned key/host key only if check admits
	// under the store lock. Contract mirrors Replace.
	ReplaceAdmitted(check AdmissionCheck, dev Device) (previous Device, acknowledged bool, err error)
	// ListAdmitted copies the account's devices only if check admits under
	// the store lock (the disclosure gate).
	ListAdmitted(check AdmissionCheck, accountID string) ([]Device, error)
	// RevokeAdmitted applies the revocation only if check admits under the
	// store lock. Contract mirrors Revoke.
	RevokeAdmitted(check AdmissionCheck, id, accountID string) (revoked Device, affectedOthers []Device, acknowledged bool, err error)
}

type storeFile struct {
	Version     int            `json:"version"`
	Devices     []deviceRecord `json:"devices"`
	RevokedKeys []string       `json:"revoked_keys,omitempty"`
}

// storeFileVersion 2 adds durable revoked-key tombstones. Version 1 files
// (no tombstones) are accepted on load for migration; new writes are always
// version 2.
const storeFileVersion = 2

type deviceRecord struct {
	Device
	EnrolledAt time.Time `json:"enrolled_at"`
}

func validateDevice(dev Device) error {
	if !ValidDeviceID(dev.ID) {
		return fmt.Errorf("%w: bad device id", ErrBadRequest)
	}
	if !ValidAccountID(dev.AccountID) {
		return fmt.Errorf("%w: bad account id", ErrBadRequest)
	}
	if !ValidPublicKey(dev.PublicKey) {
		return fmt.Errorf("%w: public key must be raw 32-byte Ed25519", ErrBadRequest)
	}
	if !ValidSSHHostKey(dev.SSHHostKey) {
		return ErrHostKeyInvalid
	}
	return nil
}

func keyID(pub []byte) string { return base64.StdEncoding.EncodeToString(pub) }

// registry is the shared mutation engine for the file and memory stores.
// All decisions (existence, ownership, terminality, quota, tombstones,
// duplicate keys) are made under one lock together with the mutation itself.
type registry struct {
	mu          sync.Mutex
	limits      Limits
	devices     map[string]deviceRecord
	revokedKeys map[string]bool
	// revokedFromRecords holds key IDs derived from device records with
	// Revoked=true (load migration and cascades). Together with
	// revokedKeys it forms the full rejection set, so a capped tombstone
	// table can never weaken a revocation.
	revokedFromRecords map[string]bool
	// pendingDurability is set when a mutation was applied and renamed but
	// its directory fsync failed: the file holds the new state while
	// durability is unproven. While set, the store is fail-closed for
	// acknowledgments: every mutating call re-attempts the flush and NO
	// mutation is acknowledged until a flush succeeds. Applied state is
	// never reverted to active.
	pendingDurability bool
	// pendingAffected lists devices whose revocation transitions have been
	// applied but not yet durably acknowledged. Retries re-report them so
	// containment (disconnect) callbacks fire on every attempt.
	pendingAffected []Device
	// persist rewrites the durable copy; nil for the memory store.
	persist func() (renamed bool, err error)
}

func newRegistry(limits Limits, persist func() (renamed bool, err error)) *registry {
	return &registry{
		limits:             limits,
		devices:            make(map[string]deviceRecord),
		revokedKeys:        make(map[string]bool),
		revokedFromRecords: make(map[string]bool),
		persist:            persist,
	}
}

// keyRevokedLocked reports whether a key is dead for admission: explicitly
// tombstoned, or carried by any revoked device record (derived — the
// capacity of the explicit table cannot weaken this).
func (r *registry) keyRevokedLocked(key string) bool {
	return r.revokedKeys[key] || r.revokedFromRecords[key]
}

// duplicateKeyDeviceLocked returns an active device (other than skipID)
// holding the same public key, if any.
func (r *registry) duplicateKeyDeviceLocked(key, skipID string) (deviceRecord, bool) {
	for _, rec := range r.devices {
		if rec.ID != skipID && !rec.Revoked && keyID(rec.PublicKey) == key {
			return rec, true
		}
	}
	return deviceRecord{}, false
}

func (r *registry) markKeyRevokedLocked(key string) {
	// Explicit table has a bounded capacity; the derived set does not, and
	// rejection consults both, so capacity never weakens revocation.
	if len(r.revokedKeys) < r.limits.revokedKeys() {
		r.revokedKeys[key] = true
	}
}

// mutate applies fn and persists. check is the FINAL admission gate: it
// runs under the lock after acquisition, immediately before any state
// change, flush attempt, or rollback-snapshot work — a queued request whose
// authorization expired while waiting on the lock applies nothing. fn
// reports the devices affected by a revocation transition (empty for
// non-revocation mutations) so that uncertain attempts can keep containment
// information available.
//
// Durability contract:
//   - check denied: nothing is read, changed, or flushed; ErrAdmissionDenied.
//   - No pending uncertainty, fn made no change: nothing persisted, no
//     flush attempt, fn's error (or nil) returned as-is.
//   - Persistence succeeded (rename + dir fsync): everything applied so
//     far is durable; pending state is cleared and acknowledged.
//   - Failure BEFORE the rename: the file provably did not change; this
//     call's changes roll back. With no prior pending state the error is
//     ErrStoreFailure; with pending durability it remains
//     ErrDurabilityUncertain (the earlier mutation is still unproven).
//   - Failure AFTER the rename: the file holds the new state; memory keeps
//     the applied state, pendingDurability/pendingAffected are set, and
//     the error is ErrDurabilityUncertain. Callers get the affected
//     devices for containment and must not acknowledge.
func (r *registry) mutate(check AdmissionCheck, fn func() (commit bool, affected []Device, err error)) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if err := admitUnderLock(check); err != nil {
		return err
	}
	// Snapshot for rollback: only valid when the durable file provably did
	// not change (failure before rename).
	snapDevices := cloneDevices(r.devices)
	snapKeys := cloneKeys(r.revokedKeys)
	snapDerived := cloneKeys(r.revokedFromRecords)
	commit, affected, err := fn()
	// While durability is pending (an earlier mutation was applied but its
	// fsync failed), every mutating call re-attempts the flush — including
	// pure no-ops such as an idempotent revoke retry — and nothing is
	// acknowledged until a flush succeeds.
	needPersist := commit || r.pendingDurability
	if !needPersist {
		return err
	}
	if r.persist == nil {
		return err
	}
	wasPending := r.pendingDurability
	renamed, perr := r.persist()
	if perr != nil {
		if renamed {
			r.pendingDurability = true
			r.pendingAffected = appendUniqueDevices(r.pendingAffected, affected)
			return fmt.Errorf("%w: %v", ErrDurabilityUncertain, perr)
		}
		r.devices = snapDevices
		r.revokedKeys = snapKeys
		r.revokedFromRecords = snapDerived
		if wasPending {
			return fmt.Errorf("%w: %v", ErrDurabilityUncertain, perr)
		}
		return fmt.Errorf("%w: %v", ErrStoreFailure, perr)
	}
	// Durable: acknowledge everything applied so far.
	r.pendingDurability = false
	r.pendingAffected = nil
	return err
}

// appendUniqueDevices merges src into dst, deduplicating by device ID.
func appendUniqueDevices(dst, src []Device) []Device {
	for _, d := range src {
		dup := false
		for _, e := range dst {
			if e.ID == d.ID {
				dup = true
				break
			}
		}
		if !dup {
			dst = append(dst, d)
		}
	}
	return dst
}

func cloneDevices(m map[string]deviceRecord) map[string]deviceRecord {
	out := make(map[string]deviceRecord, len(m))
	for k, v := range m {
		out[k] = v
	}
	return out
}

func cloneKeys(m map[string]bool) map[string]bool {
	out := make(map[string]bool, len(m))
	for k, v := range m {
		out[k] = v
	}
	return out
}

func (r *registry) put(check AdmissionCheck, dev Device) error {
	if err := validateDevice(dev); err != nil {
		return err
	}
	return r.mutate(check, func() (bool, []Device, error) {
		if _, exists := r.devices[dev.ID]; exists {
			return false, nil, ErrDeviceIDTaken
		}
		if r.keyRevokedLocked(keyID(dev.PublicKey)) {
			return false, nil, ErrPublicKeyRevoked
		}
		if _, dup := r.duplicateKeyDeviceLocked(keyID(dev.PublicKey), dev.ID); dup {
			return false, nil, ErrDuplicateKey
		}
		if n := r.limits.perAccount(); n > 0 && r.countLocked(dev.AccountID) >= n {
			return false, nil, ErrAccountQuotaExceeded
		}
		if len(r.devices) >= r.limits.total() {
			return false, nil, ErrLimitExceeded
		}
		r.devices[dev.ID] = deviceRecord{Device: dev, EnrolledAt: time.Now().UTC()}
		return true, nil, nil
	})
}

// replace swaps the pinned key/host key of an existing device. Return
// contract mirrors revoke: on ErrDurabilityUncertain the replacement IS
// applied (memory + file, never reverted) and `previous` carries the
// pre-replacement record — the old key identity — so callers fire
// containment for the original device immediately; acknowledged stays false
// and every retry re-attempts the flush.
func (r *registry) replace(check AdmissionCheck, dev Device) (Device, bool, error) {
	var (
		previous Device
		applied  bool
	)
	if err := validateDevice(dev); err != nil {
		return Device{}, false, err
	}
	err := r.mutate(check, func() (bool, []Device, error) {
		prev, exists := r.devices[dev.ID]
		if !exists {
			return false, nil, ErrDeviceNotFound
		}
		if prev.AccountID != dev.AccountID {
			return false, nil, ErrOwnerMismatch
		}
		if r.effectiveRevokedLocked(prev) {
			// Terminal: a concurrent or inherited revocation always wins
			// over a replace.
			return false, nil, ErrDeviceRevoked
		}
		previous = prev.Device
		if prev.Revoked == dev.Revoked && sameKey(prev.PublicKey, dev.PublicKey) && prev.SSHHostKey == dev.SSHHostKey {
			return false, nil, nil // no-op
		}
		if !sameKey(prev.PublicKey, dev.PublicKey) && r.keyRevokedLocked(keyID(dev.PublicKey)) {
			return false, nil, ErrPublicKeyRevoked
		}
		if !sameKey(prev.PublicKey, dev.PublicKey) {
			if _, dup := r.duplicateKeyDeviceLocked(keyID(dev.PublicKey), dev.ID); dup {
				return false, nil, ErrDuplicateKey
			}
		}
		r.devices[dev.ID] = deviceRecord{Device: dev, EnrolledAt: time.Now().UTC()}
		applied = true
		return true, nil, nil
	})
	if errors.Is(err, ErrDurabilityUncertain) {
		// The replacement is applied; contain the ORIGINAL device (old key)
		// and keep it in the pending set so revoke-style retries re-report
		// it until durability is proven.
		r.mu.Lock()
		if previous.ID != "" {
			r.pendingAffected = appendUniqueDevices(r.pendingAffected, []Device{previous})
		}
		r.mu.Unlock()
		return previous, false, err
	}
	if err != nil {
		return Device{}, false, err
	}
	return previous, applied, nil
}

// revoke applies the revocation plus cascade. Return contract:
//   - err == nil, acknowledged == true: durably persisted; the service may
//     acknowledge (HTTP 200) and fire containment callbacks.
//   - err == nil, acknowledged == false: idempotent no-op (already revoked
//     with proven durability); no callbacks needed.
//   - err == ErrDurabilityUncertain: the revocation (and any cascade) IS
//     APPLIED in memory and on disk — it is never reverted — but durability
//     is unproven. revoked/cascaded still identify every affected device so
//     callers fire containment (disconnect) immediately: containment is not
//     a durability acknowledgment. The HTTP layer must return an error and
//     the operation retried; every retry re-attempts the flush and cannot
//     succeed until the fsync does.
//   - other errors: nothing was applied (no containment needed).
func (r *registry) revoke(check AdmissionCheck, id, accountID string) (Device, []Device, bool, error) {
	var (
		result   Device
		cascaded []Device
		affected []Device
	)
	err := r.mutate(check, func() (bool, []Device, error) {
		rec, ok := r.devices[id]
		if !ok {
			return false, nil, ErrDeviceNotFound
		}
		if rec.AccountID != accountID {
			return false, nil, ErrOwnerMismatch
		}
		if rec.Revoked {
			result = rec.Device
			if r.pendingDurability {
				// Retry of an uncertain revocation: force the flush and, on
				// success, re-report the pending affected set so containment
				// re-runs alongside the acknowledgment.
				affected = appendUniqueDevices(nil, r.pendingAffected)
				return true, affected, nil
			}
			return false, nil, nil
		}
		rec.Revoked = true
		r.devices[id] = rec
		r.markKeyRevokedLocked(keyID(rec.PublicKey))
		r.revokedFromRecords[keyID(rec.PublicKey)] = true
		result = rec.Device
		affected = append(affected, rec.Device)
		// Cascade: every other device carrying this key is invalidated in
		// the same atomic write, so no copy of a revoked key remains active.
		for otherID, other := range r.devices {
			if otherID != id && !other.Revoked && sameKey(other.PublicKey, rec.PublicKey) {
				other.Revoked = true
				r.devices[otherID] = other
				r.revokedFromRecords[keyID(other.PublicKey)] = true
				cascaded = append(cascaded, other.Device)
				affected = append(affected, other.Device)
			}
		}
		return true, affected, nil
	})
	if err != nil {
		if errors.Is(err, ErrDurabilityUncertain) {
			// Applied but not durable-acknowledged: still report every
			// affected device (pending set included) for containment;
			// acknowledged stays false so the caller cannot report success.
			r.mu.Lock()
			all := appendUniqueDevices(appendUniqueDevices(nil, r.pendingAffected), affected)
			r.mu.Unlock()
			others := []Device{}
			for _, d := range all {
				if d.ID != result.ID {
					others = append(others, d)
				}
			}
			return result, others, false, err
		}
		// Nothing was applied (unknown device, owner mismatch, rolled back).
		return Device{}, nil, false, err
	}
	// Acknowledged iff this call performed a transition that flushed
	// durably (a fresh revocation, or a retry that completed the pending
	// flush). A clean idempotent no-op is not an acknowledgment.
	return result, cascaded, len(affected) > 0, nil
}

// effectiveRevokedLocked applies inherited revocation: a record is dead if
// it is itself revoked OR its key is in the rejection set (explicit
// tombstones, revoked records, or cascades). This covers historical
// duplicates written before cascade admission existed: loading revoked A
// with an active same-key B, or a bare tombstone over B's key, makes B
// effectively revoked for every read, admission and replacement — the raw
// file flag alone must never resurrect a dead key through GetDevice.
func (r *registry) effectiveRevokedLocked(rec deviceRecord) bool {
	return rec.Revoked || r.keyRevokedLocked(keyID(rec.PublicKey))
}

// applyEffectiveRevocationLocked marks every inherited-revocation device in
// the in-memory map so reads and admissions observe terminal state without
// relying on the per-read overlay.
func (r *registry) applyEffectiveRevocationLocked() {
	for id, rec := range r.devices {
		if !rec.Revoked && r.keyRevokedLocked(keyID(rec.PublicKey)) {
			rec.Revoked = true
			r.devices[id] = rec
			r.revokedFromRecords[keyID(rec.PublicKey)] = true
		}
	}
}

func (r *registry) get(id string) (Device, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	rec, ok := r.devices[id]
	if !ok {
		return Device{}, ErrDeviceNotFound
	}
	if r.effectiveRevokedLocked(rec) {
		rec.Revoked = true
	}
	return rec.Device, nil
}

func (r *registry) list(accountID string, check AdmissionCheck) ([]Device, error) {
	if !ValidAccountID(accountID) {
		return nil, fmt.Errorf("%w: bad account", ErrBadRequest)
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	// Disclosure gate: the copy is only built when the check admits under
	// the lock, so an expired request queued behind a mutation receives
	// nothing.
	if err := admitUnderLock(check); err != nil {
		return nil, err
	}
	var out []Device
	for _, rec := range r.devices {
		if rec.AccountID != accountID {
			continue
		}
		if r.effectiveRevokedLocked(rec) {
			rec.Revoked = true
		}
		out = append(out, rec.Device)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out, nil
}

func (r *registry) countLocked(accountID string) int {
	n := 0
	for _, rec := range r.devices {
		if rec.AccountID == accountID {
			n++
		}
	}
	return n
}

func (r *registry) count(accountID string) (int, error) {
	if !ValidAccountID(accountID) {
		return 0, fmt.Errorf("%w: bad account", ErrBadRequest)
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.countLocked(accountID), nil
}

// FileStore is the durable device registry. Every mutation is applied under
// the registry lock and written to a temp file in the same directory,
// fsynced and renamed over the target, so a crash at any point leaves either
// the old or the new complete state — never a torn file. Loading fails
// closed on any corrupt or invalid record rather than silently dropping
// devices.
type FileStore struct {
	*registry
	path string
	// dirSync overrides the post-rename directory fsync (A13 test hook).
	dirSync func(*os.File) error
}

// NewFileStore opens (or creates) the registry at path. The containing
// directory is created with 0700 if missing.
func NewFileStore(path string, opts ...StoreOption) (*FileStore, error) {
	if path == "" {
		return nil, errors.New("identity: store path required")
	}
	var so storeOptions
	for _, opt := range opts {
		opt(&so)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, fmt.Errorf("identity: store dir: %w", err)
	}
	fs := &FileStore{registry: newRegistry(so.limits, nil), path: path, dirSync: so.dirSyncHook}
	fs.registry.persist = func() (bool, error) { return fs.persistLocked() }
	if err := fs.load(); err != nil {
		return nil, err
	}
	return fs, nil
}

func (fs *FileStore) load() error {
	data, err := os.ReadFile(fs.path)
	switch {
	case errors.Is(err, os.ErrNotExist):
		_, perr := fs.persistLocked()
		return perr
	case err != nil:
		return fmt.Errorf("identity: store read: %w", err)
	}
	if len(data) > 16<<20 {
		return fmt.Errorf("identity: store file too large")
	}
	fs.mu.Lock()
	defer fs.mu.Unlock()
	var f storeFile
	if err := json.Unmarshal(data, &f); err != nil {
		return fmt.Errorf("identity: store corrupt: %w", err)
	}
	if f.Version < 1 || f.Version > storeFileVersion {
		return fmt.Errorf("identity: unsupported store version %d", f.Version)
	}
	if len(f.Devices) > fs.limits.total() {
		return fmt.Errorf("identity: store exceeds device cap")
	}
	for _, rec := range f.Devices {
		if err := validateDevice(rec.Device); err != nil {
			return fmt.Errorf("identity: store record invalid: %w", err)
		}
		if _, dup := fs.devices[rec.ID]; dup {
			return fmt.Errorf("identity: store has duplicate device %q", rec.ID)
		}
		fs.devices[rec.ID] = rec
		// Derive key revocation from revoked records: v1 registries have no
		// tombstone table at all, and a v2 table can be incomplete — the
		// records are authoritative.
		if rec.Revoked {
			fs.revokedFromRecords[keyID(rec.PublicKey)] = true
		}
	}
	if len(f.RevokedKeys) > fs.limits.revokedKeys() {
		return fmt.Errorf("identity: store exceeds revoked-key cap")
	}
	for _, k := range f.RevokedKeys {
		b, err := base64.StdEncoding.DecodeString(k)
		if err != nil || len(b) != ed25519.PublicKeySize {
			return fmt.Errorf("identity: store has invalid revoked-key tombstone")
		}
		fs.revokedKeys[k] = true
	}
	// Historical duplicates inherit revocation: a record sharing its key
	// with a revoked record or a bare tombstone is effectively revoked.
	// Applied to the in-memory map immediately (and re-derived on every
	// load), so the actual gateway read path — GetDevice — can never serve
	// a dead key as active. The file converges on the next mutation.
	fs.applyEffectiveRevocationLocked()
	return nil
}

// persistLocked atomically rewrites the registry file and reports whether
// the rename already happened. Caller holds fs.mu (via registry.mutate) or
// runs before the registry is shared.
//
// Failure stages (A13):
//   - false, err — the file was NOT changed (temp create/write/fsync/close
//     or the rename itself failed); the caller must roll back memory.
//   - true, err — the rename succeeded but durability could not be proven
//     (directory open/fsync failed); the file holds the NEW state, so the
//     caller must keep the applied in-memory state and refuse to
//     acknowledge the mutation (ErrDurabilityUncertain).
func (fs *FileStore) persistLocked() (renamed bool, err error) {
	f := storeFile{Version: storeFileVersion}
	for _, rec := range fs.devices {
		f.Devices = append(f.Devices, rec)
	}
	sort.Slice(f.Devices, func(i, j int) bool { return f.Devices[i].ID < f.Devices[j].ID })
	for k := range fs.revokedKeys {
		f.RevokedKeys = append(f.RevokedKeys, k)
	}
	sort.Strings(f.RevokedKeys)
	data, err := json.MarshalIndent(f, "", "  ")
	if err != nil {
		return false, err
	}
	tmp, err := os.CreateTemp(filepath.Dir(fs.path), ".registry-*.tmp")
	if err != nil {
		return false, err
	}
	tmpName := tmp.Name()
	cleanup := func() { tmp.Close(); os.Remove(tmpName) }
	if err := tmp.Chmod(0o600); err != nil {
		cleanup()
		return false, err
	}
	if _, err := tmp.Write(data); err != nil {
		cleanup()
		return false, err
	}
	if err := tmp.Sync(); err != nil {
		cleanup()
		return false, err
	}
	if err := tmp.Close(); err != nil {
		os.Remove(tmpName)
		return false, err
	}
	if err := os.Rename(tmpName, fs.path); err != nil {
		os.Remove(tmpName)
		return false, err
	}
	renamed = true
	// Make the rename itself durable. Failure here is uncertainty, not
	// failure-to-apply: the file already holds the new state.
	dir, err := os.Open(filepath.Dir(fs.path))
	if err != nil {
		return true, fmt.Errorf("durability: open registry dir: %w", err)
	}
	sync := (*os.File).Sync
	if fs.dirSync != nil {
		sync = fs.dirSync
	}
	if err := sync(dir); err != nil {
		dir.Close()
		return true, fmt.Errorf("durability: fsync registry dir: %w", err)
	}
	if err := dir.Close(); err != nil {
		return true, fmt.Errorf("durability: close registry dir: %w", err)
	}
	return true, nil
}

// GetDevice returns the device by ID, or ErrDeviceNotFound.
func (fs *FileStore) GetDevice(id string) (Device, error) { return fs.registry.get(id) }

// Put stores a new device; quota and tombstone checks are atomic.
func (fs *FileStore) Put(dev Device) error { return fs.registry.put(nil, dev) }

// Replace swaps an existing device's key and host key atomically; refused
// for revoked devices (ErrDeviceRevoked, including inherited revocation)
// and revoked keys. See registry.replace for the uncertainty contract.
func (fs *FileStore) Replace(dev Device) (Device, bool, error) {
	return fs.registry.replace(nil, dev)
}

// List returns the account's devices ordered by ID.
func (fs *FileStore) List(accountID string) ([]Device, error) {
	return fs.registry.list(accountID, nil)
}

// Count returns the number of devices the account owns.
func (fs *FileStore) Count(accountID string) (int, error) { return fs.registry.count(accountID) }

// Revoke persists the revocation (plus key tombstone and cascade to any
// duplicate-key devices) before returning. The bool reports whether the
// revocation is durably ACKNOWLEDGED by this call; on ErrDurabilityUncertain
// the affected devices are still returned for containment. See
// registry.revoke for the full contract.
func (fs *FileStore) Revoke(id, accountID string) (Device, []Device, bool, error) {
	return fs.registry.revoke(nil, id, accountID)
}

// PutAdmitted stores dev only if the admission check passes under the store
// lock, immediately before the state change.
func (fs *FileStore) PutAdmitted(check AdmissionCheck, dev Device) error {
	return fs.registry.put(check, dev)
}

// ReplaceAdmitted swaps an existing device's pinned key/host key only if
// the admission check passes under the store lock.
func (fs *FileStore) ReplaceAdmitted(check AdmissionCheck, dev Device) (Device, bool, error) {
	return fs.registry.replace(check, dev)
}

// ListAdmitted copies the account's devices only if the admission check
// passes under the store lock (the disclosure gate).
func (fs *FileStore) ListAdmitted(check AdmissionCheck, accountID string) ([]Device, error) {
	return fs.registry.list(accountID, check)
}

// RevokeAdmitted applies the revocation only if the admission check passes
// under the store lock, immediately before the state change.
func (fs *FileStore) RevokeAdmitted(check AdmissionCheck, id, accountID string) (Device, []Device, bool, error) {
	return fs.registry.revoke(check, id, accountID)
}

var _ AuthorizedStore = (*FileStore)(nil)

// MemoryStore is a DeviceStore without persistence, for tests and for
// embedding. It enforces the same validation, quota and tombstone semantics
// as FileStore.
type MemoryStore struct {
	*registry
}

// NewMemoryStore returns an empty in-memory registry.
func NewMemoryStore(opts ...StoreOption) *MemoryStore {
	var so storeOptions
	for _, opt := range opts {
		opt(&so)
	}
	return &MemoryStore{registry: newRegistry(so.limits, nil)}
}

// GetDevice returns the device by ID, or ErrDeviceNotFound.
func (ms *MemoryStore) GetDevice(id string) (Device, error) { return ms.registry.get(id) }

// Put stores a new device; quota and tombstone checks are atomic.
func (ms *MemoryStore) Put(dev Device) error { return ms.registry.put(nil, dev) }

// Replace swaps an existing device's key and host key atomically (no
// durability component, so replacements always acknowledge).
func (ms *MemoryStore) Replace(dev Device) (Device, bool, error) {
	return ms.registry.replace(nil, dev)
}

// List returns the account's devices ordered by ID.
func (ms *MemoryStore) List(accountID string) ([]Device, error) {
	return ms.registry.list(accountID, nil)
}

// Count returns the number of devices the account owns.
func (ms *MemoryStore) Count(accountID string) (int, error) { return ms.registry.count(accountID) }

// Revoke mirrors FileStore.Revoke semantics (tombstone and cascade
// included; no durability component, so revocations always acknowledge).
func (ms *MemoryStore) Revoke(id, accountID string) (Device, []Device, bool, error) {
	return ms.registry.revoke(nil, id, accountID)
}

// PutAdmitted stores dev only if the admission check passes under the store
// lock, immediately before the state change.
func (ms *MemoryStore) PutAdmitted(check AdmissionCheck, dev Device) error {
	return ms.registry.put(check, dev)
}

// ReplaceAdmitted swaps an existing device's pinned key/host key only if
// the admission check passes under the store lock.
func (ms *MemoryStore) ReplaceAdmitted(check AdmissionCheck, dev Device) (Device, bool, error) {
	return ms.registry.replace(check, dev)
}

// ListAdmitted copies the account's devices only if the admission check
// passes under the store lock (the disclosure gate).
func (ms *MemoryStore) ListAdmitted(check AdmissionCheck, accountID string) ([]Device, error) {
	return ms.registry.list(accountID, check)
}

// RevokeAdmitted applies the revocation only if the admission check passes
// under the store lock, immediately before the state change.
func (ms *MemoryStore) RevokeAdmitted(check AdmissionCheck, id, accountID string) (Device, []Device, bool, error) {
	return ms.registry.revoke(check, id, accountID)
}

var _ AuthorizedStore = (*MemoryStore)(nil)
