package identity

// Round-seven finding (Astra final review, P2): signingKey classified the
// rate-limited diagnostic by reading v.keys AFTER releasing v.mu, while
// runRefresh published recovered keys under the mutex. The unlocked read
// could not change the authorization outcome (the caller is rejected either
// way), but it corrupted the diagnostic class and was a data race.
//
// These regressions drive real recovered-key publications from cooldown
// rollovers while concurrent callers continuously exercise BOTH arms of the
// rate-limited diagnostic (cold-cache "unavailable" and warm-cache "unknown
// kid"), which the round-six failed-cold tests never overlapped with a
// publish. Run under -race.

import (
	"context"
	"crypto/rsa"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// recoveryJWKS serves an accumulating set of signing keys and counts
// fetches. The served snapshot is built under the stub lock so test-side
// key additions never race an in-flight fetch.
type recoveryJWKS struct {
	mu      sync.Mutex
	keys    map[string]*rsa.PrivateKey
	fetches atomic.Int64
}

func newRecoveryJWKS() *recoveryJWKS {
	return &recoveryJWKS{keys: map[string]*rsa.PrivateKey{}}
}

func (s *recoveryJWKS) addKey(kid string, key *rsa.PrivateKey) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.keys[kid] = key
}

func (s *recoveryJWKS) RoundTrip(*http.Request) (*http.Response, error) {
	s.fetches.Add(1)
	s.mu.Lock()
	defer s.mu.Unlock()
	return jwksHTTPResponse(s.keys), nil
}

func (s *recoveryJWKS) fetchCount() int64 { return s.fetches.Load() }

// hammerResult classifies one rate-limited verification outcome. The two
// counted classes are the two arms of the (formerly racy) diagnostic; any
// third outcome — authorization, hang past the per-call deadline, or a
// non-ErrUnauthorized error — is a failure.
type hammerResult struct {
	unavailable atomic.Int64 // "signing keys unavailable (refresh rate-limited)"
	unknownKid  atomic.Int64 // "unknown kid (refresh rate-limited)"
	bad         atomic.Int64 // anything else: authorized, hung, or wrong error
}

func (h *hammerResult) record(err error, ctxErr error) {
	switch {
	case err == nil:
		h.bad.Add(1) // the ghost kid is never published: never authorizable
	case ctxErr != nil:
		h.bad.Add(1) // verification hung until the caller deadline
	case strings.Contains(err.Error(), "signing keys unavailable"):
		h.unavailable.Add(1)
	case strings.Contains(err.Error(), "unknown kid"):
		h.unknownKid.Add(1)
	default:
		h.bad.Add(1)
	}
}

// RED (data race): the rate-limited diagnostic read v.keys after v.mu.Unlock
// while runRefresh wrote v.keys under the mutex. Cooldown rollovers recover
// the endpoint and publish new kids while hammerers keep taking the
// rate-limited branch, so publisher and diagnostic readers genuinely
// overlap; it also pins the diagnostic classification itself, the bounded
// one-fetch-per-rollover recovery, and that the ghost kid is never served.
func TestRecoveredKeyPublishUnderRateLimitedTraffic(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	stub := newRecoveryJWKS()
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: stub},
		Clock:      clock.Now, RefreshCooldown: time.Hour,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}

	// A token for a kid the endpoint never serves. It passes every claim
	// check, so each verification reaches signingKey and lands in the
	// unknown-kid rate-limited branch (cold phase: the unavailable branch).
	longExp := clock.Now().Add(365 * 24 * time.Hour).Unix()
	ghostClaims := baseClaims(clock, "113958430858354529072", "user@example.com")
	ghostClaims["exp"] = longExp
	ghostTok := signToken(t, key, "kid-ghost", nil, ghostClaims)

	const hammerers = 16
	const rounds = 300
	var res hammerResult
	stop := make(chan struct{})
	var wg sync.WaitGroup
	wg.Add(hammerers)
	for i := 0; i < hammerers; i++ {
		go func() {
			defer wg.Done()
			for {
				select {
				case <-stop:
					return
				default:
				}
				ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
				_, err := v.VerifyToken(ctx, ghostTok)
				ctxErr := ctx.Err() // read before cancel: deadline, not self-cancel
				cancel()
				res.record(err, ctxErr)
			}
		}()
	}

	// Cold phase: with no keys ever served, the first refresh attempt fails
	// (empty JWKS) and arms the cooldown; every hammerer then takes the
	// "signing keys unavailable" arm. Hold this state in real time so the
	// arm is genuinely exercised under load before the recovery rounds.
	time.Sleep(100 * time.Millisecond)

	for i := 0; i < rounds; i++ {
		kid := fmt.Sprintf("kid-%d", i)
		stub.addKey(kid, key)
		before := stub.fetchCount()
		clock.Advance(2 * time.Hour) // roll the cooldown over: refresh re-arms

		// The publish is driven by whichever caller first finds the elapsed
		// cooldown (a hammerer or this poll); wait until the recovered key
		// is actually served from the cache.
		tok := signToken(t, key, kid, nil, baseClaims(clock, "113958430858354529072", "user@example.com"))
		deadline := time.Now().Add(5 * time.Second)
		published := false
		for time.Now().Before(deadline) {
			if _, err := v.VerifyToken(context.Background(), tok); err == nil {
				published = true
				break
			}
			time.Sleep(50 * time.Microsecond)
		}
		if !published {
			close(stop)
			wg.Wait()
			t.Fatalf("round %d: recovered key %q never published/served after cooldown rollover", i, kid)
		}
		if got := stub.fetchCount() - before; got != 1 {
			close(stop)
			wg.Wait()
			t.Fatalf("round %d: cooldown-rollover recovery caused %d fetches, want exactly 1", i, got)
		}
	}

	close(stop)
	wg.Wait()
	if bad := res.bad.Load(); bad != 0 {
		t.Fatalf("%d rate-limited-path verifications were authorized, hung, or misclassified", bad)
	}
	// Both arms of the diagnostic must have been exercised under load: the
	// cold phase before the first publish and the warm unknown-kid phase
	// after it.
	if res.unavailable.Load() == 0 {
		t.Fatal("cold-cache rate-limited arm (signing keys unavailable) never exercised")
	}
	if res.unknownKid.Load() == 0 {
		t.Fatal("warm-cache rate-limited arm (unknown kid) never exercised")
	}
}

// RED (functional): the round-six failed-cold test recovered sequentially,
// after all concurrent callers had already drained. Here the recovery
// publish must release concurrent cold waiters in one batch: every waiter
// is authorized by the published keys and the recovery costs exactly one
// fetch.
func TestRecoveryPublishReleasesConcurrentColdWaiters(t *testing.T) {
	clock := newFakeClock()
	key := mustRSA(t)
	var outage atomic.Bool
	var fetches atomic.Int64
	rt := roundTripperFunc(func(r *http.Request) (*http.Response, error) {
		fetches.Add(1)
		if outage.Load() {
			return nil, errors.New("jwks outage")
		}
		return jwksHTTPResponse(map[string]*rsa.PrivateKey{"kid-1": key}), nil
	})
	v, err := NewGoogleVerifier(GoogleConfig{
		ClientID: "test-client-id", JWKSURL: "https://jwks.test/certs",
		Allowlist:  []string{"user@example.com"},
		HTTPClient: &http.Client{Transport: rt},
		Clock:      clock.Now, RefreshCooldown: time.Hour,
		Logger: func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	claims := baseClaims(clock, "113958430858354529072", "user@example.com")
	claims["exp"] = clock.Now().Add(365 * 24 * time.Hour).Unix()
	tok := signToken(t, key, "kid-1", nil, claims)

	// Cold cache + outage: one failed fetch, caller rejected, cooldown armed.
	outage.Store(true)
	if _, err := v.VerifyToken(context.Background(), tok); err == nil {
		t.Fatal("outage must not authorize")
	}
	if got := fetches.Load(); got != 1 {
		t.Fatalf("failed cold fetch = %d attempts, want exactly 1", got)
	}

	// Endpoint recovers; the cooldown rolls over; concurrent cold callers
	// must all be released by the single recovered-key publication.
	outage.Store(false)
	clock.Advance(2 * time.Hour)
	const waiters = 10
	var wg sync.WaitGroup
	wg.Add(waiters)
	results := make([]error, waiters)
	for i := 0; i < waiters; i++ {
		go func(i int) {
			defer wg.Done()
			ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
			defer cancel()
			_, results[i] = v.VerifyToken(ctx, tok)
		}(i)
	}
	wg.Wait()
	for i, err := range results {
		if err != nil {
			t.Fatalf("waiter %d not released by recovered keys: %v", i, err)
		}
	}
	if got := fetches.Load(); got != 2 {
		t.Fatalf("recovery cost %d total fetches, want exactly 2 (failed cold + rollover)", got)
	}
}
