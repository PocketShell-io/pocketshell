package identity

import (
	"crypto/ed25519"
	"errors"
	"fmt"
	"strconv"
	"sync"
	"time"
)

// transcriptDomain is the constant domain-separation prefix baked into every
// challenge transcript, so signatures can never be reused as signatures of
// some other protocol's messages.
const transcriptDomain = "pocketshell-challenge-v1"

// enrollmentTranscriptDomain separates enrollment signatures from host-auth
// signatures over the same challenge. Enrollment requests must sign this
// v2 payload; the bare challenge transcript alone is not accepted.
const enrollmentTranscriptDomain = "pocketshell-enroll-request-v2"

// EnrollmentTranscript returns the canonical bytes an enrolling device must
// sign: the full challenge binding (role, protocol, domain, device ID,
// account, nonces, expiry) PLUS the exact registration payload — the
// provided Ed25519 public key, the asserted SSH host key and the
// re-enrollment mode. Signing only the challenge transcript is insufficient:
// an attacker could otherwise alter the asserted SSH host key under an
// unaltered challenge signature. There is deliberately no legacy format.
func EnrollmentTranscript(pub ed25519.PublicKey, ch *Challenge, sshHostKey string, reenroll bool) ([]byte, error) {
	if len(pub) != ed25519.PublicKeySize {
		return nil, fmt.Errorf("%w: registration public key must be raw 32-byte Ed25519", ErrBadRequest)
	}
	if ch == nil {
		return nil, ErrChallengeInvalid
	}
	ct, err := ch.Transcript()
	if err != nil {
		return nil, err
	}
	mode := "0"
	if reenroll {
		mode = "1"
	}
	out := make([]byte, 0, 512+len(sshHostKey))
	out = append(out, enrollmentTranscriptDomain...)
	out = lengthPrefix(out, string(ct))
	out = lengthPrefix(out, string(pub))
	out = lengthPrefix(out, sshHostKey)
	out = lengthPrefix(out, mode)
	return out, nil
}

// SignEnrollment signs the enrollment payload with the device private key.
// The private key must match pub; mismatches are client bugs and are
// rejected rather than signed.
func SignEnrollment(priv ed25519.PrivateKey, pub ed25519.PublicKey, ch *Challenge, sshHostKey string, reenroll bool) ([]byte, error) {
	if len(priv) != ed25519.PrivateKeySize {
		return nil, ErrProofInvalid
	}
	if !sameKey(priv.Public().(ed25519.PublicKey), pub) {
		return nil, fmt.Errorf("%w: private key does not match the registration public key", ErrBadRequest)
	}
	t, err := EnrollmentTranscript(pub, ch, sshHostKey, reenroll)
	if err != nil {
		return nil, err
	}
	return ed25519.Sign(priv, t), nil
}

// VerifyEnrollment checks an Ed25519 enrollment signature: the submitted
// public key, SSH host key and re-enrollment mode must be exactly the values
// covered by the signature, on top of the (single-use) challenge binding.
// The caller must have consumed the challenge first.
func VerifyEnrollment(pub ed25519.PublicKey, ch *Challenge, sshHostKey string, reenroll bool, sig []byte) error {
	if len(sig) != ed25519.SignatureSize {
		return fmt.Errorf("%w: bad signature size", ErrProofInvalid)
	}
	t, err := EnrollmentTranscript(pub, ch, sshHostKey, reenroll)
	if err != nil {
		return err
	}
	if !ed25519.Verify(pub, t, sig) {
		return ErrProofInvalid
	}
	return nil
}

// Challenge binds a server nonce to everything that matters about the
// session it was issued for: the account, the device, the role (enroll vs
// host auth), the gateway domain, the protocol version and the connection
// the challenge is meant for. Signatures are made over Transcript(ch);
// replaying them on another connection or for another device fails because
// every one of those fields is inside the signed transcript.
type Challenge struct {
	ID              string
	AccountID       string
	DeviceID        string
	Role            string
	Protocol        string
	Domain          string
	Nonce           string // server-generated per challenge
	ConnectionNonce string // per-connection binding (server- or caller-supplied)
	ExpiresAt       time.Time
}

// ChallengeFromWire rebuilds a Challenge from the public wire fields of the
// challenge response (`/identity/v1/challenge`), so any client (host agent,
// tunnel CLI enroller) can produce the canonical enrollment signature with
// SignEnrollment without hand-rolling the transcript. All fields come from
// the response JSON: challenge_id, device_id, account_id, role, protocol,
// domain, nonce, connection_nonce, expires_at (Unix seconds). The result
// must round-trip to the response's `transcript` bytes; SignEnrollment then
// covers those bindings plus the exact payload values submitted at enroll
// time. There is no legacy format.
func ChallengeFromWire(challengeID, deviceID, accountID, role, protocol, domain, nonce, connectionNonce string, expiresAtUnix int64) (*Challenge, error) {
	if challengeID == "" || len(challengeID) > 64 {
		return nil, fmt.Errorf("%w: bad challenge id", ErrBadRequest)
	}
	if !ValidDeviceID(deviceID) {
		return nil, fmt.Errorf("%w: bad device id", ErrBadRequest)
	}
	if !ValidAccountID(accountID) {
		return nil, fmt.Errorf("%w: bad account id", ErrBadRequest)
	}
	if err := validateChallengeField(role, 64); err != nil {
		return nil, fmt.Errorf("%w: bad role", ErrBadRequest)
	}
	if err := validateChallengeField(protocol, 64); err != nil {
		return nil, fmt.Errorf("%w: bad protocol", ErrBadRequest)
	}
	if err := validateChallengeField(domain, 253); err != nil {
		return nil, fmt.Errorf("%w: bad domain", ErrBadRequest)
	}
	if nonce == "" || len(nonce) > 256 || connectionNonce == "" || len(connectionNonce) > 256 {
		return nil, fmt.Errorf("%w: bad nonce", ErrBadRequest)
	}
	if expiresAtUnix <= 0 {
		return nil, fmt.Errorf("%w: bad expires_at", ErrBadRequest)
	}
	return &Challenge{
		ID:              challengeID,
		DeviceID:        deviceID,
		AccountID:       accountID,
		Role:            role,
		Protocol:        protocol,
		Domain:          domain,
		Nonce:           nonce,
		ConnectionNonce: connectionNonce,
		ExpiresAt:       time.Unix(expiresAtUnix, 0).UTC(),
	}, nil
}

// Transcript returns the canonical bytes the device private key must sign:
// the domain separator followed by length-prefixed role, protocol, domain,
// device ID, account ID, nonce, connection nonce and expiry.
func (ch *Challenge) Transcript() ([]byte, error) {
	if ch == nil {
		return nil, ErrChallengeInvalid
	}
	out := make([]byte, 0, 256)
	out = append(out, transcriptDomain...)
	out = lengthPrefix(out, ch.Role)
	out = lengthPrefix(out, ch.Protocol)
	out = lengthPrefix(out, ch.Domain)
	out = lengthPrefix(out, ch.DeviceID)
	out = lengthPrefix(out, ch.AccountID)
	out = lengthPrefix(out, ch.Nonce)
	out = lengthPrefix(out, ch.ConnectionNonce)
	out = lengthPrefix(out, strconv.FormatInt(ch.ExpiresAt.Unix(), 10))
	return out, nil
}

// Sign produces the Ed25519 signature over the challenge transcript with
// the device private key.
func Sign(priv ed25519.PrivateKey, ch *Challenge) ([]byte, error) {
	if len(priv) != ed25519.PrivateKeySize {
		return nil, ErrProofInvalid
	}
	t, err := ch.Transcript()
	if err != nil {
		return nil, err
	}
	return ed25519.Sign(priv, t), nil
}

// Verify checks an Ed25519 signature over the challenge transcript. It does
// not consume the challenge; callers must enforce single-use and the
// deadline via ChallengeIssuer.Consume before or after calling Verify.
func Verify(pub ed25519.PublicKey, ch *Challenge, sig []byte) error {
	if len(pub) != ed25519.PublicKeySize {
		return fmt.Errorf("%w: bad public key", ErrProofInvalid)
	}
	if len(sig) != ed25519.SignatureSize {
		return fmt.Errorf("%w: bad signature size", ErrProofInvalid)
	}
	t, err := ch.Transcript()
	if err != nil {
		return err
	}
	if !ed25519.Verify(pub, t, sig) {
		return ErrProofInvalid
	}
	return nil
}

// VerifyDeviceProof checks a device's proof of possession: the device must
// not be revoked, must be the one the challenge was issued for, and the
// signature must verify under the enrolled public key.
func VerifyDeviceProof(dev Device, ch *Challenge, sig []byte) error {
	if dev.Revoked {
		return ErrDeviceRevoked
	}
	if dev.ID != ch.DeviceID {
		return fmt.Errorf("%w: challenge bound to device %q", ErrChallengeInvalid, ch.DeviceID)
	}
	if !ValidPublicKey(dev.PublicKey) {
		return fmt.Errorf("%w: stored public key has bad size", ErrProofInvalid)
	}
	return Verify(ed25519.PublicKey(dev.PublicKey), ch, sig)
}

// ChallengeParams describes a challenge to issue. AccountID comes only from
// a verified principal. ConnectionNonce may be supplied by the caller (the
// tunnel worker binds a challenge to its connection epoch); when empty a
// random one is generated.
type ChallengeParams struct {
	AccountID       string
	DeviceID        string
	Role            string
	Protocol        string
	Domain          string
	ConnectionNonce string
}

// ChallengeIssuer issues and consumes single-use, expiring challenges with
// bounded outstanding challenges per account AND in aggregate (global max),
// so many accounts cannot multiply the memory footprint. Consume removes the
// challenge, so a second use of the same ID always fails (replay safety).
type ChallengeIssuer struct {
	ttl           time.Duration
	maxPerAccount int
	globalMax     int
	clock         func() time.Time

	mu         sync.Mutex
	byID       map[string]*Challenge
	perAccount map[string]int
}

// ChallengeOption customizes an issuer.
type ChallengeOption func(*ChallengeIssuer)

// WithGlobalMax bounds the total number of live challenges across all
// accounts (default 4096).
func WithGlobalMax(n int) ChallengeOption {
	return func(ci *ChallengeIssuer) {
		if n > 0 {
			ci.globalMax = n
		}
	}
}

// NewChallengeIssuer builds an issuer. ttl defaults to 2 minutes and
// maxPerAccount to 16 outstanding challenges; the aggregate default is 4096.
func NewChallengeIssuer(ttl time.Duration, maxPerAccount int, clock func() time.Time, opts ...ChallengeOption) *ChallengeIssuer {
	if ttl <= 0 {
		ttl = 2 * time.Minute
	}
	if maxPerAccount <= 0 {
		maxPerAccount = 16
	}
	if clock == nil {
		clock = time.Now
	}
	ci := &ChallengeIssuer{
		ttl:           ttl,
		maxPerAccount: maxPerAccount,
		globalMax:     4096,
		clock:         clock,
		byID:          make(map[string]*Challenge),
		perAccount:    make(map[string]int),
	}
	for _, opt := range opts {
		opt(ci)
	}
	return ci
}

// Issue creates a challenge after validating the binding fields.
func (ci *ChallengeIssuer) Issue(p ChallengeParams) (*Challenge, error) {
	if !ValidAccountID(p.AccountID) {
		return nil, fmt.Errorf("%w: bad account", ErrBadRequest)
	}
	if !ValidDeviceID(p.DeviceID) {
		return nil, fmt.Errorf("%w: bad device id", ErrBadRequest)
	}
	if err := validateChallengeField(p.Role, 64); err != nil {
		return nil, fmt.Errorf("%w: bad role", ErrBadRequest)
	}
	if err := validateChallengeField(p.Protocol, 64); err != nil {
		return nil, fmt.Errorf("%w: bad protocol", ErrBadRequest)
	}
	if err := validateChallengeField(p.Domain, 253); err != nil {
		return nil, fmt.Errorf("%w: bad domain", ErrBadRequest)
	}
	connNonce := p.ConnectionNonce
	if connNonce == "" {
		nonce, err := randomToken(32)
		if err != nil {
			return nil, fmt.Errorf("identity: nonce: %w", err)
		}
		connNonce = nonce
	} else if len(connNonce) > 256 {
		return nil, fmt.Errorf("%w: connection nonce too long", ErrBadRequest)
	}
	nonce, err := randomToken(32)
	if err != nil {
		return nil, fmt.Errorf("identity: nonce: %w", err)
	}
	id, err := randomToken(16)
	if err != nil {
		return nil, fmt.Errorf("identity: challenge id: %w", err)
	}
	now := ci.clock().UTC()
	ch := &Challenge{
		ID:              id,
		AccountID:       p.AccountID,
		DeviceID:        p.DeviceID,
		Role:            p.Role,
		Protocol:        p.Protocol,
		Domain:          p.Domain,
		Nonce:           nonce,
		ConnectionNonce: connNonce,
		ExpiresAt:       now.Add(ci.ttl),
	}

	ci.mu.Lock()
	defer ci.mu.Unlock()
	ci.sweepLocked(now)
	if ci.perAccount[p.AccountID] >= ci.maxPerAccount {
		return nil, ErrLimitExceeded
	}
	if ci.globalMax > 0 && len(ci.byID) >= ci.globalMax {
		return nil, ErrLimitExceeded
	}
	ci.byID[ch.ID] = ch
	ci.perAccount[p.AccountID]++
	return ch, nil
}

// Consume atomically removes and returns the challenge. The second call for
// the same ID fails with ErrChallengeInvalid, as does any call after the
// deadline. Callers must then check AccountID/DeviceID/Role/Protocol against
// what they expect.
func (ci *ChallengeIssuer) Consume(id string) (*Challenge, error) {
	if id == "" || len(id) > 64 {
		return nil, ErrChallengeInvalid
	}
	ci.mu.Lock()
	defer ci.mu.Unlock()
	ch, ok := ci.byID[id]
	if !ok {
		return nil, ErrChallengeInvalid
	}
	delete(ci.byID, id)
	ci.perAccount[ch.AccountID]--
	if ci.perAccount[ch.AccountID] <= 0 {
		delete(ci.perAccount, ch.AccountID)
	}
	if ci.clock().UTC().After(ch.ExpiresAt) {
		return nil, fmt.Errorf("%w: expired", ErrChallengeInvalid)
	}
	return ch, nil
}

// Outstanding reports how many live challenges an account holds (tests).
func (ci *ChallengeIssuer) Outstanding(accountID string) int {
	ci.mu.Lock()
	defer ci.mu.Unlock()
	return ci.perAccount[accountID]
}

func (ci *ChallengeIssuer) sweepLocked(now time.Time) {
	for id, ch := range ci.byID {
		if now.After(ch.ExpiresAt) {
			delete(ci.byID, id)
			ci.perAccount[ch.AccountID]--
			if ci.perAccount[ch.AccountID] <= 0 {
				delete(ci.perAccount, ch.AccountID)
			}
		}
	}
}

func validateChallengeField(s string, max int) error {
	if s == "" || len(s) > max {
		return errors.New("empty or oversized")
	}
	for i := 0; i < len(s); i++ {
		c := s[i]
		if c <= 0x20 || c >= 0x7f {
			return errors.New("bad character")
		}
	}
	return nil
}
