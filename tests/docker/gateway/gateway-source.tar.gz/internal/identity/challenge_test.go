package identity

import (
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"errors"
	"strings"
	"sync"
	"testing"
	"time"
)

func testChallenge(clock *fakeClock) *Challenge {
	return &Challenge{
		ID:              "challenge-id-1",
		AccountID:       "google:113958430858354529072",
		DeviceID:        "laptop-1",
		Role:            RoleEnroll,
		Protocol:        ProtocolIdentity,
		Domain:          "gateway.pocketshell.io",
		Nonce:           "AAAA_server_nonce_AAAA",
		ConnectionNonce: "BBBB_connection_nonce_BBB",
		ExpiresAt:       clock.Now().Add(2 * time.Minute),
	}
}

func TestTranscriptDeterministicAndBound(t *testing.T) {
	clock := newFakeClock()
	ch := testChallenge(clock)
	t1, err := ch.Transcript()
	if err != nil {
		t.Fatal(err)
	}
	t2, err := ch.Transcript()
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(t1, t2) {
		t.Fatal("transcript must be deterministic")
	}
	// Every binding field must change the transcript.
	mutate := func(f func(*Challenge)) []byte {
		c := *ch
		f(&c)
		b, err := c.Transcript()
		if err != nil {
			t.Fatal(err)
		}
		return b
	}
	for name, other := range map[string][]byte{
		"role":      mutate(func(c *Challenge) { c.Role = RoleHost }),
		"protocol":  mutate(func(c *Challenge) { c.Protocol = "other/1" }),
		"domain":    mutate(func(c *Challenge) { c.Domain = "evil.example" }),
		"device":    mutate(func(c *Challenge) { c.DeviceID = "other" }),
		"account":   mutate(func(c *Challenge) { c.AccountID = "google:999" }),
		"nonce":     mutate(func(c *Challenge) { c.Nonce = "different" }),
		"connnonce": mutate(func(c *Challenge) { c.ConnectionNonce = "different" }),
		"expiry":    mutate(func(c *Challenge) { c.ExpiresAt = ch.ExpiresAt.Add(time.Second) }),
	} {
		if bytes.Equal(t1, other) {
			t.Fatalf("transcript not bound to %s", name)
		}
	}
	// Length prefixes: field values containing separator-like content cannot
	// alias a different field split.
	alias := &Challenge{
		ID: ch.ID, AccountID: ch.AccountID, DeviceID: "l", Role: "aptop-1" + ch.Role,
		Protocol: ch.Protocol, Domain: ch.Domain, Nonce: ch.Nonce,
		ConnectionNonce: ch.ConnectionNonce, ExpiresAt: ch.ExpiresAt,
	}
	at, err := alias.Transcript()
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Equal(t1, at) {
		t.Fatal("transcript must be unambiguous under field splitting")
	}
}

func TestSignVerifyRoundtrip(t *testing.T) {
	clock := newFakeClock()
	ch := testChallenge(clock)
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	sig, err := Sign(priv, ch)
	if err != nil {
		t.Fatal(err)
	}
	if err := Verify(pub, ch, sig); err != nil {
		t.Fatalf("verify own signature: %v", err)
	}
	// Tampered signature or transcript must fail.
	if err := Verify(pub, ch, append(sig, 0)); err == nil {
		t.Fatal("bad signature size accepted")
	}
	bad := append([]byte(nil), sig...)
	bad[0] ^= 0xff
	if err := Verify(pub, ch, bad); err == nil {
		t.Fatal("tampered signature accepted")
	}
	otherPub, otherPriv, _ := ed25519.GenerateKey(rand.Reader)
	otherSig, _ := Sign(otherPriv, ch)
	if err := Verify(pub, ch, otherSig); err == nil {
		t.Fatal("signature by another key accepted")
	}
	_ = otherPub
	// A different challenge transcript must not verify.
	other := testChallenge(clock)
	other.Nonce = "different"
	if err := Verify(pub, other, sig); err == nil {
		t.Fatal("signature replayed onto a different challenge accepted")
	}
}

func TestVerifyDeviceProof(t *testing.T) {
	clock := newFakeClock()
	ch := testChallenge(clock)
	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	sig, _ := Sign(priv, ch)
	dev := Device{ID: ch.DeviceID, AccountID: ch.AccountID, PublicKey: pub}

	if err := VerifyDeviceProof(dev, ch, sig); err != nil {
		t.Fatalf("valid proof rejected: %v", err)
	}
	revoked := dev
	revoked.Revoked = true
	if err := VerifyDeviceProof(revoked, ch, sig); !errors.Is(err, ErrDeviceRevoked) {
		t.Fatalf("revoked device proof: %v, want ErrDeviceRevoked", err)
	}
	other := dev
	other.ID = "other-device"
	if err := VerifyDeviceProof(other, ch, sig); !errors.Is(err, ErrChallengeInvalid) {
		t.Fatalf("wrong device proof: %v, want ErrChallengeInvalid", err)
	}
}

func TestChallengeIssuerSingleUse(t *testing.T) {
	clock := newFakeClock()
	ci := NewChallengeIssuer(time.Minute, 16, clock.Now)
	ch, err := ci.Issue(ChallengeParams{
		AccountID: "google:123", DeviceID: "dev-1",
		Role: RoleEnroll, Protocol: ProtocolIdentity, Domain: "gateway.pocketshell.io",
	})
	if err != nil {
		t.Fatal(err)
	}
	got, err := ci.Consume(ch.ID)
	if err != nil {
		t.Fatal(err)
	}
	if got.ID != ch.ID || got.Nonce != ch.Nonce {
		t.Fatal("consumed challenge mismatch")
	}
	if _, err := ci.Consume(ch.ID); !errors.Is(err, ErrChallengeInvalid) {
		t.Fatalf("replayed challenge consume: %v, want ErrChallengeInvalid", err)
	}
	if _, err := ci.Consume("does-not-exist"); !errors.Is(err, ErrChallengeInvalid) {
		t.Fatalf("unknown challenge: %v", err)
	}
}

func TestChallengeIssuerExpiry(t *testing.T) {
	clock := newFakeClock()
	ci := NewChallengeIssuer(time.Minute, 16, clock.Now)
	ch, _ := ci.Issue(ChallengeParams{
		AccountID: "google:123", DeviceID: "dev-1",
		Role: RoleEnroll, Protocol: ProtocolIdentity, Domain: "d",
	})
	clock.Advance(time.Minute + time.Second)
	if _, err := ci.Consume(ch.ID); err == nil || !errors.Is(err, ErrChallengeInvalid) {
		t.Fatalf("expired challenge: %v, want ErrChallengeInvalid", err)
	}
}

func TestChallengeIssuerPerAccountBound(t *testing.T) {
	clock := newFakeClock()
	ci := NewChallengeIssuer(time.Minute, 2, clock.Now)
	issue := func(account string) error {
		_, err := ci.Issue(ChallengeParams{
			AccountID: account, DeviceID: "dev-1",
			Role: RoleEnroll, Protocol: ProtocolIdentity, Domain: "d",
		})
		return err
	}
	if err := issue("google:1"); err != nil {
		t.Fatal(err)
	}
	if err := issue("google:1"); err != nil {
		t.Fatal(err)
	}
	if err := issue("google:1"); !errors.Is(err, ErrLimitExceeded) {
		t.Fatalf("third challenge: %v, want ErrLimitExceeded", err)
	}
	// Another account is unaffected; expiring frees the quota.
	if err := issue("google:2"); err != nil {
		t.Fatalf("other account blocked: %v", err)
	}
	clock.Advance(time.Minute + time.Second)
	if err := issue("google:1"); err != nil {
		t.Fatalf("expired challenges must free quota: %v", err)
	}
	if ci.Outstanding("google:1") > 2 {
		t.Fatal("outstanding bound violated")
	}
}

func TestChallengeIssuerCallerConnectionNonce(t *testing.T) {
	ci := NewChallengeIssuer(time.Minute, 4, nil)
	ch, err := ci.Issue(ChallengeParams{
		AccountID: "google:123", DeviceID: "dev-1",
		Role: RoleHost, Protocol: "pocketshell-tunnel/1", Domain: "gateway.pocketshell.io",
		ConnectionNonce: "conn-epoch-42",
	})
	if err != nil {
		t.Fatal(err)
	}
	if ch.ConnectionNonce != "conn-epoch-42" {
		t.Fatalf("connection nonce = %q, want caller-supplied", ch.ConnectionNonce)
	}
}

func TestChallengeIssuerConcurrentConsume(t *testing.T) {
	ci := NewChallengeIssuer(time.Minute, 64, nil)
	ch, err := ci.Issue(ChallengeParams{
		AccountID: "google:123", DeviceID: "dev-1",
		Role: RoleEnroll, Protocol: ProtocolIdentity, Domain: "d",
	})
	if err != nil {
		t.Fatal(err)
	}
	const n = 32
	errs := make(chan error, n)
	var wg sync.WaitGroup
	for i := 0; i < n; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			_, err := ci.Consume(ch.ID)
			errs <- err
		}()
	}
	wg.Wait()
	close(errs)
	wins := 0
	for err := range errs {
		if err == nil {
			wins++
		} else if !errors.Is(err, ErrChallengeInvalid) {
			t.Fatalf("unexpected error: %v", err)
		}
	}
	if wins != 1 {
		t.Fatalf("single-use violated: %d consumers won", wins)
	}
}

func TestChallengeIssuerValidation(t *testing.T) {
	ci := NewChallengeIssuer(time.Minute, 4, nil)
	cases := []struct {
		name string
		p    ChallengeParams
	}{
		{"bad account", ChallengeParams{AccountID: "user@example.com", DeviceID: "d-1", Role: RoleEnroll, Protocol: ProtocolIdentity, Domain: "d"}},
		{"bad device", ChallengeParams{AccountID: "google:1", DeviceID: "", Role: RoleEnroll, Protocol: ProtocolIdentity, Domain: "d"}},
		{"bad role", ChallengeParams{AccountID: "google:1", DeviceID: "d-1", Role: strings.Repeat("x", 65), Protocol: ProtocolIdentity, Domain: "d"}},
		{"role with space", ChallengeParams{AccountID: "google:1", DeviceID: "d-1", Role: "bad role", Protocol: ProtocolIdentity, Domain: "d"}},
		{"oversized conn nonce", ChallengeParams{AccountID: "google:1", DeviceID: "d-1", Role: RoleEnroll, Protocol: ProtocolIdentity, Domain: "d", ConnectionNonce: strings.Repeat("x", 300)}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if _, err := ci.Issue(tc.p); !errors.Is(err, ErrBadRequest) {
				t.Fatalf("err = %v, want ErrBadRequest", err)
			}
		})
	}
}
