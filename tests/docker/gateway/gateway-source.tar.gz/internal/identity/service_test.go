package identity

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// stubVerifier maps fixed bearer tokens to Principals — keeps HTTP e2e tests
// offline while exercising the real service wiring. Expiry is explicit and
// positive: the service rejects zero-expiry principals (production never
// trusts them, and test doubles must carry a real lifetime).
type stubVerifier struct {
	principals map[string]Principal
	expiry     time.Time
}

// newStubVerifier builds a stub whose principals expire in the future.
func newStubVerifier(expiry time.Time, principals map[string]Principal) stubVerifier {
	return stubVerifier{principals: principals, expiry: expiry}
}

func (sv stubVerifier) VerifyToken(_ context.Context, token string) (Principal, error) {
	p, ok := sv.principals[token]
	if !ok {
		return Principal{}, fmt.Errorf("%w: stub", ErrUnauthorized)
	}
	// Fill in the fixture lifetime only when the principal does not declare
	// its own: expiry-boundary tests need self-carried past/zero values.
	if p.ExpiresAt.IsZero() {
		p.ExpiresAt = sv.expiry
	}
	return p, nil
}

const (
	tokenA = "token-alice"
	tokenB = "token-bob"
	emailA = "alice@example.com"
	emailB = "bob@example.com"
	subA   = "113958430858354529072"
	subB   = "223958430858354529081"
)

func newTestService(t *testing.T, mutate func(*Config)) *Service {
	t.Helper()
	cfg := Config{
		Verifier: newStubVerifier(time.Now().Add(time.Hour), map[string]Principal{
			tokenA: {AccountID: "google:" + subA, Email: emailA},
			tokenB: {AccountID: "google:" + subB, Email: emailB},
		}),
		StorePath: filepath.Join(t.TempDir(), "devices.json"),
		Clock:     time.Now,
		Logger:    func(string, ...any) {},
	}
	if mutate != nil {
		mutate(&cfg)
	}
	s, err := NewService(cfg)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

func newKeyPair(t *testing.T) (ed25519.PublicKey, ed25519.PrivateKey) {
	t.Helper()
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	return pub, priv
}

func postJSON(t *testing.T, handler http.Handler, path, token string, body any) *http.Response {
	t.Helper()
	raw, err := json.Marshal(body)
	if err != nil {
		t.Fatal(err)
	}
	req := httptest.NewRequest(http.MethodPost, path, strings.NewReader(string(raw)))
	req.Host = "gateway.test"
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	rec := httptest.NewRecorder()
	handler.ServeHTTP(rec, req)
	return rec.Result()
}

func getJSON(t *testing.T, handler http.Handler, path, token string) *http.Response {
	t.Helper()
	req := httptest.NewRequest(http.MethodGet, path, nil)
	req.Host = "gateway.test"
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	rec := httptest.NewRecorder()
	handler.ServeHTTP(rec, req)
	return rec.Result()
}

func decodeBody(t *testing.T, resp *http.Response, v any) {
	t.Helper()
	defer resp.Body.Close()
	if err := json.NewDecoder(resp.Body).Decode(v); err != nil {
		t.Fatalf("decode %s response: %v", resp.Status, err)
	}
}

// runEnrollment performs the full two-step client flow: request a challenge,
// sign its transcript with the device private key, enroll.
func runEnrollment(t *testing.T, s *Service, token, deviceID string, priv ed25519.PrivateKey, hostKey string, reenroll bool) *http.Response {
	t.Helper()
	resp := postJSON(t, s, "/identity/v1/challenge", token, map[string]string{"device_id": deviceID})
	if resp.StatusCode != http.StatusOK {
		return resp
	}
	var ch challengeResponse
	decodeBody(t, resp, &ch)
	transcript, err := base64.StdEncoding.DecodeString(ch.Transcript)
	if err != nil {
		t.Fatalf("challenge transcript: %v", err)
	}
	// The response transcript must match the documented Challenge layout.
	rebuilt := &Challenge{
		ID: ch.ChallengeID, DeviceID: ch.DeviceID, Role: ch.Role, Protocol: ch.Protocol,
		Domain: ch.Domain, Nonce: ch.Nonce, ConnectionNonce: ch.ConnectionNonce,
		ExpiresAt: time.Unix(ch.ExpiresAt, 0).UTC(),
		AccountID: accountIDForToken(token),
	}
	want, err := rebuilt.Transcript()
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(transcript, want) {
		t.Fatal("wire transcript differs from Challenge.Transcript()")
	}
	// The enrollment signature covers the challenge binding PLUS the exact
	// payload (public key, SSH host key, re-enrollment mode).
	pub := priv.Public().(ed25519.PublicKey)
	sig, err := SignEnrollment(priv, pub, rebuilt, hostKey, reenroll)
	if err != nil {
		t.Fatal(err)
	}
	return postJSON(t, s, "/identity/v1/enroll", token, enrollRequest{
		DeviceID:    deviceID,
		PublicKey:   base64.StdEncoding.EncodeToString(pub),
		SSHHostKey:  hostKey,
		ChallengeID: ch.ChallengeID,
		Signature:   base64.StdEncoding.EncodeToString(sig),
		Reenroll:    reenroll,
	})
}

func accountIDForToken(token string) string {
	if token == tokenA {
		return "google:" + subA
	}
	return "google:" + subB
}

const testHostKey = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIExAmPlE+host+key+data=="

func TestEnrollFlowEndToEnd(t *testing.T) {
	s := newTestService(t, func(c *Config) { c.Domain = "gateway.test" })
	pub, priv := newKeyPair(t)

	resp := runEnrollment(t, s, tokenA, "laptop-1", priv, testHostKey, false)
	if resp.StatusCode != http.StatusCreated {
		t.Fatalf("enroll status = %s, want 201", resp.Status)
	}
	var dev deviceJSON
	decodeBody(t, resp, &dev)
	if dev.ID != "laptop-1" || dev.AccountID != "google:"+subA || dev.Revoked {
		t.Fatalf("enrolled device = %+v", dev)
	}
	var key []byte
	key, err := base64.StdEncoding.DecodeString(dev.PublicKey)
	if err != nil || !sameKey(key, pub) {
		t.Fatalf("stored key mismatch: %v", err)
	}

	// Contract surface: Store().GetDevice and TokenAuthenticator.
	got, err := s.Store().GetDevice("laptop-1")
	if err != nil || !sameKey(got.PublicKey, pub) {
		t.Fatalf("Store.GetDevice: %v", err)
	}
	p, err := s.TokenAuthenticator()(t.Context(), tokenA)
	if err != nil || p.AccountID != "google:"+subA {
		t.Fatalf("TokenAuthenticator: %v", err)
	}

	// List shows only the owner's devices.
	list := getJSON(t, s, "/identity/v1/devices", tokenA)
	var out struct {
		Devices []deviceJSON `json:"devices"`
	}
	decodeBody(t, list, &out)
	if len(out.Devices) != 1 || out.Devices[0].ID != "laptop-1" {
		t.Fatalf("list = %+v", out.Devices)
	}
}

func TestEnrollRequiresAuth(t *testing.T) {
	s := newTestService(t, nil)
	resp := postJSON(t, s, "/identity/v1/challenge", "", map[string]string{"device_id": "dev"})
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("no-token challenge = %s", resp.Status)
	}
	resp = postJSON(t, s, "/identity/v1/enroll", "wrong-token", enrollRequest{})
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("bad-token enroll = %s", resp.Status)
	}
	resp = getJSON(t, s, "/identity/v1/devices", "")
	if resp.StatusCode != http.StatusUnauthorized {
		t.Fatalf("no-token list = %s", resp.Status)
	}
}

func TestReplayAndWrongKeyFail(t *testing.T) {
	s := newTestService(t, nil)
	_, priv := newKeyPair(t)

	// Capture the challenge to replay it manually.
	resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-1"})
	var ch challengeResponse
	decodeBody(t, resp, &ch)
	rebuilt := &Challenge{
		ID: ch.ChallengeID, DeviceID: ch.DeviceID, Role: ch.Role, Protocol: ch.Protocol,
		Domain: ch.Domain, Nonce: ch.Nonce, ConnectionNonce: ch.ConnectionNonce,
		ExpiresAt: time.Unix(ch.ExpiresAt, 0).UTC(), AccountID: accountIDForToken(tokenA),
	}
	pub := priv.Public().(ed25519.PublicKey)
	sig, err := SignEnrollment(priv, pub, rebuilt, testHostKey, false)
	if err != nil {
		t.Fatal(err)
	}
	enrollReq := func(challengeID, sigB64 string) enrollRequest {
		return enrollRequest{
			DeviceID: "dev-1", PublicKey: base64.StdEncoding.EncodeToString(pub),
			SSHHostKey: testHostKey, ChallengeID: challengeID,
			Signature: sigB64,
		}
	}

	first := postJSON(t, s, "/identity/v1/enroll", tokenA, enrollReq(ch.ChallengeID, base64.StdEncoding.EncodeToString(sig)))
	if first.StatusCode != http.StatusCreated {
		t.Fatalf("first enroll = %s", first.Status)
	}
	// Replay: same challenge ID and signature a second time.
	replay := postJSON(t, s, "/identity/v1/enroll", tokenA, enrollReq(ch.ChallengeID, base64.StdEncoding.EncodeToString(sig)))
	if replay.StatusCode != http.StatusUnauthorized {
		t.Fatalf("replayed challenge = %s, want 401", replay.Status)
	}

	// A signature made with a different private key than the claimed public
	// key fails even though the payload is otherwise valid.
	resp = postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-2"})
	decodeBody(t, resp, &ch)
	_, evil := newKeyPair(t)
	payload, err := EnrollmentTranscript(pub, rebuilt, testHostKey, false)
	if err != nil {
		t.Fatal(err)
	}
	evilSig := ed25519.Sign(evil, payload) // signed under wrong key
	bad := postJSON(t, s, "/identity/v1/enroll", tokenA, enrollRequest{
		DeviceID: "dev-2", PublicKey: base64.StdEncoding.EncodeToString(pub),
		SSHHostKey: testHostKey, ChallengeID: ch.ChallengeID,
		Signature: base64.StdEncoding.EncodeToString(evilSig),
	})
	if bad.StatusCode != http.StatusUnauthorized {
		t.Fatalf("wrong private key = %s, want 401", bad.Status)
	}
	if _, err := s.Store().GetDevice("dev-2"); !errors.Is(err, ErrDeviceNotFound) {
		t.Fatal("failed proof must not enroll anything")
	}

	// Challenge issued for one device cannot enroll another.
	resp = postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-3"})
	decodeBody(t, resp, &ch)
	other := *rebuilt
	other.ID = ch.ChallengeID
	other.DeviceID = ch.DeviceID
	other.Nonce = ch.Nonce
	other.ConnectionNonce = ch.ConnectionNonce
	other.ExpiresAt = time.Unix(ch.ExpiresAt, 0).UTC()
	sig3, err := SignEnrollment(priv, pub, &other, testHostKey, false)
	if err != nil {
		t.Fatal(err)
	}
	misuse := postJSON(t, s, "/identity/v1/enroll", tokenA, enrollRequest{
		DeviceID: "dev-4", PublicKey: base64.StdEncoding.EncodeToString(pub),
		SSHHostKey: testHostKey, ChallengeID: ch.ChallengeID,
		Signature: base64.StdEncoding.EncodeToString(sig3),
	})
	if misuse.StatusCode != http.StatusBadRequest {
		t.Fatalf("cross-device challenge = %s, want 400", misuse.Status)
	}
}

func TestNoMutableKeyReplacementWithoutExplicitReenrollment(t *testing.T) {
	_, priv1 := newKeyPair(t)
	pub2, priv2 := newKeyPair(t)
	s := newTestService(t, nil) // AllowReenrollment defaults to false

	if resp := runEnrollment(t, s, tokenA, "dev-1", priv1, testHostKey, false); resp.StatusCode != http.StatusCreated {
		t.Fatalf("initial enroll = %s", resp.Status)
	}
	// Same key + host key is idempotent.
	same := runEnrollment(t, s, tokenA, "dev-1", priv1, testHostKey, false)
	if same.StatusCode != http.StatusOK {
		t.Fatalf("idempotent re-enroll = %s, want 200", same.Status)
	}
	// Different key, no explicit re-enroll flag: rejected.
	sub := runEnrollment(t, s, tokenA, "dev-1", priv2, testHostKey, false)
	if sub.StatusCode != http.StatusConflict {
		t.Fatalf("silent key replacement = %s, want 409", sub.Status)
	}
	// Explicit flag but gateway policy off: rejected.
	forced := runEnrollment(t, s, tokenA, "dev-1", priv2, testHostKey, true)
	if forced.StatusCode != http.StatusForbidden {
		t.Fatalf("re-enroll while disabled = %s, want 403", forced.Status)
	}
	got, _ := s.Store().GetDevice("dev-1")
	if !sameKey(got.PublicKey, mustPub(priv1)) {
		t.Fatal("original key must survive rejected re-enrollments")
	}
	// Host key substitution is equally gated.
	hostSub := runEnrollment(t, s, tokenA, "dev-1", priv1, "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAADIFferent+host+key==", false)
	if hostSub.StatusCode != http.StatusConflict {
		t.Fatalf("host key substitution = %s, want 409", hostSub.Status)
	}

	// With the operator opt-in, explicit re-enrollment replaces the key.
	s2 := newTestService(t, func(c *Config) { c.AllowReenrollment = true })
	if resp := runEnrollment(t, s2, tokenA, "dev-1", priv1, testHostKey, false); resp.StatusCode != http.StatusCreated {
		t.Fatalf("initial enroll = %s", resp.Status)
	}
	rotated := runEnrollment(t, s2, tokenA, "dev-1", priv2, testHostKey, true)
	if rotated.StatusCode != http.StatusOK {
		t.Fatalf("explicit re-enroll = %s, want 200", rotated.Status)
	}
	got, _ = s2.Store().GetDevice("dev-1")
	if !sameKey(got.PublicKey, pub2) {
		t.Fatal("key was not rotated by explicit re-enrollment")
	}
}

func mustPub(priv ed25519.PrivateKey) ed25519.PublicKey { return priv.Public().(ed25519.PublicKey) }

func TestCrossOwnerIsolation(t *testing.T) {
	_, privA := newKeyPair(t)
	s := newTestService(t, nil)
	if resp := runEnrollment(t, s, tokenA, "alice-device", privA, testHostKey, false); resp.StatusCode != http.StatusCreated {
		t.Fatalf("alice enroll = %s", resp.Status)
	}

	// Bob cannot register a device under Alice's ID.
	_, privB := newKeyPair(t)
	takeover := runEnrollment(t, s, tokenB, "alice-device", privB, testHostKey, false)
	if takeover.StatusCode != http.StatusForbidden {
		t.Fatalf("bob enrolling alice's device id = %s, want 403", takeover.Status)
	}
	takeoverReenroll := runEnrollment(t, s, tokenB, "alice-device", privB, testHostKey, true)
	if takeoverReenroll.StatusCode != http.StatusForbidden {
		t.Fatalf("bob re-enrolling alice's device id = %s, want 403", takeoverReenroll.Status)
	}
	// Bob cannot revoke Alice's device — and cannot even see it existed.
	resp := postJSON(t, s, "/identity/v1/devices/alice-device/revoke", tokenB, nil)
	if resp.StatusCode != http.StatusNotFound {
		t.Fatalf("bob revoking alice's device = %s, want 404", resp.Status)
	}
	// Bob's list must not contain Alice's device.
	var out struct {
		Devices []deviceJSON `json:"devices"`
	}
	decodeBody(t, getJSON(t, s, "/identity/v1/devices", tokenB), &out)
	for _, d := range out.Devices {
		if d.ID == "alice-device" {
			t.Fatal("alice's device leaked into bob's list")
		}
	}
	// The device survives all of it, untouched.
	got, err := s.Store().GetDevice("alice-device")
	if err != nil || got.Revoked {
		t.Fatalf("alice's device damaged: %+v err=%v", got, err)
	}

	// Alice revokes her own device; it disappears from usability but the
	// tombstone stays so the ID cannot silently come back.
	resp = postJSON(t, s, "/identity/v1/devices/alice-device/revoke", tokenA, nil)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("owner revoke = %s", resp.Status)
	}
	got, err = s.Store().GetDevice("alice-device")
	if err != nil || !got.Revoked {
		t.Fatalf("revocation not visible: %+v err=%v", got, err)
	}
	// Re-enrolling a revoked device is refused even with the same key.
	resp = runEnrollment(t, s, tokenA, "alice-device", privA, testHostKey, false)
	if resp.StatusCode != http.StatusConflict {
		t.Fatalf("revive revoked device = %s, want 409", resp.Status)
	}
	// Revoking again is idempotent and fires no callback (covered below).
	resp = postJSON(t, s, "/identity/v1/devices/alice-device/revoke", tokenA, nil)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("second revoke = %s", resp.Status)
	}
}

func TestRevocationCallbackFiresAfterPersist(t *testing.T) {
	dir := t.TempDir()
	s := newTestService(t, func(c *Config) { c.StorePath = filepath.Join(dir, "devices.json") })
	_, priv := newKeyPair(t)
	if resp := runEnrollment(t, s, tokenA, "dev-1", priv, testHostKey, false); resp.StatusCode != http.StatusCreated {
		t.Fatalf("enroll = %s", resp.Status)
	}

	var callbackDev Device
	var persistedAtCallback bool
	s.OnRevoke(func(d Device) {
		callbackDev = d
		// The callback must observe the revocation already durable on disk.
		fs, err := NewFileStore(filepath.Join(dir, "devices.json"))
		if err != nil {
			t.Errorf("registry unreadable during callback: %v", err)
			return
		}
		got, err := fs.GetDevice(d.ID)
		persistedAtCallback = err == nil && got.Revoked
	})
	resp := postJSON(t, s, "/identity/v1/devices/dev-1/revoke", tokenA, nil)
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("revoke = %s", resp.Status)
	}
	if callbackDev.ID != "dev-1" || !callbackDev.Revoked {
		t.Fatalf("callback device = %+v", callbackDev)
	}
	if !persistedAtCallback {
		t.Fatal("callback fired before revocation was persisted")
	}
}

func TestChallengeExpiryAndQuota(t *testing.T) {
	clock := newFakeClock()
	s := newTestService(t, func(c *Config) {
		c.Clock = clock.Now
		c.ChallengeTTL = time.Minute
		c.MaxOutstandingChallenges = 1
	})
	_, priv := newKeyPair(t)

	// Issue one challenge, advance past TTL, enrollment must fail.
	resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-1"})
	var ch challengeResponse
	decodeBody(t, resp, &ch)
	clock.Advance(2 * time.Minute)
	rebuilt := &Challenge{
		ID: ch.ChallengeID, DeviceID: ch.DeviceID, Role: ch.Role, Protocol: ch.Protocol,
		Domain: ch.Domain, Nonce: ch.Nonce, ConnectionNonce: ch.ConnectionNonce,
		ExpiresAt: time.Unix(ch.ExpiresAt, 0).UTC(), AccountID: accountIDForToken(tokenA),
	}
	sig, err := SignEnrollment(priv, mustPub(priv), rebuilt, testHostKey, false)
	if err != nil {
		t.Fatal(err)
	}
	expired := postJSON(t, s, "/identity/v1/enroll", tokenA, enrollRequest{
		DeviceID: "dev-1", PublicKey: base64.StdEncoding.EncodeToString(mustPub(priv)),
		SSHHostKey: testHostKey, ChallengeID: ch.ChallengeID,
		Signature: base64.StdEncoding.EncodeToString(sig),
	})
	if expired.StatusCode != http.StatusUnauthorized {
		t.Fatalf("expired challenge = %s, want 401", expired.Status)
	}
	// The consumed-but-expired challenge freed its slot: the flow works now.
	resp = runEnrollment(t, s, tokenA, "dev-1", priv, testHostKey, false)
	if resp.StatusCode != http.StatusCreated {
		t.Fatalf("enroll after expiry = %s", resp.Status)
	}
	// Outstanding bound: a second concurrent challenge for the same account is refused.
	if resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-2"}); resp.StatusCode != http.StatusOK {
		t.Fatalf("second challenge = %s", resp.Status)
	}
	if resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-3"}); resp.StatusCode != http.StatusTooManyRequests {
		t.Fatalf("challenge quota = %s, want 429", resp.Status)
	}
}

func TestDeviceQuotaAdmission(t *testing.T) {
	s := newTestService(t, func(c *Config) { c.MaxDevicesPerAccount = 1 })
	_, priv := newKeyPair(t)
	if resp := runEnrollment(t, s, tokenA, "dev-1", priv, testHostKey, false); resp.StatusCode != http.StatusCreated {
		t.Fatalf("first enroll = %s", resp.Status)
	}
	resp := runEnrollment(t, s, tokenA, "dev-2", priv, testHostKey, false)
	if resp.StatusCode != http.StatusForbidden {
		t.Fatalf("second enroll = %s, want 403", resp.Status)
	}
}

func TestBodyAndProtocolBounds(t *testing.T) {
	s := newTestService(t, func(c *Config) { c.MaxBodyBytes = 64 })
	huge := strings.Repeat("a", 4096)
	resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": huge})
	if resp.StatusCode != http.StatusBadRequest && resp.StatusCode != http.StatusRequestEntityTooLarge {
		t.Fatalf("oversized body = %s, want 400/413", resp.Status)
	}
	// Unknown fields rejected (strict JSON).
	resp = postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]any{"device_id": "d", "admin": true})
	if resp.StatusCode != http.StatusBadRequest {
		t.Fatalf("unknown field = %s, want 400", resp.Status)
	}
	// Unknown paths and methods.
	if resp = getJSON(t, s, "/identity/v1/unknown", tokenA); resp.StatusCode != http.StatusNotFound {
		t.Fatalf("unknown path = %s", resp.Status)
	}
	if resp = getJSON(t, s, "/identity/v1/enroll", tokenA); resp.StatusCode != http.StatusMethodNotAllowed {
		t.Fatalf("GET enroll = %s, want 405", resp.Status)
	}
	// Bad device_id rejected early.
	resp = postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "../etc"})
	if resp.StatusCode != http.StatusBadRequest {
		t.Fatalf("path-like device id = %s, want 400", resp.Status)
	}
}

func TestHostEnforcement(t *testing.T) {
	s := newTestService(t, func(c *Config) { c.Domain = "gateway.test" })
	resp := postJSON(t, s, "/identity/v1/challenge", tokenA, map[string]string{"device_id": "dev-1"})
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("canonical host = %s", resp.Status)
	}
	req := httptest.NewRequest(http.MethodPost, "/identity/v1/challenge", strings.NewReader(`{"device_id":"dev-1"}`))
	req.Host = "evil.example"
	req.Header.Set("Authorization", "Bearer "+tokenA)
	rec := httptest.NewRecorder()
	s.ServeHTTP(rec, req)
	if rec.Code != http.StatusForbidden {
		t.Fatalf("foreign host = %d, want 403", rec.Code)
	}
}

func TestServiceRestartReusesRegistry(t *testing.T) {
	dir := t.TempDir()
	s1 := newTestService(t, func(c *Config) { c.StorePath = filepath.Join(dir, "devices.json") })
	_, priv := newKeyPair(t)
	if resp := runEnrollment(t, s1, tokenA, "dev-1", priv, testHostKey, false); resp.StatusCode != http.StatusCreated {
		t.Fatalf("enroll = %s", resp.Status)
	}
	s2 := newTestService(t, func(c *Config) { c.StorePath = filepath.Join(dir, "devices.json") })
	got, err := s2.Store().GetDevice("dev-1")
	if err != nil {
		t.Fatalf("device missing after restart: %v", err)
	}
	if !sameKey(got.PublicKey, mustPub(priv)) {
		t.Fatal("device key changed across restart")
	}
	// And the registry refuses to come up on a corrupted file (fail closed).
	path := filepath.Join(dir, "corrupt.json")
	os.WriteFile(path, []byte("{broken"), 0o600)
	if _, err := NewService(Config{Verifier: stubVerifier{principals: map[string]Principal{}}, StorePath: path}); err == nil {
		t.Fatal("service started on a corrupt registry")
	}
	// And refuses to start without any registry.
	if _, err := NewService(Config{Verifier: stubVerifier{principals: map[string]Principal{}}}); err == nil {
		t.Fatal("service started without a registry")
	}
	// And refuses to start without a verifier source.
	if _, err := NewService(Config{StorePath: filepath.Join(dir, "x.json")}); err == nil {
		t.Fatal("service started without a verifier")
	}
}

func TestNewServiceWithGoogleVerifierDefaults(t *testing.T) {
	s, err := NewService(Config{
		ClientID:  "test-client-id",
		StorePath: filepath.Join(t.TempDir(), "devices.json"),
		Logger:    func(string, ...any) {},
	})
	if err != nil {
		t.Fatal(err)
	}
	if s.TokenAuthenticator() == nil || s.Store() == nil || s.Handler() == nil {
		t.Fatal("contract surface incomplete")
	}
}

func mustDecodeB64(t *testing.T, s string) []byte {
	t.Helper()
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil {
		t.Fatalf("base64 decode: %v", err)
	}
	return b
}
