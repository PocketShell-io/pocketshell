module github.com/PocketShell-io/pocketshell-gateway

go 1.27.2

require (
	github.com/gorilla/websocket v1.5.3
	golang.org/x/crypto v0.57.0
	golang.org/x/net v0.60.0
	golang.org/x/sys v0.48.0
)

require golang.org/x/text v0.42.0 // indirect
