package main

// Round-three wiring tests: the positive path uses the REAL host agent
// package — actual HTTP enrollment against the actual identity handlers
// (C1 contract: the challenge response carries the account and the v2
// enrollment transcript), then the real hostagent.Run session loop — and
// a client session carrying opaque bytes through the fully wired
// services. Revocation containment is exercised against the real store,
// including the applied-but-unproven durability path.

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/gorilla/websocket"
	"golang.org/x/crypto/ssh"

	"github.com/PocketShell-io/pocketshell-gateway/internal/hostagent"
	"github.com/PocketShell-io/pocketshell-gateway/internal/identity"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel/wsnet"
	"github.com/PocketShell-io/pocketshell-gateway/security/sshlab"
)

func mustJSON(t *testing.T, v any) []byte {
	t.Helper()
	raw, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	return raw
}

func readJSONWS(t *testing.T, ws *websocket.Conn, v any) {
	t.Helper()
	ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	mt, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("read ws frame: %v", err)
	}
	if mt != websocket.TextMessage {
		t.Fatalf("handshake frame type %d, want text", mt)
	}
	if err := json.Unmarshal(raw, v); err != nil {
		t.Fatalf("handshake frame not JSON: %v (%s)", err, raw)
	}
}

// sshHostKeyLine renders pub as a real OpenSSH authorized_keys line
// (ssh wire format: string "ssh-ed25519" || string key), as a real host
// would pin it.
func sshHostKeyLine(pub ed25519.PublicKey) string {
	blob := make([]byte, 0, 4+11+4+32)
	blob = binary.BigEndian.AppendUint32(blob, 11)
	blob = append(blob, "ssh-ed25519"...)
	blob = binary.BigEndian.AppendUint32(blob, 32)
	blob = append(blob, pub...)
	return "ssh-ed25519 " + base64.StdEncoding.EncodeToString(blob) + " e2e-host"
}

// postChallenge issues one identity challenge over HTTP.
func postChallenge(t *testing.T, apiBase, token, deviceID string) (*http.Response, []byte) {
	t.Helper()
	return postChallengeClient(t, &http.Client{Timeout: 5 * time.Second}, apiBase, token, deviceID)
}

// postChallengeClient is postChallenge with an injectable client, so the
// TLS-transport regressions can present the fixture CA trust (verification
// complete, never bypassed).
func postChallengeClient(t *testing.T, client *http.Client, apiBase, token, deviceID string) (*http.Response, []byte) {
	t.Helper()
	raw, err := json.Marshal(map[string]string{"device_id": deviceID})
	if err != nil {
		t.Fatal(err)
	}
	req, err := http.NewRequest(http.MethodPost, apiBase+"/identity/v1/challenge", bytes.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)
	res, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	b, err := io.ReadAll(res.Body)
	if err != nil {
		t.Fatal(err)
	}
	return res, b
}

// tryEnrollOverHTTP runs the REAL identity enrollment contract over HTTP
// against the REAL handlers (finding C1 interop): challenge with the
// account-carrying response, canonical reconstruction via the shared
// identity.ChallengeFromWire, byte-exact transcript round-trip, then the
// v2 possession signature via the shared identity.SignEnrollment. Returns
// the enroll response for status assertions. The pinned host key defaults
// to a well-formed line over the device key; the explicit-line variant
// below enrolls a REAL SSH endpoint pin.
func tryEnrollOverHTTP(t *testing.T, apiBase, token, deviceID string, key ed25519.PrivateKey, reenroll bool) (*http.Response, []byte) {
	t.Helper()
	return tryEnrollOverHTTPWithHostKey(t, apiBase, token, deviceID, key,
		sshHostKeyLine(key.Public().(ed25519.PublicKey)), reenroll)
}

func tryEnrollOverHTTPWithHostKey(t *testing.T, apiBase, token, deviceID string, key ed25519.PrivateKey, hostKey string, reenroll bool) (*http.Response, []byte) {
	t.Helper()
	client := &http.Client{Timeout: 5 * time.Second}
	pub := key.Public().(ed25519.PublicKey)

	// 1. Challenge bound to the verified account.
	chRes, chBody := postChallenge(t, apiBase, token, deviceID)
	if chRes.StatusCode != http.StatusOK {
		return chRes, chBody
	}
	var chResp struct {
		ChallengeID     string `json:"challenge_id"`
		DeviceID        string `json:"device_id"`
		AccountID       string `json:"account_id"`
		Role            string `json:"role"`
		Protocol        string `json:"protocol"`
		Domain          string `json:"domain"`
		Nonce           string `json:"nonce"`
		ConnectionNonce string `json:"connection_nonce"`
		ExpiresAt       int64  `json:"expires_at"`
		Transcript      string `json:"transcript"`
	}
	if err := json.Unmarshal(chBody, &chResp); err != nil {
		t.Fatalf("challenge response: %v (%s)", err, chBody)
	}

	// 2. Canonical reconstruction from the wire fields (the shared
	// helper — no hand-rolled transcript parsing here either).
	ch, err := identity.ChallengeFromWire(chResp.ChallengeID, chResp.DeviceID,
		chResp.AccountID, chResp.Role, chResp.Protocol, chResp.Domain,
		chResp.Nonce, chResp.ConnectionNonce, chResp.ExpiresAt)
	if err != nil {
		t.Fatalf("challenge from wire: %v", err)
	}

	// 3. Byte-exact round trip against the server transcript.
	canonical, err := ch.Transcript()
	if err != nil {
		t.Fatal(err)
	}
	serverTranscript, err := base64.StdEncoding.DecodeString(chResp.Transcript)
	if err != nil || !bytes.Equal(canonical, serverTranscript) {
		t.Fatal("server transcript does not round-trip the canonical encoding")
	}

	// 4. v2 possession signature over challenge + key + host key + mode.
	sig, err := identity.SignEnrollment(key, pub, ch, hostKey, reenroll)
	if err != nil {
		t.Fatal(err)
	}

	// 5. Enroll.
	raw, err := json.Marshal(map[string]string{
		"device_id":    deviceID,
		"public_key":   base64.StdEncoding.EncodeToString(pub),
		"ssh_host_key": hostKey,
		"challenge_id": chResp.ChallengeID,
		"signature":    base64.StdEncoding.EncodeToString(sig),
	})
	if err != nil {
		t.Fatal(err)
	}
	req, err := http.NewRequest(http.MethodPost, apiBase+"/identity/v1/enroll", bytes.NewReader(raw))
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)
	res, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	body, err := io.ReadAll(res.Body)
	if err != nil {
		t.Fatal(err)
	}
	return res, body
}

// enrollOverHTTP is the fatal-success variant used on the happy path.
// Enrollment answers 201 Created (round-three identity API; 200 tolerated
// for older snapshots).
func enrollOverHTTP(t *testing.T, apiBase, token, deviceID string, key ed25519.PrivateKey, reenroll bool) {
	t.Helper()
	res, body := tryEnrollOverHTTP(t, apiBase, token, deviceID, key, reenroll)
	expectEnrolled(t, res, body, deviceID)
}

// enrollOverHTTPWithHostKey is the fatal-success variant with an explicit
// pinned SSH host-key line (used when the lab SSH endpoint is a REAL sshd
// and the enrolled pin must match it).
func enrollOverHTTPWithHostKey(t *testing.T, apiBase, token, deviceID string, key ed25519.PrivateKey, hostKey string, reenroll bool) {
	t.Helper()
	res, body := tryEnrollOverHTTPWithHostKey(t, apiBase, token, deviceID, key, hostKey, reenroll)
	expectEnrolled(t, res, body, deviceID)
}

func expectEnrolled(t *testing.T, res *http.Response, body []byte, deviceID string) {
	t.Helper()
	if res.StatusCode != http.StatusCreated && res.StatusCode != http.StatusOK {
		t.Fatalf("enroll: HTTP %d: %s", res.StatusCode, body)
	}
	var dev struct {
		ID string `json:"id"`
	}
	if err := json.Unmarshal(body, &dev); err != nil || dev.ID != deviceID {
		t.Fatalf("enroll response id=%q err=%v", dev.ID, err)
	}
}

// startRealAgent runs the real hostagent session loop (challenge-auth,
// mux accept, loopback bridge, bounded reconnect) and waits until the
// tunnel service reports the device connected.
func startRealAgent(t *testing.T, api *newAPI, serverURL, deviceID string, key ed25519.PrivateKey, sshAddr string) (stop func(), done chan error) {
	t.Helper()
	// hostagent dials with gorilla, which only accepts ws:// or wss://
	// schemes; convert the http(s) test-server URL accordingly.
	wsURL := "ws" + strings.TrimPrefix(serverURL, "http")
	ctx, cancel := context.WithCancel(context.Background())
	agent := hostagent.NewAgent(hostagent.AgentConfig{
		ServerURL:        wsURL,
		DeviceID:         deviceID,
		Key:              key,
		SSHHost:          sshAddr,
		HandshakeTimeout: 3 * time.Second,
		LocalDialTimeout: 2 * time.Second,
		Logger:           quietLogger(),
		// F-11 fixed upstream (NewAgent defaults Now); the wiring test
		// runs the real agent with production defaults.
	})
	done = make(chan error, 1)
	go func() { done <- agent.Run(ctx) }()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if api.tunnelSvc.IsDeviceConnected(deviceID) {
			return cancel, done
		}
		select {
		case err := <-done:
			t.Fatalf("agent exited before registering: %v", err)
		default:
		}
		time.Sleep(10 * time.Millisecond)
	}
	cancel()
	t.Fatal("host agent never registered through the wired tunnel service")
	return nil, nil
}

func quietLogger() *slog.Logger {
	h := slog.NewTextHandler(io.Discard, nil)
	return slog.New(h)
}

func errPtr(e error) *error { return &e }

// revokeOverHTTP drives the REAL identity revocation endpoint — the
// production containment path. Identity round-eight fires the OnRevoke
// callbacks from the service handlers (never from raw store calls), so
// wiring tests must revoke over HTTP for containment to be exercised.
// Returns the HTTP status: 200 only when durability is proven; 500 while
// the flush is unproven (containment fires either way).
func revokeOverHTTP(t *testing.T, apiBase, token, deviceID string) int {
	t.Helper()
	req, err := http.NewRequest(http.MethodPost,
		apiBase+"/identity/v1/devices/"+deviceID+"/revoke", nil)
	if err != nil {
		t.Fatal(err)
	}
	req.Header.Set("Authorization", "Bearer "+token)
	res, err := (&http.Client{Timeout: 5 * time.Second}).Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer res.Body.Close()
	return res.StatusCode
}

func TestEnrollmentInteroperatesOverHTTP(t *testing.T) {
	api := registryTestAPI(t)
	r := testRelay()
	s := httptest.NewServer(newHandler(r, api))
	defer s.Close()

	key := ed25519.NewKeyFromSeed(make([]byte, 32)) // deterministic test key
	// Wrong bearer is refused by the real handler before any challenge:
	// a bad-bearer challenge must not return a usable transcript.
	chRes, chBody := postChallenge(t, s.URL, "bad-bearer", "laptop-1")
	if chRes.StatusCode != http.StatusUnauthorized {
		t.Fatalf("bad-bearer challenge = %d, want 401 (%s)", chRes.StatusCode, chBody)
	}
	// Real enrollment succeeds and the device is durably registered with
	// the right owner.
	enrollOverHTTP(t, s.URL, "good-bearer", "laptop-1", key, false)
	dev, err := api.identitySvc.DeviceStore().GetDevice("laptop-1")
	if err != nil {
		t.Fatal(err)
	}
	if dev.AccountID != "google:sub-test" || dev.Revoked {
		t.Fatalf("enrolled device wrong: %+v", dev)
	}
	if !identity.ValidSSHHostKey(dev.SSHHostKey) {
		t.Fatalf("stored host key not the pinned line: %q", dev.SSHHostKey)
	}
	// Idempotent re-enrollment with the SAME key+host key succeeds (fresh
	// challenge — every attempt consumes one); the store refuses key
	// substitution (different key, same ID).
	enrollOverHTTP(t, s.URL, "good-bearer", "laptop-1", key, false)
	other := ed25519.NewKeyFromSeed([]byte("another 32-byte seed for keys!!!"))
	res, body := tryEnrollOverHTTP(t, s.URL, "good-bearer", "laptop-1", other, false)
	if res.StatusCode == http.StatusOK || res.StatusCode == http.StatusCreated {
		t.Fatalf("key substitution under an existing device ID succeeded: %s", body)
	}
}

func TestTunnelEndToEndSSHTransport(t *testing.T) {
	api := registryTestAPI(t)
	r := testRelay()
	s := httptest.NewServer(newHandler(r, api))
	defer s.Close()

	key := ed25519.NewKeyFromSeed([]byte("e2e device seed 32 bytes!!!!!!!!"))
	enrollOverHTTP(t, s.URL, "good-bearer", "laptop-1", key, false)
	deviceID := "laptop-1"

	_, sshPort := echoListener(t)
	sshAddr := fmt.Sprintf("127.0.0.1:%d", sshPort)

	stopAgent, _ := startRealAgent(t, api, s.URL, deviceID, key, sshAddr)
	defer stopAgent()

	// Client: first frame carries the scoped credential (never a query
	// parameter), then the session is opaque binary bytes.
	d := websocket.Dialer{HandshakeTimeout: 5 * time.Second}
	ws, _, err := d.Dial("ws"+strings.TrimPrefix(s.URL, "http")+"/api/v1/hosts/"+deviceID+"/ssh", nil)
	if err != nil {
		t.Fatalf("client dial: %v", err)
	}
	defer ws.Close()
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.ClientAuth{
		Type: "auth", V: tunnel.ProtocolVersion,
		Token: "good-bearer", DeviceID: deviceID,
	})); err != nil {
		t.Fatal(err)
	}
	var ready tunnel.ReadyMsg
	readJSONWS(t, ws, &ready)
	if ready.Type != "ready" {
		t.Fatalf("client got %q (%+v), want ready", ready.Type, ready)
	}
	if ready.DeviceID != deviceID {
		t.Errorf("ready device = %q, want %q", ready.DeviceID, deviceID)
	}

	// Opaque bytes both ways: gateway → host agent mux → loopback sshd.
	payload := []byte("SSH-2.0-pocketshell-e2e\r\nopaque-bytes-123")
	ws.SetWriteDeadline(time.Now().Add(5 * time.Second))
	if err := ws.WriteMessage(websocket.BinaryMessage, payload); err != nil {
		t.Fatal(err)
	}
	ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	mt, got, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("client echo read: %v", err)
	}
	if mt != websocket.BinaryMessage || string(got) != string(payload) {
		t.Fatalf("echo mismatch: type=%d len=%d", mt, len(got))
	}

	// Revocation through the REAL endpoint tears the agent down (the wired
	// OnRevoke containment path) and the client session dies with it. The
	// endpoint answers 200 only when durability is proven.
	if code := revokeOverHTTP(t, s.URL, "good-bearer", deviceID); code != http.StatusOK {
		t.Fatalf("revoke: HTTP %d, want 200", code)
	}
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if !api.tunnelSvc.IsDeviceConnected(deviceID) {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if api.tunnelSvc.IsDeviceConnected(deviceID) {
		t.Fatal("revoked device stayed connected — OnRevoke wiring broken")
	}
	ws.SetReadDeadline(time.Now().Add(3 * time.Second))
	if _, _, err := ws.ReadMessage(); err == nil {
		t.Fatal("client session survived host revocation")
	}

	// Revocation is terminal for re-registration: a fresh host-agent
	// handshake for the revoked device is refused by the tunnel with the
	// application error frame (close/reject code "revoked"). Proven
	// directly against the wired tunnel service — independent of the real
	// agent's own reconnect/backoff timing.
	rawReRegistrationRefused(t, s.URL, deviceID, key)
	// The real agent's reconnect attempts stay refused too: it never
	// re-registers.
	refused := time.Now().Add(3 * time.Second)
	for time.Now().Before(refused) {
		if api.tunnelSvc.IsDeviceConnected(deviceID) {
			t.Fatal("revoked device re-registered after revocation")
		}
		time.Sleep(20 * time.Millisecond)
	}
	// DEPENDENCY (hostagent owner): the real agent currently treats the
	// tunnel's rejection as a retriable error and keeps reconnecting —
	// its readJSONMsg consumes the tunnel's TEXT error frame before the
	// CLOSE frame its classify() maps to fatal. Revocation-rejection
	// should terminate the agent loop (errFatalAuth); until that lands,
	// stopAgent's cancel is the only way the loop ends.
	_ = stopAgent
}

// rawReRegistrationRefused performs one host-agent handshake as a revoked
// device and asserts the tunnel refuses it (error frame code "revoked" or
// an equivalent application close).
func rawReRegistrationRefused(t *testing.T, serverURL, deviceID string, key ed25519.PrivateKey) {
	t.Helper()
	ws, _, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial("ws"+strings.TrimPrefix(serverURL, "http")+"/api/v1/agent/connect", nil)
	if err != nil {
		t.Fatalf("agent dial: %v", err)
	}
	defer ws.Close()
	var ch tunnel.HostChallenge
	readJSONWS(t, ws, &ch)
	challenge, err := ch.ToIdentityChallenge(deviceID)
	if err != nil {
		t.Fatal(err)
	}
	sig, err := identity.Sign(key, challenge)
	if err != nil {
		t.Fatal(err)
	}
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.HostAuth{
		Type: "auth", V: tunnel.ProtocolVersion, DeviceID: deviceID,
		Signature: base64.StdEncoding.EncodeToString(sig),
	})); err != nil {
		t.Fatal(err)
	}
	ws.SetReadDeadline(time.Now().Add(3 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatalf("no rejection frame for the revoked device: %v", err)
	}
	var msg tunnel.ErrMsg
	if json.Unmarshal(raw, &msg) != nil || (msg.Code != "revoked" && msg.Code != "forbidden") {
		t.Fatalf("revoked re-registration got %s, want revoked/forbidden", raw)
	}
}

// tryDialClientSSH performs the documented client handshake (text auth
// frame → ready) without failing the test, so lifecycle tests can retry it
// while the agent is still connecting. A non-ready reply is surfaced as an
// error carrying the raw frame.
//
// On success the handshake-phase read deadline is CLEARED before the
// WebSocket is handed back: wsnet.Wrap delegates deadlines to the same
// conn, so a leftover deadline here would leak into the caller's SSH or
// session phase and fake failures (or, worse, fake teardown evidence) on
// a local timeout instead of the behavior under test. Outer test timeouts
// stay OUTSIDE the transport.
func tryDialClientSSH(t *testing.T, serverURL, deviceID, token string) (*websocket.Conn, tunnel.ReadyMsg, error) {
	t.Helper()
	ws, _, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial("ws"+strings.TrimPrefix(serverURL, "http")+"/api/v1/hosts/"+deviceID+"/ssh", nil)
	if err != nil {
		return nil, tunnel.ReadyMsg{}, err
	}
	t.Cleanup(func() { ws.Close() })
	if err := ws.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.ClientAuth{
		Type: "auth", V: tunnel.ProtocolVersion, Token: token, DeviceID: deviceID,
	})); err != nil {
		return nil, tunnel.ReadyMsg{}, err
	}
	ws.SetReadDeadline(time.Now().Add(5 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		return nil, tunnel.ReadyMsg{}, err
	}
	var ready tunnel.ReadyMsg
	if err := json.Unmarshal(raw, &ready); err != nil || ready.Type != "ready" {
		return nil, tunnel.ReadyMsg{}, fmt.Errorf("not ready: %s", raw)
	}
	// Handshake phase over: no deadline of ours may survive into it.
	if err := ws.SetReadDeadline(time.Time{}); err != nil {
		return nil, tunnel.ReadyMsg{}, err
	}
	return ws, ready, nil
}

// dialClientSSH performs the documented client handshake against the wired
// tunnel and returns the live WebSocket plus the ready message (whose
// ssh_host_key is ADVISORY metadata, cross-checked — never trusted —
// against the independently provisioned pin).
func dialClientSSH(t *testing.T, serverURL, deviceID, token string) (*websocket.Conn, tunnel.ReadyMsg) {
	t.Helper()
	ws, ready, err := tryDialClientSSH(t, serverURL, deviceID, token)
	if err != nil {
		t.Fatalf("client dial/auth: %v", err)
	}
	return ws, ready
}

// samePin compares the identifying prefix of two authorized_keys lines
// (type + base64 blob). The ready message's host key is advisory metadata
// an untrusted gateway controls; the pin is what the SSH client actually
// enforces.
func samePin(a, b string) bool {
	fa, fb := strings.Fields(a), strings.Fields(b)
	return len(fa) >= 2 && len(fb) >= 2 && fa[0] == fb[0] && fa[1] == fb[1]
}

// realSSHSession runs the REAL golang.org/x/crypto/ssh client over the
// post-ready client WebSocket — host-key verification against the
// INDEPENDENT pin (ssh.FixedHostKey, never the ready advisory), real
// public-key auth against the lab sshd, real sentinel exec through the
// agent's loopback bridge. This is the accepted proof that the tunnel
// carried a REAL successful SSH session (P12 recipe); an echo listener
// stand-in does not qualify.
//
// No local transport deadline is installed here: the handshake deadlines
// were cleared by the dial helper, ssh.ClientConfig.Timeout does not apply
// to NewClientConn (there is no dial), and the outer test timeout is the
// only bound — the corrections explicitly forbid letting a local timeout
// stand in for behavior. A timeout-class handshake error is therefore a
// HARD test-infrastructure failure, never an acceptable outcome.
func realSSHSession(t *testing.T, ws *websocket.Conn, pinLine string, signer ssh.Signer) *ssh.Client {
	t.Helper()
	pin, _, _, _, err := ssh.ParseAuthorizedKey([]byte(pinLine))
	if err != nil {
		t.Fatalf("independent pin unparsable: %v", err)
	}
	cl, chans, reqs, err := ssh.NewClientConn(wsnet.Wrap(ws), "tunnel", &ssh.ClientConfig{
		User:            "pocketshell",
		Auth:            []ssh.AuthMethod{ssh.PublicKeys(signer)},
		HostKeyCallback: ssh.FixedHostKey(pin),
	})
	if err != nil {
		var ne net.Error
		if errors.As(err, &ne) && ne.Timeout() {
			t.Fatalf("SSH handshake failed on a LOCAL timeout — a handshake deadline leaked into the SSH phase: %v", err)
		}
		t.Fatalf("real SSH handshake over the wired tunnel: %v", err)
	}
	client := ssh.NewClient(cl, chans, reqs)
	sess, err := client.NewSession()
	if err != nil {
		client.Close()
		t.Fatalf("SSH session: %v", err)
	}
	defer sess.Close()
	out, err := sess.CombinedOutput("echo tunnel-e2e-durability-ok")
	if err != nil || !strings.Contains(string(out), "tunnel-e2e-durability-ok") {
		client.Close()
		t.Fatalf("sentinel exec over the tunnel: err=%v out=%q", err, out)
	}
	return client
}

// expectSSHClientTeardown requires the SSH client's Wait to RETURN within
// the window (the connection was torn down) and REJECTS timeout-class
// errors: a local read deadline firing is not teardown evidence — the old
// assertion accepted ANY Wait outcome, so a leftover test deadline could
// pass a revocation that never disconnected anyone. Server-side closure is
// asserted separately through sshlab.Stats by the caller.
func expectSSHClientTeardown(t *testing.T, cl *ssh.Client, what string) {
	t.Helper()
	watchErr := make(chan error, 1)
	go func() { watchErr <- cl.Wait() }()
	select {
	case err := <-watchErr:
		if err != nil {
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				t.Fatalf("%s: SSH client died of a LOCAL timeout, not the teardown under test: %v", what, err)
			}
		}
		// A clean-protocol disconnect (nil) is equally a teardown.
	case <-time.After(10 * time.Second):
		t.Fatalf("%s: active SSH session survived (Wait did not return within 10s)", what)
	}
}

// requireBackendClosed polls the lab sshd's OWN counters until the backend
// leg of the session is observed closed — server-side evidence, taken
// BEFORE any deferred cleanup can tear the topology down. This is the
// mutation-control that makes teardown assertions load-bearing: if
// revocation containment were disabled and nobody disconnected the
// session, both this and expectSSHClientTeardown fail.
func requireBackendClosed(t *testing.T, sshd *sshlab.Server, closedBefore int64, what string) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if sshd.Stats().ClosedConns > closedBefore {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("%s: lab sshd never observed the backend connection close (ClosedConns stayed %d)", what, closedBefore)
}

func TestRevocationContainmentOnUncertainDurability(t *testing.T) {
	// Real durable store with an injectable post-rename directory fsync
	// (identity package test hook) so the applied-but-unproven path can
	// be driven deterministically. The hook starts healthy — enrollment,
	// the agent registration and the REAL SSH session need a working
	// store — and is armed only once the full topology is live.
	var hookErr atomic.Pointer[error]
	hookErr.Store(nil)
	regPath := filepath.Join(t.TempDir(), "registry.json")
	store, err := identity.NewFileStore(regPath,
		identity.WithDirSyncHook(func(*os.File) error {
			if e := hookErr.Load(); e != nil {
				return *e
			}
			return nil
		}))
	if err != nil {
		t.Fatal(err)
	}
	oldRegistry, oldTunnel := registryPosture, tunnelPosture
	t.Cleanup(func() { registryPosture, tunnelPosture = oldRegistry, oldTunnel })
	idSvc := buildRegistryWith(identity.Config{
		Verifier: stubVerifier{accountID: "google:sub-test", email: "ops@example.com"},
		Store:    store,
		Logger:   func(string, ...any) {},
	})
	if idSvc == nil {
		t.Fatal("identity service should construct with an injected store")
	}
	tunSvc := buildTunnel(idSvc, []string{"https://app.pocketshell.io"}, tunnel.Limits{
		MaxHosts: 4, MaxClientsGlobal: 4, MaxClientsPerAccount: 2, MaxStreamsPerHost: 2,
	})
	if tunSvc == nil {
		t.Fatal("tunnel should construct")
	}
	t.Cleanup(tunSvc.Close)
	api := &newAPI{identitySvc: idSvc, tunnelSvc: tunSvc}

	r := testRelay()
	s := httptest.NewServer(newHandler(r, api))
	defer s.Close()

	// REAL home SSH endpoint: in-process lab sshd (public-key-only, benign
	// exec allowlist) with an INDEPENDENT host-key pin and a real client
	// key — the durability claim below is proven against a REAL successful
	// SSH session, not an echo-listener stand-in.
	hostKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	clientKey, err := sshlab.NewSSHKey()
	if err != nil {
		t.Fatal(err)
	}
	sshd, err := sshlab.StartSSHD(hostKey.Signer, clientKey.Public)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(sshd.Close)
	pinLine := strings.TrimSpace(hostKey.AuthorizedLine())

	key := ed25519.NewKeyFromSeed([]byte("durability seed 32 bytes!!!!!!!!"))
	deviceID := "laptop-1"
	// The device enrolls the REAL sshd's authorized line as its pinned
	// host key, so the client's independent pin and the ready advisory
	// describe the same endpoint.
	enrollOverHTTPWithHostKey(t, s.URL, "good-bearer", deviceID, key, pinLine, false)

	stopAgent, _ := startRealAgent(t, api, s.URL, deviceID, key, sshd.Addr())
	defer stopAgent()

	// REAL successful SSH client session through the fully wired services:
	// auth frame → ready (advisory cross-checked against the pin) →
	// golang.org/x/crypto/ssh handshake with host-key verification and
	// public-key auth → sentinel exec through the agent's loopback bridge.
	ws, ready := dialClientSSH(t, s.URL, deviceID, "good-bearer")
	if !samePin(ready.SSHHostKey, pinLine) {
		t.Fatalf("ready advisory %q does not describe the pinned endpoint %q", ready.SSHHostKey, pinLine)
	}
	cl := realSSHSession(t, ws, pinLine, clientKey.Signer)

	// Baseline: the backend leg is OPEN server-side (negative control for
	// the closure evidence below — the counters are load-bearing, so the
	// test must know their pre-teardown value).
	closedBefore := sshd.Stats().ClosedConns

	// NOW arm the post-rename directory-fsync failure: revocation IS
	// applied (rename done, containment callbacks fire — the agent and
	// every stream riding it must disconnect) but the endpoint must NOT
	// acknowledge (500, never 200 while the flush is unproven).
	hookErr.Store(errPtr(errors.New("directory fsync unavailable")))
	if code := revokeOverHTTP(t, s.URL, "good-bearer", deviceID); code != http.StatusInternalServerError {
		t.Fatalf("uncertain revoke: HTTP %d, want 500 (no 200 until flush proof)", code)
	}

	// Containment despite the missing ACK: the ACTIVE SSH session dies
	// promptly, and NEVER by one of our own local deadlines — a
	// timeout-class Wait would be the false pass the corrections forbid.
	// Together with the server-side counter below, a build with revocation
	// containment disabled cannot pass here: the client would stay alive
	// (10s fatal) and the sshd would never see the close.
	expectSSHClientTeardown(t, cl, "durability-uncertain revocation")
	requireBackendClosed(t, sshd, closedBefore, "durability-uncertain revocation")

	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if !api.tunnelSvc.IsDeviceConnected(deviceID) {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if api.tunnelSvc.IsDeviceConnected(deviceID) {
		t.Fatal("containment did not fire on the uncertain revocation attempt")
	}

	// The applied state is on disk even though the caller got an error
	// (rename+tombstone precede the unproven flush).
	raw, err := os.ReadFile(regPath)
	if err != nil {
		t.Fatal(err)
	}
	var disk struct {
		Devices []struct {
			ID      string `json:"ID"`
			Revoked bool   `json:"Revoked"`
		} `json:"devices"`
	}
	if err := json.Unmarshal(raw, &disk); err != nil {
		t.Fatalf("registry file unreadable: %v", err)
	}
	revokedOnDisk := false
	for _, d := range disk.Devices {
		if d.ID == deviceID {
			revokedOnDisk = d.Revoked
		}
	}
	if !revokedOnDisk {
		t.Fatalf("registry file does not carry the applied revocation: %s", raw)
	}

	// Re-admission is denied while durability is unproven: a fresh client
	// admission is refused (no ready frame — an error frame or transport
	// failure at most)...
	ws2, res2, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial("ws"+strings.TrimPrefix(s.URL, "http")+"/api/v1/hosts/"+deviceID+"/ssh", nil)
	if err == nil {
		if err := ws2.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.ClientAuth{
			Type: "auth", V: tunnel.ProtocolVersion, Token: "good-bearer", DeviceID: deviceID,
		})); err != nil {
			t.Fatal(err)
		}
		ws2.SetReadDeadline(time.Now().Add(3 * time.Second))
		if _, rraw, rerr := ws2.ReadMessage(); rerr == nil {
			var msg tunnel.ErrMsg
			if json.Unmarshal(rraw, &msg) != nil || msg.Type != "error" {
				t.Fatalf("client admitted after an uncertain revocation: %s", rraw)
			}
		}
		ws2.Close()
	} else if res2 == nil {
		t.Fatalf("client dial failed without a response: %v", err)
	}
	// ...and a fresh host-agent handshake for the revoked device is
	// refused through the real production path.
	rawReRegistrationRefused(t, s.URL, deviceID, key)

	// Retry after the flush works: the same idempotent revoke re-attempts
	// the flush and can now acknowledge — and only NOW.
	hookErr.Store(nil)
	if code := revokeOverHTTP(t, s.URL, "good-bearer", deviceID); code != http.StatusOK {
		t.Fatalf("retry after flush recovery: HTTP %d, want 200", code)
	}
	// Still terminal after the acknowledged retry.
	rawReRegistrationRefused(t, s.URL, deviceID, key)

	// The historical revoked key can never be re-admitted, through the
	// store or the typed tunnel adapter (fail closed).
	reused := identity.Device{
		ID:         "laptop-2",
		AccountID:  "google:sub-test",
		PublicKey:  key.Public().(ed25519.PublicKey),
		SSHHostKey: sshHostKeyLine(key.Public().(ed25519.PublicKey)),
	}
	if err := api.identitySvc.DeviceStore().Put(reused); err == nil {
		t.Fatal("revoked key re-admitted under a new device ID")
	}
	adapter := tunnelStoreAdapter{inner: api.identitySvc.DeviceStore()}
	if _, err := adapter.GetDevice("laptop-2"); err == nil {
		t.Fatal("refused device readable through the tunnel adapter")
	}
	if got, err := adapter.GetDevice(deviceID); err != nil || !got.Revoked {
		t.Fatalf("revoked flag lost through adapter: %+v err=%v", got, err)
	}
}

// admissionWindowVerifier is a test verifier whose tokens expire at a
// fixed wall-clock deadline (populated ExpiresAt — the expiry gate stays
// engaged), used to prove the session-lifetime policy of finding F-14.
type admissionWindowVerifier struct {
	deadline time.Time
}

func (v admissionWindowVerifier) VerifyToken(_ context.Context, token string) (identity.Principal, error) {
	if token != "good-bearer" {
		return identity.Principal{}, errors.New("bad token")
	}
	if !time.Now().Before(v.deadline) {
		return identity.Principal{}, errors.New("admission token expired")
	}
	return identity.Principal{
		AccountID: "google:sub-test",
		Email:     "ops@example.com",
		ExpiresAt: v.deadline,
	}, nil
}

func TestSessionPolicyAdmissionVsAbsoluteDuration(t *testing.T) {
	// F-14, behaviorally: the short broker JWT governs ADMISSION only. A
	// client session admitted while the token was valid stays alive past
	// the token's expiry (the tunnel's absolute MaxSessionDuration is the
	// session policy — no claim exp closes an admitted session), while a
	// NEW admission after the expiry is rejected at the gate.
	oldRegistry, oldTunnel := registryPosture, tunnelPosture
	t.Cleanup(func() { registryPosture, tunnelPosture = oldRegistry, oldTunnel })
	deadline := time.Now().Add(1200 * time.Millisecond)
	idSvc := buildRegistryWith(identity.Config{
		Verifier:  expiryGate{inner: admissionWindowVerifier{deadline: deadline}},
		StorePath: filepath.Join(t.TempDir(), "registry.json"),
		Logger:    func(string, ...any) {},
	})
	if idSvc == nil {
		t.Fatal("identity service should construct")
	}
	tunSvc := buildTunnel(idSvc, []string{"https://app.pocketshell.io"}, tunnel.Limits{
		MaxHosts: 4, MaxClientsGlobal: 4, MaxClientsPerAccount: 2, MaxStreamsPerHost: 2,
	})
	if tunSvc == nil {
		t.Fatal("tunnel service should construct")
	}
	t.Cleanup(tunSvc.Close)
	api := &newAPI{identitySvc: idSvc, tunnelSvc: tunSvc}
	s := httptest.NewServer(newHandler(testRelay(), api))
	defer s.Close()

	key := ed25519.NewKeyFromSeed([]byte("session policy seed 32 bytes!!!!"))
	enrollOverHTTP(t, s.URL, "good-bearer", "laptop-1", key, false)
	_, sshPort := echoListener(t)
	stopAgent, _ := startRealAgent(t, api, s.URL, "laptop-1", key, fmt.Sprintf("127.0.0.1:%d", sshPort))
	defer stopAgent()

	dialClient := func() *websocket.Conn {
		t.Helper()
		ws, _, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
			Dial("ws"+strings.TrimPrefix(s.URL, "http")+"/api/v1/hosts/laptop-1/ssh", nil)
		if err != nil {
			t.Fatalf("client dial: %v", err)
		}
		t.Cleanup(func() { ws.Close() })
		if err := ws.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.ClientAuth{
			Type: "auth", V: tunnel.ProtocolVersion, Token: "good-bearer", DeviceID: "laptop-1",
		})); err != nil {
			t.Fatal(err)
		}
		var ready tunnel.ReadyMsg
		readJSONWS(t, ws, &ready)
		if ready.Type != "ready" {
			t.Fatalf("client got %q, want ready", ready.Type)
		}
		return ws
	}

	// Admitted BEFORE the token expiry: admission succeeds.
	live := dialClient()
	live.SetWriteDeadline(time.Now().Add(3 * time.Second))
	if err := live.WriteMessage(websocket.BinaryMessage, []byte("before-expiry")); err != nil {
		t.Fatal(err)
	}

	// Cross the admission-token expiry while the session is open.
	time.Sleep(time.Until(deadline) + 400*time.Millisecond)
	if !time.Now().After(deadline) {
		t.Fatal("test window misconfigured: deadline not crossed")
	}

	// The admitted session is NOT closed by the token's exp: the tunnel's
	// absolute MaxSessionDuration is the session policy (F-14 — no claim
	// of expiry-driven termination).
	live.SetWriteDeadline(time.Now().Add(3 * time.Second))
	if err := live.WriteMessage(websocket.BinaryMessage, []byte("after-expiry")); err != nil {
		t.Fatalf("admitted session was closed by the token expiry: %v", err)
	}

	// A NEW admission after the expiry is rejected: the gate refuses the
	// expired token before any handler.
	ws2, res, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial("ws"+strings.TrimPrefix(s.URL, "http")+"/api/v1/hosts/laptop-1/ssh", nil)
	if err != nil {
		if res == nil {
			t.Fatal(err)
		}
		t.Fatalf("post-expiry dial unexpectedly failed at handshake: %v", err)
	}
	defer ws2.Close()
	_ = ws2.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.ClientAuth{
		Type: "auth", V: tunnel.ProtocolVersion, Token: "good-bearer", DeviceID: "laptop-1",
	}))
	ws2.SetReadDeadline(time.Now().Add(3 * time.Second))
	_, raw, err := ws2.ReadMessage()
	if err != nil {
		t.Fatal("no response frame for the post-expiry admission")
	}
	var msg tunnel.ErrMsg
	if json.Unmarshal(raw, &msg) != nil || msg.Code != "unauthorized" {
		t.Fatalf("post-expiry admission got %+v, want unauthorized close", msg)
	}

	// The pre-existing session is still functional after the second
	// client's rejection (unrelated failures never disturb live sessions).
	live.SetWriteDeadline(time.Now().Add(3 * time.Second))
	if err := live.WriteMessage(websocket.BinaryMessage, []byte("still-alive")); err != nil {
		t.Fatalf("live session disturbed by an unrelated rejected admission: %v", err)
	}
}

func TestTunnelClientAuthFailures(t *testing.T) {
	api := registryTestAPI(t)
	s := httptest.NewServer(newHandler(testRelay(), api))
	defer s.Close()

	key := ed25519.NewKeyFromSeed([]byte("auth-failure seed 32 bytes!!!!!!"))
	enrollOverHTTP(t, s.URL, "good-bearer", "laptop-1", key, false)
	deviceID := "laptop-1"

	_, sshPort := echoListener(t)
	stopAgent, agentDone := startRealAgent(t, api, s.URL, deviceID, key, fmt.Sprintf("127.0.0.1:%d", sshPort))
	defer func() { stopAgent() }()

	dial := func(token, device string) (int, string) {
		ws, res, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
			Dial("ws"+strings.TrimPrefix(s.URL, "http")+"/api/v1/hosts/"+device+"/ssh", nil)
		if err != nil {
			if res != nil {
				return res.StatusCode, ""
			}
			return -1, err.Error()
		}
		defer ws.Close()
		_ = ws.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.ClientAuth{
			Type: "auth", V: tunnel.ProtocolVersion, Token: token, DeviceID: device,
		}))
		ws.SetReadDeadline(time.Now().Add(3 * time.Second))
		_, raw, err := ws.ReadMessage()
		if err != nil {
			return 101, "closed without error frame"
		}
		var msg tunnel.ErrMsg
		_ = json.Unmarshal(raw, &msg)
		return 101, msg.Code
	}

	if code, msg := dial("bad-bearer", deviceID); code != 101 || msg != "unauthorized" {
		t.Errorf("bad token: %d/%q, want 101/unauthorized (close frame)", code, msg)
	}
	if code, msg := dial("good-bearer", "unknown-device"); code != 101 || (msg != "not_found" && msg != "forbidden") {
		t.Errorf("unknown device: %d/%q, want not_found/forbidden", code, msg)
	}
	// The registry cross-check runs BEFORE admission: another account's
	// device is refused with the SAME uniform denial as an unknown device
	// (no device-existence oracle — tunnel finding F-04).
	otherKey := ed25519.NewKeyFromSeed([]byte("other-account seed 32 bytes!!!!!"))
	if err := api.identitySvc.DeviceStore().Put(identity.Device{
		ID: "other-laptop", AccountID: "google:sub-other",
		PublicKey:  otherKey.Public().(ed25519.PublicKey),
		SSHHostKey: sshHostKeyLine(otherKey.Public().(ed25519.PublicKey)),
	}); err != nil {
		t.Fatal(err)
	}
	if code, msg := dial("good-bearer", "other-laptop"); code != 101 || msg != "not_found" {
		t.Errorf("cross-account device: %d/%q, want uniform not_found (no existence oracle)", code, msg)
	}
	// Malformed auth frame (wrong version).
	ws, _, err := (&websocket.Dialer{HandshakeTimeout: 5 * time.Second}).
		Dial("ws"+strings.TrimPrefix(s.URL, "http")+"/api/v1/hosts/"+deviceID+"/ssh", nil)
	if err != nil {
		t.Fatal(err)
	}
	defer ws.Close()
	_ = ws.WriteMessage(websocket.TextMessage, mustJSON(t, tunnel.ClientAuth{
		Type: "auth", V: 99, Token: "good-bearer", DeviceID: deviceID,
	}))
	ws.SetReadDeadline(time.Now().Add(3 * time.Second))
	_, raw, err := ws.ReadMessage()
	if err != nil {
		t.Fatal("no protocol-error frame")
	}
	var msg tunnel.ErrMsg
	if json.Unmarshal(raw, &msg) != nil || msg.Code != "protocol" {
		t.Fatalf("malformed frame: %s", raw)
	}
	// The agent stays connected throughout (unrelated clients failed).
	if !api.tunnelSvc.IsDeviceConnected(deviceID) {
		t.Error("host agent dropped while unrelated client auth failed")
	}
	_ = agentDone
}
