package main

// Tests for configuration policy: origin list parsing, the TLS host
// whitelist (canonical + aliases), the fail-closed registry gate and its
// state-location rule, and startup validation invariants.

import (
	"net/http"
	"path/filepath"
	"strings"
	"testing"

	"github.com/PocketShell-io/pocketshell-gateway/internal/tunnel"
)

func TestParseOrigins(t *testing.T) {
	got := parseOrigins(defaultOrigins)
	if len(got) != 2 || !got["https://app.pocketshell.io"] || !got["https://pocketshell.io"] {
		t.Fatalf("defaultOrigins parsed as %v, want the two production web origins", got)
	}
	if got := parseOrigins(""); len(got) != 0 {
		t.Fatalf("empty -origins = %v, want no browser origins", got)
	}

	got = parseOrigins("HTTPS://App.PocketShell.IO, https://other.example/path, javascript://alert(1), https://u:pW@x.example, https://ok.example")
	for _, want := range []string{"https://app.pocketshell.io", "https://ok.example"} {
		if !got[want] {
			t.Errorf("missing %q in %v", want, got)
		}
	}
	for _, absent := range []string{"https://other.example/path", "javascript://alert(1)", "https://u:pw@x.example"} {
		if got[absent] {
			t.Errorf("junk origin %q accepted", absent)
		}
	}
}

func TestOriginAllowedCaseFolding(t *testing.T) {
	r := testRelay()
	for _, origin := range []string{"https://APP.pocketshell.IO", "https://app.pocketshell.io"} {
		req := httptestRequest(origin)
		if !r.originAllowed(req) {
			t.Errorf("origin %q should be allowed", origin)
		}
	}
}

func httptestRequest(origin string) *http.Request {
	req, _ := http.NewRequest(http.MethodGet, "https://gateway.example/", nil)
	if origin != "" {
		req.Header.Set("Origin", origin)
	}
	return req
}

func TestOriginAllowedRejects(t *testing.T) {
	r := testRelay()
	for _, origin := range []string{
		"https://evil.example",
		"https://app.pocketshell.io.evil.example",
		"http://app.pocketshell.io", // scheme matters
		"not a url",
	} {
		if r.originAllowed(httptestRequest(origin)) {
			t.Errorf("origin %q should be rejected", origin)
		}
	}
	// No Origin header: not a browser; the token gate still applies.
	if !r.originAllowed(httptestRequest("")) {
		t.Error("headerless (non-browser) request should pass the origin gate")
	}
}

func TestHostWhitelist(t *testing.T) {
	policy := hostWhitelist("gateway.pocketshell.io", "relay.pocketshell.io")
	for _, host := range []string{
		"gateway.pocketshell.io",
		"relay.pocketshell.io",
		"Gateway.PocketShell.io", // case-folded
		"relay.pocketshell.io.",  // trailing dot (absolute form)
	} {
		if err := policy(nil, host); err != nil {
			t.Errorf("host %q should be whitelisted: %v", host, err)
		}
	}
	for _, host := range []string{
		"evil.example",
		"gateway.pocketshell.io.evil.example",
		"sub.gateway.pocketshell.io",
		"",
	} {
		if err := policy(nil, host); err == nil {
			t.Errorf("host %q should NOT be whitelisted", host)
		} else if !strings.Contains(err.Error(), "whitelist") && !strings.Contains(err.Error(), "configured") {
			t.Errorf("rejection for %q should be explicit, got: %v", host, err)
		}
	}
}

func TestValidateRegistryPath(t *testing.T) {
	for _, ok := range []string{
		"",
		registryBaseDir,
		registryBaseDir + "/registry",
		registryBaseDir + "/registry/devices.db",
	} {
		if err := validateRegistryPath(ok); err != nil {
			t.Errorf("validateRegistryPath(%q) = %v, want nil", ok, err)
		}
	}
	for _, bad := range []string{
		"registry",                        // relative
		"./registry",                      // relative
		"/etc/pocketshell",                // outside the state dir
		"/var/lib/pocketshell-relay-evil", // prefix trick
		"/var/lib/pocketshell-relay/../pocketshell-relay-evil/x",
		"/tmp/registry",
	} {
		if err := validateRegistryPath(bad); err == nil {
			t.Errorf("validateRegistryPath(%q) = nil, want error", bad)
		}
	}
}

func TestValidateConfig(t *testing.T) {
	allow := []string{"ops@example.com"}

	if err := validateConfig("", false, false, false, allow, ""); err != nil {
		t.Errorf("plain dev start should be fine: %v", err)
	}
	if err := validateConfig("", false, false, false, nil, ""); err != nil {
		t.Errorf("dev with empty allowlist is fine (dev auth path): %v", err)
	}
	if err := validateConfig("gateway.pocketshell.io", false, false, false, allow, ""); err != nil {
		t.Errorf("production config should validate: %v", err)
	}

	// Dev escape hatches must never ride on a public domain.
	if err := validateConfig("gateway.pocketshell.io", true, false, false, allow, ""); err == nil {
		t.Error("dev-any-token + public domain must be refused")
	}
	if err := validateConfig("gateway.pocketshell.io", false, true, false, allow, ""); err == nil {
		t.Error("dev-private-hosts + public domain must be refused")
	}
	// …nor next to the new API.
	if err := validateConfig("", true, false, false, nil, registryBaseDir+"/registry"); err == nil {
		t.Error("dev-any-token + registry must be refused")
	}
	if err := validateConfig("", false, true, false, nil, registryBaseDir+"/registry"); err == nil {
		t.Error("dev-private-hosts + registry must be refused")
	}
	// The insecure-broker dev opt-in (plain-http broker URLs) is a
	// dev-listen-only escape hatch: never next to a public domain.
	if err := validateConfig("gateway.pocketshell.io", false, false, true, allow, ""); err == nil {
		t.Error("broker-insecure-dev + public domain must be refused")
	}
	if err := validateConfig("", false, false, true, allow, ""); err != nil {
		t.Errorf("broker-insecure-dev + dev-listen must be allowed: %v", err)
	}
	// Fail closed: a public TLS listener with nobody allowed is a misconfig.
	if err := validateConfig("gateway.pocketshell.io", false, false, false, nil, ""); err == nil {
		t.Error("public domain with empty allowlist must be refused")
	}
	// Registry path rule enforced through validateConfig too.
	if err := validateConfig("", false, false, false, nil, "/tmp/registry"); err == nil {
		t.Error("registry outside the state dir must be refused")
	}
}

func TestRegistryStateReporting(t *testing.T) {
	oldRegistry, oldTunnel := registryPosture, tunnelPosture
	t.Cleanup(func() { registryPosture, tunnelPosture = oldRegistry, oldTunnel })

	// No -registry: disabled, no service — the fail-closed default.
	if svc := buildRegistry("gateway.pocketshell.io", "", nil); svc != nil {
		t.Error("disabled registry must return nil service")
	}
	if registryPosture != "disabled" || tunnelPosture != "disabled" {
		t.Errorf("postures = %q/%q, want disabled/disabled", registryPosture, tunnelPosture)
	}

	// A registry that cannot construct (no verifier and no client ID —
	// the new API has no Google fallback) reports "failed" and serves
	// nothing — never a half-open API.
	if svc := buildRegistry("gateway.pocketshell.io", filepath.Join(t.TempDir(), "registry.json"), nil); svc != nil {
		t.Error("failed registry must return nil service")
	}
	if registryPosture != "failed" {
		t.Errorf("posture = %q, want failed", registryPosture)
	}
	if svc := buildTunnel(nil, nil, tunnel.Limits{}); svc != nil {
		t.Error("tunnel without a registry must return nil service")
	}
	if tunnelPosture != "disabled" {
		t.Errorf("tunnel posture = %q, want disabled", tunnelPosture)
	}
}

func TestSplitListAndPort(t *testing.T) {
	got := splitList(" a@example.com , b@example.com ,, ")
	if len(got) != 2 || got[0] != "a@example.com" || got[1] != "b@example.com" {
		t.Fatalf("splitList = %v", got)
	}
	if n, err := parsePort("22"); err != nil || n != 22 {
		t.Fatalf("parsePort(22) = %d, %v", n, err)
	}
	if _, err := parsePort("0"); err == nil {
		t.Error("port 0 should be invalid")
	}
	if _, err := parsePort("65536"); err == nil {
		t.Error("port 65536 should be invalid")
	}
	if _, err := parsePort("22x"); err == nil {
		t.Error("non-numeric port should be invalid")
	}
}
