# Hosted outbound tunnel architecture and security practices

Research date: 2026-10-07. Scope: current official ngrok and Cloudflare documentation; architecture research only. PocketShell mapping uses the local design contract and independent design review, not runtime inspection or implementation approval. “Acceptance requirement” below is our recommendation/inference, not a claim that a vendor requires this custom implementation. No provider control-plane changes or public testing were performed.

## Outbound-only connectivity, NAT, and destination confinement

### Takeaway
Outbound connector sessions are an established way to reach services behind NAT without an inbound SSH port. This changes reachability; it does not remove the attack surface of a publicly reachable gateway or the SSH service receiving forwarded connections.

### Cited Findings
- ngrok agents initiate an outbound TLS session on port 443; received endpoint traffic returns to the upstream over that session. The documented session model works behind NAT without port forwarding. — [Agent overview](https://ngrok.com/docs/gateway/agent); [Agent session model](https://ngrok.com/docs/gateway/agent/how-it-works)
- Cloudflare Tunnel establishes outbound encrypted connector connections without a public origin IP or inbound firewall ports. Each tunnel maintains four connections to two Cloudflare data centers; replicas provide additional availability. The overview identifies public-application Tunnel as distinct from Cloudflare One private networking. — [Tunnel overview](https://developers.cloudflare.com/tunnel/)
- ngrok TCP endpoints can forward to any address reachable by the agent, including a non-local network service. Cloudflare's browser SSH example permits either localhost or a different server IP. — [TCP endpoints](https://ngrok.com/docs/gateway/endpoints/tcp); [Browser SSH setup](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/use-cases/ssh/ssh-browser-rendering/)

### Inferences
- **Acceptance requirement H1:** host agents initiate authenticated WSS to `gateway.pocketshell.io`; no home inbound port is necessary. Document the firewall assumptions separately for gateway and host.
- **Acceptance requirement H2:** preserve PocketShell's stricter local destination policy: a configured literal IPv4/IPv6 loopback SSH destination only; gateway messages cannot supply destinations, change the local service, or execute local management commands. Vendors' general-purpose LAN routing is a product capability, not a suitable default here.
- **Acceptance requirement H3:** reconnect uses bounded backoff with jitter and connection epochs; replacement-host cleanup cannot remove the new host registration. ngrok's documented heartbeats, timeout detection, and reconnection are useful operational precedent. — [Connector connectivity](https://ngrok.com/docs/gateway/agent/connectivity)

### Gaps
- Vendor redundancy is not evidence that PocketShell's single-instance design has failover or distributed revocation. No such guarantee should be inherited.

## Transport encryption, termination, and relay trust boundaries

### Takeaway
TLS to a hosted relay authenticates and encrypts that transport leg. Payload secrecy from the relay requires a separate end-to-end protocol with independently authenticated endpoints; encrypting multiple legs is not equivalent.

### Cited Findings
- ngrok verifies its service certificate using bundled certificate authorities and performs a certificate revocation check. Its connector TLS is a long-lived service connection. — [Connector TLS verification](https://ngrok.com/docs/gateway/agent/connectivity)
- ngrok TLS endpoints can terminate TLS at the cloud, agent, or upstream; its documentation reserves payload invisibility to the cloud for the end-to-end configuration. Agent/upstream termination makes the customer responsible for application certificates. Re-encryption after termination is a separate option. — [TLS endpoints](https://ngrok.com/docs/gateway/endpoints/tls)
- Cloudflare separates the encrypted connector connection from the connector-to-local-origin connection. The configured service URL selects HTTP versus HTTPS; HTTPS origin trust requires its own name/CA verification. Zone SSL mode does not replace that local verification. — [HTTPS origins](https://developers.cloudflare.com/tunnel/troubleshooting/https-origins/)

### Inferences
- **Acceptance requirement H4:** document the actual PocketShell path as SSH client → SSH bytes inside browser/client WSS → gateway terminates WSS → opaque SSH bytes inside agent WSS → local agent TCP → SSH daemon. SSH cryptography terminates in the SSH client and daemon; WSS cryptography terminates at the gateway and each client/agent.
- **Acceptance requirement H5:** require normal TLS hostname/chain validation for canonical gateway and supported alias; prohibit an insecure certificate-verification bypass in production clients. Do not copy ngrok's proprietary CA distribution model without an explicit lifecycle design.
- **Acceptance requirement H6:** the client independently verifies and pins the real local SSH host key before SSH user authentication. Gateway-owned registry metadata cannot be sole first-contact trust under the compromised-gateway threat model; changed host keys require independent verification.
- **Acceptance requirement H7:** security language must state that the gateway can observe account/device/session metadata, route traffic, deny service, or disregard its ACLs if compromised. Payload confidentiality depends on actual end-to-end SSH and correct host-key checking, not TLS termination or vendor marketing.

### Gaps
- Neither provider's managed security assurances validate PocketShell's mux framing, browser SSH implementation, host-key pairing, or relay code. These require project-specific evidence.

## Connector enrollment credentials, machine identity, and human access

### Takeaway
Connector credentials authorize a machine's participation in a tunnel; human policy authorizes access to an application. Neither is inherently permission to log in to an SSH operating-system account.

### Cited Findings
- ngrok tunnel authtokens authenticate an agent and start a tunnel session. Credential ACLs restrict what domains/addresses/labels may be bound; omission means unrestricted binding. Ownership may be assigned to a User or Service User. The generated secret is returned only on creation. — [Credential creation](https://ngrok.com/docs/api-reference/credentials/create); [Credential details](https://ngrok.com/docs/api-reference/credentials/get)
- A remotely managed Cloudflare tunnel runs using its token; anyone possessing that token can run a connector for that tunnel. — [Tunnel tokens](https://developers.cloudflare.com/tunnel/reference/tunnel-tokens/)
- Access service tokens are Client ID/Client Secret pairs for automated systems reaching Access-protected applications. Human login and Service Auth are distinct policy mechanisms. A service-token application JWT has an empty `sub`. — [Service tokens](https://developers.cloudflare.com/cloudflare-one/access-controls/service-credentials/service-tokens/); [Application token claims](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/application-token/)
- ngrok documents limited TCP-layer authentication actions such as IP restriction and mutual TLS; it does not describe HTTP OAuth as raw TCP SSH user authentication. — [TCP authentication](https://ngrok.com/docs/gateway/endpoints/tcp)

### Inferences
- **Acceptance requirement H8:** separate human Google issuer+subject ownership, per-device enrollment/signature keys, gateway TLS identity, SSH host keys, and SSH login credentials in documentation, storage, and authorization decisions. A device registration signature proves possession of the registration key, not possession of the asserted SSH host key or an SSH login key.
- **Acceptance requirement H9:** explicit authenticated enrollment binds issuer+subject owner, device ID, registration public key, asserted real SSH host key, canonical service/protocol, and a fresh single-use challenge in one canonical signed transcript. Persist owner/key uniqueness atomically; no silent key replacement or cross-owner device association.
- **Acceptance requirement H10:** each device has separately revocable enrollment credentials stored with restrictive local permissions. No shared fleet secret, Google token, deployment credential, or relay ACL is an SSH authorized key. Keep GitHub OIDC delivery identity separate from all runtime enrollment/user identity.

### Gaps
- ngrok authtoken ACLs are binding scopes, not a specification for per-user stream ACLs. Cloudflare tunnel tokens can intentionally authorize multiple replicas, so they are not evidence of a unique device identity scheme. These products do not establish PocketShell challenge transcript or replay rules.

## Origin-side authentication and independent SSH policy

### Takeaway
Do not treat successful passage through a relay or edge policy as proof of origin identity. SSH server authentication and user authentication must remain explicit endpoint duties unless a deliberate trusted SSH proxy/CA architecture is chosen.

### Cited Findings
- Cloudflare recommends verifying the Access JWT rather than trusting an assertion header. Verification keys rotate; the JWT key ID selects the relevant public key. — [Validate JWTs](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/)
- Cloudflare Tunnel's `access` origin setting can require connector JWT validation with team and application audiences. `noTLSVerify` defaults false; idle keepalive limits are not concurrent-connection limits. — [Origin parameters](https://developers.cloudflare.com/tunnel/reference/origin-parameters/)
- Cloudflare's legacy short-lived SSH certificate setup requires the SSH daemon to trust its SSH CA via `TrustedUserCAKeys`; certificate principals govern Unix login names. The guide warns that this makes host security depend on the Access configuration. It is explicitly not recommended for new deployments, which should use Access for Infrastructure. — [Legacy SSH certificates](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/non-http/short-lived-certificates-legacy/)

### Inferences
- **Acceptance requirement H11:** PocketShell verifies Google JWT signature, issuer, audience, expiration and subject, then derives ownership exclusively from verified claims. A forged header, client-provided owner ID, email alone, or an authenticated device connection cannot substitute for user ownership checks.
- **Acceptance requirement H12:** local SSH daemon independently requires its configured SSH login credentials; tests/evidence must distinguish gateway admission from SSH authentication. Wrong or missing SSH credentials must fail even when gateway ownership passes.
- **Acceptance requirement H13:** local SSH daemon policy controls port/agent/X11 forwarding. Limiting the agent's TCP dial destination to loopback does not itself prevent an authenticated SSH user from creating SSH forwarding channels.

### Gaps
- The documented optional Cloudflare connector JWT control is L7 Access behavior; it is not a drop-in origin-authentication mechanism for PocketShell's raw SSH byte streams. No Cloudflare CA should become a PocketShell trust root merely because the vendor offers certificates.

## Revocation, credential rotation, and active-session lifetime

### Takeaway
Revocation must specify whether it prevents new authentication, closes existing transport sessions, or invalidates endpoint SSH access. These are separate outcomes with different enforcement locations.

### Cited Findings
- Rotating a Cloudflare tunnel token prevents new connections using the old token but existing connectors stay active until restarted. A compromised-token procedure adds forced disconnection of all existing connections. — [Tunnel token rotation](https://developers.cloudflare.com/tunnel/reference/tunnel-tokens/)
- Cloudflare Access service-token secrets support rotation with an explicit overlap window or immediate old-secret revocation. Deleting the service token revokes access; merely revoking existing application sessions leaves valid machine credentials able to obtain a new token. — [Service credential lifecycle](https://developers.cloudflare.com/cloudflare-one/access-controls/service-credentials/service-tokens/)
- Access JWT signing keys normally rotate every six weeks; previous keys remain valid for seven days. Cloudflare recommends dynamic key discovery and matching JWT `kid`, rather than one hard-coded public key. — [Signing-key rotation](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/http-apps/authorization-cookie/validating-json/)
- Cloudflare browser-rendering documentation states application session duration governs new/refreshed connections, not the duration of an active SSH session. — [Browser terminal limitations](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/non-http/browser-rendering/)

### Inferences
- **Acceptance requirement H14:** persist device revocation before acknowledging it; serialize with enrollment, reconnect registration and stream admission; terminate honest-gateway host and client sessions, and reject stale/replayed/new authentication using the revoked key. Define trusted re-enrollment separately.
- **Acceptance requirement H15:** specify active-session behavior for Google token expiration, allowlist removal, owner disablement, idle deadlines and revocation. A successful initial handshake must not imply permanently authenticated transport.
- **Acceptance requirement H16:** document a compromised-gateway response requiring endpoint SSH authorized-key removal (or SSH CA/principal revocation where applicable) and termination of affected SSH sessions when immediate endpoint-side denial is needed. Gateway ACL deletion alone does not protect against a gateway that ignores it.
- **Acceptance requirement H17:** maintain separate rotation procedures for TLS certificates, Google verification keys, device registration keys, SSH host keys and SSH login keys. SSH host-key rotation requires new independent client trust, not transparent registry replacement.

### Gaps
- The ngrok credential-delete page exposes deletion but the fetched text does not establish immediate termination semantics for existing sessions. Do not claim equivalence to PocketShell's proposed close-on-revoke behavior.

## Browser SSH credential location and product differences

### Takeaway
Browser access is a user experience, not a complete credential-security statement. PocketShell must state precisely where its SSH private key is generated, stored, unlocked and used, and treat delivered browser code as a separate trusted component.

### Cited Findings
- Cloudflare's public browser SSH method presents a terminal after Access login and does not require users to install client software or manage SSH keys. Browser-rendered applications support Allow/Block policies but not Bypass/Service Auth. — [Browser SSH](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/use-cases/ssh/ssh-browser-rendering/); [Browser terminal](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/non-http/browser-rendering/)
- The legacy certificate guide says browser SSH otherwise prompts for server username/password and can use configured short-lived certificates. Its native CLI example stores key and certificate files under `~/.cloudflared/`; that example is not evidence of browser private-key storage. — [Legacy certificate configuration](https://developers.cloudflare.com/cloudflare-one/access-controls/applications/non-http/short-lived-certificates-legacy/)
- Access for Infrastructure is a different method using Cloudflare One Client, granular target/username policies and short-lived certificates. It supports SSH command logging; downloaded logs are encrypted using the customer's public key, while Enterprise Logpush logs are not encrypted with that key. It excludes port, agent and X11 forwarding. — [Infrastructure SSH](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/use-cases/ssh/ssh-infrastructure-access/)

### Inferences
- **Acceptance requirement H18:** document PocketShell browser key handling from its own implementation: plaintext/private-key presence in browser memory, persistent encrypted storage if used, unlock/sign operations, lifetime and clearing behavior; prove no SSH private-key upload to gateway or agent. Do not present provider “keyless” UX as evidence for PocketShell storage design.
- **Acceptance requirement H19:** frontend distribution can read terminal plaintext or use unlocked signing keys if compromised. Gateway runtime/deployment identities must not modify the frontend bucket/distribution or its deployment pipeline. Host-key pairing must survive a malicious registry, while compromised browser delivery remains an explicit trust limitation.
- Infrastructure command logging demonstrates a materially different SSH trust/processing model from an opaque byte relay. Its encrypted log-export claim is about stored exports, not proof that the provider never processes SSH commands.

### Gaps
- The reviewed official public-browser guides do not identify exact browser SSH private-key generation, custody, storage or host-key verification mechanics. Do not invent these or claim browser-held keys from a native CLI example.

## Rate limits, resource budgets, and plan boundaries

### Takeaway
HTTP request limits and provider protection do not bound all costs of long-lived SSH/WebSocket streams. A custom gateway needs admission, memory, framing and dial budgets at its own protocol boundaries.

### Cited Findings
- ngrok's rate-limit action supports the `on_http_request` phase, returns HTTP 429 on excess, and applies capacity independently per ingress server. This is not a global byte-stream or SSH-channel quota. — [Rate-limit action](https://ngrok.com/docs/gateway/traffic-policy/actions/rate-limit)
- ngrok TLS endpoints document ClientHello/handshake/idle deadlines and message-size limits, with support required to configure connection limits/timeouts. These concern ngrok TLS endpoints, not PocketShell SSH over WSS. — [TLS endpoint limits](https://ngrok.com/docs/gateway/endpoints/tls)
- ngrok TCP on Free requires a payment method; Cloudflare Tunnel availability on all plans does not mean every Access product/log feature is included. Infrastructure SSH Logpush is Enterprise-only, while downloaded SSH logs are available on all plans. — [TCP availability](https://ngrok.com/docs/gateway/endpoints/tcp); [Tunnel overview](https://developers.cloudflare.com/tunnel/); [Infrastructure logs](https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/use-cases/ssh/ssh-infrastructure-access/)

### Inferences
- **Acceptance requirement H20:** specify exact global and per-owner budgets for unauthenticated sockets, auth/challenge deadlines, enrollment attempts, devices, connected hosts, active streams, frame/chunk sizes, queued/buffered bytes and local SSH dials. Include connection-rate limits before expensive identity work and fair limits after authentication.
- **Acceptance requirement H21:** slow/blocked stream writes must not indefinitely block heartbeats, control messages or revocation; cancellation and cleanup must release budget accounting. HTTP upgrade rate limiting does not replace these stream controls.
- **Acceptance requirement H22:** product claims must distinguish transport encryption, access policy, DDoS mitigation, SSH secrecy, origin authentication, availability and logging. No vendor plan entitlement or edge protection transfers automatically to the custom gateway. Avoid repeating the Tunnel marketing phrase implying zero attack surface.

### Gaps
- No official source supplies appropriate numeric budgets for this custom single-instance multiplexed gateway. Choose documented values from implementation capacity and measured defensive validation; vendor defaults are examples, not acceptance thresholds.
