# PocketShell gateway

`gateway.pocketshell.io` (legacy alias `relay.pocketshell.io`) — the Go server
that lets the PocketShell browser speak SSH end to end. The browser runs the
SSH client itself; this gateway ferries opaque SSH bytes after verifying who
you are. The wire protocol of the original proxy is **frozen**
(WebSocket ⇄ TCP byte pipe behind a verified Google ID token); a new
versioned tunnel API (opaque end-to-end SSH streams over one persistent host
connection) is being added alongside it and stays disabled until an identity
registry is configured.

## Repository map

| Path | Owner | Contents |
| --- | --- | --- |
| `relay.go` | root integration | the original proxy front door + integration point for the new API |
| `internal/identity` | identity worker | Google JWT verification, device registry, enrollment, Ed25519 challenges |
| `internal/tunnel`, `internal/hostagent` | tunnel worker | versioned multi-user reverse tunnels, host agent |
| `cmd/pocketshell-link` | tunnel worker | local host CLI (`--server ws://gateway:PORT` for dev) |
| `.github/`, `infra/github-actions.yaml`, `scripts/`, `Makefile`, `docs/deployment.md` | delivery worker (this branch) | CI/CD, one-time bootstrap, deployment, e2e and regression harnesses, helper build matrix + wheels, docs |

`docs/design.md` is the implementation contract; `docs/deployment.md` is the
deployment & security contract; `docs/deployment-review-findings.md` is the
independent review ledger this branch implements (D1–D14 fixed; the R1–R5
required-repair round — structured systemd parsing, validate-first helper
provisioning, strict bootstrap subject, runtime-role IAM fences, mandatory
fail-closed e2e gate — is implemented and regression-harnessed).

## Quickstart (development)

```sh
make build-arm64            # cross-compile the gateway for linux/arm64
make test                   # go test -race ./... (includes contract tests)
make check                  # fmt + vet + test + contract + ALL regression harnesses
make e2e-docker             # real SSH through the gateway inside Docker
make build-matrix           # helper binaries for linux+darwin / amd64+arm64 (needs cmd/pocketshell-link)
make wheels                 # platform wheels carrying the helper (built locally; never published)
```

Run a local gateway in explicit development mode (plain WS, no TLS, token and
private-host checks lifted — refuses to combine with a public domain):

```sh
go run . -listen :8080 -dev-allow-any-token -dev-allow-private-hosts
```

Dial through it like the browser does:

```
ws://127.0.0.1:8080/upgrade?token=<google-id-token>&host=<host>&port=<port>
```

The Docker e2e (`make e2e-docker`) exercises the real thing end to end: a
client speaks SSH over that WebSocket toward a strict sshd fixture — pinned
host key accepted, **wrong host key rejected**, **unenrolled client key
rejected**, and a command round-trips.

### New API / pocketshell-link convention

The host CLI takes `--server ws://gateway:PORT` (e.g. the compose gateway name)
plus an explicit insecure-development opt-in on both ends. The gateway's dev
flags hard-fail when combined with a public domain, so the opt-in cannot leak
into production. `scripts/e2e/run-newapi.sh` runs the production-shaped
compose fixture and is a MANDATORY gate: missing runtime sources, Docker,
compose or tooling fail nonzero with the dependency named — it never
succeeds by skipping, has no legacy-adapter fallback and takes no waivers.

## CI/CD

| Target | What runs |
| --- | --- |
| `make test` | `go test -race -count=1 ./...` — includes the delivery contract tests |
| `make vet` / `make fmt-check` | go vet / gofmt gates |
| `make vuln` | govulncheck (pinned v1.8.0) |
| `make build-arm64` / `make artifacts` | ARM64 gateway (+ link CLI when present); release set with archive+binary digests, `VERSION`, digest-bound manifest |
| `make contract` | semantic CI/CD contract suite (OIDC trust, IAM boundaries incl. the runtime signing-key/path fences, allowedPattern matrices, workflow pinning, provisioning sync) |
| `make installer-harness` / `make api-harness` / `make bootstrap-harness` / `make provision-harness` / `make packaging-harness` | regression harnesses: on-instance installer (incl. real structured-systemd fixtures), deploy driver, bootstrap trust validation, generated-document provisioning sequence, wheel/matrix packaging (all no-AWS, all real CI steps) |
| `make workflow-harness` | workflow checker + 17 mutation negatives (a checker that misses a bad mutation is a failed test) |
| `make e2e-docker` / `make e2e-newapi` | the SSH end-to-end above / the production-shaped new-API gate (mandatory; missing deps fail) |
| `make build-matrix` / `make wheels` | helper release infra: 4-platform matrix + sha256 sidecars + provenance; platform wheels (never published) |

Push/PR → `ci.yml` runs EVERY gate at that exact commit; only its `deploy`
job — only on a push to `refs/heads/main` of the canonical repo with no
failed/cancelled/skipped need — calls the reusable `deploy.yml`, which
assumes `pocketshell-github-deploy` via GitHub OIDC (exact immutable
subject, no wildcards, PRs/forks/branches rejected by AWS), uploads to
`s3://…/artifacts/<sha256>/` with `IfNoneMatch:*` immutability, and invokes
the single bounded SSM deploy document on the single pinned instance. The
instance provisions the IMDS helpers through a validate-first/atomic-rename
preamble, verifies both digests + version + manifest, installs atomically
with the legacy binary preserved, restarts `pocketshell-relay` with exactly
one `-domain gateway.pocketshell.io -aliases relay.pocketshell.io` pair,
health-checks with **trusted TLS on both names**, the running process's
binary hash and the structured systemd property audit, and rolls back
automatically on any failure. No approval gates; failed deploys fail closed
to the previous binary.

One-time bootstrap (coordinator): `scripts/bootstrap-aws.sh` — the trusted
OIDC subject is pinned to the verified immutable value (no override, no
fallback); see `docs/deployment.md` §3 for the DNS-first prerequisites and
the read-only IAM-simulation verification (including the explicit-deny
signing-key/path fences) it performs.

## Security model, in one paragraph

SSH authenticates shells; the gateway authenticates ownership. The legacy
proxy verifies a Google ID token + allowlist before any dial, with SSRF guards
and bounded sessions. The new API (disabled until a registry is configured)
requires enrolled Ed25519 device keys with proof of possession, issuer+subject
account identity, single-use challenges, and pinned real SSH host keys — no
shared relay token, no custom shell protocol, no credentials in URLs or logs.
Deployment authority equals GitHub main-branch write access, stated honestly;
the deploy role's permissions are minimal and simulation-tested. The Astra
threat model (compromised gateway) is covered by the e2e negative controls:
the gateway cannot mint shell access, impersonate hosts, or replay credentials
— SSH's own host-key and client-key checks fail closed. Frontend supply-chain
compromise is explicitly out of scope for these guarantees (D13).

## Limitations

- The new tunnel API requires a configured identity registry and explicit
  device enrollment; until then only the frozen legacy proxy serves. The
  deploy pipeline ACTIVATES it explicitly: every deploy carries the
  activation configuration (pinned `-certdir` base and `-registry` state
  file) and the on-instance health gate fails the deploy — with automatic
  rollback — unless `/healthz` reports `registry=enabled` + `tunnel=enabled`
  AND the mounted routes reject anonymous requests (401/426, never 404). A
  version/commit-healthy deploy that never mounted the API is impossible to
  ship green.
- First production deploy of the canonical name requires DNS for
  `gateway.pocketshell.io` to already point at the instance (ACME issuance
  happens on first start); the pipeline fails closed otherwise.
- The deploy role can upload artifacts and run exactly one pinned SSM
  document — it cannot read objects, delete, open sessions, touch IAM/DNS, or
  run `AWS-RunShellScript`.
- S3 immutability is per-object conditional writes (`IfNoneMatch:*`), not
  bucket Object Lock (existing bucket; a coordinator-level change if ever
  wanted).
- D13 on-instance hardening is implemented and audited (dedicated service
  user, capability-bound unit, IMDS deny with verified fallback, structured
  systemd property audit); the instance role's pre-existing legacy grants
  remain root/security-owned, now fenced by the R4 explicit denies.
- Helper distribution: version/commit injection is live (the metadata seam
  `main.version`/`main.commit` landed in the runtime); wheels are built but
  never published, and the publish channel is a coordinator decision.
